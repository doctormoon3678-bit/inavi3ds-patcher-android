plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.doctormoon.inavi3dspatcher"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.doctormoon.inavi3dspatcher"
        minSdk = 26
        // 28: 외부 저장소 레거시 접근을 그대로 쓰기 위해 (사이드로드 전용 앱)
        targetSdk = 28
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}
