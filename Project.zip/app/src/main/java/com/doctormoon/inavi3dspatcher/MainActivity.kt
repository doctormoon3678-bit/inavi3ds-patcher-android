package com.doctormoon.inavi3dspatcher

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.OpenableColumns
import android.provider.Settings
import android.view.View
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream

class MainActivity : Activity() {

    private val reqApk = 11
    private val reqApktool = 12
    private val reqSigner = 13
    private val reqPerm = 21

    private val downloads = File(Environment.getExternalStorageDirectory(), "Download")
    private val workDir = File(downloads, "inavi3ds_patcher_termux")

    private lateinit var statusView: TextView
    private lateinit var apkEdit: EditText
    private lateinit var detectView: TextView
    private lateinit var verGroup: RadioGroup
    private lateinit var itemsBox: LinearLayout
    private lateinit var ksSwitch: Switch
    private lateinit var ksBox: LinearLayout
    private lateinit var ksPath: EditText
    private lateinit var ksAlias: EditText
    private lateinit var ksPass: EditText

    private var curVer: String? = null
    private val itemChecks = LinkedHashMap<String, CheckBox>()
    private val excluded = HashSet<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        requestNeededPermissions()
        refreshStatus()
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    // ---------------------------------------------------------------- UI 구성

    private fun buildUi() {
        val ctx: Context = this
        val scroll = ScrollView(ctx)
        scroll.setBackgroundColor(Ui.BG)
        scroll.isFillViewport = true
        val root = LinearLayout(ctx)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(Ui.dp(ctx, 18), Ui.dp(ctx, 28), Ui.dp(ctx, 18), Ui.dp(ctx, 24))
        scroll.addView(root)

        root.addView(Ui.text(ctx, "iNavi 3DS Patcher", 24f, Ui.TXT, true))
        root.addView(Ui.text(ctx, "아이나비 3DS APK를 폰에서 패치합니다 (Termux 필요)", 12f, Ui.SUB))

        // 0. 준비 상태
        val c0 = Ui.card(ctx, "0  준비 상태")
        statusView = Ui.text(ctx, "", 13f, Ui.TXT)
        statusView.typeface = Typeface.MONOSPACE
        c0.addView(statusView, Ui.vlp(ctx, 8))
        c0.addView(
            Ui.row(
                ctx,
                Ui.button(ctx, "엔진 설치") { installEngine() },
                Ui.button(ctx, "Termux 환경 설치") { runSetup() }
            ), Ui.vlp(ctx, 10)
        )
        c0.addView(
            Ui.row(
                ctx,
                Ui.button(ctx, "apktool.jar 선택") { pickFile(reqApktool) },
                Ui.button(ctx, "signer.jar 선택") { pickFile(reqSigner) }
            ), Ui.vlp(ctx, 6)
        )
        c0.addView(
            Ui.row(ctx, Ui.button(ctx, "권한 허용") { requestAllPermissions() }), Ui.vlp(ctx, 6)
        )
        c0.addView(
            Ui.text(
                ctx,
                "처음 한 번: Termux에서 아래 명령 실행 후 Termux를 완전히 종료했다가 다시 여세요.\n" +
                    "mkdir -p ~/.termux && echo \"allow-external-apps=true\" >> ~/.termux/termux.properties",
                11f, Ui.SUB
            ), Ui.vlp(ctx, 10)
        )
        root.addView(c0, Ui.vlp(ctx, 16))

        // 1. APK
        val c1 = Ui.card(ctx, "1  APK 선택")
        apkEdit = Ui.edit(ctx, "APK 경로 (또는 아래 버튼으로 선택)")
        c1.addView(apkEdit, Ui.vlp(ctx, 8))
        c1.addView(Ui.row(ctx, Ui.button(ctx, "APK 찾아보기") { pickFile(reqApk) }), Ui.vlp(ctx, 6))
        detectView = Ui.text(ctx, "", 12f, Ui.SUB)
        c1.addView(detectView, Ui.vlp(ctx, 6))
        root.addView(c1, Ui.vlp(ctx, 12))

        // 2. 패치 옵션 / 항목
        val c2 = Ui.card(ctx, "2  패치 옵션")
        verGroup = RadioGroup(ctx)
        verGroup.orientation = RadioGroup.HORIZONTAL
        c2.addView(verGroup, Ui.vlp(ctx, 6))
        itemsBox = LinearLayout(ctx)
        itemsBox.orientation = LinearLayout.VERTICAL
        c2.addView(itemsBox, Ui.vlp(ctx, 6))
        root.addView(c2, Ui.vlp(ctx, 12))

        // 3. 서명
        val c3 = Ui.card(ctx, "3  서명")
        ksSwitch = Switch(ctx)
        ksSwitch.text = "내 키스토어 사용 (끄면 자동 디버그 키)"
        ksSwitch.setTextColor(Ui.TXT)
        c3.addView(ksSwitch, Ui.vlp(ctx, 6))
        ksBox = LinearLayout(ctx)
        ksBox.orientation = LinearLayout.VERTICAL
        ksBox.visibility = View.GONE
        ksPath = Ui.edit(ctx, "키스토어 경로 (.jks / .p12)")
        ksAlias = Ui.edit(ctx, "별칭 (alias)")
        ksPass = Ui.edit(ctx, "비밀번호", true)
        ksBox.addView(ksPath, Ui.vlp(ctx, 6))
        ksBox.addView(ksAlias, Ui.vlp(ctx, 6))
        ksBox.addView(ksPass, Ui.vlp(ctx, 6))
        c3.addView(ksBox, Ui.vlp(ctx, 4))
        ksSwitch.setOnCheckedChangeListener { _, on -> ksBox.visibility = if (on) View.VISIBLE else View.GONE }
        root.addView(c3, Ui.vlp(ctx, 12))

        // 시작
        root.addView(Ui.button(ctx, "패치 시작 (Termux에서 실행)", true) { startPatch() }, Ui.vlp(ctx, 16))
        val foot = Ui.text(ctx, "Create by DoctorMoon", 11f, Ui.SUB)
        foot.gravity = android.view.Gravity.END
        root.addView(foot, Ui.vlp(ctx, 14))

        setContentView(scroll)
        populateVersions()
    }

    private fun populateVersions() {
        val vers = Packs.versions(this)
        for (v in vers) {
            val rb = RadioButton(this)
            rb.text = v
            rb.id = View.generateViewId()
            rb.tag = v
            rb.setTextColor(Ui.TXT)
            rb.buttonTintList = ColorStateList.valueOf(Ui.ACC)
            verGroup.addView(rb)
        }
        verGroup.setOnCheckedChangeListener { g, checkedId ->
            val rb = g.findViewById<RadioButton>(checkedId)
            if (rb != null) selectVersion(rb.tag as String)
        }
        if (vers.isNotEmpty()) (verGroup.getChildAt(vers.size - 1) as RadioButton).isChecked = true
    }

    private fun selectVersion(ver: String) {
        curVer = ver
        excluded.clear()
        itemChecks.clear()
        itemsBox.removeAllViews()
        val pack = try {
            Packs.load(this, ver)
        } catch (e: Exception) {
            toast("패치팩을 읽지 못했습니다: " + e.message)
            return
        }
        for (item in pack.items) {
            val n = item.files.size
            val cb = Ui.check(this, item.title + (if (n > 0) "  ($n)" else ""), item.default)
            itemChecks[item.id] = cb
            itemsBox.addView(cb, Ui.vlp(this, 8))
            if (item.desc.isNotEmpty()) {
                val d = Ui.text(this, item.desc, 11f, Ui.SUB)
                d.setPadding(Ui.dp(this, 36), 0, 0, 0)
                itemsBox.addView(d)
            }
            if (n > 0) {
                val b = Ui.button(this, "파일 선택") { showFilePicker(item) }
                val lp = Ui.vlp(this, 4)
                lp.marginStart = Ui.dp(this, 36)
                itemsBox.addView(b, lp)
            }
        }
    }

    private fun showFilePicker(item: PackItem) {
        val names = Array(item.files.size) { i ->
            val f = item.files[i]
            (if (f.op == "add") "[추가] " else "[교체] ") + f.path.substringAfterLast('/')
        }
        val checked = BooleanArray(item.files.size) { i -> item.files[i].path !in excluded }
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle(item.title)
            .setMultiChoiceItems(names, checked) { _, which, isChecked ->
                val p = item.files[which].path
                if (isChecked) excluded.remove(p) else excluded.add(p)
            }
            .setPositiveButton("확인", null)
            .show()
    }

    // ---------------------------------------------------------------- 권한 / 상태

    private fun hasStorage(): Boolean {
        if (Build.VERSION.SDK_INT >= 30 && Environment.isExternalStorageManager()) return true
        return checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
    }

    private fun requestNeededPermissions() {
        val need = ArrayList<String>()
        if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            need.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
            need.add(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
        if (Termux.installed(this) && checkSelfPermission(Termux.PERM) != PackageManager.PERMISSION_GRANTED) {
            need.add(Termux.PERM)
        }
        if (need.isNotEmpty()) requestPermissions(need.toTypedArray(), reqPerm)
    }

    private fun requestAllPermissions() {
        requestNeededPermissions()
        if (Build.VERSION.SDK_INT >= 30 && !Environment.isExternalStorageManager()) {
            try {
                startActivity(
                    Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName"))
                )
            } catch (e: Exception) {
                toast("설정 > 앱 > 이 앱 > 모든 파일 접근을 직접 허용해 주세요")
            }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refreshStatus()
    }

    private fun refreshStatus() {
        val lines = ArrayList<String>()
        fun row(ok: Boolean, s: String) {
            lines.add((if (ok) "✓ " else "✗ ") + s)
        }
        row(Termux.installed(this), "Termux 설치됨")
        row(checkSelfPermission(Termux.PERM) == PackageManager.PERMISSION_GRANTED, "Termux 실행 권한")
        row(hasStorage(), "저장공간 권한")
        row(File(workDir, "patcher_termux.py").exists(), "엔진 설치됨")
        row(File(workDir, "tools/apktool.jar").exists(), "tools/apktool.jar")
        row(File(workDir, "tools/uber-apk-signer.jar").exists(), "tools/uber-apk-signer.jar")
        statusView.text = lines.joinToString("\n")
    }

    // ---------------------------------------------------------------- 파일 처리

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
    }

    private fun pickFile(code: Int) {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "*/*"
        startActivityForResult(i, code)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        when (requestCode) {
            reqApk -> importApk(uri)
            reqApktool -> importTool(uri, "apktool.jar")
            reqSigner -> importTool(uri, "uber-apk-signer.jar")
        }
    }

    private fun displayName(uri: Uri): String {
        contentResolver.query(uri, null, null, null, null)?.use { c ->
            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (i >= 0 && c.moveToFirst()) return c.getString(i)
        }
        return uri.lastPathSegment?.substringAfterLast('/') ?: "input.apk"
    }

    private fun copyUri(uri: Uri, dest: File) {
        dest.parentFile?.mkdirs()
        val input = contentResolver.openInputStream(uri) ?: throw IllegalStateException("파일을 열 수 없습니다")
        input.use { i -> FileOutputStream(dest).use { o -> i.copyTo(o) } }
    }

    private fun importApk(uri: Uri) {
        toast("APK를 복사하는 중…")
        Thread {
            try {
                var name = displayName(uri)
                if (!name.endsWith(".apk", ignoreCase = true)) name += ".apk"
                val dest = File(workDir, "input/$name")
                copyUri(uri, dest)
                runOnUiThread {
                    apkEdit.setText(dest.absolutePath)
                    detectVersion(dest.absolutePath)
                    toast("APK 준비 완료")
                }
            } catch (e: Exception) {
                runOnUiThread { toast("APK 복사 실패 (저장공간 권한 확인): " + e.message) }
            }
        }.start()
    }

    private fun importTool(uri: Uri, name: String) {
        Thread {
            try {
                copyUri(uri, File(workDir, "tools/$name"))
                runOnUiThread {
                    toast("$name 저장 완료")
                    refreshStatus()
                }
            } catch (e: Exception) {
                runOnUiThread { toast("복사 실패: " + e.message) }
            }
        }.start()
    }

    /** 선택한 APK의 버전을 읽어 맞는 패치 옵션을 자동 선택 */
    private fun detectVersion(path: String) {
        val info = packageManager.getPackageArchiveInfo(path, 0)
        val vn = info?.versionName
        if (vn == null) {
            detectView.text = "버전을 확인하지 못했습니다"
            return
        }
        detectView.text = "감지된 버전: $vn"
        for (i in 0 until verGroup.childCount) {
            val rb = verGroup.getChildAt(i) as RadioButton
            if (vn.startsWith(rb.tag as String)) {
                rb.isChecked = true
                break
            }
        }
    }

    private fun copyAssetDir(path: String, dest: File) {
        val names = assets.list(path) ?: return
        if (names.isEmpty()) {
            dest.parentFile?.mkdirs()
            assets.open(path).use { i -> FileOutputStream(dest).use { o -> i.copyTo(o) } }
        } else {
            dest.mkdirs()
            for (n in names) copyAssetDir("$path/$n", File(dest, n))
        }
    }

    private fun installEngine() {
        if (!hasStorage()) {
            toast("먼저 저장공간 권한을 허용하세요")
            return
        }
        toast("엔진을 설치하는 중…")
        Thread {
            try {
                File(workDir, "tools").mkdirs()
                copyAssetDir("engine", workDir)
                runOnUiThread {
                    toast("엔진 설치 완료: " + workDir.absolutePath)
                    refreshStatus()
                }
            } catch (e: Exception) {
                runOnUiThread { toast("설치 실패: " + e.message) }
            }
        }.start()
    }

    // ---------------------------------------------------------------- Termux 실행

    private fun termuxHelp(e: Exception) {
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("Termux 실행 실패")
            .setMessage(
                "1) Termux가 설치되어 있어야 합니다.\n" +
                    "2) 위 '권한 허용'으로 Termux 실행 권한을 허용하세요.\n" +
                    "3) Termux에서 아래를 실행하고 Termux를 완전히 종료 후 다시 여세요.\n\n" +
                    "mkdir -p ~/.termux && echo \"allow-external-apps=true\" >> ~/.termux/termux.properties\n\n" +
                    "(" + e.javaClass.simpleName + ": " + e.message + ")"
            )
            .setPositiveButton("확인", null)
            .show()
    }

    private fun runSetup() {
        val script = File(workDir, "setup_termux.sh")
        if (!script.exists()) {
            toast("먼저 '엔진 설치'를 하세요")
            return
        }
        try {
            Termux.run(this, Termux.PREFIX + "/bin/sh", arrayOf(script.absolutePath), workDir.absolutePath)
        } catch (e: Exception) {
            termuxHelp(e)
        }
    }

    private fun startPatch() {
        val apk = apkEdit.text.toString().trim()
        if (!File(apk).isFile) {
            toast("APK 파일을 선택하세요")
            return
        }
        val ver = curVer
        if (ver == null) {
            toast("패치 옵션을 선택하세요")
            return
        }
        val ids = itemChecks.filter { it.value.isChecked }.keys.toList()
        if (ids.isEmpty()) {
            toast("적용할 항목을 하나 이상 선택하세요")
            return
        }
        if (!File(workDir, "patcher_termux.py").exists()) {
            toast("먼저 '엔진 설치'를 하세요")
            return
        }
        if (!File(workDir, "tools/apktool.jar").exists() || !File(workDir, "tools/uber-apk-signer.jar").exists()) {
            toast("apktool.jar 와 signer.jar 를 먼저 선택하세요")
            return
        }
        val base = File(apk).name.removeSuffix(".apk").removeSuffix(".APK")
        val out = File(downloads, base + "_patched.apk")

        val args = ArrayList<String>()
        args.add(File(workDir, "patcher_termux.py").absolutePath)
        args.add("--apk"); args.add(apk)
        args.add("--ver"); args.add(ver)
        args.add("--items"); args.add(ids.joinToString(","))
        args.add("--out"); args.add(out.absolutePath)
        args.add("--yes")
        if (excluded.isNotEmpty()) {
            args.add("--exclude"); args.add(excluded.joinToString(","))
        }
        if (ksSwitch.isChecked) {
            val kp = ksPath.text.toString().trim()
            val ka = ksAlias.text.toString().trim()
            val kw = ksPass.text.toString()
            if (kp.isEmpty() || ka.isEmpty() || kw.isEmpty()) {
                toast("키스토어 정보를 모두 입력하세요")
                return
            }
            args.add("--ks"); args.add(kp)
            args.add("--alias"); args.add(ka)
            args.add("--pass"); args.add(kw)
        }
        try {
            Termux.run(this, Termux.PREFIX + "/bin/python", args.toTypedArray(), workDir.absolutePath)
            toast("Termux에서 패치를 시작합니다. 결과: " + out.absolutePath)
        } catch (e: Exception) {
            termuxHelp(e)
        }
    }
}
