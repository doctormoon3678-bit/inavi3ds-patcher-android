package com.doctormoon.inavi3dspatcher

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.InputType
import android.util.TypedValue
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

/** 다크모드 UI 도우미 (XML 레이아웃 없이 코드로 구성) */
object Ui {
    val BG = Color.parseColor("#0E1014")
    val CARD = Color.parseColor("#161920")
    val CARD2 = Color.parseColor("#1D212B")
    val ACC = Color.parseColor("#7C93FF")
    val TXT = Color.parseColor("#E8EAF0")
    val SUB = Color.parseColor("#8A90A2")

    fun dp(ctx: Context, v: Int): Int = (v * ctx.resources.displayMetrics.density + 0.5f).toInt()

    fun rounded(ctx: Context, color: Int, radiusDp: Int): GradientDrawable {
        val d = GradientDrawable()
        d.setColor(color)
        d.cornerRadius = dp(ctx, radiusDp).toFloat()
        return d
    }

    fun vlp(ctx: Context, topDp: Int = 0): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        p.topMargin = dp(ctx, topDp)
        return p
    }

    fun text(ctx: Context, s: String, sizeSp: Float = 14f, color: Int = TXT, bold: Boolean = false): TextView {
        val t = TextView(ctx)
        t.text = s
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sizeSp)
        t.setTextColor(color)
        if (bold) t.setTypeface(t.typeface, Typeface.BOLD)
        return t
    }

    fun card(ctx: Context, title: String): LinearLayout {
        val c = LinearLayout(ctx)
        c.orientation = LinearLayout.VERTICAL
        c.background = rounded(ctx, CARD, 14)
        val pad = dp(ctx, 16)
        c.setPadding(pad, pad, pad, pad)
        c.addView(text(ctx, title, 15f, TXT, true))
        return c
    }

    fun button(ctx: Context, label: String, primary: Boolean = false, onClick: () -> Unit): Button {
        val b = Button(ctx)
        b.text = label
        b.isAllCaps = false
        b.setTextColor(if (primary) Color.parseColor("#0B0D12") else TXT)
        b.background = rounded(ctx, if (primary) ACC else CARD2, 10)
        b.setOnClickListener { onClick() }
        return b
    }

    fun edit(ctx: Context, hint: String, password: Boolean = false): EditText {
        val e = EditText(ctx)
        e.hint = hint
        e.setHintTextColor(SUB)
        e.setTextColor(TXT)
        e.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
        e.isSingleLine = true
        e.background = rounded(ctx, CARD2, 10)
        val pad = dp(ctx, 12)
        e.setPadding(pad, pad, pad, pad)
        if (password) e.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        return e
    }

    fun check(ctx: Context, label: String, checked: Boolean): CheckBox {
        val c = CheckBox(ctx)
        c.text = label
        c.isChecked = checked
        c.setTextColor(TXT)
        c.buttonTintList = ColorStateList.valueOf(ACC)
        return c
    }

    fun row(ctx: Context, vararg views: View): LinearLayout {
        val r = LinearLayout(ctx)
        r.orientation = LinearLayout.HORIZONTAL
        for (v in views) {
            val p = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            p.marginEnd = dp(ctx, 6)
            r.addView(v, p)
        }
        return r
    }
}
