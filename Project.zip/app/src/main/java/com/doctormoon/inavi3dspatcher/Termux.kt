package com.doctormoon.inavi3dspatcher

import android.content.Context
import android.content.Intent

/** Termux RUN_COMMAND 연동 (Termux 쪽에서 allow-external-apps=true 설정 필요) */
object Termux {
    const val PKG = "com.termux"
    const val PERM = "com.termux.permission.RUN_COMMAND"
    const val PREFIX = "/data/data/com.termux/files/usr"
    const val HOME = "/data/data/com.termux/files/home"

    fun installed(ctx: Context): Boolean = try {
        ctx.packageManager.getPackageInfo(PKG, 0)
        true
    } catch (e: Exception) {
        false
    }

    /** Termux 세션을 열어 명령을 실행한다 (진행 상황은 Termux 화면에 표시됨) */
    fun run(ctx: Context, exe: String, args: Array<String>, workDir: String) {
        val intent = Intent("com.termux.RUN_COMMAND")
        intent.setClassName(PKG, "com.termux.app.RunCommandService")
        intent.putExtra("com.termux.RUN_COMMAND_PATH", exe)
        intent.putExtra("com.termux.RUN_COMMAND_ARGUMENTS", args)
        intent.putExtra("com.termux.RUN_COMMAND_WORKDIR", workDir)
        intent.putExtra("com.termux.RUN_COMMAND_BACKGROUND", false)
        intent.putExtra("com.termux.RUN_COMMAND_SESSION_ACTION", "0")
        ctx.startForegroundService(intent)
    }
}
