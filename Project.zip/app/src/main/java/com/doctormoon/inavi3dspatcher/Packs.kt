package com.doctormoon.inavi3dspatcher

import android.content.Context
import org.json.JSONObject

data class PackFile(val path: String, val op: String)

data class PackItem(
    val id: String,
    val title: String,
    val desc: String,
    val default: Boolean,
    val files: List<PackFile>
)

data class Pack(val version: String, val items: List<PackItem>)

/** assets/engine/patches/<버전>/manifest.json 에서 패치 항목을 읽는다 */
object Packs {
    private const val ROOT = "engine/patches"

    fun versions(ctx: Context): List<String> =
        (ctx.assets.list(ROOT) ?: emptyArray()).sorted()

    fun load(ctx: Context, ver: String): Pack {
        val text = ctx.assets.open("$ROOT/$ver/manifest.json").bufferedReader(Charsets.UTF_8).use { it.readText() }
        val arr = JSONObject(text).getJSONArray("items")
        val items = ArrayList<PackItem>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val fa = o.getJSONArray("files")
            val files = ArrayList<PackFile>()
            for (j in 0 until fa.length()) {
                val f = fa.getJSONObject(j)
                files.add(PackFile(f.getString("path"), f.optString("op", "replace")))
            }
            items.add(
                PackItem(
                    o.getString("id"),
                    o.getString("title"),
                    o.optString("desc", ""),
                    o.optBoolean("default", true),
                    files
                )
            )
        }
        return Pack(ver, items)
    }
}
