#!/usr/bin/env python3
"""iNavi 3DS Patcher - Termux(안드로이드) 터미널 버전
사용법:  python patcher_termux.py            (대화형 메뉴)
         python patcher_termux.py --apk /sdcard/Download/a.apk --ver 4.0 --yes   (비대화형)
"""
import os, sys, glob, argparse, tempfile, shutil, re
import engine

TTY = sys.stdout.isatty()
def c(code, s): return f"\033[{code}m{s}\033[0m" if TTY else s
BOLD = lambda s: c("1", s); DIM = lambda s: c("2", s); ACC = lambda s: c("38;5;147", s)
OK = lambda s: c("32", s); ERR = lambda s: c("31", s)


def banner():
    print(ACC("╭──────────────────────────────────╮"))
    print(ACC("│") + BOLD("   iNavi 3DS Patcher  ·  Termux   ") + ACC("│"))
    print(ACC("╰──────────────────────────────────╯"))
    print(DIM("                  Create by DoctorMoon\n"))


def ask(prompt, default=""):
    try:
        v = input(prompt).strip()
    except EOFError:
        v = ""
    return v or default


def parse_nums(text, n):
    out = set()
    for tok in re.split(r"[,\s]+", text.strip()):
        if not tok: continue
        m = re.fullmatch(r"(\d+)-(\d+)", tok)
        if m: out.update(range(int(m[1]), int(m[2]) + 1))
        elif tok.isdigit(): out.add(int(tok))
    return {i for i in out if 1 <= i <= n}


def find_apks():
    dirs = ["~/storage/downloads", "/storage/emulated/0/Download", "/sdcard/Download", "."]
    seen, out = set(), []
    for d in dirs:
        for p in sorted(glob.glob(os.path.join(os.path.expanduser(d), "*.apk"))):
            r = os.path.realpath(p)
            if r not in seen: seen.add(r); out.append(p)
    return out


def pick_apk():
    apks = find_apks()
    print(BOLD("1. APK 선택"))
    for i, p in enumerate(apks, 1): print(f"  {i}) {os.path.basename(p)}  {DIM(os.path.dirname(p))}")
    while True:
        v = ask("번호 또는 APK 전체 경로 입력: ")
        if v.isdigit() and 1 <= int(v) <= len(apks): return apks[int(v) - 1]
        v = os.path.expanduser(v.strip("'\""))
        if os.path.isfile(v): return v
        print(ERR("  파일을 찾을 수 없습니다."))


def pick_pack(packs):
    vers = sorted(packs)
    print("\n" + BOLD("2. 패치 옵션"))
    for i, v in enumerate(vers, 1): print(f"  {i}) {v}")
    while True:
        v = ask(f"번호 선택 [{len(vers)}]: ", str(len(vers)))
        if v.isdigit() and 1 <= int(v) <= len(vers): return vers[int(v) - 1]
        if v in packs: return v


def pick_files(item, excluded):
    files = item["files"]
    while True:
        print("\n" + BOLD(f"[{item['title']}] 파일 {len(files)}개") + DIM("  번호=토글, a=모두선택, n=모두해제, 엔터=완료"))
        for i, r in enumerate(files, 1):
            mark = "x" if r["path"] not in excluded else " "
            tag = "추가" if r["op"] == "add" else "교체"
            print(f"  {i:3d} [{mark}] {tag} {r['path'].replace('smali/com/thinkware/sundo/', '…/')}")
        v = ask("> ")
        if not v: return
        if v == "a": excluded.difference_update(r["path"] for r in files)
        elif v == "n": excluded.update(r["path"] for r in files)
        else:
            for i in parse_nums(v, len(files)):
                p = files[i - 1]["path"]
                (excluded.discard if p in excluded else excluded.add)(p)


def pick_items(manifest):
    items = manifest["items"]
    on = {it["id"]: it.get("default", True) for it in items}
    excluded = set()
    while True:
        print("\n" + BOLD("3. 패치 항목") + DIM("  번호=토글, f번호=파일 선택, a=모두선택, n=모두해제, 엔터=다음"))
        for i, it in enumerate(items, 1):
            n = len(it["files"])
            cnt = f" ({n}개 파일)" if n else ""
            ex = sum(1 for r in it["files"] if r["path"] in excluded)
            exs = DIM(f" · 제외 {ex}") if ex else ""
            print(f"  {i}) [{'x' if on[it['id']] else ' '}] {it['title']}{cnt}{exs}")
            print(DIM(f"        {it['desc']}"))
        v = ask("> ")
        if not v:
            ids = [i for i, s in on.items() if s]
            if ids: return ids, excluded
            print(ERR("  하나 이상 선택하세요.")); continue
        if v == "a": on = {k: True for k in on}
        elif v == "n": on = {k: False for k in on}
        elif re.fullmatch(r"f\d+", v):
            k = int(v[1:])
            if 1 <= k <= len(items) and items[k - 1]["files"]: pick_files(items[k - 1], excluded)
        else:
            for k in parse_nums(v, len(items)):
                it = items[k - 1]; on[it["id"]] = not on[it["id"]]


def pick_keystore():
    print("\n" + BOLD("4. 서명"))
    if ask("내 키스토어를 사용할까요? (y/N): ").lower() != "y":
        print(DIM("  자동 디버그 키로 서명합니다."))
        return None
    path = os.path.expanduser(ask("  키스토어 경로: "))
    return {"path": path, "alias": ask("  별칭(alias): "), "pass": ask("  비밀번호: ")}


def main():
    ap = argparse.ArgumentParser(description="iNavi 3DS Patcher (Termux)")
    ap.add_argument("--apk"); ap.add_argument("--ver"); ap.add_argument("--items", help="적용할 항목 id (쉼표 구분)")
    ap.add_argument("--exclude", help="제외할 파일 상대경로 (쉼표 구분)")
    ap.add_argument("--out"); ap.add_argument("--yes", action="store_true", help="확인 없이 진행")
    ap.add_argument("--ks"); ap.add_argument("--alias"); ap.add_argument("--pass", dest="ks_pass")
    ap.add_argument("--list", action="store_true", help="패치팩/항목 목록만 출력")
    ap.add_argument("--apply-dir", help="디컴파일된 폴더에 패치만 적용(빌드/서명 생략, 테스트용)")
    a = ap.parse_args()

    packs = engine.list_packs()
    if not packs: print(ERR("패치팩(patches/)이 없습니다.")); return 1
    if a.list:
        for v in sorted(packs):
            m = engine.load_pack(packs[v]); print(v, [(i["id"], len(i["files"])) for i in m["items"]])
        return 0

    banner()
    if a.ver and a.ver not in packs: print(ERR(f"패치팩 {a.ver} 없음. 사용 가능: {', '.join(sorted(packs))}")); return 1

    if a.apply_dir:
        ver = a.ver or sorted(packs)[-1]; m = engine.load_pack(packs[ver])
        ids = a.items.split(",") if a.items else [i["id"] for i in m["items"]]
        r = engine.apply_pack(a.apply_dir, packs[ver], set(ids), set(), print)
        print(OK("적용 완료"), r["stats"], r["warnings"]); return 0

    apk = os.path.expanduser(a.apk) if a.apk else pick_apk()
    if not os.path.isfile(apk): print(ERR("APK 파일이 없습니다: " + apk)); return 1
    ver = a.ver or pick_pack(packs)
    manifest = engine.load_pack(packs[ver])
    if a.items:
        ids, excluded = [i for i in a.items.split(",") if i], {p for p in (a.exclude or "").split(",") if p}
    elif a.yes:
        ids, excluded = [i["id"] for i in manifest["items"] if i.get("default", True)], set()
    else:
        ids, excluded = pick_items(manifest)
    ks = {"path": a.ks, "alias": a.alias or "", "pass": a.ks_pass or ""} if a.ks else (None if a.yes or a.apk else pick_keystore())
    default_out = os.path.splitext(apk)[0] + "_patched.apk"
    out = os.path.expanduser(a.out) if a.out else (default_out if a.yes else os.path.expanduser(ask(f"\n저장 위치 [{default_out}]: ", default_out)))

    print("\n" + BOLD("요약"))
    print(f"  APK   : {apk}\n  패치  : {ver}  항목 {', '.join(ids)}" + (f" (파일 {len(excluded)}개 제외)" if excluded else "") + f"\n  저장  : {out}")
    if not a.yes and ask("\n시작할까요? (Y/n): ", "y").lower() != "y": print("취소했습니다."); return 0

    print()
    def confirm(msg):
        print(ERR("\n" + msg))
        return True if a.yes else ask("그래도 계속할까요? (y/N): ").lower() == "y"
    try:
        engine.patch_apk(apk, out, packs[ver], ids, excluded, ks, tempfile.gettempdir(), print, confirm)
    except engine.Cancelled:
        print(ERR("\n중지되었습니다.")); return 1
    except Exception as e:
        print(ERR(f"\n오류: {e}")); return 1
    print(OK("\n완료! ") + out)
    return 0


if __name__ == "__main__":
    sys.exit(main())
