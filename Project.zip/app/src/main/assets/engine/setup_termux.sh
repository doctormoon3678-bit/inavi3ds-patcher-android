#!/data/data/com.termux/files/usr/bin/sh
# Termux 초기 설정: sh setup_termux.sh
cd "$(dirname "$0")" || exit 1

echo "[1/3] 필수 패키지 설치 (python, openjdk-17, aapt)"
pkg update -y
pkg install -y python openjdk-17 aapt || { echo "패키지 설치 실패"; exit 1; }
pkg install -y zipalign >/dev/null 2>&1 || echo "  (zipalign 패키지 없음 - 선택 사항이라 건너뜁니다)"

echo "[2/3] 저장공간 접근"
[ -d "$HOME/storage" ] || termux-setup-storage

echo "[3/3] 도구 파일 확인"
MISSING=0
for f in tools/apktool.jar tools/uber-apk-signer.jar; do
  [ -f "$f" ] || { echo "  없음: $f"; MISSING=1; }
done
[ "$MISSING" = 1 ] && { echo "tools/ 폴더에 위 파일을 넣은 뒤 다시 실행하세요."; exit 1; }

java -version 2>&1 | head -1
command -v aapt || echo "  ! aapt 를 찾지 못했습니다"
echo
echo "준비 완료.  실행:  python patcher_termux.py"
