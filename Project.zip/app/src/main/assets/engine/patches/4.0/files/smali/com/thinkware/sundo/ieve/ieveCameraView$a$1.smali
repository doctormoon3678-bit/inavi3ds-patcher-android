.class Lcom/thinkware/sundo/ieve/ieveCameraView$a$1;
.super Ljava/lang/Object;
.source "ieveCameraView.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/thinkware/sundo/ieve/ieveCameraView$a;->a()Landroid/hardware/Camera;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/thinkware/sundo/ieve/ieveCameraView$a;


# direct methods
.method constructor <init>(Lcom/thinkware/sundo/ieve/ieveCameraView$a;)V
    .locals 0

    .prologue
    .line 1
    iput-object p1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$a$1;->a:Lcom/thinkware/sundo/ieve/ieveCameraView$a;

    .line 72
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 5

    .prologue
    .line 75
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$a$1;->a:Lcom/thinkware/sundo/ieve/ieveCameraView$a;

    invoke-static {v1}, Lcom/thinkware/sundo/ieve/ieveCameraView$a;->a(Lcom/thinkware/sundo/ieve/ieveCameraView$a;)Ljava/lang/Object;

    move-result-object v2

    monitor-enter v2

    .line 77
    :try_start_0
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$a$1;->a:Lcom/thinkware/sundo/ieve/ieveCameraView$a;

    invoke-static {}, Landroid/hardware/Camera;->open()Landroid/hardware/Camera;

    move-result-object v3

    invoke-static {v1, v3}, Lcom/thinkware/sundo/ieve/ieveCameraView$a;->a(Lcom/thinkware/sundo/ieve/ieveCameraView$a;Landroid/hardware/Camera;)V
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 81
    :goto_0
    :try_start_1
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$a$1;->a:Lcom/thinkware/sundo/ieve/ieveCameraView$a;

    invoke-static {v1}, Lcom/thinkware/sundo/ieve/ieveCameraView$a;->a(Lcom/thinkware/sundo/ieve/ieveCameraView$a;)Ljava/lang/Object;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->notify()V

    .line 75
    monitor-exit v2

    .line 83
    return-void

    .line 78
    :catch_0
    move-exception v0

    .line 79
    .local v0, "e":Ljava/lang/RuntimeException;
    invoke-static {}, Lcom/thinkware/sundo/ieve/ieveCameraView;->a()Ljava/lang/String;

    move-result-object v1

    new-instance v3, Ljava/lang/StringBuilder;

    const-string v4, "open[failed:"

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/lang/RuntimeException;->getLocalizedMessage()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, "]"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v1, v3}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    .line 75
    .end local v0    # "e":Ljava/lang/RuntimeException;
    :catchall_0
    move-exception v1

    monitor-exit v2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw v1
.end method
