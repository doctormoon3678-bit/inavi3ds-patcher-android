.class public final enum Ltas/internal/avm/AvmEnumerations$PGSDataType;
.super Ljava/lang/Enum;
.source "AvmEnumerations.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltas/internal/avm/AvmEnumerations;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "PGSDataType"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum",
        "<",
        "Ltas/internal/avm/AvmEnumerations$PGSDataType;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Ltas/internal/avm/AvmEnumerations$PGSDataType;

.field public static final enum PG_TYPE_DYNAMIC:Ltas/internal/avm/AvmEnumerations$PGSDataType;

.field public static final enum PG_TYPE_STATIC:Ltas/internal/avm/AvmEnumerations$PGSDataType;

.field public static final enum PG_TYPE_UNKNOWN:Ltas/internal/avm/AvmEnumerations$PGSDataType;


# instance fields
.field private type:I


# direct methods
.method static constructor <clinit>()V
    .locals 6

    .prologue
    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v3, 0x0

    .line 295
    new-instance v0, Ltas/internal/avm/AvmEnumerations$PGSDataType;

    const-string/jumbo v1, "PG_TYPE_STATIC"

    invoke-direct {v0, v1, v3, v3}, Ltas/internal/avm/AvmEnumerations$PGSDataType;-><init>(Ljava/lang/String;II)V

    sput-object v0, Ltas/internal/avm/AvmEnumerations$PGSDataType;->PG_TYPE_STATIC:Ltas/internal/avm/AvmEnumerations$PGSDataType;

    .line 296
    new-instance v0, Ltas/internal/avm/AvmEnumerations$PGSDataType;

    const-string/jumbo v1, "PG_TYPE_DYNAMIC"

    invoke-direct {v0, v1, v4, v4}, Ltas/internal/avm/AvmEnumerations$PGSDataType;-><init>(Ljava/lang/String;II)V

    sput-object v0, Ltas/internal/avm/AvmEnumerations$PGSDataType;->PG_TYPE_DYNAMIC:Ltas/internal/avm/AvmEnumerations$PGSDataType;

    .line 297
    new-instance v0, Ltas/internal/avm/AvmEnumerations$PGSDataType;

    const-string/jumbo v1, "PG_TYPE_UNKNOWN"

    const/16 v2, 0xff

    invoke-direct {v0, v1, v5, v2}, Ltas/internal/avm/AvmEnumerations$PGSDataType;-><init>(Ljava/lang/String;II)V

    sput-object v0, Ltas/internal/avm/AvmEnumerations$PGSDataType;->PG_TYPE_UNKNOWN:Ltas/internal/avm/AvmEnumerations$PGSDataType;

    .line 294
    const/4 v0, 0x3

    new-array v0, v0, [Ltas/internal/avm/AvmEnumerations$PGSDataType;

    sget-object v1, Ltas/internal/avm/AvmEnumerations$PGSDataType;->PG_TYPE_STATIC:Ltas/internal/avm/AvmEnumerations$PGSDataType;

    aput-object v1, v0, v3

    sget-object v1, Ltas/internal/avm/AvmEnumerations$PGSDataType;->PG_TYPE_DYNAMIC:Ltas/internal/avm/AvmEnumerations$PGSDataType;

    aput-object v1, v0, v4

    sget-object v1, Ltas/internal/avm/AvmEnumerations$PGSDataType;->PG_TYPE_UNKNOWN:Ltas/internal/avm/AvmEnumerations$PGSDataType;

    aput-object v1, v0, v5

    sput-object v0, Ltas/internal/avm/AvmEnumerations$PGSDataType;->$VALUES:[Ltas/internal/avm/AvmEnumerations$PGSDataType;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .locals 0
    .param p3, "type"    # I

    .prologue
    .line 300
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 301
    iput p3, p0, Ltas/internal/avm/AvmEnumerations$PGSDataType;->type:I

    .line 300
    return-void
.end method

.method public static createFromOrdinalNumber(I)Ltas/internal/avm/AvmEnumerations$PGSDataType;
    .locals 5
    .param p0, "number"    # I

    .prologue
    .line 318
    invoke-static {}, Ltas/internal/avm/AvmEnumerations$PGSDataType;->values()[Ltas/internal/avm/AvmEnumerations$PGSDataType;

    move-result-object v2

    const/4 v1, 0x0

    array-length v3, v2

    :goto_0
    if-ge v1, v3, :cond_1

    aget-object v0, v2, v1

    .line 319
    .local v0, "i":Ltas/internal/avm/AvmEnumerations$PGSDataType;
    invoke-virtual {v0}, Ltas/internal/avm/AvmEnumerations$PGSDataType;->ordinal()I

    move-result v4

    if-ne v4, p0, :cond_0

    .line 320
    return-object v0

    .line 318
    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    .line 323
    .end local v0    # "i":Ltas/internal/avm/AvmEnumerations$PGSDataType;
    :cond_1
    sget-object v1, Ltas/internal/avm/AvmEnumerations$PGSDataType;->PG_TYPE_UNKNOWN:Ltas/internal/avm/AvmEnumerations$PGSDataType;

    return-object v1
.end method

.method public static createFromValue(I)Ltas/internal/avm/AvmEnumerations$PGSDataType;
    .locals 5
    .param p0, "type"    # I

    .prologue
    .line 309
    invoke-static {}, Ltas/internal/avm/AvmEnumerations$PGSDataType;->values()[Ltas/internal/avm/AvmEnumerations$PGSDataType;

    move-result-object v2

    const/4 v1, 0x0

    array-length v3, v2

    :goto_0
    if-ge v1, v3, :cond_1

    aget-object v0, v2, v1

    .line 310
    .local v0, "i":Ltas/internal/avm/AvmEnumerations$PGSDataType;
    invoke-virtual {v0}, Ltas/internal/avm/AvmEnumerations$PGSDataType;->toInteger()I

    move-result v4

    if-ne v4, p0, :cond_0

    .line 311
    return-object v0

    .line 309
    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    .line 314
    .end local v0    # "i":Ltas/internal/avm/AvmEnumerations$PGSDataType;
    :cond_1
    sget-object v1, Ltas/internal/avm/AvmEnumerations$PGSDataType;->PG_TYPE_UNKNOWN:Ltas/internal/avm/AvmEnumerations$PGSDataType;

    return-object v1
.end method

.method public static valueOf(Ljava/lang/String;)Ltas/internal/avm/AvmEnumerations$PGSDataType;
    .locals 1
    .param p0, "name"    # Ljava/lang/String;

    .prologue
    .line 294
    const-class v0, Ltas/internal/avm/AvmEnumerations$PGSDataType;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object v0

    check-cast v0, Ltas/internal/avm/AvmEnumerations$PGSDataType;

    return-object v0
.end method

.method public static values()[Ltas/internal/avm/AvmEnumerations$PGSDataType;
    .locals 1

    .prologue
    .line 294
    sget-object v0, Ltas/internal/avm/AvmEnumerations$PGSDataType;->$VALUES:[Ltas/internal/avm/AvmEnumerations$PGSDataType;

    return-object v0
.end method


# virtual methods
.method public toInteger()I
    .locals 1

    .prologue
    .line 305
    iget v0, p0, Ltas/internal/avm/AvmEnumerations$PGSDataType;->type:I

    return v0
.end method
