.class public Ltas/ipc/MsgTransceiver;
.super Ljava/lang/Object;
.source "MsgTransceiver.java"


# instance fields
.field private IMPL:Ltas/internal/ipc/Transceiver;


# direct methods
.method public constructor <init>(Landroid/content/Context;Ljava/lang/String;Landroid/os/Looper;)V
    .locals 1
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "name"    # Ljava/lang/String;
    .param p3, "looper"    # Landroid/os/Looper;

    .prologue
    .line 30
    const/4 v0, 0x0

    invoke-direct {p0, p1, p2, p3, v0}, Ltas/ipc/MsgTransceiver;-><init>(Landroid/content/Context;Ljava/lang/String;Landroid/os/Looper;Ljava/lang/Class;)V

    .line 29
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Ljava/lang/String;Landroid/os/Looper;Ljava/lang/Class;)V
    .locals 1
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "name"    # Ljava/lang/String;
    .param p3, "looper"    # Landroid/os/Looper;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/lang/String;",
            "Landroid/os/Looper;",
            "Ljava/lang/Class",
            "<+",
            "Ltas/ipc/MsgReceiverService;",
            ">;)V"
        }
    .end annotation

    .prologue
    .line 39
    .local p4, "srvcls":Ljava/lang/Class;, "Ljava/lang/Class<+Ltas/ipc/MsgReceiverService;>;"
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 42
    new-instance v0, Ltas/internal/ipc/Transceiver;

    invoke-direct {v0, p1, p2, p3, p4}, Ltas/internal/ipc/Transceiver;-><init>(Landroid/content/Context;Ljava/lang/String;Landroid/os/Looper;Ljava/lang/Class;)V

    iput-object v0, p0, Ltas/ipc/MsgTransceiver;->IMPL:Ltas/internal/ipc/Transceiver;

    .line 41
    return-void
.end method


# virtual methods
.method public acceptAnonymousSession(Ltas/ipc/TransceiverSession$Callback;)V
    .locals 1
    .param p1, "cb"    # Ltas/ipc/TransceiverSession$Callback;

    .prologue
    .line 136
    if-eqz p1, :cond_0

    .line 137
    iget-object v0, p0, Ltas/ipc/MsgTransceiver;->IMPL:Ltas/internal/ipc/Transceiver;

    invoke-virtual {v0, p1}, Ltas/internal/ipc/Transceiver;->acceptAnonymousSession(Ltas/ipc/TransceiverSession$Callback;)V

    .line 135
    :cond_0
    return-void
.end method

.method public acceptSession(Ljava/lang/String;Ltas/ipc/TransceiverSession$Callback;)V
    .locals 1
    .param p1, "name"    # Ljava/lang/String;
    .param p2, "cb"    # Ltas/ipc/TransceiverSession$Callback;

    .prologue
    .line 86
    if-eqz p1, :cond_0

    if-eqz p2, :cond_0

    .line 87
    iget-object v0, p0, Ltas/ipc/MsgTransceiver;->IMPL:Ltas/internal/ipc/Transceiver;

    invoke-virtual {v0, p1, p2}, Ltas/internal/ipc/Transceiver;->acceptSession(Ljava/lang/String;Ltas/ipc/TransceiverSession$Callback;)V

    .line 85
    :cond_0
    return-void
.end method

.method public getExtra()Landroid/os/Bundle;
    .locals 1

    .prologue
    .line 175
    iget-object v0, p0, Ltas/ipc/MsgTransceiver;->IMPL:Ltas/internal/ipc/Transceiver;

    invoke-virtual {v0}, Ltas/internal/ipc/Transceiver;->getExtra()Landroid/os/Bundle;

    move-result-object v0

    return-object v0
.end method

.method public isOnline()Z
    .locals 1

    .prologue
    .line 60
    iget-object v0, p0, Ltas/ipc/MsgTransceiver;->IMPL:Ltas/internal/ipc/Transceiver;

    invoke-virtual {v0}, Ltas/internal/ipc/Transceiver;->isOnline()Z

    move-result v0

    return v0
.end method

.method public isP2pMode()Z
    .locals 1

    .prologue
    .line 64
    iget-object v0, p0, Ltas/ipc/MsgTransceiver;->IMPL:Ltas/internal/ipc/Transceiver;

    invoke-virtual {v0}, Ltas/internal/ipc/Transceiver;->isP2pMode()Z

    move-result v0

    return v0
.end method

.method public offline()V
    .locals 1

    .prologue
    .line 56
    iget-object v0, p0, Ltas/ipc/MsgTransceiver;->IMPL:Ltas/internal/ipc/Transceiver;

    invoke-virtual {v0}, Ltas/internal/ipc/Transceiver;->offline()V

    .line 55
    return-void
.end method

.method public online()V
    .locals 1

    .prologue
    .line 49
    iget-object v0, p0, Ltas/ipc/MsgTransceiver;->IMPL:Ltas/internal/ipc/Transceiver;

    invoke-virtual {v0}, Ltas/internal/ipc/Transceiver;->online()V

    .line 48
    return-void
.end method

.method public peekExtra()Landroid/os/Bundle;
    .locals 1

    .prologue
    .line 182
    iget-object v0, p0, Ltas/ipc/MsgTransceiver;->IMPL:Ltas/internal/ipc/Transceiver;

    invoke-virtual {v0}, Ltas/internal/ipc/Transceiver;->peekExtra()Landroid/os/Bundle;

    move-result-object v0

    return-object v0
.end method

.method public release()V
    .locals 1

    .prologue
    .line 204
    iget-object v0, p0, Ltas/ipc/MsgTransceiver;->IMPL:Ltas/internal/ipc/Transceiver;

    invoke-virtual {v0}, Ltas/internal/ipc/Transceiver;->release()V

    .line 203
    return-void
.end method

.method public requestAnonymousSession(Ltas/ipc/TransceiverSession$Callback;)V
    .locals 1
    .param p1, "cb"    # Ltas/ipc/TransceiverSession$Callback;

    .prologue
    .line 111
    if-eqz p1, :cond_0

    .line 112
    iget-object v0, p0, Ltas/ipc/MsgTransceiver;->IMPL:Ltas/internal/ipc/Transceiver;

    invoke-virtual {v0, p1}, Ltas/internal/ipc/Transceiver;->requestAnonymousSession(Ltas/ipc/TransceiverSession$Callback;)V

    .line 110
    :cond_0
    return-void
.end method

.method public requestAnonymousSessionLazily(Ltas/ipc/TransceiverSession$Callback;)Ltas/ipc/TransceiverSession;
    .locals 1
    .param p1, "cb"    # Ltas/ipc/TransceiverSession$Callback;

    .prologue
    .line 127
    iget-object v0, p0, Ltas/ipc/MsgTransceiver;->IMPL:Ltas/internal/ipc/Transceiver;

    invoke-virtual {v0, p1}, Ltas/internal/ipc/Transceiver;->requestAnonymousSessionLazily(Ltas/ipc/TransceiverSession$Callback;)Ltas/ipc/TransceiverSession;

    move-result-object v0

    return-object v0
.end method

.method public requestOrAcceptAnonymousSession(Ltas/ipc/TransceiverSession$Callback;)V
    .locals 1
    .param p1, "cb"    # Ltas/ipc/TransceiverSession$Callback;

    .prologue
    .line 149
    if-eqz p1, :cond_0

    .line 150
    iget-object v0, p0, Ltas/ipc/MsgTransceiver;->IMPL:Ltas/internal/ipc/Transceiver;

    invoke-virtual {v0, p1}, Ltas/internal/ipc/Transceiver;->requestOrAcceptAnonymousSession(Ltas/ipc/TransceiverSession$Callback;)V

    .line 148
    :cond_0
    return-void
.end method

.method public requestOrAcceptAnonymousSessionLazily(Ltas/ipc/TransceiverSession$Callback;)Ltas/ipc/TransceiverSession;
    .locals 1
    .param p1, "cb"    # Ltas/ipc/TransceiverSession$Callback;

    .prologue
    .line 167
    iget-object v0, p0, Ltas/ipc/MsgTransceiver;->IMPL:Ltas/internal/ipc/Transceiver;

    invoke-virtual {v0, p1}, Ltas/internal/ipc/Transceiver;->requestOrAcceptAnonymousSessionLazily(Ltas/ipc/TransceiverSession$Callback;)Ltas/ipc/TransceiverSession;

    move-result-object v0

    return-object v0
.end method

.method public requestOrAcceptSession(Ljava/lang/String;Ltas/ipc/TransceiverSession$Callback;)V
    .locals 1
    .param p1, "name"    # Ljava/lang/String;
    .param p2, "cb"    # Ltas/ipc/TransceiverSession$Callback;

    .prologue
    .line 100
    if-eqz p1, :cond_0

    if-eqz p2, :cond_0

    .line 101
    iget-object v0, p0, Ltas/ipc/MsgTransceiver;->IMPL:Ltas/internal/ipc/Transceiver;

    invoke-virtual {v0, p1, p2}, Ltas/internal/ipc/Transceiver;->requestOrAcceptSession(Ljava/lang/String;Ltas/ipc/TransceiverSession$Callback;)V

    .line 99
    :cond_0
    return-void
.end method

.method public requestSession(Ljava/lang/String;Ltas/ipc/TransceiverSession$Callback;)V
    .locals 1
    .param p1, "name"    # Ljava/lang/String;
    .param p2, "cb"    # Ltas/ipc/TransceiverSession$Callback;

    .prologue
    .line 74
    if-eqz p1, :cond_0

    if-eqz p2, :cond_0

    .line 75
    iget-object v0, p0, Ltas/ipc/MsgTransceiver;->IMPL:Ltas/internal/ipc/Transceiver;

    invoke-virtual {v0, p1, p2}, Ltas/internal/ipc/Transceiver;->requestSession(Ljava/lang/String;Ltas/ipc/TransceiverSession$Callback;)V

    .line 73
    :cond_0
    return-void
.end method

.method public setExtra(Landroid/os/Bundle;)V
    .locals 1
    .param p1, "extra"    # Landroid/os/Bundle;

    .prologue
    .line 190
    iget-object v0, p0, Ltas/ipc/MsgTransceiver;->IMPL:Ltas/internal/ipc/Transceiver;

    invoke-virtual {v0, p1}, Ltas/internal/ipc/Transceiver;->setExtra(Landroid/os/Bundle;)V

    .line 189
    return-void
.end method

.method public update()V
    .locals 1

    .prologue
    .line 200
    iget-object v0, p0, Ltas/ipc/MsgTransceiver;->IMPL:Ltas/internal/ipc/Transceiver;

    invoke-virtual {v0}, Ltas/internal/ipc/Transceiver;->update()V

    .line 199
    return-void
.end method
