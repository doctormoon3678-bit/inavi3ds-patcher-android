.class public interface abstract Ltas/util/power/Acc$Observer;
.super Ljava/lang/Object;
.source "Acc.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltas/util/power/Acc;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "Observer"
.end annotation


# virtual methods
.method public abstract onAccOff()V
.end method

.method public abstract onAccOn()V
.end method
