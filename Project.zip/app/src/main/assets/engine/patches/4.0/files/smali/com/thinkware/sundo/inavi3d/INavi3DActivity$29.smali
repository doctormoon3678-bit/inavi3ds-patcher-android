.class Lcom/thinkware/sundo/inavi3d/INavi3DActivity$29;
.super Ljava/lang/Object;
.source "INavi3DActivity.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/thinkware/sundo/inavi3d/INavi3DActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;


# direct methods
.method constructor <init>(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)V
    .locals 0

    .prologue
    .line 10087
    iput-object p1, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$29;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 14
    .param p1, "v"    # Landroid/view/View;

    .prologue
    const/16 v13, 0x1773

    const/4 v12, -0x1

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v9, 0x1

    .line 10091
    invoke-virtual {p1}, Landroid/view/View;->getId()I

    move-result v6

    .line 10092
    .local v6, "nViewID":I
    iget-object v8, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$29;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v8, v8, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->mEditInput:Landroid/widget/EditText;

    invoke-virtual {v8}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v7

    .line 10094
    .local v7, "strInput":Ljava/lang/String;
    const-string v8, "******"

    invoke-virtual {v7, v8}, Ljava/lang/String;->compareTo(Ljava/lang/String;)I

    move-result v8

    if-nez v8, :cond_0

    .line 10096
    iget-object v8, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$29;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    const v9, 0x7f0a0435

    invoke-virtual {v8, v9}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->findViewById(I)Landroid/view/View;

    move-result-object v8

    invoke-virtual {v8, v10}, Landroid/view/View;->setVisibility(I)V

    .line 10227
    :goto_0
    return-void

    .line 10101
    :cond_0
    const v8, 0x7f0a043a

    if-ne v6, v8, :cond_1

    invoke-virtual {v7}, Ljava/lang/String;->length()I

    move-result v8

    if-lt v8, v11, :cond_3

    :cond_1
    const v8, 0x7f0a0441

    if-ne v6, v8, :cond_2

    invoke-virtual {v7}, Ljava/lang/String;->length()I

    move-result v8

    if-lt v8, v11, :cond_3

    :cond_2
    const v8, 0x7f0a0438

    if-ne v6, v8, :cond_4

    invoke-virtual {v7}, Ljava/lang/String;->length()I

    move-result v8

    if-ge v8, v11, :cond_4

    .line 10105
    :cond_3
    iget-object v8, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$29;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    const-string v10, "\uc720\ud6a8\ud55c \ud30c\uc77c\uba85\uc744 \uc785\ub825\ud558\uc138\uc694."

    invoke-static {v8, v10, v9}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v8

    invoke-virtual {v8}, Landroid/widget/Toast;->show()V

    goto :goto_0

    .line 10109
    :cond_4
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DR/DRManager;->getInstance()Lcom/thinkware/sundo/inavi3d/DR/DRManager;

    move-result-object v1

    .line 10110
    .local v1, "drManager":Lcom/thinkware/sundo/inavi3d/DR/DRManager;
    iget-object v8, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$29;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-boolean v8, v8, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->mbUnderground:Z

    if-ne v8, v9, :cond_5

    move v8, v9

    :goto_1
    invoke-virtual {v1, v8, v7}, Lcom/thinkware/sundo/inavi3d/DR/DRManager;->SetDRLogOption(ILjava/lang/String;)V

    .line 10112
    iget-object v8, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$29;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    const-string v11, "input_method"

    invoke-virtual {v8, v11}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/view/inputmethod/InputMethodManager;

    .line 10113
    .local v2, "imm":Landroid/view/inputmethod/InputMethodManager;
    iget-object v8, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$29;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v8, v8, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->mEditInput:Landroid/widget/EditText;

    invoke-virtual {v8}, Landroid/widget/EditText;->getWindowToken()Landroid/os/IBinder;

    move-result-object v8

    invoke-virtual {v2, v8, v10}, Landroid/view/inputmethod/InputMethodManager;->hideSoftInputFromWindow(Landroid/os/IBinder;I)Z

    .line 10115
    sparse-switch v6, :sswitch_data_0

    goto :goto_0

    .line 10117
    :sswitch_0
    invoke-virtual {v1}, Lcom/thinkware/sundo/inavi3d/DR/DRManager;->ClickButton1()V

    goto :goto_0

    .end local v2    # "imm":Landroid/view/inputmethod/InputMethodManager;
    :cond_5
    move v8, v10

    .line 10110
    goto :goto_1

    .line 10120
    .restart local v2    # "imm":Landroid/view/inputmethod/InputMethodManager;
    :sswitch_1
    invoke-virtual {v1}, Lcom/thinkware/sundo/inavi3d/DR/DRManager;->ClickButton2()V

    goto :goto_0

    .line 10123
    :sswitch_2
    invoke-virtual {v1}, Lcom/thinkware/sundo/inavi3d/DR/DRManager;->ClickButton3()V

    goto :goto_0

    .line 10126
    :sswitch_3
    invoke-virtual {v1}, Lcom/thinkware/sundo/inavi3d/DR/DRManager;->ClickButton4()V

    goto :goto_0

    .line 10129
    :sswitch_4
    invoke-virtual {v1}, Lcom/thinkware/sundo/inavi3d/DR/DRManager;->ClickButton5()V

    goto :goto_0

    .line 10132
    :sswitch_5
    invoke-virtual {v1}, Lcom/thinkware/sundo/inavi3d/DR/DRManager;->ClickButton6()V

    goto :goto_0

    .line 10135
    :sswitch_6
    invoke-virtual {v1}, Lcom/thinkware/sundo/inavi3d/DR/DRManager;->ClickButton7()V

    goto :goto_0

    .line 10138
    :sswitch_7
    const-string v4, ""

    .line 10139
    .local v4, "kDRExpectData":Ljava/lang/String;
    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    sget-object v10, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->kStorageRoot:Ljava/lang/String;

    invoke-virtual {v8, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    const-string v10, "/DRExpectData"

    invoke-virtual {v8, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    .line 10140
    new-instance v0, Ljava/io/File;

    invoke-direct {v0, v4}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 10141
    .local v0, "Drfile":Ljava/io/File;
    invoke-virtual {v0}, Ljava/io/File;->isDirectory()Z

    move-result v8

    if-nez v8, :cond_6

    .line 10142
    invoke-virtual {v0}, Ljava/io/File;->mkdir()Z

    .line 10144
    :cond_6
    sget-object v8, Lcom/thinkware/sundo/inavi3d/GpsLogDriver;->mPath:Ljava/io/File;

    invoke-virtual {v8}, Ljava/io/File;->mkdir()Z

    .line 10145
    const-string v8, ""

    invoke-static {v13, v9, v8}, Lcom/thinkware/sundo/inavi3d/Inavi;->ProcessMessage(IILjava/lang/String;)I

    .line 10146
    iget-object v8, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$29;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    const-string v10, "\ub85c\uae45\uc2dc\uc791 (/storage/emulated/0/inavi3d/gpslog/)"

    invoke-static {v8, v10, v9}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v8

    invoke-virtual {v8}, Landroid/widget/Toast;->show()V

    .line 10148
    invoke-virtual {v1}, Lcom/thinkware/sundo/inavi3d/DR/DRManager;->ClickButton8()V

    goto/16 :goto_0

    .line 10151
    .end local v0    # "Drfile":Ljava/io/File;
    .end local v4    # "kDRExpectData":Ljava/lang/String;
    :sswitch_8
    invoke-virtual {v1}, Lcom/thinkware/sundo/inavi3d/DR/DRManager;->ClickButton9()V

    goto/16 :goto_0

    .line 10154
    :sswitch_9
    sget-object v8, Lcom/thinkware/sundo/inavi3d/GpsLogDriver;->mPath:Ljava/io/File;

    invoke-virtual {v8}, Ljava/io/File;->mkdir()Z

    .line 10155
    const-string v8, ""

    invoke-static {v13, v10, v8}, Lcom/thinkware/sundo/inavi3d/Inavi;->ProcessMessage(IILjava/lang/String;)I

    .line 10156
    iget-object v8, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$29;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    const-string v10, "\ub85c\uae45\uc911\ub2e8 (/storage/emulated/0/inavi3d/gpslog/)"

    invoke-static {v8, v10, v9}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v8

    invoke-virtual {v8}, Landroid/widget/Toast;->show()V

    .line 10158
    invoke-virtual {v1}, Lcom/thinkware/sundo/inavi3d/DR/DRManager;->ClickButton10()V

    goto/16 :goto_0

    .line 10162
    :sswitch_a
    invoke-virtual {v1}, Lcom/thinkware/sundo/inavi3d/DR/DRManager;->ClickButton11()V

    goto/16 :goto_0

    .line 10166
    :sswitch_b
    invoke-virtual {v1}, Lcom/thinkware/sundo/inavi3d/DR/DRManager;->ClickButton12()V

    goto/16 :goto_0

    .line 10170
    :sswitch_c
    invoke-virtual {v1}, Lcom/thinkware/sundo/inavi3d/DR/DRManager;->ClickButton13()V

    goto/16 :goto_0

    .line 10174
    :sswitch_d
    invoke-virtual {v1}, Lcom/thinkware/sundo/inavi3d/DR/DRManager;->ClickButton14()V

    goto/16 :goto_0

    .line 10178
    :sswitch_e
    invoke-virtual {v1}, Lcom/thinkware/sundo/inavi3d/DR/DRManager;->ClickButton15()V

    goto/16 :goto_0

    .line 10182
    :sswitch_f
    invoke-virtual {v1}, Lcom/thinkware/sundo/inavi3d/DR/DRManager;->ClickButton16()V

    goto/16 :goto_0

    .line 10186
    :sswitch_10
    invoke-virtual {v1, v10}, Lcom/thinkware/sundo/inavi3d/DR/DRManager;->_DRSetLogMode(Z)V

    .line 10187
    iget-object v8, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$29;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v8, v8, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_DRLogLayout:Landroid/widget/RelativeLayout;

    const/16 v9, 0x8

    invoke-virtual {v8, v9}, Landroid/widget/RelativeLayout;->setVisibility(I)V

    .line 10188
    iget-object v8, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$29;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    invoke-static {v8, v10}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$5500(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;I)V

    .line 10189
    iget-object v8, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$29;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    invoke-static {v8}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$300(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)Lcom/thinkware/sundo/inavi3d/Inavi;

    move-result-object v8

    const v9, 0x1adb0

    invoke-virtual {v8, v9, v10, v12, v12}, Lcom/thinkware/sundo/inavi3d/Inavi;->PushMessage(IIII)V

    goto/16 :goto_0

    .line 10194
    :sswitch_11
    invoke-virtual {v7}, Ljava/lang/String;->length()I

    move-result v8

    const/4 v11, 0x5

    if-ne v8, v11, :cond_8

    .line 10196
    invoke-static {v7}, Ljava/lang/Integer;->valueOf(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/Integer;->intValue()I

    move-result v5

    .line 10198
    .local v5, "nID":I
    const/16 v8, 0x2710

    if-ge v8, v5, :cond_7

    const/16 v8, 0x2af8

    if-le v8, v5, :cond_7

    .line 10200
    iget-object v8, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$29;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iput-boolean v9, v8, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_bDRActivityVisible:Z

    .line 10202
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    move-result-object v8

    invoke-virtual {v8}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->hideStatusBar()Z

    .line 10203
    invoke-virtual {v1}, Lcom/thinkware/sundo/inavi3d/DR/DRManager;->getDRInfo()Lcom/thinkware/sundo/inavi3d/DR/DRInfo;

    move-result-object v8

    invoke-virtual {v8, v10}, Lcom/thinkware/sundo/inavi3d/DR/DRInfo;->setViewMode(I)V

    .line 10204
    invoke-virtual {v1, v5}, Lcom/thinkware/sundo/inavi3d/DR/DRManager;->SetParkID(I)V

    .line 10205
    iget-object v8, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$29;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    const/16 v9, 0x2713

    iput v9, v8, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_nDRMode:I

    .line 10208
    new-instance v3, Landroid/content/Intent;

    iget-object v8, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$29;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    const-class v9, Lcom/thinkware/sundo/inavi3d/DR/DRServiceActivity;

    invoke-direct {v3, v8, v9}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 10209
    .local v3, "intent":Landroid/content/Intent;
    iget-object v8, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$29;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    invoke-virtual {v8, v3}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->startActivity(Landroid/content/Intent;)V

    goto/16 :goto_0

    .line 10213
    .end local v3    # "intent":Landroid/content/Intent;
    :cond_7
    iget-object v8, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$29;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    const-string v10, "\uc720\ud6a8\ud55c \ud30c\uc77c\uba85\uc744 \uc785\ub825\ud558\uc138\uc694."

    invoke-static {v8, v10, v9}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v8

    invoke-virtual {v8}, Landroid/widget/Toast;->show()V

    goto/16 :goto_0

    .line 10218
    .end local v5    # "nID":I
    :cond_8
    iget-object v8, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$29;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    const-string v10, "\uc720\ud6a8\ud55c \ud30c\uc77c\uba85\uc744 \uc785\ub825\ud558\uc138\uc694."

    invoke-static {v8, v10, v9}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v8

    invoke-virtual {v8}, Landroid/widget/Toast;->show()V

    goto/16 :goto_0

    .line 10115
    :sswitch_data_0
    .sparse-switch
        0x7f0a00de -> :sswitch_0
        0x7f0a0332 -> :sswitch_1
        0x7f0a033e -> :sswitch_2
        0x7f0a033f -> :sswitch_3
        0x7f0a0434 -> :sswitch_10
        0x7f0a0435 -> :sswitch_11
        0x7f0a0438 -> :sswitch_b
        0x7f0a043a -> :sswitch_7
        0x7f0a043b -> :sswitch_9
        0x7f0a0441 -> :sswitch_8
        0x7f0a0442 -> :sswitch_4
        0x7f0a0443 -> :sswitch_5
        0x7f0a0444 -> :sswitch_6
        0x7f0a0446 -> :sswitch_a
        0x7f0a0447 -> :sswitch_c
        0x7f0a0448 -> :sswitch_d
        0x7f0a0449 -> :sswitch_e
        0x7f0a044a -> :sswitch_f
    .end sparse-switch
.end method
