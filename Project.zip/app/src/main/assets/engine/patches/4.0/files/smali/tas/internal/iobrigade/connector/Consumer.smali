.class final Ltas/internal/iobrigade/connector/Consumer;
.super Ljava/lang/Object;
.source "Consumer.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ltas/internal/iobrigade/connector/Consumer$IoBrigadeConnectNativeContext;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation


# static fields
.field private static final TAG:Ljava/lang/String;


# instance fields
.field private final mLink_T_toNode:Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TT;"
        }
    .end annotation
.end field


# direct methods
.method static synthetic -get0()Ljava/lang/String;
    .locals 1

    sget-object v0, Ltas/internal/iobrigade/connector/Consumer;->TAG:Ljava/lang/String;

    return-object v0
.end method

.method static synthetic -get1(Ltas/internal/iobrigade/connector/Consumer;)Ljava/lang/Object;
    .locals 1

    iget-object v0, p0, Ltas/internal/iobrigade/connector/Consumer;->mLink_T_toNode:Ljava/lang/Object;

    return-object v0
.end method

.method static constructor <clinit>()V
    .locals 1

    .prologue
    .line 17
    const-class v0, Ltas/internal/iobrigade/connector/Consumer;

    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Ltas/internal/iobrigade/connector/Consumer;->TAG:Ljava/lang/String;

    .line 15
    return-void
.end method

.method constructor <init>(Ljava/lang/Object;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    .prologue
    .line 21
    .local p0, "this":Ltas/internal/iobrigade/connector/Consumer;, "Ltas/internal/iobrigade/connector/Consumer<TT;>;"
    .local p1, "ltn":Ljava/lang/Object;, "TT;"
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ltas/internal/iobrigade/connector/Consumer;->mLink_T_toNode:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method getConnParamTypeName()Ljava/lang/String;
    .locals 1

    .prologue
    .line 25
    .local p0, "this":Ltas/internal/iobrigade/connector/Consumer;, "Ltas/internal/iobrigade/connector/Consumer<TT;>;"
    iget-object v0, p0, Ltas/internal/iobrigade/connector/Consumer;->mLink_T_toNode:Ljava/lang/Object;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method getLinkedConnector()Ljava/lang/Object;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TT;"
        }
    .end annotation

    .prologue
    .line 23
    .local p0, "this":Ltas/internal/iobrigade/connector/Consumer;, "Ltas/internal/iobrigade/connector/Consumer<TT;>;"
    iget-object v0, p0, Ltas/internal/iobrigade/connector/Consumer;->mLink_T_toNode:Ljava/lang/Object;

    return-object v0
.end method
