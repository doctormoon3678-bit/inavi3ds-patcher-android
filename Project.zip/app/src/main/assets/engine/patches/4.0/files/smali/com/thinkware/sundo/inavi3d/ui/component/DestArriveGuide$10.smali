.class Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide$10;
.super Ljava/lang/Object;
.source "DestArriveGuide.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;->SetData(Lcom/thinkware/sundo/inavi3d/Struct/DestInfo;Lcom/thinkware/sundo/inavi3d/OBD2/OBD2GoalInfo;Lcom/thinkware/sundo/inavi3d/INavi3DActivity;Z)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;


# direct methods
.method constructor <init>(Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;)V
    .locals 0

    .prologue
    .line 1227
    iput-object p1, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide$10;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 4

    .prologue
    const/4 v3, 0x0

    .line 1231
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide$10;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;

    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide$10;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;

    invoke-static {v1}, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;->access$500(Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;)Landroid/content/res/Resources;

    move-result-object v1

    const v2, 0x7f020343

    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 1232
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide$10;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;->DestInfoDetail:Landroid/widget/Button;

    invoke-virtual {v0, v3}, Landroid/widget/Button;->setVisibility(I)V

    .line 1233
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide$10;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;->DestInfoAround:Landroid/widget/Button;

    invoke-virtual {v0, v3}, Landroid/widget/Button;->setVisibility(I)V

    .line 1234
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide$10;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;->DestInfoRoadview:Landroid/widget/Button;

    invoke-virtual {v0, v3}, Landroid/widget/Button;->setVisibility(I)V

    .line 1235
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide$10;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;->DestInfoFivepin:Landroid/widget/Button;

    invoke-virtual {v0, v3}, Landroid/widget/Button;->setVisibility(I)V

    .line 1236
    return-void
.end method
