.class Ltas/internal/camera/InputChannel$Guardian;
.super Landroid/os/Handler;
.source "InputChannel.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltas/internal/camera/InputChannel;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "Guardian"
.end annotation


# static fields
.field private static final INVALID_MSG:I = -0x1

.field private static final MSG_OPEN:I = 0x0

.field private static final MSG_RELEASE:I = 0x1

.field private static final TAG:Ljava/lang/String; = "TasCAM<Guardian>"

.field private static final TIMEOUT:I = 0x1388

.field private static final TOLERABLE_CHECK_COUNT:I = 0x2


# instance fields
.field private mCheckCount:I

.field private mDispatcher:Ltas/internal/camera/Dispatcher;

.field private mEnabled:Z

.field private mGuardian:Ltas/internal/camera/util/CameraMonitor;

.field private mMonitor:Ltas/internal/camera/util/CameraMonitor;

.field private mProc:Ljava/lang/String;

.field private mWhat:I


# direct methods
.method static synthetic -wrap0(Ltas/internal/camera/InputChannel$Guardian;ZLjava/lang/String;)Z
    .locals 1
    .param p1, "open"    # Z
    .param p2, "proc"    # Ljava/lang/String;

    .prologue
    invoke-direct {p0, p1, p2}, Ltas/internal/camera/InputChannel$Guardian;->start(ZLjava/lang/String;)Z

    move-result v0

    return v0
.end method

.method static synthetic -wrap1(Ltas/internal/camera/InputChannel$Guardian;)V
    .locals 0

    invoke-direct {p0}, Ltas/internal/camera/InputChannel$Guardian;->disable()V

    return-void
.end method

.method static synthetic -wrap2(Ltas/internal/camera/InputChannel$Guardian;)V
    .locals 0

    invoke-direct {p0}, Ltas/internal/camera/InputChannel$Guardian;->enable()V

    return-void
.end method

.method static synthetic -wrap3(Ltas/internal/camera/InputChannel$Guardian;ILtas/internal/camera/InputSourceInner;)V
    .locals 0
    .param p1, "what"    # I
    .param p2, "input"    # Ltas/internal/camera/InputSourceInner;

    .prologue
    invoke-direct {p0, p1, p2}, Ltas/internal/camera/InputChannel$Guardian;->onCheckFailure(ILtas/internal/camera/InputSourceInner;)V

    return-void
.end method

.method static synthetic -wrap4(Ltas/internal/camera/InputChannel$Guardian;ILtas/internal/camera/InputSourceInner;)V
    .locals 0
    .param p1, "what"    # I
    .param p2, "input"    # Ltas/internal/camera/InputSourceInner;

    .prologue
    invoke-direct {p0, p1, p2}, Ltas/internal/camera/InputChannel$Guardian;->onCheckSuccess(ILtas/internal/camera/InputSourceInner;)V

    return-void
.end method

.method static synthetic -wrap5(Ltas/internal/camera/InputChannel$Guardian;)V
    .locals 0

    invoke-direct {p0}, Ltas/internal/camera/InputChannel$Guardian;->stop()V

    return-void
.end method

.method private constructor <init>(Ltas/internal/camera/Dispatcher;Ltas/internal/camera/util/CameraMonitor;)V
    .locals 1
    .param p1, "dispatcher"    # Ltas/internal/camera/Dispatcher;
    .param p2, "monitor"    # Ltas/internal/camera/util/CameraMonitor;

    .prologue
    .line 405
    invoke-direct {p0}, Landroid/os/Handler;-><init>()V

    .line 402
    const/4 v0, 0x0

    iput v0, p0, Ltas/internal/camera/InputChannel$Guardian;->mCheckCount:I

    .line 406
    iput-object p1, p0, Ltas/internal/camera/InputChannel$Guardian;->mDispatcher:Ltas/internal/camera/Dispatcher;

    .line 407
    iput-object p2, p0, Ltas/internal/camera/InputChannel$Guardian;->mMonitor:Ltas/internal/camera/util/CameraMonitor;

    .line 404
    return-void
.end method

.method synthetic constructor <init>(Ltas/internal/camera/Dispatcher;Ltas/internal/camera/util/CameraMonitor;Ltas/internal/camera/InputChannel$Guardian;)V
    .locals 0
    .param p1, "dispatcher"    # Ltas/internal/camera/Dispatcher;
    .param p2, "monitor"    # Ltas/internal/camera/util/CameraMonitor;

    .prologue
    invoke-direct {p0, p1, p2}, Ltas/internal/camera/InputChannel$Guardian;-><init>(Ltas/internal/camera/Dispatcher;Ltas/internal/camera/util/CameraMonitor;)V

    return-void
.end method

.method private cancelPendings()V
    .locals 1

    .prologue
    .line 425
    iget v0, p0, Ltas/internal/camera/InputChannel$Guardian;->mWhat:I

    invoke-direct {p0, v0}, Ltas/internal/camera/InputChannel$Guardian;->cancelPendings(I)V

    .line 424
    return-void
.end method

.method private cancelPendings(I)V
    .locals 4
    .param p1, "what"    # I

    .prologue
    const/4 v3, -0x1

    .line 429
    if-eq p1, v3, :cond_0

    invoke-virtual {p0, p1}, Ltas/internal/camera/InputChannel$Guardian;->hasMessages(I)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 430
    const-string/jumbo v0, "TasCAM<Guardian>"

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "cancel : "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 431
    invoke-virtual {p0, p1}, Ltas/internal/camera/InputChannel$Guardian;->removeMessages(I)V

    .line 432
    iput v3, p0, Ltas/internal/camera/InputChannel$Guardian;->mWhat:I

    .line 428
    :cond_0
    return-void
.end method

.method private check(ILtas/internal/camera/InputSourceInner;)V
    .locals 4
    .param p1, "what"    # I
    .param p2, "input"    # Ltas/internal/camera/InputSourceInner;

    .prologue
    .line 474
    const-string/jumbo v1, "TasCAM<Guardian>"

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "times out... "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string/jumbo v3, ", "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 476
    iget v1, p2, Ltas/internal/camera/InputSourceInner;->camidCompat:I

    invoke-direct {p0, v1}, Ltas/internal/camera/InputChannel$Guardian;->getGuardian(I)Ltas/internal/camera/util/CameraMonitor;

    move-result-object v0

    .line 477
    .local v0, "guardian":Ltas/internal/camera/util/CameraMonitor;
    new-instance v1, Ltas/internal/camera/InputChannel$Guardian$1;

    invoke-direct {v1, p0, p1, p2}, Ltas/internal/camera/InputChannel$Guardian$1;-><init>(Ltas/internal/camera/InputChannel$Guardian;ILtas/internal/camera/InputSourceInner;)V

    invoke-virtual {v0, v1}, Ltas/internal/camera/util/CameraMonitor;->setCallback(Ltas/internal/camera/util/CameraMonitor$Callback;)V

    .line 497
    invoke-virtual {v0}, Ltas/internal/camera/util/CameraMonitor;->connect()V

    .line 473
    return-void
.end method

.method private disable()V
    .locals 1

    .prologue
    .line 415
    invoke-direct {p0}, Ltas/internal/camera/InputChannel$Guardian;->cancelPendings()V

    .line 416
    invoke-direct {p0}, Ltas/internal/camera/InputChannel$Guardian;->releaseGuardian()V

    .line 417
    const/4 v0, 0x0

    iput-boolean v0, p0, Ltas/internal/camera/InputChannel$Guardian;->mEnabled:Z

    .line 414
    return-void
.end method

.method private disconnectGuardian()V
    .locals 1

    .prologue
    .line 589
    iget-object v0, p0, Ltas/internal/camera/InputChannel$Guardian;->mGuardian:Ltas/internal/camera/util/CameraMonitor;

    if-eqz v0, :cond_0

    .line 590
    iget-object v0, p0, Ltas/internal/camera/InputChannel$Guardian;->mGuardian:Ltas/internal/camera/util/CameraMonitor;

    invoke-virtual {v0}, Ltas/internal/camera/util/CameraMonitor;->disconnect()I

    .line 588
    :cond_0
    return-void
.end method

.method private enable()V
    .locals 1

    .prologue
    .line 411
    const/4 v0, 0x1

    iput-boolean v0, p0, Ltas/internal/camera/InputChannel$Guardian;->mEnabled:Z

    .line 410
    return-void
.end method

.method private getGuardian(I)Ltas/internal/camera/util/CameraMonitor;
    .locals 4
    .param p1, "camid"    # I

    .prologue
    const/4 v3, 0x0

    .line 563
    iget-object v0, p0, Ltas/internal/camera/InputChannel$Guardian;->mGuardian:Ltas/internal/camera/util/CameraMonitor;

    if-nez v0, :cond_0

    .line 564
    const-string/jumbo v0, "TasCAM<Guardian>"

    const-string/jumbo v1, "start"

    invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 565
    new-instance v0, Ltas/internal/camera/util/CameraMonitor;

    .line 566
    iget-object v1, p0, Ltas/internal/camera/InputChannel$Guardian;->mMonitor:Ltas/internal/camera/util/CameraMonitor;

    invoke-virtual {v1}, Ltas/internal/camera/util/CameraMonitor;->getContext()Landroid/content/Context;

    move-result-object v1

    const/4 v2, 0x1

    .line 565
    invoke-direct {v0, v1, v3, v2}, Ltas/internal/camera/util/CameraMonitor;-><init>(Landroid/content/Context;Ltas/internal/camera/util/CameraMonitor$Callback;Z)V

    iput-object v0, p0, Ltas/internal/camera/InputChannel$Guardian;->mGuardian:Ltas/internal/camera/util/CameraMonitor;

    .line 569
    :cond_0
    iget-object v0, p0, Ltas/internal/camera/InputChannel$Guardian;->mGuardian:Ltas/internal/camera/util/CameraMonitor;

    invoke-virtual {v0}, Ltas/internal/camera/util/CameraMonitor;->reset()V

    .line 570
    iget-object v0, p0, Ltas/internal/camera/InputChannel$Guardian;->mGuardian:Ltas/internal/camera/util/CameraMonitor;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Ltas/internal/camera/util/CameraMonitor;->monitorAll(Z)V

    .line 571
    iget-object v0, p0, Ltas/internal/camera/InputChannel$Guardian;->mGuardian:Ltas/internal/camera/util/CameraMonitor;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-virtual {v0, v1}, Ltas/internal/camera/util/CameraMonitor;->monitor(Ljava/lang/Integer;)V

    .line 574
    iget-object v0, p0, Ltas/internal/camera/InputChannel$Guardian;->mMonitor:Ltas/internal/camera/util/CameraMonitor;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-virtual {v0, v1}, Ltas/internal/camera/util/CameraMonitor;->skip(Ljava/lang/Integer;)V

    .line 576
    iget-object v0, p0, Ltas/internal/camera/InputChannel$Guardian;->mGuardian:Ltas/internal/camera/util/CameraMonitor;

    return-object v0
.end method

.method private getInput()Ltas/internal/camera/InputSourceInner;
    .locals 1

    .prologue
    .line 437
    iget-object v0, p0, Ltas/internal/camera/InputChannel$Guardian;->mDispatcher:Ltas/internal/camera/Dispatcher;

    iget-object v0, v0, Ltas/internal/camera/Dispatcher;->channel:Ltas/internal/camera/InputChannel;

    invoke-virtual {v0}, Ltas/internal/camera/InputChannel;->getCurrInput()Ltas/internal/camera/InputSourceInner;

    move-result-object v0

    return-object v0
.end method

.method private isEnabled()Z
    .locals 1

    .prologue
    .line 421
    iget-boolean v0, p0, Ltas/internal/camera/InputChannel$Guardian;->mEnabled:Z

    return v0
.end method

.method private onCheckFailure(ILtas/internal/camera/InputSourceInner;)V
    .locals 4
    .param p1, "what"    # I
    .param p2, "input"    # Ltas/internal/camera/InputSourceInner;

    .prologue
    const/4 v3, 0x0

    .line 529
    const-string/jumbo v1, "TasCAM<Guardian>"

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "camera still "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    .line 530
    if-nez p1, :cond_0

    const-string/jumbo v0, "not opened"

    .line 529
    :goto_0
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 535
    iget-object v0, p0, Ltas/internal/camera/InputChannel$Guardian;->mDispatcher:Ltas/internal/camera/Dispatcher;

    iget-object v0, v0, Ltas/internal/camera/Dispatcher;->server:Ltas/internal/camera/server/ServerOutGoing;

    iget-object v1, p0, Ltas/internal/camera/InputChannel$Guardian;->mProc:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ltas/internal/camera/server/ServerOutGoing;->isClientRunning(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_1

    .line 536
    iget-object v0, p0, Ltas/internal/camera/InputChannel$Guardian;->mDispatcher:Ltas/internal/camera/Dispatcher;

    iget-object v0, v0, Ltas/internal/camera/Dispatcher;->server:Ltas/internal/camera/server/ServerOutGoing;

    iget-object v1, p0, Ltas/internal/camera/InputChannel$Guardian;->mProc:Ljava/lang/String;

    iget-object v2, p2, Ltas/internal/camera/InputSourceInner;->camcls:Ljava/lang/String;

    invoke-virtual {v0, v1, v2}, Ltas/internal/camera/server/ServerOutGoing;->isClientConcern(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    .line 535
    if-eqz v0, :cond_1

    .line 537
    iget v0, p0, Ltas/internal/camera/InputChannel$Guardian;->mCheckCount:I

    const/4 v1, 0x2

    if-ge v0, v1, :cond_1

    .line 538
    const-string/jumbo v0, "TasCAM<Guardian>"

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "remote client is running. schedule next "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 540
    iget v0, p0, Ltas/internal/camera/InputChannel$Guardian;->mCheckCount:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Ltas/internal/camera/InputChannel$Guardian;->mCheckCount:I

    .line 541
    invoke-direct {p0, p1, p2}, Ltas/internal/camera/InputChannel$Guardian;->schedule(ILtas/internal/camera/InputSourceInner;)V

    .line 542
    invoke-direct {p0}, Ltas/internal/camera/InputChannel$Guardian;->disconnectGuardian()V

    .line 559
    :goto_1
    iget-object v0, p0, Ltas/internal/camera/InputChannel$Guardian;->mMonitor:Ltas/internal/camera/util/CameraMonitor;

    invoke-virtual {v0}, Ltas/internal/camera/util/CameraMonitor;->reset()V

    .line 528
    return-void

    .line 530
    :cond_0
    const-string/jumbo v0, "opened"

    goto :goto_0

    .line 545
    :cond_1
    const-string/jumbo v0, "TasCAM<Guardian>"

    const-string/jumbo v1, "remote client probably dead. cancel event"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 547
    iget-object v0, p0, Ltas/internal/camera/InputChannel$Guardian;->mDispatcher:Ltas/internal/camera/Dispatcher;

    iget-object v0, v0, Ltas/internal/camera/Dispatcher;->channel:Ltas/internal/camera/InputChannel;

    invoke-static {v0, v3}, Ltas/internal/camera/InputChannel;->-set0(Ltas/internal/camera/InputChannel;Ltas/internal/camera/InputSourceInner;)Ltas/internal/camera/InputSourceInner;

    .line 548
    iget-object v0, p0, Ltas/internal/camera/InputChannel$Guardian;->mDispatcher:Ltas/internal/camera/Dispatcher;

    iget-object v0, v0, Ltas/internal/camera/Dispatcher;->channel:Ltas/internal/camera/InputChannel;

    invoke-static {v0, v3}, Ltas/internal/camera/InputChannel;->-set1(Ltas/internal/camera/InputChannel;Ljava/lang/String;)Ljava/lang/String;

    .line 554
    iget-object v0, p0, Ltas/internal/camera/InputChannel$Guardian;->mDispatcher:Ltas/internal/camera/Dispatcher;

    invoke-virtual {v0}, Ltas/internal/camera/Dispatcher;->resume()V

    .line 556
    invoke-direct {p0}, Ltas/internal/camera/InputChannel$Guardian;->stop()V

    goto :goto_1
.end method

.method private onCheckSuccess(ILtas/internal/camera/InputSourceInner;)V
    .locals 3
    .param p1, "what"    # I
    .param p2, "input"    # Ltas/internal/camera/InputSourceInner;

    .prologue
    .line 501
    const-string/jumbo v1, "TasCAM<Guardian>"

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "camera already "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    .line 502
    if-nez p1, :cond_0

    const-string/jumbo v0, "opened"

    .line 501
    :goto_0
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 509
    packed-switch p1, :pswitch_data_0

    .line 519
    const-string/jumbo v0, "TasCAM<Guardian>"

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "invalid what="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 523
    :goto_1
    invoke-direct {p0}, Ltas/internal/camera/InputChannel$Guardian;->releaseGuardian()V

    .line 524
    iget-object v0, p0, Ltas/internal/camera/InputChannel$Guardian;->mMonitor:Ltas/internal/camera/util/CameraMonitor;

    invoke-virtual {v0}, Ltas/internal/camera/util/CameraMonitor;->reset()V

    .line 525
    iget-object v0, p0, Ltas/internal/camera/InputChannel$Guardian;->mMonitor:Ltas/internal/camera/util/CameraMonitor;

    invoke-virtual {v0}, Ltas/internal/camera/util/CameraMonitor;->reconnect()V

    .line 500
    return-void

    .line 502
    :cond_0
    const-string/jumbo v0, "released"

    goto :goto_0

    .line 511
    :pswitch_0
    iget-object v0, p0, Ltas/internal/camera/InputChannel$Guardian;->mDispatcher:Ltas/internal/camera/Dispatcher;

    iget-object v0, v0, Ltas/internal/camera/Dispatcher;->channel:Ltas/internal/camera/InputChannel;

    invoke-virtual {v0}, Ltas/internal/camera/InputChannel;->onCameraOpen()V

    goto :goto_1

    .line 515
    :pswitch_1
    iget-object v0, p0, Ltas/internal/camera/InputChannel$Guardian;->mDispatcher:Ltas/internal/camera/Dispatcher;

    iget-object v0, v0, Ltas/internal/camera/Dispatcher;->channel:Ltas/internal/camera/InputChannel;

    invoke-virtual {v0}, Ltas/internal/camera/InputChannel;->onCameraRelease()V

    goto :goto_1

    .line 509
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
        :pswitch_1
    .end packed-switch
.end method

.method private releaseGuardian()V
    .locals 3

    .prologue
    const/4 v2, 0x0

    .line 580
    iget-object v0, p0, Ltas/internal/camera/InputChannel$Guardian;->mGuardian:Ltas/internal/camera/util/CameraMonitor;

    if-eqz v0, :cond_0

    .line 581
    const-string/jumbo v0, "TasCAM<Guardian>"

    const-string/jumbo v1, "stop"

    invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 582
    iget-object v0, p0, Ltas/internal/camera/InputChannel$Guardian;->mGuardian:Ltas/internal/camera/util/CameraMonitor;

    invoke-virtual {v0}, Ltas/internal/camera/util/CameraMonitor;->release()V

    .line 583
    iput-object v2, p0, Ltas/internal/camera/InputChannel$Guardian;->mGuardian:Ltas/internal/camera/util/CameraMonitor;

    .line 585
    :cond_0
    const/4 v0, 0x0

    iput v0, p0, Ltas/internal/camera/InputChannel$Guardian;->mCheckCount:I

    .line 579
    return-void
.end method

.method private schedule(ILtas/internal/camera/InputSourceInner;)V
    .locals 4
    .param p1, "what"    # I
    .param p2, "input"    # Ltas/internal/camera/InputSourceInner;

    .prologue
    const/4 v0, 0x0

    .line 468
    iput p1, p0, Ltas/internal/camera/InputChannel$Guardian;->mWhat:I

    .line 470
    invoke-virtual {p0, p1, v0, v0, p2}, Ltas/internal/camera/InputChannel$Guardian;->obtainMessage(IIILjava/lang/Object;)Landroid/os/Message;

    move-result-object v0

    const-wide/16 v2, 0x1388

    .line 469
    invoke-virtual {p0, v0, v2, v3}, Ltas/internal/camera/InputChannel$Guardian;->sendMessageDelayed(Landroid/os/Message;J)Z

    .line 467
    return-void
.end method

.method private start(ZLjava/lang/String;)Z
    .locals 5
    .param p1, "open"    # Z
    .param p2, "proc"    # Ljava/lang/String;

    .prologue
    const/4 v4, 0x0

    .line 441
    iget-boolean v1, p0, Ltas/internal/camera/InputChannel$Guardian;->mEnabled:Z

    if-nez v1, :cond_0

    .line 442
    const-string/jumbo v1, "TasCAM<Guardian>"

    const-string/jumbo v2, "disabled"

    invoke-static {v1, v2}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 443
    return v4

    .line 446
    :cond_0
    if-eqz p1, :cond_1

    const/4 v0, 0x0

    .line 447
    .local v0, "what":I
    :goto_0
    invoke-virtual {p0, v0}, Ltas/internal/camera/InputChannel$Guardian;->hasMessages(I)Z

    move-result v1

    if-eqz v1, :cond_2

    .line 448
    const-string/jumbo v1, "TasCAM<Guardian>"

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "already in schedule : "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 449
    return v4

    .line 446
    .end local v0    # "what":I
    :cond_1
    const/4 v0, 0x1

    .restart local v0    # "what":I
    goto :goto_0

    .line 452
    :cond_2
    const-string/jumbo v1, "TasCAM<Guardian>"

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "prepare : "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 454
    if-eqz p1, :cond_3

    .line 455
    iput-object p2, p0, Ltas/internal/camera/InputChannel$Guardian;->mProc:Ljava/lang/String;

    .line 458
    :cond_3
    invoke-direct {p0}, Ltas/internal/camera/InputChannel$Guardian;->getInput()Ltas/internal/camera/InputSourceInner;

    move-result-object v1

    invoke-direct {p0, v0, v1}, Ltas/internal/camera/InputChannel$Guardian;->schedule(ILtas/internal/camera/InputSourceInner;)V

    .line 459
    const/4 v1, 0x1

    return v1
.end method

.method private stop()V
    .locals 0

    .prologue
    .line 463
    invoke-direct {p0}, Ltas/internal/camera/InputChannel$Guardian;->cancelPendings()V

    .line 464
    invoke-direct {p0}, Ltas/internal/camera/InputChannel$Guardian;->releaseGuardian()V

    .line 462
    return-void
.end method


# virtual methods
.method public handleMessage(Landroid/os/Message;)V
    .locals 2
    .param p1, "msg"    # Landroid/os/Message;

    .prologue
    .line 595
    iget v0, p1, Landroid/os/Message;->what:I

    packed-switch v0, :pswitch_data_0

    .line 594
    :goto_0
    return-void

    .line 598
    :pswitch_0
    const/4 v0, -0x1

    iput v0, p0, Ltas/internal/camera/InputChannel$Guardian;->mWhat:I

    .line 599
    iget v1, p1, Landroid/os/Message;->what:I

    iget-object v0, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v0, Ltas/internal/camera/InputSourceInner;

    invoke-direct {p0, v1, v0}, Ltas/internal/camera/InputChannel$Guardian;->check(ILtas/internal/camera/InputSourceInner;)V

    goto :goto_0

    .line 595
    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
        :pswitch_0
    .end packed-switch
.end method
