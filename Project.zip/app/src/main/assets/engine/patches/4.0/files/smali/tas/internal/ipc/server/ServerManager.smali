.class Ltas/internal/ipc/server/ServerManager;
.super Ljava/lang/Object;
.source "ServerManager.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ltas/internal/ipc/server/ServerManager$ClientHandler;,
        Ltas/internal/ipc/server/ServerManager$ClientHolder;,
        Ltas/internal/ipc/server/ServerManager$SenderHolder;,
        Ltas/internal/ipc/server/ServerManager$ReceiverHolder;
    }
.end annotation


# static fields
.field private static final DBG:Z = true

.field private static final MAX_CONNECTIONS:I = 0x7fffffff

.field private static final MSG_ON_RECEIVER_OFF_LINE:I = 0x11

.field private static final MSG_ON_RECEIVER_ON_LINE:I = 0x10

.field private static final MSG_ON_RECEIVER_UPDATE:I = 0x14

.field private static final MSG_ON_SENDER_OFF_LINE:I = 0x13

.field private static final MSG_ON_SENDER_ON_LINE:I = 0x12

.field private static final MSG_ON_SENDER_UPDATE:I = 0x15

.field private static final MSG_QUIT:I = 0x16

.field private static final MSG_REGISTER_RECEIVER:I = 0x0

.field private static final MSG_REGISTER_SENDER:I = 0x3

.field private static final MSG_SET_CALLBACK:I = 0xe

.field private static final MSG_TRANSMIT:I = 0xf

.field private static final MSG_UNREGISTER_RECEIVER:I = 0x1

.field private static final MSG_UNREGISTER_SENDER:I = 0x4

.field private static final MSG_UNWATCH_ANONYMOUS_RECEIVER:I = 0x9

.field private static final MSG_UNWATCH_ANONYMOUS_SENDER:I = 0xd

.field private static final MSG_UNWATCH_RECEIVER:I = 0x7

.field private static final MSG_UNWATCH_SENDER:I = 0xb

.field private static final MSG_UPDATE_RECEIVER:I = 0x2

.field private static final MSG_UPDATE_SENDER:I = 0x5

.field private static final MSG_WATCH_ANONYMOUS_RECEIVER:I = 0x8

.field private static final MSG_WATCH_ANONYMOUS_SENDER:I = 0xc

.field private static final MSG_WATCH_RECEIVER:I = 0x6

.field private static final MSG_WATCH_SENDER:I = 0xa

.field private static final TAG:Ljava/lang/String; = "TasIPC<ServerManager>"


# instance fields
.field private final mClients:Landroid/util/ArrayMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/util/ArrayMap",
            "<",
            "Ljava/lang/String;",
            "Ltas/internal/ipc/server/ServerManager$ClientHolder;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static synthetic -get0(Ltas/internal/ipc/server/ServerManager;)Landroid/util/ArrayMap;
    .locals 1

    iget-object v0, p0, Ltas/internal/ipc/server/ServerManager;->mClients:Landroid/util/ArrayMap;

    return-object v0
.end method

.method constructor <init>()V
    .locals 2

    .prologue
    .line 57
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1075
    new-instance v0, Landroid/util/ArrayMap;

    const/16 v1, 0xa

    invoke-direct {v0, v1}, Landroid/util/ArrayMap;-><init>(I)V

    .line 1074
    iput-object v0, p0, Ltas/internal/ipc/server/ServerManager;->mClients:Landroid/util/ArrayMap;

    .line 57
    return-void
.end method

.method private getClientHolder(IZ)Ltas/internal/ipc/server/ServerManager$ClientHolder;
    .locals 5
    .param p1, "pid"    # I
    .param p2, "autoCreate"    # Z

    .prologue
    const/4 v4, 0x0

    .line 153
    monitor-enter p0

    .line 154
    :try_start_0
    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v1

    .line 155
    .local v1, "p":Ljava/lang/String;
    iget-object v2, p0, Ltas/internal/ipc/server/ServerManager;->mClients:Landroid/util/ArrayMap;

    invoke-virtual {v2, v1}, Landroid/util/ArrayMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/ipc/server/ServerManager$ClientHolder;

    .line 156
    .local v0, "c":Ltas/internal/ipc/server/ServerManager$ClientHolder;
    if-nez v0, :cond_1

    if-eqz p2, :cond_1

    .line 157
    iget-object v2, p0, Ltas/internal/ipc/server/ServerManager;->mClients:Landroid/util/ArrayMap;

    invoke-virtual {v2}, Landroid/util/ArrayMap;->size()I

    move-result v2

    const v3, 0x7fffffff

    if-ne v2, v3, :cond_0

    .line 158
    const-string/jumbo v2, "TasIPC<ServerManager>"

    const-string/jumbo v3, "too many connections now... 2147483647"

    invoke-static {v2, v3}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 159
    invoke-virtual {p0}, Ltas/internal/ipc/server/ServerManager;->dump()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit p0

    .line 160
    return-object v4

    .line 162
    :cond_0
    :try_start_1
    new-instance v0, Ltas/internal/ipc/server/ServerManager$ClientHolder;

    .end local v0    # "c":Ltas/internal/ipc/server/ServerManager$ClientHolder;
    const/4 v2, 0x0

    invoke-direct {v0, p0, p1, v2}, Ltas/internal/ipc/server/ServerManager$ClientHolder;-><init>(Ltas/internal/ipc/server/ServerManager;ILtas/internal/ipc/server/ServerManager$ClientHolder;)V

    .line 163
    .restart local v0    # "c":Ltas/internal/ipc/server/ServerManager$ClientHolder;
    iget-object v2, p0, Ltas/internal/ipc/server/ServerManager;->mClients:Landroid/util/ArrayMap;

    invoke-virtual {v2, v1, v0}, Landroid/util/ArrayMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 165
    :cond_1
    if-nez v0, :cond_2

    .line 166
    const-string/jumbo v2, "TasIPC<ServerManager>"

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v4, "no client found at "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :cond_2
    monitor-exit p0

    .line 168
    return-object v0

    .line 153
    .end local v0    # "c":Ltas/internal/ipc/server/ServerManager$ClientHolder;
    .end local v1    # "p":Ljava/lang/String;
    :catchall_0
    move-exception v2

    monitor-exit p0

    throw v2
.end method

.method private schedule(IILtas/internal/ipc/server/RemoteReceiver;)V
    .locals 2
    .param p1, "pid"    # I
    .param p2, "what"    # I
    .param p3, "receiver"    # Ltas/internal/ipc/server/RemoteReceiver;

    .prologue
    .line 125
    const/4 v1, 0x0

    invoke-direct {p0, p1, v1}, Ltas/internal/ipc/server/ServerManager;->getClientHolder(IZ)Ltas/internal/ipc/server/ServerManager$ClientHolder;

    move-result-object v0

    .line 126
    .local v0, "c":Ltas/internal/ipc/server/ServerManager$ClientHolder;
    if-eqz v0, :cond_0

    .line 127
    invoke-static {v0}, Ltas/internal/ipc/server/ServerManager$ClientHolder;->-get0(Ltas/internal/ipc/server/ServerManager$ClientHolder;)Ltas/internal/ipc/server/ServerManager$ClientHandler;

    move-result-object v1

    invoke-static {v1, p2, p3}, Ltas/internal/ipc/server/ServerManager$ClientHandler;->-wrap0(Ltas/internal/ipc/server/ServerManager$ClientHandler;ILtas/internal/ipc/server/RemoteReceiver;)V

    .line 124
    :cond_0
    return-void
.end method

.method private schedule(IILtas/internal/ipc/server/RemoteSender;)V
    .locals 2
    .param p1, "pid"    # I
    .param p2, "what"    # I
    .param p3, "sender"    # Ltas/internal/ipc/server/RemoteSender;

    .prologue
    .line 132
    const/4 v1, 0x0

    invoke-direct {p0, p1, v1}, Ltas/internal/ipc/server/ServerManager;->getClientHolder(IZ)Ltas/internal/ipc/server/ServerManager$ClientHolder;

    move-result-object v0

    .line 133
    .local v0, "c":Ltas/internal/ipc/server/ServerManager$ClientHolder;
    if-eqz v0, :cond_0

    .line 134
    invoke-static {v0}, Ltas/internal/ipc/server/ServerManager$ClientHolder;->-get0(Ltas/internal/ipc/server/ServerManager$ClientHolder;)Ltas/internal/ipc/server/ServerManager$ClientHandler;

    move-result-object v1

    invoke-static {v1, p2, p3}, Ltas/internal/ipc/server/ServerManager$ClientHandler;->-wrap1(Ltas/internal/ipc/server/ServerManager$ClientHandler;ILtas/internal/ipc/server/RemoteSender;)V

    .line 131
    :cond_0
    return-void
.end method

.method private schedule(ILtas/internal/ipc/server/IServerCallback;)V
    .locals 2
    .param p1, "pid"    # I
    .param p2, "cb"    # Ltas/internal/ipc/server/IServerCallback;

    .prologue
    .line 139
    const/4 v1, 0x1

    invoke-direct {p0, p1, v1}, Ltas/internal/ipc/server/ServerManager;->getClientHolder(IZ)Ltas/internal/ipc/server/ServerManager$ClientHolder;

    move-result-object v0

    .line 140
    .local v0, "c":Ltas/internal/ipc/server/ServerManager$ClientHolder;
    if-eqz v0, :cond_0

    .line 141
    invoke-static {v0}, Ltas/internal/ipc/server/ServerManager$ClientHolder;->-get0(Ltas/internal/ipc/server/ServerManager$ClientHolder;)Ltas/internal/ipc/server/ServerManager$ClientHandler;

    move-result-object v1

    invoke-static {v1, p2}, Ltas/internal/ipc/server/ServerManager$ClientHandler;->-wrap2(Ltas/internal/ipc/server/ServerManager$ClientHandler;Ltas/internal/ipc/server/IServerCallback;)V

    .line 138
    :cond_0
    return-void
.end method

.method private schedule(ILtas/internal/ipc/server/RemoteMessage;)V
    .locals 2
    .param p1, "pid"    # I
    .param p2, "rmsg"    # Ltas/internal/ipc/server/RemoteMessage;

    .prologue
    .line 146
    const/4 v1, 0x0

    invoke-direct {p0, p1, v1}, Ltas/internal/ipc/server/ServerManager;->getClientHolder(IZ)Ltas/internal/ipc/server/ServerManager$ClientHolder;

    move-result-object v0

    .line 147
    .local v0, "c":Ltas/internal/ipc/server/ServerManager$ClientHolder;
    if-eqz v0, :cond_0

    .line 148
    invoke-static {v0}, Ltas/internal/ipc/server/ServerManager$ClientHolder;->-get0(Ltas/internal/ipc/server/ServerManager$ClientHolder;)Ltas/internal/ipc/server/ServerManager$ClientHandler;

    move-result-object v1

    invoke-static {v1, p2}, Ltas/internal/ipc/server/ServerManager$ClientHandler;->-wrap3(Ltas/internal/ipc/server/ServerManager$ClientHandler;Ltas/internal/ipc/server/RemoteMessage;)V

    .line 145
    :cond_0
    return-void
.end method


# virtual methods
.method dump()V
    .locals 18

    .prologue
    .line 1195
    new-instance v11, Ljava/lang/StringBuilder;

    invoke-direct {v11}, Ljava/lang/StringBuilder;-><init>()V

    .line 1196
    .local v11, "sb":Ljava/lang/StringBuilder;
    const-string/jumbo v16, "******************************\n"

    move-object/from16 v0, v16

    invoke-virtual {v11, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1197
    const-string/jumbo v16, "Number of Clients: "

    move-object/from16 v0, v16

    invoke-virtual {v11, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v16

    move-object/from16 v0, p0

    iget-object v0, v0, Ltas/internal/ipc/server/ServerManager;->mClients:Landroid/util/ArrayMap;

    move-object/from16 v17, v0

    invoke-virtual/range {v17 .. v17}, Landroid/util/ArrayMap;->size()I

    move-result v17

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v16

    const-string/jumbo v17, "\n"

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1198
    move-object/from16 v0, p0

    iget-object v0, v0, Ltas/internal/ipc/server/ServerManager;->mClients:Landroid/util/ArrayMap;

    move-object/from16 v16, v0

    invoke-virtual/range {v16 .. v16}, Landroid/util/ArrayMap;->values()Ljava/util/Collection;

    move-result-object v4

    .line 1199
    .local v4, "clients":Ljava/util/Collection;, "Ljava/util/Collection<Ltas/internal/ipc/server/ServerManager$ClientHolder;>;"
    invoke-interface {v4}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v3

    .local v3, "client$iterator":Ljava/util/Iterator;
    :cond_0
    :goto_0
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v16

    if-eqz v16, :cond_7

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ltas/internal/ipc/server/ServerManager$ClientHolder;

    .line 1200
    .local v2, "client":Ltas/internal/ipc/server/ServerManager$ClientHolder;
    if-eqz v2, :cond_0

    .line 1203
    invoke-static {v2}, Ltas/internal/ipc/server/ServerManager$ClientHolder;->-get0(Ltas/internal/ipc/server/ServerManager$ClientHolder;)Ltas/internal/ipc/server/ServerManager$ClientHandler;

    move-result-object v1

    .line 1204
    .local v1, "c":Ltas/internal/ipc/server/ServerManager$ClientHandler;
    const-string/jumbo v16, "\nClient: "

    move-object/from16 v0, v16

    invoke-virtual {v11, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1205
    const-string/jumbo v16, "p="

    move-object/from16 v0, v16

    invoke-virtual {v11, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v16

    iget v0, v1, Ltas/internal/ipc/server/ServerManager$ClientHandler;->pid:I

    move/from16 v17, v0

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 1206
    const-string/jumbo v16, ", t="

    move-object/from16 v0, v16

    invoke-virtual {v11, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v16

    iget v0, v1, Ltas/internal/ipc/server/ServerManager$ClientHandler;->tid:I

    move/from16 v17, v0

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 1207
    const-string/jumbo v16, " {\n"

    move-object/from16 v0, v16

    invoke-virtual {v11, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1208
    const-string/jumbo v16, "  s {\n"

    move-object/from16 v0, v16

    invoke-virtual {v11, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1209
    invoke-static {v1}, Ltas/internal/ipc/server/ServerManager$ClientHandler;->-get1(Ltas/internal/ipc/server/ServerManager$ClientHandler;)Ljava/util/List;

    move-result-object v16

    invoke-interface/range {v16 .. v16}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v13

    .local v13, "sh$iterator":Ljava/util/Iterator;
    :cond_1
    invoke-interface {v13}, Ljava/util/Iterator;->hasNext()Z

    move-result v16

    if-eqz v16, :cond_3

    invoke-interface {v13}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Ltas/internal/ipc/server/ServerManager$SenderHolder;

    .line 1210
    .local v12, "sh":Ltas/internal/ipc/server/ServerManager$SenderHolder;
    if-eqz v12, :cond_1

    .line 1211
    const-string/jumbo v16, "    "

    move-object/from16 v0, v16

    invoke-virtual {v11, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v16

    invoke-static {v12}, Ltas/internal/ipc/server/ServerManager$SenderHolder;->-get1(Ltas/internal/ipc/server/ServerManager$SenderHolder;)Ltas/internal/ipc/server/RemoteSender;

    move-result-object v17

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v16

    const-string/jumbo v17, "\n"

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1213
    invoke-static {v12}, Ltas/internal/ipc/server/ServerManager$SenderHolder;->-get3(Ltas/internal/ipc/server/ServerManager$SenderHolder;)Ljava/util/List;

    move-result-object v16

    invoke-interface/range {v16 .. v16}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v15

    .local v15, "watch$iterator":Ljava/util/Iterator;
    :goto_1
    invoke-interface {v15}, Ljava/util/Iterator;->hasNext()Z

    move-result v16

    if-eqz v16, :cond_2

    invoke-interface {v15}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v14

    check-cast v14, Ljava/lang/String;

    .line 1214
    .local v14, "watch":Ljava/lang/String;
    const-string/jumbo v16, "      w:"

    move-object/from16 v0, v16

    invoke-virtual {v11, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v16

    move-object/from16 v0, v16

    invoke-virtual {v0, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v16

    const-string/jumbo v17, "\n"

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_1

    .line 1217
    .end local v14    # "watch":Ljava/lang/String;
    :cond_2
    const-string/jumbo v16, "      anonymous:"

    move-object/from16 v0, v16

    invoke-virtual {v11, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v16

    .line 1218
    invoke-static {v12}, Ltas/internal/ipc/server/ServerManager$SenderHolder;->-get2(Ltas/internal/ipc/server/ServerManager$SenderHolder;)Z

    move-result v17

    .line 1217
    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v16

    .line 1218
    const-string/jumbo v17, "\n"

    .line 1217
    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1220
    invoke-static {v12}, Ltas/internal/ipc/server/ServerManager$SenderHolder;->-get0(Ltas/internal/ipc/server/ServerManager$SenderHolder;)Ljava/util/List;

    move-result-object v16

    invoke-interface/range {v16 .. v16}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v8

    .local v8, "rr$iterator":Ljava/util/Iterator;
    :goto_2
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    move-result v16

    if-eqz v16, :cond_1

    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ltas/internal/ipc/server/RemoteReceiver;

    .line 1221
    .local v7, "rr":Ltas/internal/ipc/server/RemoteReceiver;
    const-string/jumbo v16, "      r:"

    move-object/from16 v0, v16

    invoke-virtual {v11, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v16

    move-object/from16 v0, v16

    invoke-virtual {v0, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v16

    const-string/jumbo v17, "\n"

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_2

    .line 1224
    .end local v7    # "rr":Ltas/internal/ipc/server/RemoteReceiver;
    .end local v8    # "rr$iterator":Ljava/util/Iterator;
    .end local v12    # "sh":Ltas/internal/ipc/server/ServerManager$SenderHolder;
    .end local v15    # "watch$iterator":Ljava/util/Iterator;
    :cond_3
    const-string/jumbo v16, "  }\n"

    move-object/from16 v0, v16

    invoke-virtual {v11, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1225
    const-string/jumbo v16, "  r {\n"

    move-object/from16 v0, v16

    invoke-virtual {v11, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1226
    invoke-static {v1}, Ltas/internal/ipc/server/ServerManager$ClientHandler;->-get0(Ltas/internal/ipc/server/ServerManager$ClientHandler;)Ljava/util/List;

    move-result-object v16

    invoke-interface/range {v16 .. v16}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v6

    .local v6, "rh$iterator":Ljava/util/Iterator;
    :cond_4
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    move-result v16

    if-eqz v16, :cond_6

    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;

    .line 1227
    .local v5, "rh":Ltas/internal/ipc/server/ServerManager$ReceiverHolder;
    if-eqz v5, :cond_4

    .line 1228
    const-string/jumbo v16, "    "

    move-object/from16 v0, v16

    invoke-virtual {v11, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v16

    invoke-static {v5}, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->-get0(Ltas/internal/ipc/server/ServerManager$ReceiverHolder;)Ltas/internal/ipc/server/RemoteReceiver;

    move-result-object v17

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v16

    const-string/jumbo v17, "\n"

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1230
    invoke-static {v5}, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->-get3(Ltas/internal/ipc/server/ServerManager$ReceiverHolder;)Ljava/util/List;

    move-result-object v16

    invoke-interface/range {v16 .. v16}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v15

    .restart local v15    # "watch$iterator":Ljava/util/Iterator;
    :goto_3
    invoke-interface {v15}, Ljava/util/Iterator;->hasNext()Z

    move-result v16

    if-eqz v16, :cond_5

    invoke-interface {v15}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v14

    check-cast v14, Ljava/lang/String;

    .line 1231
    .restart local v14    # "watch":Ljava/lang/String;
    const-string/jumbo v16, "      w:"

    move-object/from16 v0, v16

    invoke-virtual {v11, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v16

    move-object/from16 v0, v16

    invoke-virtual {v0, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v16

    const-string/jumbo v17, "\n"

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_3

    .line 1234
    .end local v14    # "watch":Ljava/lang/String;
    :cond_5
    const-string/jumbo v16, "      anonymous:"

    move-object/from16 v0, v16

    invoke-virtual {v11, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v16

    .line 1235
    invoke-static {v5}, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->-get2(Ltas/internal/ipc/server/ServerManager$ReceiverHolder;)Z

    move-result v17

    .line 1234
    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v16

    .line 1235
    const-string/jumbo v17, "\n"

    .line 1234
    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1237
    invoke-static {v5}, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->-get1(Ltas/internal/ipc/server/ServerManager$ReceiverHolder;)Ljava/util/List;

    move-result-object v16

    invoke-interface/range {v16 .. v16}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v10

    .local v10, "rs$iterator":Ljava/util/Iterator;
    :goto_4
    invoke-interface {v10}, Ljava/util/Iterator;->hasNext()Z

    move-result v16

    if-eqz v16, :cond_4

    invoke-interface {v10}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ltas/internal/ipc/server/RemoteSender;

    .line 1238
    .local v9, "rs":Ltas/internal/ipc/server/RemoteSender;
    const-string/jumbo v16, "      s:"

    move-object/from16 v0, v16

    invoke-virtual {v11, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v16

    move-object/from16 v0, v16

    invoke-virtual {v0, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v16

    const-string/jumbo v17, "\n"

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_4

    .line 1241
    .end local v5    # "rh":Ltas/internal/ipc/server/ServerManager$ReceiverHolder;
    .end local v9    # "rs":Ltas/internal/ipc/server/RemoteSender;
    .end local v10    # "rs$iterator":Ljava/util/Iterator;
    .end local v15    # "watch$iterator":Ljava/util/Iterator;
    :cond_6
    const-string/jumbo v16, "  }\n"

    move-object/from16 v0, v16

    invoke-virtual {v11, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1242
    const-string/jumbo v16, "}\n"

    move-object/from16 v0, v16

    invoke-virtual {v11, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto/16 :goto_0

    .line 1244
    .end local v1    # "c":Ltas/internal/ipc/server/ServerManager$ClientHandler;
    .end local v2    # "client":Ltas/internal/ipc/server/ServerManager$ClientHolder;
    .end local v6    # "rh$iterator":Ljava/util/Iterator;
    .end local v13    # "sh$iterator":Ljava/util/Iterator;
    :cond_7
    const-string/jumbo v16, "******************************\n"

    move-object/from16 v0, v16

    invoke-virtual {v11, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1245
    const-string/jumbo v16, "TasIPC<ServerManager>"

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v17

    invoke-static/range {v16 .. v17}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 1194
    return-void
.end method

.method dumpAsync()V
    .locals 2

    .prologue
    .line 1189
    new-instance v0, Ltas/internal/ipc/server/ServerManager$1;

    const-string/jumbo v1, "TasIPC<ServerManager>.dumpAsync"

    invoke-direct {v0, p0, v1}, Ltas/internal/ipc/server/ServerManager$1;-><init>(Ltas/internal/ipc/server/ServerManager;Ljava/lang/String;)V

    invoke-virtual {v0}, Ltas/internal/ipc/server/ServerManager$1;->start()V

    .line 1188
    return-void
.end method

.method registerReceiver(ILtas/internal/ipc/server/RemoteReceiver;)V
    .locals 1
    .param p1, "pid"    # I
    .param p2, "receiver"    # Ltas/internal/ipc/server/RemoteReceiver;

    .prologue
    .line 61
    const/4 v0, 0x0

    invoke-direct {p0, p1, v0, p2}, Ltas/internal/ipc/server/ServerManager;->schedule(IILtas/internal/ipc/server/RemoteReceiver;)V

    .line 60
    return-void
.end method

.method registerSender(ILtas/internal/ipc/server/RemoteSender;)V
    .locals 1
    .param p1, "pid"    # I
    .param p2, "sender"    # Ltas/internal/ipc/server/RemoteSender;

    .prologue
    .line 73
    const/4 v0, 0x3

    invoke-direct {p0, p1, v0, p2}, Ltas/internal/ipc/server/ServerManager;->schedule(IILtas/internal/ipc/server/RemoteSender;)V

    .line 72
    return-void
.end method

.method setCallback(ILtas/internal/ipc/server/IServerCallback;)V
    .locals 0
    .param p1, "pid"    # I
    .param p2, "cb"    # Ltas/internal/ipc/server/IServerCallback;

    .prologue
    .line 117
    invoke-direct {p0, p1, p2}, Ltas/internal/ipc/server/ServerManager;->schedule(ILtas/internal/ipc/server/IServerCallback;)V

    .line 116
    return-void
.end method

.method transmit(Ltas/internal/ipc/server/RemoteMessage;)V
    .locals 1
    .param p1, "rmsg"    # Ltas/internal/ipc/server/RemoteMessage;

    .prologue
    .line 121
    iget-object v0, p1, Ltas/internal/ipc/server/RemoteMessage;->receiver:Ltas/internal/ipc/server/RemoteReceiver;

    invoke-virtual {v0}, Ltas/internal/ipc/server/RemoteReceiver;->getpid()I

    move-result v0

    invoke-direct {p0, v0, p1}, Ltas/internal/ipc/server/ServerManager;->schedule(ILtas/internal/ipc/server/RemoteMessage;)V

    .line 120
    return-void
.end method

.method unregisterReceiver(ILtas/internal/ipc/server/RemoteReceiver;)V
    .locals 1
    .param p1, "pid"    # I
    .param p2, "receiver"    # Ltas/internal/ipc/server/RemoteReceiver;

    .prologue
    .line 65
    const/4 v0, 0x1

    invoke-direct {p0, p1, v0, p2}, Ltas/internal/ipc/server/ServerManager;->schedule(IILtas/internal/ipc/server/RemoteReceiver;)V

    .line 64
    return-void
.end method

.method unregisterSender(ILtas/internal/ipc/server/RemoteSender;)V
    .locals 1
    .param p1, "pid"    # I
    .param p2, "sender"    # Ltas/internal/ipc/server/RemoteSender;

    .prologue
    .line 77
    const/4 v0, 0x4

    invoke-direct {p0, p1, v0, p2}, Ltas/internal/ipc/server/ServerManager;->schedule(IILtas/internal/ipc/server/RemoteSender;)V

    .line 76
    return-void
.end method

.method unwatchAnonymousReceiver(ILtas/internal/ipc/server/RemoteSender;)V
    .locals 1
    .param p1, "pid"    # I
    .param p2, "sender"    # Ltas/internal/ipc/server/RemoteSender;

    .prologue
    .line 105
    const/16 v0, 0x9

    invoke-direct {p0, p1, v0, p2}, Ltas/internal/ipc/server/ServerManager;->schedule(IILtas/internal/ipc/server/RemoteSender;)V

    .line 104
    return-void
.end method

.method unwatchAnonymousSender(ILtas/internal/ipc/server/RemoteReceiver;)V
    .locals 1
    .param p1, "pid"    # I
    .param p2, "receiver"    # Ltas/internal/ipc/server/RemoteReceiver;

    .prologue
    .line 113
    const/16 v0, 0xd

    invoke-direct {p0, p1, v0, p2}, Ltas/internal/ipc/server/ServerManager;->schedule(IILtas/internal/ipc/server/RemoteReceiver;)V

    .line 112
    return-void
.end method

.method unwatchReceiver(ILtas/internal/ipc/server/RemoteSender;)V
    .locals 1
    .param p1, "pid"    # I
    .param p2, "sender"    # Ltas/internal/ipc/server/RemoteSender;

    .prologue
    .line 89
    const/4 v0, 0x7

    invoke-direct {p0, p1, v0, p2}, Ltas/internal/ipc/server/ServerManager;->schedule(IILtas/internal/ipc/server/RemoteSender;)V

    .line 88
    return-void
.end method

.method unwatchSender(ILtas/internal/ipc/server/RemoteReceiver;)V
    .locals 1
    .param p1, "pid"    # I
    .param p2, "receiver"    # Ltas/internal/ipc/server/RemoteReceiver;

    .prologue
    .line 97
    const/16 v0, 0xb

    invoke-direct {p0, p1, v0, p2}, Ltas/internal/ipc/server/ServerManager;->schedule(IILtas/internal/ipc/server/RemoteReceiver;)V

    .line 96
    return-void
.end method

.method updateReceiver(ILtas/internal/ipc/server/RemoteReceiver;)V
    .locals 1
    .param p1, "pid"    # I
    .param p2, "receiver"    # Ltas/internal/ipc/server/RemoteReceiver;

    .prologue
    .line 69
    const/4 v0, 0x2

    invoke-direct {p0, p1, v0, p2}, Ltas/internal/ipc/server/ServerManager;->schedule(IILtas/internal/ipc/server/RemoteReceiver;)V

    .line 68
    return-void
.end method

.method updateSender(ILtas/internal/ipc/server/RemoteSender;)V
    .locals 1
    .param p1, "pid"    # I
    .param p2, "sender"    # Ltas/internal/ipc/server/RemoteSender;

    .prologue
    .line 81
    const/4 v0, 0x5

    invoke-direct {p0, p1, v0, p2}, Ltas/internal/ipc/server/ServerManager;->schedule(IILtas/internal/ipc/server/RemoteSender;)V

    .line 80
    return-void
.end method

.method watchAnonymousReceiver(ILtas/internal/ipc/server/RemoteSender;)V
    .locals 1
    .param p1, "pid"    # I
    .param p2, "sender"    # Ltas/internal/ipc/server/RemoteSender;

    .prologue
    .line 101
    const/16 v0, 0x8

    invoke-direct {p0, p1, v0, p2}, Ltas/internal/ipc/server/ServerManager;->schedule(IILtas/internal/ipc/server/RemoteSender;)V

    .line 100
    return-void
.end method

.method watchAnonymousSender(ILtas/internal/ipc/server/RemoteReceiver;)V
    .locals 1
    .param p1, "pid"    # I
    .param p2, "receiver"    # Ltas/internal/ipc/server/RemoteReceiver;

    .prologue
    .line 109
    const/16 v0, 0xc

    invoke-direct {p0, p1, v0, p2}, Ltas/internal/ipc/server/ServerManager;->schedule(IILtas/internal/ipc/server/RemoteReceiver;)V

    .line 108
    return-void
.end method

.method watchReceiver(ILtas/internal/ipc/server/RemoteSender;)V
    .locals 1
    .param p1, "pid"    # I
    .param p2, "sender"    # Ltas/internal/ipc/server/RemoteSender;

    .prologue
    .line 85
    const/4 v0, 0x6

    invoke-direct {p0, p1, v0, p2}, Ltas/internal/ipc/server/ServerManager;->schedule(IILtas/internal/ipc/server/RemoteSender;)V

    .line 84
    return-void
.end method

.method watchSender(ILtas/internal/ipc/server/RemoteReceiver;)V
    .locals 1
    .param p1, "pid"    # I
    .param p2, "receiver"    # Ltas/internal/ipc/server/RemoteReceiver;

    .prologue
    .line 93
    const/16 v0, 0xa

    invoke-direct {p0, p1, v0, p2}, Ltas/internal/ipc/server/ServerManager;->schedule(IILtas/internal/ipc/server/RemoteReceiver;)V

    .line 92
    return-void
.end method
