.class Lcom/thinkware/sundo/ieve/IEVE$3;
.super Ljava/lang/Object;
.source "IEVE.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/thinkware/sundo/ieve/IEVE;->setStreamDataInfo(ZII)Z
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/thinkware/sundo/ieve/IEVE;


# direct methods
.method constructor <init>(Lcom/thinkware/sundo/ieve/IEVE;)V
    .locals 0

    .prologue
    .line 1
    iput-object p1, p0, Lcom/thinkware/sundo/ieve/IEVE$3;->a:Lcom/thinkware/sundo/ieve/IEVE;

    .line 2620
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 5

    .prologue
    .line 2623
    :goto_0
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE$3;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v1}, Lcom/thinkware/sundo/ieve/IEVE;->d(Lcom/thinkware/sundo/ieve/IEVE;)Lcom/thinkware/sundo/ieve/ieveCameraView;

    move-result-object v1

    invoke-virtual {v1}, Lcom/thinkware/sundo/ieve/ieveCameraView;->isTakingStream()Z

    move-result v1

    if-nez v1, :cond_0

    .line 2630
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE$3;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v1}, Lcom/thinkware/sundo/ieve/IEVE;->d(Lcom/thinkware/sundo/ieve/IEVE;)Lcom/thinkware/sundo/ieve/ieveCameraView;

    move-result-object v1

    iget-object v2, p0, Lcom/thinkware/sundo/ieve/IEVE$3;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v2}, Lcom/thinkware/sundo/ieve/IEVE;->G(Lcom/thinkware/sundo/ieve/IEVE;)Z

    move-result v2

    iget-object v3, p0, Lcom/thinkware/sundo/ieve/IEVE$3;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v3}, Lcom/thinkware/sundo/ieve/IEVE;->H(Lcom/thinkware/sundo/ieve/IEVE;)I

    move-result v3

    iget-object v4, p0, Lcom/thinkware/sundo/ieve/IEVE$3;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v4}, Lcom/thinkware/sundo/ieve/IEVE;->I(Lcom/thinkware/sundo/ieve/IEVE;)I

    move-result v4

    invoke-virtual {v1, v2, v3, v4}, Lcom/thinkware/sundo/ieve/ieveCameraView;->setSupportSaveStream(ZII)V

    .line 2631
    return-void

    .line 2625
    :cond_0
    const-wide/16 v2, 0x1

    :try_start_0
    invoke-static {v2, v3}, Ljava/lang/Thread;->sleep(J)V
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    .line 2626
    :catch_0
    move-exception v0

    .line 2627
    .local v0, "e":Ljava/lang/InterruptedException;
    invoke-virtual {v0}, Ljava/lang/InterruptedException;->printStackTrace()V

    goto :goto_0
.end method
