.class Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR$12;
.super Ljava/lang/Object;
.source "DestArriveGuideAR.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;->changemode(Z)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;

.field final synthetic val$bOBD2:Z


# direct methods
.method constructor <init>(Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;Z)V
    .locals 0

    .prologue
    .line 1367
    iput-object p1, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR$12;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;

    iput-boolean p2, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR$12;->val$bOBD2:Z

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 7

    .prologue
    const/16 v6, 0x131

    const/4 v5, 0x1

    const/16 v4, 0x8

    const/4 v3, 0x0

    .line 1372
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR$12;->val$bOBD2:Z

    if-ne v0, v5, :cond_1

    .line 1373
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR$12;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;

    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR$12;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;

    invoke-static {v1}, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;->access$500(Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;)Landroid/content/res/Resources;

    move-result-object v1

    const v2, 0x7f02000f

    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 1374
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR$12;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;->DestInfoTitle:Landroid/widget/TextView;

    if-eqz v0, :cond_0

    .line 1375
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR$12;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;->DestInfoTitle:Landroid/widget/TextView;

    const-string v1, "ECO \uc815\ubcf4"

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1377
    :cond_0
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR$12;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;->DestInfoDetail:Landroid/widget/Button;

    invoke-virtual {v0, v4}, Landroid/widget/Button;->setVisibility(I)V

    .line 1378
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR$12;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;->DestInfoAround:Landroid/widget/Button;

    invoke-virtual {v0, v4}, Landroid/widget/Button;->setVisibility(I)V

    .line 1379
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR$12;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;->DestInfoRoadview:Landroid/widget/Button;

    invoke-virtual {v0, v4}, Landroid/widget/Button;->setVisibility(I)V

    .line 1380
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR$12;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;->DestInfoFivepin:Landroid/widget/Button;

    invoke-virtual {v0, v4}, Landroid/widget/Button;->setVisibility(I)V

    .line 1381
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->getInstance()Lcom/thinkware/sundo/inavi3d/InaviConfig;

    move-result-object v0

    invoke-virtual {v0, v6, v5}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->CNaviConfigSet(II)Z

    .line 1394
    :goto_0
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->getInstance()Lcom/thinkware/sundo/inavi3d/InaviConfig;

    move-result-object v0

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->SetConfigSave()Z

    .line 1396
    return-void

    .line 1384
    :cond_1
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR$12;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;

    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR$12;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;

    invoke-static {v1}, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;->access$500(Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;)Landroid/content/res/Resources;

    move-result-object v1

    const v2, 0x7f02000e

    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 1385
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR$12;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;->DestInfoTitle:Landroid/widget/TextView;

    if-eqz v0, :cond_2

    .line 1386
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR$12;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;->DestInfoTitle:Landroid/widget/TextView;

    const-string v1, "\ubaa9\uc801\uc9c0 \ub3c4\ucc29\uc548\ub0b4"

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1388
    :cond_2
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR$12;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;->DestInfoDetail:Landroid/widget/Button;

    invoke-virtual {v0, v3}, Landroid/widget/Button;->setVisibility(I)V

    .line 1389
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR$12;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;->DestInfoAround:Landroid/widget/Button;

    invoke-virtual {v0, v3}, Landroid/widget/Button;->setVisibility(I)V

    .line 1390
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR$12;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;->DestInfoRoadview:Landroid/widget/Button;

    invoke-virtual {v0, v3}, Landroid/widget/Button;->setVisibility(I)V

    .line 1391
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR$12;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;->DestInfoFivepin:Landroid/widget/Button;

    invoke-virtual {v0, v3}, Landroid/widget/Button;->setVisibility(I)V

    .line 1392
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->getInstance()Lcom/thinkware/sundo/inavi3d/InaviConfig;

    move-result-object v0

    invoke-virtual {v0, v6, v3}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->CNaviConfigSet(II)Z

    goto :goto_0
.end method
