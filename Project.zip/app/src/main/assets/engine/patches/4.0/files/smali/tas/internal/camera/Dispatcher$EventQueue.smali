.class Ltas/internal/camera/Dispatcher$EventQueue;
.super Ltas/internal/camera/QueueBase;
.source "Dispatcher.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltas/internal/camera/Dispatcher;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "EventQueue"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ltas/internal/camera/QueueBase",
        "<",
        "Ltas/internal/camera/server/RemoteMessage;",
        ">;"
    }
.end annotation


# instance fields
.field private mM:Ltas/internal/camera/Dispatcher;


# direct methods
.method private constructor <init>(Ltas/internal/camera/Dispatcher;)V
    .locals 0
    .param p1, "m"    # Ltas/internal/camera/Dispatcher;

    .prologue
    .line 267
    invoke-direct {p0}, Ltas/internal/camera/QueueBase;-><init>()V

    .line 268
    iput-object p1, p0, Ltas/internal/camera/Dispatcher$EventQueue;->mM:Ltas/internal/camera/Dispatcher;

    .line 267
    return-void
.end method

.method synthetic constructor <init>(Ltas/internal/camera/Dispatcher;Ltas/internal/camera/Dispatcher$EventQueue;)V
    .locals 0
    .param p1, "m"    # Ltas/internal/camera/Dispatcher;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/camera/Dispatcher$EventQueue;-><init>(Ltas/internal/camera/Dispatcher;)V

    return-void
.end method

.method private ensureBooleanValue(Ltas/internal/camera/server/RemoteMessage;)Ltas/internal/camera/server/RemoteMessage;
    .locals 5
    .param p1, "curr"    # Ltas/internal/camera/server/RemoteMessage;

    .prologue
    const/4 v4, 0x0

    .line 272
    invoke-virtual {p0}, Ltas/internal/camera/Dispatcher$EventQueue;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_0

    .line 273
    return-object v4

    .line 275
    :cond_0
    invoke-virtual {p0}, Ltas/internal/camera/Dispatcher$EventQueue;->iterator()Ljava/util/Iterator;

    move-result-object v0

    .line 276
    .local v0, "iter":Ljava/util/Iterator;, "Ljava/util/Iterator<Ltas/internal/camera/server/RemoteMessage;>;"
    :cond_1
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_2

    .line 277
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ltas/internal/camera/server/RemoteMessage;

    .line 278
    .local v1, "tmp":Ltas/internal/camera/server/RemoteMessage;
    iget-object v2, v1, Ltas/internal/camera/server/RemoteMessage;->params:Ltas/internal/camera/InputParams;

    iget-object v2, v2, Ltas/internal/camera/InputParams;->cam:Ljava/lang/String;

    if-eqz v2, :cond_1

    iget-object v2, p1, Ltas/internal/camera/server/RemoteMessage;->params:Ltas/internal/camera/InputParams;

    iget-object v2, v2, Ltas/internal/camera/InputParams;->cam:Ljava/lang/String;

    if-eqz v2, :cond_1

    .line 279
    iget-object v2, v1, Ltas/internal/camera/server/RemoteMessage;->params:Ltas/internal/camera/InputParams;

    iget-object v2, v2, Ltas/internal/camera/InputParams;->cam:Ljava/lang/String;

    iget-object v3, p1, Ltas/internal/camera/server/RemoteMessage;->params:Ltas/internal/camera/InputParams;

    iget-object v3, v3, Ltas/internal/camera/InputParams;->cam:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/String;->compareTo(Ljava/lang/String;)I

    move-result v2

    if-nez v2, :cond_1

    .line 280
    iget-object v2, v1, Ltas/internal/camera/server/RemoteMessage;->params:Ltas/internal/camera/InputParams;

    iget v2, v2, Ltas/internal/camera/InputParams;->what:I

    iget-object v3, p1, Ltas/internal/camera/server/RemoteMessage;->params:Ltas/internal/camera/InputParams;

    iget v3, v3, Ltas/internal/camera/InputParams;->what:I

    if-ne v2, v3, :cond_1

    .line 281
    invoke-interface {v0}, Ljava/util/Iterator;->remove()V

    .line 282
    return-object v1

    .line 285
    .end local v1    # "tmp":Ltas/internal/camera/server/RemoteMessage;
    :cond_2
    return-object v4
.end method


# virtual methods
.method public bridge synthetic onAvailable(Ljava/lang/Object;)Z
    .locals 1
    .param p1, "msg"    # Ljava/lang/Object;

    .prologue
    .line 334
    check-cast p1, Ltas/internal/camera/server/RemoteMessage;

    .end local p1    # "msg":Ljava/lang/Object;
    invoke-virtual {p0, p1}, Ltas/internal/camera/Dispatcher$EventQueue;->onAvailable(Ltas/internal/camera/server/RemoteMessage;)Z

    move-result v0

    return v0
.end method

.method public onAvailable(Ltas/internal/camera/server/RemoteMessage;)Z
    .locals 4
    .param p1, "msg"    # Ltas/internal/camera/server/RemoteMessage;

    .prologue
    .line 335
    iget-object v1, p0, Ltas/internal/camera/Dispatcher$EventQueue;->mM:Ltas/internal/camera/Dispatcher;

    invoke-static {v1, p1}, Ltas/internal/camera/Dispatcher;->-wrap6(Ltas/internal/camera/Dispatcher;Ltas/internal/camera/server/RemoteMessage;)Z

    move-result v0

    .line 336
    .local v0, "r":Z
    if-nez v0, :cond_0

    .line 338
    iget-object v1, p0, Ltas/internal/camera/Dispatcher$EventQueue;->TAG:Ljava/lang/String;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "dropped - post err - "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 340
    invoke-virtual {p1}, Ltas/internal/camera/server/RemoteMessage;->recycle()V

    .line 342
    :cond_0
    return v0
.end method

.method public bridge synthetic onDequeue()Ljava/lang/Object;
    .locals 1

    .prologue
    .line 288
    invoke-virtual {p0}, Ltas/internal/camera/Dispatcher$EventQueue;->onDequeue()Ltas/internal/camera/server/RemoteMessage;

    move-result-object v0

    return-object v0
.end method

.method public onDequeue()Ltas/internal/camera/server/RemoteMessage;
    .locals 6

    .prologue
    .line 289
    invoke-virtual {p0}, Ltas/internal/camera/Dispatcher$EventQueue;->pollHead()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/camera/server/RemoteMessage;

    .line 290
    .local v0, "curr":Ltas/internal/camera/server/RemoteMessage;
    const/4 v1, 0x0

    .line 291
    .local v1, "dup":Ltas/internal/camera/server/RemoteMessage;
    const/4 v2, 0x0

    .line 292
    .local v2, "ready":Z
    iget-object v3, v0, Ltas/internal/camera/server/RemoteMessage;->params:Ltas/internal/camera/InputParams;

    iget v3, v3, Ltas/internal/camera/InputParams;->what:I

    packed-switch v3, :pswitch_data_0

    .line 315
    iget-object v3, p0, Ltas/internal/camera/Dispatcher$EventQueue;->mM:Ltas/internal/camera/Dispatcher;

    invoke-static {v3, v0}, Ltas/internal/camera/Dispatcher;->-wrap3(Ltas/internal/camera/Dispatcher;Ltas/internal/camera/server/RemoteMessage;)Z

    move-result v2

    .line 319
    .end local v1    # "dup":Ltas/internal/camera/server/RemoteMessage;
    .end local v2    # "ready":Z
    :goto_0
    if-nez v2, :cond_0

    .line 320
    iget-object v3, p0, Ltas/internal/camera/Dispatcher$EventQueue;->TAG:Ljava/lang/String;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v5, "dropped - "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v3, v4}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 321
    invoke-virtual {v0}, Ltas/internal/camera/server/RemoteMessage;->recycle()V

    .line 322
    const/4 v0, 0x0

    .line 324
    .local v0, "curr":Ltas/internal/camera/server/RemoteMessage;
    if-eqz v1, :cond_0

    .line 325
    iget-object v3, p0, Ltas/internal/camera/Dispatcher$EventQueue;->TAG:Ljava/lang/String;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v5, "dropped - dup - "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v3, v4}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 326
    invoke-virtual {v1}, Ltas/internal/camera/server/RemoteMessage;->recycle()V

    .line 327
    const/4 v1, 0x0

    .line 331
    .end local v0    # "curr":Ltas/internal/camera/server/RemoteMessage;
    :cond_0
    return-object v0

    .line 294
    .local v0, "curr":Ltas/internal/camera/server/RemoteMessage;
    .restart local v1    # "dup":Ltas/internal/camera/server/RemoteMessage;
    .restart local v2    # "ready":Z
    :pswitch_0
    invoke-direct {p0, v0}, Ltas/internal/camera/Dispatcher$EventQueue;->ensureBooleanValue(Ltas/internal/camera/server/RemoteMessage;)Ltas/internal/camera/server/RemoteMessage;

    move-result-object v1

    .line 295
    .local v1, "dup":Ltas/internal/camera/server/RemoteMessage;
    if-nez v1, :cond_1

    iget-object v3, p0, Ltas/internal/camera/Dispatcher$EventQueue;->mM:Ltas/internal/camera/Dispatcher;

    invoke-static {v3, v0}, Ltas/internal/camera/Dispatcher;->-wrap0(Ltas/internal/camera/Dispatcher;Ltas/internal/camera/server/RemoteMessage;)Z

    move-result v2

    .local v2, "ready":Z
    goto :goto_0

    .local v2, "ready":Z
    :cond_1
    const/4 v2, 0x0

    goto :goto_0

    .line 299
    .local v1, "dup":Ltas/internal/camera/server/RemoteMessage;
    :pswitch_1
    iget-object v3, p0, Ltas/internal/camera/Dispatcher$EventQueue;->mM:Ltas/internal/camera/Dispatcher;

    invoke-static {v3, v0}, Ltas/internal/camera/Dispatcher;->-wrap2(Ltas/internal/camera/Dispatcher;Ltas/internal/camera/server/RemoteMessage;)Z

    move-result v2

    .local v2, "ready":Z
    goto :goto_0

    .line 303
    .local v2, "ready":Z
    :pswitch_2
    iget-object v3, p0, Ltas/internal/camera/Dispatcher$EventQueue;->mM:Ltas/internal/camera/Dispatcher;

    invoke-static {v3, v0}, Ltas/internal/camera/Dispatcher;->-wrap1(Ltas/internal/camera/Dispatcher;Ltas/internal/camera/server/RemoteMessage;)Z

    move-result v2

    .local v2, "ready":Z
    goto :goto_0

    .line 307
    .local v2, "ready":Z
    :pswitch_3
    iget-object v3, p0, Ltas/internal/camera/Dispatcher$EventQueue;->mM:Ltas/internal/camera/Dispatcher;

    invoke-static {v3, v0}, Ltas/internal/camera/Dispatcher;->-wrap4(Ltas/internal/camera/Dispatcher;Ltas/internal/camera/server/RemoteMessage;)Z

    move-result v2

    .local v2, "ready":Z
    goto :goto_0

    .line 311
    .local v2, "ready":Z
    :pswitch_4
    iget-object v3, p0, Ltas/internal/camera/Dispatcher$EventQueue;->mM:Ltas/internal/camera/Dispatcher;

    invoke-static {v3, v0}, Ltas/internal/camera/Dispatcher;->-wrap5(Ltas/internal/camera/Dispatcher;Ltas/internal/camera/server/RemoteMessage;)Z

    move-result v2

    .local v2, "ready":Z
    goto :goto_0

    .line 292
    nop

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_0
        :pswitch_1
        :pswitch_2
        :pswitch_3
        :pswitch_4
    .end packed-switch
.end method
