.class Ltas/util/backlight/KBacklight$1;
.super Landroid/os/UEventObserver;
.source "KBacklight.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ltas/util/backlight/KBacklight;-><init>()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Ltas/util/backlight/KBacklight;


# direct methods
.method constructor <init>(Ltas/util/backlight/KBacklight;)V
    .locals 0
    .param p1, "this$0"    # Ltas/util/backlight/KBacklight;

    .prologue
    .line 167
    iput-object p1, p0, Ltas/util/backlight/KBacklight$1;->this$0:Ltas/util/backlight/KBacklight;

    invoke-direct {p0}, Landroid/os/UEventObserver;-><init>()V

    return-void
.end method


# virtual methods
.method public onUEvent(Landroid/os/UEventObserver$UEvent;)V
    .locals 1
    .param p1, "event"    # Landroid/os/UEventObserver$UEvent;

    .prologue
    .line 169
    iget-object v0, p0, Ltas/util/backlight/KBacklight$1;->this$0:Ltas/util/backlight/KBacklight;

    invoke-static {v0, p1}, Ltas/util/backlight/KBacklight;->-wrap1(Ltas/util/backlight/KBacklight;Landroid/os/UEventObserver$UEvent;)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 170
    return-void

    .line 173
    :cond_0
    iget-object v0, p0, Ltas/util/backlight/KBacklight$1;->this$0:Ltas/util/backlight/KBacklight;

    invoke-static {v0, p1}, Ltas/util/backlight/KBacklight;->-wrap0(Ltas/util/backlight/KBacklight;Landroid/os/UEventObserver$UEvent;)Z

    move-result v0

    if-eqz v0, :cond_1

    .line 174
    return-void

    .line 168
    :cond_1
    return-void
.end method
