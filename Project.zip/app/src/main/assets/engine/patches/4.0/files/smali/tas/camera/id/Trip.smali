.class public Ltas/camera/id/Trip;
.super Ltas/camera/CameraId;
.source "Trip.java"


# static fields
.field public static final SET_VERSION_COMPUTER:I = 0x7d1

.field public static final SET_VERSION_PROGRAM:I = 0x7d2


# instance fields
.field private final proxy:Ltas/internal/camera/client/CameraProxy;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ltas/internal/camera/client/CameraProxy",
            "<",
            "Ltas/camera/id/Trip;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 1
    .param p1, "context"    # Landroid/content/Context;

    .prologue
    .line 24
    invoke-direct {p0}, Ltas/camera/CameraId;-><init>()V

    .line 25
    new-instance v0, Ltas/internal/camera/client/CameraProxy;

    invoke-direct {v0, p1, p0}, Ltas/internal/camera/client/CameraProxy;-><init>(Landroid/content/Context;Ltas/camera/CameraId;)V

    iput-object v0, p0, Ltas/camera/id/Trip;->proxy:Ltas/internal/camera/client/CameraProxy;

    .line 24
    return-void
.end method


# virtual methods
.method protected proxy()Ltas/internal/camera/client/CameraProxy;
    .locals 1

    .prologue
    .line 29
    iget-object v0, p0, Ltas/camera/id/Trip;->proxy:Ltas/internal/camera/client/CameraProxy;

    return-object v0
.end method

.method public setListener(Ltas/camera/BaseListener;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ltas/camera/BaseListener",
            "<",
            "Ltas/camera/id/Trip;",
            ">;)V"
        }
    .end annotation

    .prologue
    .line 33
    .local p1, "l":Ltas/camera/BaseListener;, "Ltas/camera/BaseListener<Ltas/camera/id/Trip;>;"
    iget-object v0, p0, Ltas/camera/id/Trip;->proxy:Ltas/internal/camera/client/CameraProxy;

    invoke-virtual {v0, p1}, Ltas/internal/camera/client/CameraProxy;->setListener(Ltas/camera/BaseListener;)V

    .line 32
    return-void
.end method
