.class public Ltas/ipc/TransceiverSession$SimpleCallback;
.super Ljava/lang/Object;
.source "TransceiverSession.java"

# interfaces
.implements Ltas/ipc/TransceiverSession$Callback;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltas/ipc/TransceiverSession;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "SimpleCallback"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    .prologue
    .line 227
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onReceive(Ltas/ipc/TransceiverSession;ILtas/ipc/MsgData;)V
    .locals 0
    .param p1, "session"    # Ltas/ipc/TransceiverSession;
    .param p2, "what"    # I
    .param p3, "msg"    # Ltas/ipc/MsgData;

    .prologue
    .line 240
    return-void
.end method

.method public onReceiverOffline(Ltas/ipc/TransceiverSession;)V
    .locals 0
    .param p1, "session"    # Ltas/ipc/TransceiverSession;

    .prologue
    .line 246
    return-void
.end method

.method public onReceiverOnline(Ltas/ipc/TransceiverSession;)V
    .locals 0
    .param p1, "session"    # Ltas/ipc/TransceiverSession;

    .prologue
    .line 243
    return-void
.end method

.method public onReceiverUpdate(Ltas/ipc/TransceiverSession;Landroid/os/Bundle;)V
    .locals 0
    .param p1, "session"    # Ltas/ipc/TransceiverSession;
    .param p2, "extra"    # Landroid/os/Bundle;

    .prologue
    .line 250
    return-void
.end method

.method public onReply(Ltas/ipc/TransceiverSession;ILtas/ipc/MsgData;)V
    .locals 0
    .param p1, "session"    # Ltas/ipc/TransceiverSession;
    .param p2, "what"    # I
    .param p3, "msg"    # Ltas/ipc/MsgData;

    .prologue
    .line 254
    return-void
.end method

.method public onSenderOffline(Ltas/ipc/TransceiverSession;)V
    .locals 0
    .param p1, "session"    # Ltas/ipc/TransceiverSession;

    .prologue
    .line 232
    return-void
.end method

.method public onSenderOnline(Ltas/ipc/TransceiverSession;)V
    .locals 0
    .param p1, "session"    # Ltas/ipc/TransceiverSession;

    .prologue
    .line 229
    return-void
.end method

.method public onSenderUpdate(Ltas/ipc/TransceiverSession;Landroid/os/Bundle;)V
    .locals 0
    .param p1, "session"    # Ltas/ipc/TransceiverSession;
    .param p2, "extra"    # Landroid/os/Bundle;

    .prologue
    .line 236
    return-void
.end method
