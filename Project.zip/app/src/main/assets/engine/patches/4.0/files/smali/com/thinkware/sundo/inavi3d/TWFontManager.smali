.class public Lcom/thinkware/sundo/inavi3d/TWFontManager;
.super Ljava/lang/Object;
.source "TWFontManager.java"


# static fields
.field public static final FONT_TYPE_COUNT:I = 0x8

.field public static final FONT_TYPE_RIX_B:I = 0x0

.field public static final FONT_TYPE_RIX_EB:I = 0x1

.field public static final FONT_TYPE_RIX_L:I = 0x2

.field public static final FONT_TYPE_RIX_M:I = 0x3

.field public static final FONT_TYPE_ROBOTO_BOLD:I = 0x4

.field public static final FONT_TYPE_ROBOTO_BOLDITALIC:I = 0x5

.field public static final FONT_TYPE_ROBOTO_ITALIC:I = 0x6

.field public static final FONT_TYPE_ROBOTO_REGULAR:I = 0x7

.field private static mInstance:Lcom/thinkware/sundo/inavi3d/TWFontManager;

.field static mRixGo_B:Landroid/graphics/Typeface;

.field static mRixGo_EB:Landroid/graphics/Typeface;

.field static mRixGo_L:Landroid/graphics/Typeface;

.field static mRixGo_M:Landroid/graphics/Typeface;

.field static mRobotoBold:Landroid/graphics/Typeface;

.field static mRobotoBoldItalic:Landroid/graphics/Typeface;

.field static mRobotoItalic:Landroid/graphics/Typeface;

.field static mRobotoRegular:Landroid/graphics/Typeface;


# instance fields
.field private mAsManager:Landroid/content/res/AssetManager;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .prologue
    const/4 v0, 0x0

    .line 15
    sput-object v0, Lcom/thinkware/sundo/inavi3d/TWFontManager;->mRixGo_B:Landroid/graphics/Typeface;

    .line 16
    sput-object v0, Lcom/thinkware/sundo/inavi3d/TWFontManager;->mRixGo_EB:Landroid/graphics/Typeface;

    .line 17
    sput-object v0, Lcom/thinkware/sundo/inavi3d/TWFontManager;->mRixGo_L:Landroid/graphics/Typeface;

    .line 18
    sput-object v0, Lcom/thinkware/sundo/inavi3d/TWFontManager;->mRixGo_M:Landroid/graphics/Typeface;

    .line 20
    sput-object v0, Lcom/thinkware/sundo/inavi3d/TWFontManager;->mRobotoBold:Landroid/graphics/Typeface;

    .line 21
    sput-object v0, Lcom/thinkware/sundo/inavi3d/TWFontManager;->mRobotoBoldItalic:Landroid/graphics/Typeface;

    .line 22
    sput-object v0, Lcom/thinkware/sundo/inavi3d/TWFontManager;->mRobotoItalic:Landroid/graphics/Typeface;

    .line 23
    sput-object v0, Lcom/thinkware/sundo/inavi3d/TWFontManager;->mRobotoRegular:Landroid/graphics/Typeface;

    return-void
.end method

.method public constructor <init>(Landroid/content/res/AssetManager;)V
    .locals 0
    .param p1, "asManager"    # Landroid/content/res/AssetManager;

    .prologue
    .line 37
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 38
    sput-object p0, Lcom/thinkware/sundo/inavi3d/TWFontManager;->mInstance:Lcom/thinkware/sundo/inavi3d/TWFontManager;

    .line 39
    iput-object p1, p0, Lcom/thinkware/sundo/inavi3d/TWFontManager;->mAsManager:Landroid/content/res/AssetManager;

    .line 40
    return-void
.end method

.method public static getFont(I)Landroid/graphics/Typeface;
    .locals 2
    .param p0, "Type"    # I

    .prologue
    .line 50
    packed-switch p0, :pswitch_data_0

    .line 100
    sget-object v0, Lcom/thinkware/sundo/inavi3d/TWFontManager;->mRobotoRegular:Landroid/graphics/Typeface;

    if-nez v0, :cond_0

    .line 101
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/TWFontManager;->getInstance()Lcom/thinkware/sundo/inavi3d/TWFontManager;

    move-result-object v0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/TWFontManager;->mAsManager:Landroid/content/res/AssetManager;

    const-string v1, "fonts/Roboto-Regular.ttf"

    invoke-static {v0, v1}, Landroid/graphics/Typeface;->createFromAsset(Landroid/content/res/AssetManager;Ljava/lang/String;)Landroid/graphics/Typeface;

    move-result-object v0

    sput-object v0, Lcom/thinkware/sundo/inavi3d/TWFontManager;->mRobotoRegular:Landroid/graphics/Typeface;

    .line 103
    :cond_0
    sget-object v0, Lcom/thinkware/sundo/inavi3d/TWFontManager;->mRobotoRegular:Landroid/graphics/Typeface;

    :goto_0
    return-object v0

    .line 52
    :pswitch_0
    sget-object v0, Lcom/thinkware/sundo/inavi3d/TWFontManager;->mRixGo_B:Landroid/graphics/Typeface;

    if-nez v0, :cond_1

    .line 53
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/TWFontManager;->getInstance()Lcom/thinkware/sundo/inavi3d/TWFontManager;

    move-result-object v0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/TWFontManager;->mAsManager:Landroid/content/res/AssetManager;

    const-string v1, "fonts/Inavi_RixGo_B.ttf"

    invoke-static {v0, v1}, Landroid/graphics/Typeface;->createFromAsset(Landroid/content/res/AssetManager;Ljava/lang/String;)Landroid/graphics/Typeface;

    move-result-object v0

    sput-object v0, Lcom/thinkware/sundo/inavi3d/TWFontManager;->mRixGo_B:Landroid/graphics/Typeface;

    .line 55
    :cond_1
    sget-object v0, Lcom/thinkware/sundo/inavi3d/TWFontManager;->mRixGo_B:Landroid/graphics/Typeface;

    goto :goto_0

    .line 58
    :pswitch_1
    sget-object v0, Lcom/thinkware/sundo/inavi3d/TWFontManager;->mRixGo_EB:Landroid/graphics/Typeface;

    if-nez v0, :cond_2

    .line 59
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/TWFontManager;->getInstance()Lcom/thinkware/sundo/inavi3d/TWFontManager;

    move-result-object v0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/TWFontManager;->mAsManager:Landroid/content/res/AssetManager;

    const-string v1, "fonts/Inavi_RixGo_EB.ttf"

    invoke-static {v0, v1}, Landroid/graphics/Typeface;->createFromAsset(Landroid/content/res/AssetManager;Ljava/lang/String;)Landroid/graphics/Typeface;

    move-result-object v0

    sput-object v0, Lcom/thinkware/sundo/inavi3d/TWFontManager;->mRixGo_EB:Landroid/graphics/Typeface;

    .line 61
    :cond_2
    sget-object v0, Lcom/thinkware/sundo/inavi3d/TWFontManager;->mRixGo_EB:Landroid/graphics/Typeface;

    goto :goto_0

    .line 64
    :pswitch_2
    sget-object v0, Lcom/thinkware/sundo/inavi3d/TWFontManager;->mRixGo_L:Landroid/graphics/Typeface;

    if-nez v0, :cond_3

    .line 65
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/TWFontManager;->getInstance()Lcom/thinkware/sundo/inavi3d/TWFontManager;

    move-result-object v0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/TWFontManager;->mAsManager:Landroid/content/res/AssetManager;

    const-string v1, "fonts/Inavi_RixGo_L.ttf"

    invoke-static {v0, v1}, Landroid/graphics/Typeface;->createFromAsset(Landroid/content/res/AssetManager;Ljava/lang/String;)Landroid/graphics/Typeface;

    move-result-object v0

    sput-object v0, Lcom/thinkware/sundo/inavi3d/TWFontManager;->mRixGo_L:Landroid/graphics/Typeface;

    .line 67
    :cond_3
    sget-object v0, Lcom/thinkware/sundo/inavi3d/TWFontManager;->mRixGo_L:Landroid/graphics/Typeface;

    goto :goto_0

    .line 70
    :pswitch_3
    sget-object v0, Lcom/thinkware/sundo/inavi3d/TWFontManager;->mRixGo_M:Landroid/graphics/Typeface;

    if-nez v0, :cond_4

    .line 71
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/TWFontManager;->getInstance()Lcom/thinkware/sundo/inavi3d/TWFontManager;

    move-result-object v0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/TWFontManager;->mAsManager:Landroid/content/res/AssetManager;

    const-string v1, "fonts/Inavi_RixGo_M.ttf"

    invoke-static {v0, v1}, Landroid/graphics/Typeface;->createFromAsset(Landroid/content/res/AssetManager;Ljava/lang/String;)Landroid/graphics/Typeface;

    move-result-object v0

    sput-object v0, Lcom/thinkware/sundo/inavi3d/TWFontManager;->mRixGo_M:Landroid/graphics/Typeface;

    .line 73
    :cond_4
    sget-object v0, Lcom/thinkware/sundo/inavi3d/TWFontManager;->mRixGo_M:Landroid/graphics/Typeface;

    goto :goto_0

    .line 76
    :pswitch_4
    sget-object v0, Lcom/thinkware/sundo/inavi3d/TWFontManager;->mRobotoBold:Landroid/graphics/Typeface;

    if-nez v0, :cond_5

    .line 77
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/TWFontManager;->getInstance()Lcom/thinkware/sundo/inavi3d/TWFontManager;

    move-result-object v0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/TWFontManager;->mAsManager:Landroid/content/res/AssetManager;

    const-string v1, "fonts/Roboto-Bold.ttf"

    invoke-static {v0, v1}, Landroid/graphics/Typeface;->createFromAsset(Landroid/content/res/AssetManager;Ljava/lang/String;)Landroid/graphics/Typeface;

    move-result-object v0

    sput-object v0, Lcom/thinkware/sundo/inavi3d/TWFontManager;->mRobotoBold:Landroid/graphics/Typeface;

    .line 79
    :cond_5
    sget-object v0, Lcom/thinkware/sundo/inavi3d/TWFontManager;->mRobotoBold:Landroid/graphics/Typeface;

    goto :goto_0

    .line 82
    :pswitch_5
    sget-object v0, Lcom/thinkware/sundo/inavi3d/TWFontManager;->mRobotoBoldItalic:Landroid/graphics/Typeface;

    if-nez v0, :cond_6

    .line 83
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/TWFontManager;->getInstance()Lcom/thinkware/sundo/inavi3d/TWFontManager;

    move-result-object v0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/TWFontManager;->mAsManager:Landroid/content/res/AssetManager;

    const-string v1, "fonts/Roboto-BoldItalic.ttf"

    invoke-static {v0, v1}, Landroid/graphics/Typeface;->createFromAsset(Landroid/content/res/AssetManager;Ljava/lang/String;)Landroid/graphics/Typeface;

    move-result-object v0

    sput-object v0, Lcom/thinkware/sundo/inavi3d/TWFontManager;->mRobotoBoldItalic:Landroid/graphics/Typeface;

    .line 85
    :cond_6
    sget-object v0, Lcom/thinkware/sundo/inavi3d/TWFontManager;->mRobotoBoldItalic:Landroid/graphics/Typeface;

    goto :goto_0

    .line 88
    :pswitch_6
    sget-object v0, Lcom/thinkware/sundo/inavi3d/TWFontManager;->mRobotoItalic:Landroid/graphics/Typeface;

    if-nez v0, :cond_7

    .line 89
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/TWFontManager;->getInstance()Lcom/thinkware/sundo/inavi3d/TWFontManager;

    move-result-object v0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/TWFontManager;->mAsManager:Landroid/content/res/AssetManager;

    const-string v1, "fonts/Roboto-Italic.ttf"

    invoke-static {v0, v1}, Landroid/graphics/Typeface;->createFromAsset(Landroid/content/res/AssetManager;Ljava/lang/String;)Landroid/graphics/Typeface;

    move-result-object v0

    sput-object v0, Lcom/thinkware/sundo/inavi3d/TWFontManager;->mRobotoItalic:Landroid/graphics/Typeface;

    .line 91
    :cond_7
    sget-object v0, Lcom/thinkware/sundo/inavi3d/TWFontManager;->mRobotoItalic:Landroid/graphics/Typeface;

    goto/16 :goto_0

    .line 94
    :pswitch_7
    sget-object v0, Lcom/thinkware/sundo/inavi3d/TWFontManager;->mRobotoRegular:Landroid/graphics/Typeface;

    if-nez v0, :cond_8

    .line 95
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/TWFontManager;->getInstance()Lcom/thinkware/sundo/inavi3d/TWFontManager;

    move-result-object v0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/TWFontManager;->mAsManager:Landroid/content/res/AssetManager;

    const-string v1, "fonts/Roboto-Regular.ttf"

    invoke-static {v0, v1}, Landroid/graphics/Typeface;->createFromAsset(Landroid/content/res/AssetManager;Ljava/lang/String;)Landroid/graphics/Typeface;

    move-result-object v0

    sput-object v0, Lcom/thinkware/sundo/inavi3d/TWFontManager;->mRobotoRegular:Landroid/graphics/Typeface;

    .line 97
    :cond_8
    sget-object v0, Lcom/thinkware/sundo/inavi3d/TWFontManager;->mRobotoRegular:Landroid/graphics/Typeface;

    goto/16 :goto_0

    .line 50
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
        :pswitch_1
        :pswitch_2
        :pswitch_3
        :pswitch_4
        :pswitch_5
        :pswitch_6
        :pswitch_7
    .end packed-switch
.end method

.method public static getInstance()Lcom/thinkware/sundo/inavi3d/TWFontManager;
    .locals 2

    .prologue
    .line 43
    sget-object v0, Lcom/thinkware/sundo/inavi3d/TWFontManager;->mInstance:Lcom/thinkware/sundo/inavi3d/TWFontManager;

    if-nez v0, :cond_1

    .line 44
    new-instance v0, Lcom/thinkware/sundo/inavi3d/TWFontManager;

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v1

    if-nez v1, :cond_0

    invoke-static {}, Landroid/app/AppGlobals;->getInitialApplication()Landroid/app/Application;

    move-result-object v1

    :cond_0
    invoke-virtual {v1}, Landroid/content/Context;->getAssets()Landroid/content/res/AssetManager;

    move-result-object v1

    invoke-direct {v0, v1}, Lcom/thinkware/sundo/inavi3d/TWFontManager;-><init>(Landroid/content/res/AssetManager;)V

    sput-object v0, Lcom/thinkware/sundo/inavi3d/TWFontManager;->mInstance:Lcom/thinkware/sundo/inavi3d/TWFontManager;

    .line 46
    :cond_1
    sget-object v0, Lcom/thinkware/sundo/inavi3d/TWFontManager;->mInstance:Lcom/thinkware/sundo/inavi3d/TWFontManager;

    return-object v0
.end method

.method public static setTypeFace(Landroid/view/View;I)V
    .locals 2
    .param p0, "view"    # Landroid/view/View;
    .param p1, "type"    # I

    .prologue
    .line 108
    invoke-static {p1}, Lcom/thinkware/sundo/inavi3d/TWFontManager;->getFont(I)Landroid/graphics/Typeface;

    move-result-object v0

    .line 109
    .local v0, "font":Landroid/graphics/Typeface;
    if-nez v0, :cond_1

    .line 122
    .end local p0    # "view":Landroid/view/View;
    :cond_0
    :goto_0
    return-void

    .line 113
    .restart local p0    # "view":Landroid/view/View;
    :cond_1
    if-eqz p0, :cond_0

    .line 114
    :try_start_0
    invoke-static {p0, v0}, Lcom/thinkware/sundo/inavi3d/TWFontManager;->setTypeFaceViewReferences(Landroid/view/View;Landroid/graphics/Typeface;)V

    .line 115
    instance-of v1, p0, Landroid/view/ViewGroup;

    if-eqz v1, :cond_0

    .line 116
    check-cast p0, Landroid/view/ViewGroup;

    .end local p0    # "view":Landroid/view/View;
    invoke-static {p0, v0}, Lcom/thinkware/sundo/inavi3d/TWFontManager;->setTypeFaceGroupReferences(Landroid/view/ViewGroup;Landroid/graphics/Typeface;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    .line 119
    :catch_0
    move-exception v1

    goto :goto_0
.end method

.method private static setTypeFaceGroupReferences(Landroid/view/ViewGroup;Landroid/graphics/Typeface;)V
    .locals 4
    .param p0, "viewGroup"    # Landroid/view/ViewGroup;
    .param p1, "font"    # Landroid/graphics/Typeface;

    .prologue
    .line 125
    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v1

    .line 126
    .local v1, "nrOfChildren":I
    const/4 v0, 0x0

    .local v0, "i":I
    :goto_0
    if-ge v0, v1, :cond_1

    .line 127
    invoke-virtual {p0, v0}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v2

    .line 128
    .local v2, "view":Landroid/view/View;
    invoke-static {v2, p1}, Lcom/thinkware/sundo/inavi3d/TWFontManager;->setTypeFaceViewReferences(Landroid/view/View;Landroid/graphics/Typeface;)V

    .line 129
    instance-of v3, v2, Landroid/view/ViewGroup;

    if-eqz v3, :cond_0

    .line 130
    check-cast v2, Landroid/view/ViewGroup;

    .end local v2    # "view":Landroid/view/View;
    invoke-static {v2, p1}, Lcom/thinkware/sundo/inavi3d/TWFontManager;->setTypeFaceGroupReferences(Landroid/view/ViewGroup;Landroid/graphics/Typeface;)V

    .line 126
    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    .line 133
    :cond_1
    return-void
.end method

.method private static setTypeFaceViewReferences(Landroid/view/View;Landroid/graphics/Typeface;)V
    .locals 1
    .param p0, "view"    # Landroid/view/View;
    .param p1, "font"    # Landroid/graphics/Typeface;

    .prologue
    .line 136
    instance-of v0, p0, Landroid/widget/TextView;

    if-eqz v0, :cond_0

    if-eqz p1, :cond_0

    .line 137
    check-cast p0, Landroid/widget/TextView;

    .end local p0    # "view":Landroid/view/View;
    invoke-virtual {p0, p1}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 138
    :cond_0
    return-void
.end method
