.class Ltas/internal/ipc/Dispatcher;
.super Landroid/os/Handler;
.source "Dispatcher.java"


# static fields
.field public static final MSG_CATEGORY_1:I = 0x64

.field public static final MSG_CATEGORY_1_END:I = 0xc7

.field public static final MSG_CATEGORY_2:I = 0xc8

.field public static final MSG_CATEGORY_2_END:I = 0x12b

.field public static final MSG_RECEIVE:I = 0xcc

.field public static final MSG_RECEIVER_OFF_LINE:I = 0x66

.field public static final MSG_RECEIVER_ON_LINE:I = 0x65

.field public static final MSG_RECEIVER_UPDATE:I = 0x67

.field public static final MSG_REPLY:I = 0x68

.field public static final MSG_SENDER_OFF_LINE:I = 0xca

.field public static final MSG_SENDER_ON_LINE:I = 0xc9

.field public static final MSG_SENDER_UPDATE:I = 0xcb


# instance fields
.field private mActivate:Z

.field private mR:Ljava/lang/ref/WeakReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference",
            "<",
            "Ltas/internal/ipc/Receiver;",
            ">;"
        }
    .end annotation
.end field

.field private mS:Ljava/lang/ref/WeakReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference",
            "<",
            "Ltas/internal/ipc/Sender;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Landroid/os/Looper;Ltas/internal/ipc/Receiver;)V
    .locals 1
    .param p1, "l"    # Landroid/os/Looper;
    .param p2, "r"    # Ltas/internal/ipc/Receiver;

    .prologue
    .line 39
    const/4 v0, 0x0

    invoke-direct {p0, p1, v0, p2}, Ltas/internal/ipc/Dispatcher;-><init>(Landroid/os/Looper;Ltas/internal/ipc/Sender;Ltas/internal/ipc/Receiver;)V

    return-void
.end method

.method constructor <init>(Landroid/os/Looper;Ltas/internal/ipc/Sender;)V
    .locals 1
    .param p1, "l"    # Landroid/os/Looper;
    .param p2, "s"    # Ltas/internal/ipc/Sender;

    .prologue
    .line 38
    const/4 v0, 0x0

    invoke-direct {p0, p1, p2, v0}, Ltas/internal/ipc/Dispatcher;-><init>(Landroid/os/Looper;Ltas/internal/ipc/Sender;Ltas/internal/ipc/Receiver;)V

    return-void
.end method

.method constructor <init>(Landroid/os/Looper;Ltas/internal/ipc/Sender;Ltas/internal/ipc/Receiver;)V
    .locals 1
    .param p1, "l"    # Landroid/os/Looper;
    .param p2, "s"    # Ltas/internal/ipc/Sender;
    .param p3, "r"    # Ltas/internal/ipc/Receiver;

    .prologue
    const/4 v0, 0x0

    .line 41
    if-eqz p1, :cond_2

    .end local p1    # "l":Landroid/os/Looper;
    :goto_0
    invoke-direct {p0, p1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 34
    iput-object v0, p0, Ltas/internal/ipc/Dispatcher;->mS:Ljava/lang/ref/WeakReference;

    .line 35
    iput-object v0, p0, Ltas/internal/ipc/Dispatcher;->mR:Ljava/lang/ref/WeakReference;

    .line 42
    if-eqz p2, :cond_0

    new-instance v0, Ljava/lang/ref/WeakReference;

    invoke-direct {v0, p2}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    iput-object v0, p0, Ltas/internal/ipc/Dispatcher;->mS:Ljava/lang/ref/WeakReference;

    .line 43
    :cond_0
    if-eqz p3, :cond_1

    new-instance v0, Ljava/lang/ref/WeakReference;

    invoke-direct {v0, p3}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    iput-object v0, p0, Ltas/internal/ipc/Dispatcher;->mR:Ljava/lang/ref/WeakReference;

    .line 40
    :cond_1
    return-void

    .line 41
    .restart local p1    # "l":Landroid/os/Looper;
    :cond_2
    invoke-static {}, Landroid/os/Looper;->myLooper()Landroid/os/Looper;

    move-result-object p1

    goto :goto_0
.end method


# virtual methods
.method activate()V
    .locals 1

    .prologue
    .line 46
    const/4 v0, 0x1

    iput-boolean v0, p0, Ltas/internal/ipc/Dispatcher;->mActivate:Z

    return-void
.end method

.method deactivate()V
    .locals 1

    .prologue
    .line 47
    const/4 v0, 0x0

    iput-boolean v0, p0, Ltas/internal/ipc/Dispatcher;->mActivate:Z

    return-void
.end method

.method dispatch(ILtas/ipc/ReceiverSession;)V
    .locals 1
    .param p1, "what"    # I
    .param p2, "rs"    # Ltas/ipc/ReceiverSession;

    .prologue
    const/4 v0, 0x0

    .line 54
    invoke-virtual {p0, p1, v0, v0, p2}, Ltas/internal/ipc/Dispatcher;->obtainMessage(IIILjava/lang/Object;)Landroid/os/Message;

    move-result-object v0

    invoke-virtual {p0, v0}, Ltas/internal/ipc/Dispatcher;->sendMessage(Landroid/os/Message;)Z

    .line 53
    return-void
.end method

.method dispatch(ILtas/ipc/SenderSession;)V
    .locals 1
    .param p1, "what"    # I
    .param p2, "ss"    # Ltas/ipc/SenderSession;

    .prologue
    const/4 v0, 0x0

    .line 50
    invoke-virtual {p0, p1, v0, v0, p2}, Ltas/internal/ipc/Dispatcher;->obtainMessage(IIILjava/lang/Object;)Landroid/os/Message;

    move-result-object v0

    invoke-virtual {p0, v0}, Ltas/internal/ipc/Dispatcher;->sendMessage(Landroid/os/Message;)Z

    .line 49
    return-void
.end method

.method public handleMessage(Landroid/os/Message;)V
    .locals 6
    .param p1, "msg"    # Landroid/os/Message;

    .prologue
    .line 59
    iget v5, p1, Landroid/os/Message;->what:I

    sparse-switch v5, :sswitch_data_0

    .line 57
    :cond_0
    :goto_0
    return-void

    .line 61
    :sswitch_0
    iget-object v2, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v2, Ltas/ipc/ReceiverSession;

    .line 62
    .local v2, "rs":Ltas/ipc/ReceiverSession;
    iget-object v5, p0, Ltas/internal/ipc/Dispatcher;->mR:Ljava/lang/ref/WeakReference;

    if-eqz v5, :cond_1

    iget-object v5, p0, Ltas/internal/ipc/Dispatcher;->mR:Ljava/lang/ref/WeakReference;

    invoke-virtual {v5}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ltas/internal/ipc/Receiver;

    .line 63
    :goto_1
    if-eqz v1, :cond_0

    invoke-virtual {v1, v2}, Ltas/internal/ipc/Receiver;->dispatchOnline(Ltas/ipc/ReceiverSession;)V

    goto :goto_0

    .line 62
    :cond_1
    const/4 v1, 0x0

    .local v1, "r":Ltas/internal/ipc/Receiver;
    goto :goto_1

    .line 67
    .end local v1    # "r":Ltas/internal/ipc/Receiver;
    .end local v2    # "rs":Ltas/ipc/ReceiverSession;
    :sswitch_1
    iget-object v2, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v2, Ltas/ipc/ReceiverSession;

    .line 68
    .restart local v2    # "rs":Ltas/ipc/ReceiverSession;
    iget-object v5, p0, Ltas/internal/ipc/Dispatcher;->mR:Ljava/lang/ref/WeakReference;

    if-eqz v5, :cond_2

    iget-object v5, p0, Ltas/internal/ipc/Dispatcher;->mR:Ljava/lang/ref/WeakReference;

    invoke-virtual {v5}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ltas/internal/ipc/Receiver;

    .line 69
    :goto_2
    if-eqz v1, :cond_0

    invoke-virtual {v1, v2}, Ltas/internal/ipc/Receiver;->dispatchOffline(Ltas/ipc/ReceiverSession;)V

    goto :goto_0

    .line 68
    :cond_2
    const/4 v1, 0x0

    .restart local v1    # "r":Ltas/internal/ipc/Receiver;
    goto :goto_2

    .line 73
    .end local v1    # "r":Ltas/internal/ipc/Receiver;
    .end local v2    # "rs":Ltas/ipc/ReceiverSession;
    :sswitch_2
    iget-object v2, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v2, Ltas/ipc/ReceiverSession;

    .line 74
    .restart local v2    # "rs":Ltas/ipc/ReceiverSession;
    iget-object v5, p0, Ltas/internal/ipc/Dispatcher;->mR:Ljava/lang/ref/WeakReference;

    if-eqz v5, :cond_3

    iget-object v5, p0, Ltas/internal/ipc/Dispatcher;->mR:Ljava/lang/ref/WeakReference;

    invoke-virtual {v5}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ltas/internal/ipc/Receiver;

    .line 75
    :goto_3
    if-eqz v1, :cond_0

    invoke-virtual {v1, v2}, Ltas/internal/ipc/Receiver;->dispatchUpdate(Ltas/ipc/ReceiverSession;)V

    goto :goto_0

    .line 74
    :cond_3
    const/4 v1, 0x0

    .restart local v1    # "r":Ltas/internal/ipc/Receiver;
    goto :goto_3

    .line 79
    .end local v1    # "r":Ltas/internal/ipc/Receiver;
    .end local v2    # "rs":Ltas/ipc/ReceiverSession;
    :sswitch_3
    iget-object v2, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v2, Ltas/ipc/ReceiverSession;

    .line 80
    .restart local v2    # "rs":Ltas/ipc/ReceiverSession;
    iget-object v5, v2, Ltas/ipc/ReceiverSession;->q:Ljava/util/Queue;

    invoke-interface {v5}, Ljava/util/Queue;->poll()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/ipc/MsgData;

    .line 81
    .local v0, "data":Ltas/ipc/MsgData;
    if-eqz v0, :cond_0

    .line 84
    iget-object v5, p0, Ltas/internal/ipc/Dispatcher;->mR:Ljava/lang/ref/WeakReference;

    if-eqz v5, :cond_5

    iget-object v5, p0, Ltas/internal/ipc/Dispatcher;->mR:Ljava/lang/ref/WeakReference;

    invoke-virtual {v5}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ltas/internal/ipc/Receiver;

    .line 85
    :goto_4
    iget-boolean v5, p0, Ltas/internal/ipc/Dispatcher;->mActivate:Z

    if-eqz v5, :cond_4

    if-eqz v1, :cond_4

    .line 86
    invoke-virtual {v1, v2, v0}, Ltas/internal/ipc/Receiver;->dispatchReceive(Ltas/ipc/ReceiverSession;Ltas/ipc/MsgData;)V

    .line 88
    :cond_4
    invoke-virtual {v0}, Ltas/ipc/MsgData;->recycle()V

    goto :goto_0

    .line 84
    :cond_5
    const/4 v1, 0x0

    .restart local v1    # "r":Ltas/internal/ipc/Receiver;
    goto :goto_4

    .line 92
    .end local v0    # "data":Ltas/ipc/MsgData;
    .end local v1    # "r":Ltas/internal/ipc/Receiver;
    .end local v2    # "rs":Ltas/ipc/ReceiverSession;
    :sswitch_4
    iget-object v4, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v4, Ltas/ipc/SenderSession;

    .line 93
    .local v4, "ss":Ltas/ipc/SenderSession;
    iget-object v5, p0, Ltas/internal/ipc/Dispatcher;->mS:Ljava/lang/ref/WeakReference;

    if-eqz v5, :cond_6

    iget-object v5, p0, Ltas/internal/ipc/Dispatcher;->mS:Ljava/lang/ref/WeakReference;

    invoke-virtual {v5}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ltas/internal/ipc/Sender;

    .line 94
    :goto_5
    if-eqz v3, :cond_0

    invoke-virtual {v3, v4}, Ltas/internal/ipc/Sender;->dispatchOnline(Ltas/ipc/SenderSession;)V

    goto/16 :goto_0

    .line 93
    :cond_6
    const/4 v3, 0x0

    .local v3, "s":Ltas/internal/ipc/Sender;
    goto :goto_5

    .line 98
    .end local v3    # "s":Ltas/internal/ipc/Sender;
    .end local v4    # "ss":Ltas/ipc/SenderSession;
    :sswitch_5
    iget-object v4, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v4, Ltas/ipc/SenderSession;

    .line 99
    .restart local v4    # "ss":Ltas/ipc/SenderSession;
    iget-object v5, p0, Ltas/internal/ipc/Dispatcher;->mS:Ljava/lang/ref/WeakReference;

    if-eqz v5, :cond_7

    iget-object v5, p0, Ltas/internal/ipc/Dispatcher;->mS:Ljava/lang/ref/WeakReference;

    invoke-virtual {v5}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ltas/internal/ipc/Sender;

    .line 100
    :goto_6
    if-eqz v3, :cond_0

    invoke-virtual {v3, v4}, Ltas/internal/ipc/Sender;->dispatchOffline(Ltas/ipc/SenderSession;)V

    goto/16 :goto_0

    .line 99
    :cond_7
    const/4 v3, 0x0

    .restart local v3    # "s":Ltas/internal/ipc/Sender;
    goto :goto_6

    .line 104
    .end local v3    # "s":Ltas/internal/ipc/Sender;
    .end local v4    # "ss":Ltas/ipc/SenderSession;
    :sswitch_6
    iget-object v4, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v4, Ltas/ipc/SenderSession;

    .line 105
    .restart local v4    # "ss":Ltas/ipc/SenderSession;
    iget-object v5, p0, Ltas/internal/ipc/Dispatcher;->mS:Ljava/lang/ref/WeakReference;

    if-eqz v5, :cond_8

    iget-object v5, p0, Ltas/internal/ipc/Dispatcher;->mS:Ljava/lang/ref/WeakReference;

    invoke-virtual {v5}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ltas/internal/ipc/Sender;

    .line 106
    :goto_7
    if-eqz v3, :cond_0

    invoke-virtual {v3, v4}, Ltas/internal/ipc/Sender;->dispatchUpdate(Ltas/ipc/SenderSession;)V

    goto/16 :goto_0

    .line 105
    :cond_8
    const/4 v3, 0x0

    .restart local v3    # "s":Ltas/internal/ipc/Sender;
    goto :goto_7

    .line 110
    .end local v3    # "s":Ltas/internal/ipc/Sender;
    .end local v4    # "ss":Ltas/ipc/SenderSession;
    :sswitch_7
    iget-object v4, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v4, Ltas/ipc/SenderSession;

    .line 111
    .restart local v4    # "ss":Ltas/ipc/SenderSession;
    iget-object v5, v4, Ltas/ipc/SenderSession;->q:Ljava/util/Queue;

    invoke-interface {v5}, Ljava/util/Queue;->poll()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/ipc/MsgData;

    .line 112
    .restart local v0    # "data":Ltas/ipc/MsgData;
    if-eqz v0, :cond_0

    .line 115
    iget-object v5, p0, Ltas/internal/ipc/Dispatcher;->mS:Ljava/lang/ref/WeakReference;

    if-eqz v5, :cond_a

    iget-object v5, p0, Ltas/internal/ipc/Dispatcher;->mS:Ljava/lang/ref/WeakReference;

    invoke-virtual {v5}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ltas/internal/ipc/Sender;

    .line 116
    :goto_8
    iget-boolean v5, p0, Ltas/internal/ipc/Dispatcher;->mActivate:Z

    if-eqz v5, :cond_9

    if-eqz v3, :cond_9

    .line 117
    invoke-virtual {v3, v4, v0}, Ltas/internal/ipc/Sender;->dispatchReply(Ltas/ipc/SenderSession;Ltas/ipc/MsgData;)V

    .line 119
    :cond_9
    invoke-virtual {v0}, Ltas/ipc/MsgData;->recycle()V

    goto/16 :goto_0

    .line 115
    :cond_a
    const/4 v3, 0x0

    .restart local v3    # "s":Ltas/internal/ipc/Sender;
    goto :goto_8

    .line 59
    :sswitch_data_0
    .sparse-switch
        0x65 -> :sswitch_4
        0x66 -> :sswitch_5
        0x67 -> :sswitch_6
        0x68 -> :sswitch_7
        0xc9 -> :sswitch_0
        0xca -> :sswitch_1
        0xcb -> :sswitch_2
        0xcc -> :sswitch_3
    .end sparse-switch
.end method
