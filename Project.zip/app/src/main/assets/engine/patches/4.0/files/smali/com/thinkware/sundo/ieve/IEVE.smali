.class public Lcom/thinkware/sundo/ieve/IEVE;
.super Ljava/lang/Object;
.source "IEVE.java"


# annotations
.annotation build Landroid/annotation/SuppressLint;
    value = {
        "DefaultLocale",
        "HandlerLeak"
    }
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/thinkware/sundo/ieve/IEVE$a;
    }
.end annotation


# static fields
.field public static final ID_IEVE_LAST_RECOG_CSWS:I = 0x0

.field public static final ID_IEVE_LAST_RECOG_FCWS:I = 0x1

.field public static final ID_IEVE_LAST_RECOG_FVSA:I = 0x2

.field public static final ID_IEVE_LAST_RECOG_LDWS:I = 0x3

.field public static final ID_IEVE_LAST_RECOG_PCWS:I = 0x6

.field public static final ID_IEVE_LAST_RECOG_PLCA:I = 0x4

.field public static final ID_IEVE_LAST_RECOG_TLCA:I = 0x5

.field public static final ID_IEVE_PROCESS_TIME_DR:I = 0x2

.field public static final ID_IEVE_PROCESS_TIME_FCWS:I = 0x7

.field public static final ID_IEVE_PROCESS_TIME_FCWS_AVR:I = 0x17

.field public static final ID_IEVE_PROCESS_TIME_FVSA:I = 0x4

.field public static final ID_IEVE_PROCESS_TIME_FVSA_AVR:I = 0x14

.field public static final ID_IEVE_PROCESS_TIME_LDWS:I = 0x5

.field public static final ID_IEVE_PROCESS_TIME_LDWS_AVR:I = 0x15

.field public static final ID_IEVE_PROCESS_TIME_PCWS:I = 0x8

.field public static final ID_IEVE_PROCESS_TIME_PCWS_AVR:I = 0x18

.field public static final ID_IEVE_PROCESS_TIME_RECOG:I = 0x0

.field public static final ID_IEVE_PROCESS_TIME_RECOG_AVR:I = 0x10

.field public static final ID_IEVE_PROCESS_TIME_SETIM:I = 0x1

.field public static final ID_IEVE_PROCESS_TIME_SETIM_AVR:I = 0x11

.field public static final ID_IEVE_PROCESS_TIME_TLCA:I = 0x6

.field public static final ID_IEVE_PROCESS_TIME_TLCA_AVR:I = 0x16

.field public static final ID_IEVE_PROCESS_TIME_VP:I = 0x3

.field public static final ID_IEVE_ROI_RANGE_BOTTOM:I = 0x4

.field public static final ID_IEVE_ROI_RANGE_LEFT:I = 0x1

.field public static final ID_IEVE_ROI_RANGE_RIGHT:I = 0x3

.field public static final ID_IEVE_ROI_RANGE_TOP:I = 0x2

.field public static IEVE_BASE_COORDINATE_SHIFT:D = 0.0

.field public static final IEVE_CAMERA_MODEL_AR0130:I = 0xa

.field public static final IEVE_CAMERA_MODEL_CC5811:I = 0xb

.field public static final IEVE_CAMERA_MODEL_CP8210:I = 0xc

.field public static final IEVE_CAMERA_MODEL_IBE100:I = 0x0

.field public static final IEVE_CAMERA_MODEL_ISX017:I = 0x2

.field public static final IEVE_CAMERA_MODEL_PC6060:I = 0x1

.field public static final IEVE_CAR_A_TYPE_MINI:I = 0x0

.field public static final IEVE_CAR_B_TYPE_SMALL:I = 0x1

.field public static final IEVE_CAR_C_TYPE_MEDIUM:I = 0x2

.field public static final IEVE_CAR_D_TYPE_LARGE:I = 0x3

.field public static final IEVE_CAR_E_TYPE_EXECUTIVE:I = 0x4

.field public static final IEVE_CAR_F_TYPE_LUXURY:I = 0x5

.field public static final IEVE_CAR_J_TYPE_SUV:I = 0x8

.field public static final IEVE_CAR_M_TYPE_MULTI_PURPOSE:I = 0x7

.field public static final IEVE_CAR_SPEED_SOURCE_DRGPS:I = 0x1

.field public static final IEVE_CAR_SPEED_SOURCE_GPS:I = 0x0

.field public static final IEVE_CAR_SPEED_SOURCE_OBD2:I = 0x2

.field public static final IEVE_CAR_S_TYPE_SPORT:I = 0x6

.field public static final IEVE_CSWS_SENSE_STRONG:I = 0x2

.field public static final IEVE_CSWS_SENSE_WEAK:I = 0x1

.field public static final IEVE_DEVICE_MODEL_OTHERS:I = 0x270f

.field public static final IEVE_DEVICE_MODEL_TWA8F12CF:I = 0x3e8

.field public static final IEVE_DEVICE_MODEL_TW_CUBE2:I = 0x4

.field public static final IEVE_DEVICE_MODEL_TW_CUBE_FL:I = 0x8

.field public static final IEVE_DEVICE_MODEL_TW_CUBE_LITE:I = 0x7

.field public static final IEVE_DEVICE_MODEL_TW_DAVINCI:I = 0xa

.field public static final IEVE_DEVICE_MODEL_TW_DIXIE:I = 0x1

.field public static final IEVE_DEVICE_MODEL_TW_DIXON:I = 0x0

.field public static final IEVE_DEVICE_MODEL_TW_LEO:I = 0x3

.field public static final IEVE_DEVICE_MODEL_TW_MOWGLI:I = 0x9

.field public static final IEVE_DEVICE_MODEL_TW_MX:I = 0x6

.field public static final IEVE_DEVICE_MODEL_TW_RUNA:I = 0x5

.field public static final IEVE_DEVICE_MODEL_TW_TAURUS:I = 0x2

.field public static final IEVE_FCWS_SENSE_NORMAL:I = 0x2

.field public static final IEVE_FCWS_SENSE_STRONG:I = 0x3

.field public static final IEVE_FCWS_SENSE_WEAK:I = 0x1

.field public static final IEVE_GPS_NORMAL:I = 0x0

.field public static final IEVE_GPS_OVERPASS:I = 0x1

.field public static final IEVE_GPS_TUNNEL:I = 0x3

.field public static final IEVE_GPS_UNDERPASS:I = 0x2

.field public static final IEVE_HAND_DRIVE_TYPE_LEFT:I = 0x0

.field public static final IEVE_HAND_DRIVE_TYPE_RIGHT:I = 0x1

.field public static final IEVE_HMSG_ERROR_CAMERA:I = 0x3ed

.field public static final IEVE_HMSG_ERROR_CODE:I = 0x4af

.field public static final IEVE_HMSG_PREVIEW_PERFORM:I = 0x3f2

.field public static final IEVE_HMSG_PREVIEW_SNAPSHOT:I = 0x3fc

.field public static final IEVE_HMSG_PREVIEW_STOP:I = 0x44b

.field public static final IEVE_HMSG_RCODE_ADAS:I = 0x457

.field public static final IEVE_HMSG_SIMULATION_MODE_CHANGE:I = 0x776

.field public static final IEVE_ID_CFG_CAM_HEIGHT:I = 0x7200

.field public static final IEVE_ID_CFG_CAM_HEIGHT_DEFAULT:I = 0x7201

.field public static final IEVE_ID_CFG_ROI_BOTTOM:I = 0x7102

.field public static final IEVE_ID_CFG_ROI_BOTTOM_DEFAULT:I = 0x7112

.field public static final IEVE_ID_CFG_ROI_LEFT:I = 0x7100

.field public static final IEVE_ID_CFG_ROI_LEFT_DEFAULT:I = 0x7110

.field public static final IEVE_ID_CFG_ROI_LEFT_STEP:I = 0x7120

.field public static final IEVE_ID_CFG_ROI_RIGHT:I = 0x7101

.field public static final IEVE_ID_CFG_ROI_RIGHT_DEFAULT:I = 0x7111

.field public static final IEVE_ID_CFG_ROI_RIGHT_STEP:I = 0x7121

.field public static final IEVE_ID_CFG_SOUND_LEVEL:I = 0x7400

.field public static final IEVE_ID_CFG_SOUND_MAX_LEVEL:I = 0x7401

.field public static final IEVE_ID_CFG_VANISH_PT_DEFAULT:I = 0x7302

.field public static final IEVE_ID_CFG_VANISH_PT_X:I = 0x7300

.field public static final IEVE_ID_CFG_VANISH_PT_Y:I = 0x7301

.field public static final IEVE_IMAGE_PROCESS_MAX_FRAMERATE:D = 12.0

.field public static final IEVE_INTERMEDIATE_LOCATION:I

.field public static final IEVE_LANGUAGE_TYPE_CN:I = 0x2

.field public static final IEVE_LANGUAGE_TYPE_JP:I = 0x3

.field public static final IEVE_LANGUAGE_TYPE_KR:I = 0x0

.field public static final IEVE_LANGUAGE_TYPE_US:I = 0x1

.field public static final IEVE_MODE_AR:I = 0x1

.field public static final IEVE_MODE_CALIBRATION_ADJUST:I = 0x10

.field public static final IEVE_MODE_CALIBRATION_FIND_VP:I = 0x40

.field public static final IEVE_MODE_CALIBRATION_INSTALL:I = 0x20

.field public static final IEVE_MODE_DR:I = 0x2

.field public static final IEVE_MODE_RECOG_CSWS:I = 0x8000

.field public static final IEVE_MODE_RECOG_FCWS:I = 0x200

.field public static final IEVE_MODE_RECOG_FVSA:I = 0x400

.field public static final IEVE_MODE_RECOG_LDWS:I = 0x100

.field public static final IEVE_MODE_RECOG_PCWS:I = 0x800

.field public static final IEVE_MODE_RECOG_PLCA:I = 0x1000

.field public static final IEVE_MODE_RECOG_TLCA:I = 0x2000

.field public static final IEVE_MODE_RECOG_TSRS:I = 0x4000

.field public static final IEVE_MODE_RECOG_UFCW:I = 0x10000

.field public static final IEVE_OBD_BRAKESWITCH_OFF:I = 0x1

.field public static final IEVE_OBD_BRAKESWITCH_ON:I = 0x2

.field public static final IEVE_OBD_BRAKESWITCH_UNKNOWN:I = 0x0

.field public static final IEVE_OBD_ERROR_CODE_INT:I = -0x5f5e0ff

.field public static final IEVE_OBD_ERROR_CODE_STR:Ljava/lang/String; = "NotSupported"

.field public static final IEVE_OBD_GEAR_DRIVE:I = 0x5

.field public static final IEVE_OBD_GEAR_NEUTRAL:I = 0x6

.field public static final IEVE_OBD_GEAR_PARK:I = 0x0

.field public static final IEVE_OBD_GEAR_REAR:I = 0x7

.field public static final IEVE_OBD_GEAR_UNKNOWN:I = -0x1

.field public static final IEVE_PCWS_SENSE_NORMAL:I = 0x2

.field public static final IEVE_PCWS_SENSE_STRONG:I = 0x3

.field public static final IEVE_PCWS_SENSE_WEAK:I = 0x1

.field public static final IEVE_RCODE_ADAS_DONE:I = 0x0

.field public static final IEVE_RCODE_ADAS_ERROR:I = 0x6000

.field public static final IEVE_RCODE_ADAS_NOT_IMAGEDATA:I = 0x6002

.field public static final IEVE_RCODE_ADAS_NOT_INITIALIZED:I = 0x6003

.field public static final IEVE_RCODE_ADAS_PROCESSING:I = 0x6001

.field public static final IEVE_RCODE_ADJUST_CAM_DIRECTION:I = 0x6100

.field public static final IEVE_RCODE_ADJUST_CAM_NOT_FOUND:I = 0x6110

.field public static final IEVE_RCODE_ADJUST_CAM_NO_ERROR:I = 0x0

.field public static final IEVE_RCODE_ADJUST_CAM_VERTICAL:I = 0x6101

.field public static final IEVE_RCODE_AUTO_VP_END:I = 0x6020

.field public static final IEVE_RCODE_AUTO_VP_FINDING:I = 0x6012

.field public static final IEVE_RCODE_AUTO_VP_FOUND:I = 0x6011

.field public static final IEVE_RCODE_AUTO_VP_NOT_FOUND:I = 0x6013

.field public static final IEVE_RCODE_CSWS_ATTENTION_LEFT:I = 0x8600

.field public static final IEVE_RCODE_CSWS_ATTENTION_RIGHT:I = 0x8601

.field public static final IEVE_RCODE_CSWS_END:I = 0x8604

.field public static final IEVE_RCODE_CSWS_WARNING_LEFT:I = 0x8602

.field public static final IEVE_RCODE_CSWS_WARNING_RIGHT:I = 0x8603

.field public static final IEVE_RCODE_FCWS_ATTENTION:I = 0x8503

.field public static final IEVE_RCODE_FCWS_DETECTION:I = 0x8502

.field public static final IEVE_RCODE_FCWS_END:I = 0x8505

.field public static final IEVE_RCODE_FCWS_ERROR:I = 0x8500

.field public static final IEVE_RCODE_FCWS_READY:I = 0x8501

.field public static final IEVE_RCODE_FCWS_WARNING:I = 0x8504

.field public static final IEVE_RCODE_FVSA_END:I = 0x8203

.field public static final IEVE_RCODE_FVSA_ERROR:I = 0x8200

.field public static final IEVE_RCODE_FVSA_GO:I = 0x8202

.field public static final IEVE_RCODE_FVSA_READY:I = 0x8201

.field public static final IEVE_RCODE_LDWS_END:I = 0x8120

.field public static final IEVE_RCODE_LDWS_ERROR:I = 0x8100

.field public static final IEVE_RCODE_LDWS_LEFT:I = 0x8102

.field public static final IEVE_RCODE_LDWS_LEFT_BAN:I = 0x8104

.field public static final IEVE_RCODE_LDWS_READY:I = 0x8101

.field public static final IEVE_RCODE_LDWS_RIGHT:I = 0x8103

.field public static final IEVE_RCODE_LDWS_RIGHT_BAN:I = 0x8105

.field public static final IEVE_RCODE_LDWS_WANDER:I = 0x8110

.field public static final IEVE_RCODE_PCWS_ATTENTION:I = 0x8703

.field public static final IEVE_RCODE_PCWS_DETECTION:I = 0x8702

.field public static final IEVE_RCODE_PCWS_END:I = 0x8705

.field public static final IEVE_RCODE_PCWS_ERROR:I = 0x8700

.field public static final IEVE_RCODE_PCWS_READY:I = 0x8701

.field public static final IEVE_RCODE_PCWS_WARNING:I = 0x8704

.field public static final IEVE_RCODE_PLCA_LEFT:I = 0x8301

.field public static final IEVE_RCODE_PLCA_MID:I = 0x8303

.field public static final IEVE_RCODE_PLCA_RIGHT:I = 0x8302

.field public static final IEVE_RCODE_PLCA_TO_LEFT:I = 0x8311

.field public static final IEVE_RCODE_PLCA_TO_RIGHT:I = 0x8312

.field public static final IEVE_RCODE_PLCA_TO_STRAIGHT:I = 0x8313

.field public static final IEVE_RCODE_PLCA_UNKNOWN:I = 0x8300

.field public static final IEVE_RCODE_TLCA_END:I = 0x8403

.field public static final IEVE_RCODE_TLCA_ERROR:I = 0x8400

.field public static final IEVE_RCODE_TLCA_GO:I = 0x8402

.field public static final IEVE_RCODE_TLCA_READY:I = 0x8401

.field public static final IEVE_SOUND_ID_CSWA:I = 0x7

.field public static final IEVE_SOUND_ID_CSWW:I = 0x8

.field public static final IEVE_SOUND_ID_FCWA:I = 0x5

.field public static final IEVE_SOUND_ID_FCWW:I = 0x6

.field public static final IEVE_SOUND_ID_FVSA:I = 0x2

.field public static final IEVE_SOUND_ID_LDWC:I = 0x0

.field public static final IEVE_SOUND_ID_LDWS:I = 0x1

.field public static final IEVE_SOUND_ID_PCWA:I = 0x9

.field public static final IEVE_SOUND_ID_PCWW:I = 0xa

.field public static final IEVE_SOUND_ID_PLCA:I = 0x4

.field public static final IEVE_SOUND_ID_TLCA:I = 0x3

.field private static final V:I = 0x7ce

.field private static final W:I = 0x7cf

.field private static final a:Ljava/lang/String; = "java_IEVE"

.field private static ah:Landroid/os/Handler; = null

.field private static final ai:I = 0x125c

.field private static final aj:I = 0x125d

.field private static final ak:I = 0x125e

.field private static final al:I = 0xfa0

.field private static ao:D

.field private static ap:D


# instance fields
.field private A:I

.field private B:Z

.field private C:I

.field private D:I

.field private E:I

.field private F:I

.field private G:I

.field private H:I

.field private I:I

.field public IEVE_IMAGESIZE_HD720_HEIGHT:I

.field public IEVE_IMAGESIZE_HD720_WIDTH:I

.field public IEVE_IMAGESIZE_INFO_HEIGHT:I

.field public IEVE_IMAGESIZE_INFO_WIDTH:I

.field public IEVE_IMAGESIZE_QVGA:I

.field public IEVE_IMAGESIZE_QVGA_ASPECTRATIO:D

.field public IEVE_IMAGESIZE_QVGA_HEIGHT:I

.field public IEVE_IMAGESIZE_QVGA_HEIGHT_2:I

.field public IEVE_IMAGESIZE_QVGA_WIDTH:I

.field public IEVE_IMAGESIZE_QVGA_WIDTH_2:I

.field public IEVE_IMAGESIZE_VGA:I

.field public IEVE_IMAGESIZE_VGA_ASPECTRATIO:D

.field public IEVE_IMAGESIZE_VGA_HEIGHT:I

.field public IEVE_IMAGESIZE_VGA_HEIGHT_2:I

.field public IEVE_IMAGESIZE_VGA_WIDTH:I

.field public IEVE_IMAGESIZE_VGA_WIDTH_2:I

.field private J:I

.field private K:I

.field private L:I

.field private M:I

.field private N:I

.field private O:I

.field private P:I

.field private Q:I

.field private R:I

.field private S:Landroid/graphics/Point;

.field private T:Lcom/thinkware/sundo/ieve/ieveSoundManager;

.field private U:Z

.field private X:F

.field private Y:F

.field private Z:F

.field private aa:F

.field private ab:F

.field private ac:Z

.field private ad:I

.field private ae:I

.field private af:Ljava/util/Timer;

.field private ag:Ljava/util/TimerTask;

.field private am:Landroid/os/Handler;

.field private an:Lcom/thinkware/sundo/ieve/IEVE$a;

.field private aq:I

.field private final ar:I

.field private as:Ljava/lang/Runnable;

.field private at:Lcom/thinkware/sundo/ieve/ieveTextView;

.field private au:Lcom/thinkware/sundo/ieve/ieveDebugImageView;

.field private b:Landroid/content/Context;

.field private c:Landroid/os/Handler;

.field private d:Lcom/stradvision/pdvdtest/SV_ADAS;

.field private e:Lcom/thinkware/sundo/ieve/ieveNative;

.field private f:Lcom/thinkware/sundo/ieve/ieveGuideInfos;

.field private g:Lcom/thinkware/sundo/ieve/ieveNScreenManager;

.field private h:Lcom/thinkware/sundo/ieve/ieveARView;

.field private i:Lcom/thinkware/sundo/ieve/ieveCalibrationView;

.field private j:Lcom/thinkware/sundo/ieve/ieveCameraView;

.field private k:I

.field private l:I

.field private m:I

.field private n:I

.field private o:I

.field private p:Z

.field private q:Z

.field private r:Landroid/graphics/Rect;

.field private s:Landroid/graphics/Rect;

.field private t:Landroid/graphics/Rect;

.field private u:Landroid/graphics/Rect;

.field private v:Landroid/graphics/Rect;

.field private w:Landroid/graphics/Rect;

.field private x:Landroid/graphics/Rect;

.field private y:I

.field private z:I


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .prologue
    .line 252
    sget-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$IEVE_INTERMEDIATE_KIND;->IEVE_INTERMEDIATE_LOCATION:Lcom/thinkware/sundo/ieve/ieveGuideInfos$IEVE_INTERMEDIATE_KIND;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$IEVE_INTERMEDIATE_KIND;->getValue()I

    move-result v0

    sput v0, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_INTERMEDIATE_LOCATION:I

    .line 364
    const/4 v0, 0x0

    sput-object v0, Lcom/thinkware/sundo/ieve/IEVE;->ah:Landroid/os/Handler;

    .line 2811
    const-wide v0, 0x4115f90000000000L    # 360000.0

    sput-wide v0, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_BASE_COORDINATE_SHIFT:D

    .line 2812
    const-wide v0, 0x4030cccccccccccdL    # 16.8

    sput-wide v0, Lcom/thinkware/sundo/ieve/IEVE;->ao:D

    .line 2813
    const-wide v0, 0x4052733333333333L    # 73.8

    sput-wide v0, Lcom/thinkware/sundo/ieve/IEVE;->ap:D

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/os/Handler;)V
    .locals 9
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "handlerparent"    # Landroid/os/Handler;

    .prologue
    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v6, 0x0

    .line 653
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 30
    iput-object v6, p0, Lcom/thinkware/sundo/ieve/IEVE;->b:Landroid/content/Context;

    .line 31
    iput-object v6, p0, Lcom/thinkware/sundo/ieve/IEVE;->c:Landroid/os/Handler;

    .line 34
    new-instance v1, Lcom/stradvision/pdvdtest/SV_ADAS;

    invoke-direct {v1}, Lcom/stradvision/pdvdtest/SV_ADAS;-><init>()V

    iput-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->d:Lcom/stradvision/pdvdtest/SV_ADAS;

    .line 37
    new-instance v1, Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-direct {v1}, Lcom/thinkware/sundo/ieve/ieveNative;-><init>()V

    iput-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    .line 40
    iput-object v6, p0, Lcom/thinkware/sundo/ieve/IEVE;->f:Lcom/thinkware/sundo/ieve/ieveGuideInfos;

    .line 43
    iput-object v6, p0, Lcom/thinkware/sundo/ieve/IEVE;->g:Lcom/thinkware/sundo/ieve/ieveNScreenManager;

    .line 46
    iput-object v6, p0, Lcom/thinkware/sundo/ieve/IEVE;->h:Lcom/thinkware/sundo/ieve/ieveARView;

    .line 47
    iput-object v6, p0, Lcom/thinkware/sundo/ieve/IEVE;->i:Lcom/thinkware/sundo/ieve/ieveCalibrationView;

    .line 48
    iput-object v6, p0, Lcom/thinkware/sundo/ieve/IEVE;->j:Lcom/thinkware/sundo/ieve/ieveCameraView;

    .line 255
    const/4 v1, 0x2

    iput v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->k:I

    .line 256
    iput v2, p0, Lcom/thinkware/sundo/ieve/IEVE;->l:I

    .line 257
    iput v2, p0, Lcom/thinkware/sundo/ieve/IEVE;->m:I

    .line 260
    iput v3, p0, Lcom/thinkware/sundo/ieve/IEVE;->n:I

    .line 261
    iput v3, p0, Lcom/thinkware/sundo/ieve/IEVE;->o:I

    .line 262
    iput-boolean v7, p0, Lcom/thinkware/sundo/ieve/IEVE;->p:Z

    .line 263
    iput-boolean v2, p0, Lcom/thinkware/sundo/ieve/IEVE;->q:Z

    .line 266
    iput-object v6, p0, Lcom/thinkware/sundo/ieve/IEVE;->r:Landroid/graphics/Rect;

    .line 267
    iput-object v6, p0, Lcom/thinkware/sundo/ieve/IEVE;->s:Landroid/graphics/Rect;

    .line 268
    iput-object v6, p0, Lcom/thinkware/sundo/ieve/IEVE;->t:Landroid/graphics/Rect;

    .line 269
    iput-object v6, p0, Lcom/thinkware/sundo/ieve/IEVE;->u:Landroid/graphics/Rect;

    .line 270
    iput-object v6, p0, Lcom/thinkware/sundo/ieve/IEVE;->v:Landroid/graphics/Rect;

    .line 271
    iput-object v6, p0, Lcom/thinkware/sundo/ieve/IEVE;->w:Landroid/graphics/Rect;

    .line 272
    iput-object v6, p0, Lcom/thinkware/sundo/ieve/IEVE;->x:Landroid/graphics/Rect;

    .line 278
    iput v7, p0, Lcom/thinkware/sundo/ieve/IEVE;->y:I

    .line 279
    iput v7, p0, Lcom/thinkware/sundo/ieve/IEVE;->z:I

    .line 280
    iput v7, p0, Lcom/thinkware/sundo/ieve/IEVE;->A:I

    .line 283
    iput-boolean v7, p0, Lcom/thinkware/sundo/ieve/IEVE;->B:Z

    .line 284
    const/16 v1, 0x20

    iput v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->C:I

    .line 285
    const v1, 0x8604

    iput v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->D:I

    .line 286
    const v1, 0x8505

    iput v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->E:I

    .line 287
    const v1, 0x8203

    iput v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->F:I

    .line 288
    const v1, 0x8120

    iput v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->G:I

    .line 289
    const v1, 0x8705

    iput v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->H:I

    .line 290
    const v1, 0x8313

    iput v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->I:I

    .line 291
    const v1, 0x8403

    iput v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->J:I

    .line 292
    iget v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->D:I

    iput v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->K:I

    .line 293
    iget v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->G:I

    iput v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->L:I

    .line 294
    iget v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->E:I

    iput v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->M:I

    .line 295
    iget v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->H:I

    iput v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->N:I

    .line 296
    iget v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->F:I

    iput v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->O:I

    .line 297
    iget v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->J:I

    iput v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->P:I

    .line 298
    iget v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->I:I

    iput v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->Q:I

    .line 299
    iput v7, p0, Lcom/thinkware/sundo/ieve/IEVE;->R:I

    .line 300
    iput-object v6, p0, Lcom/thinkware/sundo/ieve/IEVE;->S:Landroid/graphics/Point;

    .line 303
    iput-object v6, p0, Lcom/thinkware/sundo/ieve/IEVE;->T:Lcom/thinkware/sundo/ieve/ieveSoundManager;

    .line 317
    const/16 v1, 0x140

    iput v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_IMAGESIZE_QVGA_WIDTH:I

    .line 318
    const/16 v1, 0xf0

    iput v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_IMAGESIZE_QVGA_HEIGHT:I

    .line 319
    iget v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_IMAGESIZE_QVGA_WIDTH:I

    div-int/lit8 v1, v1, 0x2

    iput v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_IMAGESIZE_QVGA_WIDTH_2:I

    .line 320
    iget v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_IMAGESIZE_QVGA_HEIGHT:I

    div-int/lit8 v1, v1, 0x2

    iput v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_IMAGESIZE_QVGA_HEIGHT_2:I

    .line 321
    iget v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_IMAGESIZE_QVGA_WIDTH:I

    iget v2, p0, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_IMAGESIZE_QVGA_HEIGHT:I

    mul-int/2addr v1, v2

    iput v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_IMAGESIZE_QVGA:I

    .line 322
    iget v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_IMAGESIZE_QVGA_WIDTH:I

    int-to-double v2, v1

    iget v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_IMAGESIZE_QVGA_HEIGHT:I

    int-to-double v4, v1

    div-double/2addr v2, v4

    iput-wide v2, p0, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_IMAGESIZE_QVGA_ASPECTRATIO:D

    .line 323
    iget v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_IMAGESIZE_QVGA_WIDTH:I

    mul-int/lit8 v1, v1, 0x2

    iput v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_IMAGESIZE_VGA_WIDTH:I

    .line 324
    iget v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_IMAGESIZE_QVGA_HEIGHT:I

    mul-int/lit8 v1, v1, 0x2

    iput v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_IMAGESIZE_VGA_HEIGHT:I

    .line 325
    iget v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_IMAGESIZE_QVGA_WIDTH:I

    iput v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_IMAGESIZE_VGA_WIDTH_2:I

    .line 326
    iget v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_IMAGESIZE_QVGA_HEIGHT:I

    iput v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_IMAGESIZE_VGA_HEIGHT_2:I

    .line 327
    iget v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_IMAGESIZE_VGA_WIDTH:I

    iget v2, p0, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_IMAGESIZE_VGA_HEIGHT:I

    mul-int/2addr v1, v2

    iput v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_IMAGESIZE_VGA:I

    .line 328
    iget v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_IMAGESIZE_VGA_WIDTH:I

    int-to-double v2, v1

    iget v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_IMAGESIZE_VGA_HEIGHT:I

    int-to-double v4, v1

    div-double/2addr v2, v4

    iput-wide v2, p0, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_IMAGESIZE_VGA_ASPECTRATIO:D

    .line 329
    const/16 v1, 0x500

    iput v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_IMAGESIZE_HD720_WIDTH:I

    .line 330
    const/16 v1, 0x2d0

    iput v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_IMAGESIZE_HD720_HEIGHT:I

    .line 331
    iget v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_IMAGESIZE_QVGA_WIDTH:I

    iput v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_IMAGESIZE_INFO_WIDTH:I

    .line 332
    iget v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_IMAGESIZE_QVGA_HEIGHT:I

    iput v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_IMAGESIZE_INFO_HEIGHT:I

    .line 335
    iput-boolean v7, p0, Lcom/thinkware/sundo/ieve/IEVE;->U:Z

    .line 349
    iput v8, p0, Lcom/thinkware/sundo/ieve/IEVE;->X:F

    .line 350
    iput v8, p0, Lcom/thinkware/sundo/ieve/IEVE;->Y:F

    .line 351
    iput v8, p0, Lcom/thinkware/sundo/ieve/IEVE;->Z:F

    .line 352
    iput v8, p0, Lcom/thinkware/sundo/ieve/IEVE;->aa:F

    .line 353
    iput v8, p0, Lcom/thinkware/sundo/ieve/IEVE;->ab:F

    .line 354
    iput-boolean v7, p0, Lcom/thinkware/sundo/ieve/IEVE;->ac:Z

    .line 355
    iput v7, p0, Lcom/thinkware/sundo/ieve/IEVE;->ad:I

    .line 356
    iput v7, p0, Lcom/thinkware/sundo/ieve/IEVE;->ae:I

    .line 359
    iput-object v6, p0, Lcom/thinkware/sundo/ieve/IEVE;->af:Ljava/util/Timer;

    .line 360
    iput-object v6, p0, Lcom/thinkware/sundo/ieve/IEVE;->ag:Ljava/util/TimerTask;

    .line 412
    iput-object v6, p0, Lcom/thinkware/sundo/ieve/IEVE;->am:Landroid/os/Handler;

    .line 616
    iput-object v6, p0, Lcom/thinkware/sundo/ieve/IEVE;->an:Lcom/thinkware/sundo/ieve/IEVE$a;

    .line 2864
    const/16 v1, 0x3c

    iput v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->aq:I

    .line 2865
    const/16 v1, 0x21

    iput v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->ar:I

    .line 2866
    iput-object v6, p0, Lcom/thinkware/sundo/ieve/IEVE;->as:Ljava/lang/Runnable;

    .line 2867
    iput-object v6, p0, Lcom/thinkware/sundo/ieve/IEVE;->at:Lcom/thinkware/sundo/ieve/ieveTextView;

    .line 2868
    iput-object v6, p0, Lcom/thinkware/sundo/ieve/IEVE;->au:Lcom/thinkware/sundo/ieve/ieveDebugImageView;

    .line 654
    iput-object p1, p0, Lcom/thinkware/sundo/ieve/IEVE;->b:Landroid/content/Context;

    .line 655
    iput-object p2, p0, Lcom/thinkware/sundo/ieve/IEVE;->c:Landroid/os/Handler;

    .line 657
    const-string v1, "java_IEVE"

    const-string v2, "\n===== IEVE java start! ==========================================="

    invoke-static {v1, v2}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 658
    const-string v1, "java_IEVE"

    const-string v2, "Constructor"

    invoke-static {v1, v2}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 661
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->b:Landroid/content/Context;

    if-nez v1, :cond_1

    .line 662
    const-string v1, "Context is null!"

    new-array v2, v7, [Ljava/lang/Object;

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    .line 663
    .local v0, "text":Ljava/lang/String;
    const-string v1, "java_IEVE"

    invoke-static {v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 686
    .end local v0    # "text":Ljava/lang/String;
    :cond_0
    :goto_0
    return-void

    .line 666
    :cond_1
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->c:Landroid/os/Handler;

    if-nez v1, :cond_2

    .line 667
    const-string v1, "HandlerParent is null!"

    new-array v2, v7, [Ljava/lang/Object;

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    .line 668
    .restart local v0    # "text":Ljava/lang/String;
    const-string v1, "java_IEVE"

    invoke-static {v1, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 671
    .end local v0    # "text":Ljava/lang/String;
    :cond_2
    invoke-direct {p0}, Lcom/thinkware/sundo/ieve/IEVE;->a()V

    .line 673
    new-instance v1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;

    invoke-direct {v1}, Lcom/thinkware/sundo/ieve/ieveGuideInfos;-><init>()V

    iput-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->f:Lcom/thinkware/sundo/ieve/ieveGuideInfos;

    .line 674
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v1}, Lcom/thinkware/sundo/ieve/ieveNative;->IsInitializedJNI()Z

    move-result v1

    if-nez v1, :cond_0

    .line 675
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v1}, Lcom/thinkware/sundo/ieve/ieveNative;->InitializeJNI()Z

    move-result v1

    if-nez v1, :cond_3

    .line 676
    const-string v1, "IEVE InitJNI error"

    new-array v2, v7, [Ljava/lang/Object;

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    .line 677
    .restart local v0    # "text":Ljava/lang/String;
    const-string v1, "java_IEVE"

    invoke-static {v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 678
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->am:Landroid/os/Handler;

    iget-object v2, p0, Lcom/thinkware/sundo/ieve/IEVE;->am:Landroid/os/Handler;

    const/16 v3, 0x4af

    invoke-static {v2, v3, v0}, Landroid/os/Message;->obtain(Landroid/os/Handler;ILjava/lang/Object;)Landroid/os/Message;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto :goto_0

    .line 682
    .end local v0    # "text":Ljava/lang/String;
    :cond_3
    const-string v1, "IEVE InitJNI success"

    new-array v2, v7, [Ljava/lang/Object;

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    .line 683
    .restart local v0    # "text":Ljava/lang/String;
    const-string v1, "java_IEVE"

    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0
.end method

.method static synthetic A(Lcom/thinkware/sundo/ieve/IEVE;)I
    .locals 1

    .prologue
    .line 287
    iget v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->F:I

    return v0
.end method

.method static synthetic B(Lcom/thinkware/sundo/ieve/IEVE;)I
    .locals 1

    .prologue
    .line 296
    iget v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->O:I

    return v0
.end method

.method static synthetic C(Lcom/thinkware/sundo/ieve/IEVE;)I
    .locals 1

    .prologue
    .line 291
    iget v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->J:I

    return v0
.end method

.method static synthetic D(Lcom/thinkware/sundo/ieve/IEVE;)I
    .locals 1

    .prologue
    .line 297
    iget v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->P:I

    return v0
.end method

.method static synthetic E(Lcom/thinkware/sundo/ieve/IEVE;)I
    .locals 1

    .prologue
    .line 290
    iget v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->I:I

    return v0
.end method

.method static synthetic F(Lcom/thinkware/sundo/ieve/IEVE;)I
    .locals 1

    .prologue
    .line 298
    iget v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->Q:I

    return v0
.end method

.method static synthetic G(Lcom/thinkware/sundo/ieve/IEVE;)Z
    .locals 1

    .prologue
    .line 262
    iget-boolean v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->p:Z

    return v0
.end method

.method static synthetic H(Lcom/thinkware/sundo/ieve/IEVE;)I
    .locals 1

    .prologue
    .line 261
    iget v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->o:I

    return v0
.end method

.method static synthetic I(Lcom/thinkware/sundo/ieve/IEVE;)I
    .locals 1

    .prologue
    .line 260
    iget v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->n:I

    return v0
.end method

.method static synthetic J(Lcom/thinkware/sundo/ieve/IEVE;)Ljava/lang/Runnable;
    .locals 1

    .prologue
    .line 2866
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->as:Ljava/lang/Runnable;

    return-object v0
.end method

.method static synthetic a(Lcom/thinkware/sundo/ieve/IEVE;[B)I
    .locals 1

    .prologue
    .line 1737
    invoke-direct {p0, p1}, Lcom/thinkware/sundo/ieve/IEVE;->a([B)I

    move-result v0

    return v0
.end method

.method private a([B)I
    .locals 41
    .param p1, "data"    # [B

    .prologue
    .line 1738
    move-object/from16 v0, p0

    iget-boolean v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->B:Z

    if-eqz v2, :cond_0

    const/16 v35, 0x6001

    .line 2022
    :goto_0
    return v35

    .line 1740
    :cond_0
    if-nez p1, :cond_1

    .line 1741
    const-string v2, "perform[data is null]"

    const/4 v3, 0x0

    new-array v3, v3, [Ljava/lang/Object;

    invoke-static {v2, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v40

    .line 1742
    .local v40, "text":Ljava/lang/String;
    const-string v2, "java_IEVE"

    move-object/from16 v0, v40

    invoke-static {v2, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 1743
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->am:Landroid/os/Handler;

    move-object/from16 v0, p0

    iget-object v3, v0, Lcom/thinkware/sundo/ieve/IEVE;->am:Landroid/os/Handler;

    const/16 v5, 0x4af

    move-object/from16 v0, v40

    invoke-static {v3, v5, v0}, Landroid/os/Message;->obtain(Landroid/os/Handler;ILjava/lang/Object;)Landroid/os/Message;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    .line 1744
    const/16 v35, 0x6000

    goto :goto_0

    .line 1747
    .end local v40    # "text":Ljava/lang/String;
    :cond_1
    const/4 v2, 0x1

    move-object/from16 v0, p0

    iput-boolean v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->B:Z

    .line 1749
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    move-object/from16 v0, p1

    invoke-virtual {v2, v0}, Lcom/thinkware/sundo/ieve/ieveNative;->PerformADAS([B)I

    move-result v35

    .line 1750
    .local v35, "retPerform":I
    if-eqz v35, :cond_2

    .line 1751
    const/4 v2, 0x0

    move-object/from16 v0, p0

    iput-boolean v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->B:Z

    .line 1752
    const-string v2, "perform[PerformADAS:%d]"

    const/4 v3, 0x1

    new-array v3, v3, [Ljava/lang/Object;

    const/4 v5, 0x0

    invoke-static/range {v35 .. v35}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    aput-object v6, v3, v5

    invoke-static {v2, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v40

    .line 1753
    .restart local v40    # "text":Ljava/lang/String;
    const-string v2, "java_IEVE"

    move-object/from16 v0, v40

    invoke-static {v2, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    .line 1757
    .end local v40    # "text":Ljava/lang/String;
    :cond_2
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->at:Lcom/thinkware/sundo/ieve/ieveTextView;

    if-eqz v2, :cond_d

    .line 1758
    const-string v4, ""

    .line 1761
    .local v4, "dbgtxt":Ljava/lang/String;
    const-string v2, "Cam: %.1ffps"

    const/4 v3, 0x1

    new-array v3, v3, [Ljava/lang/Object;

    const/4 v5, 0x0

    move-object/from16 v0, p0

    iget-object v6, v0, Lcom/thinkware/sundo/ieve/IEVE;->j:Lcom/thinkware/sundo/ieve/ieveCameraView;

    invoke-virtual {v6}, Lcom/thinkware/sundo/ieve/ieveCameraView;->getFrameRateReal()D

    move-result-wide v6

    invoke-static {v6, v7}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v6

    aput-object v6, v3, v5

    invoke-static {v2, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    .line 1762
    const/16 v3, 0x3f1

    const/high16 v5, 0x44000000    # 512.0f

    const/high16 v6, 0x41c80000    # 25.0f

    const/high16 v7, 0x41a00000    # 20.0f

    const v8, -0xff0100

    move-object/from16 v2, p0

    invoke-virtual/range {v2 .. v8}, Lcom/thinkware/sundo/ieve/IEVE;->DebugPrint(ILjava/lang/String;FFFI)V

    .line 1766
    new-instance v25, Ljava/util/Date;

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v2

    move-object/from16 v0, v25

    invoke-direct {v0, v2, v3}, Ljava/util/Date;-><init>(J)V

    .line 1767
    .local v25, "now":Ljava/util/Date;
    const-string v2, "%s[%d:%02d:%02d]"

    const/4 v3, 0x4

    new-array v3, v3, [Ljava/lang/Object;

    const/4 v5, 0x0

    move-object/from16 v0, p0

    iget-object v6, v0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v6}, Lcom/thinkware/sundo/ieve/ieveNative;->GetVersion()Ljava/lang/String;

    move-result-object v6

    aput-object v6, v3, v5

    const/4 v5, 0x1

    invoke-virtual/range {v25 .. v25}, Ljava/util/Date;->getHours()I

    move-result v6

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    aput-object v6, v3, v5

    const/4 v5, 0x2

    invoke-virtual/range {v25 .. v25}, Ljava/util/Date;->getMinutes()I

    move-result v6

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    aput-object v6, v3, v5

    const/4 v5, 0x3

    invoke-virtual/range {v25 .. v25}, Ljava/util/Date;->getSeconds()I

    move-result v6

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    aput-object v6, v3, v5

    invoke-static {v2, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    .line 1769
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-static {v4}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string v3, " dr:%.1f"

    const/4 v5, 0x1

    new-array v5, v5, [Ljava/lang/Object;

    const/4 v6, 0x0

    move-object/from16 v0, p0

    iget-object v7, v0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v7}, Lcom/thinkware/sundo/ieve/ieveNative;->GetCarAngleDirectionFromDR()F

    move-result v7

    invoke-static {v7}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v7

    aput-object v7, v5, v6

    invoke-static {v3, v5}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    .line 1771
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-static {v4}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    invoke-direct {v3, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string v5, " sn:%s|bg:%s"

    const/4 v2, 0x2

    new-array v6, v2, [Ljava/lang/Object;

    const/4 v7, 0x0

    invoke-virtual/range {p0 .. p0}, Lcom/thinkware/sundo/ieve/IEVE;->getUseSunFilm()Z

    move-result v2

    if-eqz v2, :cond_e

    const-string v2, "T"

    :goto_1
    aput-object v2, v6, v7

    const/4 v7, 0x1

    invoke-virtual/range {p0 .. p0}, Lcom/thinkware/sundo/ieve/IEVE;->isShowBGCover()Z

    move-result v2

    if-eqz v2, :cond_f

    const-string v2, "T"

    :goto_2
    aput-object v2, v6, v7

    invoke-static {v5, v6}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    .line 1773
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-static {v4}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string v3, " vp(%d,%d#%d/%d)"

    const/4 v5, 0x4

    new-array v5, v5, [Ljava/lang/Object;

    const/4 v6, 0x0

    invoke-virtual/range {p0 .. p0}, Lcom/thinkware/sundo/ieve/IEVE;->getVanishingPointX()I

    move-result v7

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    aput-object v7, v5, v6

    const/4 v6, 0x1

    invoke-virtual/range {p0 .. p0}, Lcom/thinkware/sundo/ieve/IEVE;->getVanishingPointY()I

    move-result v7

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    aput-object v7, v5, v6

    const/4 v6, 0x2

    .line 1774
    move-object/from16 v0, p0

    iget-object v7, v0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v7}, Lcom/thinkware/sundo/ieve/ieveNative;->GetCountNotFindVP()I

    move-result v7

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    aput-object v7, v5, v6

    const/4 v6, 0x3

    move-object/from16 v0, p0

    iget-object v7, v0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v7}, Lcom/thinkware/sundo/ieve/ieveNative;->GetCountTryFoundVP()I

    move-result v7

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    aput-object v7, v5, v6

    .line 1773
    invoke-static {v3, v5}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    .line 1776
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-static {v4}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string v3, " DAS:"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "%.1f"

    const/4 v5, 0x1

    new-array v5, v5, [Ljava/lang/Object;

    const/4 v6, 0x0

    move-object/from16 v0, p0

    iget-object v7, v0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v7}, Lcom/thinkware/sundo/ieve/ieveNative;->GetFrameRateADAS()D

    move-result-wide v10

    invoke-static {v10, v11}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v7

    aput-object v7, v5, v6

    invoke-static {v3, v5}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    .line 1778
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-static {v4}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string v3, " L|R("

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    .line 1779
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v2}, Lcom/thinkware/sundo/ieve/ieveNative;->IsTurnedOnTurnLampL()Z

    move-result v2

    if-eqz v2, :cond_10

    const-string v2, "T"

    :goto_3
    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const/16 v3, 0x7100

    move-object/from16 v0, p0

    invoke-virtual {v0, v3}, Lcom/thinkware/sundo/ieve/IEVE;->getIEVEConfigValue(I)I

    move-result v3

    invoke-static {v3}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "|"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    .line 1780
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v2}, Lcom/thinkware/sundo/ieve/ieveNative;->IsTurnedOnTurnLampR()Z

    move-result v2

    if-eqz v2, :cond_11

    const-string v2, "T"

    :goto_4
    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const/16 v3, 0x7101

    move-object/from16 v0, p0

    invoke-virtual {v0, v3}, Lcom/thinkware/sundo/ieve/IEVE;->getIEVEConfigValue(I)I

    move-result v3

    invoke-static {v3}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, ")"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    .line 1778
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    .line 1782
    invoke-virtual/range {p0 .. p0}, Lcom/thinkware/sundo/ieve/IEVE;->isEnableModeRecogLDWS()Z

    move-result v2

    if-eqz v2, :cond_3

    .line 1783
    const-string v31, "e"

    .line 1784
    .local v31, "resultLDWS":Ljava/lang/String;
    move-object/from16 v0, p0

    iget v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->G:I

    sparse-switch v2, :sswitch_data_0

    .line 1792
    :goto_5
    new-instance v2, Ljava/lang/StringBuilder;

    .line 1794
    invoke-static {v4}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string v3, " LD("

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    move-object/from16 v0, v31

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, ")"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    .line 1796
    .end local v31    # "resultLDWS":Ljava/lang/String;
    :cond_3
    invoke-virtual/range {p0 .. p0}, Lcom/thinkware/sundo/ieve/IEVE;->isEnableModeRecogPLCA()Z

    move-result v2

    if-eqz v2, :cond_4

    .line 1797
    const-string v33, "u"

    .line 1798
    .local v33, "resultPLCA":Ljava/lang/String;
    move-object/from16 v0, p0

    iget v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->I:I

    packed-switch v2, :pswitch_data_0

    .line 1802
    :goto_6
    new-instance v2, Ljava/lang/StringBuilder;

    .line 1804
    invoke-static {v4}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string v3, " PL("

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    move-object/from16 v0, v33

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, ")"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    .line 1806
    .end local v33    # "resultPLCA":Ljava/lang/String;
    :cond_4
    invoke-virtual/range {p0 .. p0}, Lcom/thinkware/sundo/ieve/IEVE;->isEnableModeRecogFCWS()Z

    move-result v2

    if-eqz v2, :cond_5

    .line 1807
    const-string v28, "e"

    .line 1808
    .local v28, "resultFCWS":Ljava/lang/String;
    move-object/from16 v0, p0

    iget v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->E:I

    packed-switch v2, :pswitch_data_1

    .line 1814
    :goto_7
    new-instance v2, Ljava/lang/StringBuilder;

    .line 1816
    invoke-static {v4}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string v3, " FC("

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    move-object/from16 v0, v28

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, ")"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    .line 1818
    .end local v28    # "resultFCWS":Ljava/lang/String;
    :cond_5
    invoke-virtual/range {p0 .. p0}, Lcom/thinkware/sundo/ieve/IEVE;->isEnableModeRecogPCWS()Z

    move-result v2

    if-eqz v2, :cond_6

    .line 1819
    const-string v32, "e"

    .line 1820
    .local v32, "resultPCWS":Ljava/lang/String;
    move-object/from16 v0, p0

    iget v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->H:I

    packed-switch v2, :pswitch_data_2

    .line 1826
    :goto_8
    new-instance v2, Ljava/lang/StringBuilder;

    .line 1828
    invoke-static {v4}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string v3, " PC("

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    move-object/from16 v0, v32

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, ")"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    .line 1830
    .end local v32    # "resultPCWS":Ljava/lang/String;
    :cond_6
    invoke-virtual/range {p0 .. p0}, Lcom/thinkware/sundo/ieve/IEVE;->isEnableModeRecogFVSA()Z

    move-result v2

    if-eqz v2, :cond_7

    .line 1831
    const-string v29, "e"

    .line 1832
    .local v29, "resultFVSA":Ljava/lang/String;
    move-object/from16 v0, p0

    iget v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->F:I

    packed-switch v2, :pswitch_data_3

    .line 1836
    :goto_9
    new-instance v2, Ljava/lang/StringBuilder;

    .line 1838
    invoke-static {v4}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string v3, " FV("

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    move-object/from16 v0, v29

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "#%d"

    const/4 v5, 0x1

    new-array v5, v5, [Ljava/lang/Object;

    const/4 v6, 0x0

    move-object/from16 v0, p0

    iget-object v7, v0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v7}, Lcom/thinkware/sundo/ieve/ieveNative;->GetCountNotifyFVSA()I

    move-result v7

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    aput-object v7, v5, v6

    invoke-static {v3, v5}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, ")"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    .line 1840
    .end local v29    # "resultFVSA":Ljava/lang/String;
    :cond_7
    invoke-virtual/range {p0 .. p0}, Lcom/thinkware/sundo/ieve/IEVE;->isEnableModeRecogTLCA()Z

    move-result v2

    if-eqz v2, :cond_8

    .line 1841
    const-string v34, "e"

    .line 1842
    .local v34, "resultTLCA":Ljava/lang/String;
    move-object/from16 v0, p0

    iget v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->J:I

    packed-switch v2, :pswitch_data_4

    .line 1846
    :goto_a
    new-instance v2, Ljava/lang/StringBuilder;

    .line 1848
    invoke-static {v4}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string v3, " TL("

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    move-object/from16 v0, v34

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "#%d"

    const/4 v5, 0x1

    new-array v5, v5, [Ljava/lang/Object;

    const/4 v6, 0x0

    move-object/from16 v0, p0

    iget-object v7, v0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v7}, Lcom/thinkware/sundo/ieve/ieveNative;->GetCountNotifyTLCA()I

    move-result v7

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    aput-object v7, v5, v6

    invoke-static {v3, v5}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, ")"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    .line 1850
    .end local v34    # "resultTLCA":Ljava/lang/String;
    :cond_8
    const-string v38, "-"

    .line 1851
    .local v38, "stateGPS":Ljava/lang/String;
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v2}, Lcom/thinkware/sundo/ieve/ieveNative;->GetCarStatusGPS()I

    move-result v2

    packed-switch v2, :pswitch_data_5

    .line 1856
    :goto_b
    new-instance v3, Ljava/lang/StringBuilder;

    .line 1858
    invoke-static {v4}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    invoke-direct {v3, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string v5, " GPS:%s(%s)"

    const/4 v2, 0x2

    new-array v6, v2, [Ljava/lang/Object;

    const/4 v2, 0x0

    aput-object v38, v6, v2

    const/4 v7, 0x1

    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v2}, Lcom/thinkware/sundo/ieve/ieveNative;->GetCarShadowGPS()Z

    move-result v2

    if-eqz v2, :cond_12

    const-string v2, "x"

    :goto_c
    aput-object v2, v6, v7

    invoke-static {v5, v6}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    .line 1859
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v2}, Lcom/thinkware/sundo/ieve/ieveNative;->GetOBD2InfoGearMode()I

    move-result v2

    packed-switch v2, :pswitch_data_6

    .line 1864
    :pswitch_0
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-static {v4}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string v3, " GR(E)"

    const/4 v5, 0x0

    new-array v5, v5, [Ljava/lang/Object;

    invoke-static {v3, v5}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    .line 1866
    :goto_d
    const/4 v3, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/high16 v7, 0x41900000    # 18.0f

    const v8, -0xff0100

    move-object/from16 v2, p0

    invoke-virtual/range {v2 .. v8}, Lcom/thinkware/sundo/ieve/IEVE;->DebugPrint(ILjava/lang/String;FFFI)V

    .line 1870
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v2}, Lcom/thinkware/sundo/ieve/ieveNative;->GetRecogResultVP()I

    move-result v30

    .line 1871
    .local v30, "resultFindVP":I
    if-eqz v30, :cond_9

    .line 1872
    const-string v4, ""

    .line 1873
    packed-switch v30, :pswitch_data_7

    .line 1879
    :goto_e
    const/4 v3, 0x1

    const/high16 v5, 0x43960000    # 300.0f

    const/high16 v6, 0x41a00000    # 20.0f

    const/high16 v7, 0x42480000    # 50.0f

    const/high16 v8, -0x10000

    move-object/from16 v2, p0

    invoke-virtual/range {v2 .. v8}, Lcom/thinkware/sundo/ieve/IEVE;->DebugPrint(ILjava/lang/String;FFFI)V

    .line 1884
    :cond_9
    const-string v4, ""

    .line 1886
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v2}, Lcom/thinkware/sundo/ieve/ieveNative;->GetHistoryRecogLDWS()[I

    move-result-object v22

    .line 1887
    .local v22, "historyRecogLDWS":[I
    if-eqz v22, :cond_c

    .line 1888
    const/4 v2, 0x4

    move-object/from16 v0, p0

    invoke-virtual {v0, v2}, Lcom/thinkware/sundo/ieve/IEVE;->getLastRecog(I)I

    move-result v24

    .line 1889
    .local v24, "lastRecogPLCA":I
    packed-switch v24, :pswitch_data_8

    .line 1893
    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "Lane: N "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    move-object/from16 v0, v22

    array-length v3, v0

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "["

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    .line 1895
    :goto_f
    if-eqz v22, :cond_a

    .line 1896
    move-object/from16 v0, v22

    array-length v2, v0

    add-int/lit8 v23, v2, -0x1

    .local v23, "i":I
    :goto_10
    if-gez v23, :cond_13

    .line 1906
    .end local v23    # "i":I
    :cond_a
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-static {v4}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string v3, " / "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    .line 1908
    if-eqz v22, :cond_b

    .line 1909
    move-object/from16 v0, v22

    array-length v2, v0

    add-int/lit8 v23, v2, -0x1

    .restart local v23    # "i":I
    :goto_11
    if-gez v23, :cond_14

    .line 1918
    .end local v23    # "i":I
    :cond_b
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-static {v4}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string v3, "]"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    .line 1920
    .end local v24    # "lastRecogPLCA":I
    :cond_c
    const/16 v3, 0x3ef

    const/4 v5, 0x0

    const/high16 v6, 0x43660000    # 230.0f

    const/high16 v7, 0x41a00000    # 20.0f

    const v8, -0xff0100

    move-object/from16 v2, p0

    invoke-virtual/range {v2 .. v8}, Lcom/thinkware/sundo/ieve/IEVE;->DebugPrint(ILjava/lang/String;FFFI)V

    .line 1943
    move-object/from16 v0, p0

    iget v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->G:I

    packed-switch v2, :pswitch_data_9

    .line 1954
    const/16 v6, 0x321

    const-string v7, ""

    const/high16 v8, 0x44800000    # 1024.0f

    const/high16 v9, 0x42700000    # 60.0f

    const/high16 v10, 0x41f00000    # 30.0f

    const/high16 v11, -0x10000

    move-object/from16 v5, p0

    invoke-virtual/range {v5 .. v11}, Lcom/thinkware/sundo/ieve/IEVE;->DebugPrint(ILjava/lang/String;FFFI)V

    .line 1957
    :goto_12
    move-object/from16 v0, p0

    iget v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->F:I

    packed-switch v2, :pswitch_data_a

    .line 1962
    const/16 v6, 0x322

    const-string v7, ""

    const/high16 v8, 0x44800000    # 1024.0f

    const/high16 v9, 0x42700000    # 60.0f

    const/high16 v10, 0x41f00000    # 30.0f

    const/high16 v11, -0x10000

    move-object/from16 v5, p0

    invoke-virtual/range {v5 .. v11}, Lcom/thinkware/sundo/ieve/IEVE;->DebugPrint(ILjava/lang/String;FFFI)V

    .line 1965
    :goto_13
    move-object/from16 v0, p0

    iget v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->I:I

    packed-switch v2, :pswitch_data_b

    .line 1973
    const/16 v6, 0x323

    const-string v7, ""

    const/high16 v8, 0x44800000    # 1024.0f

    const/high16 v9, 0x42b40000    # 90.0f

    const/high16 v10, 0x41f00000    # 30.0f

    const/high16 v11, -0x10000

    move-object/from16 v5, p0

    invoke-virtual/range {v5 .. v11}, Lcom/thinkware/sundo/ieve/IEVE;->DebugPrint(ILjava/lang/String;FFFI)V

    .line 1976
    :goto_14
    move-object/from16 v0, p0

    iget v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->J:I

    packed-switch v2, :pswitch_data_c

    .line 1981
    const/16 v6, 0x324

    const-string v7, ""

    const/high16 v8, 0x44800000    # 1024.0f

    const/high16 v9, 0x42b40000    # 90.0f

    const/high16 v10, 0x41f00000    # 30.0f

    const/high16 v11, -0x10000

    move-object/from16 v5, p0

    invoke-virtual/range {v5 .. v11}, Lcom/thinkware/sundo/ieve/IEVE;->DebugPrint(ILjava/lang/String;FFFI)V

    .line 1987
    :goto_15
    const-string v2, "DalvikHeapMem(%s/%s)"

    const/4 v3, 0x2

    new-array v3, v3, [Ljava/lang/Object;

    const/4 v5, 0x0

    .line 1988
    invoke-static {}, Lcom/thinkware/sundo/ieve/ieveSystemStatus;->getRuntimeMemorySizeAllocated()J

    move-result-wide v6

    const/4 v9, 0x2

    invoke-static {v6, v7, v9}, Lcom/thinkware/sundo/ieve/ieveSystemStatus;->formatSize(JI)Ljava/lang/String;

    move-result-object v6

    aput-object v6, v3, v5

    const/4 v5, 0x1

    .line 1989
    invoke-static {}, Lcom/thinkware/sundo/ieve/ieveSystemStatus;->getRuntimeMemorySizeMax()J

    move-result-wide v6

    const/4 v9, 0x2

    invoke-static {v6, v7, v9}, Lcom/thinkware/sundo/ieve/ieveSystemStatus;->formatSize(JI)Ljava/lang/String;

    move-result-object v6

    aput-object v6, v3, v5

    .line 1987
    invoke-static {v2, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    .line 1990
    const/16 v3, 0x3fd

    const/high16 v5, 0x43c00000    # 384.0f

    const/high16 v6, 0x43f00000    # 480.0f

    const/high16 v7, 0x41900000    # 18.0f

    move-object/from16 v2, p0

    invoke-virtual/range {v2 .. v7}, Lcom/thinkware/sundo/ieve/IEVE;->DebugPrint(ILjava/lang/String;FFF)V

    .line 1993
    const-string v2, "NativeHeapMem(%s/%s)"

    const/4 v3, 0x2

    new-array v3, v3, [Ljava/lang/Object;

    const/4 v5, 0x0

    .line 1994
    invoke-static {}, Lcom/thinkware/sundo/ieve/ieveSystemStatus;->getNativeHeapMemorySizeAllocated()J

    move-result-wide v6

    const/4 v9, 0x2

    invoke-static {v6, v7, v9}, Lcom/thinkware/sundo/ieve/ieveSystemStatus;->formatSize(JI)Ljava/lang/String;

    move-result-object v6

    aput-object v6, v3, v5

    const/4 v5, 0x1

    .line 1995
    invoke-static {}, Lcom/thinkware/sundo/ieve/ieveSystemStatus;->getNativeHeapMemorySizeTotal()J

    move-result-wide v6

    const/4 v9, 0x2

    invoke-static {v6, v7, v9}, Lcom/thinkware/sundo/ieve/ieveSystemStatus;->formatSize(JI)Ljava/lang/String;

    move-result-object v6

    aput-object v6, v3, v5

    .line 1993
    invoke-static {v2, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    .line 1996
    const/16 v3, 0x3fe

    const/high16 v5, 0x43c00000    # 384.0f

    const/high16 v6, 0x43fa0000    # 500.0f

    const/high16 v7, 0x41900000    # 18.0f

    move-object/from16 v2, p0

    invoke-virtual/range {v2 .. v7}, Lcom/thinkware/sundo/ieve/IEVE;->DebugPrint(ILjava/lang/String;FFF)V

    .line 2001
    const/high16 v8, 0x44400000    # 768.0f

    .line 2002
    .local v8, "shiftX":F
    invoke-virtual/range {p0 .. p0}, Lcom/thinkware/sundo/ieve/IEVE;->getStatus()I

    move-result v39

    .line 2003
    .local v39, "status":I
    if-eqz v39, :cond_d

    and-int/lit8 v2, v39, 0x10

    const/16 v3, 0x10

    if-eq v2, v3, :cond_d

    and-int/lit8 v2, v39, 0x20

    const/16 v3, 0x20

    if-eq v2, v3, :cond_d

    .line 2004
    invoke-virtual/range {p0 .. p0}, Lcom/thinkware/sundo/ieve/IEVE;->getCarSpeedK()I

    move-result v36

    .line 2005
    .local v36, "speedk":I
    invoke-virtual/range {p0 .. p0}, Lcom/thinkware/sundo/ieve/IEVE;->getCarSpeedKDummyDR()I

    move-result v37

    .line 2007
    .local v37, "speedkdr":I
    const/16 v6, 0xa

    const-string v2, "RG:(%.1f)%.1fms"

    const/4 v3, 0x2

    new-array v3, v3, [Ljava/lang/Object;

    const/4 v5, 0x0

    const/16 v7, 0x10

    move-object/from16 v0, p0

    invoke-virtual {v0, v7}, Lcom/thinkware/sundo/ieve/IEVE;->getProcessingTime(I)D

    move-result-wide v10

    invoke-static {v10, v11}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v7

    aput-object v7, v3, v5

    const/4 v5, 0x1

    const/4 v7, 0x0

    move-object/from16 v0, p0

    invoke-virtual {v0, v7}, Lcom/thinkware/sundo/ieve/IEVE;->getProcessingTime(I)D

    move-result-wide v10

    invoke-static {v10, v11}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v7

    aput-object v7, v3, v5

    invoke-static {v2, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v7

    const/high16 v9, 0x437a0000    # 250.0f

    const/high16 v10, 0x41b00000    # 22.0f

    const v11, -0xff0100

    move-object/from16 v5, p0

    invoke-virtual/range {v5 .. v11}, Lcom/thinkware/sundo/ieve/IEVE;->DebugPrint(ILjava/lang/String;FFFI)V

    .line 2008
    const/16 v6, 0xb

    const-string v2, "IM:(%.1f)%.1fms"

    const/4 v3, 0x2

    new-array v3, v3, [Ljava/lang/Object;

    const/4 v5, 0x0

    const/16 v7, 0x11

    move-object/from16 v0, p0

    invoke-virtual {v0, v7}, Lcom/thinkware/sundo/ieve/IEVE;->getProcessingTime(I)D

    move-result-wide v10

    invoke-static {v10, v11}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v7

    aput-object v7, v3, v5

    const/4 v5, 0x1

    const/4 v7, 0x1

    move-object/from16 v0, p0

    invoke-virtual {v0, v7}, Lcom/thinkware/sundo/ieve/IEVE;->getProcessingTime(I)D

    move-result-wide v10

    invoke-static {v10, v11}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v7

    aput-object v7, v3, v5

    invoke-static {v2, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v7

    const v9, 0x43898000    # 275.0f

    const/high16 v10, 0x41b00000    # 22.0f

    const v11, -0xff0100

    move-object/from16 v5, p0

    invoke-virtual/range {v5 .. v11}, Lcom/thinkware/sundo/ieve/IEVE;->DebugPrint(ILjava/lang/String;FFFI)V

    .line 2010
    const/16 v6, 0xc

    const-string v2, "FC:(SV)%.1fms"

    const/4 v3, 0x1

    new-array v3, v3, [Ljava/lang/Object;

    const/4 v5, 0x0

    move-object/from16 v0, p0

    iget-object v7, v0, Lcom/thinkware/sundo/ieve/IEVE;->d:Lcom/stradvision/pdvdtest/SV_ADAS;

    invoke-virtual {v7}, Lcom/stradvision/pdvdtest/SV_ADAS;->GetProcTimePDVD()F

    move-result v7

    invoke-static {v7}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v7

    aput-object v7, v3, v5

    invoke-static {v2, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v7

    const/high16 v9, 0x43960000    # 300.0f

    const/high16 v10, 0x41b00000    # 22.0f

    const v11, -0xff0100

    move-object/from16 v5, p0

    invoke-virtual/range {v5 .. v11}, Lcom/thinkware/sundo/ieve/IEVE;->DebugPrint(ILjava/lang/String;FFFI)V

    .line 2012
    const/16 v6, 0xd

    const-string v2, "FV:(%.1f)%.1fms"

    const/4 v3, 0x2

    new-array v3, v3, [Ljava/lang/Object;

    const/4 v5, 0x0

    const/16 v7, 0x14

    move-object/from16 v0, p0

    invoke-virtual {v0, v7}, Lcom/thinkware/sundo/ieve/IEVE;->getProcessingTime(I)D

    move-result-wide v10

    invoke-static {v10, v11}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v7

    aput-object v7, v3, v5

    const/4 v5, 0x1

    const/4 v7, 0x4

    move-object/from16 v0, p0

    invoke-virtual {v0, v7}, Lcom/thinkware/sundo/ieve/IEVE;->getProcessingTime(I)D

    move-result-wide v10

    invoke-static {v10, v11}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v7

    aput-object v7, v3, v5

    invoke-static {v2, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v7

    const v9, 0x43a28000    # 325.0f

    const/high16 v10, 0x41b00000    # 22.0f

    const v11, -0xff0100

    move-object/from16 v5, p0

    invoke-virtual/range {v5 .. v11}, Lcom/thinkware/sundo/ieve/IEVE;->DebugPrint(ILjava/lang/String;FFFI)V

    .line 2013
    const/16 v6, 0xe

    const-string v2, "LD:(%.1f)%.1fms"

    const/4 v3, 0x2

    new-array v3, v3, [Ljava/lang/Object;

    const/4 v5, 0x0

    const/16 v7, 0x15

    move-object/from16 v0, p0

    invoke-virtual {v0, v7}, Lcom/thinkware/sundo/ieve/IEVE;->getProcessingTime(I)D

    move-result-wide v10

    invoke-static {v10, v11}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v7

    aput-object v7, v3, v5

    const/4 v5, 0x1

    const/4 v7, 0x5

    move-object/from16 v0, p0

    invoke-virtual {v0, v7}, Lcom/thinkware/sundo/ieve/IEVE;->getProcessingTime(I)D

    move-result-wide v10

    invoke-static {v10, v11}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v7

    aput-object v7, v3, v5

    invoke-static {v2, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v7

    const/high16 v9, 0x43af0000    # 350.0f

    const/high16 v10, 0x41b00000    # 22.0f

    const v11, -0xff0100

    move-object/from16 v5, p0

    invoke-virtual/range {v5 .. v11}, Lcom/thinkware/sundo/ieve/IEVE;->DebugPrint(ILjava/lang/String;FFFI)V

    .line 2014
    const/16 v6, 0xf

    const-string v2, "TL:(%.1f)%.1fms"

    const/4 v3, 0x2

    new-array v3, v3, [Ljava/lang/Object;

    const/4 v5, 0x0

    const/16 v7, 0x16

    move-object/from16 v0, p0

    invoke-virtual {v0, v7}, Lcom/thinkware/sundo/ieve/IEVE;->getProcessingTime(I)D

    move-result-wide v10

    invoke-static {v10, v11}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v7

    aput-object v7, v3, v5

    const/4 v5, 0x1

    const/4 v7, 0x6

    move-object/from16 v0, p0

    invoke-virtual {v0, v7}, Lcom/thinkware/sundo/ieve/IEVE;->getProcessingTime(I)D

    move-result-wide v10

    invoke-static {v10, v11}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v7

    aput-object v7, v3, v5

    invoke-static {v2, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v7

    const v9, 0x43bb8000    # 375.0f

    const/high16 v10, 0x41b00000    # 22.0f

    const v11, -0xff0100

    move-object/from16 v5, p0

    invoke-virtual/range {v5 .. v11}, Lcom/thinkware/sundo/ieve/IEVE;->DebugPrint(ILjava/lang/String;FFFI)V

    .line 2015
    const/16 v6, 0x10

    const-string v2, "VP:%.1fms"

    const/4 v3, 0x1

    new-array v3, v3, [Ljava/lang/Object;

    const/4 v5, 0x0

    const/4 v7, 0x3

    move-object/from16 v0, p0

    invoke-virtual {v0, v7}, Lcom/thinkware/sundo/ieve/IEVE;->getProcessingTime(I)D

    move-result-wide v10

    invoke-static {v10, v11}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v7

    aput-object v7, v3, v5

    invoke-static {v2, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v7

    const/high16 v9, 0x43c80000    # 400.0f

    const/high16 v10, 0x41b00000    # 22.0f

    const v11, -0xff0100

    move-object/from16 v5, p0

    invoke-virtual/range {v5 .. v11}, Lcom/thinkware/sundo/ieve/IEVE;->DebugPrint(ILjava/lang/String;FFFI)V

    .line 2016
    const/16 v6, 0x11

    const-string v2, "DR:%.1fms"

    const/4 v3, 0x1

    new-array v3, v3, [Ljava/lang/Object;

    const/4 v5, 0x0

    const/4 v7, 0x2

    move-object/from16 v0, p0

    invoke-virtual {v0, v7}, Lcom/thinkware/sundo/ieve/IEVE;->getProcessingTime(I)D

    move-result-wide v10

    invoke-static {v10, v11}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v7

    aput-object v7, v3, v5

    invoke-static {v2, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v7

    const v9, 0x43d48000    # 425.0f

    const/high16 v10, 0x41b00000    # 22.0f

    const v11, -0xff0100

    move-object/from16 v5, p0

    invoke-virtual/range {v5 .. v11}, Lcom/thinkware/sundo/ieve/IEVE;->DebugPrint(ILjava/lang/String;FFFI)V

    .line 2018
    const/16 v10, 0x384

    const-string v2, "%.1f(%.1f)km/h"

    const/4 v3, 0x2

    new-array v3, v3, [Ljava/lang/Object;

    const/4 v5, 0x0

    move/from16 v0, v36

    int-to-float v6, v0

    const/high16 v7, 0x41200000    # 10.0f

    div-float/2addr v6, v7

    invoke-static {v6}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v6

    aput-object v6, v3, v5

    const/4 v5, 0x1

    move/from16 v0, v37

    int-to-float v6, v0

    const/high16 v7, 0x41200000    # 10.0f

    div-float/2addr v6, v7

    invoke-static {v6}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v6

    aput-object v6, v3, v5

    invoke-static {v2, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    const/4 v3, 0x0

    new-array v3, v3, [Ljava/lang/Object;

    invoke-static {v2, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v11

    const/high16 v12, 0x43960000    # 300.0f

    const/high16 v13, 0x42c80000    # 100.0f

    const/high16 v14, 0x42100000    # 36.0f

    if-nez v37, :cond_15

    const v15, -0xff0100

    :goto_16
    const/16 v16, 0x1

    const/16 v17, 0x0

    const/16 v18, 0x0

    const/16 v19, 0x2

    const/16 v20, 0x0

    const/16 v21, 0x0

    move-object/from16 v9, p0

    invoke-virtual/range {v9 .. v21}, Lcom/thinkware/sundo/ieve/IEVE;->DebugPrint(ILjava/lang/String;FFFIZZZIILandroid/graphics/Typeface;)V

    .line 2021
    .end local v4    # "dbgtxt":Ljava/lang/String;
    .end local v8    # "shiftX":F
    .end local v22    # "historyRecogLDWS":[I
    .end local v25    # "now":Ljava/util/Date;
    .end local v30    # "resultFindVP":I
    .end local v36    # "speedk":I
    .end local v37    # "speedkdr":I
    .end local v38    # "stateGPS":Ljava/lang/String;
    .end local v39    # "status":I
    :cond_d
    const/4 v2, 0x0

    move-object/from16 v0, p0

    iput-boolean v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->B:Z

    goto/16 :goto_0

    .line 1771
    .restart local v4    # "dbgtxt":Ljava/lang/String;
    .restart local v25    # "now":Ljava/util/Date;
    :cond_e
    const-string v2, "F"

    goto/16 :goto_1

    :cond_f
    const-string v2, "F"

    goto/16 :goto_2

    .line 1779
    :cond_10
    const-string v2, "F"

    goto/16 :goto_3

    .line 1780
    :cond_11
    const-string v2, "F"

    goto/16 :goto_4

    .line 1785
    .restart local v31    # "resultLDWS":Ljava/lang/String;
    :sswitch_0
    const-string v31, "RD"

    goto/16 :goto_5

    .line 1786
    :sswitch_1
    const-string v31, "LT"

    goto/16 :goto_5

    .line 1787
    :sswitch_2
    const-string v31, "LB"

    goto/16 :goto_5

    .line 1788
    :sswitch_3
    const-string v31, "RT"

    goto/16 :goto_5

    .line 1789
    :sswitch_4
    const-string v31, "RB"

    goto/16 :goto_5

    .line 1790
    :sswitch_5
    const-string v31, "WD"

    goto/16 :goto_5

    .line 1791
    :sswitch_6
    const-string v31, "ED"

    goto/16 :goto_5

    .line 1799
    .end local v31    # "resultLDWS":Ljava/lang/String;
    .restart local v33    # "resultPLCA":Ljava/lang/String;
    :pswitch_1
    const-string v33, "L"

    goto/16 :goto_6

    .line 1800
    :pswitch_2
    const-string v33, "R"

    goto/16 :goto_6

    .line 1801
    :pswitch_3
    const-string v33, "S"

    goto/16 :goto_6

    .line 1809
    .end local v33    # "resultPLCA":Ljava/lang/String;
    .restart local v28    # "resultFCWS":Ljava/lang/String;
    :pswitch_4
    const-string v28, "R"

    goto/16 :goto_7

    .line 1810
    :pswitch_5
    const-string v28, "D"

    goto/16 :goto_7

    .line 1811
    :pswitch_6
    const-string v28, "A"

    goto/16 :goto_7

    .line 1812
    :pswitch_7
    const-string v28, "W"

    goto/16 :goto_7

    .line 1813
    :pswitch_8
    const-string v28, "E"

    goto/16 :goto_7

    .line 1821
    .end local v28    # "resultFCWS":Ljava/lang/String;
    .restart local v32    # "resultPCWS":Ljava/lang/String;
    :pswitch_9
    const-string v32, "R"

    goto/16 :goto_8

    .line 1822
    :pswitch_a
    const-string v32, "D"

    goto/16 :goto_8

    .line 1823
    :pswitch_b
    const-string v32, "A"

    goto/16 :goto_8

    .line 1824
    :pswitch_c
    const-string v32, "W"

    goto/16 :goto_8

    .line 1825
    :pswitch_d
    const-string v32, "E"

    goto/16 :goto_8

    .line 1833
    .end local v32    # "resultPCWS":Ljava/lang/String;
    .restart local v29    # "resultFVSA":Ljava/lang/String;
    :pswitch_e
    const-string v29, "R"

    goto/16 :goto_9

    .line 1834
    :pswitch_f
    const-string v29, "G"

    goto/16 :goto_9

    .line 1835
    :pswitch_10
    const-string v29, "E"

    goto/16 :goto_9

    .line 1843
    .end local v29    # "resultFVSA":Ljava/lang/String;
    .restart local v34    # "resultTLCA":Ljava/lang/String;
    :pswitch_11
    const-string v34, "R"

    goto/16 :goto_a

    .line 1844
    :pswitch_12
    const-string v34, "G"

    goto/16 :goto_a

    .line 1845
    :pswitch_13
    const-string v34, "E"

    goto/16 :goto_a

    .line 1852
    .end local v34    # "resultTLCA":Ljava/lang/String;
    .restart local v38    # "stateGPS":Ljava/lang/String;
    :pswitch_14
    const-string v38, "Nr"

    goto/16 :goto_b

    .line 1853
    :pswitch_15
    const-string v38, "Ov"

    goto/16 :goto_b

    .line 1854
    :pswitch_16
    const-string v38, "Un"

    goto/16 :goto_b

    .line 1855
    :pswitch_17
    const-string v38, "Tn"

    goto/16 :goto_b

    .line 1858
    :cond_12
    const-string v2, "o"

    goto/16 :goto_c

    .line 1860
    :pswitch_18
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-static {v4}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string v3, " GR(P)"

    const/4 v5, 0x0

    new-array v5, v5, [Ljava/lang/Object;

    invoke-static {v3, v5}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    goto/16 :goto_d

    .line 1861
    :pswitch_19
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-static {v4}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string v3, " GR(D)"

    const/4 v5, 0x0

    new-array v5, v5, [Ljava/lang/Object;

    invoke-static {v3, v5}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    goto/16 :goto_d

    .line 1862
    :pswitch_1a
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-static {v4}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string v3, " GR(N)"

    const/4 v5, 0x0

    new-array v5, v5, [Ljava/lang/Object;

    invoke-static {v3, v5}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    goto/16 :goto_d

    .line 1863
    :pswitch_1b
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-static {v4}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string v3, " GR(R)"

    const/4 v5, 0x0

    new-array v5, v5, [Ljava/lang/Object;

    invoke-static {v3, v5}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    goto/16 :goto_d

    .line 1874
    .restart local v30    # "resultFindVP":I
    :pswitch_1c
    const-string v2, "VP(Finding...)"

    const/4 v3, 0x0

    new-array v3, v3, [Ljava/lang/Object;

    invoke-static {v2, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    goto/16 :goto_e

    .line 1875
    :pswitch_1d
    const-string v2, "VP(Not Found)"

    const/4 v3, 0x0

    new-array v3, v3, [Ljava/lang/Object;

    invoke-static {v2, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    goto/16 :goto_e

    .line 1876
    :pswitch_1e
    const-string v2, "VP(Found)"

    const/4 v3, 0x0

    new-array v3, v3, [Ljava/lang/Object;

    invoke-static {v2, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    goto/16 :goto_e

    .line 1890
    .restart local v22    # "historyRecogLDWS":[I
    .restart local v24    # "lastRecogPLCA":I
    :pswitch_1f
    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "Lane: L "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    move-object/from16 v0, v22

    array-length v3, v0

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "["

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    goto/16 :goto_f

    .line 1891
    :pswitch_20
    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "Lane: R "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    move-object/from16 v0, v22

    array-length v3, v0

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "["

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    goto/16 :goto_f

    .line 1892
    :pswitch_21
    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "Lane: M "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    move-object/from16 v0, v22

    array-length v3, v0

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "["

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    goto/16 :goto_f

    .line 1897
    .restart local v23    # "i":I
    :cond_13
    aget v2, v22, v23

    shr-int/lit8 v2, v2, 0x0

    and-int/lit8 v26, v2, 0x3

    .line 1898
    .local v26, "plt":I
    packed-switch v26, :pswitch_data_d

    .line 1901
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-static {v4}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string v3, "-"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    .line 1896
    :goto_17
    add-int/lit8 v23, v23, -0x1

    goto/16 :goto_10

    .line 1899
    :pswitch_22
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-static {v4}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string v3, ":"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    goto :goto_17

    .line 1900
    :pswitch_23
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-static {v4}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string v3, "|"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    goto :goto_17

    .line 1910
    .end local v26    # "plt":I
    :cond_14
    aget v2, v22, v23

    shr-int/lit8 v2, v2, 0x8

    and-int/lit8 v27, v2, 0x3

    .line 1911
    .local v27, "prt":I
    packed-switch v27, :pswitch_data_e

    .line 1914
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-static {v4}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string v3, "-"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    .line 1909
    :goto_18
    add-int/lit8 v23, v23, -0x1

    goto/16 :goto_11

    .line 1912
    :pswitch_24
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-static {v4}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string v3, ":"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    goto :goto_18

    .line 1913
    :pswitch_25
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-static {v4}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string v3, "|"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    goto :goto_18

    .line 1945
    .end local v23    # "i":I
    .end local v24    # "lastRecogPLCA":I
    .end local v27    # "prt":I
    :pswitch_26
    const/16 v6, 0x321

    const-string v7, "Left Lane Departure"

    const/high16 v8, 0x44800000    # 1024.0f

    const/high16 v9, 0x42700000    # 60.0f

    const/high16 v10, 0x41f00000    # 30.0f

    const/16 v11, -0x100

    const/4 v12, 0x1

    const/4 v13, 0x0

    const/4 v14, 0x0

    const/4 v15, 0x2

    const/16 v16, 0x0

    const/16 v17, 0x0

    move-object/from16 v5, p0

    invoke-virtual/range {v5 .. v17}, Lcom/thinkware/sundo/ieve/IEVE;->DebugPrint(ILjava/lang/String;FFFIZZZIILandroid/graphics/Typeface;)V

    goto/16 :goto_12

    .line 1948
    :pswitch_27
    const/16 v6, 0x321

    const-string v7, "Left Lane Departure"

    const/high16 v8, 0x44800000    # 1024.0f

    const/high16 v9, 0x42700000    # 60.0f

    const/high16 v10, 0x41f00000    # 30.0f

    const/high16 v11, -0x10000

    const/4 v12, 0x1

    const/4 v13, 0x0

    const/4 v14, 0x0

    const/4 v15, 0x2

    const/16 v16, 0x0

    const/16 v17, 0x0

    move-object/from16 v5, p0

    invoke-virtual/range {v5 .. v17}, Lcom/thinkware/sundo/ieve/IEVE;->DebugPrint(ILjava/lang/String;FFFIZZZIILandroid/graphics/Typeface;)V

    goto/16 :goto_12

    .line 1951
    :pswitch_28
    const/16 v6, 0x321

    const-string v7, "Right Lane Departure"

    const/high16 v8, 0x44800000    # 1024.0f

    const/high16 v9, 0x42700000    # 60.0f

    const/high16 v10, 0x41f00000    # 30.0f

    const/high16 v11, -0x10000

    const/4 v12, 0x1

    const/4 v13, 0x0

    const/4 v14, 0x0

    const/4 v15, 0x2

    const/16 v16, 0x0

    const/16 v17, 0x0

    move-object/from16 v5, p0

    invoke-virtual/range {v5 .. v17}, Lcom/thinkware/sundo/ieve/IEVE;->DebugPrint(ILjava/lang/String;FFFIZZZIILandroid/graphics/Typeface;)V

    goto/16 :goto_12

    .line 1959
    :pswitch_29
    const/16 v6, 0x322

    const-string v7, "Car GO!"

    const/high16 v8, 0x44800000    # 1024.0f

    const/high16 v9, 0x42700000    # 60.0f

    const/high16 v10, 0x41f00000    # 30.0f

    const v11, -0xff0100

    const/4 v12, 0x1

    const/4 v13, 0x0

    const/4 v14, 0x0

    const/4 v15, 0x2

    const/16 v16, 0x0

    const/16 v17, 0x0

    move-object/from16 v5, p0

    invoke-virtual/range {v5 .. v17}, Lcom/thinkware/sundo/ieve/IEVE;->DebugPrint(ILjava/lang/String;FFFIZZZIILandroid/graphics/Typeface;)V

    goto/16 :goto_13

    .line 1967
    :pswitch_2a
    const/16 v6, 0x323

    const-string v7, "Change lane to left!"

    const/high16 v8, 0x44800000    # 1024.0f

    const/high16 v9, 0x42b40000    # 90.0f

    const/high16 v10, 0x41f00000    # 30.0f

    const v11, -0xff0100

    const/4 v12, 0x1

    const/4 v13, 0x0

    const/4 v14, 0x0

    const/4 v15, 0x2

    const/16 v16, 0x0

    const/16 v17, 0x0

    move-object/from16 v5, p0

    invoke-virtual/range {v5 .. v17}, Lcom/thinkware/sundo/ieve/IEVE;->DebugPrint(ILjava/lang/String;FFFIZZZIILandroid/graphics/Typeface;)V

    goto/16 :goto_14

    .line 1970
    :pswitch_2b
    const/16 v6, 0x323

    const-string v7, "Change lane to Right!"

    const/high16 v8, 0x44800000    # 1024.0f

    const/high16 v9, 0x42b40000    # 90.0f

    const/high16 v10, 0x41f00000    # 30.0f

    const v11, -0xff0100

    const/4 v12, 0x1

    const/4 v13, 0x0

    const/4 v14, 0x0

    const/4 v15, 0x2

    const/16 v16, 0x0

    const/16 v17, 0x0

    move-object/from16 v5, p0

    invoke-virtual/range {v5 .. v17}, Lcom/thinkware/sundo/ieve/IEVE;->DebugPrint(ILjava/lang/String;FFFIZZZIILandroid/graphics/Typeface;)V

    goto/16 :goto_14

    .line 1978
    :pswitch_2c
    const/16 v6, 0x324

    const-string v7, "Traffic Signal Green!"

    const/high16 v8, 0x44800000    # 1024.0f

    const/high16 v9, 0x42b40000    # 90.0f

    const/high16 v10, 0x41f00000    # 30.0f

    const v11, -0xff0100

    const/4 v12, 0x1

    const/4 v13, 0x0

    const/4 v14, 0x0

    const/4 v15, 0x2

    const/16 v16, 0x0

    const/16 v17, 0x0

    move-object/from16 v5, p0

    invoke-virtual/range {v5 .. v17}, Lcom/thinkware/sundo/ieve/IEVE;->DebugPrint(ILjava/lang/String;FFFIZZZIILandroid/graphics/Typeface;)V

    goto/16 :goto_15

    .line 2018
    .restart local v8    # "shiftX":F
    .restart local v36    # "speedk":I
    .restart local v37    # "speedkdr":I
    .restart local v39    # "status":I
    :cond_15
    const/high16 v15, -0x10000

    goto/16 :goto_16

    .line 1784
    :sswitch_data_0
    .sparse-switch
        0x8101 -> :sswitch_0
        0x8102 -> :sswitch_1
        0x8103 -> :sswitch_3
        0x8104 -> :sswitch_2
        0x8105 -> :sswitch_4
        0x8110 -> :sswitch_5
        0x8120 -> :sswitch_6
    .end sparse-switch

    .line 1798
    :pswitch_data_0
    .packed-switch 0x8311
        :pswitch_1
        :pswitch_2
        :pswitch_3
    .end packed-switch

    .line 1808
    :pswitch_data_1
    .packed-switch 0x8501
        :pswitch_4
        :pswitch_5
        :pswitch_6
        :pswitch_7
        :pswitch_8
    .end packed-switch

    .line 1820
    :pswitch_data_2
    .packed-switch 0x8701
        :pswitch_9
        :pswitch_a
        :pswitch_b
        :pswitch_c
        :pswitch_d
    .end packed-switch

    .line 1832
    :pswitch_data_3
    .packed-switch 0x8201
        :pswitch_e
        :pswitch_f
        :pswitch_10
    .end packed-switch

    .line 1842
    :pswitch_data_4
    .packed-switch 0x8401
        :pswitch_11
        :pswitch_12
        :pswitch_13
    .end packed-switch

    .line 1851
    :pswitch_data_5
    .packed-switch 0x0
        :pswitch_14
        :pswitch_15
        :pswitch_16
        :pswitch_17
    .end packed-switch

    .line 1859
    :pswitch_data_6
    .packed-switch 0x0
        :pswitch_18
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_19
        :pswitch_1a
        :pswitch_1b
    .end packed-switch

    .line 1873
    :pswitch_data_7
    .packed-switch 0x6011
        :pswitch_1e
        :pswitch_1c
        :pswitch_1d
    .end packed-switch

    .line 1889
    :pswitch_data_8
    .packed-switch 0x8301
        :pswitch_1f
        :pswitch_20
        :pswitch_21
    .end packed-switch

    .line 1943
    :pswitch_data_9
    .packed-switch 0x8102
        :pswitch_27
        :pswitch_28
        :pswitch_26
    .end packed-switch

    .line 1957
    :pswitch_data_a
    .packed-switch 0x8202
        :pswitch_29
    .end packed-switch

    .line 1965
    :pswitch_data_b
    .packed-switch 0x8311
        :pswitch_2a
        :pswitch_2b
    .end packed-switch

    .line 1976
    :pswitch_data_c
    .packed-switch 0x8402
        :pswitch_2c
    .end packed-switch

    .line 1898
    :pswitch_data_d
    .packed-switch 0x1
        :pswitch_22
        :pswitch_23
    .end packed-switch

    .line 1911
    :pswitch_data_e
    .packed-switch 0x1
        :pswitch_24
        :pswitch_25
    .end packed-switch
.end method

.method static synthetic a(Lcom/thinkware/sundo/ieve/IEVE;)Landroid/os/Handler;
    .locals 1

    .prologue
    .line 412
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->am:Landroid/os/Handler;

    return-object v0
.end method

.method private a()V
    .locals 2

    .prologue
    .line 414
    const-string v0, "java_IEVE"

    const-string v1, "createHandler"

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 415
    new-instance v0, Lcom/thinkware/sundo/ieve/IEVE$1;

    invoke-direct {v0, p0}, Lcom/thinkware/sundo/ieve/IEVE$1;-><init>(Lcom/thinkware/sundo/ieve/IEVE;)V

    iput-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->am:Landroid/os/Handler;

    .line 597
    return-void
.end method

.method private a(I)V
    .locals 1
    .param p1, "soundid"    # I

    .prologue
    .line 2038
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->T:Lcom/thinkware/sundo/ieve/ieveSoundManager;

    if-nez v0, :cond_0

    .line 2040
    :goto_0
    return-void

    .line 2039
    :cond_0
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->T:Lcom/thinkware/sundo/ieve/ieveSoundManager;

    invoke-virtual {v0, p1}, Lcom/thinkware/sundo/ieve/ieveSoundManager;->stopSound(I)V

    goto :goto_0
.end method

.method private a(IIZZZ)V
    .locals 7
    .param p1, "soundid"    # I
    .param p2, "soundlevel"    # I
    .param p3, "left"    # Z
    .param p4, "right"    # Z
    .param p5, "loop"    # Z

    .prologue
    .line 2027
    const/high16 v6, 0x3f800000    # 1.0f

    move-object v0, p0

    move v1, p1

    move v2, p2

    move v3, p3

    move v4, p4

    move v5, p5

    invoke-direct/range {v0 .. v6}, Lcom/thinkware/sundo/ieve/IEVE;->a(IIZZZF)V

    .line 2028
    return-void
.end method

.method private a(IIZZZF)V
    .locals 6
    .param p1, "soundid"    # I
    .param p2, "soundlevel"    # I
    .param p3, "left"    # Z
    .param p4, "right"    # Z
    .param p5, "loop"    # Z
    .param p6, "percent"    # F

    .prologue
    .line 2031
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->T:Lcom/thinkware/sundo/ieve/ieveSoundManager;

    if-nez v0, :cond_0

    .line 2034
    :goto_0
    return-void

    .line 2032
    :cond_0
    const/4 v0, -0x1

    if-eq p2, v0, :cond_1

    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->T:Lcom/thinkware/sundo/ieve/ieveSoundManager;

    invoke-virtual {v0, p2}, Lcom/thinkware/sundo/ieve/ieveSoundManager;->setSoundVolume(I)V

    .line 2033
    :cond_1
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->T:Lcom/thinkware/sundo/ieve/ieveSoundManager;

    move v1, p1

    move v2, p3

    move v3, p4

    move v4, p5

    move v5, p6

    invoke-virtual/range {v0 .. v5}, Lcom/thinkware/sundo/ieve/ieveSoundManager;->playSound(IZZZF)V

    goto :goto_0
.end method

.method static synthetic a(Lcom/thinkware/sundo/ieve/IEVE;I)V
    .locals 0

    .prologue
    .line 2727
    invoke-direct {p0, p1}, Lcom/thinkware/sundo/ieve/IEVE;->c(I)V

    return-void
.end method

.method static synthetic a(Lcom/thinkware/sundo/ieve/IEVE;IIZZZ)V
    .locals 0

    .prologue
    .line 2026
    invoke-direct/range {p0 .. p5}, Lcom/thinkware/sundo/ieve/IEVE;->a(IIZZZ)V

    return-void
.end method

.method static synthetic a(Lcom/thinkware/sundo/ieve/IEVE;IIZZZF)V
    .locals 0

    .prologue
    .line 2030
    invoke-direct/range {p0 .. p6}, Lcom/thinkware/sundo/ieve/IEVE;->a(IIZZZF)V

    return-void
.end method

.method static synthetic a(Lcom/thinkware/sundo/ieve/IEVE;Z)V
    .locals 0

    .prologue
    .line 335
    iput-boolean p1, p0, Lcom/thinkware/sundo/ieve/IEVE;->U:Z

    return-void
.end method

.method static synthetic b(Lcom/thinkware/sundo/ieve/IEVE;)Lcom/thinkware/sundo/ieve/ieveTextView;
    .locals 1

    .prologue
    .line 2867
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->at:Lcom/thinkware/sundo/ieve/ieveTextView;

    return-object v0
.end method

.method private b()V
    .locals 3

    .prologue
    const/4 v2, 0x0

    .line 600
    const-string v0, "java_IEVE"

    const-string v1, "destroyHandler"

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 601
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->am:Landroid/os/Handler;

    invoke-virtual {v0, v2}, Landroid/os/Handler;->removeCallbacksAndMessages(Ljava/lang/Object;)V

    .line 602
    iput-object v2, p0, Lcom/thinkware/sundo/ieve/IEVE;->am:Landroid/os/Handler;

    .line 603
    return-void
.end method

.method private b(I)V
    .locals 3
    .param p1, "mode"    # I

    .prologue
    .line 2721
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->am:Landroid/os/Handler;

    const/16 v2, 0x7ce

    invoke-static {v1, v2}, Landroid/os/Message;->obtain(Landroid/os/Handler;I)Landroid/os/Message;

    move-result-object v0

    .line 2722
    .local v0, "msg":Landroid/os/Message;
    iput p1, v0, Landroid/os/Message;->arg1:I

    .line 2723
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->am:Landroid/os/Handler;

    invoke-virtual {v1, v0}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    .line 2724
    return-void
.end method

.method static synthetic b(Lcom/thinkware/sundo/ieve/IEVE;I)V
    .locals 0

    .prologue
    .line 2720
    invoke-direct {p0, p1}, Lcom/thinkware/sundo/ieve/IEVE;->b(I)V

    return-void
.end method

.method static synthetic c(Lcom/thinkware/sundo/ieve/IEVE;)Landroid/os/Handler;
    .locals 1

    .prologue
    .line 31
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->c:Landroid/os/Handler;

    return-object v0
.end method

.method private c()V
    .locals 6

    .prologue
    .line 723
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->h:Lcom/thinkware/sundo/ieve/ieveARView;

    if-nez v0, :cond_0

    .line 724
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveARView;

    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->b:Landroid/content/Context;

    invoke-direct {v0, v1, p0}, Lcom/thinkware/sundo/ieve/ieveARView;-><init>(Landroid/content/Context;Lcom/thinkware/sundo/ieve/IEVE;)V

    iput-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->h:Lcom/thinkware/sundo/ieve/ieveARView;

    .line 725
    const-string v0, "java_IEVE"

    const-string v1, "createViewAR"

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 727
    :cond_0
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->g:Lcom/thinkware/sundo/ieve/ieveNScreenManager;

    const/16 v1, 0x1030

    iget-object v2, p0, Lcom/thinkware/sundo/ieve/IEVE;->h:Lcom/thinkware/sundo/ieve/ieveARView;

    iget-object v3, p0, Lcom/thinkware/sundo/ieve/IEVE;->x:Landroid/graphics/Rect;

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-virtual/range {v0 .. v5}, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->insertView(ILandroid/view/View;Landroid/graphics/Rect;ZI)Z

    .line 728
    return-void
.end method

.method private c(I)V
    .locals 9
    .param p1, "msg"    # I

    .prologue
    const/16 v8, 0x1040

    const/16 v7, 0x1030

    const/16 v1, 0x1010

    const/4 v6, 0x4

    const/4 v4, 0x0

    .line 2728
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->j:Lcom/thinkware/sundo/ieve/ieveCameraView;

    if-nez v0, :cond_1

    .line 2779
    :cond_0
    :goto_0
    return-void

    .line 2730
    :cond_1
    const/16 v0, 0x7100

    invoke-virtual {p0, v0}, Lcom/thinkware/sundo/ieve/IEVE;->getIEVEConfigValue(I)I

    .line 2731
    const/16 v0, 0x7101

    invoke-virtual {p0, v0}, Lcom/thinkware/sundo/ieve/IEVE;->getIEVEConfigValue(I)I

    .line 2732
    const/16 v0, 0x7102

    invoke-virtual {p0, v0}, Lcom/thinkware/sundo/ieve/IEVE;->getIEVEConfigValue(I)I

    .line 2733
    const/16 v0, 0x7200

    invoke-virtual {p0, v0}, Lcom/thinkware/sundo/ieve/IEVE;->getIEVEConfigValue(I)I

    .line 2735
    if-nez p1, :cond_2

    .line 2736
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->j:Lcom/thinkware/sundo/ieve/ieveCameraView;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveCameraView;->clearSnapshot()V

    .line 2737
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->g:Lcom/thinkware/sundo/ieve/ieveNScreenManager;

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->removeView(I)Z

    .line 2738
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->g:Lcom/thinkware/sundo/ieve/ieveNScreenManager;

    invoke-virtual {v0, v7, v6}, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->setVisibility(II)Z

    .line 2739
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->g:Lcom/thinkware/sundo/ieve/ieveNScreenManager;

    invoke-virtual {v0, v8, v6}, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->setVisibility(II)Z

    goto :goto_0

    .line 2742
    :cond_2
    and-int/lit8 v0, p1, 0x10

    const/16 v2, 0x10

    if-ne v0, v2, :cond_3

    .line 2743
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->v:Landroid/graphics/Rect;

    iget-object v2, p0, Lcom/thinkware/sundo/ieve/IEVE;->u:Landroid/graphics/Rect;

    invoke-virtual {v0, v2}, Landroid/graphics/Rect;->set(Landroid/graphics/Rect;)V

    .line 2744
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->j:Lcom/thinkware/sundo/ieve/ieveCameraView;

    const/4 v2, 0x1

    invoke-virtual {v0, v2}, Lcom/thinkware/sundo/ieve/ieveCameraView;->takeSnapshot(Z)Z

    .line 2745
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->g:Lcom/thinkware/sundo/ieve/ieveNScreenManager;

    iget-object v2, p0, Lcom/thinkware/sundo/ieve/IEVE;->j:Lcom/thinkware/sundo/ieve/ieveCameraView;

    iget-object v3, p0, Lcom/thinkware/sundo/ieve/IEVE;->v:Landroid/graphics/Rect;

    move v5, v4

    invoke-virtual/range {v0 .. v5}, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->insertView(ILandroid/view/View;Landroid/graphics/Rect;ZI)Z

    .line 2746
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->g:Lcom/thinkware/sundo/ieve/ieveNScreenManager;

    invoke-virtual {v0, v7, v6}, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->setVisibility(II)Z

    .line 2747
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->i:Lcom/thinkware/sundo/ieve/ieveCalibrationView;

    if-eqz v0, :cond_0

    .line 2748
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->g:Lcom/thinkware/sundo/ieve/ieveNScreenManager;

    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->u:Landroid/graphics/Rect;

    invoke-virtual {v0, v8, v1}, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->moveView(ILandroid/graphics/Rect;)Z

    .line 2749
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->i:Lcom/thinkware/sundo/ieve/ieveCalibrationView;

    invoke-virtual {v0, v4}, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->enableDrawCenterMark(Z)V

    .line 2750
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->i:Lcom/thinkware/sundo/ieve/ieveCalibrationView;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->updateRoiPoints()V

    goto :goto_0

    .line 2753
    :cond_3
    and-int/lit8 v0, p1, 0x20

    const/16 v2, 0x20

    if-ne v0, v2, :cond_4

    .line 2754
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->v:Landroid/graphics/Rect;

    iget-object v2, p0, Lcom/thinkware/sundo/ieve/IEVE;->u:Landroid/graphics/Rect;

    invoke-virtual {v0, v2}, Landroid/graphics/Rect;->set(Landroid/graphics/Rect;)V

    .line 2755
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->j:Lcom/thinkware/sundo/ieve/ieveCameraView;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveCameraView;->clearSnapshot()V

    .line 2756
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->g:Lcom/thinkware/sundo/ieve/ieveNScreenManager;

    iget-object v2, p0, Lcom/thinkware/sundo/ieve/IEVE;->j:Lcom/thinkware/sundo/ieve/ieveCameraView;

    iget-object v3, p0, Lcom/thinkware/sundo/ieve/IEVE;->v:Landroid/graphics/Rect;

    move v5, v4

    invoke-virtual/range {v0 .. v5}, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->insertView(ILandroid/view/View;Landroid/graphics/Rect;ZI)Z

    .line 2757
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->g:Lcom/thinkware/sundo/ieve/ieveNScreenManager;

    invoke-virtual {v0, v7, v6}, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->setVisibility(II)Z

    .line 2758
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->i:Lcom/thinkware/sundo/ieve/ieveCalibrationView;

    if-eqz v0, :cond_0

    .line 2759
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->g:Lcom/thinkware/sundo/ieve/ieveNScreenManager;

    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->u:Landroid/graphics/Rect;

    invoke-virtual {v0, v8, v1}, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->moveView(ILandroid/graphics/Rect;)Z

    .line 2760
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->i:Lcom/thinkware/sundo/ieve/ieveCalibrationView;

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->enableDrawCenterMark(Z)V

    .line 2761
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->i:Lcom/thinkware/sundo/ieve/ieveCalibrationView;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->updateRoiPoints()V

    goto/16 :goto_0

    .line 2765
    :cond_4
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->g:Lcom/thinkware/sundo/ieve/ieveNScreenManager;

    invoke-virtual {v0, v8, v6}, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->setVisibility(II)Z

    .line 2766
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->j:Lcom/thinkware/sundo/ieve/ieveCameraView;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveCameraView;->clearSnapshot()V

    .line 2767
    and-int/lit8 v0, p1, 0x1

    const/4 v2, 0x1

    if-ne v0, v2, :cond_5

    .line 2768
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->v:Landroid/graphics/Rect;

    iget-object v2, p0, Lcom/thinkware/sundo/ieve/IEVE;->t:Landroid/graphics/Rect;

    invoke-virtual {v0, v2}, Landroid/graphics/Rect;->set(Landroid/graphics/Rect;)V

    .line 2769
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->g:Lcom/thinkware/sundo/ieve/ieveNScreenManager;

    iget-object v2, p0, Lcom/thinkware/sundo/ieve/IEVE;->j:Lcom/thinkware/sundo/ieve/ieveCameraView;

    iget-object v3, p0, Lcom/thinkware/sundo/ieve/IEVE;->v:Landroid/graphics/Rect;

    move v5, v4

    invoke-virtual/range {v0 .. v5}, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->insertView(ILandroid/view/View;Landroid/graphics/Rect;ZI)Z

    .line 2770
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->g:Lcom/thinkware/sundo/ieve/ieveNScreenManager;

    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->x:Landroid/graphics/Rect;

    invoke-virtual {v0, v7, v1, v4}, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->moveView(ILandroid/graphics/Rect;I)Z

    goto/16 :goto_0

    .line 2773
    :cond_5
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->v:Landroid/graphics/Rect;

    iget-object v2, p0, Lcom/thinkware/sundo/ieve/IEVE;->w:Landroid/graphics/Rect;

    invoke-virtual {v0, v2}, Landroid/graphics/Rect;->set(Landroid/graphics/Rect;)V

    .line 2774
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->g:Lcom/thinkware/sundo/ieve/ieveNScreenManager;

    iget-object v2, p0, Lcom/thinkware/sundo/ieve/IEVE;->j:Lcom/thinkware/sundo/ieve/ieveCameraView;

    iget-object v3, p0, Lcom/thinkware/sundo/ieve/IEVE;->v:Landroid/graphics/Rect;

    move v5, v4

    invoke-virtual/range {v0 .. v5}, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->insertView(ILandroid/view/View;Landroid/graphics/Rect;ZI)Z

    .line 2775
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->g:Lcom/thinkware/sundo/ieve/ieveNScreenManager;

    invoke-virtual {v0, v7, v6}, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->setVisibility(II)Z

    goto/16 :goto_0
.end method

.method static synthetic c(Lcom/thinkware/sundo/ieve/IEVE;I)V
    .locals 0

    .prologue
    .line 2037
    invoke-direct {p0, p1}, Lcom/thinkware/sundo/ieve/IEVE;->a(I)V

    return-void
.end method

.method static synthetic d(Lcom/thinkware/sundo/ieve/IEVE;)Lcom/thinkware/sundo/ieve/ieveCameraView;
    .locals 1

    .prologue
    .line 48
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->j:Lcom/thinkware/sundo/ieve/ieveCameraView;

    return-object v0
.end method

.method private d()V
    .locals 7

    .prologue
    .line 732
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->an:Lcom/thinkware/sundo/ieve/IEVE$a;

    if-nez v0, :cond_0

    .line 733
    new-instance v0, Lcom/thinkware/sundo/ieve/IEVE$a;

    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->am:Landroid/os/Handler;

    invoke-direct {v0, p0, v1}, Lcom/thinkware/sundo/ieve/IEVE$a;-><init>(Lcom/thinkware/sundo/ieve/IEVE;Landroid/os/Handler;)V

    iput-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->an:Lcom/thinkware/sundo/ieve/IEVE$a;

    .line 735
    :cond_0
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->j:Lcom/thinkware/sundo/ieve/ieveCameraView;

    if-nez v0, :cond_1

    .line 736
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveCameraView;

    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->b:Landroid/content/Context;

    iget v2, p0, Lcom/thinkware/sundo/ieve/IEVE;->z:I

    iget v3, p0, Lcom/thinkware/sundo/ieve/IEVE;->A:I

    iget v4, p0, Lcom/thinkware/sundo/ieve/IEVE;->y:I

    iget-object v5, p0, Lcom/thinkware/sundo/ieve/IEVE;->an:Lcom/thinkware/sundo/ieve/IEVE$a;

    invoke-virtual {v5}, Lcom/thinkware/sundo/ieve/IEVE$a;->a()Landroid/os/Handler;

    move-result-object v5

    iget v6, p0, Lcom/thinkware/sundo/ieve/IEVE;->m:I

    invoke-direct/range {v0 .. v6}, Lcom/thinkware/sundo/ieve/ieveCameraView;-><init>(Landroid/content/Context;IIILandroid/os/Handler;I)V

    iput-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->j:Lcom/thinkware/sundo/ieve/ieveCameraView;

    .line 737
    const-string v0, "java_IEVE"

    const-string v1, "createViewCamera"

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 739
    :cond_1
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->j:Lcom/thinkware/sundo/ieve/ieveCameraView;

    iget v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->l:I

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/ieve/ieveCameraView;->setCameraModelType(I)V

    .line 740
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->j:Lcom/thinkware/sundo/ieve/ieveCameraView;

    iget v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->k:I

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/ieve/ieveCameraView;->setDeviceModelType(I)V

    .line 741
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->j:Lcom/thinkware/sundo/ieve/ieveCameraView;

    const-wide/high16 v2, 0x4028000000000000L    # 12.0

    invoke-virtual {v0, v2, v3}, Lcom/thinkware/sundo/ieve/ieveCameraView;->setPreviewCallbackMaxFPS(D)V

    .line 742
    iget-boolean v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->p:Z

    iget v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->n:I

    iget v2, p0, Lcom/thinkware/sundo/ieve/IEVE;->o:I

    invoke-virtual {p0, v0, v1, v2}, Lcom/thinkware/sundo/ieve/IEVE;->setStreamDataInfo(ZII)Z

    .line 743
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->g:Lcom/thinkware/sundo/ieve/ieveNScreenManager;

    const/16 v1, 0x1010

    iget-object v2, p0, Lcom/thinkware/sundo/ieve/IEVE;->j:Lcom/thinkware/sundo/ieve/ieveCameraView;

    iget-object v3, p0, Lcom/thinkware/sundo/ieve/IEVE;->v:Landroid/graphics/Rect;

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-virtual/range {v0 .. v5}, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->insertView(ILandroid/view/View;Landroid/graphics/Rect;ZI)Z

    .line 744
    return-void
.end method

.method static synthetic d(Lcom/thinkware/sundo/ieve/IEVE;I)V
    .locals 0

    .prologue
    .line 285
    iput p1, p0, Lcom/thinkware/sundo/ieve/IEVE;->D:I

    return-void
.end method

.method private e()V
    .locals 6

    .prologue
    .line 748
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->b:Landroid/content/Context;

    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v0

    const-string v1, "com.thinkware.inavi3ds"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 754
    :goto_0
    return-void

    .line 749
    :cond_0
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->i:Lcom/thinkware/sundo/ieve/ieveCalibrationView;

    if-nez v0, :cond_1

    .line 750
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;

    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->b:Landroid/content/Context;

    iget-object v2, p0, Lcom/thinkware/sundo/ieve/IEVE;->u:Landroid/graphics/Rect;

    iget-object v3, p0, Lcom/thinkware/sundo/ieve/IEVE;->j:Lcom/thinkware/sundo/ieve/ieveCameraView;

    invoke-direct {v0, v1, v2, v3, p0}, Lcom/thinkware/sundo/ieve/ieveCalibrationView;-><init>(Landroid/content/Context;Landroid/graphics/Rect;Lcom/thinkware/sundo/ieve/ieveCameraView;Lcom/thinkware/sundo/ieve/IEVE;)V

    iput-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->i:Lcom/thinkware/sundo/ieve/ieveCalibrationView;

    .line 751
    const-string v0, "java_IEVE"

    const-string v1, "createViewCalibr"

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 753
    :cond_1
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->g:Lcom/thinkware/sundo/ieve/ieveNScreenManager;

    const/16 v1, 0x1040

    iget-object v2, p0, Lcom/thinkware/sundo/ieve/IEVE;->i:Lcom/thinkware/sundo/ieve/ieveCalibrationView;

    iget-object v3, p0, Lcom/thinkware/sundo/ieve/IEVE;->u:Landroid/graphics/Rect;

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-virtual/range {v0 .. v5}, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->insertView(ILandroid/view/View;Landroid/graphics/Rect;ZI)Z

    goto :goto_0
.end method

.method static synthetic e(Lcom/thinkware/sundo/ieve/IEVE;I)V
    .locals 0

    .prologue
    .line 288
    iput p1, p0, Lcom/thinkware/sundo/ieve/IEVE;->G:I

    return-void
.end method

.method static synthetic e(Lcom/thinkware/sundo/ieve/IEVE;)Z
    .locals 1

    .prologue
    .line 335
    iget-boolean v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->U:Z

    return v0
.end method

.method static synthetic f(Lcom/thinkware/sundo/ieve/IEVE;)Lcom/thinkware/sundo/ieve/ieveNative;
    .locals 1

    .prologue
    .line 37
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    return-object v0
.end method

.method private f()V
    .locals 2

    .prologue
    .line 758
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->g:Lcom/thinkware/sundo/ieve/ieveNScreenManager;

    const/16 v1, 0x1030

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->removeView(I)Z

    .line 759
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->h:Lcom/thinkware/sundo/ieve/ieveARView;

    if-eqz v0, :cond_0

    .line 760
    const/4 v0, 0x0

    iput-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->h:Lcom/thinkware/sundo/ieve/ieveARView;

    .line 761
    const-string v0, "java_IEVE"

    const-string v1, "destroyViewAR:mViewArview"

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 763
    :cond_0
    return-void
.end method

.method static synthetic f(Lcom/thinkware/sundo/ieve/IEVE;I)V
    .locals 0

    .prologue
    .line 286
    iput p1, p0, Lcom/thinkware/sundo/ieve/IEVE;->E:I

    return-void
.end method

.method static synthetic g(Lcom/thinkware/sundo/ieve/IEVE;)I
    .locals 1

    .prologue
    .line 356
    iget v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->ae:I

    return v0
.end method

.method private g()V
    .locals 3

    .prologue
    const/4 v2, 0x0

    .line 767
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->g:Lcom/thinkware/sundo/ieve/ieveNScreenManager;

    const/16 v1, 0x1010

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->removeView(I)Z

    .line 768
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->j:Lcom/thinkware/sundo/ieve/ieveCameraView;

    if-eqz v0, :cond_0

    .line 769
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->j:Lcom/thinkware/sundo/ieve/ieveCameraView;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveCameraView;->cameraDestroy()V

    .line 770
    iput-object v2, p0, Lcom/thinkware/sundo/ieve/IEVE;->j:Lcom/thinkware/sundo/ieve/ieveCameraView;

    .line 771
    const-string v0, "java_IEVE"

    const-string v1, "destroyViewCamera:mViewCamera"

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 773
    :cond_0
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->an:Lcom/thinkware/sundo/ieve/IEVE$a;

    if-eqz v0, :cond_1

    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->an:Lcom/thinkware/sundo/ieve/IEVE$a;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/IEVE$a;->destroy()V

    iput-object v2, p0, Lcom/thinkware/sundo/ieve/IEVE;->an:Lcom/thinkware/sundo/ieve/IEVE$a;

    .line 774
    :cond_1
    return-void
.end method

.method static synthetic g(Lcom/thinkware/sundo/ieve/IEVE;I)V
    .locals 0

    .prologue
    .line 289
    iput p1, p0, Lcom/thinkware/sundo/ieve/IEVE;->H:I

    return-void
.end method

.method static synthetic h(Lcom/thinkware/sundo/ieve/IEVE;)Lcom/stradvision/pdvdtest/SV_ADAS;
    .locals 1

    .prologue
    .line 34
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->d:Lcom/stradvision/pdvdtest/SV_ADAS;

    return-object v0
.end method

.method private h()V
    .locals 2

    .prologue
    .line 778
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->g:Lcom/thinkware/sundo/ieve/ieveNScreenManager;

    const/16 v1, 0x1040

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->removeView(I)Z

    .line 779
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->i:Lcom/thinkware/sundo/ieve/ieveCalibrationView;

    if-eqz v0, :cond_0

    .line 780
    const/4 v0, 0x0

    iput-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->i:Lcom/thinkware/sundo/ieve/ieveCalibrationView;

    .line 781
    const-string v0, "java_IEVE"

    const-string v1, "destroyViewCalibr:mViewCalibr"

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 783
    :cond_0
    return-void
.end method

.method static synthetic h(Lcom/thinkware/sundo/ieve/IEVE;I)V
    .locals 0

    .prologue
    .line 287
    iput p1, p0, Lcom/thinkware/sundo/ieve/IEVE;->F:I

    return-void
.end method

.method static synthetic i(Lcom/thinkware/sundo/ieve/IEVE;)Lcom/thinkware/sundo/ieve/ieveDebugImageView;
    .locals 1

    .prologue
    .line 2868
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->au:Lcom/thinkware/sundo/ieve/ieveDebugImageView;

    return-object v0
.end method

.method private i()Ljava/lang/String;
    .locals 4

    .prologue
    .line 1335
    invoke-static {}, Lcom/thinkware/sundo/ieve/ieveSystemStatus;->getDeviceSerialNumber()Ljava/lang/String;

    move-result-object v0

    .line 1336
    .local v0, "uid":Ljava/lang/String;
    if-eqz v0, :cond_0

    invoke-virtual {v0}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v1

    const-string v2, "-"

    const-string v3, ""

    invoke-virtual {v1, v2, v3}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v1

    .line 1337
    :goto_0
    return-object v1

    :cond_0
    const-string v1, ""

    goto :goto_0
.end method

.method static synthetic i(Lcom/thinkware/sundo/ieve/IEVE;I)V
    .locals 0

    .prologue
    .line 291
    iput p1, p0, Lcom/thinkware/sundo/ieve/IEVE;->J:I

    return-void
.end method

.method public static ieveProcessImage(II[I)I
    .locals 4
    .param p0, "cmd"    # I
    .param p1, "arg"    # I
    .param p2, "buffer"    # [I

    .prologue
    const/16 v3, 0x125d

    .line 384
    const/4 v1, 0x1

    .line 385
    .local v1, "ret":I
    sget-object v2, Lcom/thinkware/sundo/ieve/IEVE;->ah:Landroid/os/Handler;

    if-eqz v2, :cond_0

    if-ne p0, v3, :cond_0

    .line 387
    sget-object v2, Lcom/thinkware/sundo/ieve/IEVE;->ah:Landroid/os/Handler;

    invoke-static {v2, v3}, Landroid/os/Message;->obtain(Landroid/os/Handler;I)Landroid/os/Message;

    move-result-object v0

    .line 388
    .local v0, "msg":Landroid/os/Message;
    iput p1, v0, Landroid/os/Message;->arg1:I

    .line 389
    iput-object p2, v0, Landroid/os/Message;->obj:Ljava/lang/Object;

    .line 390
    sget-object v2, Lcom/thinkware/sundo/ieve/IEVE;->ah:Landroid/os/Handler;

    invoke-virtual {v2, v0}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    .line 393
    .end local v0    # "msg":Landroid/os/Message;
    :cond_0
    return v1
.end method

.method public static ieveProcessMessage(IILjava/lang/String;)I
    .locals 4
    .param p0, "cmd"    # I
    .param p1, "arg"    # I
    .param p2, "value"    # Ljava/lang/String;

    .prologue
    const/16 v3, 0x125c

    .line 371
    const/4 v1, 0x1

    .line 372
    .local v1, "ret":I
    sget-object v2, Lcom/thinkware/sundo/ieve/IEVE;->ah:Landroid/os/Handler;

    if-eqz v2, :cond_0

    if-ne p0, v3, :cond_0

    .line 374
    sget-object v2, Lcom/thinkware/sundo/ieve/IEVE;->ah:Landroid/os/Handler;

    invoke-static {v2, v3}, Landroid/os/Message;->obtain(Landroid/os/Handler;I)Landroid/os/Message;

    move-result-object v0

    .line 375
    .local v0, "msg":Landroid/os/Message;
    iput p1, v0, Landroid/os/Message;->arg1:I

    .line 376
    iput-object p2, v0, Landroid/os/Message;->obj:Ljava/lang/Object;

    .line 377
    sget-object v2, Lcom/thinkware/sundo/ieve/IEVE;->ah:Landroid/os/Handler;

    invoke-virtual {v2, v0}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    .line 380
    .end local v0    # "msg":Landroid/os/Message;
    :cond_0
    return v1
.end method

.method public static ieveProcessState(III)I
    .locals 4
    .param p0, "cmd"    # I
    .param p1, "arg"    # I
    .param p2, "value"    # I

    .prologue
    const/16 v3, 0x125e

    .line 397
    const/4 v1, 0x1

    .line 398
    .local v1, "ret":I
    sget-object v2, Lcom/thinkware/sundo/ieve/IEVE;->ah:Landroid/os/Handler;

    if-eqz v2, :cond_0

    if-ne p0, v3, :cond_0

    .line 400
    sget-object v2, Lcom/thinkware/sundo/ieve/IEVE;->ah:Landroid/os/Handler;

    invoke-static {v2, v3}, Landroid/os/Message;->obtain(Landroid/os/Handler;I)Landroid/os/Message;

    move-result-object v0

    .line 401
    .local v0, "msg":Landroid/os/Message;
    iput p1, v0, Landroid/os/Message;->arg1:I

    .line 402
    iput p2, v0, Landroid/os/Message;->arg2:I

    .line 403
    sget-object v2, Lcom/thinkware/sundo/ieve/IEVE;->ah:Landroid/os/Handler;

    invoke-virtual {v2, v0}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    .line 406
    .end local v0    # "msg":Landroid/os/Message;
    :cond_0
    return v1
.end method

.method private j()V
    .locals 6

    .prologue
    .line 2897
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->au:Lcom/thinkware/sundo/ieve/ieveDebugImageView;

    if-nez v0, :cond_0

    .line 2898
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveDebugImageView;

    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->b:Landroid/content/Context;

    iget-object v2, p0, Lcom/thinkware/sundo/ieve/IEVE;->x:Landroid/graphics/Rect;

    invoke-direct {v0, v1, v2}, Lcom/thinkware/sundo/ieve/ieveDebugImageView;-><init>(Landroid/content/Context;Landroid/graphics/Rect;)V

    iput-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->au:Lcom/thinkware/sundo/ieve/ieveDebugImageView;

    .line 2899
    const-string v0, "java_IEVE"

    const-string v1, "createViewDebugImg"

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 2901
    :cond_0
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->g:Lcom/thinkware/sundo/ieve/ieveNScreenManager;

    const v1, 0xfffe

    iget-object v2, p0, Lcom/thinkware/sundo/ieve/IEVE;->au:Lcom/thinkware/sundo/ieve/ieveDebugImageView;

    iget-object v3, p0, Lcom/thinkware/sundo/ieve/IEVE;->x:Landroid/graphics/Rect;

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-virtual/range {v0 .. v5}, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->insertView(ILandroid/view/View;Landroid/graphics/Rect;ZI)Z

    .line 2902
    return-void
.end method

.method static synthetic j(Lcom/thinkware/sundo/ieve/IEVE;)V
    .locals 0

    .prologue
    .line 2896
    invoke-direct {p0}, Lcom/thinkware/sundo/ieve/IEVE;->j()V

    return-void
.end method

.method static synthetic j(Lcom/thinkware/sundo/ieve/IEVE;I)V
    .locals 0

    .prologue
    .line 290
    iput p1, p0, Lcom/thinkware/sundo/ieve/IEVE;->I:I

    return-void
.end method

.method private k()V
    .locals 6

    .prologue
    .line 2905
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->at:Lcom/thinkware/sundo/ieve/ieveTextView;

    if-nez v0, :cond_0

    .line 2906
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveTextView;

    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->b:Landroid/content/Context;

    invoke-direct {v0, v1}, Lcom/thinkware/sundo/ieve/ieveTextView;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->at:Lcom/thinkware/sundo/ieve/ieveTextView;

    .line 2907
    const-string v0, "java_IEVE"

    const-string v1, "createViewDebugLog"

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 2909
    :cond_0
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->at:Lcom/thinkware/sundo/ieve/ieveTextView;

    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->x:Landroid/graphics/Rect;

    invoke-virtual {v1}, Landroid/graphics/Rect;->width()I

    move-result v1

    int-to-float v1, v1

    const/high16 v2, 0x44800000    # 1024.0f

    div-float/2addr v1, v2

    iget-object v2, p0, Lcom/thinkware/sundo/ieve/IEVE;->x:Landroid/graphics/Rect;

    invoke-virtual {v2}, Landroid/graphics/Rect;->height()I

    move-result v2

    int-to-float v2, v2

    const/high16 v3, 0x44160000    # 600.0f

    div-float/2addr v2, v3

    invoke-virtual {v0, v1, v2}, Lcom/thinkware/sundo/ieve/ieveTextView;->setAspectRatioView(FF)V

    .line 2911
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->as:Ljava/lang/Runnable;

    if-nez v0, :cond_1

    .line 2912
    new-instance v0, Lcom/thinkware/sundo/ieve/IEVE$4;

    invoke-direct {v0, p0}, Lcom/thinkware/sundo/ieve/IEVE$4;-><init>(Lcom/thinkware/sundo/ieve/IEVE;)V

    iput-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->as:Ljava/lang/Runnable;

    .line 2923
    :cond_1
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->at:Lcom/thinkware/sundo/ieve/ieveTextView;

    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->as:Ljava/lang/Runnable;

    const-wide/16 v2, 0x21

    invoke-virtual {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveTextView;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 2924
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->g:Lcom/thinkware/sundo/ieve/ieveNScreenManager;

    const v1, 0xffff

    iget-object v2, p0, Lcom/thinkware/sundo/ieve/IEVE;->at:Lcom/thinkware/sundo/ieve/ieveTextView;

    iget-object v3, p0, Lcom/thinkware/sundo/ieve/IEVE;->x:Landroid/graphics/Rect;

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-virtual/range {v0 .. v5}, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->insertView(ILandroid/view/View;Landroid/graphics/Rect;ZI)Z

    .line 2925
    return-void
.end method

.method static synthetic k(Lcom/thinkware/sundo/ieve/IEVE;)V
    .locals 0

    .prologue
    .line 2927
    invoke-direct {p0}, Lcom/thinkware/sundo/ieve/IEVE;->l()V

    return-void
.end method

.method static synthetic k(Lcom/thinkware/sundo/ieve/IEVE;I)V
    .locals 0

    .prologue
    .line 292
    iput p1, p0, Lcom/thinkware/sundo/ieve/IEVE;->K:I

    return-void
.end method

.method static synthetic l(Lcom/thinkware/sundo/ieve/IEVE;)I
    .locals 1

    .prologue
    .line 355
    iget v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->ad:I

    return v0
.end method

.method private l()V
    .locals 2

    .prologue
    .line 2928
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->g:Lcom/thinkware/sundo/ieve/ieveNScreenManager;

    const v1, 0xfffe

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->removeView(I)Z

    .line 2929
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->au:Lcom/thinkware/sundo/ieve/ieveDebugImageView;

    if-eqz v0, :cond_0

    .line 2930
    const/4 v0, 0x0

    iput-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->au:Lcom/thinkware/sundo/ieve/ieveDebugImageView;

    .line 2931
    const-string v0, "java_IEVE"

    const-string v1, "destroyViewDebugImg:mViewDbgimg"

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 2933
    :cond_0
    return-void
.end method

.method static synthetic l(Lcom/thinkware/sundo/ieve/IEVE;I)V
    .locals 0

    .prologue
    .line 293
    iput p1, p0, Lcom/thinkware/sundo/ieve/IEVE;->L:I

    return-void
.end method

.method static synthetic m(Lcom/thinkware/sundo/ieve/IEVE;)F
    .locals 1

    .prologue
    .line 349
    iget v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->X:F

    return v0
.end method

.method private m()V
    .locals 3

    .prologue
    const/4 v2, 0x0

    .line 2936
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->g:Lcom/thinkware/sundo/ieve/ieveNScreenManager;

    const v1, 0xffff

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->removeView(I)Z

    .line 2937
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->as:Ljava/lang/Runnable;

    if-eqz v0, :cond_0

    iput-object v2, p0, Lcom/thinkware/sundo/ieve/IEVE;->as:Ljava/lang/Runnable;

    .line 2938
    :cond_0
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->at:Lcom/thinkware/sundo/ieve/ieveTextView;

    if-eqz v0, :cond_1

    .line 2939
    iput-object v2, p0, Lcom/thinkware/sundo/ieve/IEVE;->at:Lcom/thinkware/sundo/ieve/ieveTextView;

    .line 2940
    const-string v0, "java_IEVE"

    const-string v1, "destroyViewDebugLog:mViewDbglog"

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 2942
    :cond_1
    return-void
.end method

.method static synthetic m(Lcom/thinkware/sundo/ieve/IEVE;I)V
    .locals 0

    .prologue
    .line 294
    iput p1, p0, Lcom/thinkware/sundo/ieve/IEVE;->M:I

    return-void
.end method

.method static synthetic n(Lcom/thinkware/sundo/ieve/IEVE;)F
    .locals 1

    .prologue
    .line 350
    iget v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->Y:F

    return v0
.end method

.method static synthetic n(Lcom/thinkware/sundo/ieve/IEVE;I)V
    .locals 0

    .prologue
    .line 295
    iput p1, p0, Lcom/thinkware/sundo/ieve/IEVE;->N:I

    return-void
.end method

.method static synthetic o(Lcom/thinkware/sundo/ieve/IEVE;)F
    .locals 1

    .prologue
    .line 351
    iget v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->Z:F

    return v0
.end method

.method static synthetic o(Lcom/thinkware/sundo/ieve/IEVE;I)V
    .locals 0

    .prologue
    .line 296
    iput p1, p0, Lcom/thinkware/sundo/ieve/IEVE;->O:I

    return-void
.end method

.method static synthetic p(Lcom/thinkware/sundo/ieve/IEVE;)F
    .locals 1

    .prologue
    .line 352
    iget v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->aa:F

    return v0
.end method

.method static synthetic p(Lcom/thinkware/sundo/ieve/IEVE;I)V
    .locals 0

    .prologue
    .line 297
    iput p1, p0, Lcom/thinkware/sundo/ieve/IEVE;->P:I

    return-void
.end method

.method static synthetic q(Lcom/thinkware/sundo/ieve/IEVE;)F
    .locals 1

    .prologue
    .line 353
    iget v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->ab:F

    return v0
.end method

.method static synthetic q(Lcom/thinkware/sundo/ieve/IEVE;I)V
    .locals 0

    .prologue
    .line 298
    iput p1, p0, Lcom/thinkware/sundo/ieve/IEVE;->Q:I

    return-void
.end method

.method static synthetic r(Lcom/thinkware/sundo/ieve/IEVE;)Z
    .locals 1

    .prologue
    .line 354
    iget-boolean v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->ac:Z

    return v0
.end method

.method static synthetic s(Lcom/thinkware/sundo/ieve/IEVE;)I
    .locals 1

    .prologue
    .line 285
    iget v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->D:I

    return v0
.end method

.method static synthetic t(Lcom/thinkware/sundo/ieve/IEVE;)I
    .locals 1

    .prologue
    .line 292
    iget v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->K:I

    return v0
.end method

.method static synthetic u(Lcom/thinkware/sundo/ieve/IEVE;)I
    .locals 1

    .prologue
    .line 288
    iget v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->G:I

    return v0
.end method

.method static synthetic v(Lcom/thinkware/sundo/ieve/IEVE;)I
    .locals 1

    .prologue
    .line 293
    iget v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->L:I

    return v0
.end method

.method static synthetic w(Lcom/thinkware/sundo/ieve/IEVE;)I
    .locals 1

    .prologue
    .line 286
    iget v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->E:I

    return v0
.end method

.method static synthetic x(Lcom/thinkware/sundo/ieve/IEVE;)I
    .locals 1

    .prologue
    .line 294
    iget v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->M:I

    return v0
.end method

.method static synthetic y(Lcom/thinkware/sundo/ieve/IEVE;)I
    .locals 1

    .prologue
    .line 289
    iget v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->H:I

    return v0
.end method

.method static synthetic z(Lcom/thinkware/sundo/ieve/IEVE;)I
    .locals 1

    .prologue
    .line 295
    iget v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->N:I

    return v0
.end method


# virtual methods
.method public DebugPrint(ILjava/lang/String;FFF)V
    .locals 6
    .param p1, "index"    # I
    .param p2, "text"    # Ljava/lang/String;
    .param p3, "posx"    # F
    .param p4, "posy"    # F
    .param p5, "size"    # F

    .prologue
    .line 2871
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->at:Lcom/thinkware/sundo/ieve/ieveTextView;

    if-nez v0, :cond_0

    .line 2873
    :goto_0
    return-void

    .line 2872
    :cond_0
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->at:Lcom/thinkware/sundo/ieve/ieveTextView;

    invoke-virtual {p0}, Lcom/thinkware/sundo/ieve/IEVE;->isDebugPrint()Z

    move-result v1

    if-nez v1, :cond_1

    const-string v2, ""

    :goto_1
    iget v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->aq:I

    int-to-float v1, v1

    add-float v4, p4, v1

    move v1, p1

    move v3, p3

    move v5, p5

    invoke-virtual/range {v0 .. v5}, Lcom/thinkware/sundo/ieve/ieveTextView;->insertText(ILjava/lang/String;FFF)V

    goto :goto_0

    :cond_1
    move-object v2, p2

    goto :goto_1
.end method

.method public DebugPrint(ILjava/lang/String;FFFI)V
    .locals 7
    .param p1, "index"    # I
    .param p2, "text"    # Ljava/lang/String;
    .param p3, "posx"    # F
    .param p4, "posy"    # F
    .param p5, "size"    # F
    .param p6, "color"    # I

    .prologue
    .line 2876
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->at:Lcom/thinkware/sundo/ieve/ieveTextView;

    if-nez v0, :cond_0

    .line 2878
    :goto_0
    return-void

    .line 2877
    :cond_0
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->at:Lcom/thinkware/sundo/ieve/ieveTextView;

    invoke-virtual {p0}, Lcom/thinkware/sundo/ieve/IEVE;->isDebugPrint()Z

    move-result v1

    if-nez v1, :cond_1

    const-string v2, ""

    :goto_1
    iget v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->aq:I

    int-to-float v1, v1

    add-float v4, p4, v1

    move v1, p1

    move v3, p3

    move v5, p5

    move v6, p6

    invoke-virtual/range {v0 .. v6}, Lcom/thinkware/sundo/ieve/ieveTextView;->insertText(ILjava/lang/String;FFFI)V

    goto :goto_0

    :cond_1
    move-object v2, p2

    goto :goto_1
.end method

.method public DebugPrint(ILjava/lang/String;FFFIZZZIILandroid/graphics/Typeface;)V
    .locals 13
    .param p1, "index"    # I
    .param p2, "text"    # Ljava/lang/String;
    .param p3, "posx"    # F
    .param p4, "posy"    # F
    .param p5, "size"    # F
    .param p6, "color"    # I
    .param p7, "shadow"    # Z
    .param p8, "italic"    # Z
    .param p9, "underline"    # Z
    .param p10, "alignh"    # I
    .param p11, "alignv"    # I
    .param p12, "type"    # Landroid/graphics/Typeface;

    .prologue
    .line 2881
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->at:Lcom/thinkware/sundo/ieve/ieveTextView;

    if-nez v0, :cond_0

    .line 2883
    :goto_0
    return-void

    .line 2882
    :cond_0
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->at:Lcom/thinkware/sundo/ieve/ieveTextView;

    invoke-virtual {p0}, Lcom/thinkware/sundo/ieve/IEVE;->isDebugPrint()Z

    move-result v1

    if-nez v1, :cond_1

    const-string v2, ""

    :goto_1
    iget v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->aq:I

    int-to-float v1, v1

    add-float v4, p4, v1

    move v1, p1

    move/from16 v3, p3

    move/from16 v5, p5

    move/from16 v6, p6

    move/from16 v7, p7

    move/from16 v8, p8

    move/from16 v9, p9

    move/from16 v10, p10

    move/from16 v11, p11

    move-object/from16 v12, p12

    invoke-virtual/range {v0 .. v12}, Lcom/thinkware/sundo/ieve/ieveTextView;->insertText(ILjava/lang/String;FFFIZZZIILandroid/graphics/Typeface;)V

    goto :goto_0

    :cond_1
    move-object v2, p2

    goto :goto_1
.end method

.method public checkDebugMode()V
    .locals 2

    .prologue
    .line 2886
    const-string v0, "java_IEVE"

    const-string v1, "checkDebugMode"

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 2887
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->CheckDebugMode()V

    .line 2888
    invoke-virtual {p0}, Lcom/thinkware/sundo/ieve/IEVE;->isDebugPrint()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-direct {p0}, Lcom/thinkware/sundo/ieve/IEVE;->k()V

    .line 2890
    :goto_0
    return-void

    .line 2889
    :cond_0
    invoke-direct {p0}, Lcom/thinkware/sundo/ieve/IEVE;->m()V

    goto :goto_0
.end method

.method public checkPickPlane(II)[I
    .locals 1
    .param p1, "x"    # I
    .param p2, "y"    # I

    .prologue
    .line 2893
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0, p1, p2}, Lcom/thinkware/sundo/ieve/ieveNative;->CheckPickPlane(II)[I

    move-result-object v0

    return-object v0
.end method

.method public confirmRegistration(Ljava/lang/String;)Z
    .locals 4
    .param p1, "encryptfolder"    # Ljava/lang/String;

    .prologue
    const/4 v0, 0x0

    .line 713
    if-eqz p1, :cond_0

    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_1

    .line 714
    :cond_0
    const-string v1, "java_IEVE"

    const-string v2, "confirmRegistration:encryption_folder is null"

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 718
    :goto_0
    return v0

    .line 717
    :cond_1
    const-string v1, "java_IEVE"

    const-string v2, "confirmRegistration[%s]"

    const/4 v3, 0x1

    new-array v3, v3, [Ljava/lang/Object;

    aput-object p1, v3, v0

    invoke-static {v2, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 718
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0, p1}, Lcom/thinkware/sundo/ieve/ieveNative;->ConfirmRegistration(Ljava/lang/String;)Z

    move-result v0

    goto :goto_0
.end method

.method public convertGeoRegToFPoint3D_X(II)F
    .locals 8
    .param p1, "reg_lon"    # I
    .param p2, "reg_lat"    # I

    .prologue
    .line 2842
    int-to-double v0, p1

    sget-wide v4, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_BASE_COORDINATE_SHIFT:D

    div-double v2, v0, v4

    .line 2843
    .local v2, "dlon":D
    int-to-double v0, p2

    sget-wide v4, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_BASE_COORDINATE_SHIFT:D

    div-double v6, v0, v4

    .line 2844
    .local v6, "dlat":D
    sget-wide v4, Lcom/thinkware/sundo/ieve/IEVE;->ap:D

    move-object v1, p0

    invoke-virtual/range {v1 .. v7}, Lcom/thinkware/sundo/ieve/IEVE;->getDistMeterOfLongitude(DDD)D

    move-result-wide v0

    double-to-float v0, v0

    return v0
.end method

.method public convertGeoRegToFPoint3D_Z(I)F
    .locals 6
    .param p1, "reg_lat"    # I

    .prologue
    .line 2848
    int-to-double v2, p1

    sget-wide v4, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_BASE_COORDINATE_SHIFT:D

    div-double v0, v2, v4

    .line 2849
    .local v0, "dlat":D
    sget-wide v2, Lcom/thinkware/sundo/ieve/IEVE;->ao:D

    invoke-virtual {p0, v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/IEVE;->getDistMeterOfLatitude(DD)D

    move-result-wide v2

    double-to-float v2, v2

    return v2
.end method

.method public convertiNaviRegToFPoint3D_X(I)F
    .locals 1
    .param p1, "reg_x"    # I

    .prologue
    .line 2854
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0, p1}, Lcom/thinkware/sundo/ieve/ieveNative;->ConvertiNaviRegToFP3DX(I)F

    move-result v0

    return v0
.end method

.method public convertiNaviRegToFPoint3D_Z(I)F
    .locals 1
    .param p1, "reg_y"    # I

    .prologue
    .line 2859
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0, p1}, Lcom/thinkware/sundo/ieve/ieveNative;->ConvertiNaviRegToFP3DZ(I)F

    move-result v0

    return v0
.end method

.method public destroy()V
    .locals 2

    .prologue
    const/4 v1, 0x0

    .line 690
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->ag:Ljava/util/TimerTask;

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->ag:Ljava/util/TimerTask;

    invoke-virtual {v0}, Ljava/util/TimerTask;->cancel()Z

    iput-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->ag:Ljava/util/TimerTask;

    .line 691
    :cond_0
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->af:Ljava/util/Timer;

    if-eqz v0, :cond_1

    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->af:Ljava/util/Timer;

    invoke-virtual {v0}, Ljava/util/Timer;->cancel()V

    iput-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->af:Ljava/util/Timer;

    .line 693
    :cond_1
    invoke-direct {p0}, Lcom/thinkware/sundo/ieve/IEVE;->b()V

    .line 694
    invoke-direct {p0}, Lcom/thinkware/sundo/ieve/IEVE;->l()V

    .line 695
    invoke-direct {p0}, Lcom/thinkware/sundo/ieve/IEVE;->m()V

    .line 696
    invoke-direct {p0}, Lcom/thinkware/sundo/ieve/IEVE;->f()V

    .line 697
    invoke-direct {p0}, Lcom/thinkware/sundo/ieve/IEVE;->g()V

    .line 698
    invoke-direct {p0}, Lcom/thinkware/sundo/ieve/IEVE;->h()V

    .line 700
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->f:Lcom/thinkware/sundo/ieve/ieveGuideInfos;

    if-eqz v0, :cond_2

    iput-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->f:Lcom/thinkware/sundo/ieve/ieveGuideInfos;

    .line 701
    :cond_2
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->T:Lcom/thinkware/sundo/ieve/ieveSoundManager;

    if-eqz v0, :cond_3

    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->T:Lcom/thinkware/sundo/ieve/ieveSoundManager;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveSoundManager;->destroy()V

    iput-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->T:Lcom/thinkware/sundo/ieve/ieveSoundManager;

    .line 702
    :cond_3
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    if-eqz v0, :cond_4

    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->Destroy()Z

    .line 705
    :cond_4
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->d:Lcom/stradvision/pdvdtest/SV_ADAS;

    if-eqz v0, :cond_5

    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->d:Lcom/stradvision/pdvdtest/SV_ADAS;

    invoke-virtual {v0}, Lcom/stradvision/pdvdtest/SV_ADAS;->Destroy()V

    .line 707
    :cond_5
    const-string v0, "java_IEVE"

    const-string v1, "destroy"

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 708
    const-string v0, "java_IEVE"

    const-string v1, "===== IEVE java end! ==========================================="

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 709
    return-void
.end method

.method public enableCalibration(I)Z
    .locals 6
    .param p1, "mode"    # I

    .prologue
    const/4 v1, 0x1

    const/4 v0, 0x0

    .line 787
    const/16 v2, 0x10

    if-eq p1, v2, :cond_0

    const/16 v2, 0x20

    if-eq p1, v2, :cond_0

    .line 788
    const-string v2, "java_IEVE"

    const-string v3, "enableCalibration[Invalid mode: %d]"

    new-array v1, v1, [Ljava/lang/Object;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    aput-object v4, v1, v0

    invoke-static {v3, v1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v2, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 794
    :goto_0
    return v0

    .line 791
    :cond_0
    iput p1, p0, Lcom/thinkware/sundo/ieve/IEVE;->C:I

    .line 792
    iget v2, p0, Lcom/thinkware/sundo/ieve/IEVE;->C:I

    invoke-direct {p0, v2}, Lcom/thinkware/sundo/ieve/IEVE;->b(I)V

    .line 793
    const-string v2, "java_IEVE"

    const-string v3, "enableCalibration[0x%08x]"

    new-array v4, v1, [Ljava/lang/Object;

    iget v5, p0, Lcom/thinkware/sundo/ieve/IEVE;->C:I

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    aput-object v5, v4, v0

    invoke-static {v3, v4}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v2, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    move v0, v1

    .line 794
    goto :goto_0
.end method

.method public enableModeAR(Z)Z
    .locals 9
    .param p1, "enable"    # Z

    .prologue
    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v2, 0x0

    .line 799
    iget-object v3, p0, Lcom/thinkware/sundo/ieve/IEVE;->t:Landroid/graphics/Rect;

    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v1}, Lcom/thinkware/sundo/ieve/ieveNative;->IsFullMode()Z

    move-result v1

    if-eqz v1, :cond_0

    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->r:Landroid/graphics/Rect;

    :goto_0
    invoke-virtual {v3, v1}, Landroid/graphics/Rect;->set(Landroid/graphics/Rect;)V

    .line 800
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v1, p1}, Lcom/thinkware/sundo/ieve/ieveNative;->EnableModeAR(Z)Z

    move-result v0

    .line 801
    .local v0, "ret":Z
    if-nez v0, :cond_2

    .line 802
    const-string v3, "java_IEVE"

    const-string v4, "enableModeAR[%s:false][0x%08x]"

    new-array v5, v8, [Ljava/lang/Object;

    if-eqz p1, :cond_1

    const-string v1, "true"

    :goto_1
    aput-object v1, v5, v2

    invoke-virtual {p0}, Lcom/thinkware/sundo/ieve/IEVE;->getStatus()I

    move-result v1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    aput-object v1, v5, v7

    invoke-static {v4, v5}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v3, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    move v1, v2

    .line 813
    :goto_2
    return v1

    .line 799
    .end local v0    # "ret":Z
    :cond_0
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->s:Landroid/graphics/Rect;

    goto :goto_0

    .line 802
    .restart local v0    # "ret":Z
    :cond_1
    const-string v1, "false"

    goto :goto_1

    .line 805
    :cond_2
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v1, p1}, Lcom/thinkware/sundo/ieve/ieveNative;->EnableModeDR(Z)Z

    move-result v0

    .line 806
    if-nez v0, :cond_4

    .line 807
    const-string v3, "java_IEVE"

    const-string v4, "enableModeDR[%s:false][0x%08x]"

    new-array v5, v8, [Ljava/lang/Object;

    if-eqz p1, :cond_3

    const-string v1, "true"

    :goto_3
    aput-object v1, v5, v2

    invoke-virtual {p0}, Lcom/thinkware/sundo/ieve/IEVE;->getStatus()I

    move-result v1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    aput-object v1, v5, v7

    invoke-static {v4, v5}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v3, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    move v1, v2

    .line 808
    goto :goto_2

    .line 807
    :cond_3
    const-string v1, "false"

    goto :goto_3

    .line 810
    :cond_4
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    iget-object v3, p0, Lcom/thinkware/sundo/ieve/IEVE;->t:Landroid/graphics/Rect;

    iget v3, v3, Landroid/graphics/Rect;->left:I

    iget-object v4, p0, Lcom/thinkware/sundo/ieve/IEVE;->t:Landroid/graphics/Rect;

    iget v4, v4, Landroid/graphics/Rect;->top:I

    iget-object v5, p0, Lcom/thinkware/sundo/ieve/IEVE;->t:Landroid/graphics/Rect;

    invoke-virtual {v5}, Landroid/graphics/Rect;->width()I

    move-result v5

    iget-object v6, p0, Lcom/thinkware/sundo/ieve/IEVE;->t:Landroid/graphics/Rect;

    invoke-virtual {v6}, Landroid/graphics/Rect;->height()I

    move-result v6

    invoke-virtual {v1, v3, v4, v5, v6}, Lcom/thinkware/sundo/ieve/ieveNative;->SetSizeView(IIII)V

    .line 811
    invoke-virtual {p0}, Lcom/thinkware/sundo/ieve/IEVE;->getStatus()I

    move-result v1

    invoke-direct {p0, v1}, Lcom/thinkware/sundo/ieve/IEVE;->b(I)V

    .line 812
    const-string v3, "java_IEVE"

    const-string v4, "enableModeAR[%s][0x%08x]"

    new-array v5, v8, [Ljava/lang/Object;

    if-eqz p1, :cond_5

    const-string v1, "true"

    :goto_4
    aput-object v1, v5, v2

    invoke-virtual {p0}, Lcom/thinkware/sundo/ieve/IEVE;->getStatus()I

    move-result v1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    aput-object v1, v5, v7

    invoke-static {v4, v5}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v3, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    move v1, v0

    .line 813
    goto :goto_2

    .line 812
    :cond_5
    const-string v1, "false"

    goto :goto_4
.end method

.method public enableModeAR(ZZ)Z
    .locals 9
    .param p1, "enable"    # Z
    .param p2, "withDR"    # Z

    .prologue
    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v2, 0x0

    .line 818
    iget-object v3, p0, Lcom/thinkware/sundo/ieve/IEVE;->t:Landroid/graphics/Rect;

    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v1}, Lcom/thinkware/sundo/ieve/ieveNative;->IsFullMode()Z

    move-result v1

    if-eqz v1, :cond_0

    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->r:Landroid/graphics/Rect;

    :goto_0
    invoke-virtual {v3, v1}, Landroid/graphics/Rect;->set(Landroid/graphics/Rect;)V

    .line 819
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v1, p1}, Lcom/thinkware/sundo/ieve/ieveNative;->EnableModeAR(Z)Z

    move-result v0

    .line 820
    .local v0, "ret":Z
    if-nez v0, :cond_2

    .line 821
    const-string v3, "java_IEVE"

    const-string v4, "enableModeAR[%s:false][0x%08x]"

    new-array v5, v8, [Ljava/lang/Object;

    if-eqz p1, :cond_1

    const-string v1, "true"

    :goto_1
    aput-object v1, v5, v2

    invoke-virtual {p0}, Lcom/thinkware/sundo/ieve/IEVE;->getStatus()I

    move-result v1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    aput-object v1, v5, v7

    invoke-static {v4, v5}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v3, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    move v1, v2

    .line 832
    :goto_2
    return v1

    .line 818
    .end local v0    # "ret":Z
    :cond_0
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->s:Landroid/graphics/Rect;

    goto :goto_0

    .line 821
    .restart local v0    # "ret":Z
    :cond_1
    const-string v1, "false"

    goto :goto_1

    .line 824
    :cond_2
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v1, p2}, Lcom/thinkware/sundo/ieve/ieveNative;->EnableModeDR(Z)Z

    move-result v0

    .line 825
    if-nez v0, :cond_4

    .line 826
    const-string v3, "java_IEVE"

    const-string v4, "enableModeDR[%s:false][0x%08x]"

    new-array v5, v8, [Ljava/lang/Object;

    if-eqz p2, :cond_3

    const-string v1, "true"

    :goto_3
    aput-object v1, v5, v2

    invoke-virtual {p0}, Lcom/thinkware/sundo/ieve/IEVE;->getStatus()I

    move-result v1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    aput-object v1, v5, v7

    invoke-static {v4, v5}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v3, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    move v1, v2

    .line 827
    goto :goto_2

    .line 826
    :cond_3
    const-string v1, "false"

    goto :goto_3

    .line 829
    :cond_4
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    iget-object v3, p0, Lcom/thinkware/sundo/ieve/IEVE;->t:Landroid/graphics/Rect;

    iget v3, v3, Landroid/graphics/Rect;->left:I

    iget-object v4, p0, Lcom/thinkware/sundo/ieve/IEVE;->t:Landroid/graphics/Rect;

    iget v4, v4, Landroid/graphics/Rect;->top:I

    iget-object v5, p0, Lcom/thinkware/sundo/ieve/IEVE;->t:Landroid/graphics/Rect;

    invoke-virtual {v5}, Landroid/graphics/Rect;->width()I

    move-result v5

    iget-object v6, p0, Lcom/thinkware/sundo/ieve/IEVE;->t:Landroid/graphics/Rect;

    invoke-virtual {v6}, Landroid/graphics/Rect;->height()I

    move-result v6

    invoke-virtual {v1, v3, v4, v5, v6}, Lcom/thinkware/sundo/ieve/ieveNative;->SetSizeView(IIII)V

    .line 830
    invoke-virtual {p0}, Lcom/thinkware/sundo/ieve/IEVE;->getStatus()I

    move-result v1

    invoke-direct {p0, v1}, Lcom/thinkware/sundo/ieve/IEVE;->b(I)V

    .line 831
    const-string v3, "java_IEVE"

    const-string v4, "enableModeAR[%s,DR:%s][0x%08x]"

    const/4 v1, 0x3

    new-array v5, v1, [Ljava/lang/Object;

    if-eqz p1, :cond_5

    const-string v1, "true"

    :goto_4
    aput-object v1, v5, v2

    if-eqz p2, :cond_6

    const-string v1, "true"

    :goto_5
    aput-object v1, v5, v7

    invoke-virtual {p0}, Lcom/thinkware/sundo/ieve/IEVE;->getStatus()I

    move-result v1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    aput-object v1, v5, v8

    invoke-static {v4, v5}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v3, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    move v1, v0

    .line 832
    goto :goto_2

    .line 831
    :cond_5
    const-string v1, "false"

    goto :goto_4

    :cond_6
    const-string v1, "false"

    goto :goto_5
.end method

.method public enableModeFindVP(Z)Z
    .locals 6
    .param p1, "enable"    # Z

    .prologue
    .line 837
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v1, p1}, Lcom/thinkware/sundo/ieve/ieveNative;->EnableModeFindVP(Z)Z

    move-result v0

    .line 838
    .local v0, "ret":Z
    invoke-virtual {p0}, Lcom/thinkware/sundo/ieve/IEVE;->getStatus()I

    move-result v1

    invoke-direct {p0, v1}, Lcom/thinkware/sundo/ieve/IEVE;->b(I)V

    .line 839
    const-string v2, "java_IEVE"

    const-string v3, "enableModeFindVP[%s][0x%08x]"

    const/4 v1, 0x2

    new-array v4, v1, [Ljava/lang/Object;

    const/4 v5, 0x0

    if-eqz p1, :cond_0

    const-string v1, "true"

    :goto_0
    aput-object v1, v4, v5

    const/4 v1, 0x1

    invoke-virtual {p0}, Lcom/thinkware/sundo/ieve/IEVE;->getStatus()I

    move-result v5

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    aput-object v5, v4, v1

    invoke-static {v3, v4}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v2, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 840
    return v0

    .line 839
    :cond_0
    const-string v1, "false"

    goto :goto_0
.end method

.method public enableModeRecogCSWS(Z)Z
    .locals 6
    .param p1, "enable"    # Z

    .prologue
    .line 845
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v1, p1}, Lcom/thinkware/sundo/ieve/ieveNative;->EnableModeRecogCSWS(Z)Z

    move-result v0

    .line 846
    .local v0, "ret":Z
    const-string v2, "java_IEVE"

    const-string v3, "enableModeRecogCSWS[%s][0x%08x]"

    const/4 v1, 0x2

    new-array v4, v1, [Ljava/lang/Object;

    const/4 v5, 0x0

    if-eqz p1, :cond_0

    const-string v1, "true"

    :goto_0
    aput-object v1, v4, v5

    const/4 v1, 0x1

    invoke-virtual {p0}, Lcom/thinkware/sundo/ieve/IEVE;->getStatus()I

    move-result v5

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    aput-object v5, v4, v1

    invoke-static {v3, v4}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v2, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 847
    return v0

    .line 846
    :cond_0
    const-string v1, "false"

    goto :goto_0
.end method

.method public enableModeRecogFCWS(Z)Z
    .locals 6
    .param p1, "enable"    # Z

    .prologue
    .line 853
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->d:Lcom/stradvision/pdvdtest/SV_ADAS;

    invoke-virtual {v1, p1}, Lcom/stradvision/pdvdtest/SV_ADAS;->EnableModeRecogFCWS(Z)Z

    move-result v0

    .line 855
    .local v0, "ret":Z
    invoke-virtual {p0}, Lcom/thinkware/sundo/ieve/IEVE;->getStatus()I

    move-result v1

    invoke-direct {p0, v1}, Lcom/thinkware/sundo/ieve/IEVE;->b(I)V

    .line 856
    const-string v2, "java_IEVE"

    const-string v3, "enableModeRecogFCWS[%s][0x%08x]"

    const/4 v1, 0x2

    new-array v4, v1, [Ljava/lang/Object;

    const/4 v5, 0x0

    if-eqz p1, :cond_0

    const-string v1, "true"

    :goto_0
    aput-object v1, v4, v5

    const/4 v1, 0x1

    invoke-virtual {p0}, Lcom/thinkware/sundo/ieve/IEVE;->getStatus()I

    move-result v5

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    aput-object v5, v4, v1

    invoke-static {v3, v4}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v2, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 857
    return v0

    .line 856
    :cond_0
    const-string v1, "false"

    goto :goto_0
.end method

.method public enableModeRecogFVSA(Z)Z
    .locals 6
    .param p1, "enable"    # Z

    .prologue
    .line 862
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v1, p1}, Lcom/thinkware/sundo/ieve/ieveNative;->EnableModeRecogFVSA(Z)Z

    move-result v0

    .line 863
    .local v0, "ret":Z
    invoke-virtual {p0}, Lcom/thinkware/sundo/ieve/IEVE;->getStatus()I

    move-result v1

    invoke-direct {p0, v1}, Lcom/thinkware/sundo/ieve/IEVE;->b(I)V

    .line 864
    const-string v2, "java_IEVE"

    const-string v3, "enableModeRecogFVSA[%s][0x%08x]"

    const/4 v1, 0x2

    new-array v4, v1, [Ljava/lang/Object;

    const/4 v5, 0x0

    if-eqz p1, :cond_0

    const-string v1, "true"

    :goto_0
    aput-object v1, v4, v5

    const/4 v1, 0x1

    invoke-virtual {p0}, Lcom/thinkware/sundo/ieve/IEVE;->getStatus()I

    move-result v5

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    aput-object v5, v4, v1

    invoke-static {v3, v4}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v2, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 865
    return v0

    .line 864
    :cond_0
    const-string v1, "false"

    goto :goto_0
.end method

.method public enableModeRecogLDWC(Z)Z
    .locals 6
    .param p1, "enable"    # Z

    .prologue
    .line 870
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v1, p1}, Lcom/thinkware/sundo/ieve/ieveNative;->EnableModeRecogLDWC(Z)Z

    move-result v0

    .line 871
    .local v0, "ret":Z
    invoke-virtual {p0}, Lcom/thinkware/sundo/ieve/IEVE;->getStatus()I

    move-result v1

    invoke-direct {p0, v1}, Lcom/thinkware/sundo/ieve/IEVE;->b(I)V

    .line 872
    const-string v2, "java_IEVE"

    const-string v3, "enableModeRecogLDWC[%s][0x%08x]"

    const/4 v1, 0x2

    new-array v4, v1, [Ljava/lang/Object;

    const/4 v5, 0x0

    if-eqz p1, :cond_0

    const-string v1, "true"

    :goto_0
    aput-object v1, v4, v5

    const/4 v1, 0x1

    invoke-virtual {p0}, Lcom/thinkware/sundo/ieve/IEVE;->getStatus()I

    move-result v5

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    aput-object v5, v4, v1

    invoke-static {v3, v4}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v2, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 873
    return v0

    .line 872
    :cond_0
    const-string v1, "false"

    goto :goto_0
.end method

.method public enableModeRecogLDWS(Z)Z
    .locals 6
    .param p1, "enable"    # Z

    .prologue
    .line 878
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v1, p1}, Lcom/thinkware/sundo/ieve/ieveNative;->EnableModeRecogLDWS(Z)Z

    move-result v0

    .line 879
    .local v0, "ret":Z
    invoke-virtual {p0}, Lcom/thinkware/sundo/ieve/IEVE;->getStatus()I

    move-result v1

    invoke-direct {p0, v1}, Lcom/thinkware/sundo/ieve/IEVE;->b(I)V

    .line 880
    const-string v2, "java_IEVE"

    const-string v3, "enableModeRecogLDWS[%s][0x%08x]"

    const/4 v1, 0x2

    new-array v4, v1, [Ljava/lang/Object;

    const/4 v5, 0x0

    if-eqz p1, :cond_0

    const-string v1, "true"

    :goto_0
    aput-object v1, v4, v5

    const/4 v1, 0x1

    invoke-virtual {p0}, Lcom/thinkware/sundo/ieve/IEVE;->getStatus()I

    move-result v5

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    aput-object v5, v4, v1

    invoke-static {v3, v4}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v2, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 881
    return v0

    .line 880
    :cond_0
    const-string v1, "false"

    goto :goto_0
.end method

.method public enableModeRecogPCWS(Z)Z
    .locals 6
    .param p1, "enable"    # Z

    .prologue
    .line 887
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->d:Lcom/stradvision/pdvdtest/SV_ADAS;

    invoke-virtual {v1, p1}, Lcom/stradvision/pdvdtest/SV_ADAS;->EnableModeRecogPCWS(Z)Z

    move-result v0

    .line 889
    .local v0, "ret":Z
    invoke-virtual {p0}, Lcom/thinkware/sundo/ieve/IEVE;->getStatus()I

    move-result v1

    invoke-direct {p0, v1}, Lcom/thinkware/sundo/ieve/IEVE;->b(I)V

    .line 890
    const-string v2, "java_IEVE"

    const-string v3, "enableModeRecogPCWS[%s][0x%08x]"

    const/4 v1, 0x2

    new-array v4, v1, [Ljava/lang/Object;

    const/4 v5, 0x0

    if-eqz p1, :cond_0

    const-string v1, "true"

    :goto_0
    aput-object v1, v4, v5

    const/4 v1, 0x1

    invoke-virtual {p0}, Lcom/thinkware/sundo/ieve/IEVE;->getStatus()I

    move-result v5

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    aput-object v5, v4, v1

    invoke-static {v3, v4}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v2, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 891
    return v0

    .line 890
    :cond_0
    const-string v1, "false"

    goto :goto_0
.end method

.method public enableModeRecogPLCA(Z)Z
    .locals 6
    .param p1, "enable"    # Z

    .prologue
    .line 896
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v1, p1}, Lcom/thinkware/sundo/ieve/ieveNative;->EnableModeRecogPLCA(Z)Z

    move-result v0

    .line 897
    .local v0, "ret":Z
    invoke-virtual {p0}, Lcom/thinkware/sundo/ieve/IEVE;->getStatus()I

    move-result v1

    invoke-direct {p0, v1}, Lcom/thinkware/sundo/ieve/IEVE;->b(I)V

    .line 898
    const-string v2, "java_IEVE"

    const-string v3, "enableModeRecogPLCA[%s][0x%08x]"

    const/4 v1, 0x2

    new-array v4, v1, [Ljava/lang/Object;

    const/4 v5, 0x0

    if-eqz p1, :cond_0

    const-string v1, "true"

    :goto_0
    aput-object v1, v4, v5

    const/4 v1, 0x1

    invoke-virtual {p0}, Lcom/thinkware/sundo/ieve/IEVE;->getStatus()I

    move-result v5

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    aput-object v5, v4, v1

    invoke-static {v3, v4}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v2, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 899
    return v0

    .line 898
    :cond_0
    const-string v1, "false"

    goto :goto_0
.end method

.method public enableModeRecogTLCA(Z)Z
    .locals 6
    .param p1, "enable"    # Z

    .prologue
    .line 904
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v1, p1}, Lcom/thinkware/sundo/ieve/ieveNative;->EnableModeRecogTLCA(Z)Z

    move-result v0

    .line 905
    .local v0, "ret":Z
    invoke-virtual {p0}, Lcom/thinkware/sundo/ieve/IEVE;->getStatus()I

    move-result v1

    invoke-direct {p0, v1}, Lcom/thinkware/sundo/ieve/IEVE;->b(I)V

    .line 906
    const-string v2, "java_IEVE"

    const-string v3, "enableModeRecogTLCA[%s][0x%08x]"

    const/4 v1, 0x2

    new-array v4, v1, [Ljava/lang/Object;

    const/4 v5, 0x0

    if-eqz p1, :cond_0

    const-string v1, "true"

    :goto_0
    aput-object v1, v4, v5

    const/4 v1, 0x1

    invoke-virtual {p0}, Lcom/thinkware/sundo/ieve/IEVE;->getStatus()I

    move-result v5

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    aput-object v5, v4, v1

    invoke-static {v3, v4}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v2, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 907
    return v0

    .line 906
    :cond_0
    const-string v1, "false"

    goto :goto_0
.end method

.method public enableModeRecogUFCW(Z)Z
    .locals 6
    .param p1, "enable"    # Z

    .prologue
    .line 913
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->d:Lcom/stradvision/pdvdtest/SV_ADAS;

    invoke-virtual {v1, p1}, Lcom/stradvision/pdvdtest/SV_ADAS;->EnableModeRecogUFCW(Z)Z

    move-result v0

    .line 915
    .local v0, "ret":Z
    invoke-virtual {p0}, Lcom/thinkware/sundo/ieve/IEVE;->getStatus()I

    move-result v1

    invoke-direct {p0, v1}, Lcom/thinkware/sundo/ieve/IEVE;->b(I)V

    .line 916
    const-string v2, "java_IEVE"

    const-string v3, "enableModeRecogUFCW[%s][0x%08x]"

    const/4 v1, 0x2

    new-array v4, v1, [Ljava/lang/Object;

    const/4 v5, 0x0

    if-eqz p1, :cond_0

    const-string v1, "true"

    :goto_0
    aput-object v1, v4, v5

    const/4 v1, 0x1

    invoke-virtual {p0}, Lcom/thinkware/sundo/ieve/IEVE;->getStatus()I

    move-result v5

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    aput-object v5, v4, v1

    invoke-static {v3, v4}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v2, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 917
    return v0

    .line 916
    :cond_0
    const-string v1, "false"

    goto :goto_0
.end method

.method public enableSimulationMode(Z)V
    .locals 5
    .param p1, "enable"    # Z

    .prologue
    .line 922
    const-string v1, "java_IEVE"

    const-string v2, "enableSimulationMode[%s]"

    const/4 v0, 0x1

    new-array v3, v0, [Ljava/lang/Object;

    const/4 v4, 0x0

    if-eqz p1, :cond_0

    const-string v0, "true"

    :goto_0
    aput-object v0, v3, v4

    invoke-static {v2, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 923
    iput-boolean p1, p0, Lcom/thinkware/sundo/ieve/IEVE;->U:Z

    .line 924
    return-void

    .line 922
    :cond_0
    const-string v0, "false"

    goto :goto_0
.end method

.method public getAngleRegularFromGPS(D)D
    .locals 3
    .param p1, "angle"    # D

    .prologue
    .line 2826
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0, p1, p2}, Lcom/thinkware/sundo/ieve/ieveNative;->GetAngleRegularFromGPS(D)D

    move-result-wide v0

    return-wide v0
.end method

.method public getBitmapSnapshot()Landroid/graphics/Bitmap;
    .locals 1

    .prologue
    .line 928
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->j:Lcom/thinkware/sundo/ieve/ieveCameraView;

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->j:Lcom/thinkware/sundo/ieve/ieveCameraView;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveCameraView;->getBitmapSnapshot()Landroid/graphics/Bitmap;

    move-result-object v0

    :goto_0
    return-object v0

    :cond_0
    const/4 v0, 0x0

    goto :goto_0
.end method

.method public getCalcDistFCWS()F
    .locals 1

    .prologue
    .line 933
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->GetCalcDistFCWS()F

    move-result v0

    return v0
.end method

.method public getCalcTTCFCWS()F
    .locals 1

    .prologue
    .line 938
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->GetCalcTTCFCWS()F

    move-result v0

    return v0
.end method

.method public getCalibrationLastMode()I
    .locals 1

    .prologue
    .line 943
    iget v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->C:I

    return v0
.end method

.method public getCameraModelType()I
    .locals 1

    .prologue
    .line 948
    iget v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->l:I

    return v0
.end method

.method public getCarAngleDirectionFromVP()F
    .locals 1

    .prologue
    .line 953
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->GetCarAngleDirectionFromVP()F

    move-result v0

    return v0
.end method

.method public getCarAngleVerticalFromVP()F
    .locals 1

    .prologue
    .line 958
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->GetCarAngleVerticalFromVP()F

    move-result v0

    return v0
.end method

.method public getCarShadowGPS()Z
    .locals 1

    .prologue
    .line 963
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->GetCarShadowGPS()Z

    move-result v0

    return v0
.end method

.method public getCarSpeedK()I
    .locals 1

    .prologue
    .line 978
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->GetCarSpeedK()I

    move-result v0

    return v0
.end method

.method public getCarSpeedKDummyDR()I
    .locals 1

    .prologue
    .line 988
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->GetCarSpeedKDummyDR()I

    move-result v0

    return v0
.end method

.method public getCarSpeedKmH()F
    .locals 2

    .prologue
    .line 983
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->GetCarSpeedK()I

    move-result v0

    int-to-float v0, v0

    const/high16 v1, 0x41200000    # 10.0f

    div-float/2addr v0, v1

    return v0
.end method

.method public getCarStatusGPS()I
    .locals 1

    .prologue
    .line 968
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->GetCarStatusGPS()I

    move-result v0

    return v0
.end method

.method public getCarType()I
    .locals 1

    .prologue
    .line 973
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->GetCarType()I

    move-result v0

    return v0
.end method

.method public getDeviceCameraHeight()I
    .locals 1

    .prologue
    .line 993
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->GetDeviceCameraHeight()I

    move-result v0

    return v0
.end method

.method public getDeviceCameraHeightDefault()I
    .locals 1

    .prologue
    .line 998
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->GetDeviceCameraHeightDefault()I

    move-result v0

    return v0
.end method

.method public getDeviceCameraHeightMax()I
    .locals 1

    .prologue
    .line 1003
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->GetDeviceCameraHeightMax()I

    move-result v0

    return v0
.end method

.method public getDeviceCameraHeightMin()I
    .locals 1

    .prologue
    .line 1008
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->GetDeviceCameraHeightMin()I

    move-result v0

    return v0
.end method

.method public getDeviceModelType()I
    .locals 1

    .prologue
    .line 1013
    iget v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->k:I

    return v0
.end method

.method public getDistMeterOfArcOnEarth(DDDD)D
    .locals 11
    .param p1, "lat1"    # D
    .param p3, "lon1"    # D
    .param p5, "lat2"    # D
    .param p7, "lon2"    # D

    .prologue
    .line 2830
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    move-wide v2, p1

    move-wide v4, p3

    move-wide/from16 v6, p5

    move-wide/from16 v8, p7

    invoke-virtual/range {v1 .. v9}, Lcom/thinkware/sundo/ieve/ieveNative;->GetDistMeterOfArcOnEarth(DDDD)D

    move-result-wide v0

    return-wide v0
.end method

.method public getDistMeterOfLatitude(DD)D
    .locals 3
    .param p1, "lat_pos"    # D
    .param p3, "lat_base"    # D

    .prologue
    .line 2834
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0, p1, p2, p3, p4}, Lcom/thinkware/sundo/ieve/ieveNative;->GetDistMeterOfLatitude(DD)D

    move-result-wide v0

    return-wide v0
.end method

.method public getDistMeterOfLongitude(DDD)D
    .locals 9
    .param p1, "lot_pos"    # D
    .param p3, "lot_base"    # D
    .param p5, "lat_base"    # D

    .prologue
    .line 2838
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    move-wide v2, p1

    move-wide v4, p3

    move-wide v6, p5

    invoke-virtual/range {v1 .. v7}, Lcom/thinkware/sundo/ieve/ieveNative;->GetDistMeterOfLongitude(DDD)D

    move-result-wide v0

    return-wide v0
.end method

.method public getFrameRateADAS()D
    .locals 2

    .prologue
    .line 1018
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->GetFrameRateADAS()D

    move-result-wide v0

    return-wide v0
.end method

.method public getFrameRateAR()D
    .locals 2

    .prologue
    .line 1023
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->GetFrameRateAR()D

    move-result-wide v0

    return-wide v0
.end method

.method protected getFreqCountIEVE()D
    .locals 2

    .prologue
    .line 1028
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->GetFreqCountIEVE()D

    move-result-wide v0

    return-wide v0
.end method

.method public getGuideInfos()Lcom/thinkware/sundo/ieve/ieveGuideInfos;
    .locals 1

    .prologue
    .line 1033
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->f:Lcom/thinkware/sundo/ieve/ieveGuideInfos;

    return-object v0
.end method

.method public getHandDrive()I
    .locals 1

    .prologue
    .line 1038
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->GetHandDrive()I

    move-result v0

    return v0
.end method

.method public getHandlerIeve()Landroid/os/Handler;
    .locals 1

    .prologue
    .line 1043
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->am:Landroid/os/Handler;

    return-object v0
.end method

.method public getHandlerParent()Landroid/os/Handler;
    .locals 1

    .prologue
    .line 1048
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->c:Landroid/os/Handler;

    return-object v0
.end method

.method public getIEVEConfigValue(I)I
    .locals 2
    .param p1, "id"    # I

    .prologue
    .line 1053
    const/4 v0, -0x1

    .line 1054
    .local v0, "value":I
    sparse-switch p1, :sswitch_data_0

    .line 1077
    :cond_0
    :goto_0
    return v0

    .line 1055
    :sswitch_0
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v1}, Lcom/thinkware/sundo/ieve/ieveNative;->GetROILeftStep()I

    move-result v0

    goto :goto_0

    .line 1056
    :sswitch_1
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v1}, Lcom/thinkware/sundo/ieve/ieveNative;->GetROIRightStep()I

    move-result v0

    goto :goto_0

    .line 1058
    :sswitch_2
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v1}, Lcom/thinkware/sundo/ieve/ieveNative;->GetDeviceCameraHeight()I

    move-result v0

    goto :goto_0

    .line 1059
    :sswitch_3
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v1}, Lcom/thinkware/sundo/ieve/ieveNative;->GetDeviceCameraHeightDefault()I

    move-result v0

    goto :goto_0

    .line 1061
    :sswitch_4
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v1}, Lcom/thinkware/sundo/ieve/ieveNative;->GetVanishingPointXFromImage()I

    move-result v0

    goto :goto_0

    .line 1062
    :sswitch_5
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v1}, Lcom/thinkware/sundo/ieve/ieveNative;->GetVanishingPointYFromImage()I

    move-result v0

    goto :goto_0

    .line 1065
    :sswitch_6
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v1}, Lcom/thinkware/sundo/ieve/ieveNative;->GetROILeft()I

    move-result v0

    goto :goto_0

    .line 1066
    :sswitch_7
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v1}, Lcom/thinkware/sundo/ieve/ieveNative;->GetROIRight()I

    move-result v0

    goto :goto_0

    .line 1067
    :sswitch_8
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v1}, Lcom/thinkware/sundo/ieve/ieveNative;->GetROIBottom()I

    move-result v0

    goto :goto_0

    .line 1068
    :sswitch_9
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v1}, Lcom/thinkware/sundo/ieve/ieveNative;->GetROILeftDefault()I

    move-result v0

    goto :goto_0

    .line 1069
    :sswitch_a
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v1}, Lcom/thinkware/sundo/ieve/ieveNative;->GetROIRightDefault()I

    move-result v0

    goto :goto_0

    .line 1070
    :sswitch_b
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v1}, Lcom/thinkware/sundo/ieve/ieveNative;->GetROIBottomDefault()I

    move-result v0

    goto :goto_0

    .line 1071
    :sswitch_c
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->T:Lcom/thinkware/sundo/ieve/ieveSoundManager;

    if-eqz v1, :cond_0

    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->T:Lcom/thinkware/sundo/ieve/ieveSoundManager;

    invoke-virtual {v1}, Lcom/thinkware/sundo/ieve/ieveSoundManager;->getSoundVolume()I

    move-result v0

    goto :goto_0

    .line 1072
    :sswitch_d
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->T:Lcom/thinkware/sundo/ieve/ieveSoundManager;

    if-eqz v1, :cond_0

    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->T:Lcom/thinkware/sundo/ieve/ieveSoundManager;

    invoke-virtual {v1}, Lcom/thinkware/sundo/ieve/ieveSoundManager;->getSoundMaxVolume()I

    move-result v0

    goto :goto_0

    .line 1054
    nop

    :sswitch_data_0
    .sparse-switch
        0x7100 -> :sswitch_6
        0x7101 -> :sswitch_7
        0x7102 -> :sswitch_8
        0x7110 -> :sswitch_9
        0x7111 -> :sswitch_a
        0x7112 -> :sswitch_b
        0x7120 -> :sswitch_0
        0x7121 -> :sswitch_1
        0x7200 -> :sswitch_2
        0x7201 -> :sswitch_3
        0x7300 -> :sswitch_4
        0x7301 -> :sswitch_5
        0x7400 -> :sswitch_c
        0x7401 -> :sswitch_d
    .end sparse-switch
.end method

.method public getLanguage()I
    .locals 1

    .prologue
    .line 1089
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->GetLanguage()I

    move-result v0

    return v0
.end method

.method public getLastRecog(I)I
    .locals 1
    .param p1, "index"    # I

    .prologue
    .line 2945
    packed-switch p1, :pswitch_data_0

    .line 2955
    const/4 v0, 0x0

    :goto_0
    return v0

    .line 2946
    :pswitch_0
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->GetLastRecogCSWS()I

    move-result v0

    goto :goto_0

    .line 2947
    :pswitch_1
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->GetLastRecogFCWS()I

    move-result v0

    goto :goto_0

    .line 2948
    :pswitch_2
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->GetLastRecogFVSA()I

    move-result v0

    goto :goto_0

    .line 2949
    :pswitch_3
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->GetLastRecogLDWS()I

    move-result v0

    goto :goto_0

    .line 2950
    :pswitch_4
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->GetLastRecogPLCA()I

    move-result v0

    goto :goto_0

    .line 2951
    :pswitch_5
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->GetLastRecogTLCA()I

    move-result v0

    goto :goto_0

    .line 2952
    :pswitch_6
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->GetLastRecogPCWS()I

    move-result v0

    goto :goto_0

    .line 2945
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
        :pswitch_1
        :pswitch_2
        :pswitch_3
        :pswitch_4
        :pswitch_5
        :pswitch_6
    .end packed-switch
.end method

.method public getMaxProcessFPS()D
    .locals 2

    .prologue
    .line 1094
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->j:Lcom/thinkware/sundo/ieve/ieveCameraView;

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->j:Lcom/thinkware/sundo/ieve/ieveCameraView;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveCameraView;->getPreviewCallbackMaxFPS()D

    move-result-wide v0

    :goto_0
    return-wide v0

    :cond_0
    const-wide/16 v0, 0x0

    goto :goto_0
.end method

.method public getNScreenManager()Lcom/thinkware/sundo/ieve/ieveNScreenManager;
    .locals 1

    .prologue
    .line 1104
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->g:Lcom/thinkware/sundo/ieve/ieveNScreenManager;

    return-object v0
.end method

.method protected getNative()Lcom/thinkware/sundo/ieve/ieveNative;
    .locals 1

    .prologue
    .line 1099
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    return-object v0
.end method

.method protected getProcessingTime(I)D
    .locals 2
    .param p1, "index"    # I

    .prologue
    .line 2960
    packed-switch p1, :pswitch_data_0

    .line 2979
    :pswitch_0
    const-wide/16 v0, 0x0

    :goto_0
    return-wide v0

    .line 2961
    :pswitch_1
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->GetProcessTimeRecog()D

    move-result-wide v0

    goto :goto_0

    .line 2962
    :pswitch_2
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->GetProcessTimeRecogAvr()D

    move-result-wide v0

    goto :goto_0

    .line 2963
    :pswitch_3
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->GetProcessTimeSetImage()D

    move-result-wide v0

    goto :goto_0

    .line 2964
    :pswitch_4
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->GetProcessTimeSetImageAvr()D

    move-result-wide v0

    goto :goto_0

    .line 2965
    :pswitch_5
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->GetProcessTimeDR()D

    move-result-wide v0

    goto :goto_0

    .line 2966
    :pswitch_6
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->GetProcessTimeVP()D

    move-result-wide v0

    goto :goto_0

    .line 2967
    :pswitch_7
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->GetProcessTimeFVSA()D

    move-result-wide v0

    goto :goto_0

    .line 2968
    :pswitch_8
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->GetProcessTimeFVSAAvr()D

    move-result-wide v0

    goto :goto_0

    .line 2969
    :pswitch_9
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->GetProcessTimeLDWS()D

    move-result-wide v0

    goto :goto_0

    .line 2970
    :pswitch_a
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->GetProcessTimeLDWSAvr()D

    move-result-wide v0

    goto :goto_0

    .line 2971
    :pswitch_b
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->GetProcessTimeTLCA()D

    move-result-wide v0

    goto :goto_0

    .line 2972
    :pswitch_c
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->GetProcessTimeTLCAAvr()D

    move-result-wide v0

    goto :goto_0

    .line 2973
    :pswitch_d
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->GetProcessTimeFCWS()D

    move-result-wide v0

    goto :goto_0

    .line 2974
    :pswitch_e
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->GetProcessTimeFCWSAvr()D

    move-result-wide v0

    goto :goto_0

    .line 2960
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_3
        :pswitch_5
        :pswitch_6
        :pswitch_7
        :pswitch_9
        :pswitch_b
        :pswitch_d
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_2
        :pswitch_4
        :pswitch_0
        :pswitch_0
        :pswitch_8
        :pswitch_a
        :pswitch_c
        :pswitch_e
    .end packed-switch
.end method

.method public getProposeToAdjustCamera()I
    .locals 6

    .prologue
    .line 1109
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v1}, Lcom/thinkware/sundo/ieve/ieveNative;->GetProposeToAdjustCamera()I

    move-result v0

    .line 1110
    .local v0, "ret":I
    iget v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->R:I

    if-eq v0, v1, :cond_0

    const-string v1, "java_IEVE"

    const-string v2, "getProposeToAdjustCamera[0x%04x]"

    const/4 v3, 0x1

    new-array v3, v3, [Ljava/lang/Object;

    const/4 v4, 0x0

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    aput-object v5, v3, v4

    invoke-static {v2, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 1111
    :cond_0
    iput v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->R:I

    .line 1112
    return v0
.end method

.method public getROIBottom()I
    .locals 1

    .prologue
    .line 1152
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->GetROIBottom()I

    move-result v0

    return v0
.end method

.method public getROIBottomDefault()I
    .locals 1

    .prologue
    .line 1157
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->GetROIBottomDefault()I

    move-result v0

    return v0
.end method

.method public getROILeft()I
    .locals 1

    .prologue
    .line 1162
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->GetROILeft()I

    move-result v0

    return v0
.end method

.method public getROILeftDefault()I
    .locals 1

    .prologue
    .line 1167
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->GetROILeftDefault()I

    move-result v0

    return v0
.end method

.method public getROILeftStep()I
    .locals 1

    .prologue
    .line 1172
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->GetROILeftStep()I

    move-result v0

    return v0
.end method

.method public getROILeftStepDefault()I
    .locals 1

    .prologue
    .line 1177
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->GetROILeftStepDefault()I

    move-result v0

    return v0
.end method

.method public getROIRight()I
    .locals 1

    .prologue
    .line 1182
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->GetROIRight()I

    move-result v0

    return v0
.end method

.method public getROIRightDefault()I
    .locals 1

    .prologue
    .line 1187
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->GetROIRightDefault()I

    move-result v0

    return v0
.end method

.method public getROIRightStep()I
    .locals 1

    .prologue
    .line 1192
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->GetROIRightStep()I

    move-result v0

    return v0
.end method

.method public getROIRightStepDefault()I
    .locals 1

    .prologue
    .line 1197
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->GetROIRightStepDefault()I

    move-result v0

    return v0
.end method

.method public getRecogResultCSWS()I
    .locals 1

    .prologue
    .line 1117
    iget v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->D:I

    return v0
.end method

.method public getRecogResultFCWS()I
    .locals 1

    .prologue
    .line 1122
    iget v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->E:I

    return v0
.end method

.method public getRecogResultFVSA()I
    .locals 1

    .prologue
    .line 1127
    iget v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->F:I

    return v0
.end method

.method public getRecogResultLDWS()I
    .locals 1

    .prologue
    .line 1132
    iget v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->G:I

    return v0
.end method

.method public getRecogResultPCWS()I
    .locals 1

    .prologue
    .line 1137
    iget v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->H:I

    return v0
.end method

.method public getRecogResultPLCA()I
    .locals 1

    .prologue
    .line 1142
    iget v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->I:I

    return v0
.end method

.method public getRecogResultTLCA()I
    .locals 1

    .prologue
    .line 1147
    iget v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->J:I

    return v0
.end method

.method public getSensitivityCSWS()I
    .locals 1

    .prologue
    .line 1202
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->GetSensitivityCSWS()I

    move-result v0

    return v0
.end method

.method public getSensitivityFCWS()I
    .locals 1

    .prologue
    .line 1207
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->GetSensitivityFCWS()I

    move-result v0

    return v0
.end method

.method public getSensitivityPCWS()I
    .locals 1

    .prologue
    .line 1212
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->GetSensitivityPCWS()I

    move-result v0

    return v0
.end method

.method public getSizeArView()Landroid/graphics/Rect;
    .locals 1

    .prologue
    .line 1217
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->t:Landroid/graphics/Rect;

    return-object v0
.end method

.method public getSizeCameraView()Landroid/graphics/Rect;
    .locals 1

    .prologue
    .line 1232
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->v:Landroid/graphics/Rect;

    return-object v0
.end method

.method public getSizeCaptureHeight()I
    .locals 1

    .prologue
    .line 1227
    iget v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->A:I

    return v0
.end method

.method public getSizeCaptureWidth()I
    .locals 1

    .prologue
    .line 1222
    iget v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->z:I

    return v0
.end method

.method public getSizeScreenView()Landroid/graphics/Rect;
    .locals 1

    .prologue
    .line 1237
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->x:Landroid/graphics/Rect;

    return-object v0
.end method

.method public getSoundManager()Lcom/thinkware/sundo/ieve/ieveSoundManager;
    .locals 1

    .prologue
    .line 1242
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->T:Lcom/thinkware/sundo/ieve/ieveSoundManager;

    return-object v0
.end method

.method public getSoundMaxVolume()I
    .locals 1

    .prologue
    .line 1253
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->T:Lcom/thinkware/sundo/ieve/ieveSoundManager;

    if-nez v0, :cond_0

    const/4 v0, 0x0

    .line 1254
    :goto_0
    return v0

    :cond_0
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->T:Lcom/thinkware/sundo/ieve/ieveSoundManager;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveSoundManager;->getSoundMaxVolume()I

    move-result v0

    goto :goto_0
.end method

.method public getSoundVolume()I
    .locals 1

    .prologue
    .line 1247
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->T:Lcom/thinkware/sundo/ieve/ieveSoundManager;

    if-nez v0, :cond_0

    const/4 v0, 0x0

    .line 1248
    :goto_0
    return v0

    :cond_0
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->T:Lcom/thinkware/sundo/ieve/ieveSoundManager;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveSoundManager;->getSoundVolume()I

    move-result v0

    goto :goto_0
.end method

.method public getStatus()I
    .locals 1

    .prologue
    .line 1269
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->GetIeveMode()I

    move-result v0

    return v0
.end method

.method public getStradVision()Lcom/stradvision/pdvdtest/SV_ADAS;
    .locals 1

    .prologue
    .line 1083
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->d:Lcom/stradvision/pdvdtest/SV_ADAS;

    return-object v0
.end method

.method public getStreamSecondsAfter()I
    .locals 1

    .prologue
    .line 1259
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->j:Lcom/thinkware/sundo/ieve/ieveCameraView;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveCameraView;->getStreamSecondsAfter()I

    move-result v0

    return v0
.end method

.method public getStreamSecondsBefore()I
    .locals 1

    .prologue
    .line 1264
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->j:Lcom/thinkware/sundo/ieve/ieveCameraView;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveCameraView;->getStreamSecondsBefore()I

    move-result v0

    return v0
.end method

.method public getUseSunFilm()Z
    .locals 1

    .prologue
    .line 1274
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->GetUseSunFilm()Z

    move-result v0

    return v0
.end method

.method public getVanishingPointX()I
    .locals 1

    .prologue
    .line 1279
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->GetVanishingPointXFromImage()I

    move-result v0

    return v0
.end method

.method public getVanishingPointY()I
    .locals 1

    .prologue
    .line 1284
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->GetVanishingPointYFromImage()I

    move-result v0

    return v0
.end method

.method public getVersion()Ljava/lang/String;
    .locals 5

    .prologue
    .line 1289
    const-string v0, "java_IEVE"

    const-string v1, "getVersion[%s]"

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    iget-object v4, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v4}, Lcom/thinkware/sundo/ieve/ieveNative;->GetVersion()Ljava/lang/String;

    move-result-object v4

    aput-object v4, v2, v3

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 1290
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->GetVersion()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getVersionFCWS()Ljava/lang/String;
    .locals 5

    .prologue
    .line 1295
    const-string v0, "java_IEVE"

    const-string v1, "getVersionFCWS[%s]"

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    iget-object v4, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v4}, Lcom/thinkware/sundo/ieve/ieveNative;->GetVersionFCWS()Ljava/lang/String;

    move-result-object v4

    aput-object v4, v2, v3

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 1296
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->GetVersionFCWS()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getVersionFVSA()Ljava/lang/String;
    .locals 5

    .prologue
    .line 1301
    const-string v0, "java_IEVE"

    const-string v1, "getVersionFVSA[%s]"

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    iget-object v4, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v4}, Lcom/thinkware/sundo/ieve/ieveNative;->GetVersionFVSA()Ljava/lang/String;

    move-result-object v4

    aput-object v4, v2, v3

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 1302
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->GetVersionFVSA()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getVersionLDWS()Ljava/lang/String;
    .locals 5

    .prologue
    .line 1307
    const-string v0, "java_IEVE"

    const-string v1, "getVersionLDWS[%s]"

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    iget-object v4, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v4}, Lcom/thinkware/sundo/ieve/ieveNative;->GetVersionLDWS()Ljava/lang/String;

    move-result-object v4

    aput-object v4, v2, v3

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 1308
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->GetVersionLDWS()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getVersionPCWS()Ljava/lang/String;
    .locals 5

    .prologue
    .line 1313
    const-string v0, "java_IEVE"

    const-string v1, "getVersionPCWS[%s]"

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    iget-object v4, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v4}, Lcom/thinkware/sundo/ieve/ieveNative;->GetVersionPCWS()Ljava/lang/String;

    move-result-object v4

    aput-object v4, v2, v3

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 1314
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->GetVersionPCWS()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getVersionTLCA()Ljava/lang/String;
    .locals 5

    .prologue
    .line 1319
    const-string v0, "java_IEVE"

    const-string v1, "getVersionTLCA[%s]"

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    iget-object v4, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v4}, Lcom/thinkware/sundo/ieve/ieveNative;->GetVersionTLCA()Ljava/lang/String;

    move-result-object v4

    aput-object v4, v2, v3

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 1320
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->GetVersionTLCA()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getViewCalibrationView()Lcom/thinkware/sundo/ieve/ieveCalibrationView;
    .locals 1

    .prologue
    .line 1325
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->i:Lcom/thinkware/sundo/ieve/ieveCalibrationView;

    return-object v0
.end method

.method public getViewCameraView()Lcom/thinkware/sundo/ieve/ieveCameraView;
    .locals 1

    .prologue
    .line 1330
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->j:Lcom/thinkware/sundo/ieve/ieveCameraView;

    return-object v0
.end method

.method public getViewDebugView()Lcom/thinkware/sundo/ieve/ieveTextView;
    .locals 1

    .prologue
    .line 2983
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->at:Lcom/thinkware/sundo/ieve/ieveTextView;

    return-object v0
.end method

.method public hasChangedVP()Z
    .locals 2

    .prologue
    .line 1342
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->S:Landroid/graphics/Point;

    iget v0, v0, Landroid/graphics/Point;->x:I

    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v1}, Lcom/thinkware/sundo/ieve/ieveNative;->GetVanishingPointXFromImage()I

    move-result v1

    if-ne v0, v1, :cond_0

    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->S:Landroid/graphics/Point;

    iget v0, v0, Landroid/graphics/Point;->y:I

    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v1}, Lcom/thinkware/sundo/ieve/ieveNative;->GetVanishingPointYFromImage()I

    move-result v1

    if-eq v0, v1, :cond_1

    .line 1343
    :cond_0
    const-string v0, "java_IEVE"

    const-string v1, "hasChangedVP[Changed]"

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 1344
    const/4 v0, 0x1

    .line 1348
    :goto_0
    return v0

    :cond_1
    const/4 v0, 0x0

    goto :goto_0
.end method

.method public initialize(Ljava/lang/String;Landroid/graphics/Rect;Lcom/thinkware/sundo/ieve/ieveNScreenManager;IIIILjava/lang/String;)Z
    .locals 47
    .param p1, "respath"    # Ljava/lang/String;
    .param p2, "sizescreen"    # Landroid/graphics/Rect;
    .param p3, "nscreenmanager"    # Lcom/thinkware/sundo/ieve/ieveNScreenManager;
    .param p4, "devicemodeltype"    # I
    .param p5, "cameramodeltype"    # I
    .param p6, "cameraid"    # I
    .param p7, "language"    # I
    .param p8, "encryptfolder"    # Ljava/lang/String;

    .prologue
    .line 1355
    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v22

    .line 1356
    .local v22, "_UptimeBase":J
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->b:Landroid/content/Context;

    if-nez v2, :cond_0

    const/4 v2, 0x0

    .line 1609
    .end local p8    # "encryptfolder":Ljava/lang/String;
    :goto_0
    return v2

    .line 1357
    .restart local p8    # "encryptfolder":Ljava/lang/String;
    :cond_0
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->am:Landroid/os/Handler;

    if-nez v2, :cond_1

    const/4 v2, 0x0

    goto :goto_0

    .line 1358
    :cond_1
    if-eqz p1, :cond_2

    invoke-virtual/range {p1 .. p1}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_3

    .line 1359
    :cond_2
    const-string v2, "Initialize error[Resource path is NULL!]"

    const/4 v3, 0x0

    new-array v3, v3, [Ljava/lang/Object;

    invoke-static {v2, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v46

    .line 1360
    .local v46, "text":Ljava/lang/String;
    const-string v2, "java_IEVE"

    move-object/from16 v0, v46

    invoke-static {v2, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 1361
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->am:Landroid/os/Handler;

    move-object/from16 v0, p0

    iget-object v3, v0, Lcom/thinkware/sundo/ieve/IEVE;->am:Landroid/os/Handler;

    const/16 v4, 0x4af

    move-object/from16 v0, v46

    invoke-static {v3, v4, v0}, Landroid/os/Message;->obtain(Landroid/os/Handler;ILjava/lang/Object;)Landroid/os/Message;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    .line 1362
    const/4 v2, 0x0

    goto :goto_0

    .line 1364
    .end local v46    # "text":Ljava/lang/String;
    :cond_3
    if-nez p3, :cond_4

    .line 1365
    const-string v2, "Initialize error[ieveNScreenManager is NULL!]"

    const/4 v3, 0x0

    new-array v3, v3, [Ljava/lang/Object;

    invoke-static {v2, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v46

    .line 1366
    .restart local v46    # "text":Ljava/lang/String;
    const-string v2, "java_IEVE"

    move-object/from16 v0, v46

    invoke-static {v2, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 1367
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->am:Landroid/os/Handler;

    move-object/from16 v0, p0

    iget-object v3, v0, Lcom/thinkware/sundo/ieve/IEVE;->am:Landroid/os/Handler;

    const/16 v4, 0x4af

    move-object/from16 v0, v46

    invoke-static {v3, v4, v0}, Landroid/os/Message;->obtain(Landroid/os/Handler;ILjava/lang/Object;)Landroid/os/Message;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    .line 1368
    const/4 v2, 0x0

    goto :goto_0

    .line 1371
    .end local v46    # "text":Ljava/lang/String;
    :cond_4
    if-gez p7, :cond_5

    .line 1372
    const-string v2, "Initialize error[Invalid language code]"

    const/4 v3, 0x0

    new-array v3, v3, [Ljava/lang/Object;

    invoke-static {v2, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v46

    .line 1373
    .restart local v46    # "text":Ljava/lang/String;
    const-string v2, "java_IEVE"

    move-object/from16 v0, v46

    invoke-static {v2, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 1374
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->am:Landroid/os/Handler;

    move-object/from16 v0, p0

    iget-object v3, v0, Lcom/thinkware/sundo/ieve/IEVE;->am:Landroid/os/Handler;

    const/16 v4, 0x4af

    move-object/from16 v0, v46

    invoke-static {v3, v4, v0}, Landroid/os/Message;->obtain(Landroid/os/Handler;ILjava/lang/Object;)Landroid/os/Message;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    .line 1375
    const/4 v2, 0x0

    goto/16 :goto_0

    .line 1378
    .end local v46    # "text":Ljava/lang/String;
    :cond_5
    move-object/from16 v0, p3

    move-object/from16 v1, p0

    iput-object v0, v1, Lcom/thinkware/sundo/ieve/IEVE;->g:Lcom/thinkware/sundo/ieve/ieveNScreenManager;

    .line 1379
    move/from16 v0, p4

    move-object/from16 v1, p0

    iput v0, v1, Lcom/thinkware/sundo/ieve/IEVE;->k:I

    .line 1380
    move/from16 v0, p5

    move-object/from16 v1, p0

    iput v0, v1, Lcom/thinkware/sundo/ieve/IEVE;->l:I

    .line 1381
    move/from16 v0, p6

    move-object/from16 v1, p0

    iput v0, v1, Lcom/thinkware/sundo/ieve/IEVE;->m:I

    .line 1382
    const-string v2, "java_IEVE"

    const-string v3, "DeviceModelType[%d], CameraModelType[%d], CameraID[%d]"

    const/4 v4, 0x3

    new-array v4, v4, [Ljava/lang/Object;

    const/4 v5, 0x0

    move-object/from16 v0, p0

    iget v0, v0, Lcom/thinkware/sundo/ieve/IEVE;->k:I

    move/from16 v16, v0

    invoke-static/range {v16 .. v16}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v16

    aput-object v16, v4, v5

    const/4 v5, 0x1

    move-object/from16 v0, p0

    iget v0, v0, Lcom/thinkware/sundo/ieve/IEVE;->l:I

    move/from16 v16, v0

    invoke-static/range {v16 .. v16}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v16

    aput-object v16, v4, v5

    const/4 v5, 0x2

    move-object/from16 v0, p0

    iget v0, v0, Lcom/thinkware/sundo/ieve/IEVE;->m:I

    move/from16 v16, v0

    invoke-static/range {v16 .. v16}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v16

    aput-object v16, v4, v5

    invoke-static {v3, v4}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 1384
    move-object/from16 v0, p0

    iget v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->l:I

    const/4 v3, 0x2

    if-ne v2, v3, :cond_7

    .line 1385
    const/16 v2, 0x140

    move-object/from16 v0, p0

    iput v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_IMAGESIZE_QVGA_WIDTH:I

    .line 1386
    const/16 v2, 0xb4

    move-object/from16 v0, p0

    iput v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_IMAGESIZE_QVGA_HEIGHT:I

    .line 1393
    :goto_1
    move-object/from16 v0, p0

    iget v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_IMAGESIZE_QVGA_WIDTH:I

    div-int/lit8 v2, v2, 0x2

    move-object/from16 v0, p0

    iput v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_IMAGESIZE_QVGA_WIDTH_2:I

    .line 1394
    move-object/from16 v0, p0

    iget v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_IMAGESIZE_QVGA_HEIGHT:I

    div-int/lit8 v2, v2, 0x2

    move-object/from16 v0, p0

    iput v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_IMAGESIZE_QVGA_HEIGHT_2:I

    .line 1395
    move-object/from16 v0, p0

    iget v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_IMAGESIZE_QVGA_WIDTH:I

    move-object/from16 v0, p0

    iget v3, v0, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_IMAGESIZE_QVGA_HEIGHT:I

    mul-int/2addr v2, v3

    move-object/from16 v0, p0

    iput v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_IMAGESIZE_QVGA:I

    .line 1396
    move-object/from16 v0, p0

    iget v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_IMAGESIZE_QVGA_WIDTH:I

    int-to-double v2, v2

    move-object/from16 v0, p0

    iget v4, v0, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_IMAGESIZE_QVGA_HEIGHT:I

    int-to-double v4, v4

    div-double/2addr v2, v4

    move-object/from16 v0, p0

    iput-wide v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_IMAGESIZE_QVGA_ASPECTRATIO:D

    .line 1397
    move-object/from16 v0, p0

    iget v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_IMAGESIZE_QVGA_WIDTH:I

    mul-int/lit8 v2, v2, 0x2

    move-object/from16 v0, p0

    iput v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_IMAGESIZE_VGA_WIDTH:I

    .line 1398
    move-object/from16 v0, p0

    iget v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_IMAGESIZE_QVGA_HEIGHT:I

    mul-int/lit8 v2, v2, 0x2

    move-object/from16 v0, p0

    iput v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_IMAGESIZE_VGA_HEIGHT:I

    .line 1399
    move-object/from16 v0, p0

    iget v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_IMAGESIZE_QVGA_WIDTH:I

    move-object/from16 v0, p0

    iput v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_IMAGESIZE_VGA_WIDTH_2:I

    .line 1400
    move-object/from16 v0, p0

    iget v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_IMAGESIZE_QVGA_HEIGHT:I

    move-object/from16 v0, p0

    iput v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_IMAGESIZE_VGA_HEIGHT_2:I

    .line 1401
    move-object/from16 v0, p0

    iget v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_IMAGESIZE_VGA_WIDTH:I

    move-object/from16 v0, p0

    iget v3, v0, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_IMAGESIZE_VGA_HEIGHT:I

    mul-int/2addr v2, v3

    move-object/from16 v0, p0

    iput v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_IMAGESIZE_VGA:I

    .line 1402
    move-object/from16 v0, p0

    iget v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_IMAGESIZE_VGA_WIDTH:I

    int-to-double v2, v2

    move-object/from16 v0, p0

    iget v4, v0, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_IMAGESIZE_VGA_HEIGHT:I

    int-to-double v4, v4

    div-double/2addr v2, v4

    move-object/from16 v0, p0

    iput-wide v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_IMAGESIZE_VGA_ASPECTRATIO:D

    .line 1403
    const/16 v2, 0x500

    move-object/from16 v0, p0

    iput v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_IMAGESIZE_HD720_WIDTH:I

    .line 1404
    const/16 v2, 0x2d0

    move-object/from16 v0, p0

    iput v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_IMAGESIZE_HD720_HEIGHT:I

    .line 1405
    move-object/from16 v0, p0

    iget v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_IMAGESIZE_QVGA_WIDTH:I

    move-object/from16 v0, p0

    iput v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_IMAGESIZE_INFO_WIDTH:I

    .line 1406
    move-object/from16 v0, p0

    iget v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_IMAGESIZE_QVGA_HEIGHT:I

    move-object/from16 v0, p0

    iput v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_IMAGESIZE_INFO_HEIGHT:I

    .line 1408
    move-object/from16 v0, p0

    iget v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->l:I

    packed-switch v2, :pswitch_data_0

    .line 1414
    move-object/from16 v0, p0

    iget v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_IMAGESIZE_VGA_WIDTH:I

    move-object/from16 v0, p0

    iput v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->z:I

    .line 1415
    move-object/from16 v0, p0

    iget v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_IMAGESIZE_VGA_HEIGHT:I

    move-object/from16 v0, p0

    iput v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->A:I

    .line 1418
    :goto_2
    const/16 v2, 0x11

    move-object/from16 v0, p0

    iput v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->y:I

    .line 1421
    const/16 v32, 0x0

    .line 1422
    .local v32, "idraw_cswa":I
    const/16 v33, 0x0

    .line 1423
    .local v33, "idraw_csww":I
    const/4 v6, 0x0

    .line 1424
    .local v6, "idraw_fcwa":I
    const/4 v7, 0x0

    .line 1425
    .local v7, "idraw_fcww":I
    const/16 v34, 0x0

    .line 1426
    .local v34, "idraw_fvsa":I
    const/16 v35, 0x0

    .line 1427
    .local v35, "idraw_ldwc":I
    const/16 v36, 0x0

    .line 1428
    .local v36, "idraw_ldws":I
    const/4 v8, 0x0

    .line 1429
    .local v8, "idraw_pcwa":I
    const/4 v9, 0x0

    .line 1430
    .local v9, "idraw_pcww":I
    const/16 v37, 0x0

    .line 1431
    .local v37, "idraw_plca":I
    const/16 v38, 0x0

    .line 1432
    .local v38, "idraw_tlca":I
    const-string v30, ""

    .line 1434
    .local v30, "context_packname":Ljava/lang/String;
    :try_start_0
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->b:Landroid/content/Context;

    invoke-virtual {v2}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v30

    .line 1435
    const-string v2, "java_IEVE"

    new-instance v3, Ljava/lang/StringBuilder;

    const-string v4, "Package Name:"

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    move-object/from16 v0, v30

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 1436
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->b:Landroid/content/Context;

    invoke-virtual {v2}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v2

    move-object/from16 v0, v30

    invoke-virtual {v2, v0}, Landroid/content/pm/PackageManager;->getResourcesForApplication(Ljava/lang/String;)Landroid/content/res/Resources;

    move-result-object v44

    .line 1438
    .local v44, "res":Landroid/content/res/Resources;
    const-string v2, "ieve_cswa"

    const-string v3, "raw"

    move-object/from16 v0, v44

    move-object/from16 v1, v30

    invoke-virtual {v0, v2, v3, v1}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v32

    .line 1439
    const-string v2, "ieve_csww"

    const-string v3, "raw"

    move-object/from16 v0, v44

    move-object/from16 v1, v30

    invoke-virtual {v0, v2, v3, v1}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v33

    .line 1440
    const-string v2, "ieve_fcwa"

    const-string v3, "raw"

    move-object/from16 v0, v44

    move-object/from16 v1, v30

    invoke-virtual {v0, v2, v3, v1}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v6

    .line 1441
    const-string v2, "ieve_fcww"

    const-string v3, "raw"

    move-object/from16 v0, v44

    move-object/from16 v1, v30

    invoke-virtual {v0, v2, v3, v1}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v7

    .line 1442
    const-string v2, "ieve_fvsa"

    const-string v3, "raw"

    move-object/from16 v0, v44

    move-object/from16 v1, v30

    invoke-virtual {v0, v2, v3, v1}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v34

    .line 1443
    const-string v2, "ieve_ldwc"

    const-string v3, "raw"

    move-object/from16 v0, v44

    move-object/from16 v1, v30

    invoke-virtual {v0, v2, v3, v1}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v35

    .line 1444
    const-string v2, "ieve_ldws"

    const-string v3, "raw"

    move-object/from16 v0, v44

    move-object/from16 v1, v30

    invoke-virtual {v0, v2, v3, v1}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v36

    .line 1445
    const-string v2, "ieve_pcwa"

    const-string v3, "raw"

    move-object/from16 v0, v44

    move-object/from16 v1, v30

    invoke-virtual {v0, v2, v3, v1}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v8

    .line 1446
    const-string v2, "ieve_pcww"

    const-string v3, "raw"

    move-object/from16 v0, v44

    move-object/from16 v1, v30

    invoke-virtual {v0, v2, v3, v1}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v9

    .line 1447
    const-string v2, "ieve_plca"

    const-string v3, "raw"

    move-object/from16 v0, v44

    move-object/from16 v1, v30

    invoke-virtual {v0, v2, v3, v1}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v37

    .line 1448
    const-string v2, "ieve_tlca"

    const-string v3, "raw"

    move-object/from16 v0, v44

    move-object/from16 v1, v30

    invoke-virtual {v0, v2, v3, v1}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v38

    .line 1451
    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v24

    .line 1452
    .local v24, "_UptimeBaseSV":J
    const-string v2, "fcws_detection"

    const-string v3, "drawable"

    move-object/from16 v0, v44

    move-object/from16 v1, v30

    invoke-virtual {v0, v2, v3, v1}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v11

    .line 1453
    .local v11, "idpng_fcwd":I
    const-string v2, "fcws_attention"

    const-string v3, "drawable"

    move-object/from16 v0, v44

    move-object/from16 v1, v30

    invoke-virtual {v0, v2, v3, v1}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v10

    .line 1454
    .local v10, "idpng_fcwa":I
    const-string v2, "fcws_warning"

    const-string v3, "drawable"

    move-object/from16 v0, v44

    move-object/from16 v1, v30

    invoke-virtual {v0, v2, v3, v1}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v12

    .line 1455
    .local v12, "idpng_fcww":I
    const-string v2, "pcws_detection"

    const-string v3, "drawable"

    move-object/from16 v0, v44

    move-object/from16 v1, v30

    invoke-virtual {v0, v2, v3, v1}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v14

    .line 1456
    .local v14, "idpng_pcwd":I
    const-string v2, "pcws_attention"

    const-string v3, "drawable"

    move-object/from16 v0, v44

    move-object/from16 v1, v30

    invoke-virtual {v0, v2, v3, v1}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v13

    .line 1457
    .local v13, "idpng_pcwa":I
    const-string v2, "pcws_warning"

    const-string v3, "drawable"

    move-object/from16 v0, v44

    move-object/from16 v1, v30

    invoke-virtual {v0, v2, v3, v1}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v15

    .line 1458
    .local v15, "idpng_pcww":I
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->d:Lcom/stradvision/pdvdtest/SV_ADAS;

    move-object/from16 v0, p0

    iget-object v3, v0, Lcom/thinkware/sundo/ieve/IEVE;->b:Landroid/content/Context;

    move-object/from16 v0, p0

    iget v4, v0, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_IMAGESIZE_HD720_WIDTH:I

    move-object/from16 v0, p0

    iget v5, v0, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_IMAGESIZE_HD720_HEIGHT:I

    invoke-virtual/range {v2 .. v15}, Lcom/stradvision/pdvdtest/SV_ADAS;->Create(Landroid/content/Context;IIIIIIIIIIII)Z

    .line 1460
    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v2

    sub-long v26, v2, v24

    .line 1461
    .local v26, "_UptimeMsecPeriodSV":J
    const-string v2, "java_IEVE"

    const-string v3, "sv_adas.Create[Period:%.2fms]"

    const/4 v4, 0x1

    new-array v4, v4, [Ljava/lang/Object;

    const/4 v5, 0x0

    move-wide/from16 v0, v26

    long-to-double v0, v0

    move-wide/from16 v16, v0

    const-wide v18, 0x412e848000000000L    # 1000000.0

    div-double v16, v16, v18

    invoke-static/range {v16 .. v17}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v16

    aput-object v16, v4, v5

    invoke-static {v3, v4}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_0
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    .line 1468
    .end local v10    # "idpng_fcwa":I
    .end local v11    # "idpng_fcwd":I
    .end local v12    # "idpng_fcww":I
    .end local v13    # "idpng_pcwa":I
    .end local v14    # "idpng_pcwd":I
    .end local v15    # "idpng_pcww":I
    .end local v24    # "_UptimeBaseSV":J
    .end local v26    # "_UptimeMsecPeriodSV":J
    .end local v44    # "res":Landroid/content/res/Resources;
    :goto_3
    if-eqz v32, :cond_6

    if-eqz v33, :cond_6

    if-eqz v6, :cond_6

    if-eqz v7, :cond_6

    if-eqz v34, :cond_6

    if-eqz v35, :cond_6

    if-eqz v36, :cond_6

    if-eqz v8, :cond_6

    if-eqz v9, :cond_6

    if-eqz v37, :cond_6

    if-nez v38, :cond_13

    .line 1470
    :cond_6
    const-string v2, "Initialize error[load sound resource]"

    const/4 v3, 0x0

    new-array v3, v3, [Ljava/lang/Object;

    invoke-static {v2, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v46

    .line 1471
    .restart local v46    # "text":Ljava/lang/String;
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-static/range {v46 .. v46}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    invoke-direct {v3, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    if-nez v32, :cond_8

    const-string v2, "[CSWS]"

    :goto_4
    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    if-nez v33, :cond_9

    const-string v2, "[CSWW]"

    :goto_5
    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    if-nez v6, :cond_a

    const-string v2, "[FCWA]"

    :goto_6
    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    if-nez v7, :cond_b

    const-string v2, "[FCWW]"

    :goto_7
    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    if-nez v34, :cond_c

    const-string v2, "[FVSA]"

    :goto_8
    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    .line 1472
    if-nez v35, :cond_d

    const-string v2, "[LDWC]"

    :goto_9
    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    if-nez v36, :cond_e

    const-string v2, "[LDWS]"

    :goto_a
    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    if-nez v8, :cond_f

    const-string v2, "[PCWA]"

    :goto_b
    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    if-nez v9, :cond_10

    const-string v2, "[PCWW]"

    :goto_c
    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    if-nez v37, :cond_11

    const-string v2, "[PLCA]"

    :goto_d
    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    if-nez v38, :cond_12

    const-string v2, "[TLCA]"

    :goto_e
    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    .line 1471
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v46

    .line 1473
    const-string v2, "java_IEVE"

    move-object/from16 v0, v46

    invoke-static {v2, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 1474
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->am:Landroid/os/Handler;

    move-object/from16 v0, p0

    iget-object v3, v0, Lcom/thinkware/sundo/ieve/IEVE;->am:Landroid/os/Handler;

    const/16 v4, 0x4af

    move-object/from16 v0, v46

    invoke-static {v3, v4, v0}, Landroid/os/Message;->obtain(Landroid/os/Handler;ILjava/lang/Object;)Landroid/os/Message;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    .line 1475
    const/4 v2, 0x0

    goto/16 :goto_0

    .line 1389
    .end local v6    # "idraw_fcwa":I
    .end local v7    # "idraw_fcww":I
    .end local v8    # "idraw_pcwa":I
    .end local v9    # "idraw_pcww":I
    .end local v30    # "context_packname":Ljava/lang/String;
    .end local v32    # "idraw_cswa":I
    .end local v33    # "idraw_csww":I
    .end local v34    # "idraw_fvsa":I
    .end local v35    # "idraw_ldwc":I
    .end local v36    # "idraw_ldws":I
    .end local v37    # "idraw_plca":I
    .end local v38    # "idraw_tlca":I
    .end local v46    # "text":Ljava/lang/String;
    :cond_7
    const/16 v2, 0x140

    move-object/from16 v0, p0

    iput v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_IMAGESIZE_QVGA_WIDTH:I

    .line 1390
    const/16 v2, 0xf0

    move-object/from16 v0, p0

    iput v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_IMAGESIZE_QVGA_HEIGHT:I

    goto/16 :goto_1

    .line 1410
    :pswitch_0
    move-object/from16 v0, p0

    iget v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_IMAGESIZE_HD720_WIDTH:I

    move-object/from16 v0, p0

    iput v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->z:I

    .line 1411
    move-object/from16 v0, p0

    iget v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_IMAGESIZE_HD720_HEIGHT:I

    move-object/from16 v0, p0

    iput v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->A:I

    goto/16 :goto_2

    .line 1463
    .restart local v6    # "idraw_fcwa":I
    .restart local v7    # "idraw_fcww":I
    .restart local v8    # "idraw_pcwa":I
    .restart local v9    # "idraw_pcww":I
    .restart local v30    # "context_packname":Ljava/lang/String;
    .restart local v32    # "idraw_cswa":I
    .restart local v33    # "idraw_csww":I
    .restart local v34    # "idraw_fvsa":I
    .restart local v35    # "idraw_ldwc":I
    .restart local v36    # "idraw_ldws":I
    .restart local v37    # "idraw_plca":I
    .restart local v38    # "idraw_tlca":I
    :catch_0
    move-exception v31

    .line 1464
    .local v31, "e1":Landroid/content/pm/PackageManager$NameNotFoundException;
    invoke-virtual/range {v31 .. v31}, Landroid/content/pm/PackageManager$NameNotFoundException;->printStackTrace()V

    .line 1465
    const-string v2, "java_IEVE"

    new-instance v3, Ljava/lang/StringBuilder;

    const-string v4, "Initialize:"

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual/range {v31 .. v31}, Landroid/content/pm/PackageManager$NameNotFoundException;->getLocalizedMessage()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, "]"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    goto/16 :goto_3

    .line 1471
    .end local v31    # "e1":Landroid/content/pm/PackageManager$NameNotFoundException;
    .restart local v46    # "text":Ljava/lang/String;
    :cond_8
    const-string v2, ""

    goto/16 :goto_4

    :cond_9
    const-string v2, ""

    goto/16 :goto_5

    :cond_a
    const-string v2, ""

    goto/16 :goto_6

    :cond_b
    const-string v2, ""

    goto/16 :goto_7

    :cond_c
    const-string v2, ""

    goto/16 :goto_8

    .line 1472
    :cond_d
    const-string v2, ""

    goto/16 :goto_9

    :cond_e
    const-string v2, ""

    goto/16 :goto_a

    :cond_f
    const-string v2, ""

    goto/16 :goto_b

    :cond_10
    const-string v2, ""

    goto/16 :goto_c

    :cond_11
    const-string v2, ""

    goto/16 :goto_d

    :cond_12
    const-string v2, ""

    goto/16 :goto_e

    .line 1479
    .end local v46    # "text":Ljava/lang/String;
    :cond_13
    new-instance v2, Lcom/thinkware/sundo/ieve/ieveSoundManager;

    move-object/from16 v0, p0

    iget-object v3, v0, Lcom/thinkware/sundo/ieve/IEVE;->b:Landroid/content/Context;

    const/4 v4, 0x3

    invoke-direct {v2, v3, v4}, Lcom/thinkware/sundo/ieve/ieveSoundManager;-><init>(Landroid/content/Context;I)V

    move-object/from16 v0, p0

    iput-object v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->T:Lcom/thinkware/sundo/ieve/ieveSoundManager;

    .line 1480
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->T:Lcom/thinkware/sundo/ieve/ieveSoundManager;

    if-nez v2, :cond_14

    .line 1481
    const-string v2, "Initialize error[ieveSoundManager is NULL!]"

    const/4 v3, 0x0

    new-array v3, v3, [Ljava/lang/Object;

    invoke-static {v2, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v46

    .line 1482
    .restart local v46    # "text":Ljava/lang/String;
    const-string v2, "java_IEVE"

    move-object/from16 v0, v46

    invoke-static {v2, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 1483
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->am:Landroid/os/Handler;

    move-object/from16 v0, p0

    iget-object v3, v0, Lcom/thinkware/sundo/ieve/IEVE;->am:Landroid/os/Handler;

    const/16 v4, 0x4af

    move-object/from16 v0, v46

    invoke-static {v3, v4, v0}, Landroid/os/Message;->obtain(Landroid/os/Handler;ILjava/lang/Object;)Landroid/os/Message;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    .line 1484
    const/4 v2, 0x0

    goto/16 :goto_0

    .line 1487
    .end local v46    # "text":Ljava/lang/String;
    :cond_14
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->T:Lcom/thinkware/sundo/ieve/ieveSoundManager;

    const/4 v3, 0x7

    move/from16 v0, v32

    invoke-virtual {v2, v3, v0}, Lcom/thinkware/sundo/ieve/ieveSoundManager;->addSound(II)Z

    move-result v2

    if-nez v2, :cond_15

    const/4 v2, 0x0

    goto/16 :goto_0

    .line 1488
    :cond_15
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->T:Lcom/thinkware/sundo/ieve/ieveSoundManager;

    const/16 v3, 0x8

    move/from16 v0, v33

    invoke-virtual {v2, v3, v0}, Lcom/thinkware/sundo/ieve/ieveSoundManager;->addSound(II)Z

    move-result v2

    if-nez v2, :cond_16

    const/4 v2, 0x0

    goto/16 :goto_0

    .line 1489
    :cond_16
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->T:Lcom/thinkware/sundo/ieve/ieveSoundManager;

    const/4 v3, 0x0

    move/from16 v0, v35

    invoke-virtual {v2, v3, v0}, Lcom/thinkware/sundo/ieve/ieveSoundManager;->addSound(II)Z

    move-result v2

    if-nez v2, :cond_17

    const/4 v2, 0x0

    goto/16 :goto_0

    .line 1490
    :cond_17
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->T:Lcom/thinkware/sundo/ieve/ieveSoundManager;

    const/4 v3, 0x1

    move/from16 v0, v36

    invoke-virtual {v2, v3, v0}, Lcom/thinkware/sundo/ieve/ieveSoundManager;->addSound(II)Z

    move-result v2

    if-nez v2, :cond_18

    const/4 v2, 0x0

    goto/16 :goto_0

    .line 1491
    :cond_18
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->T:Lcom/thinkware/sundo/ieve/ieveSoundManager;

    const/4 v3, 0x5

    invoke-virtual {v2, v3, v6}, Lcom/thinkware/sundo/ieve/ieveSoundManager;->addSound(II)Z

    move-result v2

    if-nez v2, :cond_19

    const/4 v2, 0x0

    goto/16 :goto_0

    .line 1492
    :cond_19
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->T:Lcom/thinkware/sundo/ieve/ieveSoundManager;

    const/4 v3, 0x6

    invoke-virtual {v2, v3, v7}, Lcom/thinkware/sundo/ieve/ieveSoundManager;->addSound(II)Z

    move-result v2

    if-nez v2, :cond_1a

    const/4 v2, 0x0

    goto/16 :goto_0

    .line 1493
    :cond_1a
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->T:Lcom/thinkware/sundo/ieve/ieveSoundManager;

    const/4 v3, 0x2

    move/from16 v0, v34

    invoke-virtual {v2, v3, v0}, Lcom/thinkware/sundo/ieve/ieveSoundManager;->addSound(II)Z

    move-result v2

    if-nez v2, :cond_1b

    const/4 v2, 0x0

    goto/16 :goto_0

    .line 1494
    :cond_1b
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->T:Lcom/thinkware/sundo/ieve/ieveSoundManager;

    const/16 v3, 0x9

    invoke-virtual {v2, v3, v8}, Lcom/thinkware/sundo/ieve/ieveSoundManager;->addSound(II)Z

    move-result v2

    if-nez v2, :cond_1c

    const/4 v2, 0x0

    goto/16 :goto_0

    .line 1495
    :cond_1c
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->T:Lcom/thinkware/sundo/ieve/ieveSoundManager;

    const/16 v3, 0xa

    invoke-virtual {v2, v3, v9}, Lcom/thinkware/sundo/ieve/ieveSoundManager;->addSound(II)Z

    move-result v2

    if-nez v2, :cond_1d

    const/4 v2, 0x0

    goto/16 :goto_0

    .line 1496
    :cond_1d
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->T:Lcom/thinkware/sundo/ieve/ieveSoundManager;

    const/4 v3, 0x4

    move/from16 v0, v37

    invoke-virtual {v2, v3, v0}, Lcom/thinkware/sundo/ieve/ieveSoundManager;->addSound(II)Z

    move-result v2

    if-nez v2, :cond_1e

    const/4 v2, 0x0

    goto/16 :goto_0

    .line 1497
    :cond_1e
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->T:Lcom/thinkware/sundo/ieve/ieveSoundManager;

    const/4 v3, 0x3

    move/from16 v0, v38

    invoke-virtual {v2, v3, v0}, Lcom/thinkware/sundo/ieve/ieveSoundManager;->addSound(II)Z

    move-result v2

    if-nez v2, :cond_1f

    const/4 v2, 0x0

    goto/16 :goto_0

    .line 1499
    :cond_1f
    new-instance v2, Landroid/graphics/Point;

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-direct {v2, v3, v4}, Landroid/graphics/Point;-><init>(II)V

    move-object/from16 v0, p0

    iput-object v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->S:Landroid/graphics/Point;

    .line 1501
    new-instance v2, Landroid/graphics/Rect;

    move-object/from16 v0, p2

    invoke-direct {v2, v0}, Landroid/graphics/Rect;-><init>(Landroid/graphics/Rect;)V

    move-object/from16 v0, p0

    iput-object v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->x:Landroid/graphics/Rect;

    .line 1502
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->x:Landroid/graphics/Rect;

    invoke-virtual {v2}, Landroid/graphics/Rect;->width()I

    move-result v2

    int-to-float v2, v2

    const/high16 v3, 0x44800000    # 1024.0f

    div-float v42, v2, v3

    .line 1503
    .local v42, "ratio_resolution_x":F
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->x:Landroid/graphics/Rect;

    invoke-virtual {v2}, Landroid/graphics/Rect;->height()I

    move-result v2

    int-to-float v2, v2

    const/high16 v3, 0x44160000    # 600.0f

    div-float v43, v2, v3

    .line 1504
    .local v43, "ratio_resolution_y":F
    const/16 v40, 0x0

    .line 1505
    .local v40, "offset_y":I
    move-object/from16 v0, p0

    iget v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->l:I

    const/4 v3, 0x2

    if-eq v2, v3, :cond_20

    .line 1506
    move-object/from16 v0, p0

    iget v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->A:I

    int-to-float v2, v2

    move-object/from16 v0, p0

    iget v3, v0, Lcom/thinkware/sundo/ieve/IEVE;->z:I

    int-to-float v3, v3

    div-float v41, v2, v3

    .line 1507
    .local v41, "ratio_capture":F
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->x:Landroid/graphics/Rect;

    invoke-virtual {v2}, Landroid/graphics/Rect;->height()I

    move-result v2

    move-object/from16 v0, p0

    iget-object v3, v0, Lcom/thinkware/sundo/ieve/IEVE;->x:Landroid/graphics/Rect;

    invoke-virtual {v3}, Landroid/graphics/Rect;->width()I

    move-result v3

    int-to-float v3, v3

    mul-float v3, v3, v41

    float-to-int v3, v3

    sub-int/2addr v2, v3

    int-to-float v2, v2

    const/high16 v3, 0x40000000    # 2.0f

    div-float/2addr v2, v3

    float-to-int v0, v2

    move/from16 v40, v0

    .line 1508
    div-int/lit8 v40, v40, 0x2

    .line 1510
    .end local v41    # "ratio_capture":F
    :cond_20
    new-instance v2, Landroid/graphics/Rect;

    const/4 v3, 0x0

    move-object/from16 v0, p0

    iget-object v4, v0, Lcom/thinkware/sundo/ieve/IEVE;->x:Landroid/graphics/Rect;

    invoke-virtual {v4}, Landroid/graphics/Rect;->width()I

    move-result v4

    move-object/from16 v0, p0

    iget-object v5, v0, Lcom/thinkware/sundo/ieve/IEVE;->x:Landroid/graphics/Rect;

    invoke-virtual {v5}, Landroid/graphics/Rect;->height()I

    move-result v5

    sub-int v5, v5, v40

    move/from16 v0, v40

    invoke-direct {v2, v3, v0, v4, v5}, Landroid/graphics/Rect;-><init>(IIII)V

    move-object/from16 v0, p0

    iput-object v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->r:Landroid/graphics/Rect;

    .line 1511
    new-instance v2, Landroid/graphics/Rect;

    const/4 v3, 0x0

    const/4 v4, 0x0

    move-object/from16 v0, p0

    iget-object v5, v0, Lcom/thinkware/sundo/ieve/IEVE;->x:Landroid/graphics/Rect;

    invoke-virtual {v5}, Landroid/graphics/Rect;->width()I

    move-result v5

    const/high16 v16, 0x43a50000    # 330.0f

    mul-float v16, v16, v42

    invoke-static/range {v16 .. v16}, Lcom/thinkware/sundo/ieve/ieveMath;->ROUND_UP(F)I

    move-result v16

    sub-int v5, v5, v16

    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/ieve/IEVE;->x:Landroid/graphics/Rect;

    move-object/from16 v16, v0

    invoke-virtual/range {v16 .. v16}, Landroid/graphics/Rect;->height()I

    move-result v16

    move/from16 v0, v16

    invoke-direct {v2, v3, v4, v5, v0}, Landroid/graphics/Rect;-><init>(IIII)V

    move-object/from16 v0, p0

    iput-object v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->s:Landroid/graphics/Rect;

    .line 1512
    new-instance v2, Landroid/graphics/Rect;

    move-object/from16 v0, p0

    iget-object v3, v0, Lcom/thinkware/sundo/ieve/IEVE;->r:Landroid/graphics/Rect;

    invoke-direct {v2, v3}, Landroid/graphics/Rect;-><init>(Landroid/graphics/Rect;)V

    move-object/from16 v0, p0

    iput-object v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->t:Landroid/graphics/Rect;

    .line 1513
    move-object/from16 v0, p0

    iget v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->l:I

    const/4 v3, 0x2

    if-ne v2, v3, :cond_22

    .line 1514
    new-instance v2, Landroid/graphics/Rect;

    const/4 v3, 0x0

    const/4 v4, 0x0

    const v5, 0x441d4000    # 629.0f

    mul-float v5, v5, v42

    invoke-static {v5}, Lcom/thinkware/sundo/ieve/ieveMath;->ROUND_OFF(F)I

    move-result v5

    const v16, 0x43b18000    # 355.0f

    mul-float v16, v16, v43

    invoke-static/range {v16 .. v16}, Lcom/thinkware/sundo/ieve/ieveMath;->ROUND_OFF(F)I

    move-result v16

    move/from16 v0, v16

    invoke-direct {v2, v3, v4, v5, v0}, Landroid/graphics/Rect;-><init>(IIII)V

    move-object/from16 v0, p0

    iput-object v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->u:Landroid/graphics/Rect;

    .line 1519
    :goto_f
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->u:Landroid/graphics/Rect;

    const/high16 v3, 0x41e80000    # 29.0f

    mul-float v3, v3, v42

    invoke-static {v3}, Lcom/thinkware/sundo/ieve/ieveMath;->ROUND_OFF(F)I

    move-result v3

    const/high16 v4, 0x42b00000    # 88.0f

    mul-float v4, v4, v43

    invoke-static {v4}, Lcom/thinkware/sundo/ieve/ieveMath;->ROUND_OFF(F)I

    move-result v4

    invoke-virtual {v2, v3, v4}, Landroid/graphics/Rect;->offset(II)V

    .line 1520
    new-instance v2, Landroid/graphics/Rect;

    const/4 v3, 0x0

    const/4 v4, 0x0

    move-object/from16 v0, p0

    iget v5, v0, Lcom/thinkware/sundo/ieve/IEVE;->z:I

    move-object/from16 v0, p0

    iget v0, v0, Lcom/thinkware/sundo/ieve/IEVE;->A:I

    move/from16 v16, v0

    move/from16 v0, v16

    invoke-direct {v2, v3, v4, v5, v0}, Landroid/graphics/Rect;-><init>(IIII)V

    move-object/from16 v0, p0

    iput-object v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->v:Landroid/graphics/Rect;

    .line 1521
    new-instance v2, Landroid/graphics/Rect;

    move-object/from16 v0, p0

    iget v3, v0, Lcom/thinkware/sundo/ieve/IEVE;->z:I

    neg-int v3, v3

    add-int/lit8 v3, v3, -0x1

    move-object/from16 v0, p0

    iget v4, v0, Lcom/thinkware/sundo/ieve/IEVE;->A:I

    neg-int v4, v4

    add-int/lit8 v4, v4, -0x1

    const/4 v5, -0x1

    const/16 v16, -0x1

    move/from16 v0, v16

    invoke-direct {v2, v3, v4, v5, v0}, Landroid/graphics/Rect;-><init>(IIII)V

    move-object/from16 v0, p0

    iput-object v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->w:Landroid/graphics/Rect;

    .line 1524
    const-string v2, "java_IEVE"

    const-string v3, "offset_y_top:%d, offset_y_bottom:%d"

    const/4 v4, 0x2

    new-array v4, v4, [Ljava/lang/Object;

    const/4 v5, 0x0

    invoke-static/range {v40 .. v40}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v16

    aput-object v16, v4, v5

    const/4 v5, 0x1

    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/ieve/IEVE;->x:Landroid/graphics/Rect;

    move-object/from16 v16, v0

    invoke-virtual/range {v16 .. v16}, Landroid/graphics/Rect;->height()I

    move-result v16

    sub-int v16, v16, v40

    invoke-static/range {v16 .. v16}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v16

    aput-object v16, v4, v5

    invoke-static {v3, v4}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 1526
    new-instance v39, Lcom/thinkware/sundo/ieve/ieveInitInfos;

    invoke-direct/range {v39 .. v39}, Lcom/thinkware/sundo/ieve/ieveInitInfos;-><init>()V

    .line 1527
    .local v39, "info":Lcom/thinkware/sundo/ieve/ieveInitInfos;
    invoke-direct/range {p0 .. p0}, Lcom/thinkware/sundo/ieve/IEVE;->i()Ljava/lang/String;

    move-result-object v2

    move-object/from16 v0, v39

    iput-object v2, v0, Lcom/thinkware/sundo/ieve/ieveInitInfos;->uid:Ljava/lang/String;

    .line 1528
    move-object/from16 v0, p1

    move-object/from16 v1, v39

    iput-object v0, v1, Lcom/thinkware/sundo/ieve/ieveInitInfos;->respath:Ljava/lang/String;

    .line 1529
    if-eqz p8, :cond_23

    .end local p8    # "encryptfolder":Ljava/lang/String;
    :goto_10
    move-object/from16 v0, p8

    move-object/from16 v1, v39

    iput-object v0, v1, Lcom/thinkware/sundo/ieve/ieveInitInfos;->encryptfolder:Ljava/lang/String;

    .line 1530
    move/from16 v0, p7

    move-object/from16 v1, v39

    iput v0, v1, Lcom/thinkware/sundo/ieve/ieveInitInfos;->language:I

    .line 1531
    move-object/from16 v0, p0

    iget v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->k:I

    move-object/from16 v0, v39

    iput v2, v0, Lcom/thinkware/sundo/ieve/ieveInitInfos;->devicemodel:I

    .line 1532
    move-object/from16 v0, p0

    iget v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->l:I

    move-object/from16 v0, v39

    iput v2, v0, Lcom/thinkware/sundo/ieve/ieveInitInfos;->cameramodel:I

    .line 1533
    move-object/from16 v0, p0

    iget v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->y:I

    move-object/from16 v0, v39

    iput v2, v0, Lcom/thinkware/sundo/ieve/ieveInitInfos;->pixelformat:I

    .line 1534
    move-object/from16 v0, p0

    iget v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->z:I

    move-object/from16 v0, v39

    iput v2, v0, Lcom/thinkware/sundo/ieve/ieveInitInfos;->captureimagewidth:I

    .line 1535
    move-object/from16 v0, p0

    iget v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->A:I

    move-object/from16 v0, v39

    iput v2, v0, Lcom/thinkware/sundo/ieve/ieveInitInfos;->captureimageheight:I

    .line 1536
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->x:Landroid/graphics/Rect;

    invoke-virtual {v2}, Landroid/graphics/Rect;->width()I

    move-result v2

    move-object/from16 v0, v39

    iput v2, v0, Lcom/thinkware/sundo/ieve/ieveInitInfos;->sizescreenwidth:I

    .line 1537
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->x:Landroid/graphics/Rect;

    invoke-virtual {v2}, Landroid/graphics/Rect;->height()I

    move-result v2

    move-object/from16 v0, v39

    iput v2, v0, Lcom/thinkware/sundo/ieve/ieveInitInfos;->sizescreenheight:I

    .line 1538
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->t:Landroid/graphics/Rect;

    iget v2, v2, Landroid/graphics/Rect;->left:I

    move-object/from16 v0, v39

    iput v2, v0, Lcom/thinkware/sundo/ieve/ieveInitInfos;->sizeviewx:I

    .line 1539
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->t:Landroid/graphics/Rect;

    iget v2, v2, Landroid/graphics/Rect;->top:I

    move-object/from16 v0, v39

    iput v2, v0, Lcom/thinkware/sundo/ieve/ieveInitInfos;->sizeviewy:I

    .line 1540
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->t:Landroid/graphics/Rect;

    invoke-virtual {v2}, Landroid/graphics/Rect;->width()I

    move-result v2

    move-object/from16 v0, v39

    iput v2, v0, Lcom/thinkware/sundo/ieve/ieveInitInfos;->sizeviewwidth:I

    .line 1541
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->t:Landroid/graphics/Rect;

    invoke-virtual {v2}, Landroid/graphics/Rect;->height()I

    move-result v2

    move-object/from16 v0, v39

    iput v2, v0, Lcom/thinkware/sundo/ieve/ieveInitInfos;->sizeviewheight:I

    .line 1543
    const-string v2, "Initialize uid[%s]"

    const/4 v3, 0x1

    new-array v3, v3, [Ljava/lang/Object;

    const/4 v4, 0x0

    move-object/from16 v0, v39

    iget-object v5, v0, Lcom/thinkware/sundo/ieve/ieveInitInfos;->uid:Ljava/lang/String;

    aput-object v5, v3, v4

    invoke-static {v2, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v46

    .line 1544
    .restart local v46    # "text":Ljava/lang/String;
    const-string v2, "java_IEVE"

    move-object/from16 v0, v46

    invoke-static {v2, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 1547
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v2}, Lcom/thinkware/sundo/ieve/ieveNative;->IsInitialized()Z

    move-result v2

    if-nez v2, :cond_24

    .line 1548
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    move-object/from16 v0, v39

    invoke-virtual {v2, v0}, Lcom/thinkware/sundo/ieve/ieveNative;->Initialize(Lcom/thinkware/sundo/ieve/ieveInitInfos;)I

    move-result v45

    .line 1549
    .local v45, "ret":I
    if-eqz v45, :cond_24

    .line 1550
    const-string v2, "IEVE Initialize error[0x%04x]"

    const/4 v3, 0x1

    new-array v3, v3, [Ljava/lang/Object;

    const/4 v4, 0x0

    invoke-static/range {v45 .. v45}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    aput-object v5, v3, v4

    invoke-static {v2, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v46

    .line 1551
    const/16 v2, 0x1000

    move/from16 v0, v45

    if-ne v0, v2, :cond_21

    .line 1552
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-static/range {v46 .. v46}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string v3, ". Please check registration ID[%s]"

    const/4 v4, 0x1

    new-array v4, v4, [Ljava/lang/Object;

    const/4 v5, 0x0

    move-object/from16 v0, v39

    iget-object v0, v0, Lcom/thinkware/sundo/ieve/ieveInitInfos;->uid:Ljava/lang/String;

    move-object/from16 v16, v0

    aput-object v16, v4, v5

    invoke-static {v3, v4}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v46

    .line 1554
    :cond_21
    const-string v2, "java_IEVE"

    move-object/from16 v0, v46

    invoke-static {v2, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 1555
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->am:Landroid/os/Handler;

    move-object/from16 v0, p0

    iget-object v3, v0, Lcom/thinkware/sundo/ieve/IEVE;->am:Landroid/os/Handler;

    const/16 v4, 0x4af

    move-object/from16 v0, v46

    invoke-static {v3, v4, v0}, Landroid/os/Message;->obtain(Landroid/os/Handler;ILjava/lang/Object;)Landroid/os/Message;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    .line 1556
    const/4 v2, 0x0

    goto/16 :goto_0

    .line 1517
    .end local v39    # "info":Lcom/thinkware/sundo/ieve/ieveInitInfos;
    .end local v45    # "ret":I
    .end local v46    # "text":Ljava/lang/String;
    .restart local p8    # "encryptfolder":Ljava/lang/String;
    :cond_22
    new-instance v2, Landroid/graphics/Rect;

    const/4 v3, 0x0

    const/4 v4, 0x0

    const v5, 0x43eb8000    # 471.0f

    mul-float v5, v5, v42

    invoke-static {v5}, Lcom/thinkware/sundo/ieve/ieveMath;->ROUND_OFF(F)I

    move-result v5

    const v16, 0x43b18000    # 355.0f

    mul-float v16, v16, v43

    invoke-static/range {v16 .. v16}, Lcom/thinkware/sundo/ieve/ieveMath;->ROUND_OFF(F)I

    move-result v16

    move/from16 v0, v16

    invoke-direct {v2, v3, v4, v5, v0}, Landroid/graphics/Rect;-><init>(IIII)V

    move-object/from16 v0, p0

    iput-object v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->u:Landroid/graphics/Rect;

    goto/16 :goto_f

    .line 1529
    .restart local v39    # "info":Lcom/thinkware/sundo/ieve/ieveInitInfos;
    :cond_23
    const-string p8, ""

    goto/16 :goto_10

    .line 1559
    .end local p8    # "encryptfolder":Ljava/lang/String;
    .restart local v46    # "text":Ljava/lang/String;
    :cond_24
    invoke-direct/range {p0 .. p0}, Lcom/thinkware/sundo/ieve/IEVE;->c()V

    .line 1560
    invoke-direct/range {p0 .. p0}, Lcom/thinkware/sundo/ieve/IEVE;->d()V

    .line 1561
    invoke-direct/range {p0 .. p0}, Lcom/thinkware/sundo/ieve/IEVE;->e()V

    .line 1562
    invoke-virtual/range {p0 .. p0}, Lcom/thinkware/sundo/ieve/IEVE;->checkDebugMode()V

    .line 1564
    new-instance v2, Lcom/thinkware/sundo/ieve/IEVE$2;

    move-object/from16 v0, p0

    invoke-direct {v2, v0}, Lcom/thinkware/sundo/ieve/IEVE$2;-><init>(Lcom/thinkware/sundo/ieve/IEVE;)V

    move-object/from16 v0, p0

    iput-object v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->ag:Ljava/util/TimerTask;

    .line 1602
    new-instance v2, Ljava/util/Timer;

    invoke-direct {v2}, Ljava/util/Timer;-><init>()V

    move-object/from16 v0, p0

    iput-object v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->af:Ljava/util/Timer;

    .line 1603
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/ieve/IEVE;->af:Ljava/util/Timer;

    move-object/from16 v16, v0

    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/ieve/IEVE;->ag:Ljava/util/TimerTask;

    move-object/from16 v17, v0

    const-wide/16 v18, 0x0

    const-wide/16 v20, 0x64

    invoke-virtual/range {v16 .. v21}, Ljava/util/Timer;->schedule(Ljava/util/TimerTask;JJ)V

    .line 1605
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/ieve/IEVE;->am:Landroid/os/Handler;

    sput-object v2, Lcom/thinkware/sundo/ieve/IEVE;->ah:Landroid/os/Handler;

    .line 1606
    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v2

    sub-long v28, v2, v22

    .line 1607
    .local v28, "_UptimePeriod":J
    const-string v2, "java_IEVE"

    const-string v3, "initialize[Done][Period:%.2fms]"

    const/4 v4, 0x1

    new-array v4, v4, [Ljava/lang/Object;

    const/4 v5, 0x0

    move-wide/from16 v0, v28

    long-to-double v0, v0

    move-wide/from16 v16, v0

    const-wide v18, 0x412e848000000000L    # 1000000.0

    div-double v16, v16, v18

    invoke-static/range {v16 .. v17}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v16

    aput-object v16, v4, v5

    invoke-static {v3, v4}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 1609
    const/4 v2, 0x1

    goto/16 :goto_0

    .line 1408
    :pswitch_data_0
    .packed-switch 0x2
        :pswitch_0
    .end packed-switch
.end method

.method public isCameraOpened()Z
    .locals 1

    .prologue
    .line 1614
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->j:Lcom/thinkware/sundo/ieve/ieveCameraView;

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->j:Lcom/thinkware/sundo/ieve/ieveCameraView;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveCameraView;->isCameraOpened()Z

    move-result v0

    :goto_0
    return v0

    :cond_0
    const/4 v0, 0x0

    goto :goto_0
.end method

.method public isCameraPreview()Z
    .locals 1

    .prologue
    .line 1619
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->j:Lcom/thinkware/sundo/ieve/ieveCameraView;

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->j:Lcom/thinkware/sundo/ieve/ieveCameraView;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveCameraView;->isPreviewStart()Z

    move-result v0

    :goto_0
    return v0

    :cond_0
    const/4 v0, 0x0

    goto :goto_0
.end method

.method public isDebugPrint()Z
    .locals 1

    .prologue
    .line 2987
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->IsDebugFuncOn()Z

    move-result v0

    return v0
.end method

.method public isEnableModeAR()Z
    .locals 1

    .prologue
    .line 1624
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->IsEnableModeAR()Z

    move-result v0

    return v0
.end method

.method public isEnableModeCompactAR()Z
    .locals 1

    .prologue
    .line 1634
    const/4 v0, 0x0

    return v0
.end method

.method public isEnableModeDR()Z
    .locals 1

    .prologue
    .line 1629
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->IsEnableModeDR()Z

    move-result v0

    return v0
.end method

.method public isEnableModeFindVP()Z
    .locals 1

    .prologue
    .line 1641
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->IsEnableModeFindVP()Z

    move-result v0

    return v0
.end method

.method public isEnableModeRecogCSWS()Z
    .locals 1

    .prologue
    .line 1646
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->IsEnableModeRecogCSWS()Z

    move-result v0

    return v0
.end method

.method public isEnableModeRecogFCWS()Z
    .locals 1

    .prologue
    .line 1653
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->d:Lcom/stradvision/pdvdtest/SV_ADAS;

    invoke-virtual {v0}, Lcom/stradvision/pdvdtest/SV_ADAS;->IsEnableModeRecogFCWS()Z

    move-result v0

    return v0
.end method

.method public isEnableModeRecogFVSA()Z
    .locals 1

    .prologue
    .line 1658
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->IsEnableModeRecogFVSA()Z

    move-result v0

    return v0
.end method

.method public isEnableModeRecogLDWC()Z
    .locals 1

    .prologue
    .line 1663
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->IsEnableModeRecogLDWC()Z

    move-result v0

    return v0
.end method

.method public isEnableModeRecogLDWS()Z
    .locals 1

    .prologue
    .line 1668
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->IsEnableModeRecogLDWS()Z

    move-result v0

    return v0
.end method

.method public isEnableModeRecogPCWS()Z
    .locals 1

    .prologue
    .line 1675
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->d:Lcom/stradvision/pdvdtest/SV_ADAS;

    invoke-virtual {v0}, Lcom/stradvision/pdvdtest/SV_ADAS;->IsEnableModeRecogPCWS()Z

    move-result v0

    return v0
.end method

.method public isEnableModeRecogPLCA()Z
    .locals 1

    .prologue
    .line 1680
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->IsEnableModeRecogPLCA()Z

    move-result v0

    return v0
.end method

.method public isEnableModeRecogTLCA()Z
    .locals 1

    .prologue
    .line 1685
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->IsEnableModeRecogTLCA()Z

    move-result v0

    return v0
.end method

.method public isEnableModeRecogUFCW()Z
    .locals 1

    .prologue
    .line 1692
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->d:Lcom/stradvision/pdvdtest/SV_ADAS;

    invoke-virtual {v0}, Lcom/stradvision/pdvdtest/SV_ADAS;->IsEnableModeRecogUFCW()Z

    move-result v0

    return v0
.end method

.method public isFullMode()Z
    .locals 1

    .prologue
    .line 1697
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->IsFullMode()Z

    move-result v0

    return v0
.end method

.method public isInitialized()Z
    .locals 1

    .prologue
    .line 1702
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->IsInitialized()Z

    move-result v0

    return v0
.end method

.method public isInitializedAR()Z
    .locals 1

    .prologue
    .line 1707
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->IsInitializedAR()Z

    move-result v0

    return v0
.end method

.method public isProcessing()Z
    .locals 1

    .prologue
    .line 1712
    iget-boolean v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->B:Z

    return v0
.end method

.method public isReadySaveCamera()Z
    .locals 1

    .prologue
    .line 1717
    iget-boolean v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->q:Z

    return v0
.end method

.method public isSavingSnapshot()Z
    .locals 1

    .prologue
    .line 1722
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->j:Lcom/thinkware/sundo/ieve/ieveCameraView;

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->j:Lcom/thinkware/sundo/ieve/ieveCameraView;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveCameraView;->isSavingSnapshot()Z

    move-result v0

    :goto_0
    return v0

    :cond_0
    const/4 v0, 0x0

    goto :goto_0
.end method

.method public isSavingStreamData()Z
    .locals 1

    .prologue
    .line 1727
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->j:Lcom/thinkware/sundo/ieve/ieveCameraView;

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->j:Lcom/thinkware/sundo/ieve/ieveCameraView;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveCameraView;->isSavingStream()Z

    move-result v0

    :goto_0
    return v0

    :cond_0
    const/4 v0, 0x0

    goto :goto_0
.end method

.method public isShowBGCover()Z
    .locals 1

    .prologue
    .line 2991
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->IsShowBGCover()Z

    move-result v0

    return v0
.end method

.method public isShowDebugCamera()Z
    .locals 1

    .prologue
    .line 2999
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->IsShowDebugCamera()Z

    move-result v0

    return v0
.end method

.method public isShowDebugFCWS()Z
    .locals 1

    .prologue
    .line 3011
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->IsShowDebugFCWS()Z

    move-result v0

    return v0
.end method

.method public isShowDebugLDWS()Z
    .locals 1

    .prologue
    .line 3015
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->IsShowDebugLDWS()Z

    move-result v0

    return v0
.end method

.method public isShowDebugLineDR()Z
    .locals 1

    .prologue
    .line 3003
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->IsShowDebugLineDR()Z

    move-result v0

    return v0
.end method

.method public isShowDebugLineGrid()Z
    .locals 1

    .prologue
    .line 3007
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->IsShowDebugLineGrid()Z

    move-result v0

    return v0
.end method

.method public isShowDebugPCWS()Z
    .locals 1

    .prologue
    .line 3019
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->IsShowDebugPCWS()Z

    move-result v0

    return v0
.end method

.method public isShowDebugTLCA()Z
    .locals 1

    .prologue
    .line 3023
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->IsShowDebugTLCA()Z

    move-result v0

    return v0
.end method

.method public isSimulationMode()Z
    .locals 1

    .prologue
    .line 2995
    iget-boolean v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->U:Z

    return v0
.end method

.method public isSupportSaveStream()Z
    .locals 1

    .prologue
    .line 1732
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->j:Lcom/thinkware/sundo/ieve/ieveCameraView;

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->j:Lcom/thinkware/sundo/ieve/ieveCameraView;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveCameraView;->isSupportSaveStream()Z

    move-result v0

    :goto_0
    return v0

    :cond_0
    const/4 v0, 0x0

    goto :goto_0
.end method

.method public saveJpgCurrentPreview(DDIIIILjava/lang/String;Ljava/lang/String;Ljava/util/Date;)Z
    .locals 9
    .param p1, "lat"    # D
    .param p3, "lon"    # D
    .param p5, "carangle"    # I
    .param p6, "carspeedhmh"    # I
    .param p7, "speedlimit"    # I
    .param p8, "safecamera"    # I
    .param p9, "pathname"    # Ljava/lang/String;
    .param p10, "filename"    # Ljava/lang/String;
    .param p11, "date"    # Ljava/util/Date;

    .prologue
    .line 2046
    const-string v5, "java_IEVE"

    const-string v6, "saveJpgCurrentPreview:"

    invoke-static {v5, v6}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 2047
    const-string v5, "  [lat:%.3f, lon:%.3f, carangle:%d, carspeedhmh:%d, speedlimit:%d, safecamera:%d]"

    const/4 v6, 0x6

    new-array v6, v6, [Ljava/lang/Object;

    const/4 v7, 0x0

    invoke-static {p1, p2}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v8

    aput-object v8, v6, v7

    const/4 v7, 0x1

    invoke-static {p3, p4}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v8

    aput-object v8, v6, v7

    const/4 v7, 0x2

    invoke-static {p5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    aput-object v8, v6, v7

    const/4 v7, 0x3

    invoke-static {p6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    aput-object v8, v6, v7

    const/4 v7, 0x4

    invoke-static/range {p7 .. p7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    aput-object v8, v6, v7

    const/4 v7, 0x5

    invoke-static/range {p8 .. p8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    aput-object v8, v6, v7

    invoke-static {v5, v6}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    .line 2048
    .local v4, "text":Ljava/lang/String;
    const-string v5, "java_IEVE"

    invoke-static {v5, v4}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 2049
    const-string v5, "  [pathname:%s, filename:%s]"

    const/4 v6, 0x2

    new-array v6, v6, [Ljava/lang/Object;

    const/4 v7, 0x0

    aput-object p9, v6, v7

    const/4 v7, 0x1

    aput-object p10, v6, v7

    invoke-static {v5, v6}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    .line 2050
    const-string v5, "java_IEVE"

    invoke-static {v5, v4}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 2051
    iget-object v5, p0, Lcom/thinkware/sundo/ieve/IEVE;->j:Lcom/thinkware/sundo/ieve/ieveCameraView;

    if-nez v5, :cond_0

    .line 2052
    const-string v5, "saveJpgCurrentPreview[Camera view is null]"

    const/4 v6, 0x0

    new-array v6, v6, [Ljava/lang/Object;

    invoke-static {v5, v6}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    .line 2053
    const-string v5, "java_IEVE"

    invoke-static {v5, v4}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2054
    iget-object v5, p0, Lcom/thinkware/sundo/ieve/IEVE;->am:Landroid/os/Handler;

    iget-object v6, p0, Lcom/thinkware/sundo/ieve/IEVE;->am:Landroid/os/Handler;

    const/16 v7, 0x4af

    invoke-static {v6, v7, v4}, Landroid/os/Message;->obtain(Landroid/os/Handler;ILjava/lang/Object;)Landroid/os/Message;

    move-result-object v6

    invoke-virtual {v5, v6}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    .line 2055
    const/4 v5, 0x0

    .line 2087
    :goto_0
    return v5

    .line 2057
    :cond_0
    iget-object v5, p0, Lcom/thinkware/sundo/ieve/IEVE;->j:Lcom/thinkware/sundo/ieve/ieveCameraView;

    invoke-virtual {v5}, Lcom/thinkware/sundo/ieve/ieveCameraView;->isPreviewCallback()Z

    move-result v5

    if-nez v5, :cond_1

    .line 2058
    const-string v5, "saveJpgCurrentPreview[Camera callback is false]"

    const/4 v6, 0x0

    new-array v6, v6, [Ljava/lang/Object;

    invoke-static {v5, v6}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    .line 2059
    const-string v5, "java_IEVE"

    invoke-static {v5, v4}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2060
    iget-object v5, p0, Lcom/thinkware/sundo/ieve/IEVE;->am:Landroid/os/Handler;

    iget-object v6, p0, Lcom/thinkware/sundo/ieve/IEVE;->am:Landroid/os/Handler;

    const/16 v7, 0x4af

    invoke-static {v6, v7, v4}, Landroid/os/Message;->obtain(Landroid/os/Handler;ILjava/lang/Object;)Landroid/os/Message;

    move-result-object v6

    invoke-virtual {v5, v6}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    .line 2061
    const/4 v5, 0x0

    goto :goto_0

    .line 2063
    :cond_1
    new-instance v3, Ljava/io/File;

    move-object/from16 v0, p9

    invoke-direct {v3, v0}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 2064
    .local v3, "fp":Ljava/io/File;
    invoke-virtual {v3}, Ljava/io/File;->exists()Z

    move-result v5

    if-nez v5, :cond_2

    .line 2065
    invoke-virtual {v3}, Ljava/io/File;->mkdirs()Z

    move-result v5

    if-nez v5, :cond_2

    .line 2066
    const-string v5, "saveJpgCurrentPreview[Failed makes folder:%s]"

    const/4 v6, 0x1

    new-array v6, v6, [Ljava/lang/Object;

    const/4 v7, 0x0

    aput-object p9, v6, v7

    invoke-static {v5, v6}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    .line 2067
    const-string v5, "java_IEVE"

    invoke-static {v5, v4}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2068
    iget-object v5, p0, Lcom/thinkware/sundo/ieve/IEVE;->am:Landroid/os/Handler;

    iget-object v6, p0, Lcom/thinkware/sundo/ieve/IEVE;->am:Landroid/os/Handler;

    const/16 v7, 0x4af

    invoke-static {v6, v7, v4}, Landroid/os/Message;->obtain(Landroid/os/Handler;ILjava/lang/Object;)Landroid/os/Message;

    move-result-object v6

    invoke-virtual {v5, v6}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    .line 2069
    const/4 v5, 0x0

    goto :goto_0

    .line 2072
    :cond_2
    if-nez p11, :cond_3

    new-instance p11, Ljava/util/Date;

    .end local p11    # "date":Ljava/util/Date;
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v6

    move-object/from16 v0, p11

    invoke-direct {v0, v6, v7}, Ljava/util/Date;-><init>(J)V

    .line 2073
    .restart local p11    # "date":Ljava/util/Date;
    :cond_3
    if-nez p10, :cond_4

    .line 2074
    const-string v5, "%04d%02d%02d_%02d%02d%02d"

    const/4 v6, 0x6

    new-array v6, v6, [Ljava/lang/Object;

    const/4 v7, 0x0

    invoke-virtual/range {p11 .. p11}, Ljava/util/Date;->getYear()I

    move-result v8

    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    aput-object v8, v6, v7

    const/4 v7, 0x1

    invoke-virtual/range {p11 .. p11}, Ljava/util/Date;->getMonth()I

    move-result v8

    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    aput-object v8, v6, v7

    const/4 v7, 0x2

    invoke-virtual/range {p11 .. p11}, Ljava/util/Date;->getDay()I

    move-result v8

    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    aput-object v8, v6, v7

    const/4 v7, 0x3

    invoke-virtual/range {p11 .. p11}, Ljava/util/Date;->getHours()I

    move-result v8

    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    aput-object v8, v6, v7

    const/4 v7, 0x4

    invoke-virtual/range {p11 .. p11}, Ljava/util/Date;->getMinutes()I

    move-result v8

    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    aput-object v8, v6, v7

    const/4 v7, 0x5

    invoke-virtual/range {p11 .. p11}, Ljava/util/Date;->getSeconds()I

    move-result v8

    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    aput-object v8, v6, v7

    invoke-static {v5, v6}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p10

    .line 2077
    :cond_4
    new-instance v2, Lcom/thinkware/sundo/ieve/ieveExifTag;

    invoke-direct {v2}, Lcom/thinkware/sundo/ieve/ieveExifTag;-><init>()V

    .line 2078
    .local v2, "exiftag":Lcom/thinkware/sundo/ieve/ieveExifTag;
    move-object/from16 v0, p11

    iput-object v0, v2, Lcom/thinkware/sundo/ieve/ieveExifTag;->date:Ljava/util/Date;

    .line 2079
    iput-wide p1, v2, Lcom/thinkware/sundo/ieve/ieveExifTag;->latitude:D

    .line 2080
    iput-wide p3, v2, Lcom/thinkware/sundo/ieve/ieveExifTag;->longitude:D

    .line 2081
    iput p5, v2, Lcom/thinkware/sundo/ieve/ieveExifTag;->carangle:I

    .line 2082
    iput p6, v2, Lcom/thinkware/sundo/ieve/ieveExifTag;->carspeedhmh:I

    .line 2083
    move/from16 v0, p7

    iput v0, v2, Lcom/thinkware/sundo/ieve/ieveExifTag;->speedlimit:I

    .line 2084
    move/from16 v0, p8

    iput v0, v2, Lcom/thinkware/sundo/ieve/ieveExifTag;->safecamera:I

    .line 2085
    iget-object v5, p0, Lcom/thinkware/sundo/ieve/IEVE;->j:Lcom/thinkware/sundo/ieve/ieveCameraView;

    const/4 v6, 0x0

    move-object/from16 v0, p9

    move-object/from16 v1, p10

    invoke-virtual {v5, v6, v0, v1, v2}, Lcom/thinkware/sundo/ieve/ieveCameraView;->takeSnapshot(ZLjava/lang/String;Ljava/lang/String;Lcom/thinkware/sundo/ieve/ieveExifTag;)Z

    .line 2087
    const/4 v5, 0x1

    goto/16 :goto_0
.end method

.method public saveStreamData(Ljava/lang/String;Ljava/lang/String;)Z
    .locals 7
    .param p1, "pathname"    # Ljava/lang/String;
    .param p2, "filename"    # Ljava/lang/String;

    .prologue
    const/4 v3, 0x1

    const/16 v6, 0x4af

    const/4 v2, 0x0

    .line 2093
    if-eqz p1, :cond_0

    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    move-result v4

    if-eqz v4, :cond_2

    .line 2094
    :cond_0
    const-string v3, "saveStreamData[Invalid pathname]"

    new-array v4, v2, [Ljava/lang/Object;

    invoke-static {v3, v4}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    .line 2095
    .local v1, "text":Ljava/lang/String;
    const-string v3, "java_IEVE"

    invoke-static {v3, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2096
    iget-object v3, p0, Lcom/thinkware/sundo/ieve/IEVE;->am:Landroid/os/Handler;

    iget-object v4, p0, Lcom/thinkware/sundo/ieve/IEVE;->am:Landroid/os/Handler;

    invoke-static {v4, v6, v1}, Landroid/os/Message;->obtain(Landroid/os/Handler;ILjava/lang/Object;)Landroid/os/Message;

    move-result-object v4

    invoke-virtual {v3, v4}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    .line 2137
    .end local v1    # "text":Ljava/lang/String;
    :cond_1
    :goto_0
    return v2

    .line 2099
    :cond_2
    if-eqz p2, :cond_3

    invoke-virtual {p2}, Ljava/lang/String;->isEmpty()Z

    move-result v4

    if-eqz v4, :cond_4

    .line 2100
    :cond_3
    const-string v3, "saveStreamData[Invalid filename]"

    new-array v4, v2, [Ljava/lang/Object;

    invoke-static {v3, v4}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    .line 2101
    .restart local v1    # "text":Ljava/lang/String;
    const-string v3, "java_IEVE"

    invoke-static {v3, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2102
    iget-object v3, p0, Lcom/thinkware/sundo/ieve/IEVE;->am:Landroid/os/Handler;

    iget-object v4, p0, Lcom/thinkware/sundo/ieve/IEVE;->am:Landroid/os/Handler;

    invoke-static {v4, v6, v1}, Landroid/os/Message;->obtain(Landroid/os/Handler;ILjava/lang/Object;)Landroid/os/Message;

    move-result-object v4

    invoke-virtual {v3, v4}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto :goto_0

    .line 2105
    .end local v1    # "text":Ljava/lang/String;
    :cond_4
    iget-boolean v4, p0, Lcom/thinkware/sundo/ieve/IEVE;->q:Z

    if-eqz v4, :cond_1

    .line 2106
    const-string v4, "java_IEVE"

    const-string v5, "saveStreamData:"

    invoke-static {v4, v5}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 2107
    const-string v4, "  [pathname:%s, filename:%s]"

    const/4 v5, 0x2

    new-array v5, v5, [Ljava/lang/Object;

    aput-object p1, v5, v2

    aput-object p2, v5, v3

    invoke-static {v4, v5}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    .line 2108
    .restart local v1    # "text":Ljava/lang/String;
    const-string v4, "java_IEVE"

    invoke-static {v4, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 2109
    iget-object v4, p0, Lcom/thinkware/sundo/ieve/IEVE;->j:Lcom/thinkware/sundo/ieve/ieveCameraView;

    if-nez v4, :cond_5

    .line 2110
    const-string v3, "saveStreamData[Camera view is null]"

    new-array v4, v2, [Ljava/lang/Object;

    invoke-static {v3, v4}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    .line 2111
    const-string v3, "java_IEVE"

    invoke-static {v3, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2112
    iget-object v3, p0, Lcom/thinkware/sundo/ieve/IEVE;->am:Landroid/os/Handler;

    iget-object v4, p0, Lcom/thinkware/sundo/ieve/IEVE;->am:Landroid/os/Handler;

    invoke-static {v4, v6, v1}, Landroid/os/Message;->obtain(Landroid/os/Handler;ILjava/lang/Object;)Landroid/os/Message;

    move-result-object v4

    invoke-virtual {v3, v4}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto :goto_0

    .line 2115
    :cond_5
    iget-object v4, p0, Lcom/thinkware/sundo/ieve/IEVE;->j:Lcom/thinkware/sundo/ieve/ieveCameraView;

    invoke-virtual {v4}, Lcom/thinkware/sundo/ieve/ieveCameraView;->isPreviewCallback()Z

    move-result v4

    if-nez v4, :cond_6

    .line 2116
    const-string v3, "saveStreamData[Camera callback is false]"

    new-array v4, v2, [Ljava/lang/Object;

    invoke-static {v3, v4}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    .line 2117
    const-string v3, "java_IEVE"

    invoke-static {v3, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2118
    iget-object v3, p0, Lcom/thinkware/sundo/ieve/IEVE;->am:Landroid/os/Handler;

    iget-object v4, p0, Lcom/thinkware/sundo/ieve/IEVE;->am:Landroid/os/Handler;

    invoke-static {v4, v6, v1}, Landroid/os/Message;->obtain(Landroid/os/Handler;ILjava/lang/Object;)Landroid/os/Message;

    move-result-object v4

    invoke-virtual {v3, v4}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto :goto_0

    .line 2122
    :cond_6
    const-string v4, "/"

    invoke-virtual {p1, v4}, Ljava/lang/String;->lastIndexOf(Ljava/lang/String;)I

    move-result v4

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v5

    add-int/lit8 v5, v5, -0x1

    if-ne v4, v5, :cond_7

    .line 2123
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v4

    add-int/lit8 v4, v4, -0x1

    invoke-virtual {p1, v2, v4}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p1

    .line 2126
    :cond_7
    new-instance v0, Ljava/io/File;

    invoke-direct {v0, p1}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 2127
    .local v0, "fp":Ljava/io/File;
    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v4

    if-nez v4, :cond_8

    .line 2128
    invoke-virtual {v0}, Ljava/io/File;->mkdirs()Z

    move-result v4

    if-nez v4, :cond_8

    .line 2129
    const-string v4, "saveStreamData[Failed makes folder:%s]"

    new-array v3, v3, [Ljava/lang/Object;

    aput-object p1, v3, v2

    invoke-static {v4, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    .line 2130
    const-string v3, "java_IEVE"

    invoke-static {v3, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2131
    iget-object v3, p0, Lcom/thinkware/sundo/ieve/IEVE;->am:Landroid/os/Handler;

    iget-object v4, p0, Lcom/thinkware/sundo/ieve/IEVE;->am:Landroid/os/Handler;

    invoke-static {v4, v6, v1}, Landroid/os/Message;->obtain(Landroid/os/Handler;ILjava/lang/Object;)Landroid/os/Message;

    move-result-object v4

    invoke-virtual {v3, v4}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto/16 :goto_0

    .line 2136
    :cond_8
    iget-object v2, p0, Lcom/thinkware/sundo/ieve/IEVE;->j:Lcom/thinkware/sundo/ieve/ieveCameraView;

    invoke-virtual {v2, p1, p2}, Lcom/thinkware/sundo/ieve/ieveCameraView;->takeStream(Ljava/lang/String;Ljava/lang/String;)Z

    move v2, v3

    .line 2137
    goto/16 :goto_0
.end method

.method public setCameraID(I)V
    .locals 5
    .param p1, "cameraid"    # I

    .prologue
    const/4 v2, 0x1

    const/4 v4, 0x0

    .line 2142
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->j:Lcom/thinkware/sundo/ieve/ieveCameraView;

    if-nez v0, :cond_0

    .line 2150
    :goto_0
    return-void

    .line 2143
    :cond_0
    if-gez p1, :cond_1

    .line 2144
    const-string v0, "java_IEVE"

    const-string v1, "setCameraID[Invalid cameraID:%d]"

    new-array v2, v2, [Ljava/lang/Object;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    aput-object v3, v2, v4

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    .line 2147
    :cond_1
    const-string v0, "java_IEVE"

    const-string v1, "setCameraID[%d]"

    new-array v2, v2, [Ljava/lang/Object;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    aput-object v3, v2, v4

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 2148
    iput p1, p0, Lcom/thinkware/sundo/ieve/IEVE;->m:I

    .line 2149
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->j:Lcom/thinkware/sundo/ieve/ieveCameraView;

    iget v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->m:I

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/ieve/ieveCameraView;->setCameraID(I)V

    goto :goto_0
.end method

.method public setCarControl(DDFFFZ)V
    .locals 11
    .param p1, "longitude"    # D
    .param p3, "latitude"    # D
    .param p5, "altitude"    # F
    .param p6, "angle_dir"    # F
    .param p7, "angle_vrt"    # F
    .param p8, "animate"    # Z

    .prologue
    .line 2154
    sget-wide v4, Lcom/thinkware/sundo/ieve/IEVE;->ap:D

    move-object v1, p0

    move-wide v2, p1

    move-wide v6, p3

    invoke-virtual/range {v1 .. v7}, Lcom/thinkware/sundo/ieve/IEVE;->getDistMeterOfLongitude(DDD)D

    move-result-wide v4

    double-to-float v1, v4

    .line 2155
    .local v1, "pos_x":F
    sget-wide v4, Lcom/thinkware/sundo/ieve/IEVE;->ao:D

    invoke-virtual {p0, p3, p4, v4, v5}, Lcom/thinkware/sundo/ieve/IEVE;->getDistMeterOfLatitude(DD)D

    move-result-wide v4

    double-to-float v3, v4

    .local v3, "pos_z":F
    move-object v0, p0

    move/from16 v2, p5

    move/from16 v4, p6

    move/from16 v5, p7

    move/from16 v6, p8

    .line 2156
    invoke-virtual/range {v0 .. v6}, Lcom/thinkware/sundo/ieve/IEVE;->setCarControl(FFFFFZ)V

    .line 2157
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->at:Lcom/thinkware/sundo/ieve/ieveTextView;

    if-eqz v0, :cond_0

    .line 2158
    const/16 v5, 0x707

    const-string v0, "Lon:%.5f, Lat:%.5f"

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v4, 0x0

    invoke-static {p1, p2}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v6

    aput-object v6, v2, v4

    const/4 v4, 0x1

    invoke-static {p3, p4}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v6

    aput-object v6, v2, v4

    invoke-static {v0, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v6

    const/high16 v7, 0x44000000    # 512.0f

    const/high16 v8, 0x42d20000    # 105.0f

    const/high16 v9, 0x41f00000    # 30.0f

    const/high16 v10, -0x10000

    move-object v4, p0

    invoke-virtual/range {v4 .. v10}, Lcom/thinkware/sundo/ieve/IEVE;->DebugPrint(ILjava/lang/String;FFFI)V

    .line 2160
    :cond_0
    return-void
.end method

.method public setCarControl(FFFFFZ)V
    .locals 0
    .param p1, "pos_x"    # F
    .param p2, "pos_y"    # F
    .param p3, "pos_z"    # F
    .param p4, "angle_dir"    # F
    .param p5, "angle_vrt"    # F
    .param p6, "animate"    # Z

    .prologue
    .line 2164
    iput p1, p0, Lcom/thinkware/sundo/ieve/IEVE;->X:F

    .line 2165
    iput p2, p0, Lcom/thinkware/sundo/ieve/IEVE;->Y:F

    .line 2166
    iput p3, p0, Lcom/thinkware/sundo/ieve/IEVE;->Z:F

    .line 2167
    iput p4, p0, Lcom/thinkware/sundo/ieve/IEVE;->aa:F

    .line 2168
    iput p5, p0, Lcom/thinkware/sundo/ieve/IEVE;->ab:F

    .line 2169
    iput-boolean p6, p0, Lcom/thinkware/sundo/ieve/IEVE;->ac:Z

    .line 2174
    return-void
.end method

.method public setCarControl(IIFFFZ)V
    .locals 11
    .param p1, "reg_longitude"    # I
    .param p2, "reg_latitude"    # I
    .param p3, "altitude"    # F
    .param p4, "angle_dir"    # F
    .param p5, "angle_vrt"    # F
    .param p6, "animate"    # Z

    .prologue
    .line 2178
    invoke-virtual {p0, p1, p2}, Lcom/thinkware/sundo/ieve/IEVE;->convertGeoRegToFPoint3D_X(II)F

    move-result v1

    .line 2179
    .local v1, "pos_x":F
    invoke-virtual {p0, p2}, Lcom/thinkware/sundo/ieve/IEVE;->convertGeoRegToFPoint3D_Z(I)F

    move-result v3

    .local v3, "pos_z":F
    move-object v0, p0

    move v2, p3

    move v4, p4

    move/from16 v5, p5

    move/from16 v6, p6

    .line 2180
    invoke-virtual/range {v0 .. v6}, Lcom/thinkware/sundo/ieve/IEVE;->setCarControl(FFFFFZ)V

    .line 2181
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->at:Lcom/thinkware/sundo/ieve/ieveTextView;

    if-eqz v0, :cond_0

    .line 2182
    const/16 v5, 0x707

    const-string v0, "Lon:%.5f, Lat:%.5f"

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v4, 0x0

    int-to-double v6, p1

    sget-wide v8, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_BASE_COORDINATE_SHIFT:D

    div-double/2addr v6, v8

    invoke-static {v6, v7}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v6

    aput-object v6, v2, v4

    const/4 v4, 0x1

    int-to-double v6, p2

    sget-wide v8, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_BASE_COORDINATE_SHIFT:D

    div-double/2addr v6, v8

    invoke-static {v6, v7}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v6

    aput-object v6, v2, v4

    invoke-static {v0, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v6

    const/high16 v7, 0x44000000    # 512.0f

    const/high16 v8, 0x42d20000    # 105.0f

    const/high16 v9, 0x41f00000    # 30.0f

    const/high16 v10, -0x10000

    move-object v4, p0

    invoke-virtual/range {v4 .. v10}, Lcom/thinkware/sundo/ieve/IEVE;->DebugPrint(ILjava/lang/String;FFFI)V

    .line 2184
    :cond_0
    return-void
.end method

.method public setCarPosRegForBaseCoord(II)V
    .locals 8
    .param p1, "reg_lon"    # I
    .param p2, "reg_lat"    # I

    .prologue
    .line 2819
    int-to-double v4, p1

    sget-wide v6, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_BASE_COORDINATE_SHIFT:D

    div-double v2, v4, v6

    .line 2820
    .local v2, "dlon":D
    int-to-double v4, p2

    sget-wide v6, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_BASE_COORDINATE_SHIFT:D

    div-double v0, v4, v6

    .line 2821
    .local v0, "dlat":D
    double-to-int v4, v2

    add-int/lit8 v4, v4, -0x1

    int-to-double v4, v4

    sput-wide v4, Lcom/thinkware/sundo/ieve/IEVE;->ap:D

    .line 2822
    double-to-int v4, v0

    add-int/lit8 v4, v4, -0x1

    int-to-double v4, v4

    sput-wide v4, Lcom/thinkware/sundo/ieve/IEVE;->ao:D

    .line 2823
    return-void
.end method

.method public setCarShadowGPS(Z)V
    .locals 5
    .param p1, "isshadow"    # Z

    .prologue
    .line 2188
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->GetCarShadowGPS()Z

    move-result v0

    if-eq p1, v0, :cond_0

    .line 2189
    const-string v1, "java_IEVE"

    const-string v2, "setCarShadowGPS[%s]"

    const/4 v0, 0x1

    new-array v3, v0, [Ljava/lang/Object;

    const/4 v4, 0x0

    if-eqz p1, :cond_1

    const-string v0, "true"

    :goto_0
    aput-object v0, v3, v4

    invoke-static {v2, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 2191
    :cond_0
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0, p1}, Lcom/thinkware/sundo/ieve/ieveNative;->SetCarShadowGPS(Z)V

    .line 2192
    return-void

    .line 2189
    :cond_1
    const-string v0, "false"

    goto :goto_0
.end method

.method public setCarSpeedHmH(II)V
    .locals 9
    .param p1, "speed"    # I
    .param p2, "source"    # I

    .prologue
    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/high16 v5, 0x41200000    # 10.0f

    .line 2208
    iget v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->ad:I

    if-eq p1, v1, :cond_0

    .line 2209
    const-string v1, "java_IEVE"

    const-string v2, "setCarSpeedHmH[%.1f->%.1fkm/h][src:%d]"

    const/4 v3, 0x3

    new-array v3, v3, [Ljava/lang/Object;

    iget v4, p0, Lcom/thinkware/sundo/ieve/IEVE;->ad:I

    int-to-float v4, v4

    div-float/2addr v4, v5

    invoke-static {v4}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v4

    aput-object v4, v3, v6

    int-to-float v4, p1

    div-float/2addr v4, v5

    invoke-static {v4}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v4

    aput-object v4, v3, v7

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    aput-object v4, v3, v8

    invoke-static {v2, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 2211
    :cond_0
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v1}, Lcom/thinkware/sundo/ieve/ieveNative;->GetOBD2InfoGearMode()I

    move-result v0

    .line 2212
    .local v0, "gearmode":I
    const/4 v1, 0x7

    if-ne v0, v1, :cond_1

    const/4 p1, 0x0

    .line 2213
    :cond_1
    iget v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->ae:I

    if-eq v1, p2, :cond_2

    .line 2214
    const-string v1, "java_IEVE"

    const-string v2, "setCarSpeedSource:%d->%d]"

    new-array v3, v8, [Ljava/lang/Object;

    iget v4, p0, Lcom/thinkware/sundo/ieve/IEVE;->ae:I

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    aput-object v4, v3, v6

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    aput-object v4, v3, v7

    invoke-static {v2, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 2216
    :cond_2
    if-gez p1, :cond_3

    const/4 p1, 0x0

    .line 2217
    :cond_3
    if-nez p2, :cond_4

    const/16 v1, 0x14

    if-ge p1, v1, :cond_4

    .line 2218
    const/4 p1, 0x0

    .line 2220
    :cond_4
    iput p1, p0, Lcom/thinkware/sundo/ieve/IEVE;->ad:I

    .line 2221
    iput p2, p0, Lcom/thinkware/sundo/ieve/IEVE;->ae:I

    .line 2224
    return-void
.end method

.method public setCarSpeedK(II)V
    .locals 0
    .param p1, "speed"    # I
    .param p2, "source"    # I

    .prologue
    .line 2229
    invoke-virtual {p0, p1, p2}, Lcom/thinkware/sundo/ieve/IEVE;->setCarSpeedHmH(II)V

    .line 2230
    return-void
.end method

.method public setCarSpeedKmH(FI)V
    .locals 1
    .param p1, "speed"    # F
    .param p2, "source"    # I

    .prologue
    .line 2235
    const/high16 v0, 0x41200000    # 10.0f

    mul-float/2addr v0, p1

    invoke-static {v0}, Lcom/thinkware/sundo/ieve/ieveMath;->ROUND_OFF(F)I

    move-result v0

    invoke-virtual {p0, v0, p2}, Lcom/thinkware/sundo/ieve/IEVE;->setCarSpeedHmH(II)V

    .line 2236
    return-void
.end method

.method public setCarSpeedMS(FI)V
    .locals 1
    .param p1, "speed"    # F
    .param p2, "source"    # I

    .prologue
    .line 2241
    const/high16 v0, 0x42100000    # 36.0f

    mul-float/2addr v0, p1

    invoke-static {v0}, Lcom/thinkware/sundo/ieve/ieveMath;->ROUND_OFF(F)I

    move-result v0

    invoke-virtual {p0, v0, p2}, Lcom/thinkware/sundo/ieve/IEVE;->setCarSpeedHmH(II)V

    .line 2242
    return-void
.end method

.method public setCarSpeedMiH(FI)V
    .locals 1
    .param p1, "speed"    # F
    .param p2, "source"    # I

    .prologue
    .line 2247
    const v0, 0x4180bf5d

    mul-float/2addr v0, p1

    invoke-static {v0}, Lcom/thinkware/sundo/ieve/ieveMath;->ROUND_OFF(F)I

    move-result v0

    invoke-virtual {p0, v0, p2}, Lcom/thinkware/sundo/ieve/IEVE;->setCarSpeedHmH(II)V

    .line 2248
    return-void
.end method

.method public setCarStatusGPS(I)V
    .locals 5
    .param p1, "status"    # I

    .prologue
    const/4 v2, 0x1

    const/4 v4, 0x0

    .line 2196
    if-ltz p1, :cond_0

    const/4 v0, 0x3

    if-le p1, v0, :cond_1

    .line 2197
    :cond_0
    const-string v0, "java_IEVE"

    const-string v1, "setCarStatusGPS[Invalid status:%d]"

    new-array v2, v2, [Ljava/lang/Object;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    aput-object v3, v2, v4

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2204
    :goto_0
    return-void

    .line 2200
    :cond_1
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->GetCarStatusGPS()I

    move-result v0

    if-eq p1, v0, :cond_2

    .line 2201
    const-string v0, "java_IEVE"

    const-string v1, "setCarStatusGPS[%d]"

    new-array v2, v2, [Ljava/lang/Object;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    aput-object v3, v2, v4

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 2203
    :cond_2
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0, p1}, Lcom/thinkware/sundo/ieve/ieveNative;->SetCarStatusGPS(I)V

    goto :goto_0
.end method

.method public setCarType(IZ)V
    .locals 5
    .param p1, "type"    # I
    .param p2, "loaddefaultheight"    # Z

    .prologue
    .line 2252
    const-string v1, "java_IEVE"

    const-string v2, "setCarType[%d][%s]"

    const/4 v0, 0x2

    new-array v3, v0, [Ljava/lang/Object;

    const/4 v0, 0x0

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    aput-object v4, v3, v0

    const/4 v4, 0x1

    if-eqz p2, :cond_0

    const-string v0, "true"

    :goto_0
    aput-object v0, v3, v4

    invoke-static {v2, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 2253
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0, p1, p2}, Lcom/thinkware/sundo/ieve/ieveNative;->SetCarType(IZ)V

    .line 2254
    return-void

    .line 2252
    :cond_0
    const-string v0, "false"

    goto :goto_0
.end method

.method public setDeviceCameraHeight(I)V
    .locals 1
    .param p1, "height"    # I

    .prologue
    .line 2258
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0, p1}, Lcom/thinkware/sundo/ieve/ieveNative;->SetDeviceCameraHeight(I)V

    .line 2260
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->d:Lcom/stradvision/pdvdtest/SV_ADAS;

    invoke-virtual {v0, p1}, Lcom/stradvision/pdvdtest/SV_ADAS;->SetDeviceCameraHeight(I)V

    .line 2261
    return-void
.end method

.method public setDeviceCameraHeightDefault()V
    .locals 2

    .prologue
    .line 2265
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->SetDeviceCameraHeightDefault()V

    .line 2267
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->d:Lcom/stradvision/pdvdtest/SV_ADAS;

    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v1}, Lcom/thinkware/sundo/ieve/ieveNative;->GetDeviceCameraHeightDefault()I

    move-result v1

    invoke-virtual {v0, v1}, Lcom/stradvision/pdvdtest/SV_ADAS;->SetDeviceCameraHeight(I)V

    .line 2268
    return-void
.end method

.method public setGuideInfos(Lcom/thinkware/sundo/ieve/ieveGuideInfos;)V
    .locals 7
    .param p1, "guideinfos"    # Lcom/thinkware/sundo/ieve/ieveGuideInfos;

    .prologue
    const/4 v1, 0x0

    .line 2272
    if-nez p1, :cond_0

    .line 2273
    const-string v0, "java_IEVE"

    const-string v1, "ieveGuideInfos[Invalid ieveGuideInfos]"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2298
    :goto_0
    return-void

    .line 2276
    :cond_0
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->at:Lcom/thinkware/sundo/ieve/ieveTextView;

    if-eqz v0, :cond_1

    .line 2277
    const-string v2, ""

    .line 2278
    .local v2, "dbgtxt":Ljava/lang/String;
    const-string v3, "GI(RD:Ty(%d)No(%d), TP:%d(%dm), SC:%d(%.1f,%.1f), SA:%d, SG:%d(%.1f,%.1f), IM:%d, SZ:%d, CZ:%d)"

    const/16 v0, 0xe

    new-array v4, v0, [Ljava/lang/Object;

    const/4 v0, 0x0

    .line 2279
    iget v5, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->roadattrib_roadtype:I

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    aput-object v5, v4, v0

    const/4 v0, 0x1

    .line 2280
    iget v5, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->roadattrib_roadnumlane:I

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    aput-object v5, v4, v0

    const/4 v0, 0x2

    .line 2281
    iget v5, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->turnpoint_code:I

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    aput-object v5, v4, v0

    const/4 v0, 0x3

    .line 2282
    iget v5, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->turnpoint_dist:I

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    aput-object v5, v4, v0

    const/4 v0, 0x4

    .line 2283
    iget v5, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecamera_kind:I

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    aput-object v5, v4, v0

    const/4 v5, 0x5

    .line 2284
    iget v0, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecamera_kind:I

    if-nez v0, :cond_2

    move v0, v1

    :goto_1
    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v0

    aput-object v0, v4, v5

    const/4 v5, 0x6

    .line 2285
    iget v0, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecamera_kind:I

    if-nez v0, :cond_3

    move v0, v1

    :goto_2
    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v0

    aput-object v0, v4, v5

    const/4 v0, 0x7

    .line 2286
    iget v5, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecameraarea_kind:I

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    aput-object v5, v4, v0

    const/16 v0, 0x8

    .line 2287
    iget v5, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safeguide_kind:I

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    aput-object v5, v4, v0

    const/16 v5, 0x9

    .line 2288
    iget v0, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safeguide_kind:I

    if-nez v0, :cond_4

    move v0, v1

    :goto_3
    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v0

    aput-object v0, v4, v5

    const/16 v0, 0xa

    .line 2289
    iget v5, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safeguide_kind:I

    if-nez v5, :cond_5

    :goto_4
    invoke-static {v1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v1

    aput-object v1, v4, v0

    const/16 v0, 0xb

    .line 2290
    iget v1, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->intermediate_kind:I

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    aput-object v1, v4, v0

    const/16 v0, 0xc

    .line 2291
    iget v1, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->schoolzone_type:I

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    aput-object v1, v4, v0

    const/16 v0, 0xd

    .line 2292
    iget v1, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->constzone_type:I

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    aput-object v1, v4, v0

    .line 2278
    invoke-static {v3, v4}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    .line 2294
    const/16 v1, 0x5da

    const/high16 v3, 0x428c0000    # 70.0f

    const/high16 v4, 0x43e10000    # 450.0f

    const/high16 v5, 0x41900000    # 18.0f

    const v6, -0xff0100

    move-object v0, p0

    invoke-virtual/range {v0 .. v6}, Lcom/thinkware/sundo/ieve/IEVE;->DebugPrint(ILjava/lang/String;FFFI)V

    .line 2296
    .end local v2    # "dbgtxt":Ljava/lang/String;
    :cond_1
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->f:Lcom/thinkware/sundo/ieve/ieveGuideInfos;

    invoke-virtual {v0, p1}, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->copy(Lcom/thinkware/sundo/ieve/ieveGuideInfos;)V

    .line 2297
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->f:Lcom/thinkware/sundo/ieve/ieveGuideInfos;

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/ieve/ieveNative;->SetGuideInfos(Lcom/thinkware/sundo/ieve/ieveGuideInfos;)V

    goto/16 :goto_0

    .line 2284
    .restart local v2    # "dbgtxt":Ljava/lang/String;
    :cond_2
    iget v0, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecamera_pos_x:F

    goto :goto_1

    .line 2285
    :cond_3
    iget v0, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecamera_pos_z:F

    goto :goto_2

    .line 2288
    :cond_4
    iget v0, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safeguide_pos_x:F

    goto :goto_3

    .line 2289
    :cond_5
    iget v1, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safeguide_pos_z:F

    goto :goto_4
.end method

.method public setHandDrive(I)Z
    .locals 5
    .param p1, "hand"    # I

    .prologue
    const/4 v4, 0x1

    const/4 v1, 0x0

    .line 2302
    if-ltz p1, :cond_0

    if-le p1, v4, :cond_1

    .line 2303
    :cond_0
    const-string v0, "java_IEVE"

    const-string v2, "setHandDrive[Invalid hand:%d]"

    new-array v3, v4, [Ljava/lang/Object;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    aput-object v4, v3, v1

    invoke-static {v2, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    move v0, v1

    .line 2307
    :goto_0
    return v0

    .line 2306
    :cond_1
    const-string v2, "java_IEVE"

    const-string v3, "setHandDrive[%s]"

    new-array v4, v4, [Ljava/lang/Object;

    if-nez p1, :cond_2

    const-string v0, "Left"

    :goto_1
    aput-object v0, v4, v1

    invoke-static {v3, v4}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v2, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 2307
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0, p1}, Lcom/thinkware/sundo/ieve/ieveNative;->SetHandDrive(I)Z

    move-result v0

    goto :goto_0

    .line 2306
    :cond_2
    const-string v0, "Right"

    goto :goto_1
.end method

.method public setHandlerParent(Landroid/os/Handler;)V
    .locals 2
    .param p1, "handler"    # Landroid/os/Handler;

    .prologue
    .line 2312
    const-string v0, "java_IEVE"

    const-string v1, "setHandlerParent"

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 2313
    iput-object p1, p0, Lcom/thinkware/sundo/ieve/IEVE;->c:Landroid/os/Handler;

    .line 2314
    return-void
.end method

.method public setIEVEConfigValue(II)V
    .locals 7
    .param p1, "id"    # I
    .param p2, "value"    # I

    .prologue
    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v4, 0x0

    .line 2318
    sparse-switch p1, :sswitch_data_0

    .line 2410
    :cond_0
    :goto_0
    return-void

    .line 2320
    :sswitch_0
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0, p2}, Lcom/thinkware/sundo/ieve/ieveNative;->SetROILeftStep(I)V

    .line 2321
    const-string v0, "java_IEVE"

    const-string v1, "setIEVEConfigValue[IEVE_ID_CFG_ROI_LEFT_STEP:%d][%d]"

    new-array v2, v6, [Ljava/lang/Object;

    iget-object v3, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v3}, Lcom/thinkware/sundo/ieve/ieveNative;->GetROILeftStep()I

    move-result v3

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    aput-object v3, v2, v4

    iget-object v3, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v3}, Lcom/thinkware/sundo/ieve/ieveNative;->GetROILeft()I

    move-result v3

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    aput-object v3, v2, v5

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    .line 2324
    :sswitch_1
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0, p2}, Lcom/thinkware/sundo/ieve/ieveNative;->SetROIRightStep(I)V

    .line 2325
    const-string v0, "java_IEVE"

    const-string v1, "setIEVEConfigValue[IEVE_ID_CFG_ROI_RIGHT_STEP:%d][%d]"

    new-array v2, v6, [Ljava/lang/Object;

    iget-object v3, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v3}, Lcom/thinkware/sundo/ieve/ieveNative;->GetROIRightStep()I

    move-result v3

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    aput-object v3, v2, v4

    iget-object v3, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v3}, Lcom/thinkware/sundo/ieve/ieveNative;->GetROIRight()I

    move-result v3

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    aput-object v3, v2, v5

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    .line 2329
    :sswitch_2
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0, p2}, Lcom/thinkware/sundo/ieve/ieveNative;->SetDeviceCameraHeight(I)V

    .line 2331
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->d:Lcom/stradvision/pdvdtest/SV_ADAS;

    invoke-virtual {v0, p2}, Lcom/stradvision/pdvdtest/SV_ADAS;->SetDeviceCameraHeight(I)V

    .line 2332
    const-string v0, "java_IEVE"

    const-string v1, "setIEVEConfigValue[IEVE_ID_CFG_CAM_HEIGHT:%d]"

    new-array v2, v5, [Ljava/lang/Object;

    iget-object v3, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v3}, Lcom/thinkware/sundo/ieve/ieveNative;->GetDeviceCameraHeight()I

    move-result v3

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    aput-object v3, v2, v4

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    .line 2335
    :sswitch_3
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->SetDeviceCameraHeightDefault()V

    .line 2337
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->d:Lcom/stradvision/pdvdtest/SV_ADAS;

    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v1}, Lcom/thinkware/sundo/ieve/ieveNative;->GetDeviceCameraHeightDefault()I

    move-result v1

    invoke-virtual {v0, v1}, Lcom/stradvision/pdvdtest/SV_ADAS;->SetDeviceCameraHeight(I)V

    .line 2338
    const-string v0, "java_IEVE"

    const-string v1, "setIEVEConfigValue[IEVE_ID_CFG_CAM_HEIGHT_DEFAULT:%d]"

    new-array v2, v5, [Ljava/lang/Object;

    iget-object v3, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v3}, Lcom/thinkware/sundo/ieve/ieveNative;->GetDeviceCameraHeight()I

    move-result v3

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    aput-object v3, v2, v4

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    goto/16 :goto_0

    .line 2342
    :sswitch_4
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0, p2}, Lcom/thinkware/sundo/ieve/ieveNative;->SetVanishingPointX(I)Z

    .line 2343
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->S:Landroid/graphics/Point;

    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v1}, Lcom/thinkware/sundo/ieve/ieveNative;->GetVanishingPointXFromImage()I

    move-result v1

    iput v1, v0, Landroid/graphics/Point;->x:I

    .line 2344
    const-string v0, "java_IEVE"

    const-string v1, "setIEVEConfigValue[IEVE_ID_CFG_VANISH_PT_X:%d]"

    new-array v2, v5, [Ljava/lang/Object;

    iget-object v3, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v3}, Lcom/thinkware/sundo/ieve/ieveNative;->GetVanishingPointXFromImage()I

    move-result v3

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    aput-object v3, v2, v4

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 2346
    const-string v0, "java_IEVE"

    const-string v1, "VPToSV[%d * 4,%d * 3]"

    new-array v2, v6, [Ljava/lang/Object;

    iget-object v3, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v3}, Lcom/thinkware/sundo/ieve/ieveNative;->GetVanishingPointXFromImage()I

    move-result v3

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    aput-object v3, v2, v4

    iget-object v3, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v3}, Lcom/thinkware/sundo/ieve/ieveNative;->GetVanishingPointYFromImage()I

    move-result v3

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    aput-object v3, v2, v5

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 2347
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->d:Lcom/stradvision/pdvdtest/SV_ADAS;

    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v1}, Lcom/thinkware/sundo/ieve/ieveNative;->GetVanishingPointXFromImage()I

    move-result v1

    mul-int/lit8 v1, v1, 0x4

    iget-object v2, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v2}, Lcom/thinkware/sundo/ieve/ieveNative;->GetVanishingPointYFromImage()I

    move-result v2

    mul-int/lit8 v2, v2, 0x3

    invoke-virtual {v0, v1, v2}, Lcom/stradvision/pdvdtest/SV_ADAS;->SetVanishingPoint(II)V

    goto/16 :goto_0

    .line 2350
    :sswitch_5
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0, p2}, Lcom/thinkware/sundo/ieve/ieveNative;->SetVanishingPointY(I)Z

    .line 2351
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->S:Landroid/graphics/Point;

    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v1}, Lcom/thinkware/sundo/ieve/ieveNative;->GetVanishingPointYFromImage()I

    move-result v1

    iput v1, v0, Landroid/graphics/Point;->y:I

    .line 2352
    const-string v0, "java_IEVE"

    const-string v1, "setIEVEConfigValue[IEVE_ID_CFG_VANISH_PT_Y:%d]"

    new-array v2, v5, [Ljava/lang/Object;

    iget-object v3, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v3}, Lcom/thinkware/sundo/ieve/ieveNative;->GetVanishingPointYFromImage()I

    move-result v3

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    aput-object v3, v2, v4

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 2354
    const-string v0, "java_IEVE"

    const-string v1, "VPToSV[%d * 4,%d * 3]"

    new-array v2, v6, [Ljava/lang/Object;

    iget-object v3, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v3}, Lcom/thinkware/sundo/ieve/ieveNative;->GetVanishingPointXFromImage()I

    move-result v3

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    aput-object v3, v2, v4

    iget-object v3, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v3}, Lcom/thinkware/sundo/ieve/ieveNative;->GetVanishingPointYFromImage()I

    move-result v3

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    aput-object v3, v2, v5

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 2355
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->d:Lcom/stradvision/pdvdtest/SV_ADAS;

    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v1}, Lcom/thinkware/sundo/ieve/ieveNative;->GetVanishingPointXFromImage()I

    move-result v1

    mul-int/lit8 v1, v1, 0x4

    iget-object v2, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v2}, Lcom/thinkware/sundo/ieve/ieveNative;->GetVanishingPointYFromImage()I

    move-result v2

    mul-int/lit8 v2, v2, 0x3

    invoke-virtual {v0, v1, v2}, Lcom/stradvision/pdvdtest/SV_ADAS;->SetVanishingPoint(II)V

    goto/16 :goto_0

    .line 2358
    :sswitch_6
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->SetVanishingPointDefault()V

    .line 2359
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->S:Landroid/graphics/Point;

    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v1}, Lcom/thinkware/sundo/ieve/ieveNative;->GetVanishingPointXFromImage()I

    move-result v1

    iput v1, v0, Landroid/graphics/Point;->x:I

    .line 2360
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->S:Landroid/graphics/Point;

    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v1}, Lcom/thinkware/sundo/ieve/ieveNative;->GetVanishingPointYFromImage()I

    move-result v1

    iput v1, v0, Landroid/graphics/Point;->y:I

    .line 2361
    const-string v0, "java_IEVE"

    const-string v1, "setIEVEConfigValue[IEVE_ID_CFG_VANISH_PT_DEFAULT:x=%d,y=%d]"

    new-array v2, v6, [Ljava/lang/Object;

    iget-object v3, p0, Lcom/thinkware/sundo/ieve/IEVE;->S:Landroid/graphics/Point;

    iget v3, v3, Landroid/graphics/Point;->x:I

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    aput-object v3, v2, v4

    iget-object v3, p0, Lcom/thinkware/sundo/ieve/IEVE;->S:Landroid/graphics/Point;

    iget v3, v3, Landroid/graphics/Point;->y:I

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    aput-object v3, v2, v5

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 2363
    const-string v0, "java_IEVE"

    const-string v1, "VPToSV[%d * 4,%d * 3]"

    new-array v2, v6, [Ljava/lang/Object;

    iget-object v3, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v3}, Lcom/thinkware/sundo/ieve/ieveNative;->GetVanishingPointXFromImage()I

    move-result v3

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    aput-object v3, v2, v4

    iget-object v3, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v3}, Lcom/thinkware/sundo/ieve/ieveNative;->GetVanishingPointYFromImage()I

    move-result v3

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    aput-object v3, v2, v5

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 2364
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->d:Lcom/stradvision/pdvdtest/SV_ADAS;

    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v1}, Lcom/thinkware/sundo/ieve/ieveNative;->GetVanishingPointXFromImage()I

    move-result v1

    mul-int/lit8 v1, v1, 0x4

    iget-object v2, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v2}, Lcom/thinkware/sundo/ieve/ieveNative;->GetVanishingPointYFromImage()I

    move-result v2

    mul-int/lit8 v2, v2, 0x3

    invoke-virtual {v0, v1, v2}, Lcom/stradvision/pdvdtest/SV_ADAS;->SetVanishingPoint(II)V

    goto/16 :goto_0

    .line 2369
    :sswitch_7
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0, p2}, Lcom/thinkware/sundo/ieve/ieveNative;->SetROILeft(I)V

    .line 2370
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->i:Lcom/thinkware/sundo/ieve/ieveCalibrationView;

    if-eqz v0, :cond_1

    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->i:Lcom/thinkware/sundo/ieve/ieveCalibrationView;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->updateRoiPoints()V

    .line 2371
    :cond_1
    const-string v0, "java_IEVE"

    const-string v1, "setIEVEConfigValue[IEVE_ID_CFG_ROI_LEFT:%d]"

    new-array v2, v5, [Ljava/lang/Object;

    iget-object v3, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v3}, Lcom/thinkware/sundo/ieve/ieveNative;->GetROILeft()I

    move-result v3

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    aput-object v3, v2, v4

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    goto/16 :goto_0

    .line 2374
    :sswitch_8
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0, p2}, Lcom/thinkware/sundo/ieve/ieveNative;->SetROIRight(I)V

    .line 2375
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->i:Lcom/thinkware/sundo/ieve/ieveCalibrationView;

    if-eqz v0, :cond_2

    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->i:Lcom/thinkware/sundo/ieve/ieveCalibrationView;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->updateRoiPoints()V

    .line 2376
    :cond_2
    const-string v0, "java_IEVE"

    const-string v1, "setIEVEConfigValue[IEVE_ID_CFG_ROI_RIGHT:%d]"

    new-array v2, v5, [Ljava/lang/Object;

    iget-object v3, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v3}, Lcom/thinkware/sundo/ieve/ieveNative;->GetROIRight()I

    move-result v3

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    aput-object v3, v2, v4

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    goto/16 :goto_0

    .line 2379
    :sswitch_9
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0, p2}, Lcom/thinkware/sundo/ieve/ieveNative;->SetROIBottom(I)V

    .line 2380
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->i:Lcom/thinkware/sundo/ieve/ieveCalibrationView;

    if-eqz v0, :cond_3

    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->i:Lcom/thinkware/sundo/ieve/ieveCalibrationView;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->updateRoiPoints()V

    .line 2381
    :cond_3
    const-string v0, "java_IEVE"

    const-string v1, "setIEVEConfigValue[IEVE_ID_CFG_ROI_BOTTOM:%d]"

    new-array v2, v5, [Ljava/lang/Object;

    iget-object v3, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v3}, Lcom/thinkware/sundo/ieve/ieveNative;->GetROIBottom()I

    move-result v3

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    aput-object v3, v2, v4

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    goto/16 :goto_0

    .line 2384
    :sswitch_a
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->SetROILeftDefault()V

    .line 2385
    const-string v0, "java_IEVE"

    const-string v1, "setIEVEConfigValue[IEVE_ID_CFG_ROI_LEFT_DEFAULT:%d]"

    new-array v2, v5, [Ljava/lang/Object;

    iget-object v3, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v3}, Lcom/thinkware/sundo/ieve/ieveNative;->GetROILeft()I

    move-result v3

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    aput-object v3, v2, v4

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    goto/16 :goto_0

    .line 2388
    :sswitch_b
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->SetROIRightDefault()V

    .line 2389
    const-string v0, "java_IEVE"

    const-string v1, "setIEVEConfigValue[IEVE_ID_CFG_ROI_RIGHT_DEFAULT:%d]"

    new-array v2, v5, [Ljava/lang/Object;

    iget-object v3, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v3}, Lcom/thinkware/sundo/ieve/ieveNative;->GetROIRight()I

    move-result v3

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    aput-object v3, v2, v4

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    goto/16 :goto_0

    .line 2392
    :sswitch_c
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->SetROIBottomDefault()V

    .line 2393
    const-string v0, "java_IEVE"

    const-string v1, "setIEVEConfigValue[IEVE_ID_CFG_ROI_BOTTOM_DEFAULT:%d]"

    new-array v2, v5, [Ljava/lang/Object;

    iget-object v3, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v3}, Lcom/thinkware/sundo/ieve/ieveNative;->GetROIBottom()I

    move-result v3

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    aput-object v3, v2, v4

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    goto/16 :goto_0

    .line 2396
    :sswitch_d
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->T:Lcom/thinkware/sundo/ieve/ieveSoundManager;

    if-eqz v0, :cond_0

    .line 2397
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->T:Lcom/thinkware/sundo/ieve/ieveSoundManager;

    invoke-virtual {v0, p2}, Lcom/thinkware/sundo/ieve/ieveSoundManager;->setSoundVolume(I)V

    .line 2398
    const-string v0, "java_IEVE"

    const-string v1, "setIEVEConfigValue[IEVE_ID_CFG_SOUND_LEVEL:%d]"

    new-array v2, v5, [Ljava/lang/Object;

    iget-object v3, p0, Lcom/thinkware/sundo/ieve/IEVE;->T:Lcom/thinkware/sundo/ieve/ieveSoundManager;

    invoke-virtual {v3}, Lcom/thinkware/sundo/ieve/ieveSoundManager;->getSoundVolume()I

    move-result v3

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    aput-object v3, v2, v4

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    goto/16 :goto_0

    .line 2402
    :sswitch_e
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->T:Lcom/thinkware/sundo/ieve/ieveSoundManager;

    if-eqz v0, :cond_0

    .line 2403
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->T:Lcom/thinkware/sundo/ieve/ieveSoundManager;

    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->T:Lcom/thinkware/sundo/ieve/ieveSoundManager;

    invoke-virtual {v1}, Lcom/thinkware/sundo/ieve/ieveSoundManager;->getSoundMaxVolume()I

    move-result v1

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/ieve/ieveSoundManager;->setSoundVolume(I)V

    .line 2404
    const-string v0, "java_IEVE"

    const-string v1, "setIEVEConfigValue[IEVE_ID_CFG_SOUND_MAX_LEVEL:%d]"

    new-array v2, v5, [Ljava/lang/Object;

    iget-object v3, p0, Lcom/thinkware/sundo/ieve/IEVE;->T:Lcom/thinkware/sundo/ieve/ieveSoundManager;

    invoke-virtual {v3}, Lcom/thinkware/sundo/ieve/ieveSoundManager;->getSoundMaxVolume()I

    move-result v3

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    aput-object v3, v2, v4

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    goto/16 :goto_0

    .line 2318
    nop

    :sswitch_data_0
    .sparse-switch
        0x7100 -> :sswitch_7
        0x7101 -> :sswitch_8
        0x7102 -> :sswitch_9
        0x7110 -> :sswitch_a
        0x7111 -> :sswitch_b
        0x7112 -> :sswitch_c
        0x7120 -> :sswitch_0
        0x7121 -> :sswitch_1
        0x7200 -> :sswitch_2
        0x7201 -> :sswitch_3
        0x7300 -> :sswitch_4
        0x7301 -> :sswitch_5
        0x7302 -> :sswitch_6
        0x7400 -> :sswitch_d
        0x7401 -> :sswitch_e
    .end sparse-switch
.end method

.method public setLanguage(I)Z
    .locals 5
    .param p1, "language"    # I

    .prologue
    .line 2414
    const-string v0, "java_IEVE"

    const-string v1, "setLanguage[%d]"

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    aput-object v4, v2, v3

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 2415
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0, p1}, Lcom/thinkware/sundo/ieve/ieveNative;->SetLanguage(I)Z

    move-result v0

    return v0
.end method

.method public setMaxProcessFPS(D)V
    .locals 5
    .param p1, "fps"    # D

    .prologue
    .line 2432
    const-wide/high16 v0, 0x3ff0000000000000L    # 1.0

    cmpg-double v0, p1, v0

    if-gez v0, :cond_2

    const-wide/high16 p1, 0x3ff0000000000000L    # 1.0

    .line 2434
    :cond_0
    :goto_0
    const-string v0, "java_IEVE"

    const-string v1, "setMaxProcessFPS[%.1f]"

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    invoke-static {p1, p2}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v4

    aput-object v4, v2, v3

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 2435
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->j:Lcom/thinkware/sundo/ieve/ieveCameraView;

    if-eqz v0, :cond_1

    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->j:Lcom/thinkware/sundo/ieve/ieveCameraView;

    invoke-virtual {v0, p1, p2}, Lcom/thinkware/sundo/ieve/ieveCameraView;->setPreviewCallbackMaxFPS(D)V

    .line 2436
    :cond_1
    return-void

    .line 2433
    :cond_2
    const-wide/high16 v0, 0x403e000000000000L    # 30.0

    cmpl-double v0, p1, v0

    if-lez v0, :cond_0

    const-wide/high16 p1, 0x403e000000000000L    # 30.0

    goto :goto_0
.end method

.method public setNScreenManager(Lcom/thinkware/sundo/ieve/ieveNScreenManager;)V
    .locals 3
    .param p1, "nscreenmgr"    # Lcom/thinkware/sundo/ieve/ieveNScreenManager;

    .prologue
    const/4 v2, 0x0

    .line 2440
    const-string v0, "java_IEVE"

    const-string v1, "setNScreenManager"

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 2441
    if-nez p1, :cond_1

    .line 2442
    const-string v0, "java_IEVE"

    const-string v1, "setNScreenManager[Invalid ieveNScreenManager]"

    new-array v2, v2, [Ljava/lang/Object;

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2462
    :cond_0
    :goto_0
    return-void

    .line 2446
    :cond_1
    iput-boolean v2, p0, Lcom/thinkware/sundo/ieve/IEVE;->q:Z

    .line 2447
    invoke-direct {p0}, Lcom/thinkware/sundo/ieve/IEVE;->l()V

    .line 2448
    invoke-direct {p0}, Lcom/thinkware/sundo/ieve/IEVE;->m()V

    .line 2449
    invoke-direct {p0}, Lcom/thinkware/sundo/ieve/IEVE;->g()V

    .line 2451
    iput-object p1, p0, Lcom/thinkware/sundo/ieve/IEVE;->g:Lcom/thinkware/sundo/ieve/ieveNScreenManager;

    .line 2453
    invoke-direct {p0}, Lcom/thinkware/sundo/ieve/IEVE;->d()V

    .line 2454
    invoke-virtual {p0}, Lcom/thinkware/sundo/ieve/IEVE;->checkDebugMode()V

    .line 2455
    invoke-virtual {p0}, Lcom/thinkware/sundo/ieve/IEVE;->getStatus()I

    move-result v0

    invoke-direct {p0, v0}, Lcom/thinkware/sundo/ieve/IEVE;->b(I)V

    .line 2456
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->g:Lcom/thinkware/sundo/ieve/ieveNScreenManager;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->updateNScreen()V

    .line 2459
    iget-boolean v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->q:Z

    if-nez v0, :cond_0

    .line 2460
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->q:Z

    goto :goto_0
.end method

.method public setOBD2InfoBrakeSwitch(I)V
    .locals 5
    .param p1, "brakeswitch"    # I

    .prologue
    .line 2508
    const-string v0, "java_IEVE"

    const-string v1, "setOBD2InfoBrakeSwitch[%d]"

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    aput-object v4, v2, v3

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 2509
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0, p1}, Lcom/thinkware/sundo/ieve/ieveNative;->SetOBD2InfoBrakeSwitch(I)V

    .line 2510
    return-void
.end method

.method public setOBD2InfoGearMode(I)V
    .locals 5
    .param p1, "gearmode"    # I

    .prologue
    .line 2514
    const-string v0, "java_IEVE"

    const-string v1, "setOBD2InfoGearMode[%d]"

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    aput-object v4, v2, v3

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 2515
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0, p1}, Lcom/thinkware/sundo/ieve/ieveNative;->SetOBD2InfoGearMode(I)V

    .line 2516
    return-void
.end method

.method public setOBD2InfoSteeringDegree(F)V
    .locals 5
    .param p1, "steeringdegree"    # F

    .prologue
    .line 2520
    const-string v0, "java_IEVE"

    const-string v1, "setOBD2InfoSteeringDegree[%.1fdeg]"

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    invoke-static {p1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v4

    aput-object v4, v2, v3

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 2521
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0, p1}, Lcom/thinkware/sundo/ieve/ieveNative;->SetOBD2InfoSteeringDegree(F)V

    .line 2522
    return-void
.end method

.method public setOBD2Infos(FLjava/lang/String;Ljava/lang/String;)V
    .locals 11
    .param p1, "steeringdegree"    # F
    .param p2, "gearlevel"    # Ljava/lang/String;
    .param p3, "brakeswitch"    # Ljava/lang/String;

    .prologue
    const/4 v6, 0x1

    const/4 v5, 0x0

    .line 2466
    const/4 v10, 0x0

    .line 2467
    .local v10, "ngearstep":I
    const/4 v9, -0x1

    .line 2468
    .local v9, "ngearmode":I
    const/4 v8, 0x0

    .line 2470
    .local v8, "nbrakeswitch":I
    if-eqz p2, :cond_2

    invoke-virtual {p2}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_2

    const-string v0, "NotSupported"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_2

    .line 2471
    const-string v0, ":"

    invoke-virtual {p2, v0}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result v7

    .line 2472
    .local v7, "colon":I
    if-eqz v7, :cond_7

    .line 2473
    invoke-virtual {p2, v5, v7}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v10

    .line 2474
    add-int/lit8 v0, v7, 0x1

    invoke-virtual {p2}, Ljava/lang/String;->length()I

    move-result v1

    invoke-virtual {p2, v0, v1}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v9

    .line 2479
    :goto_0
    if-lez v10, :cond_0

    const/16 v0, 0x14

    if-le v10, v0, :cond_1

    .line 2480
    :cond_0
    const-string v0, "java_IEVE"

    const-string v1, "setOBD2Infos[Invalid GearStep:%d]"

    new-array v3, v6, [Ljava/lang/Object;

    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    aput-object v4, v3, v5

    invoke-static {v1, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 2482
    :cond_1
    if-eqz v9, :cond_2

    const/4 v0, 0x5

    if-eq v9, v0, :cond_2

    const/4 v0, 0x6

    if-eq v9, v0, :cond_2

    const/4 v0, 0x7

    if-eq v9, v0, :cond_2

    .line 2483
    const-string v0, "java_IEVE"

    const-string v1, "setOBD2Infos[Invalid GearMode:%d]"

    new-array v3, v6, [Ljava/lang/Object;

    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    aput-object v4, v3, v5

    invoke-static {v1, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 2486
    .end local v7    # "colon":I
    :cond_2
    if-eqz p3, :cond_3

    invoke-virtual {p3}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_3

    const-string v0, "NotSupported"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_3

    .line 2487
    invoke-static {p3}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v8

    .line 2490
    :cond_3
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->at:Lcom/thinkware/sundo/ieve/ieveTextView;

    if-eqz v0, :cond_6

    .line 2491
    const-string v2, ""

    .line 2492
    .local v2, "dbgtxt":Ljava/lang/String;
    const-string v0, "setOBD2Infos:IN(%.2f,%s,%s)"

    const/4 v1, 0x3

    new-array v1, v1, [Ljava/lang/Object;

    invoke-static {p1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v3

    aput-object v3, v1, v5

    if-nez p2, :cond_4

    const-string p2, "null"

    .end local p2    # "gearlevel":Ljava/lang/String;
    :cond_4
    aput-object p2, v1, v6

    const/4 v3, 0x2

    if-nez p3, :cond_5

    const-string p3, "null"

    .end local p3    # "brakeswitch":Ljava/lang/String;
    :cond_5
    aput-object p3, v1, v3

    invoke-static {v0, v1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    .line 2493
    packed-switch v9, :pswitch_data_0

    .line 2498
    :pswitch_0
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-static {v2}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string v1, "->GR(step:%d,mode:E)"

    new-array v3, v6, [Ljava/lang/Object;

    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    aput-object v4, v3, v5

    invoke-static {v1, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    .line 2500
    :goto_1
    const/16 v1, 0x513

    const/4 v3, 0x0

    const/high16 v4, 0x42480000    # 50.0f

    const/high16 v5, 0x41a00000    # 20.0f

    const v6, -0xff0100

    move-object v0, p0

    invoke-virtual/range {v0 .. v6}, Lcom/thinkware/sundo/ieve/IEVE;->DebugPrint(ILjava/lang/String;FFFI)V

    .line 2503
    .end local v2    # "dbgtxt":Ljava/lang/String;
    :cond_6
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0, p1, v9, v8}, Lcom/thinkware/sundo/ieve/ieveNative;->SetOBD2Infos(FII)V

    .line 2504
    return-void

    .line 2477
    .restart local v7    # "colon":I
    .restart local p2    # "gearlevel":Ljava/lang/String;
    .restart local p3    # "brakeswitch":Ljava/lang/String;
    :cond_7
    const-string v0, "java_IEVE"

    const-string v1, "setOBD2Infos[Nothing colon]"

    invoke-static {v0, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    goto/16 :goto_0

    .line 2494
    .end local v7    # "colon":I
    .end local p2    # "gearlevel":Ljava/lang/String;
    .end local p3    # "brakeswitch":Ljava/lang/String;
    .restart local v2    # "dbgtxt":Ljava/lang/String;
    :pswitch_1
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-static {v2}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string v1, "->GR(step:%d,mode:P)"

    new-array v3, v6, [Ljava/lang/Object;

    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    aput-object v4, v3, v5

    invoke-static {v1, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    goto :goto_1

    .line 2495
    :pswitch_2
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-static {v2}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string v1, "->GR(step:%d,mode:D)"

    new-array v3, v6, [Ljava/lang/Object;

    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    aput-object v4, v3, v5

    invoke-static {v1, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    goto :goto_1

    .line 2496
    :pswitch_3
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-static {v2}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string v1, "->GR(step:%d,mode:N)"

    new-array v3, v6, [Ljava/lang/Object;

    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    aput-object v4, v3, v5

    invoke-static {v1, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    goto :goto_1

    .line 2497
    :pswitch_4
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-static {v2}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string v1, "->GR(step:%d,mode:R)"

    new-array v3, v6, [Ljava/lang/Object;

    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    aput-object v4, v3, v5

    invoke-static {v1, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    goto/16 :goto_1

    .line 2493
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_2
        :pswitch_3
        :pswitch_4
    .end packed-switch
.end method

.method public setOperateAtSpeedLDWS(F)Z
    .locals 5
    .param p1, "speed"    # F

    .prologue
    .line 2526
    const-string v0, "java_IEVE"

    const-string v1, "setOperateAtSpeedLDWS[%.1fkm/h]"

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    invoke-static {p1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v4

    aput-object v4, v2, v3

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 2527
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    const/high16 v1, 0x41200000    # 10.0f

    mul-float/2addr v1, p1

    invoke-static {v1}, Lcom/thinkware/sundo/ieve/ieveMath;->ROUND_OFF(F)I

    move-result v1

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/ieve/ieveNative;->SetOperateAtSpeedKLDWS(I)Z

    move-result v0

    return v0
.end method

.method public setProposeToAdjustCamera(I)Z
    .locals 5
    .param p1, "returncode"    # I

    .prologue
    .line 2532
    const-string v0, "java_IEVE"

    const-string v1, "setProposeToAdjustCamera[%d]"

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    aput-object v4, v2, v3

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 2533
    iput p1, p0, Lcom/thinkware/sundo/ieve/IEVE;->R:I

    .line 2534
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0, p1}, Lcom/thinkware/sundo/ieve/ieveNative;->SetProposeToAdjustCamera(I)Z

    move-result v0

    return v0
.end method

.method public setROILeftStep(I)V
    .locals 1
    .param p1, "step"    # I

    .prologue
    .line 2539
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0, p1}, Lcom/thinkware/sundo/ieve/ieveNative;->SetROILeftStep(I)V

    .line 2540
    return-void
.end method

.method public setROIRightStep(I)V
    .locals 1
    .param p1, "step"    # I

    .prologue
    .line 2544
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0, p1}, Lcom/thinkware/sundo/ieve/ieveNative;->SetROIRightStep(I)V

    .line 2545
    return-void
.end method

.method public setRouteLine([FIZ)V
    .locals 5
    .param p1, "vertices"    # [F
    .param p2, "numvertices"    # I
    .param p3, "isescaperoute"    # Z

    .prologue
    .line 2549
    if-eqz p1, :cond_0

    array-length v1, p1

    mul-int/lit8 v2, p2, 0x3

    if-ge v1, v2, :cond_2

    .line 2550
    :cond_0
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    const/4 v2, 0x0

    invoke-virtual {v1, v2, p2, p3}, Lcom/thinkware/sundo/ieve/ieveNative;->SetRouteLine([FIZ)V

    .line 2555
    :goto_0
    if-eqz p1, :cond_1

    array-length v1, p1

    mul-int/lit8 v2, p2, 0x3

    if-eq v1, v2, :cond_1

    .line 2556
    const-string v2, "setRouteLine[vertices.length:%d, numvertices:%d, isescaperoute:%s]"

    const/4 v1, 0x3

    new-array v3, v1, [Ljava/lang/Object;

    const/4 v1, 0x0

    array-length v4, p1

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    aput-object v4, v3, v1

    const/4 v1, 0x1

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    aput-object v4, v3, v1

    const/4 v4, 0x2

    if-eqz p3, :cond_3

    const-string v1, "true"

    :goto_1
    aput-object v1, v3, v4

    invoke-static {v2, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    .line 2557
    .local v0, "text":Ljava/lang/String;
    const-string v1, "java_IEVE"

    invoke-static {v1, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 2559
    .end local v0    # "text":Ljava/lang/String;
    :cond_1
    return-void

    .line 2553
    :cond_2
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v1, p1, p2, p3}, Lcom/thinkware/sundo/ieve/ieveNative;->SetRouteLine([FIZ)V

    goto :goto_0

    .line 2556
    :cond_3
    const-string v1, "false"

    goto :goto_1
.end method

.method public setScreenPosLeaderLine(Landroid/graphics/Point;Landroid/graphics/Point;)V
    .locals 5
    .param p1, "pt1"    # Landroid/graphics/Point;
    .param p2, "pt2"    # Landroid/graphics/Point;

    .prologue
    .line 2420
    const-string v0, "java_IEVE"

    const-string v1, "setScreenPosLeaderLine[sx:%d, sy:%d, ex:%d, ey:%d]"

    const/4 v2, 0x4

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    iget v4, p1, Landroid/graphics/Point;->x:I

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    aput-object v4, v2, v3

    const/4 v3, 0x1

    iget v4, p1, Landroid/graphics/Point;->y:I

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    aput-object v4, v2, v3

    const/4 v3, 0x2

    iget v4, p2, Landroid/graphics/Point;->x:I

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    aput-object v4, v2, v3

    const/4 v3, 0x3

    iget v4, p2, Landroid/graphics/Point;->y:I

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    aput-object v4, v2, v3

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 2421
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    iget v1, p1, Landroid/graphics/Point;->x:I

    iget v2, p1, Landroid/graphics/Point;->y:I

    iget v3, p2, Landroid/graphics/Point;->x:I

    iget v4, p2, Landroid/graphics/Point;->y:I

    invoke-virtual {v0, v1, v2, v3, v4}, Lcom/thinkware/sundo/ieve/ieveNative;->SetScreenPosLeaderLine(IIII)V

    .line 2422
    return-void
.end method

.method public setScreenPosTLCA(Landroid/graphics/Point;)V
    .locals 5
    .param p1, "pt"    # Landroid/graphics/Point;

    .prologue
    .line 2426
    const-string v0, "java_IEVE"

    const-string v1, "setScreenPosTLCA[x:%d, y:%d]"

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    iget v4, p1, Landroid/graphics/Point;->x:I

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    aput-object v4, v2, v3

    const/4 v3, 0x1

    iget v4, p1, Landroid/graphics/Point;->y:I

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    aput-object v4, v2, v3

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 2427
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    iget v1, p1, Landroid/graphics/Point;->x:I

    iget v2, p1, Landroid/graphics/Point;->y:I

    invoke-virtual {v0, v1, v2}, Lcom/thinkware/sundo/ieve/ieveNative;->SetScreenPosTLCA(II)V

    .line 2428
    return-void
.end method

.method public setSensitivityCSWS(I)V
    .locals 5
    .param p1, "sense"    # I

    .prologue
    const/4 v4, 0x0

    const/4 v2, 0x1

    .line 2563
    if-lt p1, v2, :cond_0

    const/4 v0, 0x2

    if-le p1, v0, :cond_1

    .line 2564
    :cond_0
    const-string v0, "java_IEVE"

    const-string v1, "setSensitivityCSWS[Invalid sense:%d]"

    new-array v2, v2, [Ljava/lang/Object;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    aput-object v3, v2, v4

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2569
    :goto_0
    return-void

    .line 2567
    :cond_1
    const-string v0, "java_IEVE"

    const-string v1, "setSensitivityCSWS[%d]"

    new-array v2, v2, [Ljava/lang/Object;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    aput-object v3, v2, v4

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 2568
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0, p1}, Lcom/thinkware/sundo/ieve/ieveNative;->SetSensitivityCSWS(I)V

    goto :goto_0
.end method

.method public setSensitivityFCWS(I)V
    .locals 5
    .param p1, "sense"    # I

    .prologue
    const/4 v4, 0x0

    const/4 v2, 0x1

    .line 2573
    if-lt p1, v2, :cond_0

    const/4 v0, 0x3

    if-le p1, v0, :cond_1

    .line 2574
    :cond_0
    const-string v0, "java_IEVE"

    const-string v1, "setSensitivityFCWS[Invalid sense:%d]"

    new-array v2, v2, [Ljava/lang/Object;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    aput-object v3, v2, v4

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2581
    :goto_0
    return-void

    .line 2577
    :cond_1
    const-string v0, "java_IEVE"

    const-string v1, "setSensitivityFCWS[%d]"

    new-array v2, v2, [Ljava/lang/Object;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    aput-object v3, v2, v4

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 2578
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0, p1}, Lcom/thinkware/sundo/ieve/ieveNative;->SetSensitivityFCWS(I)V

    .line 2580
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->d:Lcom/stradvision/pdvdtest/SV_ADAS;

    invoke-virtual {v0, p1}, Lcom/stradvision/pdvdtest/SV_ADAS;->SetSensitivityFCWS(I)V

    goto :goto_0
.end method

.method public setSensitivityPCWS(I)V
    .locals 5
    .param p1, "sense"    # I

    .prologue
    const/4 v4, 0x0

    const/4 v2, 0x1

    .line 2585
    if-lt p1, v2, :cond_0

    const/4 v0, 0x3

    if-le p1, v0, :cond_1

    .line 2586
    :cond_0
    const-string v0, "java_IEVE"

    const-string v1, "setSensitivityPCWS[Invalid sense:%d]"

    new-array v2, v2, [Ljava/lang/Object;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    aput-object v3, v2, v4

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2593
    :goto_0
    return-void

    .line 2589
    :cond_1
    const-string v0, "java_IEVE"

    const-string v1, "setSensitivityPCWS[%d]"

    new-array v2, v2, [Ljava/lang/Object;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    aput-object v3, v2, v4

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 2590
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0, p1}, Lcom/thinkware/sundo/ieve/ieveNative;->SetSensitivityPCWS(I)V

    .line 2592
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->d:Lcom/stradvision/pdvdtest/SV_ADAS;

    invoke-virtual {v0, p1}, Lcom/stradvision/pdvdtest/SV_ADAS;->SetSensitivityPCWS(I)V

    goto :goto_0
.end method

.method public setSizeCalibrationView(Landroid/graphics/Rect;)V
    .locals 5
    .param p1, "size"    # Landroid/graphics/Rect;

    .prologue
    .line 2597
    const-string v0, "java_IEVE"

    const-string v1, "setSizeCalibrationView[%d,%d,%d,%d]"

    const/4 v2, 0x4

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    iget v4, p1, Landroid/graphics/Rect;->left:I

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    aput-object v4, v2, v3

    const/4 v3, 0x1

    iget v4, p1, Landroid/graphics/Rect;->top:I

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    aput-object v4, v2, v3

    const/4 v3, 0x2

    iget v4, p1, Landroid/graphics/Rect;->right:I

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    aput-object v4, v2, v3

    const/4 v3, 0x3

    iget v4, p1, Landroid/graphics/Rect;->bottom:I

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    aput-object v4, v2, v3

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 2598
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->u:Landroid/graphics/Rect;

    invoke-virtual {v0, p1}, Landroid/graphics/Rect;->set(Landroid/graphics/Rect;)V

    .line 2599
    invoke-virtual {p0}, Lcom/thinkware/sundo/ieve/IEVE;->getStatus()I

    move-result v0

    invoke-direct {p0, v0}, Lcom/thinkware/sundo/ieve/IEVE;->b(I)V

    .line 2600
    return-void
.end method

.method public setSoundVolume(I)V
    .locals 1
    .param p1, "value"    # I

    .prologue
    .line 2604
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->T:Lcom/thinkware/sundo/ieve/ieveSoundManager;

    if-eqz v0, :cond_0

    .line 2606
    :goto_0
    return-void

    .line 2605
    :cond_0
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->T:Lcom/thinkware/sundo/ieve/ieveSoundManager;

    invoke-virtual {v0, p1}, Lcom/thinkware/sundo/ieve/ieveSoundManager;->setSoundVolume(I)V

    goto :goto_0
.end method

.method public setStreamDataInfo(ZII)Z
    .locals 7
    .param p1, "enable"    # Z
    .param p2, "beforeseconds"    # I
    .param p3, "afterseconds"    # I

    .prologue
    const/4 v2, 0x1

    const/4 v1, 0x0

    .line 2610
    if-ltz p3, :cond_0

    if-ltz p2, :cond_0

    add-int v0, p3, p2

    if-ge v0, v2, :cond_1

    .line 2611
    :cond_0
    const-string v0, "java_IEVE"

    const-string v2, "setStreamDataInfo[Invalid seconds"

    new-array v3, v1, [Ljava/lang/Object;

    invoke-static {v2, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    move v0, v1

    .line 2633
    :goto_0
    return v0

    .line 2614
    :cond_1
    const-string v3, "java_IEVE"

    const-string v4, "setStreamDataInfo[%s,-%d~%d]"

    const/4 v0, 0x3

    new-array v5, v0, [Ljava/lang/Object;

    if-eqz p1, :cond_2

    const-string v0, "true"

    :goto_1
    aput-object v0, v5, v1

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    aput-object v0, v5, v2

    const/4 v0, 0x2

    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    aput-object v6, v5, v0

    invoke-static {v4, v5}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v3, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 2615
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->j:Lcom/thinkware/sundo/ieve/ieveCameraView;

    if-nez v0, :cond_3

    move v0, v1

    goto :goto_0

    .line 2614
    :cond_2
    const-string v0, "false"

    goto :goto_1

    .line 2617
    :cond_3
    iput p3, p0, Lcom/thinkware/sundo/ieve/IEVE;->n:I

    .line 2618
    iput p2, p0, Lcom/thinkware/sundo/ieve/IEVE;->o:I

    .line 2619
    iput-boolean p1, p0, Lcom/thinkware/sundo/ieve/IEVE;->p:Z

    .line 2620
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->am:Landroid/os/Handler;

    new-instance v1, Lcom/thinkware/sundo/ieve/IEVE$3;

    invoke-direct {v1, p0}, Lcom/thinkware/sundo/ieve/IEVE$3;-><init>(Lcom/thinkware/sundo/ieve/IEVE;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    move v0, v2

    .line 2633
    goto :goto_0
.end method

.method public setSundown(CCC)V
    .locals 1
    .param p1, "hour"    # C
    .param p2, "minute"    # C
    .param p3, "second"    # C

    .prologue
    .line 2638
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0, p1, p2, p3}, Lcom/thinkware/sundo/ieve/ieveNative;->SetSundown(CCC)V

    .line 2639
    return-void
.end method

.method public setSunup(CCC)V
    .locals 1
    .param p1, "hour"    # C
    .param p2, "minute"    # C
    .param p3, "second"    # C

    .prologue
    .line 2643
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0, p1, p2, p3}, Lcom/thinkware/sundo/ieve/ieveNative;->SetSunup(CCC)V

    .line 2644
    return-void
.end method

.method public setTurnedOnTurnLamp(ZZ)V
    .locals 2
    .param p1, "onleft"    # Z
    .param p2, "onright"    # Z

    .prologue
    .line 2648
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0, p1, p2}, Lcom/thinkware/sundo/ieve/ieveNative;->SetTurnedOnTurnLamp(ZZ)V

    .line 2649
    if-eqz p1, :cond_1

    if-eqz p2, :cond_1

    .line 2650
    const-string v0, "java_IEVE"

    const-string v1, "setTurnedOnTurnLamp[left & Right]"

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 2656
    :cond_0
    :goto_0
    return-void

    .line 2653
    :cond_1
    if-eqz p1, :cond_2

    const-string v0, "java_IEVE"

    const-string v1, "setTurnedOnTurnLamp[left]"

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 2654
    :cond_2
    if-eqz p2, :cond_0

    const-string v0, "java_IEVE"

    const-string v1, "setTurnedOnTurnLamp[right]"

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0
.end method

.method public setUseSunFilm(Z)V
    .locals 5
    .param p1, "used"    # Z

    .prologue
    .line 2660
    const-string v1, "java_IEVE"

    const-string v2, "setUseSunFilm[%s]"

    const/4 v0, 0x1

    new-array v3, v0, [Ljava/lang/Object;

    const/4 v4, 0x0

    if-eqz p1, :cond_0

    const-string v0, "true"

    :goto_0
    aput-object v0, v3, v4

    invoke-static {v2, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 2661
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0, p1}, Lcom/thinkware/sundo/ieve/ieveNative;->SetUseSunFilm(Z)V

    .line 2662
    return-void

    .line 2660
    :cond_0
    const-string v0, "false"

    goto :goto_0
.end method

.method public setVanishingPointDefault()V
    .locals 5

    .prologue
    .line 2666
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->SetVanishingPointDefault()V

    .line 2668
    const-string v0, "java_IEVE"

    const-string v1, "VPToSV[%d * 4,%d * 3]"

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    iget-object v4, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v4}, Lcom/thinkware/sundo/ieve/ieveNative;->GetVanishingPointXFromImage()I

    move-result v4

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    aput-object v4, v2, v3

    const/4 v3, 0x1

    iget-object v4, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v4}, Lcom/thinkware/sundo/ieve/ieveNative;->GetVanishingPointYFromImage()I

    move-result v4

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    aput-object v4, v2, v3

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 2669
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->d:Lcom/stradvision/pdvdtest/SV_ADAS;

    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v1}, Lcom/thinkware/sundo/ieve/ieveNative;->GetVanishingPointXFromImage()I

    move-result v1

    mul-int/lit8 v1, v1, 0x4

    iget-object v2, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v2}, Lcom/thinkware/sundo/ieve/ieveNative;->GetVanishingPointYFromImage()I

    move-result v2

    mul-int/lit8 v2, v2, 0x3

    invoke-virtual {v0, v1, v2}, Lcom/stradvision/pdvdtest/SV_ADAS;->SetVanishingPoint(II)V

    .line 2670
    return-void
.end method

.method public setVanishingPointX(I)V
    .locals 5
    .param p1, "value"    # I

    .prologue
    .line 2674
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0, p1}, Lcom/thinkware/sundo/ieve/ieveNative;->SetVanishingPointX(I)Z

    .line 2676
    const-string v0, "java_IEVE"

    const-string v1, "VPToSV[%d * 4,%d * 3]"

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    iget-object v4, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v4}, Lcom/thinkware/sundo/ieve/ieveNative;->GetVanishingPointXFromImage()I

    move-result v4

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    aput-object v4, v2, v3

    const/4 v3, 0x1

    iget-object v4, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v4}, Lcom/thinkware/sundo/ieve/ieveNative;->GetVanishingPointYFromImage()I

    move-result v4

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    aput-object v4, v2, v3

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 2677
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->d:Lcom/stradvision/pdvdtest/SV_ADAS;

    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v1}, Lcom/thinkware/sundo/ieve/ieveNative;->GetVanishingPointXFromImage()I

    move-result v1

    mul-int/lit8 v1, v1, 0x4

    iget-object v2, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v2}, Lcom/thinkware/sundo/ieve/ieveNative;->GetVanishingPointYFromImage()I

    move-result v2

    mul-int/lit8 v2, v2, 0x3

    invoke-virtual {v0, v1, v2}, Lcom/stradvision/pdvdtest/SV_ADAS;->SetVanishingPoint(II)V

    .line 2678
    return-void
.end method

.method public setVanishingPointY(I)V
    .locals 5
    .param p1, "value"    # I

    .prologue
    .line 2682
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0, p1}, Lcom/thinkware/sundo/ieve/ieveNative;->SetVanishingPointY(I)Z

    .line 2684
    const-string v0, "java_IEVE"

    const-string v1, "VPToSV[%d * 4,%d * 3]"

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    iget-object v4, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v4}, Lcom/thinkware/sundo/ieve/ieveNative;->GetVanishingPointXFromImage()I

    move-result v4

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    aput-object v4, v2, v3

    const/4 v3, 0x1

    iget-object v4, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v4}, Lcom/thinkware/sundo/ieve/ieveNative;->GetVanishingPointYFromImage()I

    move-result v4

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    aput-object v4, v2, v3

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 2685
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->d:Lcom/stradvision/pdvdtest/SV_ADAS;

    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v1}, Lcom/thinkware/sundo/ieve/ieveNative;->GetVanishingPointXFromImage()I

    move-result v1

    mul-int/lit8 v1, v1, 0x4

    iget-object v2, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v2}, Lcom/thinkware/sundo/ieve/ieveNative;->GetVanishingPointYFromImage()I

    move-result v2

    mul-int/lit8 v2, v2, 0x3

    invoke-virtual {v0, v1, v2}, Lcom/stradvision/pdvdtest/SV_ADAS;->SetVanishingPoint(II)V

    .line 2686
    return-void
.end method

.method public setViewFullMode(Z)V
    .locals 5
    .param p1, "enable"    # Z

    .prologue
    .line 2691
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->IsFullMode()Z

    move-result v0

    if-eq v0, p1, :cond_0

    .line 2692
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0, p1}, Lcom/thinkware/sundo/ieve/ieveNative;->SetFullMode(Z)V

    .line 2693
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->t:Landroid/graphics/Rect;

    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->IsFullMode()Z

    move-result v0

    if-eqz v0, :cond_1

    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->r:Landroid/graphics/Rect;

    :goto_0
    invoke-virtual {v1, v0}, Landroid/graphics/Rect;->set(Landroid/graphics/Rect;)V

    .line 2694
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->t:Landroid/graphics/Rect;

    iget v1, v1, Landroid/graphics/Rect;->left:I

    iget-object v2, p0, Lcom/thinkware/sundo/ieve/IEVE;->t:Landroid/graphics/Rect;

    iget v2, v2, Landroid/graphics/Rect;->top:I

    iget-object v3, p0, Lcom/thinkware/sundo/ieve/IEVE;->t:Landroid/graphics/Rect;

    invoke-virtual {v3}, Landroid/graphics/Rect;->width()I

    move-result v3

    iget-object v4, p0, Lcom/thinkware/sundo/ieve/IEVE;->t:Landroid/graphics/Rect;

    invoke-virtual {v4}, Landroid/graphics/Rect;->height()I

    move-result v4

    invoke-virtual {v0, v1, v2, v3, v4}, Lcom/thinkware/sundo/ieve/ieveNative;->SetSizeView(IIII)V

    .line 2695
    invoke-virtual {p0}, Lcom/thinkware/sundo/ieve/IEVE;->getStatus()I

    move-result v0

    invoke-direct {p0, v0}, Lcom/thinkware/sundo/ieve/IEVE;->b(I)V

    .line 2697
    :cond_0
    return-void

    .line 2693
    :cond_1
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->s:Landroid/graphics/Rect;

    goto :goto_0
.end method

.method public showBGCoverOverCamera(Z)V
    .locals 5
    .param p1, "enable"    # Z

    .prologue
    .line 2701
    const-string v1, "java_IEVE"

    const-string v2, "showBGCoverOverCamera[%s]"

    const/4 v0, 0x1

    new-array v3, v0, [Ljava/lang/Object;

    const/4 v4, 0x0

    if-eqz p1, :cond_0

    const-string v0, "true"

    :goto_0
    aput-object v0, v3, v4

    invoke-static {v2, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 2702
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v0, p1}, Lcom/thinkware/sundo/ieve/ieveNative;->ShowBGCoverOverCamera(Z)V

    .line 2703
    return-void

    .line 2701
    :cond_0
    const-string v0, "false"

    goto :goto_0
.end method

.method public showUpPreview(ZJ)V
    .locals 8
    .param p1, "enable"    # Z
    .param p2, "durationmillis"    # J

    .prologue
    const/4 v2, 0x1

    const/4 v3, 0x0

    .line 2707
    const-string v4, "java_IEVE"

    const-string v5, "showUpPreview[%s][%d]"

    const/4 v1, 0x2

    new-array v6, v1, [Ljava/lang/Object;

    if-eqz p1, :cond_0

    const-string v1, "true"

    :goto_0
    aput-object v1, v6, v3

    invoke-static {p2, p3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    aput-object v1, v6, v2

    invoke-static {v5, v6}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v4, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 2708
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->am:Landroid/os/Handler;

    const/16 v4, 0x3fc

    invoke-static {v1, v4}, Landroid/os/Message;->obtain(Landroid/os/Handler;I)Landroid/os/Message;

    move-result-object v0

    .line 2709
    .local v0, "msg":Landroid/os/Message;
    if-eqz p1, :cond_1

    move v1, v2

    :goto_1
    iput v1, v0, Landroid/os/Message;->arg1:I

    .line 2710
    long-to-int v1, p2

    iput v1, v0, Landroid/os/Message;->arg2:I

    .line 2711
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE;->am:Landroid/os/Handler;

    invoke-virtual {v1, v0}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    .line 2712
    return-void

    .line 2707
    .end local v0    # "msg":Landroid/os/Message;
    :cond_0
    const-string v1, "false"

    goto :goto_0

    .restart local v0    # "msg":Landroid/os/Message;
    :cond_1
    move v1, v3

    .line 2709
    goto :goto_1
.end method

.method public sleepIEVE(I)V
    .locals 2
    .param p1, "milliseconds"    # I

    .prologue
    .line 2716
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE;->e:Lcom/thinkware/sundo/ieve/ieveNative;

    const/4 v1, 0x1

    invoke-virtual {v0, p1, v1}, Lcom/thinkware/sundo/ieve/ieveNative;->SleepIEVE(IZ)V

    .line 2717
    return-void
.end method
