.class Ltas/internal/ipc/SenderManager$1;
.super Ltas/internal/ipc/server/ServerConnection;
.source "SenderManager.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ltas/internal/ipc/SenderManager;->connectToServer(Landroid/content/Context;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Ltas/internal/ipc/SenderManager;


# direct methods
.method constructor <init>(Ltas/internal/ipc/SenderManager;Landroid/content/Context;)V
    .locals 0
    .param p1, "this$0"    # Ltas/internal/ipc/SenderManager;
    .param p2, "$anonymous0"    # Landroid/content/Context;

    .prologue
    .line 650
    iput-object p1, p0, Ltas/internal/ipc/SenderManager$1;->this$0:Ltas/internal/ipc/SenderManager;

    invoke-direct {p0, p2}, Ltas/internal/ipc/server/ServerConnection;-><init>(Landroid/content/Context;)V

    return-void
.end method


# virtual methods
.method protected onReconnected()V
    .locals 9

    .prologue
    .line 658
    const-string/jumbo v6, "TasIPC<SenderManager>"

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v8, "number of senders : "

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    iget-object v8, p0, Ltas/internal/ipc/SenderManager$1;->this$0:Ltas/internal/ipc/SenderManager;

    invoke-static {v8}, Ltas/internal/ipc/SenderManager;->-get4(Ltas/internal/ipc/SenderManager;)Ljava/util/List;

    move-result-object v8

    invoke-interface {v8}, Ljava/util/List;->size()I

    move-result v8

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-static {v6, v7}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 659
    iget-object v6, p0, Ltas/internal/ipc/SenderManager$1;->this$0:Ltas/internal/ipc/SenderManager;

    invoke-static {v6}, Ltas/internal/ipc/SenderManager;->-get4(Ltas/internal/ipc/SenderManager;)Ljava/util/List;

    move-result-object v6

    invoke-interface {v6}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v3

    .local v3, "sw$iterator":Ljava/util/Iterator;
    :cond_0
    :goto_0
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_4

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ltas/internal/ipc/SenderManager$SenderWrapper;

    .line 660
    .local v2, "sw":Ltas/internal/ipc/SenderManager$SenderWrapper;
    if-eqz v2, :cond_0

    invoke-virtual {v2}, Ltas/internal/ipc/SenderManager$SenderWrapper;->ref()I

    move-result v6

    if-lez v6, :cond_0

    .line 661
    iget-object v6, p0, Ltas/internal/ipc/SenderManager$1;->this$0:Ltas/internal/ipc/SenderManager;

    invoke-static {v6, v2}, Ltas/internal/ipc/SenderManager;->-wrap7(Ltas/internal/ipc/SenderManager;Ltas/internal/ipc/SenderManager$SenderWrapper;)V

    .line 662
    invoke-static {v2}, Ltas/internal/ipc/SenderManager$SenderWrapper;->-get1(Ltas/internal/ipc/SenderManager$SenderWrapper;)Ljava/util/List;

    move-result-object v6

    invoke-interface {v6}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    .local v1, "s$iterator":Ljava/util/Iterator;
    :cond_1
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_3

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/ipc/Sender;

    .line 663
    .local v0, "s":Ltas/internal/ipc/Sender;
    if-eqz v0, :cond_1

    .line 664
    iget-object v6, v0, Ltas/internal/ipc/Sender;->mWatchList:Ljava/util/List;

    invoke-interface {v6}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v5

    .local v5, "watch$iterator":Ljava/util/Iterator;
    :cond_2
    :goto_1
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_1

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    .line 665
    .local v4, "watch":Ljava/lang/String;
    if-eqz v4, :cond_2

    .line 666
    iget-object v6, p0, Ltas/internal/ipc/SenderManager$1;->this$0:Ltas/internal/ipc/SenderManager;

    invoke-static {v6, v2, v4}, Ltas/internal/ipc/SenderManager;->-wrap11(Ltas/internal/ipc/SenderManager;Ltas/internal/ipc/SenderManager$SenderWrapper;Ljava/lang/String;)V

    goto :goto_1

    .line 670
    .end local v0    # "s":Ltas/internal/ipc/Sender;
    .end local v4    # "watch":Ljava/lang/String;
    .end local v5    # "watch$iterator":Ljava/util/Iterator;
    :cond_3
    invoke-static {v2}, Ltas/internal/ipc/SenderManager$SenderWrapper;->-get3(Ltas/internal/ipc/SenderManager$SenderWrapper;)Z

    move-result v6

    if-eqz v6, :cond_0

    .line 671
    iget-object v6, p0, Ltas/internal/ipc/SenderManager$1;->this$0:Ltas/internal/ipc/SenderManager;

    invoke-static {v6, v2}, Ltas/internal/ipc/SenderManager;->-wrap10(Ltas/internal/ipc/SenderManager;Ltas/internal/ipc/SenderManager$SenderWrapper;)V

    goto :goto_0

    .line 657
    .end local v1    # "s$iterator":Ljava/util/Iterator;
    .end local v2    # "sw":Ltas/internal/ipc/SenderManager$SenderWrapper;
    :cond_4
    return-void
.end method

.method protected prepareReconnection()V
    .locals 3

    .prologue
    .line 652
    iget-object v2, p0, Ltas/internal/ipc/SenderManager$1;->this$0:Ltas/internal/ipc/SenderManager;

    invoke-static {v2}, Ltas/internal/ipc/SenderManager;->-get4(Ltas/internal/ipc/SenderManager;)Ljava/util/List;

    move-result-object v2

    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    .local v1, "sw$iterator":Ljava/util/Iterator;
    :cond_0
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/ipc/SenderManager$SenderWrapper;

    .line 653
    .local v0, "sw":Ltas/internal/ipc/SenderManager$SenderWrapper;
    if-eqz v0, :cond_0

    invoke-static {v0}, Ltas/internal/ipc/SenderManager$SenderWrapper;->-wrap0(Ltas/internal/ipc/SenderManager$SenderWrapper;)V

    goto :goto_0

    .line 651
    .end local v0    # "sw":Ltas/internal/ipc/SenderManager$SenderWrapper;
    :cond_1
    return-void
.end method
