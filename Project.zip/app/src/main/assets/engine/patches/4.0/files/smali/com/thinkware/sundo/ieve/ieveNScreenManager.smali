.class public Lcom/thinkware/sundo/ieve/ieveNScreenManager;
.super Ljava/lang/Object;
.source "ieveNScreenManager.java"


# static fields
.field public static final ID_VIEW_ARVIEW:I = 0x1030

.field public static final ID_VIEW_CALIBR:I = 0x1040

.field public static final ID_VIEW_CAMERA:I = 0x1010

.field public static final ID_VIEW_DBGIMG:I = 0xfffe

.field public static final ID_VIEW_DBGLOG:I = 0xffff

.field public static final ID_VIEW_DPVIEW:I = 0x1020

.field private static final a:Ljava/lang/String;


# instance fields
.field private b:Landroid/content/Context;

.field private c:Landroid/graphics/Rect;

.field private d:Landroid/widget/FrameLayout;

.field private e:Ljava/util/TreeMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/TreeMap",
            "<",
            "Ljava/lang/Integer;",
            "Landroid/view/View;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .prologue
    .line 16
    const-class v0, Lcom/thinkware/sundo/ieve/ieveNScreenManager;

    invoke-virtual {v0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->a:Ljava/lang/String;

    .line 25
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .locals 4
    .param p1, "context"    # Landroid/content/Context;

    .prologue
    const/4 v3, -0x1

    const/4 v1, 0x0

    .line 33
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 17
    iput-object v1, p0, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->b:Landroid/content/Context;

    .line 28
    iput-object v1, p0, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->c:Landroid/graphics/Rect;

    .line 29
    iput-object v1, p0, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->d:Landroid/widget/FrameLayout;

    .line 30
    iput-object v1, p0, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->e:Ljava/util/TreeMap;

    .line 34
    sget-object v1, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->a:Ljava/lang/String;

    const-string v2, "Constructor"

    invoke-static {v1, v2}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 35
    iput-object p1, p0, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->b:Landroid/content/Context;

    .line 37
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->b:Landroid/content/Context;

    if-nez v1, :cond_0

    .line 38
    const-string v1, "Context is null!"

    const/4 v2, 0x0

    new-array v2, v2, [Ljava/lang/Object;

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    .line 39
    .local v0, "text":Ljava/lang/String;
    sget-object v1, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->a:Ljava/lang/String;

    invoke-static {v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 46
    .end local v0    # "text":Ljava/lang/String;
    :goto_0
    return-void

    .line 42
    :cond_0
    new-instance v1, Landroid/graphics/Rect;

    invoke-direct {v1}, Landroid/graphics/Rect;-><init>()V

    iput-object v1, p0, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->c:Landroid/graphics/Rect;

    .line 43
    new-instance v1, Landroid/widget/FrameLayout;

    iget-object v2, p0, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->b:Landroid/content/Context;

    invoke-direct {v1, v2}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    iput-object v1, p0, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->d:Landroid/widget/FrameLayout;

    .line 44
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->d:Landroid/widget/FrameLayout;

    new-instance v2, Landroid/view/ViewGroup$LayoutParams;

    invoke-direct {v2, v3, v3}, Landroid/view/ViewGroup$LayoutParams;-><init>(II)V

    invoke-virtual {v1, v2}, Landroid/widget/FrameLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 45
    new-instance v1, Ljava/util/TreeMap;

    invoke-direct {v1}, Ljava/util/TreeMap;-><init>()V

    iput-object v1, p0, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->e:Ljava/util/TreeMap;

    goto :goto_0
.end method

.method private a(Z)V
    .locals 6
    .param p1, "bringtofront"    # Z

    .prologue
    .line 214
    const/4 v3, 0x0

    .line 216
    .local v3, "view":Landroid/view/View;
    iget-object v4, p0, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->e:Ljava/util/TreeMap;

    invoke-virtual {v4}, Ljava/util/TreeMap;->clear()V

    .line 217
    const/4 v0, 0x0

    .local v0, "i":I
    :goto_0
    iget-object v4, p0, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->d:Landroid/widget/FrameLayout;

    invoke-virtual {v4}, Landroid/widget/FrameLayout;->getChildCount()I

    move-result v4

    if-lt v0, v4, :cond_2

    .line 223
    iget-object v4, p0, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->e:Ljava/util/TreeMap;

    invoke-virtual {v4}, Ljava/util/TreeMap;->keySet()Ljava/util/Set;

    move-result-object v4

    invoke-interface {v4}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v2

    .line 224
    .local v2, "it":Ljava/util/Iterator;, "Ljava/util/Iterator<Ljava/lang/Integer;>;"
    :cond_0
    :goto_1
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-nez v4, :cond_4

    .line 235
    iget-object v4, p0, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->e:Ljava/util/TreeMap;

    const v5, 0xffff

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/util/TreeMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    .end local v3    # "view":Landroid/view/View;
    check-cast v3, Landroid/view/View;

    .line 236
    .restart local v3    # "view":Landroid/view/View;
    if-eqz v3, :cond_1

    .line 237
    invoke-virtual {v3}, Landroid/view/View;->bringToFront()V

    .line 238
    invoke-virtual {v3}, Landroid/view/View;->invalidate()V

    .line 239
    iget-object v4, p0, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->d:Landroid/widget/FrameLayout;

    invoke-virtual {v4, v3}, Landroid/widget/FrameLayout;->bringChildToFront(Landroid/view/View;)V

    .line 241
    :cond_1
    iget-object v4, p0, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->d:Landroid/widget/FrameLayout;

    invoke-virtual {v4}, Landroid/widget/FrameLayout;->invalidate()V

    .line 242
    return-void

    .line 218
    .end local v2    # "it":Ljava/util/Iterator;, "Ljava/util/Iterator<Ljava/lang/Integer;>;"
    :cond_2
    iget-object v4, p0, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->d:Landroid/widget/FrameLayout;

    invoke-virtual {v4, v0}, Landroid/widget/FrameLayout;->getChildAt(I)Landroid/view/View;

    move-result-object v3

    .line 219
    if-nez v3, :cond_3

    .line 217
    :goto_2
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    .line 220
    :cond_3
    invoke-virtual {v3}, Landroid/view/View;->getId()I

    move-result v1

    .line 221
    .local v1, "index":I
    iget-object v4, p0, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->e:Ljava/util/TreeMap;

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-virtual {v4, v5, v3}, Ljava/util/TreeMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_2

    .line 225
    .end local v1    # "index":I
    .restart local v2    # "it":Ljava/util/Iterator;, "Ljava/util/Iterator<Ljava/lang/Integer;>;"
    :cond_4
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/Integer;

    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    move-result v1

    .line 226
    .restart local v1    # "index":I
    iget-object v4, p0, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->e:Ljava/util/TreeMap;

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/util/TreeMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    .end local v3    # "view":Landroid/view/View;
    check-cast v3, Landroid/view/View;

    .line 227
    .restart local v3    # "view":Landroid/view/View;
    if-eqz v3, :cond_0

    .line 228
    invoke-virtual {v3}, Landroid/view/View;->invalidate()V

    .line 229
    if-eqz p1, :cond_0

    .line 230
    invoke-virtual {v3}, Landroid/view/View;->bringToFront()V

    .line 231
    invoke-virtual {v3}, Landroid/view/View;->invalidate()V

    .line 232
    iget-object v4, p0, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->d:Landroid/widget/FrameLayout;

    invoke-virtual {v4, v3}, Landroid/widget/FrameLayout;->bringChildToFront(Landroid/view/View;)V

    goto :goto_1
.end method


# virtual methods
.method public close()V
    .locals 3

    .prologue
    const/4 v2, 0x0

    .line 49
    sget-object v0, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->a:Ljava/lang/String;

    const-string v1, "close"

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 50
    invoke-virtual {p0}, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->removeAllViews()V

    .line 51
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->e:Ljava/util/TreeMap;

    invoke-virtual {v0}, Ljava/util/TreeMap;->clear()V

    .line 52
    iput-object v2, p0, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->e:Ljava/util/TreeMap;

    .line 53
    iput-object v2, p0, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->d:Landroid/widget/FrameLayout;

    .line 54
    return-void
.end method

.method public getLayout()Landroid/widget/FrameLayout;
    .locals 1

    .prologue
    .line 57
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->d:Landroid/widget/FrameLayout;

    return-object v0
.end method

.method public getLayoutParams()Landroid/widget/FrameLayout$LayoutParams;
    .locals 1

    .prologue
    .line 61
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->d:Landroid/widget/FrameLayout;

    invoke-virtual {v0}, Landroid/widget/FrameLayout;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    check-cast v0, Landroid/widget/FrameLayout$LayoutParams;

    return-object v0
.end method

.method public getView(I)Landroid/view/View;
    .locals 1
    .param p1, "index"    # I

    .prologue
    .line 69
    if-gez p1, :cond_0

    const/4 v0, 0x0

    .line 70
    :goto_0
    return-object v0

    :cond_0
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->d:Landroid/widget/FrameLayout;

    invoke-virtual {v0, p1}, Landroid/widget/FrameLayout;->findViewById(I)Landroid/view/View;

    move-result-object v0

    goto :goto_0
.end method

.method public getViewSize(I)Landroid/graphics/Rect;
    .locals 6
    .param p1, "index"    # I

    .prologue
    const/4 v1, 0x0

    .line 74
    if-gez p1, :cond_1

    .line 78
    :cond_0
    :goto_0
    return-object v1

    .line 75
    :cond_1
    iget-object v2, p0, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->d:Landroid/widget/FrameLayout;

    invoke-virtual {v2, p1}, Landroid/widget/FrameLayout;->findViewById(I)Landroid/view/View;

    move-result-object v0

    .line 76
    .local v0, "view":Landroid/view/View;
    if-eqz v0, :cond_0

    .line 77
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->c:Landroid/graphics/Rect;

    invoke-virtual {v0}, Landroid/view/View;->getLeft()I

    move-result v2

    invoke-virtual {v0}, Landroid/view/View;->getTop()I

    move-result v3

    invoke-virtual {v0}, Landroid/view/View;->getRight()I

    move-result v4

    invoke-virtual {v0}, Landroid/view/View;->getBottom()I

    move-result v5

    invoke-virtual {v1, v2, v3, v4, v5}, Landroid/graphics/Rect;->set(IIII)V

    .line 78
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->c:Landroid/graphics/Rect;

    goto :goto_0
.end method

.method public getVisibility(I)I
    .locals 3
    .param p1, "index"    # I

    .prologue
    const/4 v1, -0x1

    .line 82
    if-gez p1, :cond_1

    .line 85
    :cond_0
    :goto_0
    return v1

    .line 83
    :cond_1
    iget-object v2, p0, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->d:Landroid/widget/FrameLayout;

    invoke-virtual {v2, p1}, Landroid/widget/FrameLayout;->findViewById(I)Landroid/view/View;

    move-result-object v0

    .line 84
    .local v0, "view":Landroid/view/View;
    if-eqz v0, :cond_0

    .line 85
    invoke-virtual {v0}, Landroid/view/View;->getVisibility()I

    move-result v1

    goto :goto_0
.end method

.method public insertView(ILandroid/view/View;IIII)Z
    .locals 9
    .param p1, "index"    # I
    .param p2, "view"    # Landroid/view/View;
    .param p3, "x"    # I
    .param p4, "y"    # I
    .param p5, "width"    # I
    .param p6, "height"    # I

    .prologue
    .line 89
    const/4 v7, 0x1

    const/4 v8, 0x0

    move-object v0, p0

    move v1, p1

    move-object v2, p2

    move v3, p3

    move v4, p4

    move v5, p5

    move v6, p6

    invoke-virtual/range {v0 .. v8}, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->insertView(ILandroid/view/View;IIIIZI)Z

    move-result v0

    return v0
.end method

.method public insertView(ILandroid/view/View;IIIIZ)Z
    .locals 9
    .param p1, "index"    # I
    .param p2, "view"    # Landroid/view/View;
    .param p3, "x"    # I
    .param p4, "y"    # I
    .param p5, "width"    # I
    .param p6, "height"    # I
    .param p7, "bringtofront"    # Z

    .prologue
    .line 93
    const/4 v8, 0x0

    move-object v0, p0

    move v1, p1

    move-object v2, p2

    move v3, p3

    move v4, p4

    move v5, p5

    move v6, p6

    move/from16 v7, p7

    invoke-virtual/range {v0 .. v8}, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->insertView(ILandroid/view/View;IIIIZI)Z

    move-result v0

    return v0
.end method

.method public insertView(ILandroid/view/View;IIIIZI)Z
    .locals 12
    .param p1, "index"    # I
    .param p2, "view"    # Landroid/view/View;
    .param p3, "x"    # I
    .param p4, "y"    # I
    .param p5, "width"    # I
    .param p6, "height"    # I
    .param p7, "bringtofront"    # Z
    .param p8, "visibility"    # I

    .prologue
    .line 97
    new-instance v11, Landroid/widget/FrameLayout$LayoutParams;

    move/from16 v0, p5

    move/from16 v1, p6

    invoke-direct {v11, v0, v1}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    .line 98
    .local v11, "params":Landroid/widget/FrameLayout$LayoutParams;
    const/16 v2, 0x30

    iput v2, v11, Landroid/widget/FrameLayout$LayoutParams;->gravity:I

    .line 99
    iput p3, v11, Landroid/widget/FrameLayout$LayoutParams;->leftMargin:I

    .line 100
    move/from16 v0, p4

    iput v0, v11, Landroid/widget/FrameLayout$LayoutParams;->topMargin:I

    .line 101
    move/from16 v0, p5

    iput v0, v11, Landroid/widget/FrameLayout$LayoutParams;->width:I

    .line 102
    move/from16 v0, p6

    iput v0, v11, Landroid/widget/FrameLayout$LayoutParams;->height:I

    move-object v2, p0

    move v3, p1

    move-object v4, p2

    move v5, p3

    move/from16 v6, p4

    move/from16 v7, p5

    move/from16 v8, p6

    move/from16 v9, p7

    move/from16 v10, p8

    .line 103
    invoke-virtual/range {v2 .. v11}, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->insertView(ILandroid/view/View;IIIIZILandroid/widget/FrameLayout$LayoutParams;)Z

    move-result v2

    return v2
.end method

.method public insertView(ILandroid/view/View;IIIIZILandroid/widget/FrameLayout$LayoutParams;)Z
    .locals 8
    .param p1, "index"    # I
    .param p2, "view"    # Landroid/view/View;
    .param p3, "x"    # I
    .param p4, "y"    # I
    .param p5, "width"    # I
    .param p6, "height"    # I
    .param p7, "bringtofront"    # Z
    .param p8, "visibility"    # I
    .param p9, "params"    # Landroid/widget/FrameLayout$LayoutParams;

    .prologue
    .line 107
    if-gez p1, :cond_0

    const/4 v1, 0x0

    .line 119
    :goto_0
    return v1

    .line 108
    :cond_0
    if-nez p2, :cond_1

    const/4 v1, 0x0

    goto :goto_0

    .line 109
    :cond_1
    const/4 v7, 0x0

    .local v7, "i":I
    :goto_1
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->d:Landroid/widget/FrameLayout;

    invoke-virtual {v1}, Landroid/widget/FrameLayout;->getChildCount()I

    move-result v1

    if-lt v7, v1, :cond_2

    .line 114
    invoke-virtual {p2, p1}, Landroid/view/View;->setId(I)V

    .line 115
    move/from16 v0, p8

    invoke-virtual {p2, v0}, Landroid/view/View;->setVisibility(I)V

    .line 116
    move-object/from16 v0, p9

    invoke-virtual {p2, v0}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 117
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->d:Landroid/widget/FrameLayout;

    invoke-virtual {v1, p2}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;)V

    .line 118
    invoke-direct {p0, p7}, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->a(Z)V

    .line 119
    const/4 v1, 0x1

    goto :goto_0

    .line 110
    :cond_2
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->d:Landroid/widget/FrameLayout;

    invoke-virtual {v1, v7}, Landroid/widget/FrameLayout;->getChildAt(I)Landroid/view/View;

    move-result-object v1

    invoke-virtual {v1, p2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_3

    move-object v1, p0

    move v2, p1

    move v3, p3

    move v4, p4

    move v5, p5

    move v6, p6

    .line 111
    invoke-virtual/range {v1 .. v6}, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->moveView(IIIII)Z

    move-result v1

    goto :goto_0

    .line 109
    :cond_3
    add-int/lit8 v7, v7, 0x1

    goto :goto_1
.end method

.method public insertView(ILandroid/view/View;Landroid/graphics/Rect;)Z
    .locals 8
    .param p1, "index"    # I
    .param p2, "view"    # Landroid/view/View;
    .param p3, "rc"    # Landroid/graphics/Rect;

    .prologue
    .line 123
    if-nez p3, :cond_0

    const/4 v0, 0x0

    .line 124
    :goto_0
    return v0

    :cond_0
    iget v3, p3, Landroid/graphics/Rect;->left:I

    iget v4, p3, Landroid/graphics/Rect;->top:I

    invoke-virtual {p3}, Landroid/graphics/Rect;->width()I

    move-result v5

    invoke-virtual {p3}, Landroid/graphics/Rect;->height()I

    move-result v6

    const/4 v7, 0x1

    move-object v0, p0

    move v1, p1

    move-object v2, p2

    invoke-virtual/range {v0 .. v7}, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->insertView(ILandroid/view/View;IIIIZ)Z

    move-result v0

    goto :goto_0
.end method

.method public insertView(ILandroid/view/View;Landroid/graphics/Rect;Z)Z
    .locals 8
    .param p1, "index"    # I
    .param p2, "view"    # Landroid/view/View;
    .param p3, "rc"    # Landroid/graphics/Rect;
    .param p4, "bringtofront"    # Z

    .prologue
    .line 128
    if-nez p3, :cond_0

    const/4 v0, 0x0

    .line 129
    :goto_0
    return v0

    :cond_0
    iget v3, p3, Landroid/graphics/Rect;->left:I

    iget v4, p3, Landroid/graphics/Rect;->top:I

    invoke-virtual {p3}, Landroid/graphics/Rect;->width()I

    move-result v5

    invoke-virtual {p3}, Landroid/graphics/Rect;->height()I

    move-result v6

    move-object v0, p0

    move v1, p1

    move-object v2, p2

    move v7, p4

    invoke-virtual/range {v0 .. v7}, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->insertView(ILandroid/view/View;IIIIZ)Z

    move-result v0

    goto :goto_0
.end method

.method public insertView(ILandroid/view/View;Landroid/graphics/Rect;ZI)Z
    .locals 9
    .param p1, "index"    # I
    .param p2, "view"    # Landroid/view/View;
    .param p3, "rc"    # Landroid/graphics/Rect;
    .param p4, "bringtofront"    # Z
    .param p5, "visibility"    # I

    .prologue
    .line 133
    if-nez p3, :cond_0

    const/4 v0, 0x0

    .line 134
    :goto_0
    return v0

    :cond_0
    iget v3, p3, Landroid/graphics/Rect;->left:I

    iget v4, p3, Landroid/graphics/Rect;->top:I

    invoke-virtual {p3}, Landroid/graphics/Rect;->width()I

    move-result v5

    invoke-virtual {p3}, Landroid/graphics/Rect;->height()I

    move-result v6

    move-object v0, p0

    move v1, p1

    move-object v2, p2

    move v7, p4

    move v8, p5

    invoke-virtual/range {v0 .. v8}, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->insertView(ILandroid/view/View;IIIIZI)Z

    move-result v0

    goto :goto_0
.end method

.method public insertView(ILandroid/view/View;Landroid/graphics/Rect;ZILandroid/widget/FrameLayout$LayoutParams;)Z
    .locals 10
    .param p1, "index"    # I
    .param p2, "view"    # Landroid/view/View;
    .param p3, "rc"    # Landroid/graphics/Rect;
    .param p4, "bringtofront"    # Z
    .param p5, "visibility"    # I
    .param p6, "params"    # Landroid/widget/FrameLayout$LayoutParams;

    .prologue
    .line 138
    if-nez p3, :cond_0

    const/4 v0, 0x0

    .line 139
    :goto_0
    return v0

    :cond_0
    iget v3, p3, Landroid/graphics/Rect;->left:I

    iget v4, p3, Landroid/graphics/Rect;->top:I

    invoke-virtual {p3}, Landroid/graphics/Rect;->width()I

    move-result v5

    invoke-virtual {p3}, Landroid/graphics/Rect;->height()I

    move-result v6

    move-object v0, p0

    move v1, p1

    move-object v2, p2

    move v7, p4

    move v8, p5

    move-object/from16 v9, p6

    invoke-virtual/range {v0 .. v9}, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->insertView(ILandroid/view/View;IIIIZILandroid/widget/FrameLayout$LayoutParams;)Z

    move-result v0

    goto :goto_0
.end method

.method public modifyViewIndex(IIZ)Z
    .locals 5
    .param p1, "s_index"    # I
    .param p2, "d_index"    # I
    .param p3, "bringtofront"    # Z

    .prologue
    const/4 v2, 0x1

    const/4 v3, 0x0

    .line 143
    if-ltz p1, :cond_0

    if-gez p2, :cond_2

    :cond_0
    move v2, v3

    .line 153
    :cond_1
    :goto_0
    return v2

    .line 144
    :cond_2
    if-eq p1, p2, :cond_1

    .line 145
    const/4 v1, 0x0

    .line 146
    .local v1, "sview":Landroid/view/View;
    const/4 v0, 0x0

    .line 147
    .local v0, "dview":Landroid/view/View;
    iget-object v4, p0, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->d:Landroid/widget/FrameLayout;

    invoke-virtual {v4, p2}, Landroid/widget/FrameLayout;->findViewById(I)Landroid/view/View;

    move-result-object v0

    .line 148
    if-eqz v0, :cond_3

    move v2, v3

    goto :goto_0

    .line 149
    :cond_3
    iget-object v4, p0, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->d:Landroid/widget/FrameLayout;

    invoke-virtual {v4, p1}, Landroid/widget/FrameLayout;->findViewById(I)Landroid/view/View;

    move-result-object v1

    .line 150
    if-nez v1, :cond_4

    move v2, v3

    goto :goto_0

    .line 151
    :cond_4
    invoke-virtual {v1, p2}, Landroid/view/View;->setId(I)V

    .line 152
    invoke-direct {p0, p3}, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->a(Z)V

    goto :goto_0
.end method

.method public moveView(IIIII)Z
    .locals 7
    .param p1, "index"    # I
    .param p2, "x"    # I
    .param p3, "y"    # I
    .param p4, "width"    # I
    .param p5, "height"    # I

    .prologue
    .line 157
    const/4 v6, 0x0

    move-object v0, p0

    move v1, p1

    move v2, p2

    move v3, p3

    move v4, p4

    move v5, p5

    invoke-virtual/range {v0 .. v6}, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->moveView(IIIIII)Z

    move-result v0

    return v0
.end method

.method public moveView(IIIIII)Z
    .locals 4
    .param p1, "index"    # I
    .param p2, "x"    # I
    .param p3, "y"    # I
    .param p4, "width"    # I
    .param p5, "height"    # I
    .param p6, "visibility"    # I

    .prologue
    const/4 v2, 0x0

    .line 161
    if-gez p1, :cond_1

    .line 174
    :cond_0
    :goto_0
    return v2

    .line 162
    :cond_1
    iget-object v3, p0, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->d:Landroid/widget/FrameLayout;

    invoke-virtual {v3, p1}, Landroid/widget/FrameLayout;->findViewById(I)Landroid/view/View;

    move-result-object v1

    .line 163
    .local v1, "view":Landroid/view/View;
    if-eqz v1, :cond_0

    .line 164
    invoke-virtual {v1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    check-cast v0, Landroid/widget/FrameLayout$LayoutParams;

    .line 165
    .local v0, "params":Landroid/widget/FrameLayout$LayoutParams;
    const/16 v3, 0x30

    iput v3, v0, Landroid/widget/FrameLayout$LayoutParams;->gravity:I

    .line 166
    iput p2, v0, Landroid/widget/FrameLayout$LayoutParams;->leftMargin:I

    .line 167
    iput p3, v0, Landroid/widget/FrameLayout$LayoutParams;->topMargin:I

    .line 168
    iput p4, v0, Landroid/widget/FrameLayout$LayoutParams;->width:I

    .line 169
    iput p5, v0, Landroid/widget/FrameLayout$LayoutParams;->height:I

    .line 170
    invoke-virtual {v1, p6}, Landroid/view/View;->setVisibility(I)V

    .line 171
    invoke-virtual {v1, v0}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 172
    iget-object v3, p0, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->d:Landroid/widget/FrameLayout;

    invoke-virtual {v3, v1, v0}, Landroid/widget/FrameLayout;->updateViewLayout(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 173
    invoke-direct {p0, v2}, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->a(Z)V

    .line 174
    const/4 v2, 0x1

    goto :goto_0
.end method

.method public moveView(ILandroid/graphics/Rect;)Z
    .locals 6
    .param p1, "index"    # I
    .param p2, "rc"    # Landroid/graphics/Rect;

    .prologue
    .line 178
    iget v2, p2, Landroid/graphics/Rect;->left:I

    iget v3, p2, Landroid/graphics/Rect;->top:I

    invoke-virtual {p2}, Landroid/graphics/Rect;->width()I

    move-result v4

    invoke-virtual {p2}, Landroid/graphics/Rect;->height()I

    move-result v5

    move-object v0, p0

    move v1, p1

    invoke-virtual/range {v0 .. v5}, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->moveView(IIIII)Z

    move-result v0

    return v0
.end method

.method public moveView(ILandroid/graphics/Rect;I)Z
    .locals 7
    .param p1, "index"    # I
    .param p2, "rc"    # Landroid/graphics/Rect;
    .param p3, "visibility"    # I

    .prologue
    .line 182
    iget v2, p2, Landroid/graphics/Rect;->left:I

    iget v3, p2, Landroid/graphics/Rect;->top:I

    invoke-virtual {p2}, Landroid/graphics/Rect;->width()I

    move-result v4

    invoke-virtual {p2}, Landroid/graphics/Rect;->height()I

    move-result v5

    move-object v0, p0

    move v1, p1

    move v6, p3

    invoke-virtual/range {v0 .. v6}, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->moveView(IIIIII)Z

    move-result v0

    return v0
.end method

.method public removeAllViews()V
    .locals 1

    .prologue
    .line 186
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->d:Landroid/widget/FrameLayout;

    invoke-virtual {v0}, Landroid/widget/FrameLayout;->removeAllViews()V

    .line 187
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->d:Landroid/widget/FrameLayout;

    invoke-virtual {v0}, Landroid/widget/FrameLayout;->invalidate()V

    .line 188
    return-void
.end method

.method public removeView(I)Z
    .locals 3
    .param p1, "index"    # I

    .prologue
    const/4 v1, 0x0

    .line 191
    if-gez p1, :cond_1

    .line 196
    :cond_0
    :goto_0
    return v1

    .line 192
    :cond_1
    iget-object v2, p0, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->d:Landroid/widget/FrameLayout;

    invoke-virtual {v2, p1}, Landroid/widget/FrameLayout;->findViewById(I)Landroid/view/View;

    move-result-object v0

    .line 193
    .local v0, "view":Landroid/view/View;
    if-eqz v0, :cond_0

    .line 194
    iget-object v2, p0, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->d:Landroid/widget/FrameLayout;

    invoke-virtual {v2, v0}, Landroid/widget/FrameLayout;->removeView(Landroid/view/View;)V

    .line 195
    invoke-direct {p0, v1}, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->a(Z)V

    .line 196
    const/4 v1, 0x1

    goto :goto_0
.end method

.method public setLayoutParams(Landroid/widget/FrameLayout$LayoutParams;)V
    .locals 1
    .param p1, "params"    # Landroid/widget/FrameLayout$LayoutParams;

    .prologue
    .line 65
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->d:Landroid/widget/FrameLayout;

    invoke-virtual {v0, p1}, Landroid/widget/FrameLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 66
    return-void
.end method

.method public setVisibility(II)Z
    .locals 3
    .param p1, "index"    # I
    .param p2, "visibility"    # I

    .prologue
    const/4 v1, 0x0

    .line 200
    if-gez p1, :cond_1

    .line 205
    :cond_0
    :goto_0
    return v1

    .line 201
    :cond_1
    iget-object v2, p0, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->d:Landroid/widget/FrameLayout;

    invoke-virtual {v2, p1}, Landroid/widget/FrameLayout;->findViewById(I)Landroid/view/View;

    move-result-object v0

    .line 202
    .local v0, "view":Landroid/view/View;
    if-eqz v0, :cond_0

    .line 203
    invoke-virtual {v0, p2}, Landroid/view/View;->setVisibility(I)V

    .line 204
    invoke-direct {p0, v1}, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->a(Z)V

    .line 205
    const/4 v1, 0x1

    goto :goto_0
.end method

.method public updateNScreen()V
    .locals 1

    .prologue
    .line 209
    const/4 v0, 0x1

    invoke-direct {p0, v0}, Lcom/thinkware/sundo/ieve/ieveNScreenManager;->a(Z)V

    .line 210
    return-void
.end method
