.class public Ltas/util/firmwaretools/FindNewFirmware;
.super Ljava/lang/Object;
.source "FindNewFirmware.java"


# static fields
.field private static final DEBUG:Z = false

.field private static final MULTISTAGE_AND_ZIP_TOKENS:Ljava/lang/String; = "-multistage.zip"

.field private static final TAG:Ljava/lang/String; = "FindNewFirmware"

.field private static final mFS:Ltas/util/firmwaretools/FindNewFirmware;


# instance fields
.field private mFWName:[Ljava/lang/String;

.field private mIsMultiStage:Z


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .prologue
    .line 11
    new-instance v0, Ltas/util/firmwaretools/FindNewFirmware;

    invoke-direct {v0}, Ltas/util/firmwaretools/FindNewFirmware;-><init>()V

    sput-object v0, Ltas/util/firmwaretools/FindNewFirmware;->mFS:Ltas/util/firmwaretools/FindNewFirmware;

    .line 14
    const-string/jumbo v0, "twfirmwareselector_jni"

    invoke-static {v0}, Ljava/lang/System;->loadLibrary(Ljava/lang/String;)V

    .line 3
    return-void
.end method

.method private constructor <init>()V
    .locals 4

    .prologue
    const/4 v3, 0x0

    const/4 v2, 0x0

    .line 17
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 8
    const/4 v0, 0x2

    new-array v0, v0, [Ljava/lang/String;

    aput-object v3, v0, v2

    const/4 v1, 0x1

    aput-object v3, v0, v1

    iput-object v0, p0, Ltas/util/firmwaretools/FindNewFirmware;->mFWName:[Ljava/lang/String;

    .line 9
    iput-boolean v2, p0, Ltas/util/firmwaretools/FindNewFirmware;->mIsMultiStage:Z

    .line 17
    return-void
.end method

.method private native doDentryWalk(Ljava/lang/String;)Ljava/lang/String;
.end method

.method private getFWInfo(Ljava/lang/String;)V
    .locals 9
    .param p1, "dpath"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ltas/util/firmwaretools/FindNewFirmwareException;
        }
    .end annotation

    .prologue
    const/4 v8, 0x1

    const/4 v7, 0x0

    .line 23
    invoke-direct {p0, p1}, Ltas/util/firmwaretools/FindNewFirmware;->doDentryWalk(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 24
    .local v0, "fwname":Ljava/lang/String;
    invoke-direct {p0}, Ltas/util/firmwaretools/FindNewFirmware;->is_multistage()I

    move-result v1

    .line 25
    .local v1, "isMultiStage":I
    iput-boolean v7, p0, Ltas/util/firmwaretools/FindNewFirmware;->mIsMultiStage:Z

    .line 27
    if-nez v0, :cond_0

    .line 28
    new-instance v4, Ltas/util/firmwaretools/FindNewFirmwareException;

    const-string/jumbo v5, "internal failure: no firmwares detected"

    invoke-direct {v4, v5}, Ltas/util/firmwaretools/FindNewFirmwareException;-><init>(Ljava/lang/String;)V

    throw v4

    .line 30
    :cond_0
    const/4 v4, -0x1

    if-ne v1, v4, :cond_1

    .line 31
    new-instance v4, Ltas/util/firmwaretools/FindNewFirmwareException;

    const-string/jumbo v5, "internal failure: an error with a multistage detection"

    invoke-direct {v4, v5}, Ltas/util/firmwaretools/FindNewFirmwareException;-><init>(Ljava/lang/String;)V

    throw v4

    .line 37
    :cond_1
    iget-object v4, p0, Ltas/util/firmwaretools/FindNewFirmware;->mFWName:[Ljava/lang/String;

    aput-object v0, v4, v7

    .line 39
    if-ne v1, v8, :cond_2

    .line 40
    const-string/jumbo v4, "-multistage.zip"

    invoke-virtual {v0, v4}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-eqz v4, :cond_4

    .line 51
    :cond_2
    :goto_0
    if-nez v1, :cond_3

    iput-boolean v7, p0, Ltas/util/firmwaretools/FindNewFirmware;->mIsMultiStage:Z

    .line 22
    :cond_3
    return-void

    .line 41
    :cond_4
    iput-boolean v8, p0, Ltas/util/firmwaretools/FindNewFirmware;->mIsMultiStage:Z

    .line 42
    new-instance v3, Ljava/lang/String;

    invoke-direct {v3, v0}, Ljava/lang/String;-><init>(Ljava/lang/String;)V

    .line 43
    .local v3, "tmp":Ljava/lang/String;
    invoke-virtual {v3}, Ljava/lang/String;->length()I

    move-result v4

    add-int/lit8 v2, v4, -0x4

    .line 45
    .local v2, "sz":I
    if-ge v2, v8, :cond_5

    .line 46
    new-instance v4, Ltas/util/firmwaretools/FindNewFirmwareException;

    const-string/jumbo v5, "internal failure: an error with a multistage processing"

    invoke-direct {v4, v5}, Ltas/util/firmwaretools/FindNewFirmwareException;-><init>(Ljava/lang/String;)V

    throw v4

    .line 48
    :cond_5
    iget-object v4, p0, Ltas/util/firmwaretools/FindNewFirmware;->mFWName:[Ljava/lang/String;

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v7, v2}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string/jumbo v6, "-multistage.zip"

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    aput-object v5, v4, v8

    goto :goto_0
.end method

.method public static getInstance()Ltas/util/firmwaretools/FindNewFirmware;
    .locals 1

    .prologue
    .line 57
    sget-object v0, Ltas/util/firmwaretools/FindNewFirmware;->mFS:Ltas/util/firmwaretools/FindNewFirmware;

    return-object v0
.end method

.method private native is_multistage()I
.end method


# virtual methods
.method public getFirmwareName(Ljava/lang/String;)[Ljava/lang/String;
    .locals 1
    .param p1, "dpath"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ltas/util/firmwaretools/FindNewFirmwareException;
        }
    .end annotation

    .prologue
    .line 61
    invoke-direct {p0, p1}, Ltas/util/firmwaretools/FindNewFirmware;->getFWInfo(Ljava/lang/String;)V

    .line 62
    iget-object v0, p0, Ltas/util/firmwaretools/FindNewFirmware;->mFWName:[Ljava/lang/String;

    return-object v0
.end method
