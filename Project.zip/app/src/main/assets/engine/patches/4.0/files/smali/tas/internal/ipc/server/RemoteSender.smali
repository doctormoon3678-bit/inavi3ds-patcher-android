.class public Ltas/internal/ipc/server/RemoteSender;
.super Ltas/internal/ipc/server/RemoteClient;
.source "RemoteSender.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ltas/internal/ipc/server/RemoteSender$1;,
        Ltas/internal/ipc/server/RemoteSender$2;
    }
.end annotation


# static fields
.field private static final CALLBACK:Ltas/internal/ipc/util/SyncdPool$Callback;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ltas/internal/ipc/util/SyncdPool$Callback",
            "<",
            "Ltas/internal/ipc/server/RemoteSender;",
            ">;"
        }
    .end annotation
.end field

.field public static final CREATOR:Landroid/os/Parcelable$Creator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/os/Parcelable$Creator",
            "<",
            "Ltas/internal/ipc/server/RemoteSender;",
            ">;"
        }
    .end annotation
.end field

.field private static final sPool:Ltas/internal/ipc/util/SyncdPool;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ltas/internal/ipc/util/SyncdPool",
            "<",
            "Ltas/internal/ipc/server/RemoteSender;",
            ">;"
        }
    .end annotation
.end field

.field private static sPoolId:I


# instance fields
.field private mAllocated:Z

.field private mPooled:Z

.field private next:Ltas/internal/ipc/server/RemoteSender;

.field private pool:I

.field public replier:Landroid/os/IBinder;


# direct methods
.method static synthetic -get0(Ltas/internal/ipc/server/RemoteSender;)Ltas/internal/ipc/server/RemoteSender;
    .locals 1

    iget-object v0, p0, Ltas/internal/ipc/server/RemoteSender;->next:Ltas/internal/ipc/server/RemoteSender;

    return-object v0
.end method

.method static synthetic -get1()I
    .locals 1

    sget v0, Ltas/internal/ipc/server/RemoteSender;->sPoolId:I

    return v0
.end method

.method static synthetic -set0(Ltas/internal/ipc/server/RemoteSender;Z)Z
    .locals 0

    iput-boolean p1, p0, Ltas/internal/ipc/server/RemoteSender;->mPooled:Z

    return p1
.end method

.method static synthetic -set1(Ltas/internal/ipc/server/RemoteSender;Ltas/internal/ipc/server/RemoteSender;)Ltas/internal/ipc/server/RemoteSender;
    .locals 0

    iput-object p1, p0, Ltas/internal/ipc/server/RemoteSender;->next:Ltas/internal/ipc/server/RemoteSender;

    return-object p1
.end method

.method static synthetic -set2(Ltas/internal/ipc/server/RemoteSender;I)I
    .locals 0

    iput p1, p0, Ltas/internal/ipc/server/RemoteSender;->pool:I

    return p1
.end method

.method static synthetic -set3(I)I
    .locals 0

    sput p0, Ltas/internal/ipc/server/RemoteSender;->sPoolId:I

    return p0
.end method

.method static constructor <clinit>()V
    .locals 2

    .prologue
    .line 36
    new-instance v0, Ltas/internal/ipc/server/RemoteSender$1;

    invoke-direct {v0}, Ltas/internal/ipc/server/RemoteSender$1;-><init>()V

    .line 35
    sput-object v0, Ltas/internal/ipc/server/RemoteSender;->CREATOR:Landroid/os/Parcelable$Creator;

    .line 70
    new-instance v0, Ltas/internal/ipc/server/RemoteSender$2;

    invoke-direct {v0}, Ltas/internal/ipc/server/RemoteSender$2;-><init>()V

    .line 69
    sput-object v0, Ltas/internal/ipc/server/RemoteSender;->CALLBACK:Ltas/internal/ipc/util/SyncdPool$Callback;

    .line 88
    new-instance v0, Ltas/internal/ipc/util/SyncdPool;

    sget-object v1, Ltas/internal/ipc/server/RemoteSender;->CALLBACK:Ltas/internal/ipc/util/SyncdPool$Callback;

    invoke-direct {v0, v1}, Ltas/internal/ipc/util/SyncdPool;-><init>(Ltas/internal/ipc/util/SyncdPool$Callback;)V

    .line 87
    sput-object v0, Ltas/internal/ipc/server/RemoteSender;->sPool:Ltas/internal/ipc/util/SyncdPool;

    .line 89
    const/4 v0, 0x0

    sput v0, Ltas/internal/ipc/server/RemoteSender;->sPoolId:I

    .line 16
    return-void
.end method

.method private constructor <init>()V
    .locals 0

    .prologue
    .line 19
    invoke-direct {p0}, Ltas/internal/ipc/server/RemoteClient;-><init>()V

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;)V
    .locals 0
    .param p1, "pkg"    # Ljava/lang/String;
    .param p2, "name"    # Ljava/lang/String;

    .prologue
    .line 17
    invoke-direct {p0, p1, p2}, Ltas/internal/ipc/server/RemoteClient;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method public constructor <init>(Ltas/internal/ipc/server/RemoteSender;)V
    .locals 0
    .param p1, "sender"    # Ltas/internal/ipc/server/RemoteSender;

    .prologue
    .line 18
    invoke-direct {p0, p1}, Ltas/internal/ipc/server/RemoteClient;-><init>(Ltas/internal/ipc/server/RemoteClient;)V

    return-void
.end method

.method synthetic constructor <init>(Ltas/internal/ipc/server/RemoteSender;Ltas/internal/ipc/server/RemoteSender;)V
    .locals 0

    .prologue
    invoke-direct {p0}, Ltas/internal/ipc/server/RemoteSender;-><init>()V

    return-void
.end method

.method public static createFromParcel(Landroid/os/Parcel;)Ltas/internal/ipc/server/RemoteSender;
    .locals 1
    .param p0, "source"    # Landroid/os/Parcel;

    .prologue
    .line 64
    invoke-static {}, Ltas/internal/ipc/server/RemoteSender;->obtain()Ltas/internal/ipc/server/RemoteSender;

    move-result-object v0

    .line 65
    .local v0, "s":Ltas/internal/ipc/server/RemoteSender;
    invoke-virtual {v0, p0}, Ltas/internal/ipc/server/RemoteSender;->readFromParcel(Landroid/os/Parcel;)V

    .line 66
    return-object v0
.end method

.method public static obtain()Ltas/internal/ipc/server/RemoteSender;
    .locals 2

    .prologue
    .line 50
    sget-object v1, Ltas/internal/ipc/server/RemoteSender;->sPool:Ltas/internal/ipc/util/SyncdPool;

    invoke-virtual {v1}, Ltas/internal/ipc/util/SyncdPool;->allocate()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/ipc/server/RemoteSender;

    .line 51
    .local v0, "s":Ltas/internal/ipc/server/RemoteSender;
    const/4 v1, 0x1

    iput-boolean v1, v0, Ltas/internal/ipc/server/RemoteSender;->mAllocated:Z

    .line 52
    return-object v0
.end method

.method public static obtain(Ltas/internal/ipc/server/RemoteSender;)Ltas/internal/ipc/server/RemoteSender;
    .locals 1
    .param p0, "that"    # Ltas/internal/ipc/server/RemoteSender;

    .prologue
    .line 56
    invoke-static {}, Ltas/internal/ipc/server/RemoteSender;->obtain()Ltas/internal/ipc/server/RemoteSender;

    move-result-object v0

    .line 57
    .local v0, "s":Ltas/internal/ipc/server/RemoteSender;
    invoke-virtual {v0, p0}, Ltas/internal/ipc/server/RemoteSender;->copyFrom(Ltas/internal/ipc/server/RemoteClient;)V

    .line 58
    return-object v0
.end method


# virtual methods
.method public copyFrom(Ltas/internal/ipc/server/RemoteClient;)V
    .locals 4
    .param p1, "c"    # Ltas/internal/ipc/server/RemoteClient;

    .prologue
    .line 25
    instance-of v1, p1, Ltas/internal/ipc/server/RemoteSender;

    if-nez v1, :cond_0

    .line 26
    new-instance v1, Ljava/lang/IllegalArgumentException;

    .line 27
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "copyFrom: "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {p1}, Ltas/internal/ipc/server/RemoteClient;->getClass()Ljava/lang/Class;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    .line 26
    invoke-direct {v1, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v1

    .line 29
    :cond_0
    invoke-super {p0, p1}, Ltas/internal/ipc/server/RemoteClient;->copyFrom(Ltas/internal/ipc/server/RemoteClient;)V

    move-object v0, p1

    .line 31
    check-cast v0, Ltas/internal/ipc/server/RemoteSender;

    .line 32
    .local v0, "s":Ltas/internal/ipc/server/RemoteSender;
    iget-object v1, v0, Ltas/internal/ipc/server/RemoteSender;->replier:Landroid/os/IBinder;

    iput-object v1, p0, Ltas/internal/ipc/server/RemoteSender;->replier:Landroid/os/IBinder;

    .line 24
    return-void
.end method

.method public readFromParcel(Landroid/os/Parcel;)V
    .locals 2
    .param p1, "source"    # Landroid/os/Parcel;

    .prologue
    .line 122
    invoke-super {p0, p1}, Ltas/internal/ipc/server/RemoteClient;->readFromParcel(Landroid/os/Parcel;)V

    .line 123
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    const/4 v1, 0x1

    if-ne v0, v1, :cond_0

    .line 124
    invoke-virtual {p1}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v0

    iput-object v0, p0, Ltas/internal/ipc/server/RemoteSender;->replier:Landroid/os/IBinder;

    .line 121
    :cond_0
    return-void
.end method

.method public recycle()V
    .locals 2

    .prologue
    const/4 v1, 0x0

    .line 98
    iget-boolean v0, p0, Ltas/internal/ipc/server/RemoteSender;->mPooled:Z

    if-eqz v0, :cond_0

    iget-boolean v0, p0, Ltas/internal/ipc/server/RemoteSender;->mAllocated:Z

    if-eqz v0, :cond_0

    .line 99
    const/4 v0, 0x0

    iput-boolean v0, p0, Ltas/internal/ipc/server/RemoteSender;->mAllocated:Z

    .line 100
    iput-object v1, p0, Ltas/internal/ipc/server/RemoteSender;->pkg:Ljava/lang/String;

    .line 101
    iput-object v1, p0, Ltas/internal/ipc/server/RemoteSender;->name:Ljava/lang/String;

    .line 102
    iput-object v1, p0, Ltas/internal/ipc/server/RemoteSender;->extra:Landroid/os/Bundle;

    .line 103
    iput-object v1, p0, Ltas/internal/ipc/server/RemoteSender;->replier:Landroid/os/IBinder;

    .line 104
    sget-object v0, Ltas/internal/ipc/server/RemoteSender;->sPool:Ltas/internal/ipc/util/SyncdPool;

    invoke-virtual {v0, p0}, Ltas/internal/ipc/util/SyncdPool;->recycle(Ljava/lang/Object;)V

    .line 95
    :cond_0
    return-void
.end method

.method public toString()Ljava/lang/String;
    .locals 2

    .prologue
    .line 130
    iget-boolean v0, p0, Ltas/internal/ipc/server/RemoteSender;->mPooled:Z

    if-eqz v0, :cond_0

    .line 131
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0, v0}, Ltas/internal/ipc/server/RemoteSender;->buildString(Ljava/lang/StringBuilder;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 132
    const-string/jumbo v1, " "

    .line 131
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 132
    iget v1, p0, Ltas/internal/ipc/server/RemoteSender;->pool:I

    .line 131
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0

    .line 135
    :cond_0
    invoke-super {p0}, Ltas/internal/ipc/server/RemoteClient;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public writeToParcel(Landroid/os/Parcel;I)V
    .locals 2
    .param p1, "dest"    # Landroid/os/Parcel;
    .param p2, "flags"    # I

    .prologue
    const/4 v1, 0x0

    .line 110
    invoke-super {p0, p1, p2}, Ltas/internal/ipc/server/RemoteClient;->writeToParcel(Landroid/os/Parcel;I)V

    .line 111
    iget-object v0, p0, Ltas/internal/ipc/server/RemoteSender;->replier:Landroid/os/IBinder;

    if-eqz v0, :cond_0

    .line 112
    const/4 v0, 0x1

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->writeInt(I)V

    .line 113
    iget-object v0, p0, Ltas/internal/ipc/server/RemoteSender;->replier:Landroid/os/IBinder;

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->writeStrongBinder(Landroid/os/IBinder;)V

    .line 117
    :goto_0
    iput-object v1, p0, Ltas/internal/ipc/server/RemoteSender;->replier:Landroid/os/IBinder;

    .line 109
    return-void

    .line 115
    :cond_0
    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->writeInt(I)V

    goto :goto_0
.end method
