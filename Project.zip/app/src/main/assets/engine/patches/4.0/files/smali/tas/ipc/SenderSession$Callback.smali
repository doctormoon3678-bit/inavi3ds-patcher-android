.class public interface abstract Ltas/ipc/SenderSession$Callback;
.super Ljava/lang/Object;
.source "SenderSession.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltas/ipc/SenderSession;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "Callback"
.end annotation


# virtual methods
.method public abstract onReceiverOffline(Ltas/ipc/SenderSession;)V
.end method

.method public abstract onReceiverOnline(Ltas/ipc/SenderSession;)V
.end method

.method public abstract onReceiverUpdate(Ltas/ipc/SenderSession;Landroid/os/Bundle;)V
.end method

.method public abstract onReply(Ltas/ipc/SenderSession;ILtas/ipc/MsgData;)V
.end method
