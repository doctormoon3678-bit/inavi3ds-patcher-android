.class public abstract Ltas/internal/ipc/server/IServerService$Stub;
.super Landroid/os/Binder;
.source "IServerService.java"

# interfaces
.implements Ltas/internal/ipc/server/IServerService;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltas/internal/ipc/server/IServerService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "Stub"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ltas/internal/ipc/server/IServerService$Stub$Proxy;
    }
.end annotation


# static fields
.field private static final DESCRIPTOR:Ljava/lang/String; = "tas.internal.ipc.server.IServerService"

.field static final TRANSACTION_registerReceiver:I = 0x1

.field static final TRANSACTION_registerSender:I = 0x4

.field static final TRANSACTION_setCallback:I = 0xf

.field static final TRANSACTION_transmit:I = 0x10

.field static final TRANSACTION_unregisterReceiver:I = 0x2

.field static final TRANSACTION_unregisterSender:I = 0x5

.field static final TRANSACTION_unwatchAnonymousReceiver:I = 0xa

.field static final TRANSACTION_unwatchAnonymousSender:I = 0xe

.field static final TRANSACTION_unwatchReceiver:I = 0x8

.field static final TRANSACTION_unwatchSender:I = 0xc

.field static final TRANSACTION_updateReceiver:I = 0x3

.field static final TRANSACTION_updateSender:I = 0x6

.field static final TRANSACTION_watchAnonymousReceiver:I = 0x9

.field static final TRANSACTION_watchAnonymousSender:I = 0xd

.field static final TRANSACTION_watchReceiver:I = 0x7

.field static final TRANSACTION_watchSender:I = 0xb


# direct methods
.method public constructor <init>()V
    .locals 1

    .prologue
    .line 13
    invoke-direct {p0}, Landroid/os/Binder;-><init>()V

    .line 15
    const-string/jumbo v0, "tas.internal.ipc.server.IServerService"

    invoke-virtual {p0, p0, v0}, Ltas/internal/ipc/server/IServerService$Stub;->attachInterface(Landroid/os/IInterface;Ljava/lang/String;)V

    .line 13
    return-void
.end method

.method public static asInterface(Landroid/os/IBinder;)Ltas/internal/ipc/server/IServerService;
    .locals 2
    .param p0, "obj"    # Landroid/os/IBinder;

    .prologue
    const/4 v1, 0x0

    .line 23
    if-nez p0, :cond_0

    .line 24
    return-object v1

    .line 26
    :cond_0
    const-string/jumbo v1, "tas.internal.ipc.server.IServerService"

    invoke-interface {p0, v1}, Landroid/os/IBinder;->queryLocalInterface(Ljava/lang/String;)Landroid/os/IInterface;

    move-result-object v0

    .line 27
    .local v0, "iin":Landroid/os/IInterface;
    if-eqz v0, :cond_1

    instance-of v1, v0, Ltas/internal/ipc/server/IServerService;

    if-eqz v1, :cond_1

    .line 28
    check-cast v0, Ltas/internal/ipc/server/IServerService;

    .end local v0    # "iin":Landroid/os/IInterface;
    return-object v0

    .line 30
    .restart local v0    # "iin":Landroid/os/IInterface;
    :cond_1
    new-instance v1, Ltas/internal/ipc/server/IServerService$Stub$Proxy;

    invoke-direct {v1, p0}, Ltas/internal/ipc/server/IServerService$Stub$Proxy;-><init>(Landroid/os/IBinder;)V

    return-object v1
.end method


# virtual methods
.method public asBinder()Landroid/os/IBinder;
    .locals 0

    .prologue
    .line 34
    return-object p0
.end method

.method public onTransact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    .locals 6
    .param p1, "code"    # I
    .param p2, "data"    # Landroid/os/Parcel;
    .param p3, "reply"    # Landroid/os/Parcel;
    .param p4, "flags"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .prologue
    const/4 v5, 0x1

    .line 38
    sparse-switch p1, :sswitch_data_0

    .line 265
    invoke-super {p0, p1, p2, p3, p4}, Landroid/os/Binder;->onTransact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z

    move-result v4

    return v4

    .line 42
    :sswitch_0
    const-string/jumbo v4, "tas.internal.ipc.server.IServerService"

    invoke-virtual {p3, v4}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    .line 43
    return v5

    .line 47
    :sswitch_1
    const-string/jumbo v4, "tas.internal.ipc.server.IServerService"

    invoke-virtual {p2, v4}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 49
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v4

    if-eqz v4, :cond_0

    .line 50
    sget-object v4, Ltas/internal/ipc/server/RemoteReceiver;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-interface {v4, p2}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ltas/internal/ipc/server/RemoteReceiver;

    .line 55
    :goto_0
    invoke-virtual {p0, v2}, Ltas/internal/ipc/server/IServerService$Stub;->registerReceiver(Ltas/internal/ipc/server/RemoteReceiver;)V

    .line 56
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 57
    return v5

    .line 53
    :cond_0
    const/4 v2, 0x0

    .local v2, "_arg0":Ltas/internal/ipc/server/RemoteReceiver;
    goto :goto_0

    .line 61
    .end local v2    # "_arg0":Ltas/internal/ipc/server/RemoteReceiver;
    :sswitch_2
    const-string/jumbo v4, "tas.internal.ipc.server.IServerService"

    invoke-virtual {p2, v4}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 63
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v4

    if-eqz v4, :cond_1

    .line 64
    sget-object v4, Ltas/internal/ipc/server/RemoteReceiver;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-interface {v4, p2}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ltas/internal/ipc/server/RemoteReceiver;

    .line 69
    :goto_1
    invoke-virtual {p0, v2}, Ltas/internal/ipc/server/IServerService$Stub;->unregisterReceiver(Ltas/internal/ipc/server/RemoteReceiver;)V

    .line 70
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 71
    return v5

    .line 67
    :cond_1
    const/4 v2, 0x0

    .restart local v2    # "_arg0":Ltas/internal/ipc/server/RemoteReceiver;
    goto :goto_1

    .line 75
    .end local v2    # "_arg0":Ltas/internal/ipc/server/RemoteReceiver;
    :sswitch_3
    const-string/jumbo v4, "tas.internal.ipc.server.IServerService"

    invoke-virtual {p2, v4}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 77
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v4

    if-eqz v4, :cond_2

    .line 78
    sget-object v4, Ltas/internal/ipc/server/RemoteReceiver;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-interface {v4, p2}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ltas/internal/ipc/server/RemoteReceiver;

    .line 83
    :goto_2
    invoke-virtual {p0, v2}, Ltas/internal/ipc/server/IServerService$Stub;->updateReceiver(Ltas/internal/ipc/server/RemoteReceiver;)V

    .line 84
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 85
    return v5

    .line 81
    :cond_2
    const/4 v2, 0x0

    .restart local v2    # "_arg0":Ltas/internal/ipc/server/RemoteReceiver;
    goto :goto_2

    .line 89
    .end local v2    # "_arg0":Ltas/internal/ipc/server/RemoteReceiver;
    :sswitch_4
    const-string/jumbo v4, "tas.internal.ipc.server.IServerService"

    invoke-virtual {p2, v4}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 91
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v4

    if-eqz v4, :cond_3

    .line 92
    sget-object v4, Ltas/internal/ipc/server/RemoteSender;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-interface {v4, p2}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ltas/internal/ipc/server/RemoteSender;

    .line 97
    :goto_3
    invoke-virtual {p0, v3}, Ltas/internal/ipc/server/IServerService$Stub;->registerSender(Ltas/internal/ipc/server/RemoteSender;)V

    .line 98
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 99
    return v5

    .line 95
    :cond_3
    const/4 v3, 0x0

    .local v3, "_arg0":Ltas/internal/ipc/server/RemoteSender;
    goto :goto_3

    .line 103
    .end local v3    # "_arg0":Ltas/internal/ipc/server/RemoteSender;
    :sswitch_5
    const-string/jumbo v4, "tas.internal.ipc.server.IServerService"

    invoke-virtual {p2, v4}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 105
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v4

    if-eqz v4, :cond_4

    .line 106
    sget-object v4, Ltas/internal/ipc/server/RemoteSender;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-interface {v4, p2}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ltas/internal/ipc/server/RemoteSender;

    .line 111
    :goto_4
    invoke-virtual {p0, v3}, Ltas/internal/ipc/server/IServerService$Stub;->unregisterSender(Ltas/internal/ipc/server/RemoteSender;)V

    .line 112
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 113
    return v5

    .line 109
    :cond_4
    const/4 v3, 0x0

    .restart local v3    # "_arg0":Ltas/internal/ipc/server/RemoteSender;
    goto :goto_4

    .line 117
    .end local v3    # "_arg0":Ltas/internal/ipc/server/RemoteSender;
    :sswitch_6
    const-string/jumbo v4, "tas.internal.ipc.server.IServerService"

    invoke-virtual {p2, v4}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 119
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v4

    if-eqz v4, :cond_5

    .line 120
    sget-object v4, Ltas/internal/ipc/server/RemoteSender;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-interface {v4, p2}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ltas/internal/ipc/server/RemoteSender;

    .line 125
    :goto_5
    invoke-virtual {p0, v3}, Ltas/internal/ipc/server/IServerService$Stub;->updateSender(Ltas/internal/ipc/server/RemoteSender;)V

    .line 126
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 127
    return v5

    .line 123
    :cond_5
    const/4 v3, 0x0

    .restart local v3    # "_arg0":Ltas/internal/ipc/server/RemoteSender;
    goto :goto_5

    .line 131
    .end local v3    # "_arg0":Ltas/internal/ipc/server/RemoteSender;
    :sswitch_7
    const-string/jumbo v4, "tas.internal.ipc.server.IServerService"

    invoke-virtual {p2, v4}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 133
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v4

    if-eqz v4, :cond_6

    .line 134
    sget-object v4, Ltas/internal/ipc/server/RemoteSender;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-interface {v4, p2}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ltas/internal/ipc/server/RemoteSender;

    .line 139
    :goto_6
    invoke-virtual {p0, v3}, Ltas/internal/ipc/server/IServerService$Stub;->watchReceiver(Ltas/internal/ipc/server/RemoteSender;)V

    .line 140
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 141
    return v5

    .line 137
    :cond_6
    const/4 v3, 0x0

    .restart local v3    # "_arg0":Ltas/internal/ipc/server/RemoteSender;
    goto :goto_6

    .line 145
    .end local v3    # "_arg0":Ltas/internal/ipc/server/RemoteSender;
    :sswitch_8
    const-string/jumbo v4, "tas.internal.ipc.server.IServerService"

    invoke-virtual {p2, v4}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 147
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v4

    if-eqz v4, :cond_7

    .line 148
    sget-object v4, Ltas/internal/ipc/server/RemoteSender;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-interface {v4, p2}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ltas/internal/ipc/server/RemoteSender;

    .line 153
    :goto_7
    invoke-virtual {p0, v3}, Ltas/internal/ipc/server/IServerService$Stub;->unwatchReceiver(Ltas/internal/ipc/server/RemoteSender;)V

    .line 154
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 155
    return v5

    .line 151
    :cond_7
    const/4 v3, 0x0

    .restart local v3    # "_arg0":Ltas/internal/ipc/server/RemoteSender;
    goto :goto_7

    .line 159
    .end local v3    # "_arg0":Ltas/internal/ipc/server/RemoteSender;
    :sswitch_9
    const-string/jumbo v4, "tas.internal.ipc.server.IServerService"

    invoke-virtual {p2, v4}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 161
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v4

    if-eqz v4, :cond_8

    .line 162
    sget-object v4, Ltas/internal/ipc/server/RemoteSender;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-interface {v4, p2}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ltas/internal/ipc/server/RemoteSender;

    .line 167
    :goto_8
    invoke-virtual {p0, v3}, Ltas/internal/ipc/server/IServerService$Stub;->watchAnonymousReceiver(Ltas/internal/ipc/server/RemoteSender;)V

    .line 168
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 169
    return v5

    .line 165
    :cond_8
    const/4 v3, 0x0

    .restart local v3    # "_arg0":Ltas/internal/ipc/server/RemoteSender;
    goto :goto_8

    .line 173
    .end local v3    # "_arg0":Ltas/internal/ipc/server/RemoteSender;
    :sswitch_a
    const-string/jumbo v4, "tas.internal.ipc.server.IServerService"

    invoke-virtual {p2, v4}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 175
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v4

    if-eqz v4, :cond_9

    .line 176
    sget-object v4, Ltas/internal/ipc/server/RemoteSender;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-interface {v4, p2}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ltas/internal/ipc/server/RemoteSender;

    .line 181
    :goto_9
    invoke-virtual {p0, v3}, Ltas/internal/ipc/server/IServerService$Stub;->unwatchAnonymousReceiver(Ltas/internal/ipc/server/RemoteSender;)V

    .line 182
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 183
    return v5

    .line 179
    :cond_9
    const/4 v3, 0x0

    .restart local v3    # "_arg0":Ltas/internal/ipc/server/RemoteSender;
    goto :goto_9

    .line 187
    .end local v3    # "_arg0":Ltas/internal/ipc/server/RemoteSender;
    :sswitch_b
    const-string/jumbo v4, "tas.internal.ipc.server.IServerService"

    invoke-virtual {p2, v4}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 189
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v4

    if-eqz v4, :cond_a

    .line 190
    sget-object v4, Ltas/internal/ipc/server/RemoteReceiver;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-interface {v4, p2}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ltas/internal/ipc/server/RemoteReceiver;

    .line 195
    :goto_a
    invoke-virtual {p0, v2}, Ltas/internal/ipc/server/IServerService$Stub;->watchSender(Ltas/internal/ipc/server/RemoteReceiver;)V

    .line 196
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 197
    return v5

    .line 193
    :cond_a
    const/4 v2, 0x0

    .restart local v2    # "_arg0":Ltas/internal/ipc/server/RemoteReceiver;
    goto :goto_a

    .line 201
    .end local v2    # "_arg0":Ltas/internal/ipc/server/RemoteReceiver;
    :sswitch_c
    const-string/jumbo v4, "tas.internal.ipc.server.IServerService"

    invoke-virtual {p2, v4}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 203
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v4

    if-eqz v4, :cond_b

    .line 204
    sget-object v4, Ltas/internal/ipc/server/RemoteReceiver;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-interface {v4, p2}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ltas/internal/ipc/server/RemoteReceiver;

    .line 209
    :goto_b
    invoke-virtual {p0, v2}, Ltas/internal/ipc/server/IServerService$Stub;->unwatchSender(Ltas/internal/ipc/server/RemoteReceiver;)V

    .line 210
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 211
    return v5

    .line 207
    :cond_b
    const/4 v2, 0x0

    .restart local v2    # "_arg0":Ltas/internal/ipc/server/RemoteReceiver;
    goto :goto_b

    .line 215
    .end local v2    # "_arg0":Ltas/internal/ipc/server/RemoteReceiver;
    :sswitch_d
    const-string/jumbo v4, "tas.internal.ipc.server.IServerService"

    invoke-virtual {p2, v4}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 217
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v4

    if-eqz v4, :cond_c

    .line 218
    sget-object v4, Ltas/internal/ipc/server/RemoteReceiver;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-interface {v4, p2}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ltas/internal/ipc/server/RemoteReceiver;

    .line 223
    :goto_c
    invoke-virtual {p0, v2}, Ltas/internal/ipc/server/IServerService$Stub;->watchAnonymousSender(Ltas/internal/ipc/server/RemoteReceiver;)V

    .line 224
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 225
    return v5

    .line 221
    :cond_c
    const/4 v2, 0x0

    .restart local v2    # "_arg0":Ltas/internal/ipc/server/RemoteReceiver;
    goto :goto_c

    .line 229
    .end local v2    # "_arg0":Ltas/internal/ipc/server/RemoteReceiver;
    :sswitch_e
    const-string/jumbo v4, "tas.internal.ipc.server.IServerService"

    invoke-virtual {p2, v4}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 231
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v4

    if-eqz v4, :cond_d

    .line 232
    sget-object v4, Ltas/internal/ipc/server/RemoteReceiver;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-interface {v4, p2}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ltas/internal/ipc/server/RemoteReceiver;

    .line 237
    :goto_d
    invoke-virtual {p0, v2}, Ltas/internal/ipc/server/IServerService$Stub;->unwatchAnonymousSender(Ltas/internal/ipc/server/RemoteReceiver;)V

    .line 238
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 239
    return v5

    .line 235
    :cond_d
    const/4 v2, 0x0

    .restart local v2    # "_arg0":Ltas/internal/ipc/server/RemoteReceiver;
    goto :goto_d

    .line 243
    .end local v2    # "_arg0":Ltas/internal/ipc/server/RemoteReceiver;
    :sswitch_f
    const-string/jumbo v4, "tas.internal.ipc.server.IServerService"

    invoke-virtual {p2, v4}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 245
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v4

    invoke-static {v4}, Ltas/internal/ipc/server/IServerCallback$Stub;->asInterface(Landroid/os/IBinder;)Ltas/internal/ipc/server/IServerCallback;

    move-result-object v0

    .line 246
    .local v0, "_arg0":Ltas/internal/ipc/server/IServerCallback;
    invoke-virtual {p0, v0}, Ltas/internal/ipc/server/IServerService$Stub;->setCallback(Ltas/internal/ipc/server/IServerCallback;)V

    .line 247
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 248
    return v5

    .line 252
    .end local v0    # "_arg0":Ltas/internal/ipc/server/IServerCallback;
    :sswitch_10
    const-string/jumbo v4, "tas.internal.ipc.server.IServerService"

    invoke-virtual {p2, v4}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 254
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v4

    if-eqz v4, :cond_e

    .line 255
    sget-object v4, Ltas/internal/ipc/server/RemoteMessage;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-interface {v4, p2}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ltas/internal/ipc/server/RemoteMessage;

    .line 260
    :goto_e
    invoke-virtual {p0, v1}, Ltas/internal/ipc/server/IServerService$Stub;->transmit(Ltas/internal/ipc/server/RemoteMessage;)V

    .line 261
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 262
    return v5

    .line 258
    :cond_e
    const/4 v1, 0x0

    .local v1, "_arg0":Ltas/internal/ipc/server/RemoteMessage;
    goto :goto_e

    .line 38
    :sswitch_data_0
    .sparse-switch
        0x1 -> :sswitch_1
        0x2 -> :sswitch_2
        0x3 -> :sswitch_3
        0x4 -> :sswitch_4
        0x5 -> :sswitch_5
        0x6 -> :sswitch_6
        0x7 -> :sswitch_7
        0x8 -> :sswitch_8
        0x9 -> :sswitch_9
        0xa -> :sswitch_a
        0xb -> :sswitch_b
        0xc -> :sswitch_c
        0xd -> :sswitch_d
        0xe -> :sswitch_e
        0xf -> :sswitch_f
        0x10 -> :sswitch_10
        0x5f4e5446 -> :sswitch_0
    .end sparse-switch
.end method
