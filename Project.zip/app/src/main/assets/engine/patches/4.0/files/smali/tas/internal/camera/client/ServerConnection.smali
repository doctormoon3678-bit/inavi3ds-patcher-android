.class Ltas/internal/camera/client/ServerConnection;
.super Ltas/internal/ipc/util/ServiceConnectionAbstract;
.source "ServerConnection.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ltas/internal/camera/client/ServerConnection$ServerCallback;,
        Ltas/internal/camera/client/ServerConnection$Holder;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ltas/internal/ipc/util/ServiceConnectionAbstract",
        "<",
        "Ltas/internal/camera/server/IServerService;",
        ">;"
    }
.end annotation


# static fields
.field private static final DBG:Z = true

.field private static final MSG_CANCEL_CAMERA:I = 0x68

.field private static final MSG_COMMAND_CAMERA:I = 0x69

.field private static final MSG_REQUEST_CAMERA:I = 0x67

.field private static final MSG_UNWATCH_CAMERA:I = 0x66

.field private static final MSG_WATCH_CAMERA:I = 0x65

.field private static final TAG:Ljava/lang/String; = "TasCAM<ServerConnection>"

.field private static final sServer:Ltas/internal/camera/client/ServerConnection;


# instance fields
.field private final mCallback:Ltas/internal/camera/client/ServerConnection$ServerCallback;

.field private final mClients:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List",
            "<",
            "Ltas/internal/camera/client/CameraProxy;",
            ">;"
        }
    .end annotation
.end field

.field private final mRefs:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map",
            "<",
            "Ljava/lang/String;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static synthetic -wrap0(Ltas/internal/camera/client/ServerConnection;Ltas/internal/camera/InputParams;)V
    .locals 0
    .param p1, "params"    # Ltas/internal/camera/InputParams;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/camera/client/ServerConnection;->onCableState(Ltas/internal/camera/InputParams;)V

    return-void
.end method

.method static synthetic -wrap1(Ltas/internal/camera/client/ServerConnection;Ltas/internal/camera/InputParams;)V
    .locals 0
    .param p1, "params"    # Ltas/internal/camera/InputParams;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/camera/client/ServerConnection;->onCameraMessage(Ltas/internal/camera/InputParams;)V

    return-void
.end method

.method static synthetic -wrap2(Ltas/internal/camera/client/ServerConnection;Ltas/internal/camera/InputParams;)V
    .locals 0
    .param p1, "params"    # Ltas/internal/camera/InputParams;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/camera/client/ServerConnection;->onCameraState(Ltas/internal/camera/InputParams;)V

    return-void
.end method

.method static synthetic -wrap3(Ltas/internal/camera/client/ServerConnection;Ltas/internal/camera/InputParams;)V
    .locals 0
    .param p1, "params"    # Ltas/internal/camera/InputParams;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/camera/client/ServerConnection;->onExtraState(Ltas/internal/camera/InputParams;)V

    return-void
.end method

.method static synthetic -wrap4(Ltas/internal/camera/client/ServerConnection;Ltas/internal/camera/InputParams;)V
    .locals 0
    .param p1, "params"    # Ltas/internal/camera/InputParams;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/camera/client/ServerConnection;->onInitialState(Ltas/internal/camera/InputParams;)V

    return-void
.end method

.method static synthetic -wrap5(Ltas/internal/camera/client/ServerConnection;Ltas/internal/camera/InputParams;)V
    .locals 0
    .param p1, "params"    # Ltas/internal/camera/InputParams;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/camera/client/ServerConnection;->onMediaServerState(Ltas/internal/camera/InputParams;)V

    return-void
.end method

.method static constructor <clinit>()V
    .locals 1

    .prologue
    .line 409
    new-instance v0, Ltas/internal/camera/client/ServerConnection;

    invoke-direct {v0}, Ltas/internal/camera/client/ServerConnection;-><init>()V

    sput-object v0, Ltas/internal/camera/client/ServerConnection;->sServer:Ltas/internal/camera/client/ServerConnection;

    .line 31
    return-void
.end method

.method private constructor <init>()V
    .locals 2

    .prologue
    .line 412
    const-string/jumbo v0, "CAM SERVER"

    invoke-direct {p0, v0}, Ltas/internal/ipc/util/ServiceConnectionAbstract;-><init>(Ljava/lang/String;)V

    .line 36
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Ltas/internal/camera/client/ServerConnection;->mClients:Ljava/util/List;

    .line 37
    new-instance v0, Landroid/util/ArrayMap;

    invoke-direct {v0}, Landroid/util/ArrayMap;-><init>()V

    iput-object v0, p0, Ltas/internal/camera/client/ServerConnection;->mRefs:Ljava/util/Map;

    .line 413
    new-instance v0, Ltas/internal/camera/client/ServerConnection$ServerCallback;

    const/4 v1, 0x0

    invoke-direct {v0, p0, v1}, Ltas/internal/camera/client/ServerConnection$ServerCallback;-><init>(Ltas/internal/camera/client/ServerConnection;Ltas/internal/camera/client/ServerConnection$ServerCallback;)V

    iput-object v0, p0, Ltas/internal/camera/client/ServerConnection;->mCallback:Ltas/internal/camera/client/ServerConnection$ServerCallback;

    .line 411
    return-void
.end method

.method public static get()Ltas/internal/camera/client/ServerConnection;
    .locals 1

    .prologue
    .line 41
    sget-object v0, Ltas/internal/camera/client/ServerConnection;->sServer:Ltas/internal/camera/client/ServerConnection;

    return-object v0
.end method

.method private onCableState(Ltas/internal/camera/InputParams;)V
    .locals 6
    .param p1, "params"    # Ltas/internal/camera/InputParams;

    .prologue
    const/4 v3, 0x1

    .line 344
    iget-object v2, p1, Ltas/internal/camera/InputParams;->cam:Ljava/lang/String;

    if-nez v2, :cond_0

    return-void

    .line 346
    :cond_0
    const-string/jumbo v2, "TasCAM<ServerConnection>"

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v5, "onCableState - "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v2, v4}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 348
    iget-object v2, p0, Ltas/internal/camera/client/ServerConnection;->mClients:Ljava/util/List;

    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    .local v1, "c$iterator":Ljava/util/Iterator;
    :cond_1
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_3

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/camera/client/CameraProxy;

    .line 349
    .local v0, "c":Ltas/internal/camera/client/CameraProxy;
    iget-object v2, p1, Ltas/internal/camera/InputParams;->cam:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ltas/internal/camera/client/CameraProxy;->isCamera(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1

    .line 350
    iget-object v2, p1, Ltas/internal/camera/InputParams;->msg:Ltas/camera/CameraMessage;

    iget v2, v2, Ltas/camera/CameraMessage;->arg1:I

    if-ne v2, v3, :cond_2

    move v2, v3

    :goto_1
    invoke-virtual {v0, v2}, Ltas/internal/camera/client/CameraProxy;->dispatchCableState(Z)V

    goto :goto_0

    :cond_2
    const/4 v2, 0x0

    goto :goto_1

    .line 343
    .end local v0    # "c":Ltas/internal/camera/client/CameraProxy;
    :cond_3
    return-void
.end method

.method private onCameraMessage(Ltas/internal/camera/InputParams;)V
    .locals 6
    .param p1, "params"    # Ltas/internal/camera/InputParams;

    .prologue
    const/4 v5, 0x0

    .line 368
    iget-object v2, p1, Ltas/internal/camera/InputParams;->cam:Ljava/lang/String;

    if-nez v2, :cond_0

    return-void

    .line 370
    :cond_0
    const-string/jumbo v2, "TasCAM<ServerConnection>"

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v4, "onCameraMessage - "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 372
    iget-object v2, p0, Ltas/internal/camera/client/ServerConnection;->mClients:Ljava/util/List;

    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    .local v1, "c$iterator":Ljava/util/Iterator;
    :cond_1
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_2

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/camera/client/CameraProxy;

    .line 373
    .local v0, "c":Ltas/internal/camera/client/CameraProxy;
    iget-object v2, p1, Ltas/internal/camera/InputParams;->cam:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ltas/internal/camera/client/CameraProxy;->isCamera(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1

    .line 374
    iget-object v2, p1, Ltas/internal/camera/InputParams;->msg:Ltas/camera/CameraMessage;

    invoke-static {v5, v2}, Ltas/internal/camera/client/ServerConnection$Holder;->obtain(Ltas/internal/camera/client/CameraProxy;Ltas/camera/CameraMessage;)Ltas/internal/camera/client/ServerConnection$Holder;

    move-result-object v2

    invoke-virtual {v0, v2}, Ltas/internal/camera/client/CameraProxy;->dispatchCameraMessage(Ltas/internal/camera/client/ServerConnection$Holder;)V

    goto :goto_0

    .line 367
    .end local v0    # "c":Ltas/internal/camera/client/CameraProxy;
    :cond_2
    return-void
.end method

.method private onCameraServerError(I)V
    .locals 5
    .param p1, "err"    # I

    .prologue
    .line 402
    const-string/jumbo v2, "TasCAM<ServerConnection>"

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v4, "onCameraServerError - "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 404
    iget-object v2, p0, Ltas/internal/camera/client/ServerConnection;->mClients:Ljava/util/List;

    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    .local v1, "c$iterator":Ljava/util/Iterator;
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_0

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/camera/client/CameraProxy;

    .line 405
    .local v0, "c":Ltas/internal/camera/client/CameraProxy;
    const/4 v2, 0x0

    invoke-virtual {v0, p1, v2}, Ltas/internal/camera/client/CameraProxy;->dispatchExtraState(II)V

    goto :goto_0

    .line 400
    .end local v0    # "c":Ltas/internal/camera/client/CameraProxy;
    :cond_0
    return-void
.end method

.method private onCameraState(Ltas/internal/camera/InputParams;)V
    .locals 6
    .param p1, "params"    # Ltas/internal/camera/InputParams;

    .prologue
    const/4 v3, 0x1

    .line 356
    iget-object v2, p1, Ltas/internal/camera/InputParams;->cam:Ljava/lang/String;

    if-nez v2, :cond_0

    return-void

    .line 358
    :cond_0
    const-string/jumbo v2, "TasCAM<ServerConnection>"

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v5, "onCameraState - "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v2, v4}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 360
    iget-object v2, p0, Ltas/internal/camera/client/ServerConnection;->mClients:Ljava/util/List;

    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    .local v1, "c$iterator":Ljava/util/Iterator;
    :cond_1
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_3

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/camera/client/CameraProxy;

    .line 361
    .local v0, "c":Ltas/internal/camera/client/CameraProxy;
    iget-object v2, p1, Ltas/internal/camera/InputParams;->cam:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ltas/internal/camera/client/CameraProxy;->isCamera(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1

    .line 362
    iget-object v2, p1, Ltas/internal/camera/InputParams;->msg:Ltas/camera/CameraMessage;

    iget v2, v2, Ltas/camera/CameraMessage;->arg1:I

    if-ne v2, v3, :cond_2

    move v2, v3

    :goto_1
    invoke-virtual {v0, v2}, Ltas/internal/camera/client/CameraProxy;->dispatchCameraState(Z)V

    goto :goto_0

    :cond_2
    const/4 v2, 0x0

    goto :goto_1

    .line 355
    .end local v0    # "c":Ltas/internal/camera/client/CameraProxy;
    :cond_3
    return-void
.end method

.method private onExtraState(Ltas/internal/camera/InputParams;)V
    .locals 5
    .param p1, "params"    # Ltas/internal/camera/InputParams;

    .prologue
    .line 380
    iget-object v2, p1, Ltas/internal/camera/InputParams;->cam:Ljava/lang/String;

    if-nez v2, :cond_0

    return-void

    .line 382
    :cond_0
    const-string/jumbo v2, "TasCAM<ServerConnection>"

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v4, "onExtraState - "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 384
    iget-object v2, p0, Ltas/internal/camera/client/ServerConnection;->mClients:Ljava/util/List;

    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    .local v1, "c$iterator":Ljava/util/Iterator;
    :cond_1
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_2

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/camera/client/CameraProxy;

    .line 385
    .local v0, "c":Ltas/internal/camera/client/CameraProxy;
    iget-object v2, p1, Ltas/internal/camera/InputParams;->cam:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ltas/internal/camera/client/CameraProxy;->isCamera(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1

    .line 386
    iget-object v2, p1, Ltas/internal/camera/InputParams;->msg:Ltas/camera/CameraMessage;

    iget v2, v2, Ltas/camera/CameraMessage;->arg1:I

    iget-object v3, p1, Ltas/internal/camera/InputParams;->msg:Ltas/camera/CameraMessage;

    iget v3, v3, Ltas/camera/CameraMessage;->arg2:I

    invoke-virtual {v0, v2, v3}, Ltas/internal/camera/client/CameraProxy;->dispatchExtraState(II)V

    goto :goto_0

    .line 379
    .end local v0    # "c":Ltas/internal/camera/client/CameraProxy;
    :cond_2
    return-void
.end method

.method private onInitialState(Ltas/internal/camera/InputParams;)V
    .locals 5
    .param p1, "params"    # Ltas/internal/camera/InputParams;

    .prologue
    .line 332
    iget-object v2, p1, Ltas/internal/camera/InputParams;->cam:Ljava/lang/String;

    if-nez v2, :cond_0

    return-void

    .line 334
    :cond_0
    const-string/jumbo v2, "TasCAM<ServerConnection>"

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v4, "onInitialState - "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 336
    iget-object v2, p0, Ltas/internal/camera/client/ServerConnection;->mClients:Ljava/util/List;

    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    .local v1, "c$iterator":Ljava/util/Iterator;
    :cond_1
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_2

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/camera/client/CameraProxy;

    .line 337
    .local v0, "c":Ltas/internal/camera/client/CameraProxy;
    iget-object v2, p1, Ltas/internal/camera/InputParams;->cam:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ltas/internal/camera/client/CameraProxy;->isCamera(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1

    .line 338
    iget-object v2, p1, Ltas/internal/camera/InputParams;->msg:Ltas/camera/CameraMessage;

    invoke-virtual {v0, v2}, Ltas/internal/camera/client/CameraProxy;->dispatchInitialState(Ltas/camera/CameraMessage;)V

    goto :goto_0

    .line 331
    .end local v0    # "c":Ltas/internal/camera/client/CameraProxy;
    :cond_2
    return-void
.end method

.method private onMediaServerState(Ltas/internal/camera/InputParams;)V
    .locals 6
    .param p1, "params"    # Ltas/internal/camera/InputParams;

    .prologue
    const/4 v3, 0x1

    .line 393
    const-string/jumbo v2, "TasCAM<ServerConnection>"

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v5, "onMediaServerState - "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v2, v4}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 395
    iget-object v2, p0, Ltas/internal/camera/client/ServerConnection;->mClients:Ljava/util/List;

    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    .local v1, "c$iterator":Ljava/util/Iterator;
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/camera/client/CameraProxy;

    .line 396
    .local v0, "c":Ltas/internal/camera/client/CameraProxy;
    iget-object v2, p1, Ltas/internal/camera/InputParams;->msg:Ltas/camera/CameraMessage;

    iget v2, v2, Ltas/camera/CameraMessage;->arg1:I

    if-ne v2, v3, :cond_0

    move v2, v3

    :goto_1
    invoke-virtual {v0, v2}, Ltas/internal/camera/client/CameraProxy;->dispatchMediaServerState(Z)V

    goto :goto_0

    :cond_0
    const/4 v2, 0x0

    goto :goto_1

    .line 391
    .end local v0    # "c":Ltas/internal/camera/client/CameraProxy;
    :cond_1
    return-void
.end method


# virtual methods
.method public addClient(Ltas/internal/camera/client/CameraProxy;)V
    .locals 1
    .param p1, "c"    # Ltas/internal/camera/client/CameraProxy;

    .prologue
    .line 54
    iget-object v0, p0, Ltas/internal/camera/client/ServerConnection;->mClients:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 53
    return-void
.end method

.method public cancel(Ltas/internal/camera/client/CameraProxy;)V
    .locals 2
    .param p1, "c"    # Ltas/internal/camera/client/CameraProxy;

    .prologue
    .line 119
    invoke-static {p1}, Ltas/internal/camera/client/ServerConnection$Holder;->obtain(Ltas/internal/camera/client/CameraProxy;)Ltas/internal/camera/client/ServerConnection$Holder;

    move-result-object v0

    const/16 v1, 0x68

    invoke-virtual {p0, v1, v0}, Ltas/internal/camera/client/ServerConnection;->schedule(ILjava/lang/Object;)V

    .line 118
    return-void
.end method

.method public command(Ltas/internal/camera/client/CameraProxy;Ltas/camera/CameraCommand;)V
    .locals 2
    .param p1, "c"    # Ltas/internal/camera/client/CameraProxy;
    .param p2, "cmd"    # Ltas/camera/CameraCommand;

    .prologue
    .line 123
    invoke-static {p1, p2}, Ltas/internal/camera/client/ServerConnection$Holder;->obtain(Ltas/internal/camera/client/CameraProxy;Ltas/camera/CameraCommand;)Ltas/internal/camera/client/ServerConnection$Holder;

    move-result-object v0

    const/16 v1, 0x69

    invoke-virtual {p0, v1, v0}, Ltas/internal/camera/client/ServerConnection;->schedule(ILjava/lang/Object;)V

    .line 122
    return-void
.end method

.method public connect(Landroid/content/Context;)V
    .locals 3
    .param p1, "context"    # Landroid/content/Context;

    .prologue
    .line 46
    const-string/jumbo v0, "tas.service.common"

    .line 47
    const-string/jumbo v1, "tas.service.camera.CameraServer"

    .line 48
    const/16 v2, 0x49

    .line 45
    invoke-virtual {p0, p1, v0, v1, v2}, Ltas/internal/camera/client/ServerConnection;->connect(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;I)V

    .line 44
    return-void
.end method

.method public bridge synthetic handleMessage(Landroid/os/IInterface;Landroid/os/Message;)V
    .locals 0
    .param p1, "remote"    # Landroid/os/IInterface;
    .param p2, "msg"    # Landroid/os/Message;

    .prologue
    .line 151
    check-cast p1, Ltas/internal/camera/server/IServerService;

    .end local p1    # "remote":Landroid/os/IInterface;
    invoke-virtual {p0, p1, p2}, Ltas/internal/camera/client/ServerConnection;->handleMessage(Ltas/internal/camera/server/IServerService;Landroid/os/Message;)V

    return-void
.end method

.method public handleMessage(Ltas/internal/camera/server/IServerService;Landroid/os/Message;)V
    .locals 8
    .param p1, "remote"    # Ltas/internal/camera/server/IServerService;
    .param p2, "msg"    # Landroid/os/Message;

    .prologue
    .line 152
    iget v7, p2, Landroid/os/Message;->what:I

    packed-switch v7, :pswitch_data_0

    .line 151
    :goto_0
    return-void

    .line 154
    :pswitch_0
    iget-object v2, p2, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v2, Ltas/internal/camera/client/ServerConnection$Holder;

    .line 155
    .local v2, "holder":Ltas/internal/camera/client/ServerConnection$Holder;
    iget-object v3, v2, Ltas/internal/camera/client/ServerConnection$Holder;->proxy:Ltas/internal/camera/client/CameraProxy;

    .line 156
    .local v3, "proxy":Ltas/internal/camera/client/CameraProxy;
    iget-object v0, v2, Ltas/internal/camera/client/ServerConnection$Holder;->msg:Ltas/camera/CameraMessage;

    .line 158
    .local v0, "cmsg":Ltas/camera/CameraMessage;
    if-nez v3, :cond_0

    .line 159
    invoke-virtual {v2}, Ltas/internal/camera/client/ServerConnection$Holder;->recycle()V

    .line 160
    return-void

    .line 163
    :cond_0
    iget-object v7, v3, Ltas/internal/camera/client/CameraProxy;->cam:Ltas/camera/CameraId;

    invoke-static {v7, v0}, Ltas/internal/camera/server/RemoteMessage;->obtain(Ltas/camera/CameraId;Ltas/camera/CameraMessage;)Ltas/internal/camera/server/RemoteMessage;

    move-result-object v5

    .line 166
    .local v5, "rmsg":Ltas/internal/camera/server/RemoteMessage;
    :try_start_0
    invoke-interface {p1, v5}, Ltas/internal/camera/server/IServerService;->watch(Ltas/internal/camera/server/RemoteMessage;)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 170
    invoke-virtual {v5}, Ltas/internal/camera/server/RemoteMessage;->recycle()V

    .line 171
    invoke-virtual {v2}, Ltas/internal/camera/client/ServerConnection$Holder;->recycle()V

    goto :goto_0

    .line 167
    :catch_0
    move-exception v1

    .line 168
    .local v1, "e":Landroid/os/RemoteException;
    :try_start_1
    invoke-virtual {v1}, Landroid/os/RemoteException;->printStackTrace()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 170
    invoke-virtual {v5}, Ltas/internal/camera/server/RemoteMessage;->recycle()V

    .line 171
    invoke-virtual {v2}, Ltas/internal/camera/client/ServerConnection$Holder;->recycle()V

    goto :goto_0

    .line 169
    .end local v1    # "e":Landroid/os/RemoteException;
    :catchall_0
    move-exception v7

    .line 170
    invoke-virtual {v5}, Ltas/internal/camera/server/RemoteMessage;->recycle()V

    .line 171
    invoke-virtual {v2}, Ltas/internal/camera/client/ServerConnection$Holder;->recycle()V

    .line 169
    throw v7

    .line 176
    .end local v0    # "cmsg":Ltas/camera/CameraMessage;
    .end local v2    # "holder":Ltas/internal/camera/client/ServerConnection$Holder;
    .end local v3    # "proxy":Ltas/internal/camera/client/CameraProxy;
    .end local v5    # "rmsg":Ltas/internal/camera/server/RemoteMessage;
    :pswitch_1
    iget-object v2, p2, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v2, Ltas/internal/camera/client/ServerConnection$Holder;

    .line 177
    .restart local v2    # "holder":Ltas/internal/camera/client/ServerConnection$Holder;
    iget-object v3, v2, Ltas/internal/camera/client/ServerConnection$Holder;->proxy:Ltas/internal/camera/client/CameraProxy;

    .line 178
    .restart local v3    # "proxy":Ltas/internal/camera/client/CameraProxy;
    iget-object v0, v2, Ltas/internal/camera/client/ServerConnection$Holder;->msg:Ltas/camera/CameraMessage;

    .line 180
    .restart local v0    # "cmsg":Ltas/camera/CameraMessage;
    if-nez v3, :cond_1

    .line 181
    invoke-virtual {v2}, Ltas/internal/camera/client/ServerConnection$Holder;->recycle()V

    .line 182
    return-void

    .line 185
    :cond_1
    iget-object v7, v3, Ltas/internal/camera/client/CameraProxy;->cam:Ltas/camera/CameraId;

    invoke-static {v7, v0}, Ltas/internal/camera/server/RemoteMessage;->obtain(Ltas/camera/CameraId;Ltas/camera/CameraMessage;)Ltas/internal/camera/server/RemoteMessage;

    move-result-object v5

    .line 188
    .restart local v5    # "rmsg":Ltas/internal/camera/server/RemoteMessage;
    :try_start_2
    invoke-interface {p1, v5}, Ltas/internal/camera/server/IServerService;->unwatch(Ltas/internal/camera/server/RemoteMessage;)V
    :try_end_2
    .catch Landroid/os/RemoteException; {:try_start_2 .. :try_end_2} :catch_1
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .line 192
    invoke-virtual {v5}, Ltas/internal/camera/server/RemoteMessage;->recycle()V

    .line 193
    invoke-virtual {v2}, Ltas/internal/camera/client/ServerConnection$Holder;->recycle()V

    goto :goto_0

    .line 189
    :catch_1
    move-exception v1

    .line 190
    .restart local v1    # "e":Landroid/os/RemoteException;
    :try_start_3
    invoke-virtual {v1}, Landroid/os/RemoteException;->printStackTrace()V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    .line 192
    invoke-virtual {v5}, Ltas/internal/camera/server/RemoteMessage;->recycle()V

    .line 193
    invoke-virtual {v2}, Ltas/internal/camera/client/ServerConnection$Holder;->recycle()V

    goto :goto_0

    .line 191
    .end local v1    # "e":Landroid/os/RemoteException;
    :catchall_1
    move-exception v7

    .line 192
    invoke-virtual {v5}, Ltas/internal/camera/server/RemoteMessage;->recycle()V

    .line 193
    invoke-virtual {v2}, Ltas/internal/camera/client/ServerConnection$Holder;->recycle()V

    .line 191
    throw v7

    .line 198
    .end local v0    # "cmsg":Ltas/camera/CameraMessage;
    .end local v2    # "holder":Ltas/internal/camera/client/ServerConnection$Holder;
    .end local v3    # "proxy":Ltas/internal/camera/client/CameraProxy;
    .end local v5    # "rmsg":Ltas/internal/camera/server/RemoteMessage;
    :pswitch_2
    iget-object v2, p2, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v2, Ltas/internal/camera/client/ServerConnection$Holder;

    .line 199
    .restart local v2    # "holder":Ltas/internal/camera/client/ServerConnection$Holder;
    iget-object v3, v2, Ltas/internal/camera/client/ServerConnection$Holder;->proxy:Ltas/internal/camera/client/CameraProxy;

    .line 200
    .restart local v3    # "proxy":Ltas/internal/camera/client/CameraProxy;
    iget-object v0, v2, Ltas/internal/camera/client/ServerConnection$Holder;->msg:Ltas/camera/CameraMessage;

    .line 202
    .restart local v0    # "cmsg":Ltas/camera/CameraMessage;
    if-nez v3, :cond_2

    .line 203
    invoke-virtual {v2}, Ltas/internal/camera/client/ServerConnection$Holder;->recycle()V

    .line 204
    return-void

    .line 207
    :cond_2
    iget-object v7, v3, Ltas/internal/camera/client/CameraProxy;->cam:Ltas/camera/CameraId;

    invoke-static {v7, v0}, Ltas/internal/camera/server/RemoteMessage;->obtain(Ltas/camera/CameraId;Ltas/camera/CameraMessage;)Ltas/internal/camera/server/RemoteMessage;

    move-result-object v5

    .line 208
    .restart local v5    # "rmsg":Ltas/internal/camera/server/RemoteMessage;
    const/4 v4, -0x1

    .line 211
    .local v4, "result":I
    :try_start_4
    invoke-interface {p1, v5}, Ltas/internal/camera/server/IServerService;->request(Ltas/internal/camera/server/RemoteMessage;)I
    :try_end_4
    .catch Landroid/os/RemoteException; {:try_start_4 .. :try_end_4} :catch_2
    .catchall {:try_start_4 .. :try_end_4} :catchall_2

    move-result v4

    .line 215
    invoke-virtual {v3, v4}, Ltas/internal/camera/client/CameraProxy;->dispatchRequestResult(I)V

    .line 216
    invoke-virtual {v5}, Ltas/internal/camera/server/RemoteMessage;->recycle()V

    .line 217
    invoke-virtual {v2}, Ltas/internal/camera/client/ServerConnection$Holder;->recycle()V

    goto/16 :goto_0

    .line 212
    :catch_2
    move-exception v1

    .line 213
    .restart local v1    # "e":Landroid/os/RemoteException;
    :try_start_5
    invoke-virtual {v1}, Landroid/os/RemoteException;->printStackTrace()V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_2

    .line 215
    invoke-virtual {v3, v4}, Ltas/internal/camera/client/CameraProxy;->dispatchRequestResult(I)V

    .line 216
    invoke-virtual {v5}, Ltas/internal/camera/server/RemoteMessage;->recycle()V

    .line 217
    invoke-virtual {v2}, Ltas/internal/camera/client/ServerConnection$Holder;->recycle()V

    goto/16 :goto_0

    .line 214
    .end local v1    # "e":Landroid/os/RemoteException;
    :catchall_2
    move-exception v7

    .line 215
    invoke-virtual {v3, v4}, Ltas/internal/camera/client/CameraProxy;->dispatchRequestResult(I)V

    .line 216
    invoke-virtual {v5}, Ltas/internal/camera/server/RemoteMessage;->recycle()V

    .line 217
    invoke-virtual {v2}, Ltas/internal/camera/client/ServerConnection$Holder;->recycle()V

    .line 214
    throw v7

    .line 222
    .end local v0    # "cmsg":Ltas/camera/CameraMessage;
    .end local v2    # "holder":Ltas/internal/camera/client/ServerConnection$Holder;
    .end local v3    # "proxy":Ltas/internal/camera/client/CameraProxy;
    .end local v4    # "result":I
    .end local v5    # "rmsg":Ltas/internal/camera/server/RemoteMessage;
    :pswitch_3
    iget-object v2, p2, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v2, Ltas/internal/camera/client/ServerConnection$Holder;

    .line 223
    .restart local v2    # "holder":Ltas/internal/camera/client/ServerConnection$Holder;
    iget-object v3, v2, Ltas/internal/camera/client/ServerConnection$Holder;->proxy:Ltas/internal/camera/client/CameraProxy;

    .line 224
    .restart local v3    # "proxy":Ltas/internal/camera/client/CameraProxy;
    iget-object v0, v2, Ltas/internal/camera/client/ServerConnection$Holder;->msg:Ltas/camera/CameraMessage;

    .line 226
    .restart local v0    # "cmsg":Ltas/camera/CameraMessage;
    if-nez v3, :cond_3

    .line 227
    invoke-virtual {v2}, Ltas/internal/camera/client/ServerConnection$Holder;->recycle()V

    .line 228
    return-void

    .line 231
    :cond_3
    iget-object v7, v3, Ltas/internal/camera/client/CameraProxy;->cam:Ltas/camera/CameraId;

    invoke-static {v7, v0}, Ltas/internal/camera/server/RemoteMessage;->obtain(Ltas/camera/CameraId;Ltas/camera/CameraMessage;)Ltas/internal/camera/server/RemoteMessage;

    move-result-object v5

    .line 234
    .restart local v5    # "rmsg":Ltas/internal/camera/server/RemoteMessage;
    :try_start_6
    invoke-interface {p1, v5}, Ltas/internal/camera/server/IServerService;->cancel(Ltas/internal/camera/server/RemoteMessage;)V
    :try_end_6
    .catch Landroid/os/RemoteException; {:try_start_6 .. :try_end_6} :catch_3
    .catchall {:try_start_6 .. :try_end_6} :catchall_3

    .line 238
    invoke-virtual {v5}, Ltas/internal/camera/server/RemoteMessage;->recycle()V

    .line 239
    invoke-virtual {v2}, Ltas/internal/camera/client/ServerConnection$Holder;->recycle()V

    goto/16 :goto_0

    .line 235
    :catch_3
    move-exception v1

    .line 236
    .restart local v1    # "e":Landroid/os/RemoteException;
    :try_start_7
    invoke-virtual {v1}, Landroid/os/RemoteException;->printStackTrace()V
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_3

    .line 238
    invoke-virtual {v5}, Ltas/internal/camera/server/RemoteMessage;->recycle()V

    .line 239
    invoke-virtual {v2}, Ltas/internal/camera/client/ServerConnection$Holder;->recycle()V

    goto/16 :goto_0

    .line 237
    .end local v1    # "e":Landroid/os/RemoteException;
    :catchall_3
    move-exception v7

    .line 238
    invoke-virtual {v5}, Ltas/internal/camera/server/RemoteMessage;->recycle()V

    .line 239
    invoke-virtual {v2}, Ltas/internal/camera/client/ServerConnection$Holder;->recycle()V

    .line 237
    throw v7

    .line 244
    .end local v0    # "cmsg":Ltas/camera/CameraMessage;
    .end local v2    # "holder":Ltas/internal/camera/client/ServerConnection$Holder;
    .end local v3    # "proxy":Ltas/internal/camera/client/CameraProxy;
    .end local v5    # "rmsg":Ltas/internal/camera/server/RemoteMessage;
    :pswitch_4
    iget-object v2, p2, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v2, Ltas/internal/camera/client/ServerConnection$Holder;

    .line 245
    .restart local v2    # "holder":Ltas/internal/camera/client/ServerConnection$Holder;
    iget-object v3, v2, Ltas/internal/camera/client/ServerConnection$Holder;->proxy:Ltas/internal/camera/client/CameraProxy;

    .line 246
    .restart local v3    # "proxy":Ltas/internal/camera/client/CameraProxy;
    iget-object v0, v2, Ltas/internal/camera/client/ServerConnection$Holder;->msg:Ltas/camera/CameraMessage;

    .line 248
    .restart local v0    # "cmsg":Ltas/camera/CameraMessage;
    if-eqz v3, :cond_4

    if-nez v0, :cond_5

    .line 249
    :cond_4
    invoke-virtual {v2}, Ltas/internal/camera/client/ServerConnection$Holder;->recycle()V

    .line 250
    return-void

    .line 253
    :cond_5
    iget-object v7, v3, Ltas/internal/camera/client/CameraProxy;->cam:Ltas/camera/CameraId;

    invoke-static {v7, v0}, Ltas/internal/camera/server/RemoteMessage;->obtain(Ltas/camera/CameraId;Ltas/camera/CameraMessage;)Ltas/internal/camera/server/RemoteMessage;

    move-result-object v5

    .line 254
    .restart local v5    # "rmsg":Ltas/internal/camera/server/RemoteMessage;
    iget v6, v0, Ltas/camera/CameraMessage;->what:I

    .line 255
    .local v6, "what":I
    const/4 v4, -0x1

    .line 258
    .restart local v4    # "result":I
    :try_start_8
    invoke-interface {p1, v5}, Ltas/internal/camera/server/IServerService;->command(Ltas/internal/camera/server/RemoteMessage;)I
    :try_end_8
    .catch Landroid/os/RemoteException; {:try_start_8 .. :try_end_8} :catch_4
    .catchall {:try_start_8 .. :try_end_8} :catchall_4

    move-result v4

    .line 262
    invoke-virtual {v3, v6, v4}, Ltas/internal/camera/client/CameraProxy;->dispatchCommandResult(II)V

    .line 263
    invoke-virtual {v5}, Ltas/internal/camera/server/RemoteMessage;->recycle()V

    .line 264
    invoke-virtual {v2}, Ltas/internal/camera/client/ServerConnection$Holder;->recycle()V

    goto/16 :goto_0

    .line 259
    :catch_4
    move-exception v1

    .line 260
    .restart local v1    # "e":Landroid/os/RemoteException;
    :try_start_9
    invoke-virtual {v1}, Landroid/os/RemoteException;->printStackTrace()V
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_4

    .line 262
    invoke-virtual {v3, v6, v4}, Ltas/internal/camera/client/CameraProxy;->dispatchCommandResult(II)V

    .line 263
    invoke-virtual {v5}, Ltas/internal/camera/server/RemoteMessage;->recycle()V

    .line 264
    invoke-virtual {v2}, Ltas/internal/camera/client/ServerConnection$Holder;->recycle()V

    goto/16 :goto_0

    .line 261
    .end local v1    # "e":Landroid/os/RemoteException;
    :catchall_4
    move-exception v7

    .line 262
    invoke-virtual {v3, v6, v4}, Ltas/internal/camera/client/CameraProxy;->dispatchCommandResult(II)V

    .line 263
    invoke-virtual {v5}, Ltas/internal/camera/server/RemoteMessage;->recycle()V

    .line 264
    invoke-virtual {v2}, Ltas/internal/camera/client/ServerConnection$Holder;->recycle()V

    .line 261
    throw v7

    .line 152
    nop

    :pswitch_data_0
    .packed-switch 0x65
        :pswitch_0
        :pswitch_1
        :pswitch_2
        :pswitch_3
        :pswitch_4
    .end packed-switch
.end method

.method public hasClient(Ltas/internal/camera/client/CameraProxy;)Z
    .locals 1
    .param p1, "c"    # Ltas/internal/camera/client/CameraProxy;

    .prologue
    .line 62
    iget-object v0, p0, Ltas/internal/camera/client/ServerConnection;->mClients:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v0

    return v0
.end method

.method public bridge synthetic onConnected(Landroid/os/IBinder;)Landroid/os/IInterface;
    .locals 1
    .param p1, "binder"    # Landroid/os/IBinder;

    .prologue
    .line 132
    invoke-virtual {p0, p1}, Ltas/internal/camera/client/ServerConnection;->onConnected(Landroid/os/IBinder;)Ltas/internal/camera/server/IServerService;

    move-result-object v0

    return-object v0
.end method

.method public onConnected(Landroid/os/IBinder;)Ltas/internal/camera/server/IServerService;
    .locals 3
    .param p1, "binder"    # Landroid/os/IBinder;

    .prologue
    .line 133
    invoke-static {p1}, Ltas/internal/camera/server/IServerService$Stub;->asInterface(Landroid/os/IBinder;)Ltas/internal/camera/server/IServerService;

    move-result-object v1

    .line 135
    .local v1, "server":Ltas/internal/camera/server/IServerService;
    :try_start_0
    iget-object v2, p0, Ltas/internal/camera/client/ServerConnection;->mCallback:Ltas/internal/camera/client/ServerConnection$ServerCallback;

    invoke-interface {v1, v2}, Ltas/internal/camera/server/IServerService;->setcallback(Ltas/internal/camera/server/IServerCallback;)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    .line 140
    .end local v1    # "server":Ltas/internal/camera/server/IServerService;
    :goto_0
    return-object v1

    .line 136
    .restart local v1    # "server":Ltas/internal/camera/server/IServerService;
    :catch_0
    move-exception v0

    .line 137
    .local v0, "e":Landroid/os/RemoteException;
    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    .line 138
    const/4 v1, 0x0

    .local v1, "server":Ltas/internal/camera/server/IServerService;
    goto :goto_0
.end method

.method public onDeath()V
    .locals 1

    .prologue
    .line 148
    const/16 v0, -0xb

    invoke-direct {p0, v0}, Ltas/internal/camera/client/ServerConnection;->onCameraServerError(I)V

    .line 147
    return-void
.end method

.method public onDisconnected()V
    .locals 1

    .prologue
    .line 144
    const/16 v0, -0xa

    invoke-direct {p0, v0}, Ltas/internal/camera/client/ServerConnection;->onCameraServerError(I)V

    .line 143
    return-void
.end method

.method public removeClient(Ltas/internal/camera/client/CameraProxy;)V
    .locals 1
    .param p1, "c"    # Ltas/internal/camera/client/CameraProxy;

    .prologue
    .line 58
    iget-object v0, p0, Ltas/internal/camera/client/ServerConnection;->mClients:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->remove(Ljava/lang/Object;)Z

    .line 57
    return-void
.end method

.method public request(Ltas/internal/camera/client/CameraProxy;)V
    .locals 2
    .param p1, "c"    # Ltas/internal/camera/client/CameraProxy;

    .prologue
    .line 115
    invoke-static {p1}, Ltas/internal/camera/client/ServerConnection$Holder;->obtain(Ltas/internal/camera/client/CameraProxy;)Ltas/internal/camera/client/ServerConnection$Holder;

    move-result-object v0

    const/16 v1, 0x67

    invoke-virtual {p0, v1, v0}, Ltas/internal/camera/client/ServerConnection;->schedule(ILjava/lang/Object;)V

    .line 114
    return-void
.end method

.method public unwatch(Ltas/internal/camera/client/CameraProxy;)V
    .locals 7
    .param p1, "c"    # Ltas/internal/camera/client/CameraProxy;

    .prologue
    .line 99
    iget-object v4, p0, Ltas/internal/camera/client/ServerConnection;->mRefs:Ljava/util/Map;

    monitor-enter v4

    .line 100
    :try_start_0
    iget-object v0, p1, Ltas/internal/camera/client/CameraProxy;->cam:Ltas/camera/CameraId;

    .line 101
    .local v0, "cam":Ltas/camera/CameraId;
    iget-object v3, p0, Ltas/internal/camera/client/ServerConnection;->mRefs:Ljava/util/Map;

    invoke-virtual {v0}, Ltas/camera/CameraId;->getClass()Ljava/lang/Class;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v5

    invoke-interface {v3, v5}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Integer;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 102
    .local v2, "ref":Ljava/lang/Integer;
    if-nez v2, :cond_0

    monitor-exit v4

    .line 103
    return-void

    .line 106
    :cond_0
    :try_start_1
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v3

    add-int/lit8 v1, v3, -0x1

    .line 107
    .local v1, "dec":I
    if-nez v1, :cond_1

    .line 108
    invoke-static {p1}, Ltas/internal/camera/client/ServerConnection$Holder;->obtain(Ltas/internal/camera/client/CameraProxy;)Ltas/internal/camera/client/ServerConnection$Holder;

    move-result-object v3

    const/16 v5, 0x66

    invoke-virtual {p0, v5, v3}, Ltas/internal/camera/client/ServerConnection;->schedule(ILjava/lang/Object;)V

    .line 110
    :cond_1
    iget-object v3, p0, Ltas/internal/camera/client/ServerConnection;->mRefs:Ljava/util/Map;

    invoke-virtual {v0}, Ltas/camera/CameraId;->getClass()Ljava/lang/Class;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v5

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-interface {v3, v5, v6}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    monitor-exit v4

    .line 98
    return-void

    .line 99
    .end local v0    # "cam":Ltas/camera/CameraId;
    .end local v1    # "dec":I
    .end local v2    # "ref":Ljava/lang/Integer;
    :catchall_0
    move-exception v3

    monitor-exit v4

    throw v3
.end method

.method public watch(Ltas/internal/camera/client/CameraProxy;)V
    .locals 13
    .param p1, "c"    # Ltas/internal/camera/client/CameraProxy;

    .prologue
    const/4 v10, 0x0

    const/4 v9, 0x1

    .line 66
    iget-object v12, p0, Ltas/internal/camera/client/ServerConnection;->mRefs:Ljava/util/Map;

    monitor-enter v12

    .line 67
    :try_start_0
    iget-object v0, p1, Ltas/internal/camera/client/CameraProxy;->cam:Ltas/camera/CameraId;

    .line 68
    .local v0, "cam":Ltas/camera/CameraId;
    invoke-virtual {v0}, Ltas/camera/CameraId;->getClass()Ljava/lang/Class;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v1

    .line 69
    .local v1, "clsname":Ljava/lang/String;
    iget-object v11, p0, Ltas/internal/camera/client/ServerConnection;->mRefs:Ljava/util/Map;

    invoke-interface {v11, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Ljava/lang/Integer;

    .line 70
    .local v8, "ref":Ljava/lang/Integer;
    if-eqz v8, :cond_0

    invoke-virtual {v8}, Ljava/lang/Integer;->intValue()I

    move-result v11

    add-int/lit8 v3, v11, 0x1

    .line 71
    .local v3, "inc":I
    :goto_0
    if-ne v3, v9, :cond_1

    .line 72
    invoke-static {p1}, Ltas/internal/camera/client/ServerConnection$Holder;->obtain(Ltas/internal/camera/client/CameraProxy;)Ltas/internal/camera/client/ServerConnection$Holder;

    move-result-object v9

    const/16 v10, 0x65

    invoke-virtual {p0, v10, v9}, Ltas/internal/camera/client/ServerConnection;->schedule(ILjava/lang/Object;)V

    .line 94
    :goto_1
    iget-object v9, p0, Ltas/internal/camera/client/ServerConnection;->mRefs:Ljava/util/Map;

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v10

    invoke-interface {v9, v1, v10}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit v12

    .line 65
    return-void

    .line 70
    .end local v3    # "inc":I
    :cond_0
    const/4 v3, 0x1

    .restart local v3    # "inc":I
    goto :goto_0

    .line 74
    :cond_1
    const/4 v2, 0x0

    .line 75
    .local v2, "found":Ltas/internal/camera/client/CameraProxy;
    :try_start_1
    iget-object v11, p0, Ltas/internal/camera/client/ServerConnection;->mClients:Ljava/util/List;

    invoke-interface {v11}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v7

    .local v7, "p$iterator":Ljava/util/Iterator;
    :cond_2
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    move-result v11

    if-eqz v11, :cond_3

    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ltas/internal/camera/client/CameraProxy;

    .line 76
    .local v6, "p":Ltas/internal/camera/client/CameraProxy;
    if-eqz v6, :cond_4

    iget-object v5, v6, Ltas/internal/camera/client/CameraProxy;->cam:Ltas/camera/CameraId;

    .line 77
    :goto_2
    if-eqz v5, :cond_2

    invoke-virtual {v5}, Ltas/camera/CameraId;->getClass()Ljava/lang/Class;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v11, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v11

    if-eqz v11, :cond_2

    .line 78
    iget-object v11, v6, Ltas/internal/camera/client/CameraProxy;->cam:Ltas/camera/CameraId;

    iget-object v11, v11, Ltas/camera/CameraId;->id:Ljava/lang/String;

    if-eqz v11, :cond_2

    .line 79
    move-object v2, v6

    .line 84
    .end local v2    # "found":Ltas/internal/camera/client/CameraProxy;
    .end local v6    # "p":Ltas/internal/camera/client/CameraProxy;
    :cond_3
    if-eqz v2, :cond_7

    .line 85
    new-instance v4, Ltas/camera/CameraMessage;

    invoke-direct {v4}, Ltas/camera/CameraMessage;-><init>()V

    .line 86
    .local v4, "msg":Ltas/camera/CameraMessage;
    iget-object v11, v2, Ltas/internal/camera/client/CameraProxy;->cam:Ltas/camera/CameraId;

    iget-object v11, v11, Ltas/camera/CameraId;->id:Ljava/lang/String;

    iput-object v11, v4, Ltas/camera/CameraMessage;->str1:Ljava/lang/String;

    .line 87
    iget-object v11, v2, Ltas/internal/camera/client/CameraProxy;->cam:Ltas/camera/CameraId;

    iget-boolean v11, v11, Ltas/camera/CameraId;->plugged:Z

    if-eqz v11, :cond_5

    move v11, v9

    :goto_3
    iput v11, v4, Ltas/camera/CameraMessage;->arg1:I

    .line 88
    iget-object v11, v2, Ltas/internal/camera/client/CameraProxy;->cam:Ltas/camera/CameraId;

    iget-boolean v11, v11, Ltas/camera/CameraId;->opened:Z

    if-eqz v11, :cond_6

    :goto_4
    iput v9, v4, Ltas/camera/CameraMessage;->arg2:I

    .line 89
    invoke-virtual {p1, v4}, Ltas/internal/camera/client/CameraProxy;->dispatchInitialState(Ltas/camera/CameraMessage;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_1

    .line 66
    .end local v0    # "cam":Ltas/camera/CameraId;
    .end local v1    # "clsname":Ljava/lang/String;
    .end local v3    # "inc":I
    .end local v4    # "msg":Ltas/camera/CameraMessage;
    .end local v7    # "p$iterator":Ljava/util/Iterator;
    .end local v8    # "ref":Ljava/lang/Integer;
    :catchall_0
    move-exception v9

    monitor-exit v12

    throw v9

    .line 76
    .restart local v0    # "cam":Ltas/camera/CameraId;
    .restart local v1    # "clsname":Ljava/lang/String;
    .restart local v2    # "found":Ltas/internal/camera/client/CameraProxy;
    .restart local v3    # "inc":I
    .restart local v6    # "p":Ltas/internal/camera/client/CameraProxy;
    .restart local v7    # "p$iterator":Ljava/util/Iterator;
    .restart local v8    # "ref":Ljava/lang/Integer;
    :cond_4
    const/4 v5, 0x0

    .local v5, "o":Ltas/camera/CameraId;
    goto :goto_2

    .end local v2    # "found":Ltas/internal/camera/client/CameraProxy;
    .end local v5    # "o":Ltas/camera/CameraId;
    .end local v6    # "p":Ltas/internal/camera/client/CameraProxy;
    .restart local v4    # "msg":Ltas/camera/CameraMessage;
    :cond_5
    move v11, v10

    .line 87
    goto :goto_3

    :cond_6
    move v9, v10

    .line 88
    goto :goto_4

    .line 91
    .end local v4    # "msg":Ltas/camera/CameraMessage;
    :cond_7
    :try_start_2
    const-string/jumbo v9, "TasCAM<ServerConnection>"

    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v11, "rare case: not found "

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v10

    invoke-static {v9, v10}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    goto :goto_1
.end method
