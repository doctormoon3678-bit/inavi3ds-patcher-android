.class public Lcom/thinkware/sundo/ieve/ieveTextView;
.super Landroid/widget/TextView;
.source "ieveTextView.java"


# static fields
.field private static final a:Ljava/lang/String;


# instance fields
.field private b:Landroid/content/Context;

.field private c:Landroid/graphics/Paint;

.field private d:Ljava/util/TreeMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/TreeMap",
            "<",
            "Ljava/lang/Integer;",
            "Lcom/thinkware/sundo/ieve/a;",
            ">;"
        }
    .end annotation
.end field

.field private e:Z

.field private f:Landroid/graphics/PointF;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .prologue
    .line 53
    const-class v0, Lcom/thinkware/sundo/ieve/ieveTextView;

    invoke-virtual {v0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveTextView;->a:Ljava/lang/String;

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .locals 5
    .param p1, "context"    # Landroid/content/Context;

    .prologue
    const/4 v4, 0x0

    const/high16 v3, 0x3f800000    # 1.0f

    const/4 v1, 0x0

    .line 63
    invoke-direct {p0, p1}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 54
    iput-object v1, p0, Lcom/thinkware/sundo/ieve/ieveTextView;->b:Landroid/content/Context;

    .line 55
    iput-object v1, p0, Lcom/thinkware/sundo/ieve/ieveTextView;->c:Landroid/graphics/Paint;

    .line 57
    iput-object v1, p0, Lcom/thinkware/sundo/ieve/ieveTextView;->d:Ljava/util/TreeMap;

    .line 58
    iput-boolean v4, p0, Lcom/thinkware/sundo/ieve/ieveTextView;->e:Z

    .line 59
    iput-object v1, p0, Lcom/thinkware/sundo/ieve/ieveTextView;->f:Landroid/graphics/PointF;

    .line 64
    sget-object v1, Lcom/thinkware/sundo/ieve/ieveTextView;->a:Ljava/lang/String;

    const-string v2, "Constructor"

    invoke-static {v1, v2}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 65
    iput-object p1, p0, Lcom/thinkware/sundo/ieve/ieveTextView;->b:Landroid/content/Context;

    .line 67
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/ieveTextView;->b:Landroid/content/Context;

    if-nez v1, :cond_0

    .line 68
    const-string v1, "Context is null!"

    new-array v2, v4, [Ljava/lang/Object;

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    .line 69
    .local v0, "text":Ljava/lang/String;
    sget-object v1, Lcom/thinkware/sundo/ieve/ieveTextView;->a:Ljava/lang/String;

    invoke-static {v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 76
    .end local v0    # "text":Ljava/lang/String;
    :goto_0
    return-void

    .line 73
    :cond_0
    new-instance v1, Landroid/graphics/Paint;

    const/4 v2, 0x1

    invoke-direct {v1, v2}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v1, p0, Lcom/thinkware/sundo/ieve/ieveTextView;->c:Landroid/graphics/Paint;

    .line 74
    new-instance v1, Ljava/util/TreeMap;

    invoke-direct {v1}, Ljava/util/TreeMap;-><init>()V

    iput-object v1, p0, Lcom/thinkware/sundo/ieve/ieveTextView;->d:Ljava/util/TreeMap;

    .line 75
    new-instance v1, Landroid/graphics/PointF;

    invoke-direct {v1, v3, v3}, Landroid/graphics/PointF;-><init>(FF)V

    iput-object v1, p0, Lcom/thinkware/sundo/ieve/ieveTextView;->f:Landroid/graphics/PointF;

    goto :goto_0
.end method


# virtual methods
.method protected dispatchDraw(Landroid/graphics/Canvas;)V
    .locals 11
    .param p1, "canvas"    # Landroid/graphics/Canvas;

    .prologue
    const/high16 v10, -0x1000000

    const/high16 v9, 0x3f800000    # 1.0f

    const/4 v8, 0x0

    const/4 v7, 0x0

    .line 120
    invoke-super {p0, p1}, Landroid/widget/TextView;->dispatchDraw(Landroid/graphics/Canvas;)V

    .line 122
    invoke-virtual {p1, v8}, Landroid/graphics/Canvas;->drawColor(I)V

    .line 123
    new-instance v4, Landroid/graphics/PaintFlagsDrawFilter;

    const/4 v5, 0x2

    invoke-direct {v4, v8, v5}, Landroid/graphics/PaintFlagsDrawFilter;-><init>(II)V

    invoke-virtual {p1, v4}, Landroid/graphics/Canvas;->setDrawFilter(Landroid/graphics/DrawFilter;)V

    .line 124
    iget-object v4, p0, Lcom/thinkware/sundo/ieve/ieveTextView;->f:Landroid/graphics/PointF;

    iget v4, v4, Landroid/graphics/PointF;->x:F

    iget-object v5, p0, Lcom/thinkware/sundo/ieve/ieveTextView;->f:Landroid/graphics/PointF;

    iget v5, v5, Landroid/graphics/PointF;->y:F

    invoke-virtual {p1, v4, v5}, Landroid/graphics/Canvas;->scale(FF)V

    .line 126
    iget-object v4, p0, Lcom/thinkware/sundo/ieve/ieveTextView;->d:Ljava/util/TreeMap;

    invoke-virtual {v4}, Ljava/util/TreeMap;->keySet()Ljava/util/Set;

    move-result-object v4

    invoke-interface {v4}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    .line 127
    .local v1, "it":Ljava/util/Iterator;, "Ljava/util/Iterator<Ljava/lang/Integer;>;"
    :cond_0
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-nez v4, :cond_2

    .line 157
    :cond_1
    iput-boolean v8, p0, Lcom/thinkware/sundo/ieve/ieveTextView;->e:Z

    .line 158
    return-void

    .line 128
    :cond_2
    iget-boolean v4, p0, Lcom/thinkware/sundo/ieve/ieveTextView;->e:Z

    if-nez v4, :cond_1

    .line 129
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/Integer;

    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    move-result v2

    .line 130
    .local v2, "key":I
    iget-object v4, p0, Lcom/thinkware/sundo/ieve/ieveTextView;->d:Ljava/util/TreeMap;

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/util/TreeMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/thinkware/sundo/ieve/a;

    .line 131
    .local v0, "fontattb":Lcom/thinkware/sundo/ieve/a;
    if-eqz v0, :cond_0

    .line 133
    iget-object v4, p0, Lcom/thinkware/sundo/ieve/ieveTextView;->c:Landroid/graphics/Paint;

    iget v5, v0, Lcom/thinkware/sundo/ieve/a;->k:I

    invoke-virtual {v4, v5}, Landroid/graphics/Paint;->setColor(I)V

    .line 134
    iget v4, v0, Lcom/thinkware/sundo/ieve/a;->o:I

    packed-switch v4, :pswitch_data_0

    .line 138
    iget-object v4, p0, Lcom/thinkware/sundo/ieve/ieveTextView;->c:Landroid/graphics/Paint;

    sget-object v5, Landroid/graphics/Paint$Align;->LEFT:Landroid/graphics/Paint$Align;

    invoke-virtual {v4, v5}, Landroid/graphics/Paint;->setTextAlign(Landroid/graphics/Paint$Align;)V

    .line 140
    :goto_1
    iget-object v4, p0, Lcom/thinkware/sundo/ieve/ieveTextView;->c:Landroid/graphics/Paint;

    iget v5, v0, Lcom/thinkware/sundo/ieve/a;->j:F

    invoke-virtual {v4, v5}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 141
    iget-object v4, p0, Lcom/thinkware/sundo/ieve/ieveTextView;->c:Landroid/graphics/Paint;

    iget-object v5, v0, Lcom/thinkware/sundo/ieve/a;->q:Landroid/graphics/Typeface;

    invoke-virtual {v4, v5}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    .line 142
    iget-object v4, p0, Lcom/thinkware/sundo/ieve/ieveTextView;->c:Landroid/graphics/Paint;

    iget-boolean v5, v0, Lcom/thinkware/sundo/ieve/a;->n:Z

    invoke-virtual {v4, v5}, Landroid/graphics/Paint;->setUnderlineText(Z)V

    .line 143
    iget-boolean v4, v0, Lcom/thinkware/sundo/ieve/a;->m:Z

    if-eqz v4, :cond_3

    iget-object v4, p0, Lcom/thinkware/sundo/ieve/ieveTextView;->c:Landroid/graphics/Paint;

    const v5, -0x41333333    # -0.4f

    invoke-virtual {v4, v5}, Landroid/graphics/Paint;->setTextSkewX(F)V

    .line 144
    :cond_3
    iget-boolean v4, v0, Lcom/thinkware/sundo/ieve/a;->l:Z

    if-eqz v4, :cond_4

    iget-object v4, p0, Lcom/thinkware/sundo/ieve/ieveTextView;->c:Landroid/graphics/Paint;

    const v5, 0x3f99999a    # 1.2f

    invoke-virtual {v4, v5, v9, v9, v10}, Landroid/graphics/Paint;->setShadowLayer(FFFI)V

    .line 147
    :goto_2
    iget v3, v0, Lcom/thinkware/sundo/ieve/a;->i:F

    .line 148
    .local v3, "posy":F
    iget v4, v0, Lcom/thinkware/sundo/ieve/a;->p:I

    packed-switch v4, :pswitch_data_1

    .line 152
    iget v4, v0, Lcom/thinkware/sundo/ieve/a;->j:F

    add-float/2addr v3, v4

    .line 155
    :goto_3
    :pswitch_0
    iget-object v4, v0, Lcom/thinkware/sundo/ieve/a;->g:Ljava/lang/String;

    iget v5, v0, Lcom/thinkware/sundo/ieve/a;->h:F

    iget-object v6, p0, Lcom/thinkware/sundo/ieve/ieveTextView;->c:Landroid/graphics/Paint;

    invoke-virtual {p1, v4, v5, v3, v6}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    goto :goto_0

    .line 135
    .end local v3    # "posy":F
    :pswitch_1
    iget-object v4, p0, Lcom/thinkware/sundo/ieve/ieveTextView;->c:Landroid/graphics/Paint;

    sget-object v5, Landroid/graphics/Paint$Align;->CENTER:Landroid/graphics/Paint$Align;

    invoke-virtual {v4, v5}, Landroid/graphics/Paint;->setTextAlign(Landroid/graphics/Paint$Align;)V

    goto :goto_1

    .line 136
    :pswitch_2
    iget-object v4, p0, Lcom/thinkware/sundo/ieve/ieveTextView;->c:Landroid/graphics/Paint;

    sget-object v5, Landroid/graphics/Paint$Align;->RIGHT:Landroid/graphics/Paint$Align;

    invoke-virtual {v4, v5}, Landroid/graphics/Paint;->setTextAlign(Landroid/graphics/Paint$Align;)V

    goto :goto_1

    .line 145
    :cond_4
    iget-object v4, p0, Lcom/thinkware/sundo/ieve/ieveTextView;->c:Landroid/graphics/Paint;

    invoke-virtual {v4, v7, v7, v7, v10}, Landroid/graphics/Paint;->setShadowLayer(FFFI)V

    goto :goto_2

    .line 150
    .restart local v3    # "posy":F
    :pswitch_3
    iget v4, v0, Lcom/thinkware/sundo/ieve/a;->j:F

    const/high16 v5, 0x40000000    # 2.0f

    div-float/2addr v4, v5

    add-float/2addr v3, v4

    goto :goto_3

    .line 134
    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_1
        :pswitch_2
    .end packed-switch

    .line 148
    :pswitch_data_1
    .packed-switch 0x1
        :pswitch_3
        :pswitch_0
    .end packed-switch
.end method

.method public getFontAttb(I)Lcom/thinkware/sundo/ieve/a;
    .locals 2
    .param p1, "index"    # I

    .prologue
    .line 79
    if-gez p1, :cond_0

    const/4 v0, 0x0

    .line 80
    :goto_0
    return-object v0

    :cond_0
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveTextView;->d:Ljava/util/TreeMap;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/TreeMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/thinkware/sundo/ieve/a;

    goto :goto_0
.end method

.method public insertText(ILjava/lang/String;FFF)V
    .locals 13
    .param p1, "index"    # I
    .param p2, "text"    # Ljava/lang/String;
    .param p3, "posx"    # F
    .param p4, "posy"    # F
    .param p5, "size"    # F

    .prologue
    .line 84
    const/4 v6, -0x1

    const/4 v7, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x0

    move-object v0, p0

    move v1, p1

    move-object v2, p2

    move/from16 v3, p3

    move/from16 v4, p4

    move/from16 v5, p5

    invoke-virtual/range {v0 .. v12}, Lcom/thinkware/sundo/ieve/ieveTextView;->insertText(ILjava/lang/String;FFFIZZZIILandroid/graphics/Typeface;)V

    .line 85
    return-void
.end method

.method public insertText(ILjava/lang/String;FFFI)V
    .locals 13
    .param p1, "index"    # I
    .param p2, "text"    # Ljava/lang/String;
    .param p3, "posx"    # F
    .param p4, "posy"    # F
    .param p5, "size"    # F
    .param p6, "color"    # I

    .prologue
    .line 88
    const/4 v7, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x0

    move-object v0, p0

    move v1, p1

    move-object v2, p2

    move/from16 v3, p3

    move/from16 v4, p4

    move/from16 v5, p5

    move/from16 v6, p6

    invoke-virtual/range {v0 .. v12}, Lcom/thinkware/sundo/ieve/ieveTextView;->insertText(ILjava/lang/String;FFFIZZZIILandroid/graphics/Typeface;)V

    .line 89
    return-void
.end method

.method public insertText(ILjava/lang/String;FFFIZZZIILandroid/graphics/Typeface;)V
    .locals 13
    .param p1, "index"    # I
    .param p2, "text"    # Ljava/lang/String;
    .param p3, "posx"    # F
    .param p4, "posy"    # F
    .param p5, "size"    # F
    .param p6, "color"    # I
    .param p7, "shadow"    # Z
    .param p8, "italic"    # Z
    .param p9, "underline"    # Z
    .param p10, "alignh"    # I
    .param p11, "alignv"    # I
    .param p12, "type"    # Landroid/graphics/Typeface;

    .prologue
    .line 92
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/ieveTextView;->d:Ljava/util/TreeMap;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/util/TreeMap;->containsKey(Ljava/lang/Object;)Z

    move-result v12

    .line 93
    .local v12, "wascontained":Z
    invoke-virtual {p0, p1}, Lcom/thinkware/sundo/ieve/ieveTextView;->getFontAttb(I)Lcom/thinkware/sundo/ieve/a;

    move-result-object v0

    .line 94
    .local v0, "fontattb":Lcom/thinkware/sundo/ieve/a;
    if-nez v0, :cond_0

    new-instance v0, Lcom/thinkware/sundo/ieve/a;

    .end local v0    # "fontattb":Lcom/thinkware/sundo/ieve/a;
    invoke-direct {v0}, Lcom/thinkware/sundo/ieve/a;-><init>()V

    .restart local v0    # "fontattb":Lcom/thinkware/sundo/ieve/a;
    :cond_0
    move-object v1, p2

    move/from16 v2, p3

    move/from16 v3, p4

    move/from16 v4, p5

    move/from16 v5, p6

    move/from16 v6, p7

    move/from16 v7, p8

    move/from16 v8, p9

    move/from16 v9, p10

    move/from16 v10, p11

    move-object/from16 v11, p12

    .line 95
    invoke-virtual/range {v0 .. v11}, Lcom/thinkware/sundo/ieve/a;->a(Ljava/lang/String;FFFIZZZIILandroid/graphics/Typeface;)V

    .line 96
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/ieveTextView;->d:Ljava/util/TreeMap;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v1, v2, v0}, Ljava/util/TreeMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 97
    if-nez v12, :cond_1

    const/4 v1, 0x1

    iput-boolean v1, p0, Lcom/thinkware/sundo/ieve/ieveTextView;->e:Z

    .line 98
    :cond_1
    return-void
.end method

.method public removeAllTexts()V
    .locals 2

    .prologue
    .line 107
    sget-object v0, Lcom/thinkware/sundo/ieve/ieveTextView;->a:Ljava/lang/String;

    const-string v1, "removeAllTexts"

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 108
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveTextView;->d:Ljava/util/TreeMap;

    invoke-virtual {v0}, Ljava/util/TreeMap;->clear()V

    .line 109
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/thinkware/sundo/ieve/ieveTextView;->e:Z

    .line 110
    return-void
.end method

.method public removeText(I)V
    .locals 6
    .param p1, "index"    # I

    .prologue
    const/4 v5, 0x1

    .line 113
    sget-object v0, Lcom/thinkware/sundo/ieve/ieveTextView;->a:Ljava/lang/String;

    const-string v1, "removeText[%d]"

    new-array v2, v5, [Ljava/lang/Object;

    const/4 v3, 0x0

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    aput-object v4, v2, v3

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 114
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveTextView;->d:Ljava/util/TreeMap;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/TreeMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 115
    iput-boolean v5, p0, Lcom/thinkware/sundo/ieve/ieveTextView;->e:Z

    .line 116
    return-void
.end method

.method public setAspectRatioView(FF)V
    .locals 5
    .param p1, "sx"    # F
    .param p2, "sy"    # F

    .prologue
    .line 101
    sget-object v0, Lcom/thinkware/sundo/ieve/ieveTextView;->a:Ljava/lang/String;

    const-string v1, "setAspectRatioView[%.2f,%.2f]"

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    invoke-static {p1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v4

    aput-object v4, v2, v3

    const/4 v3, 0x1

    invoke-static {p2}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v4

    aput-object v4, v2, v3

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 102
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveTextView;->f:Landroid/graphics/PointF;

    iput p1, v0, Landroid/graphics/PointF;->x:F

    .line 103
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveTextView;->f:Landroid/graphics/PointF;

    iput p2, v0, Landroid/graphics/PointF;->y:F

    .line 104
    return-void
.end method
