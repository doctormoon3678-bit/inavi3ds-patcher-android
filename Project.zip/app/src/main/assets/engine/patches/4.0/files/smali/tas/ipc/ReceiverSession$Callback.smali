.class public interface abstract Ltas/ipc/ReceiverSession$Callback;
.super Ljava/lang/Object;
.source "ReceiverSession.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltas/ipc/ReceiverSession;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "Callback"
.end annotation


# virtual methods
.method public abstract onReceive(Ltas/ipc/ReceiverSession;ILtas/ipc/MsgData;)V
.end method

.method public abstract onSenderOffline(Ltas/ipc/ReceiverSession;)V
.end method

.method public abstract onSenderOnline(Ltas/ipc/ReceiverSession;)V
.end method

.method public abstract onSenderUpdate(Ltas/ipc/ReceiverSession;Landroid/os/Bundle;)V
.end method
