.class Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR$10;
.super Ljava/lang/Object;
.source "DestArriveGuideAR.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;->SetData(Lcom/thinkware/sundo/inavi3d/Struct/DestInfo;Lcom/thinkware/sundo/inavi3d/OBD2/OBD2GoalInfo;Lcom/thinkware/sundo/inavi3d/INavi3DActivity;Z)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;


# direct methods
.method constructor <init>(Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;)V
    .locals 0

    .prologue
    .line 1245
    iput-object p1, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR$10;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 4

    .prologue
    const/4 v3, 0x0

    .line 1249
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR$10;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;

    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR$10;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;

    invoke-static {v1}, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;->access$500(Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;)Landroid/content/res/Resources;

    move-result-object v1

    const v2, 0x7f02000e

    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 1250
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR$10;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;->DestInfoDetail:Landroid/widget/Button;

    invoke-virtual {v0, v3}, Landroid/widget/Button;->setVisibility(I)V

    .line 1251
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR$10;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;->DestInfoAround:Landroid/widget/Button;

    invoke-virtual {v0, v3}, Landroid/widget/Button;->setVisibility(I)V

    .line 1252
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR$10;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;->DestInfoRoadview:Landroid/widget/Button;

    invoke-virtual {v0, v3}, Landroid/widget/Button;->setVisibility(I)V

    .line 1253
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR$10;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;->DestInfoFivepin:Landroid/widget/Button;

    invoke-virtual {v0, v3}, Landroid/widget/Button;->setVisibility(I)V

    .line 1254
    return-void
.end method
