.class public Lcom/thinkware/sundo/ieve/ieveGuideInfos;
.super Ljava/lang/Object;
.source "ieveGuideInfos.java"

# interfaces
.implements Ljava/lang/Cloneable;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/thinkware/sundo/ieve/ieveGuideInfos$CONSTZONE_TYPE;,
        Lcom/thinkware/sundo/ieve/ieveGuideInfos$IEVE_INTERMEDIATE_KIND;,
        Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADSPEC;,
        Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADTYPE;,
        Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERAAREA_KIND;,
        Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;,
        Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;,
        Lcom/thinkware/sundo/ieve/ieveGuideInfos$SCHOOL_TYPE;,
        Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;
    }
.end annotation


# instance fields
.field public constzone_len:I

.field public constzone_speed:I

.field public constzone_status:I

.field public constzone_type:I

.field public goal_pos_x:F

.field public goal_pos_y:F

.field public goal_pos_z:F

.field public intermediate_dist:I

.field public intermediate_kind:I

.field public noentry_angle:F

.field public noentry_enable:Z

.field public noentry_pos_x:F

.field public noentry_pos_y:F

.field public noentry_pos_z:F

.field public roadattrib_roadnumlane:I

.field public roadattrib_roadspec:I

.field public roadattrib_roadtype:I

.field public safecamera_angle:I

.field public safecamera_dist:I

.field public safecamera_kind:I

.field public safecamera_leader:I

.field public safecamera_pos_x:F

.field public safecamera_pos_y:F

.field public safecamera_pos_z:F

.field public safecamera_speedlimit:I

.field public safecameraarea_dist:I

.field public safecameraarea_isredbox:I

.field public safecameraarea_kind:I

.field public safecameraarea_speedavr:I

.field public safecameraarea_speedlimit:I

.field public safecameraarea_speedrecom:I

.field public safeguide_kind:I

.field public safeguide_pos_x:F

.field public safeguide_pos_y:F

.field public safeguide_pos_z:F

.field public schoolzone_len:I

.field public schoolzone_speed:I

.field public schoolzone_status:I

.field public schoolzone_type:I

.field public start_pos_x:F

.field public start_pos_y:F

.field public start_pos_z:F

.field public startgoal_enable:Z

.field public turnpoint_code:I

.field public turnpoint_dist:I

.field public turnpoint_nameway:Ljava/lang/String;

.field public turnpoint_pos_x:F

.field public turnpoint_pos_y:F

.field public turnpoint_pos_z:F

.field public turnpoint_roadnumlane:I

.field public turnpoint_syncsignal:I


# direct methods
.method public constructor <init>()V
    .locals 3

    .prologue
    const/4 v2, 0x0

    const/4 v1, 0x0

    .line 292
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 221
    iput-boolean v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->startgoal_enable:Z

    .line 222
    iput v2, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->start_pos_x:F

    .line 223
    iput v2, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->start_pos_y:F

    .line 224
    iput v2, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->start_pos_z:F

    .line 225
    iput v2, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->goal_pos_x:F

    .line 226
    iput v2, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->goal_pos_y:F

    .line 227
    iput v2, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->goal_pos_z:F

    .line 230
    iput-boolean v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->noentry_enable:Z

    .line 231
    iput v2, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->noentry_pos_x:F

    .line 232
    iput v2, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->noentry_pos_y:F

    .line 233
    iput v2, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->noentry_pos_z:F

    .line 234
    iput v2, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->noentry_angle:F

    .line 237
    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->roadattrib_roadtype:I

    .line 238
    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->roadattrib_roadspec:I

    .line 239
    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->roadattrib_roadnumlane:I

    .line 242
    iput v2, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->turnpoint_pos_x:F

    .line 243
    iput v2, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->turnpoint_pos_y:F

    .line 244
    iput v2, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->turnpoint_pos_z:F

    .line 245
    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->turnpoint_code:I

    .line 246
    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->turnpoint_dist:I

    .line 247
    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->turnpoint_syncsignal:I

    .line 248
    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->turnpoint_roadnumlane:I

    .line 249
    const-string v0, ""

    iput-object v0, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->turnpoint_nameway:Ljava/lang/String;

    .line 252
    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->intermediate_kind:I

    .line 253
    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->intermediate_dist:I

    .line 256
    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecamera_kind:I

    .line 257
    iput v2, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecamera_pos_x:F

    .line 258
    iput v2, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecamera_pos_y:F

    .line 259
    iput v2, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecamera_pos_z:F

    .line 260
    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecamera_dist:I

    .line 261
    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecamera_speedlimit:I

    .line 262
    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecamera_angle:I

    .line 263
    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecamera_leader:I

    .line 266
    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecameraarea_kind:I

    .line 267
    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecameraarea_dist:I

    .line 268
    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecameraarea_speedlimit:I

    .line 269
    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecameraarea_speedrecom:I

    .line 270
    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecameraarea_speedavr:I

    .line 271
    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecameraarea_isredbox:I

    .line 274
    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safeguide_kind:I

    .line 275
    iput v2, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safeguide_pos_x:F

    .line 276
    iput v2, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safeguide_pos_y:F

    .line 277
    iput v2, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safeguide_pos_z:F

    .line 280
    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->schoolzone_speed:I

    .line 281
    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->schoolzone_len:I

    .line 282
    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->schoolzone_type:I

    .line 283
    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->schoolzone_status:I

    .line 286
    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->constzone_speed:I

    .line 287
    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->constzone_len:I

    .line 288
    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->constzone_type:I

    .line 289
    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->constzone_status:I

    .line 293
    invoke-virtual {p0}, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->clear()V

    .line 294
    return-void
.end method


# virtual methods
.method public clear()V
    .locals 3

    .prologue
    const/4 v0, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x0

    .line 297
    iput-boolean v0, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->startgoal_enable:Z

    .line 298
    iput v2, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->start_pos_x:F

    .line 299
    iput v2, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->start_pos_y:F

    .line 300
    iput v2, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->start_pos_z:F

    .line 301
    iput v2, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->goal_pos_x:F

    .line 302
    iput v2, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->goal_pos_y:F

    .line 303
    iput v2, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->goal_pos_z:F

    .line 305
    iput-boolean v0, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->noentry_enable:Z

    .line 306
    iput v2, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->noentry_pos_x:F

    .line 307
    iput v2, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->noentry_pos_y:F

    .line 308
    iput v2, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->noentry_pos_z:F

    .line 309
    iput v2, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->noentry_angle:F

    .line 311
    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->roadattrib_roadtype:I

    .line 312
    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->roadattrib_roadspec:I

    .line 313
    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->roadattrib_roadnumlane:I

    .line 315
    iput v2, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->turnpoint_pos_x:F

    .line 316
    iput v2, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->turnpoint_pos_y:F

    .line 317
    iput v2, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->turnpoint_pos_z:F

    .line 318
    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->turnpoint_code:I

    .line 319
    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->turnpoint_dist:I

    .line 320
    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->turnpoint_syncsignal:I

    .line 321
    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->turnpoint_roadnumlane:I

    .line 322
    const-string v0, ""

    iput-object v0, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->turnpoint_nameway:Ljava/lang/String;

    .line 324
    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->intermediate_kind:I

    .line 325
    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->intermediate_dist:I

    .line 327
    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecamera_kind:I

    .line 328
    iput v2, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecamera_pos_x:F

    .line 329
    iput v2, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecamera_pos_y:F

    .line 330
    iput v2, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecamera_pos_z:F

    .line 331
    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecamera_dist:I

    .line 332
    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecamera_speedlimit:I

    .line 333
    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecamera_angle:I

    .line 334
    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecamera_leader:I

    .line 336
    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecameraarea_kind:I

    .line 337
    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecameraarea_dist:I

    .line 338
    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecameraarea_speedlimit:I

    .line 339
    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecameraarea_speedrecom:I

    .line 340
    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecameraarea_speedavr:I

    .line 341
    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecameraarea_isredbox:I

    .line 343
    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safeguide_kind:I

    .line 344
    iput v2, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safeguide_pos_x:F

    .line 345
    iput v2, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safeguide_pos_y:F

    .line 346
    iput v2, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safeguide_pos_z:F

    .line 348
    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->schoolzone_speed:I

    .line 349
    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->schoolzone_len:I

    .line 350
    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->schoolzone_type:I

    .line 351
    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->schoolzone_status:I

    .line 353
    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->constzone_speed:I

    .line 354
    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->constzone_len:I

    .line 355
    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->constzone_type:I

    .line 356
    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->constzone_status:I

    .line 357
    return-void
.end method

.method public clone()Lcom/thinkware/sundo/ieve/ieveGuideInfos;
    .locals 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/CloneNotSupportedException;
        }
    .end annotation

    .prologue
    .line 361
    invoke-super {p0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;

    .line 363
    .local v0, "guide":Lcom/thinkware/sundo/ieve/ieveGuideInfos;
    iget-boolean v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->startgoal_enable:Z

    iput-boolean v1, v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->startgoal_enable:Z

    .line 364
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->start_pos_x:F

    iput v1, v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->start_pos_x:F

    .line 365
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->start_pos_y:F

    iput v1, v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->start_pos_y:F

    .line 366
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->start_pos_z:F

    iput v1, v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->start_pos_z:F

    .line 367
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->goal_pos_x:F

    iput v1, v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->goal_pos_x:F

    .line 368
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->goal_pos_y:F

    iput v1, v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->goal_pos_y:F

    .line 369
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->goal_pos_z:F

    iput v1, v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->goal_pos_z:F

    .line 371
    iget-boolean v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->noentry_enable:Z

    iput-boolean v1, v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->noentry_enable:Z

    .line 372
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->noentry_pos_x:F

    iput v1, v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->noentry_pos_x:F

    .line 373
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->noentry_pos_y:F

    iput v1, v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->noentry_pos_y:F

    .line 374
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->noentry_pos_z:F

    iput v1, v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->noentry_pos_z:F

    .line 375
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->noentry_angle:F

    iput v1, v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->noentry_angle:F

    .line 377
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->roadattrib_roadtype:I

    iput v1, v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->roadattrib_roadtype:I

    .line 378
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->roadattrib_roadspec:I

    iput v1, v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->roadattrib_roadspec:I

    .line 379
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->roadattrib_roadnumlane:I

    iput v1, v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->roadattrib_roadnumlane:I

    .line 381
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->turnpoint_pos_x:F

    iput v1, v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->turnpoint_pos_x:F

    .line 382
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->turnpoint_pos_y:F

    iput v1, v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->turnpoint_pos_y:F

    .line 383
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->turnpoint_pos_z:F

    iput v1, v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->turnpoint_pos_z:F

    .line 384
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->turnpoint_code:I

    iput v1, v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->turnpoint_code:I

    .line 385
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->turnpoint_dist:I

    iput v1, v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->turnpoint_dist:I

    .line 386
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->turnpoint_syncsignal:I

    iput v1, v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->turnpoint_syncsignal:I

    .line 387
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->turnpoint_roadnumlane:I

    iput v1, v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->turnpoint_roadnumlane:I

    .line 388
    const-string v1, "%s"

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    iget-object v4, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->turnpoint_nameway:Ljava/lang/String;

    aput-object v4, v2, v3

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    iput-object v1, v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->turnpoint_nameway:Ljava/lang/String;

    .line 390
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->intermediate_kind:I

    iput v1, v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->intermediate_kind:I

    .line 391
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->intermediate_dist:I

    iput v1, v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->intermediate_dist:I

    .line 393
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecamera_kind:I

    iput v1, v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecamera_kind:I

    .line 394
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecamera_pos_x:F

    iput v1, v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecamera_pos_x:F

    .line 395
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecamera_pos_y:F

    iput v1, v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecamera_pos_y:F

    .line 396
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecamera_pos_z:F

    iput v1, v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecamera_pos_z:F

    .line 397
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecamera_dist:I

    iput v1, v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecamera_dist:I

    .line 398
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecamera_speedlimit:I

    iput v1, v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecamera_speedlimit:I

    .line 399
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecamera_angle:I

    iput v1, v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecamera_angle:I

    .line 400
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecamera_leader:I

    iput v1, v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecamera_leader:I

    .line 402
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecameraarea_kind:I

    iput v1, v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecameraarea_kind:I

    .line 403
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecameraarea_dist:I

    iput v1, v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecameraarea_dist:I

    .line 404
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecameraarea_speedlimit:I

    iput v1, v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecameraarea_speedlimit:I

    .line 405
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecameraarea_speedrecom:I

    iput v1, v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecameraarea_speedrecom:I

    .line 406
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecameraarea_speedavr:I

    iput v1, v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecameraarea_speedavr:I

    .line 407
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecameraarea_isredbox:I

    iput v1, v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecameraarea_isredbox:I

    .line 409
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safeguide_kind:I

    iput v1, v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safeguide_kind:I

    .line 410
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safeguide_pos_x:F

    iput v1, v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safeguide_pos_x:F

    .line 411
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safeguide_pos_y:F

    iput v1, v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safeguide_pos_y:F

    .line 412
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safeguide_pos_z:F

    iput v1, v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safeguide_pos_z:F

    .line 414
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->schoolzone_speed:I

    iput v1, v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->schoolzone_speed:I

    .line 415
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->schoolzone_len:I

    iput v1, v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->schoolzone_len:I

    .line 416
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->schoolzone_type:I

    iput v1, v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->schoolzone_type:I

    .line 417
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->schoolzone_status:I

    iput v1, v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->schoolzone_status:I

    .line 419
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->constzone_speed:I

    iput v1, v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->constzone_speed:I

    .line 420
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->constzone_len:I

    iput v1, v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->constzone_len:I

    .line 421
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->constzone_type:I

    iput v1, v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->constzone_type:I

    .line 422
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->constzone_status:I

    iput v1, v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->constzone_status:I

    .line 424
    return-object v0
.end method

.method public bridge synthetic clone()Ljava/lang/Object;
    .locals 1
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/CloneNotSupportedException;
        }
    .end annotation

    .prologue
    .line 1
    invoke-virtual {p0}, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->clone()Lcom/thinkware/sundo/ieve/ieveGuideInfos;

    move-result-object v0

    return-object v0
.end method

.method public copy(Lcom/thinkware/sundo/ieve/ieveGuideInfos;)V
    .locals 4
    .param p1, "guide"    # Lcom/thinkware/sundo/ieve/ieveGuideInfos;

    .prologue
    .line 428
    if-nez p1, :cond_0

    .line 490
    :goto_0
    return-void

    .line 430
    :cond_0
    iget-boolean v0, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->startgoal_enable:Z

    iput-boolean v0, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->startgoal_enable:Z

    .line 431
    iget v0, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->start_pos_x:F

    iput v0, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->start_pos_x:F

    .line 432
    iget v0, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->start_pos_y:F

    iput v0, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->start_pos_y:F

    .line 433
    iget v0, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->start_pos_z:F

    iput v0, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->start_pos_z:F

    .line 434
    iget v0, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->goal_pos_x:F

    iput v0, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->goal_pos_x:F

    .line 435
    iget v0, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->goal_pos_y:F

    iput v0, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->goal_pos_y:F

    .line 436
    iget v0, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->goal_pos_z:F

    iput v0, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->goal_pos_z:F

    .line 438
    iget-boolean v0, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->noentry_enable:Z

    iput-boolean v0, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->noentry_enable:Z

    .line 439
    iget v0, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->noentry_pos_x:F

    iput v0, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->noentry_pos_x:F

    .line 440
    iget v0, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->noentry_pos_y:F

    iput v0, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->noentry_pos_y:F

    .line 441
    iget v0, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->noentry_pos_z:F

    iput v0, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->noentry_pos_z:F

    .line 442
    iget v0, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->noentry_angle:F

    iput v0, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->noentry_angle:F

    .line 444
    iget v0, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->roadattrib_roadtype:I

    iput v0, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->roadattrib_roadtype:I

    .line 445
    iget v0, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->roadattrib_roadspec:I

    iput v0, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->roadattrib_roadspec:I

    .line 446
    iget v0, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->roadattrib_roadnumlane:I

    iput v0, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->roadattrib_roadnumlane:I

    .line 448
    iget v0, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->turnpoint_pos_x:F

    iput v0, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->turnpoint_pos_x:F

    .line 449
    iget v0, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->turnpoint_pos_y:F

    iput v0, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->turnpoint_pos_y:F

    .line 450
    iget v0, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->turnpoint_pos_z:F

    iput v0, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->turnpoint_pos_z:F

    .line 451
    iget v0, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->turnpoint_code:I

    iput v0, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->turnpoint_code:I

    .line 452
    iget v0, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->turnpoint_dist:I

    iput v0, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->turnpoint_dist:I

    .line 453
    iget v0, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->turnpoint_syncsignal:I

    iput v0, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->turnpoint_syncsignal:I

    .line 454
    iget v0, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->turnpoint_roadnumlane:I

    iput v0, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->turnpoint_roadnumlane:I

    .line 455
    const-string v0, "%s"

    const/4 v1, 0x1

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v2, 0x0

    iget-object v3, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->turnpoint_nameway:Ljava/lang/String;

    aput-object v3, v1, v2

    invoke-static {v0, v1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->turnpoint_nameway:Ljava/lang/String;

    .line 457
    iget v0, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->intermediate_kind:I

    iput v0, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->intermediate_kind:I

    .line 458
    iget v0, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->intermediate_dist:I

    iput v0, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->intermediate_dist:I

    .line 460
    iget v0, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecamera_kind:I

    iput v0, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecamera_kind:I

    .line 461
    iget v0, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecamera_pos_x:F

    iput v0, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecamera_pos_x:F

    .line 462
    iget v0, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecamera_pos_y:F

    iput v0, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecamera_pos_y:F

    .line 463
    iget v0, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecamera_pos_z:F

    iput v0, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecamera_pos_z:F

    .line 464
    iget v0, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecamera_dist:I

    iput v0, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecamera_dist:I

    .line 465
    iget v0, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecamera_speedlimit:I

    iput v0, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecamera_speedlimit:I

    .line 466
    iget v0, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecamera_angle:I

    iput v0, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecamera_angle:I

    .line 467
    iget v0, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecamera_leader:I

    iput v0, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecamera_leader:I

    .line 469
    iget v0, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecameraarea_kind:I

    iput v0, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecameraarea_kind:I

    .line 470
    iget v0, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecameraarea_dist:I

    iput v0, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecameraarea_dist:I

    .line 471
    iget v0, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecameraarea_speedlimit:I

    iput v0, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecameraarea_speedlimit:I

    .line 472
    iget v0, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecameraarea_speedrecom:I

    iput v0, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecameraarea_speedrecom:I

    .line 473
    iget v0, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecameraarea_speedavr:I

    iput v0, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecameraarea_speedavr:I

    .line 474
    iget v0, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecameraarea_isredbox:I

    iput v0, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecameraarea_isredbox:I

    .line 476
    iget v0, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safeguide_kind:I

    iput v0, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safeguide_kind:I

    .line 477
    iget v0, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safeguide_pos_x:F

    iput v0, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safeguide_pos_x:F

    .line 478
    iget v0, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safeguide_pos_y:F

    iput v0, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safeguide_pos_y:F

    .line 479
    iget v0, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safeguide_pos_z:F

    iput v0, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safeguide_pos_z:F

    .line 481
    iget v0, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->schoolzone_speed:I

    iput v0, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->schoolzone_speed:I

    .line 482
    iget v0, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->schoolzone_len:I

    iput v0, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->schoolzone_len:I

    .line 483
    iget v0, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->schoolzone_type:I

    iput v0, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->schoolzone_type:I

    .line 484
    iget v0, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->schoolzone_status:I

    iput v0, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->schoolzone_status:I

    .line 486
    iget v0, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->constzone_speed:I

    iput v0, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->constzone_speed:I

    .line 487
    iget v0, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->constzone_len:I

    iput v0, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->constzone_len:I

    .line 488
    iget v0, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->constzone_type:I

    iput v0, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->constzone_type:I

    .line 489
    iget v0, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->constzone_status:I

    iput v0, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->constzone_status:I

    goto/16 :goto_0
.end method

.method public equal(Lcom/thinkware/sundo/ieve/ieveGuideInfos;)Z
    .locals 3
    .param p1, "guide"    # Lcom/thinkware/sundo/ieve/ieveGuideInfos;

    .prologue
    const/4 v0, 0x0

    .line 493
    if-nez p1, :cond_1

    .line 559
    :cond_0
    :goto_0
    return v0

    .line 495
    :cond_1
    iget-boolean v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->startgoal_enable:Z

    iget-boolean v2, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->startgoal_enable:Z

    if-ne v1, v2, :cond_0

    .line 496
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->start_pos_x:F

    iget v2, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->start_pos_x:F

    cmpl-float v1, v1, v2

    if-nez v1, :cond_0

    .line 497
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->start_pos_y:F

    iget v2, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->start_pos_y:F

    cmpl-float v1, v1, v2

    if-nez v1, :cond_0

    .line 498
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->start_pos_z:F

    iget v2, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->start_pos_z:F

    cmpl-float v1, v1, v2

    if-nez v1, :cond_0

    .line 499
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->goal_pos_x:F

    iget v2, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->goal_pos_x:F

    cmpl-float v1, v1, v2

    if-nez v1, :cond_0

    .line 500
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->goal_pos_y:F

    iget v2, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->goal_pos_y:F

    cmpl-float v1, v1, v2

    if-nez v1, :cond_0

    .line 501
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->goal_pos_z:F

    iget v2, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->goal_pos_z:F

    cmpl-float v1, v1, v2

    if-nez v1, :cond_0

    .line 503
    iget-boolean v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->noentry_enable:Z

    iget-boolean v2, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->noentry_enable:Z

    if-ne v1, v2, :cond_0

    .line 504
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->noentry_pos_x:F

    iget v2, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->noentry_pos_x:F

    cmpl-float v1, v1, v2

    if-nez v1, :cond_0

    .line 505
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->noentry_pos_y:F

    iget v2, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->noentry_pos_y:F

    cmpl-float v1, v1, v2

    if-nez v1, :cond_0

    .line 506
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->noentry_pos_z:F

    iget v2, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->noentry_pos_z:F

    cmpl-float v1, v1, v2

    if-nez v1, :cond_0

    .line 507
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->noentry_angle:F

    iget v2, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->noentry_angle:F

    cmpl-float v1, v1, v2

    if-nez v1, :cond_0

    .line 509
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->roadattrib_roadtype:I

    iget v2, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->roadattrib_roadtype:I

    if-ne v1, v2, :cond_0

    .line 510
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->roadattrib_roadspec:I

    iget v2, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->roadattrib_roadspec:I

    if-ne v1, v2, :cond_0

    .line 511
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->roadattrib_roadnumlane:I

    iget v2, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->roadattrib_roadnumlane:I

    if-ne v1, v2, :cond_0

    .line 513
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->turnpoint_pos_x:F

    iget v2, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->turnpoint_pos_x:F

    cmpl-float v1, v1, v2

    if-nez v1, :cond_0

    .line 514
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->turnpoint_pos_y:F

    iget v2, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->turnpoint_pos_y:F

    cmpl-float v1, v1, v2

    if-nez v1, :cond_0

    .line 515
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->turnpoint_pos_z:F

    iget v2, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->turnpoint_pos_z:F

    cmpl-float v1, v1, v2

    if-nez v1, :cond_0

    .line 516
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->turnpoint_code:I

    iget v2, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->turnpoint_code:I

    if-ne v1, v2, :cond_0

    .line 517
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->turnpoint_dist:I

    iget v2, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->turnpoint_dist:I

    if-ne v1, v2, :cond_0

    .line 518
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->turnpoint_syncsignal:I

    iget v2, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->turnpoint_syncsignal:I

    if-ne v1, v2, :cond_0

    .line 519
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->turnpoint_roadnumlane:I

    iget v2, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->turnpoint_roadnumlane:I

    if-ne v1, v2, :cond_0

    .line 520
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->turnpoint_nameway:Ljava/lang/String;

    iget-object v2, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->turnpoint_nameway:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_0

    .line 522
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->intermediate_kind:I

    iget v2, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->intermediate_kind:I

    if-ne v1, v2, :cond_0

    .line 523
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->intermediate_dist:I

    iget v2, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->intermediate_dist:I

    if-ne v1, v2, :cond_0

    .line 525
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecamera_kind:I

    iget v2, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecamera_kind:I

    if-ne v1, v2, :cond_0

    .line 526
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecamera_pos_x:F

    iget v2, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecamera_pos_x:F

    cmpl-float v1, v1, v2

    if-nez v1, :cond_0

    .line 527
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecamera_pos_y:F

    iget v2, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecamera_pos_y:F

    cmpl-float v1, v1, v2

    if-nez v1, :cond_0

    .line 528
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecamera_pos_z:F

    iget v2, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecamera_pos_z:F

    cmpl-float v1, v1, v2

    if-nez v1, :cond_0

    .line 529
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecamera_dist:I

    iget v2, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecamera_dist:I

    if-ne v1, v2, :cond_0

    .line 530
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecamera_speedlimit:I

    iget v2, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecamera_speedlimit:I

    if-ne v1, v2, :cond_0

    .line 531
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecamera_angle:I

    iget v2, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecamera_angle:I

    if-ne v1, v2, :cond_0

    .line 532
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecamera_leader:I

    iget v2, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecamera_leader:I

    if-ne v1, v2, :cond_0

    .line 534
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecameraarea_kind:I

    iget v2, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecameraarea_kind:I

    if-ne v1, v2, :cond_0

    .line 535
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecameraarea_dist:I

    iget v2, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecameraarea_dist:I

    if-ne v1, v2, :cond_0

    .line 536
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecameraarea_speedlimit:I

    iget v2, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecameraarea_speedlimit:I

    if-ne v1, v2, :cond_0

    .line 537
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecameraarea_speedrecom:I

    iget v2, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecameraarea_speedrecom:I

    if-ne v1, v2, :cond_0

    .line 538
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecameraarea_speedavr:I

    iget v2, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecameraarea_speedavr:I

    if-ne v1, v2, :cond_0

    .line 539
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecameraarea_isredbox:I

    iget v2, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecameraarea_isredbox:I

    if-ne v1, v2, :cond_0

    .line 541
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safeguide_kind:I

    iget v2, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safeguide_kind:I

    if-ne v1, v2, :cond_0

    .line 542
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safeguide_pos_x:F

    iget v2, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safeguide_pos_x:F

    cmpl-float v1, v1, v2

    if-nez v1, :cond_0

    .line 543
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safeguide_pos_y:F

    iget v2, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safeguide_pos_y:F

    cmpl-float v1, v1, v2

    if-nez v1, :cond_0

    .line 544
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safeguide_pos_z:F

    iget v2, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safeguide_pos_z:F

    cmpl-float v1, v1, v2

    if-nez v1, :cond_0

    .line 546
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->schoolzone_speed:I

    iget v2, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->schoolzone_speed:I

    if-ne v1, v2, :cond_0

    .line 547
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->schoolzone_len:I

    iget v2, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->schoolzone_len:I

    if-ne v1, v2, :cond_0

    .line 548
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->schoolzone_type:I

    iget v2, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->schoolzone_type:I

    if-ne v1, v2, :cond_0

    .line 549
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->schoolzone_status:I

    iget v2, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->schoolzone_status:I

    if-ne v1, v2, :cond_0

    .line 551
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->constzone_speed:I

    iget v2, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->constzone_speed:I

    if-ne v1, v2, :cond_0

    .line 552
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->constzone_len:I

    iget v2, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->constzone_len:I

    if-ne v1, v2, :cond_0

    .line 553
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->constzone_type:I

    iget v2, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->constzone_type:I

    if-ne v1, v2, :cond_0

    .line 554
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->constzone_status:I

    iget v2, p1, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->constzone_status:I

    if-ne v1, v2, :cond_0

    .line 559
    const/4 v0, 0x1

    goto/16 :goto_0
.end method
