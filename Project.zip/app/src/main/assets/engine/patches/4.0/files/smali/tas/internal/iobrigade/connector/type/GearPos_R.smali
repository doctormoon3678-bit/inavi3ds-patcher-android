.class public final Ltas/internal/iobrigade/connector/type/GearPos_R;
.super Ljava/lang/Object;
.source "GearPos_R.java"


# direct methods
.method public constructor <init>()V
    .locals 0

    .prologue
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
