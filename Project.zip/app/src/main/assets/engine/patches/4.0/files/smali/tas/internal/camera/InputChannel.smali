.class Ltas/internal/camera/InputChannel;
.super Ljava/lang/Object;
.source "InputChannel.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ltas/internal/camera/InputChannel$Guardian;
    }
.end annotation


# static fields
.field private static final DBG:Z = true

.field private static final sUnknownCamids:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List",
            "<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private TAG:Ljava/lang/String;

.field final id:I

.field private mCurrInput:Ltas/internal/camera/InputSourceInner;

.field private mCurrProc:Ljava/lang/String;

.field private mDispatcher:Ltas/internal/camera/Dispatcher;

.field private mGuardian:Ltas/internal/camera/InputChannel$Guardian;

.field private final mLock:Ljava/lang/Object;

.field private mMediaServerDied:Z

.field private mMonitor:Ltas/internal/camera/util/CameraMonitor;

.field private mRootInput:Ltas/internal/camera/InputSourceInner;


# direct methods
.method static synthetic -set0(Ltas/internal/camera/InputChannel;Ltas/internal/camera/InputSourceInner;)Ltas/internal/camera/InputSourceInner;
    .locals 0

    iput-object p1, p0, Ltas/internal/camera/InputChannel;->mCurrInput:Ltas/internal/camera/InputSourceInner;

    return-object p1
.end method

.method static synthetic -set1(Ltas/internal/camera/InputChannel;Ljava/lang/String;)Ljava/lang/String;
    .locals 0

    iput-object p1, p0, Ltas/internal/camera/InputChannel;->mCurrProc:Ljava/lang/String;

    return-object p1
.end method

.method static constructor <clinit>()V
    .locals 2

    .prologue
    .line 647
    new-instance v0, Ljava/util/ArrayList;

    const/4 v1, 0x2

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    .line 646
    sput-object v0, Ltas/internal/camera/InputChannel;->sUnknownCamids:Ljava/util/List;

    .line 20
    return-void
.end method

.method constructor <init>(ILtas/internal/camera/InputSource;Ltas/internal/camera/Dispatcher;Ltas/internal/camera/util/CameraMonitor;)V
    .locals 2
    .param p1, "_id"    # I
    .param p2, "input"    # Ltas/internal/camera/InputSource;
    .param p3, "dispatcher"    # Ltas/internal/camera/Dispatcher;
    .param p4, "monitor"    # Ltas/internal/camera/util/CameraMonitor;

    .prologue
    .line 35
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 22
    const-string/jumbo v0, "TasCAM<InputChannel>"

    iput-object v0, p0, Ltas/internal/camera/InputChannel;->TAG:Ljava/lang/String;

    .line 33
    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, Ltas/internal/camera/InputChannel;->mLock:Ljava/lang/Object;

    .line 40
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v1, p0, Ltas/internal/camera/InputChannel;->TAG:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string/jumbo v1, "."

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Ltas/internal/camera/InputChannel;->TAG:Ljava/lang/String;

    .line 41
    iput p1, p0, Ltas/internal/camera/InputChannel;->id:I

    .line 42
    iget-object v0, p2, Ltas/internal/camera/InputSource;->hook:Ltas/internal/camera/InputSource$Hook;

    iget-object v0, v0, Ltas/internal/camera/InputSource$Hook;->impl:Ltas/internal/camera/InputSourceInner;

    iput-object v0, p0, Ltas/internal/camera/InputChannel;->mRootInput:Ltas/internal/camera/InputSourceInner;

    .line 43
    iget-object v0, p0, Ltas/internal/camera/InputChannel;->mRootInput:Ltas/internal/camera/InputSourceInner;

    iput-object p0, v0, Ltas/internal/camera/InputSourceInner;->channel:Ltas/internal/camera/InputChannel;

    .line 44
    iput-object p3, p0, Ltas/internal/camera/InputChannel;->mDispatcher:Ltas/internal/camera/Dispatcher;

    .line 45
    iget-object v0, p0, Ltas/internal/camera/InputChannel;->mDispatcher:Ltas/internal/camera/Dispatcher;

    iput-object p0, v0, Ltas/internal/camera/Dispatcher;->channel:Ltas/internal/camera/InputChannel;

    .line 46
    iput-object p4, p0, Ltas/internal/camera/InputChannel;->mMonitor:Ltas/internal/camera/util/CameraMonitor;

    .line 48
    iget-object v0, p0, Ltas/internal/camera/InputChannel;->mRootInput:Ltas/internal/camera/InputSourceInner;

    invoke-virtual {v0}, Ltas/internal/camera/InputSourceInner;->hasQueue()Z

    move-result v0

    if-eqz v0, :cond_0

    .line 49
    iget-object v0, p0, Ltas/internal/camera/InputChannel;->mDispatcher:Ltas/internal/camera/Dispatcher;

    invoke-virtual {v0}, Ltas/internal/camera/Dispatcher;->initializeEventQueue()V

    .line 50
    invoke-virtual {p0}, Ltas/internal/camera/InputChannel;->initializeGuardian()V

    .line 38
    :cond_0
    return-void
.end method

.method static addUnknownOpenedCamid(I)V
    .locals 2
    .param p0, "camid"    # I

    .prologue
    .line 635
    sget-object v0, Ltas/internal/camera/InputChannel;->sUnknownCamids:Ljava/util/List;

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 634
    return-void
.end method

.method static isUnknownOpenedCamid(I)Z
    .locals 2
    .param p0, "camid"    # I

    .prologue
    .line 643
    sget-object v0, Ltas/internal/camera/InputChannel;->sUnknownCamids:Ljava/util/List;

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v0

    return v0
.end method

.method static removeUnknownOpenedCamid(I)V
    .locals 2
    .param p0, "camid"    # I

    .prologue
    .line 639
    sget-object v0, Ltas/internal/camera/InputChannel;->sUnknownCamids:Ljava/util/List;

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/List;->remove(Ljava/lang/Object;)Z

    .line 638
    return-void
.end method


# virtual methods
.method cancel(Ljava/lang/String;Ltas/internal/camera/InputParams;)I
    .locals 5
    .param p1, "proc"    # Ljava/lang/String;
    .param p2, "params"    # Ltas/internal/camera/InputParams;

    .prologue
    const/16 v4, -0xd

    const/4 v3, 0x0

    .line 291
    iget-object v1, p0, Ltas/internal/camera/InputChannel;->mRootInput:Ltas/internal/camera/InputSourceInner;

    iget-object v2, p2, Ltas/internal/camera/InputParams;->cam:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ltas/internal/camera/InputSourceInner;->findInput(Ljava/lang/String;)Ltas/internal/camera/InputSourceInner;

    move-result-object v0

    .line 292
    .local v0, "input":Ltas/internal/camera/InputSourceInner;
    if-nez v0, :cond_0

    .line 293
    const/4 v1, -0x5

    return v1

    .line 296
    :cond_0
    iget-object v1, p0, Ltas/internal/camera/InputChannel;->mCurrInput:Ltas/internal/camera/InputSourceInner;

    if-eqz v1, :cond_1

    iget-object v1, p0, Ltas/internal/camera/InputChannel;->mCurrInput:Ltas/internal/camera/InputSourceInner;

    if-eq v1, v0, :cond_2

    .line 297
    :cond_1
    return v4

    .line 300
    :cond_2
    iget-object v1, p0, Ltas/internal/camera/InputChannel;->mCurrProc:Ljava/lang/String;

    if-nez v1, :cond_3

    .line 301
    return v4

    .line 304
    :cond_3
    iget-object v1, p0, Ltas/internal/camera/InputChannel;->mCurrProc:Ljava/lang/String;

    invoke-virtual {v1, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_4

    .line 305
    const/4 v1, -0x8

    return v1

    .line 308
    :cond_4
    invoke-virtual {v0}, Ltas/internal/camera/InputSourceInner;->isOpened()Z

    move-result v1

    if-eqz v1, :cond_5

    .line 309
    const/16 v1, -0xe

    return v1

    .line 312
    :cond_5
    iget-object v1, p0, Ltas/internal/camera/InputChannel;->mGuardian:Ltas/internal/camera/InputChannel$Guardian;

    if-eqz v1, :cond_6

    .line 313
    iget-object v1, p0, Ltas/internal/camera/InputChannel;->mGuardian:Ltas/internal/camera/InputChannel$Guardian;

    invoke-static {v1}, Ltas/internal/camera/InputChannel$Guardian;->-wrap5(Ltas/internal/camera/InputChannel$Guardian;)V

    .line 316
    :cond_6
    iget-object v1, p0, Ltas/internal/camera/InputChannel;->mDispatcher:Ltas/internal/camera/Dispatcher;

    invoke-virtual {v1}, Ltas/internal/camera/Dispatcher;->resume()V

    .line 317
    iput-object v3, p0, Ltas/internal/camera/InputChannel;->mCurrInput:Ltas/internal/camera/InputSourceInner;

    .line 318
    iput-object v3, p0, Ltas/internal/camera/InputChannel;->mCurrProc:Ljava/lang/String;

    .line 320
    const/4 v1, 0x0

    return v1
.end method

.method collectInputs(I)Ljava/util/List;
    .locals 2
    .param p1, "camid"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)",
            "Ljava/util/List",
            "<",
            "Ltas/internal/camera/InputSourceInner;",
            ">;"
        }
    .end annotation

    .prologue
    .line 368
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 369
    .local v0, "list":Ljava/util/List;, "Ljava/util/List<Ltas/internal/camera/InputSourceInner;>;"
    iget-object v1, p0, Ltas/internal/camera/InputChannel;->mRootInput:Ltas/internal/camera/InputSourceInner;

    invoke-virtual {v1, v0, p1}, Ltas/internal/camera/InputSourceInner;->collectInputs(Ljava/util/List;I)V

    .line 370
    return-object v0
.end method

.method command(Ljava/lang/String;Ltas/internal/camera/InputParams;)I
    .locals 8
    .param p1, "proc"    # Ljava/lang/String;
    .param p2, "params"    # Ltas/internal/camera/InputParams;

    .prologue
    const/4 v7, 0x0

    .line 324
    iget-object v5, p0, Ltas/internal/camera/InputChannel;->mRootInput:Ltas/internal/camera/InputSourceInner;

    iget-object v6, p2, Ltas/internal/camera/InputParams;->cam:Ljava/lang/String;

    invoke-virtual {v5, v6}, Ltas/internal/camera/InputSourceInner;->findInput(Ljava/lang/String;)Ltas/internal/camera/InputSourceInner;

    move-result-object v2

    .line 325
    .local v2, "input":Ltas/internal/camera/InputSourceInner;
    invoke-virtual {p0, v2}, Ltas/internal/camera/InputChannel;->findPath(Ltas/internal/camera/InputSourceInner;)Ljava/util/List;

    move-result-object v3

    .line 326
    .local v3, "path":Ljava/util/List;, "Ljava/util/List<Ltas/internal/camera/InputSourceInner;>;"
    if-nez v3, :cond_0

    .line 327
    const/4 v5, -0x5

    return v5

    .line 329
    :cond_0
    const/4 v4, -0x1

    .line 330
    .local v4, "result":I
    new-array v5, v7, [Ltas/internal/camera/InputSourceInner;

    invoke-interface {v3, v5}, Ljava/util/List;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Ltas/internal/camera/InputSourceInner;

    .line 331
    .local v0, "array":[Ltas/internal/camera/InputSourceInner;
    array-length v5, v0

    add-int/lit8 v1, v5, -0x1

    .local v1, "i":I
    :goto_0
    if-ltz v1, :cond_1

    .line 332
    aget-object v5, v0, v1

    invoke-virtual {v5, v2, p2, p1}, Ltas/internal/camera/InputSourceInner;->command(Ltas/internal/camera/InputSourceInner;Ltas/internal/camera/InputParams;Ljava/lang/String;)I

    move-result v4

    .line 333
    if-nez v4, :cond_2

    .line 337
    :cond_1
    return v4

    .line 331
    :cond_2
    add-int/lit8 v1, v1, -0x1

    goto :goto_0
.end method

.method findCamid(Ljava/lang/String;)Ljava/lang/String;
    .locals 3
    .param p1, "camcls"    # Ljava/lang/String;

    .prologue
    const/4 v1, 0x0

    .line 341
    iget-object v2, p0, Ltas/internal/camera/InputChannel;->mRootInput:Ltas/internal/camera/InputSourceInner;

    invoke-virtual {v2, p1}, Ltas/internal/camera/InputSourceInner;->findInput(Ljava/lang/String;)Ltas/internal/camera/InputSourceInner;

    move-result-object v0

    .line 342
    .local v0, "input":Ltas/internal/camera/InputSourceInner;
    if-eqz v0, :cond_0

    iget-object v1, v0, Ltas/internal/camera/InputSourceInner;->camid:Ljava/lang/String;

    :cond_0
    return-object v1
.end method

.method findInput(Ljava/lang/String;)Ltas/internal/camera/InputSourceInner;
    .locals 1
    .param p1, "camcls"    # Ljava/lang/String;

    .prologue
    .line 346
    iget-object v0, p0, Ltas/internal/camera/InputChannel;->mRootInput:Ltas/internal/camera/InputSourceInner;

    invoke-virtual {v0, p1}, Ltas/internal/camera/InputSourceInner;->findInput(Ljava/lang/String;)Ltas/internal/camera/InputSourceInner;

    move-result-object v0

    return-object v0
.end method

.method findPath(Ljava/lang/String;)Ljava/util/List;
    .locals 2
    .param p1, "camcls"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")",
            "Ljava/util/List",
            "<",
            "Ltas/internal/camera/InputSourceInner;",
            ">;"
        }
    .end annotation

    .prologue
    .line 350
    iget-object v1, p0, Ltas/internal/camera/InputChannel;->mRootInput:Ltas/internal/camera/InputSourceInner;

    invoke-virtual {v1, p1}, Ltas/internal/camera/InputSourceInner;->findInput(Ljava/lang/String;)Ltas/internal/camera/InputSourceInner;

    move-result-object v0

    .line 351
    .local v0, "input":Ltas/internal/camera/InputSourceInner;
    invoke-virtual {p0, v0}, Ltas/internal/camera/InputChannel;->findPath(Ltas/internal/camera/InputSourceInner;)Ljava/util/List;

    move-result-object v1

    return-object v1
.end method

.method findPath(Ltas/internal/camera/InputSourceInner;)Ljava/util/List;
    .locals 3
    .param p1, "input"    # Ltas/internal/camera/InputSourceInner;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ltas/internal/camera/InputSourceInner;",
            ")",
            "Ljava/util/List",
            "<",
            "Ltas/internal/camera/InputSourceInner;",
            ">;"
        }
    .end annotation

    .prologue
    const/4 v2, 0x0

    .line 355
    if-nez p1, :cond_0

    .line 356
    return-object v2

    .line 358
    :cond_0
    move-object v0, p1

    .line 359
    .local v0, "found":Ltas/internal/camera/InputSourceInner;
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 360
    .local v1, "path":Ljava/util/List;, "Ljava/util/List<Ltas/internal/camera/InputSourceInner;>;"
    :goto_0
    if-eqz v0, :cond_1

    .line 361
    invoke-interface {v1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 362
    iget-object v0, v0, Ltas/internal/camera/InputSourceInner;->parent:Ltas/internal/camera/InputSourceInner;

    goto :goto_0

    .line 364
    :cond_1
    return-object v1
.end method

.method getCurrInput()Ltas/internal/camera/InputSourceInner;
    .locals 1

    .prologue
    .line 67
    iget-object v0, p0, Ltas/internal/camera/InputChannel;->mCurrInput:Ltas/internal/camera/InputSourceInner;

    return-object v0
.end method

.method getRootInput()Ltas/internal/camera/InputSourceInner;
    .locals 1

    .prologue
    .line 63
    iget-object v0, p0, Ltas/internal/camera/InputChannel;->mRootInput:Ltas/internal/camera/InputSourceInner;

    return-object v0
.end method

.method initializeEventQueue()V
    .locals 1

    .prologue
    .line 374
    iget-object v0, p0, Ltas/internal/camera/InputChannel;->mDispatcher:Ltas/internal/camera/Dispatcher;

    invoke-virtual {v0}, Ltas/internal/camera/Dispatcher;->initializeEventQueue()V

    .line 375
    invoke-virtual {p0}, Ltas/internal/camera/InputChannel;->initializeGuardian()V

    .line 373
    return-void
.end method

.method initializeGuardian()V
    .locals 4

    .prologue
    const/4 v3, 0x0

    .line 379
    iget-object v0, p0, Ltas/internal/camera/InputChannel;->mGuardian:Ltas/internal/camera/InputChannel$Guardian;

    if-nez v0, :cond_0

    .line 380
    new-instance v0, Ltas/internal/camera/InputChannel$Guardian;

    iget-object v1, p0, Ltas/internal/camera/InputChannel;->mDispatcher:Ltas/internal/camera/Dispatcher;

    iget-object v2, p0, Ltas/internal/camera/InputChannel;->mMonitor:Ltas/internal/camera/util/CameraMonitor;

    invoke-direct {v0, v1, v2, v3}, Ltas/internal/camera/InputChannel$Guardian;-><init>(Ltas/internal/camera/Dispatcher;Ltas/internal/camera/util/CameraMonitor;Ltas/internal/camera/InputChannel$Guardian;)V

    iput-object v0, p0, Ltas/internal/camera/InputChannel;->mGuardian:Ltas/internal/camera/InputChannel$Guardian;

    .line 381
    iget-object v0, p0, Ltas/internal/camera/InputChannel;->mGuardian:Ltas/internal/camera/InputChannel$Guardian;

    invoke-static {v0}, Ltas/internal/camera/InputChannel$Guardian;->-wrap2(Ltas/internal/camera/InputChannel$Guardian;)V

    .line 378
    :cond_0
    return-void
.end method

.method isMediaServerDead()Z
    .locals 2

    .prologue
    .line 145
    iget-object v0, p0, Ltas/internal/camera/InputChannel;->mLock:Ljava/lang/Object;

    monitor-enter v0

    .line 146
    :try_start_0
    iget-boolean v1, p0, Ltas/internal/camera/InputChannel;->mMediaServerDied:Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit v0

    return v1

    .line 145
    :catchall_0
    move-exception v1

    monitor-exit v0

    throw v1
.end method

.method notifyPlug(Ltas/internal/camera/InputSourceInner;)V
    .locals 3
    .param p1, "input"    # Ltas/internal/camera/InputSourceInner;

    .prologue
    .line 151
    iget-object v1, p0, Ltas/internal/camera/InputChannel;->mLock:Ljava/lang/Object;

    monitor-enter v1

    .line 152
    :try_start_0
    iget-boolean v0, p0, Ltas/internal/camera/InputChannel;->mMediaServerDied:Z

    if-nez v0, :cond_0

    .line 153
    iget-object v0, p0, Ltas/internal/camera/InputChannel;->mDispatcher:Ltas/internal/camera/Dispatcher;

    const/4 v2, 0x1

    invoke-virtual {v0, p1, v2}, Ltas/internal/camera/Dispatcher;->dispatchCableStateLocked(Ltas/internal/camera/InputSourceInner;Z)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :goto_0
    monitor-exit v1

    .line 150
    return-void

    .line 155
    :cond_0
    :try_start_1
    iget-object v0, p0, Ltas/internal/camera/InputChannel;->mDispatcher:Ltas/internal/camera/Dispatcher;

    const/4 v2, 0x1

    invoke-virtual {v0, p1, v2}, Ltas/internal/camera/Dispatcher;->pendingCableStateLocked(Ltas/internal/camera/InputSourceInner;Z)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_0

    .line 151
    :catchall_0
    move-exception v0

    monitor-exit v1

    throw v0
.end method

.method notifyUnplug(Ltas/internal/camera/InputSourceInner;)V
    .locals 3
    .param p1, "input"    # Ltas/internal/camera/InputSourceInner;

    .prologue
    .line 161
    iget-object v1, p0, Ltas/internal/camera/InputChannel;->mLock:Ljava/lang/Object;

    monitor-enter v1

    .line 162
    :try_start_0
    iget-boolean v0, p0, Ltas/internal/camera/InputChannel;->mMediaServerDied:Z

    if-nez v0, :cond_0

    .line 163
    iget-object v0, p0, Ltas/internal/camera/InputChannel;->mDispatcher:Ltas/internal/camera/Dispatcher;

    const/4 v2, 0x0

    invoke-virtual {v0, p1, v2}, Ltas/internal/camera/Dispatcher;->dispatchCableStateLocked(Ltas/internal/camera/InputSourceInner;Z)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :goto_0
    monitor-exit v1

    .line 160
    return-void

    .line 165
    :cond_0
    :try_start_1
    iget-object v0, p0, Ltas/internal/camera/InputChannel;->mDispatcher:Ltas/internal/camera/Dispatcher;

    const/4 v2, 0x0

    invoke-virtual {v0, p1, v2}, Ltas/internal/camera/Dispatcher;->pendingCableStateLocked(Ltas/internal/camera/InputSourceInner;Z)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_0

    .line 161
    :catchall_0
    move-exception v0

    monitor-exit v1

    throw v0
.end method

.method onCameraOpen()V
    .locals 4

    .prologue
    .line 79
    iget-object v1, p0, Ltas/internal/camera/InputChannel;->mGuardian:Ltas/internal/camera/InputChannel$Guardian;

    if-eqz v1, :cond_0

    .line 80
    iget-object v1, p0, Ltas/internal/camera/InputChannel;->mGuardian:Ltas/internal/camera/InputChannel$Guardian;

    invoke-static {v1}, Ltas/internal/camera/InputChannel$Guardian;->-wrap5(Ltas/internal/camera/InputChannel$Guardian;)V

    .line 84
    :cond_0
    iget-object v1, p0, Ltas/internal/camera/InputChannel;->mDispatcher:Ltas/internal/camera/Dispatcher;

    invoke-virtual {v1}, Ltas/internal/camera/Dispatcher;->resume()V

    .line 86
    iget-object v0, p0, Ltas/internal/camera/InputChannel;->mCurrInput:Ltas/internal/camera/InputSourceInner;

    .line 87
    .local v0, "curr":Ltas/internal/camera/InputSourceInner;
    iget-object v2, p0, Ltas/internal/camera/InputChannel;->mLock:Ljava/lang/Object;

    monitor-enter v2

    .line 88
    :try_start_0
    iget-boolean v1, p0, Ltas/internal/camera/InputChannel;->mMediaServerDied:Z

    if-nez v1, :cond_1

    .line 89
    iget-object v1, p0, Ltas/internal/camera/InputChannel;->mDispatcher:Ltas/internal/camera/Dispatcher;

    const/4 v3, 0x1

    invoke-virtual {v1, v0, v3}, Ltas/internal/camera/Dispatcher;->dispatchCameraStateLocked(Ltas/internal/camera/InputSourceInner;Z)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :goto_0
    monitor-exit v2

    .line 95
    invoke-virtual {v0}, Ltas/internal/camera/InputSourceInner;->handleOpen()V

    .line 78
    return-void

    .line 91
    :cond_1
    const/4 v1, 0x0

    :try_start_1
    iput-boolean v1, p0, Ltas/internal/camera/InputChannel;->mMediaServerDied:Z

    .line 92
    iget-object v1, p0, Ltas/internal/camera/InputChannel;->mDispatcher:Ltas/internal/camera/Dispatcher;

    const/4 v3, 0x1

    invoke-virtual {v1, v0, v3}, Ltas/internal/camera/Dispatcher;->pendingCameraStateLocked(Ltas/internal/camera/InputSourceInner;Z)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_0

    .line 87
    :catchall_0
    move-exception v1

    monitor-exit v2

    throw v1
.end method

.method onCameraRelease()V
    .locals 5

    .prologue
    const/4 v4, 0x0

    .line 99
    iget-object v1, p0, Ltas/internal/camera/InputChannel;->mGuardian:Ltas/internal/camera/InputChannel$Guardian;

    if-eqz v1, :cond_0

    .line 100
    iget-object v1, p0, Ltas/internal/camera/InputChannel;->mGuardian:Ltas/internal/camera/InputChannel$Guardian;

    invoke-static {v1}, Ltas/internal/camera/InputChannel$Guardian;->-wrap5(Ltas/internal/camera/InputChannel$Guardian;)V

    .line 104
    :cond_0
    iget-object v1, p0, Ltas/internal/camera/InputChannel;->mDispatcher:Ltas/internal/camera/Dispatcher;

    invoke-virtual {v1}, Ltas/internal/camera/Dispatcher;->resume()V

    .line 106
    iget-object v0, p0, Ltas/internal/camera/InputChannel;->mCurrInput:Ltas/internal/camera/InputSourceInner;

    .line 107
    .local v0, "curr":Ltas/internal/camera/InputSourceInner;
    iget-object v2, p0, Ltas/internal/camera/InputChannel;->mLock:Ljava/lang/Object;

    monitor-enter v2

    .line 108
    :try_start_0
    iget-boolean v1, p0, Ltas/internal/camera/InputChannel;->mMediaServerDied:Z

    if-nez v1, :cond_1

    .line 109
    iget-object v1, p0, Ltas/internal/camera/InputChannel;->mDispatcher:Ltas/internal/camera/Dispatcher;

    const/4 v3, 0x0

    invoke-virtual {v1, v0, v3}, Ltas/internal/camera/Dispatcher;->dispatchCameraStateLocked(Ltas/internal/camera/InputSourceInner;Z)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :goto_0
    monitor-exit v2

    .line 115
    iput-object v4, p0, Ltas/internal/camera/InputChannel;->mCurrInput:Ltas/internal/camera/InputSourceInner;

    .line 116
    iput-object v4, p0, Ltas/internal/camera/InputChannel;->mCurrProc:Ljava/lang/String;

    .line 117
    invoke-virtual {v0}, Ltas/internal/camera/InputSourceInner;->handleClose()V

    .line 98
    return-void

    .line 111
    :cond_1
    const/4 v1, 0x0

    :try_start_1
    iput-boolean v1, p0, Ltas/internal/camera/InputChannel;->mMediaServerDied:Z

    .line 112
    iget-object v1, p0, Ltas/internal/camera/InputChannel;->mDispatcher:Ltas/internal/camera/Dispatcher;

    const/4 v3, 0x0

    invoke-virtual {v1, v0, v3}, Ltas/internal/camera/Dispatcher;->pendingCameraStateLocked(Ltas/internal/camera/InputSourceInner;Z)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_0

    .line 107
    :catchall_0
    move-exception v1

    monitor-exit v2

    throw v1
.end method

.method onMediaServerDied()V
    .locals 3

    .prologue
    .line 121
    iget-object v0, p0, Ltas/internal/camera/InputChannel;->mGuardian:Ltas/internal/camera/InputChannel$Guardian;

    if-eqz v0, :cond_0

    .line 122
    iget-object v0, p0, Ltas/internal/camera/InputChannel;->mGuardian:Ltas/internal/camera/InputChannel$Guardian;

    invoke-static {v0}, Ltas/internal/camera/InputChannel$Guardian;->-wrap1(Ltas/internal/camera/InputChannel$Guardian;)V

    .line 124
    :cond_0
    iget-object v1, p0, Ltas/internal/camera/InputChannel;->mLock:Ljava/lang/Object;

    monitor-enter v1

    .line 125
    const/4 v0, 0x1

    :try_start_0
    iput-boolean v0, p0, Ltas/internal/camera/InputChannel;->mMediaServerDied:Z

    .line 126
    iget-object v0, p0, Ltas/internal/camera/InputChannel;->mDispatcher:Ltas/internal/camera/Dispatcher;

    invoke-virtual {v0}, Ltas/internal/camera/Dispatcher;->cleanupLocked()V

    .line 127
    iget-object v0, p0, Ltas/internal/camera/InputChannel;->mDispatcher:Ltas/internal/camera/Dispatcher;

    const/4 v2, 0x0

    invoke-virtual {v0, v2}, Ltas/internal/camera/Dispatcher;->dispatchMediaServerStateLocked(Z)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit v1

    .line 120
    return-void

    .line 124
    :catchall_0
    move-exception v0

    monitor-exit v1

    throw v0
.end method

.method onMediaServerRevived()V
    .locals 3

    .prologue
    .line 132
    iget-object v0, p0, Ltas/internal/camera/InputChannel;->mGuardian:Ltas/internal/camera/InputChannel$Guardian;

    if-eqz v0, :cond_0

    .line 133
    iget-object v0, p0, Ltas/internal/camera/InputChannel;->mGuardian:Ltas/internal/camera/InputChannel$Guardian;

    invoke-static {v0}, Ltas/internal/camera/InputChannel$Guardian;->-wrap2(Ltas/internal/camera/InputChannel$Guardian;)V

    .line 135
    :cond_0
    iget-object v1, p0, Ltas/internal/camera/InputChannel;->mLock:Ljava/lang/Object;

    monitor-enter v1

    .line 136
    const/4 v0, 0x0

    :try_start_0
    iput-boolean v0, p0, Ltas/internal/camera/InputChannel;->mMediaServerDied:Z

    .line 137
    iget-object v0, p0, Ltas/internal/camera/InputChannel;->mDispatcher:Ltas/internal/camera/Dispatcher;

    invoke-virtual {v0}, Ltas/internal/camera/Dispatcher;->cleanupLocked()V

    .line 138
    iget-object v0, p0, Ltas/internal/camera/InputChannel;->mDispatcher:Ltas/internal/camera/Dispatcher;

    invoke-virtual {v0}, Ltas/internal/camera/Dispatcher;->resume()V

    .line 139
    iget-object v0, p0, Ltas/internal/camera/InputChannel;->mDispatcher:Ltas/internal/camera/Dispatcher;

    const/4 v2, 0x1

    invoke-virtual {v0, v2}, Ltas/internal/camera/Dispatcher;->dispatchMediaServerStateLocked(Z)V

    .line 140
    iget-object v0, p0, Ltas/internal/camera/InputChannel;->mDispatcher:Ltas/internal/camera/Dispatcher;

    invoke-virtual {v0}, Ltas/internal/camera/Dispatcher;->dispatchPendingsLocked()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit v1

    .line 131
    return-void

    .line 135
    :catchall_0
    move-exception v0

    monitor-exit v1

    throw v0
.end method

.method onNotifyCableState(Ltas/internal/camera/InputParams;)Z
    .locals 5
    .param p1, "params"    # Ltas/internal/camera/InputParams;

    .prologue
    const/4 v4, 0x0

    const/4 v3, 0x0

    .line 194
    iget-object v0, p0, Ltas/internal/camera/InputChannel;->TAG:Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "onNotifyCableState - "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 196
    iget-object v0, p1, Ltas/internal/camera/InputParams;->msg:Ltas/camera/CameraMessage;

    iget v0, v0, Ltas/camera/CameraMessage;->arg1:I

    if-nez v0, :cond_1

    .line 197
    iget-object v0, p0, Ltas/internal/camera/InputChannel;->mCurrInput:Ltas/internal/camera/InputSourceInner;

    if-eqz v0, :cond_1

    .line 198
    iget-object v0, p0, Ltas/internal/camera/InputChannel;->mCurrInput:Ltas/internal/camera/InputSourceInner;

    iget-object v1, p1, Ltas/internal/camera/InputParams;->cam:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ltas/internal/camera/InputSourceInner;->isCamcls(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_1

    .line 199
    iget-object v0, p0, Ltas/internal/camera/InputChannel;->mCurrInput:Ltas/internal/camera/InputSourceInner;

    iget v0, v0, Ltas/internal/camera/InputSourceInner;->camidCompat:I

    invoke-static {v0}, Ltas/internal/camera/InputChannel;->isUnknownOpenedCamid(I)Z

    move-result v0

    if-nez v0, :cond_1

    .line 200
    iget-object v0, p0, Ltas/internal/camera/InputChannel;->mGuardian:Ltas/internal/camera/InputChannel$Guardian;

    if-eqz v0, :cond_0

    .line 201
    iget-object v0, p0, Ltas/internal/camera/InputChannel;->mGuardian:Ltas/internal/camera/InputChannel$Guardian;

    invoke-static {v0, v4, v3}, Ltas/internal/camera/InputChannel$Guardian;->-wrap0(Ltas/internal/camera/InputChannel$Guardian;ZLjava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_1

    .line 204
    :cond_0
    iget-object v0, p0, Ltas/internal/camera/InputChannel;->TAG:Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "closing - "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Ltas/internal/camera/InputChannel;->mCurrInput:Ltas/internal/camera/InputSourceInner;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 209
    iget-object v0, p0, Ltas/internal/camera/InputChannel;->mDispatcher:Ltas/internal/camera/Dispatcher;

    invoke-virtual {v0}, Ltas/internal/camera/Dispatcher;->pause()V

    .line 213
    :cond_1
    const/4 v0, 0x1

    return v0
.end method

.method onNotifyCameraMessage(Ltas/internal/camera/InputParams;)Z
    .locals 3
    .param p1, "params"    # Ltas/internal/camera/InputParams;

    .prologue
    .line 225
    iget-object v0, p0, Ltas/internal/camera/InputChannel;->TAG:Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "onNotifyCameraMessage - "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 227
    const/4 v0, 0x1

    return v0
.end method

.method onNotifyCameraState(Ltas/internal/camera/InputParams;)Z
    .locals 3
    .param p1, "params"    # Ltas/internal/camera/InputParams;

    .prologue
    .line 218
    iget-object v0, p0, Ltas/internal/camera/InputChannel;->TAG:Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "onNotifyCameraState - "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 220
    const/4 v0, 0x1

    return v0
.end method

.method onNotifyExtraState(Ltas/internal/camera/InputParams;)Z
    .locals 3
    .param p1, "params"    # Ltas/internal/camera/InputParams;

    .prologue
    .line 232
    iget-object v0, p0, Ltas/internal/camera/InputChannel;->TAG:Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "onNotifyExtraState - "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 234
    const/4 v0, 0x1

    return v0
.end method

.method onNotifyMediaServerState(Ltas/internal/camera/InputParams;)Z
    .locals 3
    .param p1, "params"    # Ltas/internal/camera/InputParams;

    .prologue
    .line 239
    iget-object v0, p0, Ltas/internal/camera/InputChannel;->TAG:Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "onNotifyMediaServerState - "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 241
    iget-object v0, p1, Ltas/internal/camera/InputParams;->msg:Ltas/camera/CameraMessage;

    iget v0, v0, Ltas/camera/CameraMessage;->arg1:I

    if-nez v0, :cond_0

    .line 243
    iget-object v0, p0, Ltas/internal/camera/InputChannel;->mDispatcher:Ltas/internal/camera/Dispatcher;

    invoke-virtual {v0}, Ltas/internal/camera/Dispatcher;->pause()V

    .line 245
    :cond_0
    const/4 v0, 0x1

    return v0
.end method

.method onSystemMasterClear(Ljava/lang/String;)V
    .locals 1
    .param p1, "reason"    # Ljava/lang/String;

    .prologue
    .line 75
    iget-object v0, p0, Ltas/internal/camera/InputChannel;->mRootInput:Ltas/internal/camera/InputSourceInner;

    invoke-virtual {v0, p1}, Ltas/internal/camera/InputSourceInner;->onSystemMasterClear(Ljava/lang/String;)V

    .line 74
    return-void
.end method

.method onSystemShutdown()V
    .locals 1

    .prologue
    .line 71
    iget-object v0, p0, Ltas/internal/camera/InputChannel;->mRootInput:Ltas/internal/camera/InputSourceInner;

    invoke-virtual {v0}, Ltas/internal/camera/InputSourceInner;->onSystemShutdown()V

    .line 70
    return-void
.end method

.method pause()V
    .locals 1

    .prologue
    .line 59
    iget-object v0, p0, Ltas/internal/camera/InputChannel;->mDispatcher:Ltas/internal/camera/Dispatcher;

    invoke-virtual {v0}, Ltas/internal/camera/Dispatcher;->pause()V

    .line 58
    return-void
.end method

.method reportExtraState(Ltas/internal/camera/InputSourceInner;IILjava/lang/String;)V
    .locals 2
    .param p1, "input"    # Ltas/internal/camera/InputSourceInner;
    .param p2, "state"    # I
    .param p3, "flag"    # I
    .param p4, "proc"    # Ljava/lang/String;

    .prologue
    .line 183
    iget-object v1, p0, Ltas/internal/camera/InputChannel;->mLock:Ljava/lang/Object;

    monitor-enter v1

    .line 184
    :try_start_0
    iget-boolean v0, p0, Ltas/internal/camera/InputChannel;->mMediaServerDied:Z

    if-nez v0, :cond_0

    .line 185
    iget-object v0, p0, Ltas/internal/camera/InputChannel;->mDispatcher:Ltas/internal/camera/Dispatcher;

    invoke-virtual {v0, p1, p2, p3, p4}, Ltas/internal/camera/Dispatcher;->dispatchExtraStateLocked(Ltas/internal/camera/InputSourceInner;IILjava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :goto_0
    monitor-exit v1

    .line 182
    return-void

    .line 187
    :cond_0
    :try_start_1
    iget-object v0, p0, Ltas/internal/camera/InputChannel;->mDispatcher:Ltas/internal/camera/Dispatcher;

    invoke-virtual {v0, p1, p2, p3, p4}, Ltas/internal/camera/Dispatcher;->pendingExtraStateLocked(Ltas/internal/camera/InputSourceInner;IILjava/lang/String;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_0

    .line 183
    :catchall_0
    move-exception v0

    monitor-exit v1

    throw v0
.end method

.method reportUnknownCameraOpened(I)V
    .locals 1
    .param p1, "camid"    # I

    .prologue
    .line 627
    const/4 v0, 0x1

    invoke-virtual {p0, p1, v0}, Ltas/internal/camera/InputChannel;->reportUnknownCameraState(IZ)V

    .line 626
    return-void
.end method

.method reportUnknownCameraReleased(I)V
    .locals 1
    .param p1, "camid"    # I

    .prologue
    .line 631
    const/4 v0, 0x0

    invoke-virtual {p0, p1, v0}, Ltas/internal/camera/InputChannel;->reportUnknownCameraState(IZ)V

    .line 630
    return-void
.end method

.method reportUnknownCameraState(IZ)V
    .locals 5
    .param p1, "camid"    # I
    .param p2, "opened"    # Z

    .prologue
    .line 610
    invoke-virtual {p0, p1}, Ltas/internal/camera/InputChannel;->collectInputs(I)Ljava/util/List;

    move-result-object v0

    .line 611
    .local v0, "collect":Ljava/util/List;, "Ljava/util/List<Ltas/internal/camera/InputSourceInner;>;"
    if-eqz v0, :cond_0

    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result v3

    if-eqz v3, :cond_1

    .line 612
    :cond_0
    return-void

    .line 614
    :cond_1
    iget-object v4, p0, Ltas/internal/camera/InputChannel;->mLock:Ljava/lang/Object;

    monitor-enter v4

    .line 615
    :try_start_0
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v2

    .local v2, "input$iterator":Ljava/util/Iterator;
    :goto_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_3

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ltas/internal/camera/InputSourceInner;

    .line 616
    .local v1, "input":Ltas/internal/camera/InputSourceInner;
    iget-boolean v3, p0, Ltas/internal/camera/InputChannel;->mMediaServerDied:Z

    if-nez v3, :cond_2

    .line 617
    iget-object v3, p0, Ltas/internal/camera/InputChannel;->mDispatcher:Ltas/internal/camera/Dispatcher;

    invoke-virtual {v3, v1, p2}, Ltas/internal/camera/Dispatcher;->dispatchCameraStateLocked(Ltas/internal/camera/InputSourceInner;Z)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    .line 614
    .end local v1    # "input":Ltas/internal/camera/InputSourceInner;
    .end local v2    # "input$iterator":Ljava/util/Iterator;
    :catchall_0
    move-exception v3

    monitor-exit v4

    throw v3

    .line 619
    .restart local v1    # "input":Ltas/internal/camera/InputSourceInner;
    .restart local v2    # "input$iterator":Ljava/util/Iterator;
    :cond_2
    const/4 v3, 0x0

    :try_start_1
    iput-boolean v3, p0, Ltas/internal/camera/InputChannel;->mMediaServerDied:Z

    .line 620
    iget-object v3, p0, Ltas/internal/camera/InputChannel;->mDispatcher:Ltas/internal/camera/Dispatcher;

    invoke-virtual {v3, v1, p2}, Ltas/internal/camera/Dispatcher;->pendingCameraStateLocked(Ltas/internal/camera/InputSourceInner;Z)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_0

    .end local v1    # "input":Ltas/internal/camera/InputSourceInner;
    :cond_3
    monitor-exit v4

    .line 605
    return-void
.end method

.method request(Ljava/lang/String;Ltas/internal/camera/InputParams;)I
    .locals 6
    .param p1, "proc"    # Ljava/lang/String;
    .param p2, "params"    # Ltas/internal/camera/InputParams;

    .prologue
    const/4 v5, 0x0

    const/4 v4, 0x0

    .line 249
    iget-boolean v2, p0, Ltas/internal/camera/InputChannel;->mMediaServerDied:Z

    if-eqz v2, :cond_0

    .line 250
    const/4 v2, -0x6

    return v2

    .line 253
    :cond_0
    iget-object v2, p0, Ltas/internal/camera/InputChannel;->mCurrInput:Ltas/internal/camera/InputSourceInner;

    if-eqz v2, :cond_1

    .line 254
    const/4 v2, -0x2

    return v2

    .line 257
    :cond_1
    iget-object v2, p0, Ltas/internal/camera/InputChannel;->mRootInput:Ltas/internal/camera/InputSourceInner;

    iget-object v3, p2, Ltas/internal/camera/InputParams;->cam:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ltas/internal/camera/InputSourceInner;->findInput(Ljava/lang/String;)Ltas/internal/camera/InputSourceInner;

    move-result-object v0

    .line 258
    .local v0, "input":Ltas/internal/camera/InputSourceInner;
    if-nez v0, :cond_2

    .line 259
    const/4 v2, -0x5

    return v2

    .line 262
    :cond_2
    iget v2, v0, Ltas/internal/camera/InputSourceInner;->camidCompat:I

    invoke-static {v2}, Ltas/internal/camera/InputChannel;->isUnknownOpenedCamid(I)Z

    move-result v2

    if-eqz v2, :cond_3

    .line 263
    const/4 v2, -0x3

    return v2

    .line 266
    :cond_3
    invoke-virtual {v0, p1}, Ltas/internal/camera/InputSourceInner;->request(Ljava/lang/String;)I

    move-result v1

    .line 267
    .local v1, "result":I
    if-eqz v1, :cond_4

    .line 268
    return v1

    .line 271
    :cond_4
    iput-object p1, p0, Ltas/internal/camera/InputChannel;->mCurrProc:Ljava/lang/String;

    .line 272
    iput-object v0, p0, Ltas/internal/camera/InputChannel;->mCurrInput:Ltas/internal/camera/InputSourceInner;

    .line 273
    iget-object v2, p0, Ltas/internal/camera/InputChannel;->mGuardian:Ltas/internal/camera/InputChannel$Guardian;

    if-eqz v2, :cond_5

    iget-object v2, p0, Ltas/internal/camera/InputChannel;->mGuardian:Ltas/internal/camera/InputChannel$Guardian;

    const/4 v3, 0x1

    invoke-static {v2, v3, p1}, Ltas/internal/camera/InputChannel$Guardian;->-wrap0(Ltas/internal/camera/InputChannel$Guardian;ZLjava/lang/String;)Z

    move-result v2

    if-nez v2, :cond_5

    .line 274
    iput-object v4, p0, Ltas/internal/camera/InputChannel;->mCurrProc:Ljava/lang/String;

    .line 275
    iput-object v4, p0, Ltas/internal/camera/InputChannel;->mCurrInput:Ltas/internal/camera/InputSourceInner;

    .line 276
    const/4 v2, -0x7

    return v2

    .line 280
    :cond_5
    iget-object v2, p0, Ltas/internal/camera/InputChannel;->TAG:Ljava/lang/String;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v4, "opening - "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 285
    iget-object v2, p0, Ltas/internal/camera/InputChannel;->mDispatcher:Ltas/internal/camera/Dispatcher;

    invoke-virtual {v2}, Ltas/internal/camera/Dispatcher;->pause()V

    .line 287
    return v5
.end method

.method resume()V
    .locals 1

    .prologue
    .line 55
    iget-object v0, p0, Ltas/internal/camera/InputChannel;->mDispatcher:Ltas/internal/camera/Dispatcher;

    invoke-virtual {v0}, Ltas/internal/camera/Dispatcher;->resume()V

    .line 54
    return-void
.end method

.method sendMessage(Ltas/internal/camera/InputSourceInner;Ltas/camera/CameraMessage;Ljava/lang/String;Z)V
    .locals 2
    .param p1, "input"    # Ltas/internal/camera/InputSourceInner;
    .param p2, "msg"    # Ltas/camera/CameraMessage;
    .param p3, "proc"    # Ljava/lang/String;
    .param p4, "now"    # Z

    .prologue
    .line 172
    iget-object v1, p0, Ltas/internal/camera/InputChannel;->mLock:Ljava/lang/Object;

    monitor-enter v1

    .line 173
    :try_start_0
    iget-boolean v0, p0, Ltas/internal/camera/InputChannel;->mMediaServerDied:Z

    if-eqz v0, :cond_0

    if-eqz p4, :cond_1

    .line 174
    :cond_0
    iget-object v0, p0, Ltas/internal/camera/InputChannel;->mDispatcher:Ltas/internal/camera/Dispatcher;

    invoke-virtual {v0, p1, p2, p3, p4}, Ltas/internal/camera/Dispatcher;->dispatchMessageLocked(Ltas/internal/camera/InputSourceInner;Ltas/camera/CameraMessage;Ljava/lang/String;Z)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :goto_0
    monitor-exit v1

    .line 171
    return-void

    .line 176
    :cond_1
    :try_start_1
    iget-object v0, p0, Ltas/internal/camera/InputChannel;->mDispatcher:Ltas/internal/camera/Dispatcher;

    invoke-virtual {v0, p1, p2, p3}, Ltas/internal/camera/Dispatcher;->pendingMessageLocked(Ltas/internal/camera/InputSourceInner;Ltas/camera/CameraMessage;Ljava/lang/String;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_0

    .line 172
    :catchall_0
    move-exception v0

    monitor-exit v1

    throw v0
.end method
