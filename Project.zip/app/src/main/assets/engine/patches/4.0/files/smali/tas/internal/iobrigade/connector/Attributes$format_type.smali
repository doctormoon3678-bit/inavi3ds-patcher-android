.class public Ltas/internal/iobrigade/connector/Attributes$format_type;
.super Ljava/lang/Object;
.source "Attributes.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltas/internal/iobrigade/connector/Attributes;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "format_type"
.end annotation


# static fields
.field public static BRDATA:I

.field public static RAW:I


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .prologue
    .line 12
    const/4 v0, 0x4

    sput v0, Ltas/internal/iobrigade/connector/Attributes$format_type;->RAW:I

    .line 13
    const/16 v0, 0x8

    sput v0, Ltas/internal/iobrigade/connector/Attributes$format_type;->BRDATA:I

    .line 11
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .prologue
    .line 11
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
