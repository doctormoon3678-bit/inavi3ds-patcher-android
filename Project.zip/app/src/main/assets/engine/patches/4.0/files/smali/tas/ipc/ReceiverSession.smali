.class public Ltas/ipc/ReceiverSession;
.super Ljava/lang/Object;
.source "ReceiverSession.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ltas/ipc/ReceiverSession$Callback;,
        Ltas/ipc/ReceiverSession$SimpleCallback;
    }
.end annotation


# instance fields
.field public cb:Ltas/ipc/ReceiverSession$Callback;

.field public final extra:Landroid/os/Bundle;

.field public final id:J

.field public final name:Ljava/lang/String;

.field public online:Z

.field public final owner:Ltas/internal/ipc/Receiver;

.field public final pkg:Ljava/lang/String;

.field public final q:Ljava/util/Queue;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Queue",
            "<",
            "Ltas/ipc/MsgData;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Ltas/internal/ipc/Receiver;JLjava/lang/String;Ljava/lang/String;Landroid/os/Bundle;)V
    .locals 2
    .param p1, "_owner"    # Ltas/internal/ipc/Receiver;
    .param p2, "_id"    # J
    .param p4, "_pkg"    # Ljava/lang/String;
    .param p5, "_name"    # Ljava/lang/String;
    .param p6, "_extra"    # Landroid/os/Bundle;

    .prologue
    const/4 v1, 0x0

    .line 29
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 23
    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    iput-object v0, p0, Ltas/ipc/ReceiverSession;->extra:Landroid/os/Bundle;

    .line 26
    iput-object v1, p0, Ltas/ipc/ReceiverSession;->cb:Ltas/ipc/ReceiverSession$Callback;

    .line 27
    new-instance v0, Ljava/util/ArrayDeque;

    const/16 v1, 0xa

    invoke-direct {v0, v1}, Ljava/util/ArrayDeque;-><init>(I)V

    iput-object v0, p0, Ltas/ipc/ReceiverSession;->q:Ljava/util/Queue;

    .line 31
    iput-object p1, p0, Ltas/ipc/ReceiverSession;->owner:Ltas/internal/ipc/Receiver;

    .line 32
    iput-wide p2, p0, Ltas/ipc/ReceiverSession;->id:J

    .line 33
    iput-object p4, p0, Ltas/ipc/ReceiverSession;->pkg:Ljava/lang/String;

    .line 34
    iput-object p5, p0, Ltas/ipc/ReceiverSession;->name:Ljava/lang/String;

    .line 35
    if-eqz p6, :cond_0

    .line 36
    iget-object v0, p0, Ltas/ipc/ReceiverSession;->extra:Landroid/os/Bundle;

    invoke-virtual {v0, p6}, Landroid/os/Bundle;->putAll(Landroid/os/Bundle;)V

    .line 38
    :cond_0
    const/4 v0, 0x1

    iput-boolean v0, p0, Ltas/ipc/ReceiverSession;->online:Z

    .line 30
    return-void
.end method


# virtual methods
.method public destroy()V
    .locals 4

    .prologue
    .line 45
    iget-object v0, p0, Ltas/ipc/ReceiverSession;->owner:Ltas/internal/ipc/Receiver;

    iget-wide v2, p0, Ltas/ipc/ReceiverSession;->id:J

    invoke-virtual {v0, v2, v3}, Ltas/internal/ipc/Receiver;->destroySession(J)V

    .line 44
    return-void
.end method

.method public dumpToString(Ljava/lang/StringBuilder;)Ljava/lang/StringBuilder;
    .locals 4
    .param p1, "sb"    # Ljava/lang/StringBuilder;

    .prologue
    .line 131
    const-string/jumbo v0, "RemoteSender {"

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 132
    const-string/jumbo v1, " id="

    .line 131
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 132
    iget-wide v2, p0, Ltas/ipc/ReceiverSession;->id:J

    .line 131
    invoke-virtual {v0, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 133
    const-string/jumbo v1, " name="

    .line 131
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 133
    iget-object v1, p0, Ltas/ipc/ReceiverSession;->name:Ljava/lang/String;

    .line 131
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 134
    const-string/jumbo v1, " online="

    .line 131
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 134
    iget-boolean v1, p0, Ltas/ipc/ReceiverSession;->online:Z

    .line 131
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 135
    const-string/jumbo v1, " }"

    .line 131
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    return-object v0
.end method

.method public getReplier(I)Ltas/ipc/ReplierSession;
    .locals 1
    .param p1, "what"    # I

    .prologue
    .line 54
    invoke-static {p0, p1}, Ltas/ipc/ReplierSession;->obtain(Ltas/ipc/ReceiverSession;I)Ltas/ipc/ReplierSession;

    move-result-object v0

    return-object v0
.end method

.method public toString()Ljava/lang/String;
    .locals 1

    .prologue
    .line 139
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0, v0}, Ltas/ipc/ReceiverSession;->dumpToString(Ljava/lang/StringBuilder;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
