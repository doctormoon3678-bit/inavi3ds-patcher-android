.class public Ltas/internal/camera/server/ServerOutGoing$Client;
.super Ljava/lang/Object;
.source "ServerOutGoing.java"

# interfaces
.implements Landroid/os/IBinder$DeathRecipient;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltas/internal/camera/server/ServerOutGoing;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "Client"
.end annotation


# instance fields
.field private TAG:Ljava/lang/String;

.field private final mConcern:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List",
            "<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private final mProc:Landroid/app/ActivityManager$RunningAppProcessInfo;

.field private mRemote:Ltas/internal/camera/server/IServerCallback;

.field private mServer:Ltas/internal/camera/server/ServerOutGoing;


# direct methods
.method static synthetic -wrap0(Ltas/internal/camera/server/ServerOutGoing$Client;)Z
    .locals 1

    invoke-direct {p0}, Ltas/internal/camera/server/ServerOutGoing$Client;->isApplicationRunning()Z

    move-result v0

    return v0
.end method

.method static synthetic -wrap1(Ltas/internal/camera/server/ServerOutGoing$Client;Ljava/lang/String;)Z
    .locals 1
    .param p1, "cam"    # Ljava/lang/String;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/camera/server/ServerOutGoing$Client;->isWatching(Ljava/lang/String;)Z

    move-result v0

    return v0
.end method

.method static synthetic -wrap10(Ltas/internal/camera/server/ServerOutGoing$Client;Ltas/internal/camera/server/RemoteMessage;)V
    .locals 0
    .param p1, "msg"    # Ltas/internal/camera/server/RemoteMessage;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/camera/server/ServerOutGoing$Client;->notifyInitialState(Ltas/internal/camera/server/RemoteMessage;)V

    return-void
.end method

.method static synthetic -wrap11(Ltas/internal/camera/server/ServerOutGoing$Client;Ltas/internal/camera/server/RemoteMessage;)V
    .locals 0
    .param p1, "msg"    # Ltas/internal/camera/server/RemoteMessage;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/camera/server/ServerOutGoing$Client;->notifyMediaServerState(Ltas/internal/camera/server/RemoteMessage;)V

    return-void
.end method

.method static synthetic -wrap12(Ltas/internal/camera/server/ServerOutGoing$Client;)V
    .locals 0

    invoke-direct {p0}, Ltas/internal/camera/server/ServerOutGoing$Client;->unlinkToDeath()V

    return-void
.end method

.method static synthetic -wrap13(Ltas/internal/camera/server/ServerOutGoing$Client;Ljava/lang/String;)V
    .locals 0
    .param p1, "cam"    # Ljava/lang/String;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/camera/server/ServerOutGoing$Client;->unwatch(Ljava/lang/String;)V

    return-void
.end method

.method static synthetic -wrap14(Ltas/internal/camera/server/ServerOutGoing$Client;)V
    .locals 0

    invoke-direct {p0}, Ltas/internal/camera/server/ServerOutGoing$Client;->unwatchall()V

    return-void
.end method

.method static synthetic -wrap15(Ltas/internal/camera/server/ServerOutGoing$Client;Ljava/lang/String;)V
    .locals 0
    .param p1, "cam"    # Ljava/lang/String;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/camera/server/ServerOutGoing$Client;->watch(Ljava/lang/String;)V

    return-void
.end method

.method static synthetic -wrap2(Ltas/internal/camera/server/ServerOutGoing$Client;Ljava/lang/String;)Z
    .locals 1
    .param p1, "procName"    # Ljava/lang/String;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/camera/server/ServerOutGoing$Client;->verifyProcessName(Ljava/lang/String;)Z

    move-result v0

    return v0
.end method

.method static synthetic -wrap3(Ltas/internal/camera/server/ServerOutGoing$Client;)I
    .locals 1

    invoke-direct {p0}, Ltas/internal/camera/server/ServerOutGoing$Client;->pid()I

    move-result v0

    return v0
.end method

.method static synthetic -wrap4(Ltas/internal/camera/server/ServerOutGoing$Client;)Ljava/lang/String;
    .locals 1

    invoke-direct {p0}, Ltas/internal/camera/server/ServerOutGoing$Client;->name()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method static synthetic -wrap5(Ltas/internal/camera/server/ServerOutGoing$Client;)V
    .locals 0

    invoke-direct {p0}, Ltas/internal/camera/server/ServerOutGoing$Client;->linkToDeath()V

    return-void
.end method

.method static synthetic -wrap6(Ltas/internal/camera/server/ServerOutGoing$Client;Ltas/internal/camera/server/RemoteMessage;)V
    .locals 0
    .param p1, "msg"    # Ltas/internal/camera/server/RemoteMessage;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/camera/server/ServerOutGoing$Client;->notifyCableState(Ltas/internal/camera/server/RemoteMessage;)V

    return-void
.end method

.method static synthetic -wrap7(Ltas/internal/camera/server/ServerOutGoing$Client;Ltas/internal/camera/server/RemoteMessage;)V
    .locals 0
    .param p1, "msg"    # Ltas/internal/camera/server/RemoteMessage;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/camera/server/ServerOutGoing$Client;->notifyCameraMessage(Ltas/internal/camera/server/RemoteMessage;)V

    return-void
.end method

.method static synthetic -wrap8(Ltas/internal/camera/server/ServerOutGoing$Client;Ltas/internal/camera/server/RemoteMessage;)V
    .locals 0
    .param p1, "msg"    # Ltas/internal/camera/server/RemoteMessage;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/camera/server/ServerOutGoing$Client;->notifyCameraState(Ltas/internal/camera/server/RemoteMessage;)V

    return-void
.end method

.method static synthetic -wrap9(Ltas/internal/camera/server/ServerOutGoing$Client;Ltas/internal/camera/server/RemoteMessage;)V
    .locals 0
    .param p1, "msg"    # Ltas/internal/camera/server/RemoteMessage;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/camera/server/ServerOutGoing$Client;->notifyExtraState(Ltas/internal/camera/server/RemoteMessage;)V

    return-void
.end method

.method private constructor <init>(Ltas/internal/camera/server/ServerOutGoing;Landroid/app/ActivityManager$RunningAppProcessInfo;Ltas/internal/camera/server/IServerCallback;)V
    .locals 2
    .param p1, "server"    # Ltas/internal/camera/server/ServerOutGoing;
    .param p2, "proc"    # Landroid/app/ActivityManager$RunningAppProcessInfo;
    .param p3, "remote"    # Ltas/internal/camera/server/IServerCallback;

    .prologue
    .line 243
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 237
    const-string/jumbo v0, "TasCAM"

    iput-object v0, p0, Ltas/internal/camera/server/ServerOutGoing$Client;->TAG:Ljava/lang/String;

    .line 239
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Ltas/internal/camera/server/ServerOutGoing$Client;->mConcern:Ljava/util/List;

    .line 246
    iput-object p1, p0, Ltas/internal/camera/server/ServerOutGoing$Client;->mServer:Ltas/internal/camera/server/ServerOutGoing;

    iput-object p2, p0, Ltas/internal/camera/server/ServerOutGoing$Client;->mProc:Landroid/app/ActivityManager$RunningAppProcessInfo;

    iput-object p3, p0, Ltas/internal/camera/server/ServerOutGoing$Client;->mRemote:Ltas/internal/camera/server/IServerCallback;

    .line 247
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v1, p0, Ltas/internal/camera/server/ServerOutGoing$Client;->TAG:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string/jumbo v1, "<Client."

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget v1, p2, Landroid/app/ActivityManager$RunningAppProcessInfo;->pid:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string/jumbo v1, ">"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Ltas/internal/camera/server/ServerOutGoing$Client;->TAG:Ljava/lang/String;

    .line 245
    return-void
.end method

.method synthetic constructor <init>(Ltas/internal/camera/server/ServerOutGoing;Landroid/app/ActivityManager$RunningAppProcessInfo;Ltas/internal/camera/server/IServerCallback;Ltas/internal/camera/server/ServerOutGoing$Client;)V
    .locals 0
    .param p1, "server"    # Ltas/internal/camera/server/ServerOutGoing;
    .param p2, "proc"    # Landroid/app/ActivityManager$RunningAppProcessInfo;
    .param p3, "remote"    # Ltas/internal/camera/server/IServerCallback;

    .prologue
    invoke-direct {p0, p1, p2, p3}, Ltas/internal/camera/server/ServerOutGoing$Client;-><init>(Ltas/internal/camera/server/ServerOutGoing;Landroid/app/ActivityManager$RunningAppProcessInfo;Ltas/internal/camera/server/IServerCallback;)V

    return-void
.end method

.method private final isAlive()Z
    .locals 1

    .prologue
    .line 252
    iget-object v0, p0, Ltas/internal/camera/server/ServerOutGoing$Client;->mRemote:Ltas/internal/camera/server/IServerCallback;

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    :goto_0
    return v0

    :cond_0
    const/4 v0, 0x0

    goto :goto_0
.end method

.method private isApplicationRunning()Z
    .locals 2

    .prologue
    .line 400
    iget-object v0, p0, Ltas/internal/camera/server/ServerOutGoing$Client;->mServer:Ltas/internal/camera/server/ServerOutGoing;

    invoke-virtual {v0}, Ltas/internal/camera/server/ServerOutGoing;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-direct {p0}, Ltas/internal/camera/server/ServerOutGoing$Client;->pid()I

    move-result v1

    .line 399
    invoke-static {v0, v1}, Ltas/internal/camera/util/SystemUtil;->getRunningAppProcesses(Landroid/content/Context;I)Landroid/app/ActivityManager$RunningAppProcessInfo;

    move-result-object v0

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    :goto_0
    return v0

    :cond_0
    const/4 v0, 0x0

    goto :goto_0
.end method

.method private isTargetClient(Ltas/internal/camera/server/RemoteMessage;)Z
    .locals 3
    .param p1, "msg"    # Ltas/internal/camera/server/RemoteMessage;

    .prologue
    const/4 v0, 0x0

    .line 289
    iget-object v1, p1, Ltas/internal/camera/server/RemoteMessage;->params:Ltas/internal/camera/InputParams;

    iget v1, v1, Ltas/internal/camera/InputParams;->pid:I

    if-eqz v1, :cond_0

    iget-object v1, p1, Ltas/internal/camera/server/RemoteMessage;->params:Ltas/internal/camera/InputParams;

    iget v1, v1, Ltas/internal/camera/InputParams;->pid:I

    invoke-direct {p0}, Ltas/internal/camera/server/ServerOutGoing$Client;->pid()I

    move-result v2

    if-ne v1, v2, :cond_1

    .line 290
    :cond_0
    iget-object v0, p1, Ltas/internal/camera/server/RemoteMessage;->params:Ltas/internal/camera/InputParams;

    iget-object v0, v0, Ltas/internal/camera/InputParams;->proc:Ljava/lang/String;

    if-eqz v0, :cond_2

    iget-object v0, p1, Ltas/internal/camera/server/RemoteMessage;->params:Ltas/internal/camera/InputParams;

    iget-object v0, v0, Ltas/internal/camera/InputParams;->proc:Ljava/lang/String;

    invoke-direct {p0, v0}, Ltas/internal/camera/server/ServerOutGoing$Client;->verifyProcessName(Ljava/lang/String;)Z

    move-result v0

    .line 289
    :cond_1
    :goto_0
    return v0

    .line 290
    :cond_2
    const/4 v0, 0x1

    goto :goto_0
.end method

.method private isWatching(Ljava/lang/String;)Z
    .locals 1
    .param p1, "cam"    # Ljava/lang/String;

    .prologue
    .line 285
    iget-object v0, p0, Ltas/internal/camera/server/ServerOutGoing$Client;->mConcern:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v0

    return v0
.end method

.method private linkToDeath()V
    .locals 3

    .prologue
    .line 404
    iget-object v1, p0, Ltas/internal/camera/server/ServerOutGoing$Client;->mRemote:Ltas/internal/camera/server/IServerCallback;

    if-eqz v1, :cond_0

    .line 406
    :try_start_0
    iget-object v1, p0, Ltas/internal/camera/server/ServerOutGoing$Client;->mRemote:Ltas/internal/camera/server/IServerCallback;

    invoke-interface {v1}, Ltas/internal/camera/server/IServerCallback;->asBinder()Landroid/os/IBinder;

    move-result-object v1

    const/4 v2, 0x0

    invoke-interface {v1, p0, v2}, Landroid/os/IBinder;->linkToDeath(Landroid/os/IBinder$DeathRecipient;I)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    .line 403
    :cond_0
    :goto_0
    return-void

    .line 407
    :catch_0
    move-exception v0

    .line 408
    .local v0, "e":Landroid/os/RemoteException;
    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    goto :goto_0
.end method

.method private final name()Ljava/lang/String;
    .locals 1

    .prologue
    .line 251
    iget-object v0, p0, Ltas/internal/camera/server/ServerOutGoing$Client;->mProc:Landroid/app/ActivityManager$RunningAppProcessInfo;

    iget-object v0, v0, Landroid/app/ActivityManager$RunningAppProcessInfo;->processName:Ljava/lang/String;

    return-object v0
.end method

.method private notifyCableState(Ltas/internal/camera/server/RemoteMessage;)V
    .locals 3
    .param p1, "msg"    # Ltas/internal/camera/server/RemoteMessage;

    .prologue
    .line 294
    invoke-direct {p0, p1}, Ltas/internal/camera/server/ServerOutGoing$Client;->isTargetClient(Ltas/internal/camera/server/RemoteMessage;)Z

    move-result v1

    if-nez v1, :cond_0

    .line 295
    return-void

    .line 298
    :cond_0
    iget-object v1, p1, Ltas/internal/camera/server/RemoteMessage;->params:Ltas/internal/camera/InputParams;

    iget-object v1, v1, Ltas/internal/camera/InputParams;->cam:Ljava/lang/String;

    invoke-direct {p0, v1}, Ltas/internal/camera/server/ServerOutGoing$Client;->isWatching(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_1

    .line 299
    return-void

    .line 302
    :cond_1
    invoke-direct {p0}, Ltas/internal/camera/server/ServerOutGoing$Client;->isAlive()Z

    move-result v1

    if-nez v1, :cond_2

    .line 303
    iget-object v1, p0, Ltas/internal/camera/server/ServerOutGoing$Client;->TAG:Ljava/lang/String;

    const-string/jumbo v2, "client is dead"

    invoke-static {v1, v2}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 304
    return-void

    .line 308
    :cond_2
    :try_start_0
    iget-object v1, p0, Ltas/internal/camera/server/ServerOutGoing$Client;->mRemote:Ltas/internal/camera/server/IServerCallback;

    invoke-interface {v1, p1}, Ltas/internal/camera/server/IServerCallback;->onCableState(Ltas/internal/camera/server/RemoteMessage;)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    .line 293
    :goto_0
    return-void

    .line 309
    :catch_0
    move-exception v0

    .line 310
    .local v0, "e":Landroid/os/RemoteException;
    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    goto :goto_0
.end method

.method private notifyCameraMessage(Ltas/internal/camera/server/RemoteMessage;)V
    .locals 3
    .param p1, "msg"    # Ltas/internal/camera/server/RemoteMessage;

    .prologue
    .line 336
    invoke-direct {p0, p1}, Ltas/internal/camera/server/ServerOutGoing$Client;->isTargetClient(Ltas/internal/camera/server/RemoteMessage;)Z

    move-result v1

    if-nez v1, :cond_0

    .line 337
    return-void

    .line 340
    :cond_0
    iget-object v1, p1, Ltas/internal/camera/server/RemoteMessage;->params:Ltas/internal/camera/InputParams;

    iget-object v1, v1, Ltas/internal/camera/InputParams;->cam:Ljava/lang/String;

    invoke-direct {p0, v1}, Ltas/internal/camera/server/ServerOutGoing$Client;->isWatching(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_1

    .line 341
    return-void

    .line 344
    :cond_1
    invoke-direct {p0}, Ltas/internal/camera/server/ServerOutGoing$Client;->isAlive()Z

    move-result v1

    if-nez v1, :cond_2

    .line 345
    iget-object v1, p0, Ltas/internal/camera/server/ServerOutGoing$Client;->TAG:Ljava/lang/String;

    const-string/jumbo v2, "client is dead."

    invoke-static {v1, v2}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 346
    return-void

    .line 350
    :cond_2
    :try_start_0
    iget-object v1, p0, Ltas/internal/camera/server/ServerOutGoing$Client;->mRemote:Ltas/internal/camera/server/IServerCallback;

    invoke-interface {v1, p1}, Ltas/internal/camera/server/IServerCallback;->onCameraMessage(Ltas/internal/camera/server/RemoteMessage;)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    .line 335
    :goto_0
    return-void

    .line 351
    :catch_0
    move-exception v0

    .line 352
    .local v0, "e":Landroid/os/RemoteException;
    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    goto :goto_0
.end method

.method private notifyCameraState(Ltas/internal/camera/server/RemoteMessage;)V
    .locals 3
    .param p1, "msg"    # Ltas/internal/camera/server/RemoteMessage;

    .prologue
    .line 315
    invoke-direct {p0, p1}, Ltas/internal/camera/server/ServerOutGoing$Client;->isTargetClient(Ltas/internal/camera/server/RemoteMessage;)Z

    move-result v1

    if-nez v1, :cond_0

    .line 316
    return-void

    .line 319
    :cond_0
    iget-object v1, p1, Ltas/internal/camera/server/RemoteMessage;->params:Ltas/internal/camera/InputParams;

    iget-object v1, v1, Ltas/internal/camera/InputParams;->cam:Ljava/lang/String;

    invoke-direct {p0, v1}, Ltas/internal/camera/server/ServerOutGoing$Client;->isWatching(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_1

    .line 320
    return-void

    .line 323
    :cond_1
    invoke-direct {p0}, Ltas/internal/camera/server/ServerOutGoing$Client;->isAlive()Z

    move-result v1

    if-nez v1, :cond_2

    .line 324
    iget-object v1, p0, Ltas/internal/camera/server/ServerOutGoing$Client;->TAG:Ljava/lang/String;

    const-string/jumbo v2, "client is dead"

    invoke-static {v1, v2}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 325
    return-void

    .line 329
    :cond_2
    :try_start_0
    iget-object v1, p0, Ltas/internal/camera/server/ServerOutGoing$Client;->mRemote:Ltas/internal/camera/server/IServerCallback;

    invoke-interface {v1, p1}, Ltas/internal/camera/server/IServerCallback;->onCameraState(Ltas/internal/camera/server/RemoteMessage;)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    .line 314
    :goto_0
    return-void

    .line 330
    :catch_0
    move-exception v0

    .line 331
    .local v0, "e":Landroid/os/RemoteException;
    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    goto :goto_0
.end method

.method private notifyExtraState(Ltas/internal/camera/server/RemoteMessage;)V
    .locals 3
    .param p1, "msg"    # Ltas/internal/camera/server/RemoteMessage;

    .prologue
    .line 357
    invoke-direct {p0, p1}, Ltas/internal/camera/server/ServerOutGoing$Client;->isTargetClient(Ltas/internal/camera/server/RemoteMessage;)Z

    move-result v1

    if-nez v1, :cond_0

    .line 358
    return-void

    .line 361
    :cond_0
    iget-object v1, p1, Ltas/internal/camera/server/RemoteMessage;->params:Ltas/internal/camera/InputParams;

    iget-object v1, v1, Ltas/internal/camera/InputParams;->cam:Ljava/lang/String;

    invoke-direct {p0, v1}, Ltas/internal/camera/server/ServerOutGoing$Client;->isWatching(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_1

    .line 362
    return-void

    .line 365
    :cond_1
    invoke-direct {p0}, Ltas/internal/camera/server/ServerOutGoing$Client;->isAlive()Z

    move-result v1

    if-nez v1, :cond_2

    .line 366
    iget-object v1, p0, Ltas/internal/camera/server/ServerOutGoing$Client;->TAG:Ljava/lang/String;

    const-string/jumbo v2, "client is dead."

    invoke-static {v1, v2}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 367
    return-void

    .line 371
    :cond_2
    :try_start_0
    iget-object v1, p0, Ltas/internal/camera/server/ServerOutGoing$Client;->mRemote:Ltas/internal/camera/server/IServerCallback;

    invoke-interface {v1, p1}, Ltas/internal/camera/server/IServerCallback;->onExtraState(Ltas/internal/camera/server/RemoteMessage;)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    .line 356
    :goto_0
    return-void

    .line 372
    :catch_0
    move-exception v0

    .line 373
    .local v0, "e":Landroid/os/RemoteException;
    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    goto :goto_0
.end method

.method private notifyInitialState(Ltas/internal/camera/server/RemoteMessage;)V
    .locals 2
    .param p1, "msg"    # Ltas/internal/camera/server/RemoteMessage;

    .prologue
    .line 392
    :try_start_0
    iget-object v1, p0, Ltas/internal/camera/server/ServerOutGoing$Client;->mRemote:Ltas/internal/camera/server/IServerCallback;

    invoke-interface {v1, p1}, Ltas/internal/camera/server/IServerCallback;->onInitialState(Ltas/internal/camera/server/RemoteMessage;)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    .line 390
    :goto_0
    return-void

    .line 393
    :catch_0
    move-exception v0

    .line 394
    .local v0, "e":Landroid/os/RemoteException;
    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    goto :goto_0
.end method

.method private notifyMediaServerState(Ltas/internal/camera/server/RemoteMessage;)V
    .locals 3
    .param p1, "msg"    # Ltas/internal/camera/server/RemoteMessage;

    .prologue
    .line 378
    invoke-direct {p0}, Ltas/internal/camera/server/ServerOutGoing$Client;->isAlive()Z

    move-result v1

    if-nez v1, :cond_0

    .line 379
    iget-object v1, p0, Ltas/internal/camera/server/ServerOutGoing$Client;->TAG:Ljava/lang/String;

    const-string/jumbo v2, "client is dead"

    invoke-static {v1, v2}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 380
    return-void

    .line 384
    :cond_0
    :try_start_0
    iget-object v1, p0, Ltas/internal/camera/server/ServerOutGoing$Client;->mRemote:Ltas/internal/camera/server/IServerCallback;

    invoke-interface {v1, p1}, Ltas/internal/camera/server/IServerCallback;->onMediaServerState(Ltas/internal/camera/server/RemoteMessage;)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    .line 377
    :goto_0
    return-void

    .line 385
    :catch_0
    move-exception v0

    .line 386
    .local v0, "e":Landroid/os/RemoteException;
    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    goto :goto_0
.end method

.method private final pid()I
    .locals 1

    .prologue
    .line 250
    iget-object v0, p0, Ltas/internal/camera/server/ServerOutGoing$Client;->mProc:Landroid/app/ActivityManager$RunningAppProcessInfo;

    iget v0, v0, Landroid/app/ActivityManager$RunningAppProcessInfo;->pid:I

    return v0
.end method

.method private unlinkToDeath()V
    .locals 2

    .prologue
    .line 414
    iget-object v0, p0, Ltas/internal/camera/server/ServerOutGoing$Client;->mRemote:Ltas/internal/camera/server/IServerCallback;

    if-eqz v0, :cond_0

    .line 415
    iget-object v0, p0, Ltas/internal/camera/server/ServerOutGoing$Client;->mRemote:Ltas/internal/camera/server/IServerCallback;

    invoke-interface {v0}, Ltas/internal/camera/server/IServerCallback;->asBinder()Landroid/os/IBinder;

    move-result-object v0

    const/4 v1, 0x0

    invoke-interface {v0, p0, v1}, Landroid/os/IBinder;->unlinkToDeath(Landroid/os/IBinder$DeathRecipient;I)Z

    .line 413
    :cond_0
    return-void
.end method

.method private unwatch(Ljava/lang/String;)V
    .locals 3
    .param p1, "cam"    # Ljava/lang/String;

    .prologue
    .line 274
    invoke-direct {p0, p1}, Ltas/internal/camera/server/ServerOutGoing$Client;->isWatching(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 275
    iget-object v0, p0, Ltas/internal/camera/server/ServerOutGoing$Client;->mConcern:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->remove(Ljava/lang/Object;)Z

    .line 276
    iget-object v0, p0, Ltas/internal/camera/server/ServerOutGoing$Client;->TAG:Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "unwatch - "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 273
    :cond_0
    return-void
.end method

.method private unwatchall()V
    .locals 1

    .prologue
    .line 281
    iget-object v0, p0, Ltas/internal/camera/server/ServerOutGoing$Client;->mConcern:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->clear()V

    .line 280
    return-void
.end method

.method private verifyPackageName(Ljava/lang/String;)Z
    .locals 6
    .param p1, "pkg"    # Ljava/lang/String;

    .prologue
    const/4 v2, 0x0

    .line 259
    if-nez p1, :cond_0

    return v2

    .line 260
    :cond_0
    iget-object v1, p0, Ltas/internal/camera/server/ServerOutGoing$Client;->mProc:Landroid/app/ActivityManager$RunningAppProcessInfo;

    iget-object v3, v1, Landroid/app/ActivityManager$RunningAppProcessInfo;->pkgList:[Ljava/lang/String;

    array-length v4, v3

    move v1, v2

    :goto_0
    if-ge v1, v4, :cond_2

    aget-object v0, v3, v1

    .line 261
    .local v0, "p":Ljava/lang/String;
    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_1

    const/4 v1, 0x1

    return v1

    .line 260
    :cond_1
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    .line 263
    .end local v0    # "p":Ljava/lang/String;
    :cond_2
    return v2
.end method

.method private verifyProcessName(Ljava/lang/String;)Z
    .locals 1
    .param p1, "procName"    # Ljava/lang/String;

    .prologue
    .line 255
    iget-object v0, p0, Ltas/internal/camera/server/ServerOutGoing$Client;->mProc:Landroid/app/ActivityManager$RunningAppProcessInfo;

    iget-object v0, v0, Landroid/app/ActivityManager$RunningAppProcessInfo;->processName:Ljava/lang/String;

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    return v0
.end method

.method private watch(Ljava/lang/String;)V
    .locals 3
    .param p1, "cam"    # Ljava/lang/String;

    .prologue
    .line 267
    invoke-direct {p0, p1}, Ltas/internal/camera/server/ServerOutGoing$Client;->isWatching(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_0

    .line 268
    iget-object v0, p0, Ltas/internal/camera/server/ServerOutGoing$Client;->mConcern:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 269
    iget-object v0, p0, Ltas/internal/camera/server/ServerOutGoing$Client;->TAG:Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "watch - "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 266
    :cond_0
    return-void
.end method


# virtual methods
.method public binderDied()V
    .locals 3

    .prologue
    .line 421
    iget-object v0, p0, Ltas/internal/camera/server/ServerOutGoing$Client;->TAG:Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "client : "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-direct {p0}, Ltas/internal/camera/server/ServerOutGoing$Client;->pid()I

    move-result v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string/jumbo v2, " is dead"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 422
    const/4 v0, 0x0

    iput-object v0, p0, Ltas/internal/camera/server/ServerOutGoing$Client;->mRemote:Ltas/internal/camera/server/IServerCallback;

    .line 423
    iget-object v0, p0, Ltas/internal/camera/server/ServerOutGoing$Client;->mServer:Ltas/internal/camera/server/ServerOutGoing;

    invoke-static {v0, p0}, Ltas/internal/camera/server/ServerOutGoing;->-wrap0(Ltas/internal/camera/server/ServerOutGoing;Ltas/internal/camera/server/ServerOutGoing$Client;)V

    .line 420
    return-void
.end method
