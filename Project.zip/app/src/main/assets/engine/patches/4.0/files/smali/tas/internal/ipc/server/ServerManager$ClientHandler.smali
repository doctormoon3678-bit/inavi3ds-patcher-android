.class Ltas/internal/ipc/server/ServerManager$ClientHandler;
.super Landroid/os/Handler;
.source "ServerManager.java"

# interfaces
.implements Landroid/os/IBinder$DeathRecipient;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltas/internal/ipc/server/ServerManager;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "ClientHandler"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;
    }
.end annotation


# instance fields
.field private mCallback:Ltas/internal/ipc/server/IServerCallback;

.field private mHT:Landroid/os/HandlerThread;

.field private mM:Ljava/lang/ref/WeakReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference",
            "<",
            "Ltas/internal/ipc/server/ServerManager;",
            ">;"
        }
    .end annotation
.end field

.field private final mReceivers:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List",
            "<",
            "Ltas/internal/ipc/server/ServerManager$ReceiverHolder;",
            ">;"
        }
    .end annotation
.end field

.field private final mSenders:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List",
            "<",
            "Ltas/internal/ipc/server/ServerManager$SenderHolder;",
            ">;"
        }
    .end annotation
.end field

.field final pid:I

.field final tid:I


# direct methods
.method static synthetic -get0(Ltas/internal/ipc/server/ServerManager$ClientHandler;)Ljava/util/List;
    .locals 1

    iget-object v0, p0, Ltas/internal/ipc/server/ServerManager$ClientHandler;->mReceivers:Ljava/util/List;

    return-object v0
.end method

.method static synthetic -get1(Ltas/internal/ipc/server/ServerManager$ClientHandler;)Ljava/util/List;
    .locals 1

    iget-object v0, p0, Ltas/internal/ipc/server/ServerManager$ClientHandler;->mSenders:Ljava/util/List;

    return-object v0
.end method

.method static synthetic -wrap0(Ltas/internal/ipc/server/ServerManager$ClientHandler;ILtas/internal/ipc/server/RemoteReceiver;)V
    .locals 0
    .param p1, "what"    # I
    .param p2, "receiver"    # Ltas/internal/ipc/server/RemoteReceiver;

    .prologue
    invoke-direct {p0, p1, p2}, Ltas/internal/ipc/server/ServerManager$ClientHandler;->schedule(ILtas/internal/ipc/server/RemoteReceiver;)V

    return-void
.end method

.method static synthetic -wrap1(Ltas/internal/ipc/server/ServerManager$ClientHandler;ILtas/internal/ipc/server/RemoteSender;)V
    .locals 0
    .param p1, "what"    # I
    .param p2, "sender"    # Ltas/internal/ipc/server/RemoteSender;

    .prologue
    invoke-direct {p0, p1, p2}, Ltas/internal/ipc/server/ServerManager$ClientHandler;->schedule(ILtas/internal/ipc/server/RemoteSender;)V

    return-void
.end method

.method static synthetic -wrap2(Ltas/internal/ipc/server/ServerManager$ClientHandler;Ltas/internal/ipc/server/IServerCallback;)V
    .locals 0
    .param p1, "cb"    # Ltas/internal/ipc/server/IServerCallback;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/ipc/server/ServerManager$ClientHandler;->schedule(Ltas/internal/ipc/server/IServerCallback;)V

    return-void
.end method

.method static synthetic -wrap3(Ltas/internal/ipc/server/ServerManager$ClientHandler;Ltas/internal/ipc/server/RemoteMessage;)V
    .locals 0
    .param p1, "rmsg"    # Ltas/internal/ipc/server/RemoteMessage;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/ipc/server/ServerManager$ClientHandler;->schedule(Ltas/internal/ipc/server/RemoteMessage;)V

    return-void
.end method

.method private constructor <init>(Ltas/internal/ipc/server/ServerManager;Landroid/os/HandlerThread;II)V
    .locals 3
    .param p1, "m"    # Ltas/internal/ipc/server/ServerManager;
    .param p2, "ht"    # Landroid/os/HandlerThread;
    .param p3, "_pid"    # I
    .param p4, "_tid"    # I

    .prologue
    .line 196
    invoke-virtual {p2}, Landroid/os/HandlerThread;->getLooper()Landroid/os/Looper;

    move-result-object v0

    invoke-direct {p0, v0}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 181
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 180
    iput-object v0, p0, Ltas/internal/ipc/server/ServerManager$ClientHandler;->mSenders:Ljava/util/List;

    .line 184
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 183
    iput-object v0, p0, Ltas/internal/ipc/server/ServerManager$ClientHandler;->mReceivers:Ljava/util/List;

    .line 197
    iput p3, p0, Ltas/internal/ipc/server/ServerManager$ClientHandler;->pid:I

    .line 198
    iput p4, p0, Ltas/internal/ipc/server/ServerManager$ClientHandler;->tid:I

    .line 199
    iput-object p2, p0, Ltas/internal/ipc/server/ServerManager$ClientHandler;->mHT:Landroid/os/HandlerThread;

    .line 200
    new-instance v0, Ljava/lang/ref/WeakReference;

    invoke-direct {v0, p1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    iput-object v0, p0, Ltas/internal/ipc/server/ServerManager$ClientHandler;->mM:Ljava/lang/ref/WeakReference;

    .line 201
    const-string/jumbo v0, "TasIPC<ServerManager>"

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "client init. p="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget v2, p0, Ltas/internal/ipc/server/ServerManager$ClientHandler;->pid:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string/jumbo v2, ", t="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget v2, p0, Ltas/internal/ipc/server/ServerManager$ClientHandler;->tid:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 195
    return-void
.end method

.method synthetic constructor <init>(Ltas/internal/ipc/server/ServerManager;Landroid/os/HandlerThread;IILtas/internal/ipc/server/ServerManager$ClientHandler;)V
    .locals 0
    .param p1, "m"    # Ltas/internal/ipc/server/ServerManager;
    .param p2, "ht"    # Landroid/os/HandlerThread;
    .param p3, "_pid"    # I
    .param p4, "_tid"    # I

    .prologue
    invoke-direct {p0, p1, p2, p3, p4}, Ltas/internal/ipc/server/ServerManager$ClientHandler;-><init>(Ltas/internal/ipc/server/ServerManager;Landroid/os/HandlerThread;II)V

    return-void
.end method

.method private cancelAll()V
    .locals 2

    .prologue
    const/4 v1, 0x0

    .line 253
    iget-object v0, p0, Ltas/internal/ipc/server/ServerManager$ClientHandler;->mHT:Landroid/os/HandlerThread;

    if-eqz v0, :cond_0

    .line 254
    invoke-virtual {p0, v1}, Ltas/internal/ipc/server/ServerManager$ClientHandler;->removeCallbacksAndMessages(Ljava/lang/Object;)V

    .line 252
    :cond_0
    return-void
.end method

.method private findReceiver(Ljava/lang/String;)Ltas/internal/ipc/server/ServerManager$ReceiverHolder;
    .locals 4
    .param p1, "receiver"    # Ljava/lang/String;

    .prologue
    const/4 v3, 0x0

    .line 286
    iget-object v2, p0, Ltas/internal/ipc/server/ServerManager$ClientHandler;->mReceivers:Ljava/util/List;

    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    .local v1, "rh$iterator":Ljava/util/Iterator;
    :cond_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;

    .line 287
    .local v0, "rh":Ltas/internal/ipc/server/ServerManager$ReceiverHolder;
    if-eqz v0, :cond_0

    invoke-static {v0}, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->-get0(Ltas/internal/ipc/server/ServerManager$ReceiverHolder;)Ltas/internal/ipc/server/RemoteReceiver;

    move-result-object v2

    iget-object v2, v2, Ltas/internal/ipc/server/RemoteReceiver;->name:Ljava/lang/String;

    invoke-virtual {v2, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_0

    .line 288
    return-object v0

    .line 291
    .end local v0    # "rh":Ltas/internal/ipc/server/ServerManager$ReceiverHolder;
    :cond_1
    return-object v3
.end method

.method private findReceiver(Ltas/internal/ipc/server/RemoteReceiver;)Ltas/internal/ipc/server/ServerManager$ReceiverHolder;
    .locals 7
    .param p1, "receiver"    # Ltas/internal/ipc/server/RemoteReceiver;

    .prologue
    const/4 v6, 0x0

    .line 268
    iget-object v2, p0, Ltas/internal/ipc/server/ServerManager$ClientHandler;->mReceivers:Ljava/util/List;

    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    .local v1, "rh$iterator":Ljava/util/Iterator;
    :cond_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;

    .line 269
    .local v0, "rh":Ltas/internal/ipc/server/ServerManager$ReceiverHolder;
    if-eqz v0, :cond_0

    invoke-static {v0}, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->-get0(Ltas/internal/ipc/server/ServerManager$ReceiverHolder;)Ltas/internal/ipc/server/RemoteReceiver;

    move-result-object v2

    invoke-virtual {v2}, Ltas/internal/ipc/server/RemoteReceiver;->getid()J

    move-result-wide v2

    invoke-virtual {p1}, Ltas/internal/ipc/server/RemoteReceiver;->getid()J

    move-result-wide v4

    cmp-long v2, v2, v4

    if-nez v2, :cond_0

    .line 270
    return-object v0

    .line 273
    .end local v0    # "rh":Ltas/internal/ipc/server/ServerManager$ReceiverHolder;
    :cond_1
    return-object v6
.end method

.method private findSender(Ljava/lang/String;)Ltas/internal/ipc/server/ServerManager$SenderHolder;
    .locals 4
    .param p1, "sender"    # Ljava/lang/String;

    .prologue
    const/4 v3, 0x0

    .line 277
    iget-object v2, p0, Ltas/internal/ipc/server/ServerManager$ClientHandler;->mSenders:Ljava/util/List;

    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    .local v1, "sh$iterator":Ljava/util/Iterator;
    :cond_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/ipc/server/ServerManager$SenderHolder;

    .line 278
    .local v0, "sh":Ltas/internal/ipc/server/ServerManager$SenderHolder;
    if-eqz v0, :cond_0

    invoke-static {v0}, Ltas/internal/ipc/server/ServerManager$SenderHolder;->-get1(Ltas/internal/ipc/server/ServerManager$SenderHolder;)Ltas/internal/ipc/server/RemoteSender;

    move-result-object v2

    iget-object v2, v2, Ltas/internal/ipc/server/RemoteSender;->name:Ljava/lang/String;

    invoke-virtual {v2, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_0

    .line 279
    return-object v0

    .line 282
    .end local v0    # "sh":Ltas/internal/ipc/server/ServerManager$SenderHolder;
    :cond_1
    return-object v3
.end method

.method private findSender(Ltas/internal/ipc/server/RemoteSender;)Ltas/internal/ipc/server/ServerManager$SenderHolder;
    .locals 7
    .param p1, "sender"    # Ltas/internal/ipc/server/RemoteSender;

    .prologue
    const/4 v6, 0x0

    .line 259
    iget-object v2, p0, Ltas/internal/ipc/server/ServerManager$ClientHandler;->mSenders:Ljava/util/List;

    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    .local v1, "sh$iterator":Ljava/util/Iterator;
    :cond_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/ipc/server/ServerManager$SenderHolder;

    .line 260
    .local v0, "sh":Ltas/internal/ipc/server/ServerManager$SenderHolder;
    if-eqz v0, :cond_0

    invoke-static {v0}, Ltas/internal/ipc/server/ServerManager$SenderHolder;->-get1(Ltas/internal/ipc/server/ServerManager$SenderHolder;)Ltas/internal/ipc/server/RemoteSender;

    move-result-object v2

    invoke-virtual {v2}, Ltas/internal/ipc/server/RemoteSender;->getid()J

    move-result-wide v2

    invoke-virtual {p1}, Ltas/internal/ipc/server/RemoteSender;->getid()J

    move-result-wide v4

    cmp-long v2, v2, v4

    if-nez v2, :cond_0

    .line 261
    return-object v0

    .line 264
    .end local v0    # "sh":Ltas/internal/ipc/server/ServerManager$SenderHolder;
    :cond_1
    return-object v6
.end method

.method private linkToDeath(Landroid/os/IBinder;)V
    .locals 2
    .param p1, "binder"    # Landroid/os/IBinder;

    .prologue
    .line 1063
    const/4 v1, 0x0

    :try_start_0
    invoke-interface {p1, p0, v1}, Landroid/os/IBinder;->linkToDeath(Landroid/os/IBinder$DeathRecipient;I)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    .line 1061
    :goto_0
    return-void

    .line 1064
    :catch_0
    move-exception v0

    .line 1065
    .local v0, "e":Landroid/os/RemoteException;
    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    goto :goto_0
.end method

.method private quit()V
    .locals 1

    .prologue
    .line 247
    iget-object v0, p0, Ltas/internal/ipc/server/ServerManager$ClientHandler;->mHT:Landroid/os/HandlerThread;

    if-eqz v0, :cond_0

    .line 248
    const/16 v0, 0x16

    invoke-virtual {p0, v0}, Ltas/internal/ipc/server/ServerManager$ClientHandler;->sendEmptyMessage(I)Z

    .line 246
    :cond_0
    return-void
.end method

.method private schedule(ILtas/internal/ipc/server/RemoteReceiver;)V
    .locals 2
    .param p1, "what"    # I
    .param p2, "receiver"    # Ltas/internal/ipc/server/RemoteReceiver;

    .prologue
    const/4 v1, 0x0

    .line 211
    iget-object v0, p0, Ltas/internal/ipc/server/ServerManager$ClientHandler;->mHT:Landroid/os/HandlerThread;

    if-eqz v0, :cond_0

    .line 212
    invoke-virtual {p0, p1, v1, v1, p2}, Ltas/internal/ipc/server/ServerManager$ClientHandler;->obtainMessage(IIILjava/lang/Object;)Landroid/os/Message;

    move-result-object v0

    invoke-virtual {p0, v0}, Ltas/internal/ipc/server/ServerManager$ClientHandler;->sendMessage(Landroid/os/Message;)Z

    .line 210
    :cond_0
    return-void
.end method

.method private schedule(ILtas/internal/ipc/server/RemoteSender;)V
    .locals 2
    .param p1, "what"    # I
    .param p2, "sender"    # Ltas/internal/ipc/server/RemoteSender;

    .prologue
    const/4 v1, 0x0

    .line 217
    iget-object v0, p0, Ltas/internal/ipc/server/ServerManager$ClientHandler;->mHT:Landroid/os/HandlerThread;

    if-eqz v0, :cond_0

    .line 218
    invoke-virtual {p0, p1, v1, v1, p2}, Ltas/internal/ipc/server/ServerManager$ClientHandler;->obtainMessage(IIILjava/lang/Object;)Landroid/os/Message;

    move-result-object v0

    invoke-virtual {p0, v0}, Ltas/internal/ipc/server/ServerManager$ClientHandler;->sendMessage(Landroid/os/Message;)Z

    .line 216
    :cond_0
    return-void
.end method

.method private schedule(ILtas/internal/ipc/server/ServerManager$ClientHandler$Holder;)V
    .locals 2
    .param p1, "what"    # I
    .param p2, "holder"    # Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;

    .prologue
    const/4 v1, 0x0

    .line 205
    iget-object v0, p0, Ltas/internal/ipc/server/ServerManager$ClientHandler;->mHT:Landroid/os/HandlerThread;

    if-eqz v0, :cond_0

    .line 206
    invoke-virtual {p0, p1, v1, v1, p2}, Ltas/internal/ipc/server/ServerManager$ClientHandler;->obtainMessage(IIILjava/lang/Object;)Landroid/os/Message;

    move-result-object v0

    invoke-virtual {p0, v0}, Ltas/internal/ipc/server/ServerManager$ClientHandler;->sendMessage(Landroid/os/Message;)Z

    .line 204
    :cond_0
    return-void
.end method

.method private schedule(ILtas/internal/ipc/server/ServerManager$ReceiverHolder;)V
    .locals 2
    .param p1, "what"    # I
    .param p2, "receiver"    # Ltas/internal/ipc/server/ServerManager$ReceiverHolder;

    .prologue
    const/4 v1, 0x0

    .line 223
    iget-object v0, p0, Ltas/internal/ipc/server/ServerManager$ClientHandler;->mHT:Landroid/os/HandlerThread;

    if-eqz v0, :cond_0

    .line 224
    invoke-virtual {p0, p1, v1, v1, p2}, Ltas/internal/ipc/server/ServerManager$ClientHandler;->obtainMessage(IIILjava/lang/Object;)Landroid/os/Message;

    move-result-object v0

    invoke-virtual {p0, v0}, Ltas/internal/ipc/server/ServerManager$ClientHandler;->sendMessage(Landroid/os/Message;)Z

    .line 222
    :cond_0
    return-void
.end method

.method private schedule(ILtas/internal/ipc/server/ServerManager$SenderHolder;)V
    .locals 2
    .param p1, "what"    # I
    .param p2, "sender"    # Ltas/internal/ipc/server/ServerManager$SenderHolder;

    .prologue
    const/4 v1, 0x0

    .line 229
    iget-object v0, p0, Ltas/internal/ipc/server/ServerManager$ClientHandler;->mHT:Landroid/os/HandlerThread;

    if-eqz v0, :cond_0

    .line 230
    invoke-virtual {p0, p1, v1, v1, p2}, Ltas/internal/ipc/server/ServerManager$ClientHandler;->obtainMessage(IIILjava/lang/Object;)Landroid/os/Message;

    move-result-object v0

    invoke-virtual {p0, v0}, Ltas/internal/ipc/server/ServerManager$ClientHandler;->sendMessage(Landroid/os/Message;)Z

    .line 228
    :cond_0
    return-void
.end method

.method private schedule(Ltas/internal/ipc/server/IServerCallback;)V
    .locals 2
    .param p1, "cb"    # Ltas/internal/ipc/server/IServerCallback;

    .prologue
    const/4 v1, 0x0

    .line 235
    iget-object v0, p0, Ltas/internal/ipc/server/ServerManager$ClientHandler;->mHT:Landroid/os/HandlerThread;

    if-eqz v0, :cond_0

    .line 236
    const/16 v0, 0xe

    invoke-virtual {p0, v0, v1, v1, p1}, Ltas/internal/ipc/server/ServerManager$ClientHandler;->obtainMessage(IIILjava/lang/Object;)Landroid/os/Message;

    move-result-object v0

    invoke-virtual {p0, v0}, Ltas/internal/ipc/server/ServerManager$ClientHandler;->sendMessage(Landroid/os/Message;)Z

    .line 234
    :cond_0
    return-void
.end method

.method private schedule(Ltas/internal/ipc/server/RemoteMessage;)V
    .locals 2
    .param p1, "rmsg"    # Ltas/internal/ipc/server/RemoteMessage;

    .prologue
    const/4 v1, 0x0

    .line 241
    iget-object v0, p0, Ltas/internal/ipc/server/ServerManager$ClientHandler;->mHT:Landroid/os/HandlerThread;

    if-eqz v0, :cond_0

    .line 242
    const/16 v0, 0xf

    invoke-virtual {p0, v0, v1, v1, p1}, Ltas/internal/ipc/server/ServerManager$ClientHandler;->obtainMessage(IIILjava/lang/Object;)Landroid/os/Message;

    move-result-object v0

    invoke-virtual {p0, v0}, Ltas/internal/ipc/server/ServerManager$ClientHandler;->sendMessage(Landroid/os/Message;)Z

    .line 240
    :cond_0
    return-void
.end method

.method private unlinkToDeath(Landroid/os/IBinder;)V
    .locals 1
    .param p1, "binder"    # Landroid/os/IBinder;

    .prologue
    .line 1070
    const/4 v0, 0x0

    invoke-interface {p1, p0, v0}, Landroid/os/IBinder;->unlinkToDeath(Landroid/os/IBinder$DeathRecipient;I)Z

    .line 1069
    return-void
.end method


# virtual methods
.method public binderDied()V
    .locals 8

    .prologue
    .line 1039
    const-string/jumbo v5, "TasIPC<ServerManager>"

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v7, "client:"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    iget v7, p0, Ltas/internal/ipc/server/ServerManager$ClientHandler;->pid:I

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string/jumbo v7, " is dead."

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v5, v6}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 1040
    iget-object v5, p0, Ltas/internal/ipc/server/ServerManager$ClientHandler;->mM:Ljava/lang/ref/WeakReference;

    invoke-virtual {v5}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/ipc/server/ServerManager;

    .line 1041
    .local v0, "m":Ltas/internal/ipc/server/ServerManager;
    if-nez v0, :cond_0

    .line 1042
    const-string/jumbo v5, "TasIPC<ServerManager>"

    const-string/jumbo v6, "server is dead."

    invoke-static {v5, v6}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 1043
    return-void

    .line 1046
    :cond_0
    monitor-enter v0

    .line 1047
    :try_start_0
    invoke-direct {p0}, Ltas/internal/ipc/server/ServerManager$ClientHandler;->cancelAll()V

    .line 1049
    iget-object v5, p0, Ltas/internal/ipc/server/ServerManager$ClientHandler;->mSenders:Ljava/util/List;

    invoke-interface {v5}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v4

    .local v4, "sh$iterator":Ljava/util/Iterator;
    :cond_1
    :goto_0
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_2

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ltas/internal/ipc/server/ServerManager$SenderHolder;

    .line 1050
    .local v3, "sh":Ltas/internal/ipc/server/ServerManager$SenderHolder;
    if-eqz v3, :cond_1

    invoke-static {v3}, Ltas/internal/ipc/server/ServerManager$SenderHolder;->-wrap5(Ltas/internal/ipc/server/ServerManager$SenderHolder;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    .line 1046
    .end local v3    # "sh":Ltas/internal/ipc/server/ServerManager$SenderHolder;
    .end local v4    # "sh$iterator":Ljava/util/Iterator;
    :catchall_0
    move-exception v5

    monitor-exit v0

    throw v5

    .line 1053
    .restart local v4    # "sh$iterator":Ljava/util/Iterator;
    :cond_2
    :try_start_1
    iget-object v5, p0, Ltas/internal/ipc/server/ServerManager$ClientHandler;->mReceivers:Ljava/util/List;

    invoke-interface {v5}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v2

    .local v2, "rh$iterator":Ljava/util/Iterator;
    :cond_3
    :goto_1
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_4

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;

    .line 1054
    .local v1, "rh":Ltas/internal/ipc/server/ServerManager$ReceiverHolder;
    if-eqz v1, :cond_3

    invoke-static {v1}, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->-wrap5(Ltas/internal/ipc/server/ServerManager$ReceiverHolder;)V

    goto :goto_1

    .line 1057
    .end local v1    # "rh":Ltas/internal/ipc/server/ServerManager$ReceiverHolder;
    :cond_4
    invoke-direct {p0}, Ltas/internal/ipc/server/ServerManager$ClientHandler;->quit()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    monitor-exit v0

    .line 1038
    return-void
.end method

.method public handleMessage(Landroid/os/Message;)V
    .locals 24
    .param p1, "msg"    # Landroid/os/Message;

    .prologue
    .line 296
    move-object/from16 v0, p0

    iget-object v0, v0, Ltas/internal/ipc/server/ServerManager$ClientHandler;->mM:Ljava/lang/ref/WeakReference;

    move-object/from16 v21, v0

    invoke-virtual/range {v21 .. v21}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ltas/internal/ipc/server/ServerManager;

    .line 297
    .local v9, "m":Ltas/internal/ipc/server/ServerManager;
    if-nez v9, :cond_0

    .line 298
    const-string/jumbo v21, "TasIPC<ServerManager>"

    new-instance v22, Ljava/lang/StringBuilder;

    invoke-direct/range {v22 .. v22}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v23, "handleMessage["

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    move-object/from16 v0, v22

    move-object/from16 v1, p1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v22

    const-string/jumbo v23, "]: server is dead."

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    invoke-virtual/range {v22 .. v22}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v22

    invoke-static/range {v21 .. v22}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 299
    invoke-virtual {v9}, Ltas/internal/ipc/server/ServerManager;->dump()V

    .line 300
    return-void

    .line 303
    :cond_0
    move-object/from16 v0, p1

    iget v0, v0, Landroid/os/Message;->what:I

    move/from16 v21, v0

    packed-switch v21, :pswitch_data_0

    .line 295
    :cond_1
    :goto_0
    return-void

    .line 305
    :pswitch_0
    monitor-enter v9

    .line 306
    :try_start_0
    move-object/from16 v0, p1

    iget-object v15, v0, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v15, Ltas/internal/ipc/server/RemoteReceiver;

    .line 307
    .local v15, "rr":Ltas/internal/ipc/server/RemoteReceiver;
    move-object/from16 v0, p0

    invoke-direct {v0, v15}, Ltas/internal/ipc/server/ServerManager$ClientHandler;->findReceiver(Ltas/internal/ipc/server/RemoteReceiver;)Ltas/internal/ipc/server/ServerManager$ReceiverHolder;

    move-result-object v12

    .line 308
    .local v12, "rh":Ltas/internal/ipc/server/ServerManager$ReceiverHolder;
    if-eqz v12, :cond_2

    .line 309
    const-string/jumbo v21, "TasIPC<ServerManager>"

    new-instance v22, Ljava/lang/StringBuilder;

    invoke-direct/range {v22 .. v22}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v23, "r("

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    iget-object v0, v15, Ltas/internal/ipc/server/RemoteReceiver;->name:Ljava/lang/String;

    move-object/from16 v23, v0

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    const-string/jumbo v23, ") already registered."

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    invoke-virtual/range {v22 .. v22}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v22

    invoke-static/range {v21 .. v22}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 310
    invoke-virtual {v15}, Ltas/internal/ipc/server/RemoteReceiver;->recycle()V

    .line 311
    invoke-virtual {v9}, Ltas/internal/ipc/server/ServerManager;->dump()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .end local v12    # "rh":Ltas/internal/ipc/server/ServerManager$ReceiverHolder;
    .end local v15    # "rr":Ltas/internal/ipc/server/RemoteReceiver;
    :goto_1
    monitor-exit v9

    goto :goto_0

    .line 316
    .restart local v12    # "rh":Ltas/internal/ipc/server/ServerManager$ReceiverHolder;
    .restart local v15    # "rr":Ltas/internal/ipc/server/RemoteReceiver;
    :cond_2
    :try_start_1
    const-string/jumbo v21, "TasIPC<ServerManager>"

    new-instance v22, Ljava/lang/StringBuilder;

    invoke-direct/range {v22 .. v22}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v23, "r("

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    iget-object v0, v15, Ltas/internal/ipc/server/RemoteReceiver;->name:Ljava/lang/String;

    move-object/from16 v23, v0

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    const-string/jumbo v23, ") registered."

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    invoke-virtual/range {v22 .. v22}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v22

    invoke-static/range {v21 .. v22}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 319
    new-instance v12, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;

    .end local v12    # "rh":Ltas/internal/ipc/server/ServerManager$ReceiverHolder;
    new-instance v21, Ltas/internal/ipc/server/RemoteReceiver;

    move-object/from16 v0, v21

    invoke-direct {v0, v15}, Ltas/internal/ipc/server/RemoteReceiver;-><init>(Ltas/internal/ipc/server/RemoteReceiver;)V

    const/16 v22, 0x0

    move-object/from16 v0, p0

    move-object/from16 v1, v21

    move-object/from16 v2, v22

    invoke-direct {v12, v0, v1, v2}, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;-><init>(Ltas/internal/ipc/server/ServerManager$ClientHandler;Ltas/internal/ipc/server/RemoteReceiver;Ltas/internal/ipc/server/ServerManager$ReceiverHolder;)V

    .line 320
    .restart local v12    # "rh":Ltas/internal/ipc/server/ServerManager$ReceiverHolder;
    move-object/from16 v0, p0

    iget-object v0, v0, Ltas/internal/ipc/server/ServerManager$ClientHandler;->mReceivers:Ljava/util/List;

    move-object/from16 v21, v0

    move-object/from16 v0, v21

    invoke-interface {v0, v12}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 321
    invoke-virtual {v15}, Ltas/internal/ipc/server/RemoteReceiver;->recycle()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_1

    .line 305
    .end local v12    # "rh":Ltas/internal/ipc/server/ServerManager$ReceiverHolder;
    .end local v15    # "rr":Ltas/internal/ipc/server/RemoteReceiver;
    :catchall_0
    move-exception v21

    monitor-exit v9

    throw v21

    .line 326
    :pswitch_1
    monitor-enter v9

    .line 327
    :try_start_2
    move-object/from16 v0, p1

    iget-object v15, v0, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v15, Ltas/internal/ipc/server/RemoteReceiver;

    .line 328
    .restart local v15    # "rr":Ltas/internal/ipc/server/RemoteReceiver;
    move-object/from16 v0, p0

    invoke-direct {v0, v15}, Ltas/internal/ipc/server/ServerManager$ClientHandler;->findReceiver(Ltas/internal/ipc/server/RemoteReceiver;)Ltas/internal/ipc/server/ServerManager$ReceiverHolder;

    move-result-object v12

    .line 329
    .restart local v12    # "rh":Ltas/internal/ipc/server/ServerManager$ReceiverHolder;
    if-nez v12, :cond_3

    .line 330
    const-string/jumbo v21, "TasIPC<ServerManager>"

    new-instance v22, Ljava/lang/StringBuilder;

    invoke-direct/range {v22 .. v22}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v23, "r("

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    iget-object v0, v15, Ltas/internal/ipc/server/RemoteReceiver;->name:Ljava/lang/String;

    move-object/from16 v23, v0

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    const-string/jumbo v23, ") not found. "

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    move-object/from16 v0, p1

    iget v0, v0, Landroid/os/Message;->what:I

    move/from16 v23, v0

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v22

    invoke-virtual/range {v22 .. v22}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v22

    invoke-static/range {v21 .. v22}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 331
    invoke-virtual {v15}, Ltas/internal/ipc/server/RemoteReceiver;->recycle()V

    .line 332
    invoke-virtual {v9}, Ltas/internal/ipc/server/ServerManager;->dump()V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    goto/16 :goto_1

    .line 326
    .end local v12    # "rh":Ltas/internal/ipc/server/ServerManager$ReceiverHolder;
    .end local v15    # "rr":Ltas/internal/ipc/server/RemoteReceiver;
    :catchall_1
    move-exception v21

    monitor-exit v9

    throw v21

    .line 337
    .restart local v12    # "rh":Ltas/internal/ipc/server/ServerManager$ReceiverHolder;
    .restart local v15    # "rr":Ltas/internal/ipc/server/RemoteReceiver;
    :cond_3
    :try_start_3
    const-string/jumbo v21, "TasIPC<ServerManager>"

    new-instance v22, Ljava/lang/StringBuilder;

    invoke-direct/range {v22 .. v22}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v23, "r("

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    iget-object v0, v15, Ltas/internal/ipc/server/RemoteReceiver;->name:Ljava/lang/String;

    move-object/from16 v23, v0

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    const-string/jumbo v23, ") unregistered."

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    invoke-virtual/range {v22 .. v22}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v22

    invoke-static/range {v21 .. v22}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 340
    move-object/from16 v0, p0

    iget-object v0, v0, Ltas/internal/ipc/server/ServerManager$ClientHandler;->mReceivers:Ljava/util/List;

    move-object/from16 v21, v0

    move-object/from16 v0, v21

    invoke-interface {v0, v12}, Ljava/util/List;->remove(Ljava/lang/Object;)Z

    .line 341
    invoke-virtual {v15}, Ltas/internal/ipc/server/RemoteReceiver;->recycle()V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    goto/16 :goto_1

    .line 346
    .end local v12    # "rh":Ltas/internal/ipc/server/ServerManager$ReceiverHolder;
    .end local v15    # "rr":Ltas/internal/ipc/server/RemoteReceiver;
    :pswitch_2
    monitor-enter v9

    .line 347
    :try_start_4
    move-object/from16 v0, p1

    iget-object v15, v0, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v15, Ltas/internal/ipc/server/RemoteReceiver;

    .line 348
    .restart local v15    # "rr":Ltas/internal/ipc/server/RemoteReceiver;
    move-object/from16 v0, p0

    invoke-direct {v0, v15}, Ltas/internal/ipc/server/ServerManager$ClientHandler;->findReceiver(Ltas/internal/ipc/server/RemoteReceiver;)Ltas/internal/ipc/server/ServerManager$ReceiverHolder;

    move-result-object v12

    .line 349
    .restart local v12    # "rh":Ltas/internal/ipc/server/ServerManager$ReceiverHolder;
    if-nez v12, :cond_4

    .line 350
    const-string/jumbo v21, "TasIPC<ServerManager>"

    new-instance v22, Ljava/lang/StringBuilder;

    invoke-direct/range {v22 .. v22}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v23, "r("

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    iget-object v0, v15, Ltas/internal/ipc/server/RemoteReceiver;->name:Ljava/lang/String;

    move-object/from16 v23, v0

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    const-string/jumbo v23, ") not found. "

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    move-object/from16 v0, p1

    iget v0, v0, Landroid/os/Message;->what:I

    move/from16 v23, v0

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v22

    invoke-virtual/range {v22 .. v22}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v22

    invoke-static/range {v21 .. v22}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 351
    invoke-virtual {v15}, Ltas/internal/ipc/server/RemoteReceiver;->recycle()V

    .line 352
    invoke-virtual {v9}, Ltas/internal/ipc/server/ServerManager;->dump()V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_2

    goto/16 :goto_1

    .line 346
    .end local v12    # "rh":Ltas/internal/ipc/server/ServerManager$ReceiverHolder;
    .end local v15    # "rr":Ltas/internal/ipc/server/RemoteReceiver;
    :catchall_2
    move-exception v21

    monitor-exit v9

    throw v21

    .line 357
    .restart local v12    # "rh":Ltas/internal/ipc/server/ServerManager$ReceiverHolder;
    .restart local v15    # "rr":Ltas/internal/ipc/server/RemoteReceiver;
    :cond_4
    :try_start_5
    const-string/jumbo v21, "TasIPC<ServerManager>"

    new-instance v22, Ljava/lang/StringBuilder;

    invoke-direct/range {v22 .. v22}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v23, "r("

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    iget-object v0, v15, Ltas/internal/ipc/server/RemoteReceiver;->name:Ljava/lang/String;

    move-object/from16 v23, v0

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    const-string/jumbo v23, ") updated."

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    invoke-virtual/range {v22 .. v22}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v22

    invoke-static/range {v21 .. v22}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 360
    invoke-static {v12}, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->-get0(Ltas/internal/ipc/server/ServerManager$ReceiverHolder;)Ltas/internal/ipc/server/RemoteReceiver;

    move-result-object v21

    iget-object v0, v15, Ltas/internal/ipc/server/RemoteReceiver;->extra:Landroid/os/Bundle;

    move-object/from16 v22, v0

    move-object/from16 v0, v22

    move-object/from16 v1, v21

    iput-object v0, v1, Ltas/internal/ipc/server/RemoteReceiver;->extra:Landroid/os/Bundle;

    .line 362
    invoke-static {v9}, Ltas/internal/ipc/server/ServerManager;->-get0(Ltas/internal/ipc/server/ServerManager;)Landroid/util/ArrayMap;

    move-result-object v21

    invoke-virtual/range {v21 .. v21}, Landroid/util/ArrayMap;->values()Ljava/util/Collection;

    move-result-object v6

    .line 363
    .local v6, "clients":Ljava/util/Collection;, "Ljava/util/Collection<Ltas/internal/ipc/server/ServerManager$ClientHolder;>;"
    invoke-interface {v6}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v5

    .local v5, "client$iterator":Ljava/util/Iterator;
    :cond_5
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v21

    if-eqz v21, :cond_7

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ltas/internal/ipc/server/ServerManager$ClientHolder;

    .line 364
    .local v4, "client":Ltas/internal/ipc/server/ServerManager$ClientHolder;
    if-eqz v4, :cond_5

    .line 367
    invoke-static {v4}, Ltas/internal/ipc/server/ServerManager$ClientHolder;->-get0(Ltas/internal/ipc/server/ServerManager$ClientHolder;)Ltas/internal/ipc/server/ServerManager$ClientHandler;

    move-result-object v21

    move-object/from16 v0, v21

    iget-object v0, v0, Ltas/internal/ipc/server/ServerManager$ClientHandler;->mSenders:Ljava/util/List;

    move-object/from16 v21, v0

    invoke-interface/range {v21 .. v21}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v20

    .local v20, "sh$iterator":Ljava/util/Iterator;
    :cond_6
    :goto_2
    invoke-interface/range {v20 .. v20}, Ljava/util/Iterator;->hasNext()Z

    move-result v21

    if-eqz v21, :cond_5

    invoke-interface/range {v20 .. v20}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v19

    check-cast v19, Ltas/internal/ipc/server/ServerManager$SenderHolder;

    .line 368
    .local v19, "sh":Ltas/internal/ipc/server/ServerManager$SenderHolder;
    if-eqz v19, :cond_6

    invoke-static {v12}, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->-get0(Ltas/internal/ipc/server/ServerManager$ReceiverHolder;)Ltas/internal/ipc/server/RemoteReceiver;

    move-result-object v21

    move-object/from16 v0, v19

    move-object/from16 v1, v21

    invoke-static {v0, v1}, Ltas/internal/ipc/server/ServerManager$SenderHolder;->-wrap0(Ltas/internal/ipc/server/ServerManager$SenderHolder;Ltas/internal/ipc/server/RemoteReceiver;)Z

    move-result v21

    if-eqz v21, :cond_6

    .line 369
    invoke-static {v4}, Ltas/internal/ipc/server/ServerManager$ClientHolder;->-get0(Ltas/internal/ipc/server/ServerManager$ClientHolder;)Ltas/internal/ipc/server/ServerManager$ClientHandler;

    move-result-object v21

    .line 370
    invoke-static {v12}, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->-get0(Ltas/internal/ipc/server/ServerManager$ReceiverHolder;)Ltas/internal/ipc/server/RemoteReceiver;

    move-result-object v22

    const/16 v23, 0x14

    .line 369
    move-object/from16 v0, v21

    move/from16 v1, v23

    move-object/from16 v2, v22

    invoke-direct {v0, v1, v2}, Ltas/internal/ipc/server/ServerManager$ClientHandler;->schedule(ILtas/internal/ipc/server/RemoteReceiver;)V

    goto :goto_2

    .line 374
    .end local v4    # "client":Ltas/internal/ipc/server/ServerManager$ClientHolder;
    .end local v19    # "sh":Ltas/internal/ipc/server/ServerManager$SenderHolder;
    .end local v20    # "sh$iterator":Ljava/util/Iterator;
    :cond_7
    invoke-virtual {v15}, Ltas/internal/ipc/server/RemoteReceiver;->recycle()V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_2

    goto/16 :goto_1

    .line 379
    .end local v5    # "client$iterator":Ljava/util/Iterator;
    .end local v6    # "clients":Ljava/util/Collection;, "Ljava/util/Collection<Ltas/internal/ipc/server/ServerManager$ClientHolder;>;"
    .end local v12    # "rh":Ltas/internal/ipc/server/ServerManager$ReceiverHolder;
    .end local v15    # "rr":Ltas/internal/ipc/server/RemoteReceiver;
    :pswitch_3
    monitor-enter v9

    .line 380
    :try_start_6
    move-object/from16 v0, p1

    iget-object v0, v0, Landroid/os/Message;->obj:Ljava/lang/Object;

    move-object/from16 v16, v0

    check-cast v16, Ltas/internal/ipc/server/RemoteSender;

    .line 381
    .local v16, "rs":Ltas/internal/ipc/server/RemoteSender;
    move-object/from16 v0, p0

    move-object/from16 v1, v16

    invoke-direct {v0, v1}, Ltas/internal/ipc/server/ServerManager$ClientHandler;->findSender(Ltas/internal/ipc/server/RemoteSender;)Ltas/internal/ipc/server/ServerManager$SenderHolder;

    move-result-object v19

    .line 382
    .restart local v19    # "sh":Ltas/internal/ipc/server/ServerManager$SenderHolder;
    if-eqz v19, :cond_8

    .line 383
    const-string/jumbo v21, "TasIPC<ServerManager>"

    new-instance v22, Ljava/lang/StringBuilder;

    invoke-direct/range {v22 .. v22}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v23, "s("

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    move-object/from16 v0, v16

    iget-object v0, v0, Ltas/internal/ipc/server/RemoteSender;->name:Ljava/lang/String;

    move-object/from16 v23, v0

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    const-string/jumbo v23, ") already registered."

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    invoke-virtual/range {v22 .. v22}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v22

    invoke-static/range {v21 .. v22}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 384
    invoke-virtual/range {v16 .. v16}, Ltas/internal/ipc/server/RemoteSender;->recycle()V

    .line 385
    invoke-virtual {v9}, Ltas/internal/ipc/server/ServerManager;->dump()V
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_3

    goto/16 :goto_1

    .line 379
    .end local v16    # "rs":Ltas/internal/ipc/server/RemoteSender;
    .end local v19    # "sh":Ltas/internal/ipc/server/ServerManager$SenderHolder;
    :catchall_3
    move-exception v21

    monitor-exit v9

    throw v21

    .line 390
    .restart local v16    # "rs":Ltas/internal/ipc/server/RemoteSender;
    .restart local v19    # "sh":Ltas/internal/ipc/server/ServerManager$SenderHolder;
    :cond_8
    :try_start_7
    const-string/jumbo v21, "TasIPC<ServerManager>"

    new-instance v22, Ljava/lang/StringBuilder;

    invoke-direct/range {v22 .. v22}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v23, "s("

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    move-object/from16 v0, v16

    iget-object v0, v0, Ltas/internal/ipc/server/RemoteSender;->name:Ljava/lang/String;

    move-object/from16 v23, v0

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    const-string/jumbo v23, ") registered."

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    invoke-virtual/range {v22 .. v22}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v22

    invoke-static/range {v21 .. v22}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 393
    new-instance v19, Ltas/internal/ipc/server/ServerManager$SenderHolder;

    .end local v19    # "sh":Ltas/internal/ipc/server/ServerManager$SenderHolder;
    new-instance v21, Ltas/internal/ipc/server/RemoteSender;

    move-object/from16 v0, v21

    move-object/from16 v1, v16

    invoke-direct {v0, v1}, Ltas/internal/ipc/server/RemoteSender;-><init>(Ltas/internal/ipc/server/RemoteSender;)V

    const/16 v22, 0x0

    move-object/from16 v0, v19

    move-object/from16 v1, p0

    move-object/from16 v2, v21

    move-object/from16 v3, v22

    invoke-direct {v0, v1, v2, v3}, Ltas/internal/ipc/server/ServerManager$SenderHolder;-><init>(Ltas/internal/ipc/server/ServerManager$ClientHandler;Ltas/internal/ipc/server/RemoteSender;Ltas/internal/ipc/server/ServerManager$SenderHolder;)V

    .line 394
    .restart local v19    # "sh":Ltas/internal/ipc/server/ServerManager$SenderHolder;
    move-object/from16 v0, p0

    iget-object v0, v0, Ltas/internal/ipc/server/ServerManager$ClientHandler;->mSenders:Ljava/util/List;

    move-object/from16 v21, v0

    move-object/from16 v0, v21

    move-object/from16 v1, v19

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 395
    invoke-virtual/range {v16 .. v16}, Ltas/internal/ipc/server/RemoteSender;->recycle()V
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_3

    goto/16 :goto_1

    .line 400
    .end local v16    # "rs":Ltas/internal/ipc/server/RemoteSender;
    .end local v19    # "sh":Ltas/internal/ipc/server/ServerManager$SenderHolder;
    :pswitch_4
    monitor-enter v9

    .line 401
    :try_start_8
    move-object/from16 v0, p1

    iget-object v0, v0, Landroid/os/Message;->obj:Ljava/lang/Object;

    move-object/from16 v16, v0

    check-cast v16, Ltas/internal/ipc/server/RemoteSender;

    .line 402
    .restart local v16    # "rs":Ltas/internal/ipc/server/RemoteSender;
    move-object/from16 v0, p0

    move-object/from16 v1, v16

    invoke-direct {v0, v1}, Ltas/internal/ipc/server/ServerManager$ClientHandler;->findSender(Ltas/internal/ipc/server/RemoteSender;)Ltas/internal/ipc/server/ServerManager$SenderHolder;

    move-result-object v19

    .line 403
    .restart local v19    # "sh":Ltas/internal/ipc/server/ServerManager$SenderHolder;
    if-nez v19, :cond_9

    .line 404
    const-string/jumbo v21, "TasIPC<ServerManager>"

    new-instance v22, Ljava/lang/StringBuilder;

    invoke-direct/range {v22 .. v22}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v23, "s("

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    move-object/from16 v0, v16

    iget-object v0, v0, Ltas/internal/ipc/server/RemoteSender;->name:Ljava/lang/String;

    move-object/from16 v23, v0

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    const-string/jumbo v23, ") not found. "

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    move-object/from16 v0, p1

    iget v0, v0, Landroid/os/Message;->what:I

    move/from16 v23, v0

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v22

    invoke-virtual/range {v22 .. v22}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v22

    invoke-static/range {v21 .. v22}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 405
    invoke-virtual/range {v16 .. v16}, Ltas/internal/ipc/server/RemoteSender;->recycle()V

    .line 406
    invoke-virtual {v9}, Ltas/internal/ipc/server/ServerManager;->dump()V
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_4

    goto/16 :goto_1

    .line 400
    .end local v16    # "rs":Ltas/internal/ipc/server/RemoteSender;
    .end local v19    # "sh":Ltas/internal/ipc/server/ServerManager$SenderHolder;
    :catchall_4
    move-exception v21

    monitor-exit v9

    throw v21

    .line 411
    .restart local v16    # "rs":Ltas/internal/ipc/server/RemoteSender;
    .restart local v19    # "sh":Ltas/internal/ipc/server/ServerManager$SenderHolder;
    :cond_9
    :try_start_9
    const-string/jumbo v21, "TasIPC<ServerManager>"

    new-instance v22, Ljava/lang/StringBuilder;

    invoke-direct/range {v22 .. v22}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v23, "s("

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    move-object/from16 v0, v16

    iget-object v0, v0, Ltas/internal/ipc/server/RemoteSender;->name:Ljava/lang/String;

    move-object/from16 v23, v0

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    const-string/jumbo v23, ") unregistered."

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    invoke-virtual/range {v22 .. v22}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v22

    invoke-static/range {v21 .. v22}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 414
    move-object/from16 v0, p0

    iget-object v0, v0, Ltas/internal/ipc/server/ServerManager$ClientHandler;->mSenders:Ljava/util/List;

    move-object/from16 v21, v0

    move-object/from16 v0, v21

    move-object/from16 v1, v19

    invoke-interface {v0, v1}, Ljava/util/List;->remove(Ljava/lang/Object;)Z

    .line 415
    invoke-virtual/range {v16 .. v16}, Ltas/internal/ipc/server/RemoteSender;->recycle()V
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_4

    goto/16 :goto_1

    .line 420
    .end local v16    # "rs":Ltas/internal/ipc/server/RemoteSender;
    .end local v19    # "sh":Ltas/internal/ipc/server/ServerManager$SenderHolder;
    :pswitch_5
    monitor-enter v9

    .line 421
    :try_start_a
    move-object/from16 v0, p1

    iget-object v0, v0, Landroid/os/Message;->obj:Ljava/lang/Object;

    move-object/from16 v16, v0

    check-cast v16, Ltas/internal/ipc/server/RemoteSender;

    .line 422
    .restart local v16    # "rs":Ltas/internal/ipc/server/RemoteSender;
    move-object/from16 v0, p0

    move-object/from16 v1, v16

    invoke-direct {v0, v1}, Ltas/internal/ipc/server/ServerManager$ClientHandler;->findSender(Ltas/internal/ipc/server/RemoteSender;)Ltas/internal/ipc/server/ServerManager$SenderHolder;

    move-result-object v19

    .line 423
    .restart local v19    # "sh":Ltas/internal/ipc/server/ServerManager$SenderHolder;
    if-nez v19, :cond_a

    .line 424
    const-string/jumbo v21, "TasIPC<ServerManager>"

    new-instance v22, Ljava/lang/StringBuilder;

    invoke-direct/range {v22 .. v22}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v23, "s("

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    move-object/from16 v0, v16

    iget-object v0, v0, Ltas/internal/ipc/server/RemoteSender;->name:Ljava/lang/String;

    move-object/from16 v23, v0

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    const-string/jumbo v23, ") not found. "

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    move-object/from16 v0, p1

    iget v0, v0, Landroid/os/Message;->what:I

    move/from16 v23, v0

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v22

    invoke-virtual/range {v22 .. v22}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v22

    invoke-static/range {v21 .. v22}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 425
    invoke-virtual/range {v16 .. v16}, Ltas/internal/ipc/server/RemoteSender;->recycle()V

    .line 426
    invoke-virtual {v9}, Ltas/internal/ipc/server/ServerManager;->dump()V
    :try_end_a
    .catchall {:try_start_a .. :try_end_a} :catchall_5

    goto/16 :goto_1

    .line 420
    .end local v16    # "rs":Ltas/internal/ipc/server/RemoteSender;
    .end local v19    # "sh":Ltas/internal/ipc/server/ServerManager$SenderHolder;
    :catchall_5
    move-exception v21

    monitor-exit v9

    throw v21

    .line 431
    .restart local v16    # "rs":Ltas/internal/ipc/server/RemoteSender;
    .restart local v19    # "sh":Ltas/internal/ipc/server/ServerManager$SenderHolder;
    :cond_a
    :try_start_b
    const-string/jumbo v21, "TasIPC<ServerManager>"

    new-instance v22, Ljava/lang/StringBuilder;

    invoke-direct/range {v22 .. v22}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v23, "s("

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    move-object/from16 v0, v16

    iget-object v0, v0, Ltas/internal/ipc/server/RemoteSender;->name:Ljava/lang/String;

    move-object/from16 v23, v0

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    const-string/jumbo v23, ") updated."

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    invoke-virtual/range {v22 .. v22}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v22

    invoke-static/range {v21 .. v22}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 434
    invoke-static/range {v19 .. v19}, Ltas/internal/ipc/server/ServerManager$SenderHolder;->-get1(Ltas/internal/ipc/server/ServerManager$SenderHolder;)Ltas/internal/ipc/server/RemoteSender;

    move-result-object v21

    move-object/from16 v0, v16

    iget-object v0, v0, Ltas/internal/ipc/server/RemoteSender;->extra:Landroid/os/Bundle;

    move-object/from16 v22, v0

    move-object/from16 v0, v22

    move-object/from16 v1, v21

    iput-object v0, v1, Ltas/internal/ipc/server/RemoteSender;->extra:Landroid/os/Bundle;

    .line 436
    invoke-static {v9}, Ltas/internal/ipc/server/ServerManager;->-get0(Ltas/internal/ipc/server/ServerManager;)Landroid/util/ArrayMap;

    move-result-object v21

    invoke-virtual/range {v21 .. v21}, Landroid/util/ArrayMap;->values()Ljava/util/Collection;

    move-result-object v6

    .line 437
    .restart local v6    # "clients":Ljava/util/Collection;, "Ljava/util/Collection<Ltas/internal/ipc/server/ServerManager$ClientHolder;>;"
    invoke-interface {v6}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v5

    .restart local v5    # "client$iterator":Ljava/util/Iterator;
    :cond_b
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v21

    if-eqz v21, :cond_d

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ltas/internal/ipc/server/ServerManager$ClientHolder;

    .line 438
    .restart local v4    # "client":Ltas/internal/ipc/server/ServerManager$ClientHolder;
    if-eqz v4, :cond_b

    .line 441
    invoke-static {v4}, Ltas/internal/ipc/server/ServerManager$ClientHolder;->-get0(Ltas/internal/ipc/server/ServerManager$ClientHolder;)Ltas/internal/ipc/server/ServerManager$ClientHandler;

    move-result-object v21

    move-object/from16 v0, v21

    iget-object v0, v0, Ltas/internal/ipc/server/ServerManager$ClientHandler;->mReceivers:Ljava/util/List;

    move-object/from16 v21, v0

    invoke-interface/range {v21 .. v21}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v13

    .local v13, "rh$iterator":Ljava/util/Iterator;
    :cond_c
    :goto_3
    invoke-interface {v13}, Ljava/util/Iterator;->hasNext()Z

    move-result v21

    if-eqz v21, :cond_b

    invoke-interface {v13}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;

    .line 442
    .restart local v12    # "rh":Ltas/internal/ipc/server/ServerManager$ReceiverHolder;
    if-eqz v12, :cond_c

    invoke-static/range {v19 .. v19}, Ltas/internal/ipc/server/ServerManager$SenderHolder;->-get1(Ltas/internal/ipc/server/ServerManager$SenderHolder;)Ltas/internal/ipc/server/RemoteSender;

    move-result-object v21

    move-object/from16 v0, v21

    invoke-static {v12, v0}, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->-wrap0(Ltas/internal/ipc/server/ServerManager$ReceiverHolder;Ltas/internal/ipc/server/RemoteSender;)Z

    move-result v21

    if-eqz v21, :cond_c

    .line 443
    invoke-static {v4}, Ltas/internal/ipc/server/ServerManager$ClientHolder;->-get0(Ltas/internal/ipc/server/ServerManager$ClientHolder;)Ltas/internal/ipc/server/ServerManager$ClientHandler;

    move-result-object v21

    .line 444
    invoke-static/range {v19 .. v19}, Ltas/internal/ipc/server/ServerManager$SenderHolder;->-get1(Ltas/internal/ipc/server/ServerManager$SenderHolder;)Ltas/internal/ipc/server/RemoteSender;

    move-result-object v22

    const/16 v23, 0x15

    .line 443
    move-object/from16 v0, v21

    move/from16 v1, v23

    move-object/from16 v2, v22

    invoke-direct {v0, v1, v2}, Ltas/internal/ipc/server/ServerManager$ClientHandler;->schedule(ILtas/internal/ipc/server/RemoteSender;)V

    goto :goto_3

    .line 448
    .end local v4    # "client":Ltas/internal/ipc/server/ServerManager$ClientHolder;
    .end local v12    # "rh":Ltas/internal/ipc/server/ServerManager$ReceiverHolder;
    .end local v13    # "rh$iterator":Ljava/util/Iterator;
    :cond_d
    invoke-virtual/range {v16 .. v16}, Ltas/internal/ipc/server/RemoteSender;->recycle()V
    :try_end_b
    .catchall {:try_start_b .. :try_end_b} :catchall_5

    goto/16 :goto_1

    .line 453
    .end local v5    # "client$iterator":Ljava/util/Iterator;
    .end local v6    # "clients":Ljava/util/Collection;, "Ljava/util/Collection<Ltas/internal/ipc/server/ServerManager$ClientHolder;>;"
    .end local v16    # "rs":Ltas/internal/ipc/server/RemoteSender;
    .end local v19    # "sh":Ltas/internal/ipc/server/ServerManager$SenderHolder;
    :pswitch_6
    move-object/from16 v0, p1

    iget-object v0, v0, Landroid/os/Message;->obj:Ljava/lang/Object;

    move-object/from16 v16, v0

    check-cast v16, Ltas/internal/ipc/server/RemoteSender;

    .line 454
    .restart local v16    # "rs":Ltas/internal/ipc/server/RemoteSender;
    move-object/from16 v0, p0

    move-object/from16 v1, v16

    invoke-direct {v0, v1}, Ltas/internal/ipc/server/ServerManager$ClientHandler;->findSender(Ltas/internal/ipc/server/RemoteSender;)Ltas/internal/ipc/server/ServerManager$SenderHolder;

    move-result-object v19

    .line 455
    .restart local v19    # "sh":Ltas/internal/ipc/server/ServerManager$SenderHolder;
    if-nez v19, :cond_e

    .line 456
    const-string/jumbo v21, "TasIPC<ServerManager>"

    new-instance v22, Ljava/lang/StringBuilder;

    invoke-direct/range {v22 .. v22}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v23, "s("

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    move-object/from16 v0, v16

    iget-object v0, v0, Ltas/internal/ipc/server/RemoteSender;->name:Ljava/lang/String;

    move-object/from16 v23, v0

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    const-string/jumbo v23, ") not found. "

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    move-object/from16 v0, p1

    iget v0, v0, Landroid/os/Message;->what:I

    move/from16 v23, v0

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v22

    invoke-virtual/range {v22 .. v22}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v22

    invoke-static/range {v21 .. v22}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 457
    invoke-virtual/range {v16 .. v16}, Ltas/internal/ipc/server/RemoteSender;->recycle()V

    .line 458
    invoke-virtual {v9}, Ltas/internal/ipc/server/ServerManager;->dump()V

    goto/16 :goto_0

    .line 462
    :cond_e
    move-object/from16 v0, v16

    iget-object v0, v0, Ltas/internal/ipc/server/RemoteSender;->target:Ljava/lang/String;

    move-object/from16 v21, v0

    move-object/from16 v0, v19

    move-object/from16 v1, v21

    invoke-static {v0, v1}, Ltas/internal/ipc/server/ServerManager$SenderHolder;->-wrap1(Ltas/internal/ipc/server/ServerManager$SenderHolder;Ljava/lang/String;)Z

    move-result v21

    if-eqz v21, :cond_f

    .line 463
    const-string/jumbo v21, "TasIPC<ServerManager>"

    new-instance v22, Ljava/lang/StringBuilder;

    invoke-direct/range {v22 .. v22}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v23, "s("

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    move-object/from16 v0, v16

    iget-object v0, v0, Ltas/internal/ipc/server/RemoteSender;->name:Ljava/lang/String;

    move-object/from16 v23, v0

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    const-string/jumbo v23, ") already watched "

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    .line 464
    move-object/from16 v0, v16

    iget-object v0, v0, Ltas/internal/ipc/server/RemoteSender;->target:Ljava/lang/String;

    move-object/from16 v23, v0

    .line 463
    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    invoke-virtual/range {v22 .. v22}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v22

    invoke-static/range {v21 .. v22}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 465
    invoke-virtual/range {v16 .. v16}, Ltas/internal/ipc/server/RemoteSender;->recycle()V

    .line 466
    invoke-virtual {v9}, Ltas/internal/ipc/server/ServerManager;->dump()V

    goto/16 :goto_0

    .line 471
    :cond_f
    const-string/jumbo v21, "TasIPC<ServerManager>"

    new-instance v22, Ljava/lang/StringBuilder;

    invoke-direct/range {v22 .. v22}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v23, "s("

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    move-object/from16 v0, v16

    iget-object v0, v0, Ltas/internal/ipc/server/RemoteSender;->name:Ljava/lang/String;

    move-object/from16 v23, v0

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    const-string/jumbo v23, ") watches "

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    move-object/from16 v0, v16

    iget-object v0, v0, Ltas/internal/ipc/server/RemoteSender;->target:Ljava/lang/String;

    move-object/from16 v23, v0

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    invoke-virtual/range {v22 .. v22}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v22

    invoke-static/range {v21 .. v22}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 474
    move-object/from16 v0, v16

    iget-object v0, v0, Ltas/internal/ipc/server/RemoteSender;->target:Ljava/lang/String;

    move-object/from16 v21, v0

    move-object/from16 v0, v19

    move-object/from16 v1, v21

    invoke-static {v0, v1}, Ltas/internal/ipc/server/ServerManager$SenderHolder;->-wrap6(Ltas/internal/ipc/server/ServerManager$SenderHolder;Ljava/lang/String;)V

    .line 475
    monitor-enter v9

    .line 476
    :try_start_c
    invoke-static {v9}, Ltas/internal/ipc/server/ServerManager;->-get0(Ltas/internal/ipc/server/ServerManager;)Landroid/util/ArrayMap;

    move-result-object v21

    invoke-virtual/range {v21 .. v21}, Landroid/util/ArrayMap;->values()Ljava/util/Collection;

    move-result-object v6

    .line 477
    .restart local v6    # "clients":Ljava/util/Collection;, "Ljava/util/Collection<Ltas/internal/ipc/server/ServerManager$ClientHolder;>;"
    const/4 v12, 0x0

    .line 478
    .local v12, "rh":Ltas/internal/ipc/server/ServerManager$ReceiverHolder;
    invoke-interface {v6}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v5

    .end local v12    # "rh":Ltas/internal/ipc/server/ServerManager$ReceiverHolder;
    .restart local v5    # "client$iterator":Ljava/util/Iterator;
    :cond_10
    :goto_4
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v21

    if-eqz v21, :cond_14

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ltas/internal/ipc/server/ServerManager$ClientHolder;

    .line 479
    .restart local v4    # "client":Ltas/internal/ipc/server/ServerManager$ClientHolder;
    if-eqz v4, :cond_10

    .line 482
    invoke-static {v4}, Ltas/internal/ipc/server/ServerManager$ClientHolder;->-get0(Ltas/internal/ipc/server/ServerManager$ClientHolder;)Ltas/internal/ipc/server/ServerManager$ClientHandler;

    move-result-object v21

    move-object/from16 v0, v16

    iget-object v0, v0, Ltas/internal/ipc/server/RemoteSender;->target:Ljava/lang/String;

    move-object/from16 v22, v0

    invoke-direct/range {v21 .. v22}, Ltas/internal/ipc/server/ServerManager$ClientHandler;->findReceiver(Ljava/lang/String;)Ltas/internal/ipc/server/ServerManager$ReceiverHolder;

    move-result-object v12

    .line 483
    .local v12, "rh":Ltas/internal/ipc/server/ServerManager$ReceiverHolder;
    if-eqz v12, :cond_10

    .line 484
    move-object/from16 v0, v16

    iget-object v0, v0, Ltas/internal/ipc/server/RemoteSender;->name:Ljava/lang/String;

    move-object/from16 v21, v0

    move-object/from16 v0, v21

    invoke-static {v12, v0}, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->-wrap1(Ltas/internal/ipc/server/ServerManager$ReceiverHolder;Ljava/lang/String;)Z

    move-result v21

    if-nez v21, :cond_11

    .line 485
    invoke-static {v12}, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->-get2(Ltas/internal/ipc/server/ServerManager$ReceiverHolder;)Z

    move-result v21

    if-eqz v21, :cond_10

    .line 487
    :cond_11
    const/4 v8, 0x0

    .line 489
    .local v8, "holder":Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;
    invoke-static {v12}, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->-get0(Ltas/internal/ipc/server/ServerManager$ReceiverHolder;)Ltas/internal/ipc/server/RemoteReceiver;

    move-result-object v21

    move-object/from16 v0, v19

    move-object/from16 v1, v21

    invoke-static {v0, v1}, Ltas/internal/ipc/server/ServerManager$SenderHolder;->-wrap0(Ltas/internal/ipc/server/ServerManager$SenderHolder;Ltas/internal/ipc/server/RemoteReceiver;)Z

    move-result v21

    if-nez v21, :cond_12

    .line 490
    invoke-static {v12}, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->-get0(Ltas/internal/ipc/server/ServerManager$ReceiverHolder;)Ltas/internal/ipc/server/RemoteReceiver;

    move-result-object v21

    move-object/from16 v0, v19

    move-object/from16 v1, v21

    invoke-static {v0, v1}, Ltas/internal/ipc/server/ServerManager$SenderHolder;->-wrap4(Ltas/internal/ipc/server/ServerManager$SenderHolder;Ltas/internal/ipc/server/RemoteReceiver;)V

    .line 492
    new-instance v8, Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;

    .end local v8    # "holder":Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;
    const/16 v21, 0x0

    move-object/from16 v0, v19

    move-object/from16 v1, v21

    invoke-direct {v8, v0, v12, v1}, Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;-><init>(Ltas/internal/ipc/server/ServerManager$SenderHolder;Ltas/internal/ipc/server/ServerManager$ReceiverHolder;Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;)V

    .line 494
    .local v8, "holder":Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;
    const/16 v21, 0x10

    move-object/from16 v0, p0

    move/from16 v1, v21

    invoke-direct {v0, v1, v8}, Ltas/internal/ipc/server/ServerManager$ClientHandler;->schedule(ILtas/internal/ipc/server/ServerManager$ClientHandler$Holder;)V

    .line 497
    .end local v8    # "holder":Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;
    :cond_12
    invoke-static/range {v19 .. v19}, Ltas/internal/ipc/server/ServerManager$SenderHolder;->-get1(Ltas/internal/ipc/server/ServerManager$SenderHolder;)Ltas/internal/ipc/server/RemoteSender;

    move-result-object v21

    move-object/from16 v0, v21

    invoke-static {v12, v0}, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->-wrap0(Ltas/internal/ipc/server/ServerManager$ReceiverHolder;Ltas/internal/ipc/server/RemoteSender;)Z

    move-result v21

    if-nez v21, :cond_10

    .line 498
    invoke-static/range {v19 .. v19}, Ltas/internal/ipc/server/ServerManager$SenderHolder;->-get1(Ltas/internal/ipc/server/ServerManager$SenderHolder;)Ltas/internal/ipc/server/RemoteSender;

    move-result-object v21

    move-object/from16 v0, v21

    invoke-static {v12, v0}, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->-wrap4(Ltas/internal/ipc/server/ServerManager$ReceiverHolder;Ltas/internal/ipc/server/RemoteSender;)V

    .line 499
    if-nez v8, :cond_13

    .line 500
    new-instance v8, Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;

    const/16 v21, 0x0

    move-object/from16 v0, v19

    move-object/from16 v1, v21

    invoke-direct {v8, v0, v12, v1}, Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;-><init>(Ltas/internal/ipc/server/ServerManager$SenderHolder;Ltas/internal/ipc/server/ServerManager$ReceiverHolder;Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;)V

    .line 502
    :cond_13
    invoke-static {v4}, Ltas/internal/ipc/server/ServerManager$ClientHolder;->-get0(Ltas/internal/ipc/server/ServerManager$ClientHolder;)Ltas/internal/ipc/server/ServerManager$ClientHandler;

    move-result-object v21

    .line 503
    const/16 v22, 0x12

    .line 502
    move-object/from16 v0, v21

    move/from16 v1, v22

    invoke-direct {v0, v1, v8}, Ltas/internal/ipc/server/ServerManager$ClientHandler;->schedule(ILtas/internal/ipc/server/ServerManager$ClientHandler$Holder;)V
    :try_end_c
    .catchall {:try_start_c .. :try_end_c} :catchall_6

    goto/16 :goto_4

    .line 475
    .end local v4    # "client":Ltas/internal/ipc/server/ServerManager$ClientHolder;
    .end local v5    # "client$iterator":Ljava/util/Iterator;
    .end local v6    # "clients":Ljava/util/Collection;, "Ljava/util/Collection<Ltas/internal/ipc/server/ServerManager$ClientHolder;>;"
    .end local v12    # "rh":Ltas/internal/ipc/server/ServerManager$ReceiverHolder;
    :catchall_6
    move-exception v21

    monitor-exit v9

    throw v21

    .restart local v5    # "client$iterator":Ljava/util/Iterator;
    .restart local v6    # "clients":Ljava/util/Collection;, "Ljava/util/Collection<Ltas/internal/ipc/server/ServerManager$ClientHolder;>;"
    :cond_14
    monitor-exit v9

    .line 508
    invoke-virtual/range {v16 .. v16}, Ltas/internal/ipc/server/RemoteSender;->recycle()V

    goto/16 :goto_0

    .line 512
    .end local v5    # "client$iterator":Ljava/util/Iterator;
    .end local v6    # "clients":Ljava/util/Collection;, "Ljava/util/Collection<Ltas/internal/ipc/server/ServerManager$ClientHolder;>;"
    .end local v16    # "rs":Ltas/internal/ipc/server/RemoteSender;
    .end local v19    # "sh":Ltas/internal/ipc/server/ServerManager$SenderHolder;
    :pswitch_7
    move-object/from16 v0, p1

    iget-object v0, v0, Landroid/os/Message;->obj:Ljava/lang/Object;

    move-object/from16 v16, v0

    check-cast v16, Ltas/internal/ipc/server/RemoteSender;

    .line 513
    .restart local v16    # "rs":Ltas/internal/ipc/server/RemoteSender;
    move-object/from16 v0, p0

    move-object/from16 v1, v16

    invoke-direct {v0, v1}, Ltas/internal/ipc/server/ServerManager$ClientHandler;->findSender(Ltas/internal/ipc/server/RemoteSender;)Ltas/internal/ipc/server/ServerManager$SenderHolder;

    move-result-object v19

    .line 514
    .restart local v19    # "sh":Ltas/internal/ipc/server/ServerManager$SenderHolder;
    if-nez v19, :cond_15

    .line 515
    const-string/jumbo v21, "TasIPC<ServerManager>"

    new-instance v22, Ljava/lang/StringBuilder;

    invoke-direct/range {v22 .. v22}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v23, "s("

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    move-object/from16 v0, v16

    iget-object v0, v0, Ltas/internal/ipc/server/RemoteSender;->name:Ljava/lang/String;

    move-object/from16 v23, v0

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    const-string/jumbo v23, ") not found. "

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    move-object/from16 v0, p1

    iget v0, v0, Landroid/os/Message;->what:I

    move/from16 v23, v0

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v22

    invoke-virtual/range {v22 .. v22}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v22

    invoke-static/range {v21 .. v22}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 516
    invoke-virtual/range {v16 .. v16}, Ltas/internal/ipc/server/RemoteSender;->recycle()V

    .line 517
    invoke-virtual {v9}, Ltas/internal/ipc/server/ServerManager;->dump()V

    goto/16 :goto_0

    .line 521
    :cond_15
    move-object/from16 v0, v16

    iget-object v0, v0, Ltas/internal/ipc/server/RemoteSender;->target:Ljava/lang/String;

    move-object/from16 v21, v0

    move-object/from16 v0, v19

    move-object/from16 v1, v21

    invoke-static {v0, v1}, Ltas/internal/ipc/server/ServerManager$SenderHolder;->-wrap1(Ltas/internal/ipc/server/ServerManager$SenderHolder;Ljava/lang/String;)Z

    move-result v21

    if-nez v21, :cond_16

    .line 522
    const-string/jumbo v21, "TasIPC<ServerManager>"

    new-instance v22, Ljava/lang/StringBuilder;

    invoke-direct/range {v22 .. v22}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v23, "s("

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    move-object/from16 v0, v16

    iget-object v0, v0, Ltas/internal/ipc/server/RemoteSender;->name:Ljava/lang/String;

    move-object/from16 v23, v0

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    const-string/jumbo v23, ") not watch "

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    move-object/from16 v0, v16

    iget-object v0, v0, Ltas/internal/ipc/server/RemoteSender;->target:Ljava/lang/String;

    move-object/from16 v23, v0

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    invoke-virtual/range {v22 .. v22}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v22

    invoke-static/range {v21 .. v22}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 523
    invoke-virtual/range {v16 .. v16}, Ltas/internal/ipc/server/RemoteSender;->recycle()V

    .line 524
    invoke-virtual {v9}, Ltas/internal/ipc/server/ServerManager;->dump()V

    goto/16 :goto_0

    .line 529
    :cond_16
    const-string/jumbo v21, "TasIPC<ServerManager>"

    new-instance v22, Ljava/lang/StringBuilder;

    invoke-direct/range {v22 .. v22}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v23, "s("

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    move-object/from16 v0, v16

    iget-object v0, v0, Ltas/internal/ipc/server/RemoteSender;->name:Ljava/lang/String;

    move-object/from16 v23, v0

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    const-string/jumbo v23, ") unwatches "

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    move-object/from16 v0, v16

    iget-object v0, v0, Ltas/internal/ipc/server/RemoteSender;->target:Ljava/lang/String;

    move-object/from16 v23, v0

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    invoke-virtual/range {v22 .. v22}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v22

    invoke-static/range {v21 .. v22}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 532
    move-object/from16 v0, v16

    iget-object v0, v0, Ltas/internal/ipc/server/RemoteSender;->target:Ljava/lang/String;

    move-object/from16 v21, v0

    move-object/from16 v0, v19

    move-object/from16 v1, v21

    invoke-static {v0, v1}, Ltas/internal/ipc/server/ServerManager$SenderHolder;->-wrap3(Ltas/internal/ipc/server/ServerManager$SenderHolder;Ljava/lang/String;)Z

    .line 533
    monitor-enter v9

    .line 534
    :try_start_d
    invoke-static {v9}, Ltas/internal/ipc/server/ServerManager;->-get0(Ltas/internal/ipc/server/ServerManager;)Landroid/util/ArrayMap;

    move-result-object v21

    invoke-virtual/range {v21 .. v21}, Landroid/util/ArrayMap;->values()Ljava/util/Collection;

    move-result-object v6

    .line 535
    .restart local v6    # "clients":Ljava/util/Collection;, "Ljava/util/Collection<Ltas/internal/ipc/server/ServerManager$ClientHolder;>;"
    const/4 v12, 0x0

    .line 536
    .local v12, "rh":Ltas/internal/ipc/server/ServerManager$ReceiverHolder;
    invoke-interface {v6}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v5

    .end local v12    # "rh":Ltas/internal/ipc/server/ServerManager$ReceiverHolder;
    .restart local v5    # "client$iterator":Ljava/util/Iterator;
    :cond_17
    :goto_5
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v21

    if-eqz v21, :cond_1a

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ltas/internal/ipc/server/ServerManager$ClientHolder;

    .line 537
    .restart local v4    # "client":Ltas/internal/ipc/server/ServerManager$ClientHolder;
    if-eqz v4, :cond_17

    .line 540
    invoke-static {v4}, Ltas/internal/ipc/server/ServerManager$ClientHolder;->-get0(Ltas/internal/ipc/server/ServerManager$ClientHolder;)Ltas/internal/ipc/server/ServerManager$ClientHandler;

    move-result-object v21

    move-object/from16 v0, v16

    iget-object v0, v0, Ltas/internal/ipc/server/RemoteSender;->target:Ljava/lang/String;

    move-object/from16 v22, v0

    invoke-direct/range {v21 .. v22}, Ltas/internal/ipc/server/ServerManager$ClientHandler;->findReceiver(Ljava/lang/String;)Ltas/internal/ipc/server/ServerManager$ReceiverHolder;

    move-result-object v12

    .line 541
    .local v12, "rh":Ltas/internal/ipc/server/ServerManager$ReceiverHolder;
    if-eqz v12, :cond_17

    .line 543
    const/4 v8, 0x0

    .line 545
    .local v8, "holder":Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;
    invoke-static {v12}, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->-get0(Ltas/internal/ipc/server/ServerManager$ReceiverHolder;)Ltas/internal/ipc/server/RemoteReceiver;

    move-result-object v21

    move-object/from16 v0, v19

    move-object/from16 v1, v21

    invoke-static {v0, v1}, Ltas/internal/ipc/server/ServerManager$SenderHolder;->-wrap0(Ltas/internal/ipc/server/ServerManager$SenderHolder;Ltas/internal/ipc/server/RemoteReceiver;)Z

    move-result v21

    if-eqz v21, :cond_18

    .line 546
    invoke-static {v12}, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->-get0(Ltas/internal/ipc/server/ServerManager$ReceiverHolder;)Ltas/internal/ipc/server/RemoteReceiver;

    move-result-object v21

    move-object/from16 v0, v19

    move-object/from16 v1, v21

    invoke-static {v0, v1}, Ltas/internal/ipc/server/ServerManager$SenderHolder;->-wrap2(Ltas/internal/ipc/server/ServerManager$SenderHolder;Ltas/internal/ipc/server/RemoteReceiver;)Z

    .line 548
    new-instance v8, Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;

    .end local v8    # "holder":Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;
    const/16 v21, 0x0

    move-object/from16 v0, v19

    move-object/from16 v1, v21

    invoke-direct {v8, v0, v12, v1}, Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;-><init>(Ltas/internal/ipc/server/ServerManager$SenderHolder;Ltas/internal/ipc/server/ServerManager$ReceiverHolder;Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;)V

    .line 550
    .local v8, "holder":Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;
    const/16 v21, 0x11

    move-object/from16 v0, p0

    move/from16 v1, v21

    invoke-direct {v0, v1, v8}, Ltas/internal/ipc/server/ServerManager$ClientHandler;->schedule(ILtas/internal/ipc/server/ServerManager$ClientHandler$Holder;)V

    .line 553
    .end local v8    # "holder":Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;
    :cond_18
    invoke-static/range {v19 .. v19}, Ltas/internal/ipc/server/ServerManager$SenderHolder;->-get1(Ltas/internal/ipc/server/ServerManager$SenderHolder;)Ltas/internal/ipc/server/RemoteSender;

    move-result-object v21

    move-object/from16 v0, v21

    invoke-static {v12, v0}, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->-wrap0(Ltas/internal/ipc/server/ServerManager$ReceiverHolder;Ltas/internal/ipc/server/RemoteSender;)Z

    move-result v21

    if-eqz v21, :cond_17

    .line 554
    invoke-static/range {v19 .. v19}, Ltas/internal/ipc/server/ServerManager$SenderHolder;->-get1(Ltas/internal/ipc/server/ServerManager$SenderHolder;)Ltas/internal/ipc/server/RemoteSender;

    move-result-object v21

    move-object/from16 v0, v21

    invoke-static {v12, v0}, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->-wrap2(Ltas/internal/ipc/server/ServerManager$ReceiverHolder;Ltas/internal/ipc/server/RemoteSender;)Z

    .line 555
    if-nez v8, :cond_19

    .line 556
    new-instance v8, Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;

    const/16 v21, 0x0

    move-object/from16 v0, v19

    move-object/from16 v1, v21

    invoke-direct {v8, v0, v12, v1}, Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;-><init>(Ltas/internal/ipc/server/ServerManager$SenderHolder;Ltas/internal/ipc/server/ServerManager$ReceiverHolder;Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;)V

    .line 558
    :cond_19
    invoke-static {v4}, Ltas/internal/ipc/server/ServerManager$ClientHolder;->-get0(Ltas/internal/ipc/server/ServerManager$ClientHolder;)Ltas/internal/ipc/server/ServerManager$ClientHandler;

    move-result-object v21

    .line 559
    const/16 v22, 0x13

    .line 558
    move-object/from16 v0, v21

    move/from16 v1, v22

    invoke-direct {v0, v1, v8}, Ltas/internal/ipc/server/ServerManager$ClientHandler;->schedule(ILtas/internal/ipc/server/ServerManager$ClientHandler$Holder;)V
    :try_end_d
    .catchall {:try_start_d .. :try_end_d} :catchall_7

    goto :goto_5

    .line 533
    .end local v4    # "client":Ltas/internal/ipc/server/ServerManager$ClientHolder;
    .end local v5    # "client$iterator":Ljava/util/Iterator;
    .end local v6    # "clients":Ljava/util/Collection;, "Ljava/util/Collection<Ltas/internal/ipc/server/ServerManager$ClientHolder;>;"
    .end local v12    # "rh":Ltas/internal/ipc/server/ServerManager$ReceiverHolder;
    :catchall_7
    move-exception v21

    monitor-exit v9

    throw v21

    .restart local v5    # "client$iterator":Ljava/util/Iterator;
    .restart local v6    # "clients":Ljava/util/Collection;, "Ljava/util/Collection<Ltas/internal/ipc/server/ServerManager$ClientHolder;>;"
    :cond_1a
    monitor-exit v9

    .line 564
    invoke-virtual/range {v16 .. v16}, Ltas/internal/ipc/server/RemoteSender;->recycle()V

    goto/16 :goto_0

    .line 568
    .end local v5    # "client$iterator":Ljava/util/Iterator;
    .end local v6    # "clients":Ljava/util/Collection;, "Ljava/util/Collection<Ltas/internal/ipc/server/ServerManager$ClientHolder;>;"
    .end local v16    # "rs":Ltas/internal/ipc/server/RemoteSender;
    .end local v19    # "sh":Ltas/internal/ipc/server/ServerManager$SenderHolder;
    :pswitch_8
    move-object/from16 v0, p1

    iget-object v15, v0, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v15, Ltas/internal/ipc/server/RemoteReceiver;

    .line 569
    .restart local v15    # "rr":Ltas/internal/ipc/server/RemoteReceiver;
    move-object/from16 v0, p0

    invoke-direct {v0, v15}, Ltas/internal/ipc/server/ServerManager$ClientHandler;->findReceiver(Ltas/internal/ipc/server/RemoteReceiver;)Ltas/internal/ipc/server/ServerManager$ReceiverHolder;

    move-result-object v12

    .line 570
    .restart local v12    # "rh":Ltas/internal/ipc/server/ServerManager$ReceiverHolder;
    if-nez v12, :cond_1b

    .line 571
    const-string/jumbo v21, "TasIPC<ServerManager>"

    new-instance v22, Ljava/lang/StringBuilder;

    invoke-direct/range {v22 .. v22}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v23, "r("

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    iget-object v0, v15, Ltas/internal/ipc/server/RemoteReceiver;->name:Ljava/lang/String;

    move-object/from16 v23, v0

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    const-string/jumbo v23, ") not found. "

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    move-object/from16 v0, p1

    iget v0, v0, Landroid/os/Message;->what:I

    move/from16 v23, v0

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v22

    invoke-virtual/range {v22 .. v22}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v22

    invoke-static/range {v21 .. v22}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 572
    invoke-virtual {v15}, Ltas/internal/ipc/server/RemoteReceiver;->recycle()V

    .line 573
    invoke-virtual {v9}, Ltas/internal/ipc/server/ServerManager;->dump()V

    goto/16 :goto_0

    .line 577
    :cond_1b
    iget-object v0, v15, Ltas/internal/ipc/server/RemoteReceiver;->target:Ljava/lang/String;

    move-object/from16 v21, v0

    move-object/from16 v0, v21

    invoke-static {v12, v0}, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->-wrap1(Ltas/internal/ipc/server/ServerManager$ReceiverHolder;Ljava/lang/String;)Z

    move-result v21

    if-eqz v21, :cond_1c

    .line 578
    const-string/jumbo v21, "TasIPC<ServerManager>"

    new-instance v22, Ljava/lang/StringBuilder;

    invoke-direct/range {v22 .. v22}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v23, "r("

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    iget-object v0, v15, Ltas/internal/ipc/server/RemoteReceiver;->name:Ljava/lang/String;

    move-object/from16 v23, v0

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    const-string/jumbo v23, ") already watched "

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    .line 579
    iget-object v0, v15, Ltas/internal/ipc/server/RemoteReceiver;->target:Ljava/lang/String;

    move-object/from16 v23, v0

    .line 578
    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    invoke-virtual/range {v22 .. v22}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v22

    invoke-static/range {v21 .. v22}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 580
    invoke-virtual {v15}, Ltas/internal/ipc/server/RemoteReceiver;->recycle()V

    .line 581
    invoke-virtual {v9}, Ltas/internal/ipc/server/ServerManager;->dump()V

    goto/16 :goto_0

    .line 586
    :cond_1c
    const-string/jumbo v21, "TasIPC<ServerManager>"

    new-instance v22, Ljava/lang/StringBuilder;

    invoke-direct/range {v22 .. v22}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v23, "r("

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    iget-object v0, v15, Ltas/internal/ipc/server/RemoteReceiver;->name:Ljava/lang/String;

    move-object/from16 v23, v0

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    const-string/jumbo v23, ") watches "

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    iget-object v0, v15, Ltas/internal/ipc/server/RemoteReceiver;->target:Ljava/lang/String;

    move-object/from16 v23, v0

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    invoke-virtual/range {v22 .. v22}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v22

    invoke-static/range {v21 .. v22}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 589
    iget-object v0, v15, Ltas/internal/ipc/server/RemoteReceiver;->target:Ljava/lang/String;

    move-object/from16 v21, v0

    move-object/from16 v0, v21

    invoke-static {v12, v0}, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->-wrap6(Ltas/internal/ipc/server/ServerManager$ReceiverHolder;Ljava/lang/String;)V

    .line 590
    monitor-enter v9

    .line 591
    :try_start_e
    invoke-static {v9}, Ltas/internal/ipc/server/ServerManager;->-get0(Ltas/internal/ipc/server/ServerManager;)Landroid/util/ArrayMap;

    move-result-object v21

    invoke-virtual/range {v21 .. v21}, Landroid/util/ArrayMap;->values()Ljava/util/Collection;

    move-result-object v6

    .line 592
    .restart local v6    # "clients":Ljava/util/Collection;, "Ljava/util/Collection<Ltas/internal/ipc/server/ServerManager$ClientHolder;>;"
    const/16 v19, 0x0

    .line 593
    .local v19, "sh":Ltas/internal/ipc/server/ServerManager$SenderHolder;
    invoke-interface {v6}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v5

    .end local v19    # "sh":Ltas/internal/ipc/server/ServerManager$SenderHolder;
    .restart local v5    # "client$iterator":Ljava/util/Iterator;
    :cond_1d
    :goto_6
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v21

    if-eqz v21, :cond_21

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ltas/internal/ipc/server/ServerManager$ClientHolder;

    .line 594
    .restart local v4    # "client":Ltas/internal/ipc/server/ServerManager$ClientHolder;
    if-eqz v4, :cond_1d

    .line 597
    invoke-static {v4}, Ltas/internal/ipc/server/ServerManager$ClientHolder;->-get0(Ltas/internal/ipc/server/ServerManager$ClientHolder;)Ltas/internal/ipc/server/ServerManager$ClientHandler;

    move-result-object v21

    iget-object v0, v15, Ltas/internal/ipc/server/RemoteReceiver;->target:Ljava/lang/String;

    move-object/from16 v22, v0

    invoke-direct/range {v21 .. v22}, Ltas/internal/ipc/server/ServerManager$ClientHandler;->findSender(Ljava/lang/String;)Ltas/internal/ipc/server/ServerManager$SenderHolder;

    move-result-object v19

    .line 598
    .local v19, "sh":Ltas/internal/ipc/server/ServerManager$SenderHolder;
    if-eqz v19, :cond_1d

    .line 599
    invoke-static/range {v19 .. v19}, Ltas/internal/ipc/server/ServerManager$SenderHolder;->-get3(Ltas/internal/ipc/server/ServerManager$SenderHolder;)Ljava/util/List;

    move-result-object v21

    iget-object v0, v15, Ltas/internal/ipc/server/RemoteReceiver;->name:Ljava/lang/String;

    move-object/from16 v22, v0

    invoke-interface/range {v21 .. v22}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v21

    if-nez v21, :cond_1e

    .line 600
    invoke-static/range {v19 .. v19}, Ltas/internal/ipc/server/ServerManager$SenderHolder;->-get2(Ltas/internal/ipc/server/ServerManager$SenderHolder;)Z

    move-result v21

    if-eqz v21, :cond_1d

    .line 602
    :cond_1e
    const/4 v8, 0x0

    .line 604
    .local v8, "holder":Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;
    invoke-static/range {v19 .. v19}, Ltas/internal/ipc/server/ServerManager$SenderHolder;->-get1(Ltas/internal/ipc/server/ServerManager$SenderHolder;)Ltas/internal/ipc/server/RemoteSender;

    move-result-object v21

    move-object/from16 v0, v21

    invoke-static {v12, v0}, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->-wrap0(Ltas/internal/ipc/server/ServerManager$ReceiverHolder;Ltas/internal/ipc/server/RemoteSender;)Z

    move-result v21

    if-nez v21, :cond_1f

    .line 605
    invoke-static/range {v19 .. v19}, Ltas/internal/ipc/server/ServerManager$SenderHolder;->-get1(Ltas/internal/ipc/server/ServerManager$SenderHolder;)Ltas/internal/ipc/server/RemoteSender;

    move-result-object v21

    move-object/from16 v0, v21

    invoke-static {v12, v0}, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->-wrap4(Ltas/internal/ipc/server/ServerManager$ReceiverHolder;Ltas/internal/ipc/server/RemoteSender;)V

    .line 607
    new-instance v8, Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;

    .end local v8    # "holder":Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;
    const/16 v21, 0x0

    move-object/from16 v0, v19

    move-object/from16 v1, v21

    invoke-direct {v8, v0, v12, v1}, Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;-><init>(Ltas/internal/ipc/server/ServerManager$SenderHolder;Ltas/internal/ipc/server/ServerManager$ReceiverHolder;Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;)V

    .line 609
    .local v8, "holder":Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;
    const/16 v21, 0x12

    move-object/from16 v0, p0

    move/from16 v1, v21

    invoke-direct {v0, v1, v8}, Ltas/internal/ipc/server/ServerManager$ClientHandler;->schedule(ILtas/internal/ipc/server/ServerManager$ClientHandler$Holder;)V

    .line 612
    .end local v8    # "holder":Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;
    :cond_1f
    invoke-static {v12}, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->-get0(Ltas/internal/ipc/server/ServerManager$ReceiverHolder;)Ltas/internal/ipc/server/RemoteReceiver;

    move-result-object v21

    move-object/from16 v0, v19

    move-object/from16 v1, v21

    invoke-static {v0, v1}, Ltas/internal/ipc/server/ServerManager$SenderHolder;->-wrap0(Ltas/internal/ipc/server/ServerManager$SenderHolder;Ltas/internal/ipc/server/RemoteReceiver;)Z

    move-result v21

    if-nez v21, :cond_1d

    .line 613
    invoke-static {v12}, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->-get0(Ltas/internal/ipc/server/ServerManager$ReceiverHolder;)Ltas/internal/ipc/server/RemoteReceiver;

    move-result-object v21

    move-object/from16 v0, v19

    move-object/from16 v1, v21

    invoke-static {v0, v1}, Ltas/internal/ipc/server/ServerManager$SenderHolder;->-wrap4(Ltas/internal/ipc/server/ServerManager$SenderHolder;Ltas/internal/ipc/server/RemoteReceiver;)V

    .line 614
    if-nez v8, :cond_20

    .line 615
    new-instance v8, Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;

    const/16 v21, 0x0

    move-object/from16 v0, v19

    move-object/from16 v1, v21

    invoke-direct {v8, v0, v12, v1}, Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;-><init>(Ltas/internal/ipc/server/ServerManager$SenderHolder;Ltas/internal/ipc/server/ServerManager$ReceiverHolder;Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;)V

    .line 617
    :cond_20
    invoke-static {v4}, Ltas/internal/ipc/server/ServerManager$ClientHolder;->-get0(Ltas/internal/ipc/server/ServerManager$ClientHolder;)Ltas/internal/ipc/server/ServerManager$ClientHandler;

    move-result-object v21

    .line 618
    const/16 v22, 0x10

    .line 617
    move-object/from16 v0, v21

    move/from16 v1, v22

    invoke-direct {v0, v1, v8}, Ltas/internal/ipc/server/ServerManager$ClientHandler;->schedule(ILtas/internal/ipc/server/ServerManager$ClientHandler$Holder;)V
    :try_end_e
    .catchall {:try_start_e .. :try_end_e} :catchall_8

    goto/16 :goto_6

    .line 590
    .end local v4    # "client":Ltas/internal/ipc/server/ServerManager$ClientHolder;
    .end local v5    # "client$iterator":Ljava/util/Iterator;
    .end local v6    # "clients":Ljava/util/Collection;, "Ljava/util/Collection<Ltas/internal/ipc/server/ServerManager$ClientHolder;>;"
    .end local v19    # "sh":Ltas/internal/ipc/server/ServerManager$SenderHolder;
    :catchall_8
    move-exception v21

    monitor-exit v9

    throw v21

    .restart local v5    # "client$iterator":Ljava/util/Iterator;
    .restart local v6    # "clients":Ljava/util/Collection;, "Ljava/util/Collection<Ltas/internal/ipc/server/ServerManager$ClientHolder;>;"
    :cond_21
    monitor-exit v9

    .line 623
    invoke-virtual {v15}, Ltas/internal/ipc/server/RemoteReceiver;->recycle()V

    goto/16 :goto_0

    .line 627
    .end local v5    # "client$iterator":Ljava/util/Iterator;
    .end local v6    # "clients":Ljava/util/Collection;, "Ljava/util/Collection<Ltas/internal/ipc/server/ServerManager$ClientHolder;>;"
    .end local v12    # "rh":Ltas/internal/ipc/server/ServerManager$ReceiverHolder;
    .end local v15    # "rr":Ltas/internal/ipc/server/RemoteReceiver;
    :pswitch_9
    move-object/from16 v0, p1

    iget-object v15, v0, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v15, Ltas/internal/ipc/server/RemoteReceiver;

    .line 628
    .restart local v15    # "rr":Ltas/internal/ipc/server/RemoteReceiver;
    move-object/from16 v0, p0

    invoke-direct {v0, v15}, Ltas/internal/ipc/server/ServerManager$ClientHandler;->findReceiver(Ltas/internal/ipc/server/RemoteReceiver;)Ltas/internal/ipc/server/ServerManager$ReceiverHolder;

    move-result-object v12

    .line 629
    .restart local v12    # "rh":Ltas/internal/ipc/server/ServerManager$ReceiverHolder;
    if-nez v12, :cond_22

    .line 630
    const-string/jumbo v21, "TasIPC<ServerManager>"

    new-instance v22, Ljava/lang/StringBuilder;

    invoke-direct/range {v22 .. v22}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v23, "r("

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    iget-object v0, v15, Ltas/internal/ipc/server/RemoteReceiver;->name:Ljava/lang/String;

    move-object/from16 v23, v0

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    const-string/jumbo v23, ") not found. "

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    move-object/from16 v0, p1

    iget v0, v0, Landroid/os/Message;->what:I

    move/from16 v23, v0

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v22

    invoke-virtual/range {v22 .. v22}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v22

    invoke-static/range {v21 .. v22}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 631
    invoke-virtual {v15}, Ltas/internal/ipc/server/RemoteReceiver;->recycle()V

    .line 632
    invoke-virtual {v9}, Ltas/internal/ipc/server/ServerManager;->dump()V

    goto/16 :goto_0

    .line 636
    :cond_22
    iget-object v0, v15, Ltas/internal/ipc/server/RemoteReceiver;->target:Ljava/lang/String;

    move-object/from16 v21, v0

    move-object/from16 v0, v21

    invoke-static {v12, v0}, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->-wrap1(Ltas/internal/ipc/server/ServerManager$ReceiverHolder;Ljava/lang/String;)Z

    move-result v21

    if-nez v21, :cond_23

    .line 637
    const-string/jumbo v21, "TasIPC<ServerManager>"

    new-instance v22, Ljava/lang/StringBuilder;

    invoke-direct/range {v22 .. v22}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v23, "r("

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    iget-object v0, v15, Ltas/internal/ipc/server/RemoteReceiver;->name:Ljava/lang/String;

    move-object/from16 v23, v0

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    const-string/jumbo v23, ") not watch "

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    iget-object v0, v15, Ltas/internal/ipc/server/RemoteReceiver;->target:Ljava/lang/String;

    move-object/from16 v23, v0

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    invoke-virtual/range {v22 .. v22}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v22

    invoke-static/range {v21 .. v22}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 638
    invoke-virtual {v15}, Ltas/internal/ipc/server/RemoteReceiver;->recycle()V

    .line 639
    invoke-virtual {v9}, Ltas/internal/ipc/server/ServerManager;->dump()V

    goto/16 :goto_0

    .line 644
    :cond_23
    const-string/jumbo v21, "TasIPC<ServerManager>"

    new-instance v22, Ljava/lang/StringBuilder;

    invoke-direct/range {v22 .. v22}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v23, "r("

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    iget-object v0, v15, Ltas/internal/ipc/server/RemoteReceiver;->name:Ljava/lang/String;

    move-object/from16 v23, v0

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    const-string/jumbo v23, ") unwatches "

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    iget-object v0, v15, Ltas/internal/ipc/server/RemoteReceiver;->target:Ljava/lang/String;

    move-object/from16 v23, v0

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    invoke-virtual/range {v22 .. v22}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v22

    invoke-static/range {v21 .. v22}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 647
    iget-object v0, v15, Ltas/internal/ipc/server/RemoteReceiver;->target:Ljava/lang/String;

    move-object/from16 v21, v0

    move-object/from16 v0, v21

    invoke-static {v12, v0}, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->-wrap3(Ltas/internal/ipc/server/ServerManager$ReceiverHolder;Ljava/lang/String;)Z

    .line 648
    monitor-enter v9

    .line 649
    :try_start_f
    invoke-static {v9}, Ltas/internal/ipc/server/ServerManager;->-get0(Ltas/internal/ipc/server/ServerManager;)Landroid/util/ArrayMap;

    move-result-object v21

    invoke-virtual/range {v21 .. v21}, Landroid/util/ArrayMap;->values()Ljava/util/Collection;

    move-result-object v6

    .line 650
    .restart local v6    # "clients":Ljava/util/Collection;, "Ljava/util/Collection<Ltas/internal/ipc/server/ServerManager$ClientHolder;>;"
    const/16 v19, 0x0

    .line 651
    .local v19, "sh":Ltas/internal/ipc/server/ServerManager$SenderHolder;
    invoke-interface {v6}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v5

    .end local v19    # "sh":Ltas/internal/ipc/server/ServerManager$SenderHolder;
    .restart local v5    # "client$iterator":Ljava/util/Iterator;
    :cond_24
    :goto_7
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v21

    if-eqz v21, :cond_27

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ltas/internal/ipc/server/ServerManager$ClientHolder;

    .line 652
    .restart local v4    # "client":Ltas/internal/ipc/server/ServerManager$ClientHolder;
    if-eqz v4, :cond_24

    .line 655
    invoke-static {v4}, Ltas/internal/ipc/server/ServerManager$ClientHolder;->-get0(Ltas/internal/ipc/server/ServerManager$ClientHolder;)Ltas/internal/ipc/server/ServerManager$ClientHandler;

    move-result-object v21

    iget-object v0, v15, Ltas/internal/ipc/server/RemoteReceiver;->target:Ljava/lang/String;

    move-object/from16 v22, v0

    invoke-direct/range {v21 .. v22}, Ltas/internal/ipc/server/ServerManager$ClientHandler;->findSender(Ljava/lang/String;)Ltas/internal/ipc/server/ServerManager$SenderHolder;

    move-result-object v19

    .line 656
    .local v19, "sh":Ltas/internal/ipc/server/ServerManager$SenderHolder;
    if-eqz v19, :cond_24

    .line 658
    const/4 v8, 0x0

    .line 660
    .local v8, "holder":Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;
    invoke-static/range {v19 .. v19}, Ltas/internal/ipc/server/ServerManager$SenderHolder;->-get1(Ltas/internal/ipc/server/ServerManager$SenderHolder;)Ltas/internal/ipc/server/RemoteSender;

    move-result-object v21

    move-object/from16 v0, v21

    invoke-static {v12, v0}, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->-wrap0(Ltas/internal/ipc/server/ServerManager$ReceiverHolder;Ltas/internal/ipc/server/RemoteSender;)Z

    move-result v21

    if-eqz v21, :cond_25

    .line 661
    invoke-static/range {v19 .. v19}, Ltas/internal/ipc/server/ServerManager$SenderHolder;->-get1(Ltas/internal/ipc/server/ServerManager$SenderHolder;)Ltas/internal/ipc/server/RemoteSender;

    move-result-object v21

    move-object/from16 v0, v21

    invoke-static {v12, v0}, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->-wrap2(Ltas/internal/ipc/server/ServerManager$ReceiverHolder;Ltas/internal/ipc/server/RemoteSender;)Z

    .line 663
    new-instance v8, Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;

    .end local v8    # "holder":Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;
    const/16 v21, 0x0

    move-object/from16 v0, v19

    move-object/from16 v1, v21

    invoke-direct {v8, v0, v12, v1}, Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;-><init>(Ltas/internal/ipc/server/ServerManager$SenderHolder;Ltas/internal/ipc/server/ServerManager$ReceiverHolder;Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;)V

    .line 665
    .local v8, "holder":Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;
    const/16 v21, 0x13

    move-object/from16 v0, p0

    move/from16 v1, v21

    invoke-direct {v0, v1, v8}, Ltas/internal/ipc/server/ServerManager$ClientHandler;->schedule(ILtas/internal/ipc/server/ServerManager$ClientHandler$Holder;)V

    .line 668
    .end local v8    # "holder":Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;
    :cond_25
    invoke-static {v12}, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->-get0(Ltas/internal/ipc/server/ServerManager$ReceiverHolder;)Ltas/internal/ipc/server/RemoteReceiver;

    move-result-object v21

    move-object/from16 v0, v19

    move-object/from16 v1, v21

    invoke-static {v0, v1}, Ltas/internal/ipc/server/ServerManager$SenderHolder;->-wrap0(Ltas/internal/ipc/server/ServerManager$SenderHolder;Ltas/internal/ipc/server/RemoteReceiver;)Z

    move-result v21

    if-eqz v21, :cond_24

    .line 669
    invoke-static {v12}, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->-get0(Ltas/internal/ipc/server/ServerManager$ReceiverHolder;)Ltas/internal/ipc/server/RemoteReceiver;

    move-result-object v21

    move-object/from16 v0, v19

    move-object/from16 v1, v21

    invoke-static {v0, v1}, Ltas/internal/ipc/server/ServerManager$SenderHolder;->-wrap2(Ltas/internal/ipc/server/ServerManager$SenderHolder;Ltas/internal/ipc/server/RemoteReceiver;)Z

    .line 670
    if-nez v8, :cond_26

    .line 671
    new-instance v8, Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;

    const/16 v21, 0x0

    move-object/from16 v0, v19

    move-object/from16 v1, v21

    invoke-direct {v8, v0, v12, v1}, Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;-><init>(Ltas/internal/ipc/server/ServerManager$SenderHolder;Ltas/internal/ipc/server/ServerManager$ReceiverHolder;Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;)V

    .line 673
    :cond_26
    invoke-static {v4}, Ltas/internal/ipc/server/ServerManager$ClientHolder;->-get0(Ltas/internal/ipc/server/ServerManager$ClientHolder;)Ltas/internal/ipc/server/ServerManager$ClientHandler;

    move-result-object v21

    .line 674
    const/16 v22, 0x11

    .line 673
    move-object/from16 v0, v21

    move/from16 v1, v22

    invoke-direct {v0, v1, v8}, Ltas/internal/ipc/server/ServerManager$ClientHandler;->schedule(ILtas/internal/ipc/server/ServerManager$ClientHandler$Holder;)V
    :try_end_f
    .catchall {:try_start_f .. :try_end_f} :catchall_9

    goto :goto_7

    .line 648
    .end local v4    # "client":Ltas/internal/ipc/server/ServerManager$ClientHolder;
    .end local v5    # "client$iterator":Ljava/util/Iterator;
    .end local v6    # "clients":Ljava/util/Collection;, "Ljava/util/Collection<Ltas/internal/ipc/server/ServerManager$ClientHolder;>;"
    .end local v19    # "sh":Ltas/internal/ipc/server/ServerManager$SenderHolder;
    :catchall_9
    move-exception v21

    monitor-exit v9

    throw v21

    .restart local v5    # "client$iterator":Ljava/util/Iterator;
    .restart local v6    # "clients":Ljava/util/Collection;, "Ljava/util/Collection<Ltas/internal/ipc/server/ServerManager$ClientHolder;>;"
    :cond_27
    monitor-exit v9

    .line 679
    invoke-virtual {v15}, Ltas/internal/ipc/server/RemoteReceiver;->recycle()V

    goto/16 :goto_0

    .line 683
    .end local v5    # "client$iterator":Ljava/util/Iterator;
    .end local v6    # "clients":Ljava/util/Collection;, "Ljava/util/Collection<Ltas/internal/ipc/server/ServerManager$ClientHolder;>;"
    .end local v12    # "rh":Ltas/internal/ipc/server/ServerManager$ReceiverHolder;
    .end local v15    # "rr":Ltas/internal/ipc/server/RemoteReceiver;
    :pswitch_a
    move-object/from16 v0, p1

    iget-object v0, v0, Landroid/os/Message;->obj:Ljava/lang/Object;

    move-object/from16 v16, v0

    check-cast v16, Ltas/internal/ipc/server/RemoteSender;

    .line 684
    .restart local v16    # "rs":Ltas/internal/ipc/server/RemoteSender;
    move-object/from16 v0, p0

    move-object/from16 v1, v16

    invoke-direct {v0, v1}, Ltas/internal/ipc/server/ServerManager$ClientHandler;->findSender(Ltas/internal/ipc/server/RemoteSender;)Ltas/internal/ipc/server/ServerManager$SenderHolder;

    move-result-object v19

    .line 685
    .restart local v19    # "sh":Ltas/internal/ipc/server/ServerManager$SenderHolder;
    if-nez v19, :cond_28

    .line 686
    const-string/jumbo v21, "TasIPC<ServerManager>"

    new-instance v22, Ljava/lang/StringBuilder;

    invoke-direct/range {v22 .. v22}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v23, "s("

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    move-object/from16 v0, v16

    iget-object v0, v0, Ltas/internal/ipc/server/RemoteSender;->name:Ljava/lang/String;

    move-object/from16 v23, v0

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    const-string/jumbo v23, ") not found. "

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    move-object/from16 v0, p1

    iget v0, v0, Landroid/os/Message;->what:I

    move/from16 v23, v0

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v22

    invoke-virtual/range {v22 .. v22}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v22

    invoke-static/range {v21 .. v22}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 687
    invoke-virtual/range {v16 .. v16}, Ltas/internal/ipc/server/RemoteSender;->recycle()V

    .line 688
    invoke-virtual {v9}, Ltas/internal/ipc/server/ServerManager;->dump()V

    goto/16 :goto_0

    .line 693
    :cond_28
    const-string/jumbo v21, "TasIPC<ServerManager>"

    new-instance v22, Ljava/lang/StringBuilder;

    invoke-direct/range {v22 .. v22}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v23, "s("

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    move-object/from16 v0, v16

    iget-object v0, v0, Ltas/internal/ipc/server/RemoteSender;->name:Ljava/lang/String;

    move-object/from16 v23, v0

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    const-string/jumbo v23, ") watches nobody"

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    invoke-virtual/range {v22 .. v22}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v22

    invoke-static/range {v21 .. v22}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 696
    monitor-enter v9

    .line 697
    const/16 v21, 0x1

    :try_start_10
    move-object/from16 v0, v19

    move/from16 v1, v21

    invoke-static {v0, v1}, Ltas/internal/ipc/server/ServerManager$SenderHolder;->-set0(Ltas/internal/ipc/server/ServerManager$SenderHolder;Z)Z

    .line 698
    invoke-static {v9}, Ltas/internal/ipc/server/ServerManager;->-get0(Ltas/internal/ipc/server/ServerManager;)Landroid/util/ArrayMap;

    move-result-object v21

    invoke-virtual/range {v21 .. v21}, Landroid/util/ArrayMap;->values()Ljava/util/Collection;

    move-result-object v6

    .line 699
    .restart local v6    # "clients":Ljava/util/Collection;, "Ljava/util/Collection<Ltas/internal/ipc/server/ServerManager$ClientHolder;>;"
    invoke-interface {v6}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v5

    .restart local v5    # "client$iterator":Ljava/util/Iterator;
    :cond_29
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v21

    if-eqz v21, :cond_2d

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ltas/internal/ipc/server/ServerManager$ClientHolder;

    .line 700
    .restart local v4    # "client":Ltas/internal/ipc/server/ServerManager$ClientHolder;
    if-eqz v4, :cond_29

    .line 704
    invoke-static {v4}, Ltas/internal/ipc/server/ServerManager$ClientHolder;->-get0(Ltas/internal/ipc/server/ServerManager$ClientHolder;)Ltas/internal/ipc/server/ServerManager$ClientHandler;

    move-result-object v21

    .line 703
    move-object/from16 v0, v21

    iget-object v11, v0, Ltas/internal/ipc/server/ServerManager$ClientHandler;->mReceivers:Ljava/util/List;

    .line 705
    .local v11, "receivers":Ljava/util/List;, "Ljava/util/List<Ltas/internal/ipc/server/ServerManager$ReceiverHolder;>;"
    invoke-interface {v11}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v13

    .restart local v13    # "rh$iterator":Ljava/util/Iterator;
    :cond_2a
    :goto_8
    invoke-interface {v13}, Ljava/util/Iterator;->hasNext()Z

    move-result v21

    if-eqz v21, :cond_29

    invoke-interface {v13}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;

    .line 706
    .restart local v12    # "rh":Ltas/internal/ipc/server/ServerManager$ReceiverHolder;
    if-eqz v12, :cond_2a

    invoke-static {v12}, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->-get3(Ltas/internal/ipc/server/ServerManager$ReceiverHolder;)Ljava/util/List;

    move-result-object v21

    move-object/from16 v0, v16

    iget-object v0, v0, Ltas/internal/ipc/server/RemoteSender;->name:Ljava/lang/String;

    move-object/from16 v22, v0

    invoke-interface/range {v21 .. v22}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v21

    if-eqz v21, :cond_2a

    .line 708
    const/4 v8, 0x0

    .line 710
    .local v8, "holder":Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;
    invoke-static {v12}, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->-get0(Ltas/internal/ipc/server/ServerManager$ReceiverHolder;)Ltas/internal/ipc/server/RemoteReceiver;

    move-result-object v21

    move-object/from16 v0, v19

    move-object/from16 v1, v21

    invoke-static {v0, v1}, Ltas/internal/ipc/server/ServerManager$SenderHolder;->-wrap0(Ltas/internal/ipc/server/ServerManager$SenderHolder;Ltas/internal/ipc/server/RemoteReceiver;)Z

    move-result v21

    if-nez v21, :cond_2b

    .line 711
    invoke-static {v12}, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->-get0(Ltas/internal/ipc/server/ServerManager$ReceiverHolder;)Ltas/internal/ipc/server/RemoteReceiver;

    move-result-object v21

    move-object/from16 v0, v19

    move-object/from16 v1, v21

    invoke-static {v0, v1}, Ltas/internal/ipc/server/ServerManager$SenderHolder;->-wrap4(Ltas/internal/ipc/server/ServerManager$SenderHolder;Ltas/internal/ipc/server/RemoteReceiver;)V

    .line 713
    new-instance v8, Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;

    .end local v8    # "holder":Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;
    const/16 v21, 0x0

    move-object/from16 v0, v19

    move-object/from16 v1, v21

    invoke-direct {v8, v0, v12, v1}, Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;-><init>(Ltas/internal/ipc/server/ServerManager$SenderHolder;Ltas/internal/ipc/server/ServerManager$ReceiverHolder;Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;)V

    .line 715
    .local v8, "holder":Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;
    const/16 v21, 0x10

    move-object/from16 v0, p0

    move/from16 v1, v21

    invoke-direct {v0, v1, v8}, Ltas/internal/ipc/server/ServerManager$ClientHandler;->schedule(ILtas/internal/ipc/server/ServerManager$ClientHandler$Holder;)V

    .line 718
    .end local v8    # "holder":Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;
    :cond_2b
    invoke-static/range {v19 .. v19}, Ltas/internal/ipc/server/ServerManager$SenderHolder;->-get1(Ltas/internal/ipc/server/ServerManager$SenderHolder;)Ltas/internal/ipc/server/RemoteSender;

    move-result-object v21

    move-object/from16 v0, v21

    invoke-static {v12, v0}, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->-wrap0(Ltas/internal/ipc/server/ServerManager$ReceiverHolder;Ltas/internal/ipc/server/RemoteSender;)Z

    move-result v21

    if-nez v21, :cond_2a

    .line 719
    invoke-static/range {v19 .. v19}, Ltas/internal/ipc/server/ServerManager$SenderHolder;->-get1(Ltas/internal/ipc/server/ServerManager$SenderHolder;)Ltas/internal/ipc/server/RemoteSender;

    move-result-object v21

    move-object/from16 v0, v21

    invoke-static {v12, v0}, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->-wrap4(Ltas/internal/ipc/server/ServerManager$ReceiverHolder;Ltas/internal/ipc/server/RemoteSender;)V

    .line 720
    if-nez v8, :cond_2c

    .line 721
    new-instance v8, Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;

    const/16 v21, 0x0

    move-object/from16 v0, v19

    move-object/from16 v1, v21

    invoke-direct {v8, v0, v12, v1}, Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;-><init>(Ltas/internal/ipc/server/ServerManager$SenderHolder;Ltas/internal/ipc/server/ServerManager$ReceiverHolder;Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;)V

    .line 723
    :cond_2c
    invoke-static {v4}, Ltas/internal/ipc/server/ServerManager$ClientHolder;->-get0(Ltas/internal/ipc/server/ServerManager$ClientHolder;)Ltas/internal/ipc/server/ServerManager$ClientHandler;

    move-result-object v21

    .line 724
    const/16 v22, 0x12

    .line 723
    move-object/from16 v0, v21

    move/from16 v1, v22

    invoke-direct {v0, v1, v8}, Ltas/internal/ipc/server/ServerManager$ClientHandler;->schedule(ILtas/internal/ipc/server/ServerManager$ClientHandler$Holder;)V
    :try_end_10
    .catchall {:try_start_10 .. :try_end_10} :catchall_a

    goto :goto_8

    .line 696
    .end local v4    # "client":Ltas/internal/ipc/server/ServerManager$ClientHolder;
    .end local v5    # "client$iterator":Ljava/util/Iterator;
    .end local v6    # "clients":Ljava/util/Collection;, "Ljava/util/Collection<Ltas/internal/ipc/server/ServerManager$ClientHolder;>;"
    .end local v11    # "receivers":Ljava/util/List;, "Ljava/util/List<Ltas/internal/ipc/server/ServerManager$ReceiverHolder;>;"
    .end local v12    # "rh":Ltas/internal/ipc/server/ServerManager$ReceiverHolder;
    .end local v13    # "rh$iterator":Ljava/util/Iterator;
    :catchall_a
    move-exception v21

    monitor-exit v9

    throw v21

    .restart local v5    # "client$iterator":Ljava/util/Iterator;
    .restart local v6    # "clients":Ljava/util/Collection;, "Ljava/util/Collection<Ltas/internal/ipc/server/ServerManager$ClientHolder;>;"
    :cond_2d
    monitor-exit v9

    .line 730
    invoke-virtual/range {v16 .. v16}, Ltas/internal/ipc/server/RemoteSender;->recycle()V

    goto/16 :goto_0

    .line 734
    .end local v5    # "client$iterator":Ljava/util/Iterator;
    .end local v6    # "clients":Ljava/util/Collection;, "Ljava/util/Collection<Ltas/internal/ipc/server/ServerManager$ClientHolder;>;"
    .end local v16    # "rs":Ltas/internal/ipc/server/RemoteSender;
    .end local v19    # "sh":Ltas/internal/ipc/server/ServerManager$SenderHolder;
    :pswitch_b
    move-object/from16 v0, p1

    iget-object v0, v0, Landroid/os/Message;->obj:Ljava/lang/Object;

    move-object/from16 v16, v0

    check-cast v16, Ltas/internal/ipc/server/RemoteSender;

    .line 735
    .restart local v16    # "rs":Ltas/internal/ipc/server/RemoteSender;
    move-object/from16 v0, p0

    move-object/from16 v1, v16

    invoke-direct {v0, v1}, Ltas/internal/ipc/server/ServerManager$ClientHandler;->findSender(Ltas/internal/ipc/server/RemoteSender;)Ltas/internal/ipc/server/ServerManager$SenderHolder;

    move-result-object v19

    .line 736
    .restart local v19    # "sh":Ltas/internal/ipc/server/ServerManager$SenderHolder;
    if-nez v19, :cond_2e

    .line 737
    const-string/jumbo v21, "TasIPC<ServerManager>"

    new-instance v22, Ljava/lang/StringBuilder;

    invoke-direct/range {v22 .. v22}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v23, "s("

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    move-object/from16 v0, v16

    iget-object v0, v0, Ltas/internal/ipc/server/RemoteSender;->name:Ljava/lang/String;

    move-object/from16 v23, v0

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    const-string/jumbo v23, ") not found. "

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    move-object/from16 v0, p1

    iget v0, v0, Landroid/os/Message;->what:I

    move/from16 v23, v0

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v22

    invoke-virtual/range {v22 .. v22}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v22

    invoke-static/range {v21 .. v22}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 738
    invoke-virtual/range {v16 .. v16}, Ltas/internal/ipc/server/RemoteSender;->recycle()V

    .line 739
    invoke-virtual {v9}, Ltas/internal/ipc/server/ServerManager;->dump()V

    goto/16 :goto_0

    .line 744
    :cond_2e
    const-string/jumbo v21, "TasIPC<ServerManager>"

    new-instance v22, Ljava/lang/StringBuilder;

    invoke-direct/range {v22 .. v22}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v23, "s("

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    move-object/from16 v0, v16

    iget-object v0, v0, Ltas/internal/ipc/server/RemoteSender;->name:Ljava/lang/String;

    move-object/from16 v23, v0

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    const-string/jumbo v23, ") unwatches nobody"

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    invoke-virtual/range {v22 .. v22}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v22

    invoke-static/range {v21 .. v22}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 747
    monitor-enter v9

    .line 748
    const/16 v21, 0x0

    :try_start_11
    move-object/from16 v0, v19

    move/from16 v1, v21

    invoke-static {v0, v1}, Ltas/internal/ipc/server/ServerManager$SenderHolder;->-set0(Ltas/internal/ipc/server/ServerManager$SenderHolder;Z)Z

    .line 749
    invoke-static {v9}, Ltas/internal/ipc/server/ServerManager;->-get0(Ltas/internal/ipc/server/ServerManager;)Landroid/util/ArrayMap;

    move-result-object v21

    invoke-virtual/range {v21 .. v21}, Landroid/util/ArrayMap;->values()Ljava/util/Collection;

    move-result-object v6

    .line 750
    .restart local v6    # "clients":Ljava/util/Collection;, "Ljava/util/Collection<Ltas/internal/ipc/server/ServerManager$ClientHolder;>;"
    invoke-interface {v6}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v5

    .restart local v5    # "client$iterator":Ljava/util/Iterator;
    :cond_2f
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v21

    if-eqz v21, :cond_33

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ltas/internal/ipc/server/ServerManager$ClientHolder;

    .line 751
    .restart local v4    # "client":Ltas/internal/ipc/server/ServerManager$ClientHolder;
    if-eqz v4, :cond_2f

    .line 755
    invoke-static {v4}, Ltas/internal/ipc/server/ServerManager$ClientHolder;->-get0(Ltas/internal/ipc/server/ServerManager$ClientHolder;)Ltas/internal/ipc/server/ServerManager$ClientHandler;

    move-result-object v21

    .line 754
    move-object/from16 v0, v21

    iget-object v11, v0, Ltas/internal/ipc/server/ServerManager$ClientHandler;->mReceivers:Ljava/util/List;

    .line 756
    .restart local v11    # "receivers":Ljava/util/List;, "Ljava/util/List<Ltas/internal/ipc/server/ServerManager$ReceiverHolder;>;"
    invoke-interface {v11}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v13

    .restart local v13    # "rh$iterator":Ljava/util/Iterator;
    :cond_30
    :goto_9
    invoke-interface {v13}, Ljava/util/Iterator;->hasNext()Z

    move-result v21

    if-eqz v21, :cond_2f

    invoke-interface {v13}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;

    .line 757
    .restart local v12    # "rh":Ltas/internal/ipc/server/ServerManager$ReceiverHolder;
    if-eqz v12, :cond_30

    invoke-static {v12}, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->-get3(Ltas/internal/ipc/server/ServerManager$ReceiverHolder;)Ljava/util/List;

    move-result-object v21

    move-object/from16 v0, v16

    iget-object v0, v0, Ltas/internal/ipc/server/RemoteSender;->name:Ljava/lang/String;

    move-object/from16 v22, v0

    invoke-interface/range {v21 .. v22}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v21

    if-eqz v21, :cond_30

    .line 758
    invoke-static/range {v19 .. v19}, Ltas/internal/ipc/server/ServerManager$SenderHolder;->-get3(Ltas/internal/ipc/server/ServerManager$SenderHolder;)Ljava/util/List;

    move-result-object v21

    invoke-static {v12}, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->-get0(Ltas/internal/ipc/server/ServerManager$ReceiverHolder;)Ltas/internal/ipc/server/RemoteReceiver;

    move-result-object v22

    move-object/from16 v0, v22

    iget-object v0, v0, Ltas/internal/ipc/server/RemoteReceiver;->name:Ljava/lang/String;

    move-object/from16 v22, v0

    invoke-interface/range {v21 .. v22}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v21

    if-nez v21, :cond_30

    .line 760
    const/4 v8, 0x0

    .line 762
    .local v8, "holder":Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;
    invoke-static {v12}, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->-get0(Ltas/internal/ipc/server/ServerManager$ReceiverHolder;)Ltas/internal/ipc/server/RemoteReceiver;

    move-result-object v21

    move-object/from16 v0, v19

    move-object/from16 v1, v21

    invoke-static {v0, v1}, Ltas/internal/ipc/server/ServerManager$SenderHolder;->-wrap0(Ltas/internal/ipc/server/ServerManager$SenderHolder;Ltas/internal/ipc/server/RemoteReceiver;)Z

    move-result v21

    if-eqz v21, :cond_31

    .line 763
    invoke-static {v12}, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->-get0(Ltas/internal/ipc/server/ServerManager$ReceiverHolder;)Ltas/internal/ipc/server/RemoteReceiver;

    move-result-object v21

    move-object/from16 v0, v19

    move-object/from16 v1, v21

    invoke-static {v0, v1}, Ltas/internal/ipc/server/ServerManager$SenderHolder;->-wrap2(Ltas/internal/ipc/server/ServerManager$SenderHolder;Ltas/internal/ipc/server/RemoteReceiver;)Z

    .line 765
    new-instance v8, Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;

    .end local v8    # "holder":Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;
    const/16 v21, 0x0

    move-object/from16 v0, v19

    move-object/from16 v1, v21

    invoke-direct {v8, v0, v12, v1}, Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;-><init>(Ltas/internal/ipc/server/ServerManager$SenderHolder;Ltas/internal/ipc/server/ServerManager$ReceiverHolder;Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;)V

    .line 767
    .local v8, "holder":Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;
    const/16 v21, 0x11

    move-object/from16 v0, p0

    move/from16 v1, v21

    invoke-direct {v0, v1, v8}, Ltas/internal/ipc/server/ServerManager$ClientHandler;->schedule(ILtas/internal/ipc/server/ServerManager$ClientHandler$Holder;)V

    .line 770
    .end local v8    # "holder":Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;
    :cond_31
    invoke-static/range {v19 .. v19}, Ltas/internal/ipc/server/ServerManager$SenderHolder;->-get1(Ltas/internal/ipc/server/ServerManager$SenderHolder;)Ltas/internal/ipc/server/RemoteSender;

    move-result-object v21

    move-object/from16 v0, v21

    invoke-static {v12, v0}, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->-wrap0(Ltas/internal/ipc/server/ServerManager$ReceiverHolder;Ltas/internal/ipc/server/RemoteSender;)Z

    move-result v21

    if-eqz v21, :cond_30

    .line 771
    invoke-static/range {v19 .. v19}, Ltas/internal/ipc/server/ServerManager$SenderHolder;->-get1(Ltas/internal/ipc/server/ServerManager$SenderHolder;)Ltas/internal/ipc/server/RemoteSender;

    move-result-object v21

    move-object/from16 v0, v21

    invoke-static {v12, v0}, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->-wrap2(Ltas/internal/ipc/server/ServerManager$ReceiverHolder;Ltas/internal/ipc/server/RemoteSender;)Z

    .line 772
    if-nez v8, :cond_32

    .line 773
    new-instance v8, Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;

    const/16 v21, 0x0

    move-object/from16 v0, v19

    move-object/from16 v1, v21

    invoke-direct {v8, v0, v12, v1}, Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;-><init>(Ltas/internal/ipc/server/ServerManager$SenderHolder;Ltas/internal/ipc/server/ServerManager$ReceiverHolder;Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;)V

    .line 775
    :cond_32
    invoke-static {v4}, Ltas/internal/ipc/server/ServerManager$ClientHolder;->-get0(Ltas/internal/ipc/server/ServerManager$ClientHolder;)Ltas/internal/ipc/server/ServerManager$ClientHandler;

    move-result-object v21

    .line 776
    const/16 v22, 0x13

    .line 775
    move-object/from16 v0, v21

    move/from16 v1, v22

    invoke-direct {v0, v1, v8}, Ltas/internal/ipc/server/ServerManager$ClientHandler;->schedule(ILtas/internal/ipc/server/ServerManager$ClientHandler$Holder;)V
    :try_end_11
    .catchall {:try_start_11 .. :try_end_11} :catchall_b

    goto/16 :goto_9

    .line 747
    .end local v4    # "client":Ltas/internal/ipc/server/ServerManager$ClientHolder;
    .end local v5    # "client$iterator":Ljava/util/Iterator;
    .end local v6    # "clients":Ljava/util/Collection;, "Ljava/util/Collection<Ltas/internal/ipc/server/ServerManager$ClientHolder;>;"
    .end local v11    # "receivers":Ljava/util/List;, "Ljava/util/List<Ltas/internal/ipc/server/ServerManager$ReceiverHolder;>;"
    .end local v12    # "rh":Ltas/internal/ipc/server/ServerManager$ReceiverHolder;
    .end local v13    # "rh$iterator":Ljava/util/Iterator;
    :catchall_b
    move-exception v21

    monitor-exit v9

    throw v21

    .restart local v5    # "client$iterator":Ljava/util/Iterator;
    .restart local v6    # "clients":Ljava/util/Collection;, "Ljava/util/Collection<Ltas/internal/ipc/server/ServerManager$ClientHolder;>;"
    :cond_33
    monitor-exit v9

    .line 782
    invoke-virtual/range {v16 .. v16}, Ltas/internal/ipc/server/RemoteSender;->recycle()V

    goto/16 :goto_0

    .line 786
    .end local v5    # "client$iterator":Ljava/util/Iterator;
    .end local v6    # "clients":Ljava/util/Collection;, "Ljava/util/Collection<Ltas/internal/ipc/server/ServerManager$ClientHolder;>;"
    .end local v16    # "rs":Ltas/internal/ipc/server/RemoteSender;
    .end local v19    # "sh":Ltas/internal/ipc/server/ServerManager$SenderHolder;
    :pswitch_c
    move-object/from16 v0, p1

    iget-object v15, v0, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v15, Ltas/internal/ipc/server/RemoteReceiver;

    .line 787
    .restart local v15    # "rr":Ltas/internal/ipc/server/RemoteReceiver;
    move-object/from16 v0, p0

    invoke-direct {v0, v15}, Ltas/internal/ipc/server/ServerManager$ClientHandler;->findReceiver(Ltas/internal/ipc/server/RemoteReceiver;)Ltas/internal/ipc/server/ServerManager$ReceiverHolder;

    move-result-object v12

    .line 788
    .restart local v12    # "rh":Ltas/internal/ipc/server/ServerManager$ReceiverHolder;
    if-nez v12, :cond_34

    .line 789
    const-string/jumbo v21, "TasIPC<ServerManager>"

    new-instance v22, Ljava/lang/StringBuilder;

    invoke-direct/range {v22 .. v22}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v23, "r("

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    iget-object v0, v15, Ltas/internal/ipc/server/RemoteReceiver;->name:Ljava/lang/String;

    move-object/from16 v23, v0

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    const-string/jumbo v23, ") not found. "

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    move-object/from16 v0, p1

    iget v0, v0, Landroid/os/Message;->what:I

    move/from16 v23, v0

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v22

    invoke-virtual/range {v22 .. v22}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v22

    invoke-static/range {v21 .. v22}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 790
    invoke-virtual {v15}, Ltas/internal/ipc/server/RemoteReceiver;->recycle()V

    .line 791
    invoke-virtual {v9}, Ltas/internal/ipc/server/ServerManager;->dump()V

    goto/16 :goto_0

    .line 796
    :cond_34
    const-string/jumbo v21, "TasIPC<ServerManager>"

    new-instance v22, Ljava/lang/StringBuilder;

    invoke-direct/range {v22 .. v22}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v23, "r("

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    iget-object v0, v15, Ltas/internal/ipc/server/RemoteReceiver;->name:Ljava/lang/String;

    move-object/from16 v23, v0

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    const-string/jumbo v23, ") watches nobody"

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    invoke-virtual/range {v22 .. v22}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v22

    invoke-static/range {v21 .. v22}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 799
    monitor-enter v9

    .line 800
    const/16 v21, 0x1

    :try_start_12
    move/from16 v0, v21

    invoke-static {v12, v0}, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->-set0(Ltas/internal/ipc/server/ServerManager$ReceiverHolder;Z)Z

    .line 801
    invoke-static {v9}, Ltas/internal/ipc/server/ServerManager;->-get0(Ltas/internal/ipc/server/ServerManager;)Landroid/util/ArrayMap;

    move-result-object v21

    invoke-virtual/range {v21 .. v21}, Landroid/util/ArrayMap;->values()Ljava/util/Collection;

    move-result-object v6

    .line 802
    .restart local v6    # "clients":Ljava/util/Collection;, "Ljava/util/Collection<Ltas/internal/ipc/server/ServerManager$ClientHolder;>;"
    invoke-interface {v6}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v5

    .restart local v5    # "client$iterator":Ljava/util/Iterator;
    :cond_35
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v21

    if-eqz v21, :cond_39

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ltas/internal/ipc/server/ServerManager$ClientHolder;

    .line 803
    .restart local v4    # "client":Ltas/internal/ipc/server/ServerManager$ClientHolder;
    if-eqz v4, :cond_35

    .line 806
    invoke-static {v4}, Ltas/internal/ipc/server/ServerManager$ClientHolder;->-get0(Ltas/internal/ipc/server/ServerManager$ClientHolder;)Ltas/internal/ipc/server/ServerManager$ClientHandler;

    move-result-object v21

    move-object/from16 v0, v21

    iget-object v0, v0, Ltas/internal/ipc/server/ServerManager$ClientHandler;->mSenders:Ljava/util/List;

    move-object/from16 v18, v0

    .line 807
    .local v18, "senders":Ljava/util/List;, "Ljava/util/List<Ltas/internal/ipc/server/ServerManager$SenderHolder;>;"
    invoke-interface/range {v18 .. v18}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v20

    .restart local v20    # "sh$iterator":Ljava/util/Iterator;
    :cond_36
    :goto_a
    invoke-interface/range {v20 .. v20}, Ljava/util/Iterator;->hasNext()Z

    move-result v21

    if-eqz v21, :cond_35

    invoke-interface/range {v20 .. v20}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v19

    check-cast v19, Ltas/internal/ipc/server/ServerManager$SenderHolder;

    .line 808
    .restart local v19    # "sh":Ltas/internal/ipc/server/ServerManager$SenderHolder;
    if-eqz v19, :cond_36

    invoke-static/range {v19 .. v19}, Ltas/internal/ipc/server/ServerManager$SenderHolder;->-get3(Ltas/internal/ipc/server/ServerManager$SenderHolder;)Ljava/util/List;

    move-result-object v21

    iget-object v0, v15, Ltas/internal/ipc/server/RemoteReceiver;->name:Ljava/lang/String;

    move-object/from16 v22, v0

    invoke-interface/range {v21 .. v22}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v21

    if-eqz v21, :cond_36

    .line 810
    const/4 v8, 0x0

    .line 812
    .local v8, "holder":Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;
    invoke-static/range {v19 .. v19}, Ltas/internal/ipc/server/ServerManager$SenderHolder;->-get1(Ltas/internal/ipc/server/ServerManager$SenderHolder;)Ltas/internal/ipc/server/RemoteSender;

    move-result-object v21

    move-object/from16 v0, v21

    invoke-static {v12, v0}, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->-wrap0(Ltas/internal/ipc/server/ServerManager$ReceiverHolder;Ltas/internal/ipc/server/RemoteSender;)Z

    move-result v21

    if-nez v21, :cond_37

    .line 813
    invoke-static/range {v19 .. v19}, Ltas/internal/ipc/server/ServerManager$SenderHolder;->-get1(Ltas/internal/ipc/server/ServerManager$SenderHolder;)Ltas/internal/ipc/server/RemoteSender;

    move-result-object v21

    move-object/from16 v0, v21

    invoke-static {v12, v0}, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->-wrap4(Ltas/internal/ipc/server/ServerManager$ReceiverHolder;Ltas/internal/ipc/server/RemoteSender;)V

    .line 815
    new-instance v8, Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;

    .end local v8    # "holder":Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;
    const/16 v21, 0x0

    move-object/from16 v0, v19

    move-object/from16 v1, v21

    invoke-direct {v8, v0, v12, v1}, Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;-><init>(Ltas/internal/ipc/server/ServerManager$SenderHolder;Ltas/internal/ipc/server/ServerManager$ReceiverHolder;Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;)V

    .line 817
    .local v8, "holder":Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;
    const/16 v21, 0x12

    move-object/from16 v0, p0

    move/from16 v1, v21

    invoke-direct {v0, v1, v8}, Ltas/internal/ipc/server/ServerManager$ClientHandler;->schedule(ILtas/internal/ipc/server/ServerManager$ClientHandler$Holder;)V

    .line 820
    .end local v8    # "holder":Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;
    :cond_37
    invoke-static {v12}, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->-get0(Ltas/internal/ipc/server/ServerManager$ReceiverHolder;)Ltas/internal/ipc/server/RemoteReceiver;

    move-result-object v21

    move-object/from16 v0, v19

    move-object/from16 v1, v21

    invoke-static {v0, v1}, Ltas/internal/ipc/server/ServerManager$SenderHolder;->-wrap0(Ltas/internal/ipc/server/ServerManager$SenderHolder;Ltas/internal/ipc/server/RemoteReceiver;)Z

    move-result v21

    if-nez v21, :cond_36

    .line 821
    invoke-static {v12}, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->-get0(Ltas/internal/ipc/server/ServerManager$ReceiverHolder;)Ltas/internal/ipc/server/RemoteReceiver;

    move-result-object v21

    move-object/from16 v0, v19

    move-object/from16 v1, v21

    invoke-static {v0, v1}, Ltas/internal/ipc/server/ServerManager$SenderHolder;->-wrap4(Ltas/internal/ipc/server/ServerManager$SenderHolder;Ltas/internal/ipc/server/RemoteReceiver;)V

    .line 822
    if-nez v8, :cond_38

    .line 823
    new-instance v8, Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;

    const/16 v21, 0x0

    move-object/from16 v0, v19

    move-object/from16 v1, v21

    invoke-direct {v8, v0, v12, v1}, Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;-><init>(Ltas/internal/ipc/server/ServerManager$SenderHolder;Ltas/internal/ipc/server/ServerManager$ReceiverHolder;Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;)V

    .line 825
    :cond_38
    invoke-static {v4}, Ltas/internal/ipc/server/ServerManager$ClientHolder;->-get0(Ltas/internal/ipc/server/ServerManager$ClientHolder;)Ltas/internal/ipc/server/ServerManager$ClientHandler;

    move-result-object v21

    .line 826
    const/16 v22, 0x10

    .line 825
    move-object/from16 v0, v21

    move/from16 v1, v22

    invoke-direct {v0, v1, v8}, Ltas/internal/ipc/server/ServerManager$ClientHandler;->schedule(ILtas/internal/ipc/server/ServerManager$ClientHandler$Holder;)V
    :try_end_12
    .catchall {:try_start_12 .. :try_end_12} :catchall_c

    goto :goto_a

    .line 799
    .end local v4    # "client":Ltas/internal/ipc/server/ServerManager$ClientHolder;
    .end local v5    # "client$iterator":Ljava/util/Iterator;
    .end local v6    # "clients":Ljava/util/Collection;, "Ljava/util/Collection<Ltas/internal/ipc/server/ServerManager$ClientHolder;>;"
    .end local v18    # "senders":Ljava/util/List;, "Ljava/util/List<Ltas/internal/ipc/server/ServerManager$SenderHolder;>;"
    .end local v19    # "sh":Ltas/internal/ipc/server/ServerManager$SenderHolder;
    .end local v20    # "sh$iterator":Ljava/util/Iterator;
    :catchall_c
    move-exception v21

    monitor-exit v9

    throw v21

    .restart local v5    # "client$iterator":Ljava/util/Iterator;
    .restart local v6    # "clients":Ljava/util/Collection;, "Ljava/util/Collection<Ltas/internal/ipc/server/ServerManager$ClientHolder;>;"
    :cond_39
    monitor-exit v9

    .line 832
    invoke-virtual {v15}, Ltas/internal/ipc/server/RemoteReceiver;->recycle()V

    goto/16 :goto_0

    .line 836
    .end local v5    # "client$iterator":Ljava/util/Iterator;
    .end local v6    # "clients":Ljava/util/Collection;, "Ljava/util/Collection<Ltas/internal/ipc/server/ServerManager$ClientHolder;>;"
    .end local v12    # "rh":Ltas/internal/ipc/server/ServerManager$ReceiverHolder;
    .end local v15    # "rr":Ltas/internal/ipc/server/RemoteReceiver;
    :pswitch_d
    move-object/from16 v0, p1

    iget-object v15, v0, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v15, Ltas/internal/ipc/server/RemoteReceiver;

    .line 837
    .restart local v15    # "rr":Ltas/internal/ipc/server/RemoteReceiver;
    move-object/from16 v0, p0

    invoke-direct {v0, v15}, Ltas/internal/ipc/server/ServerManager$ClientHandler;->findReceiver(Ltas/internal/ipc/server/RemoteReceiver;)Ltas/internal/ipc/server/ServerManager$ReceiverHolder;

    move-result-object v12

    .line 838
    .restart local v12    # "rh":Ltas/internal/ipc/server/ServerManager$ReceiverHolder;
    if-nez v12, :cond_3a

    .line 839
    const-string/jumbo v21, "TasIPC<ServerManager>"

    new-instance v22, Ljava/lang/StringBuilder;

    invoke-direct/range {v22 .. v22}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v23, "r("

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    iget-object v0, v15, Ltas/internal/ipc/server/RemoteReceiver;->name:Ljava/lang/String;

    move-object/from16 v23, v0

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    const-string/jumbo v23, ") not found. + msg.what"

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    invoke-virtual/range {v22 .. v22}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v22

    invoke-static/range {v21 .. v22}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 840
    invoke-virtual {v15}, Ltas/internal/ipc/server/RemoteReceiver;->recycle()V

    .line 841
    invoke-virtual {v9}, Ltas/internal/ipc/server/ServerManager;->dump()V

    goto/16 :goto_0

    .line 846
    :cond_3a
    const-string/jumbo v21, "TasIPC<ServerManager>"

    new-instance v22, Ljava/lang/StringBuilder;

    invoke-direct/range {v22 .. v22}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v23, "r("

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    iget-object v0, v15, Ltas/internal/ipc/server/RemoteReceiver;->name:Ljava/lang/String;

    move-object/from16 v23, v0

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    const-string/jumbo v23, ") unwatches nobody"

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    invoke-virtual/range {v22 .. v22}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v22

    invoke-static/range {v21 .. v22}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 849
    monitor-enter v9

    .line 850
    const/16 v21, 0x0

    :try_start_13
    move/from16 v0, v21

    invoke-static {v12, v0}, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->-set0(Ltas/internal/ipc/server/ServerManager$ReceiverHolder;Z)Z

    .line 851
    invoke-static {v9}, Ltas/internal/ipc/server/ServerManager;->-get0(Ltas/internal/ipc/server/ServerManager;)Landroid/util/ArrayMap;

    move-result-object v21

    invoke-virtual/range {v21 .. v21}, Landroid/util/ArrayMap;->values()Ljava/util/Collection;

    move-result-object v6

    .line 852
    .restart local v6    # "clients":Ljava/util/Collection;, "Ljava/util/Collection<Ltas/internal/ipc/server/ServerManager$ClientHolder;>;"
    invoke-interface {v6}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v5

    .restart local v5    # "client$iterator":Ljava/util/Iterator;
    :cond_3b
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v21

    if-eqz v21, :cond_3f

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ltas/internal/ipc/server/ServerManager$ClientHolder;

    .line 853
    .restart local v4    # "client":Ltas/internal/ipc/server/ServerManager$ClientHolder;
    if-eqz v4, :cond_3b

    .line 856
    invoke-static {v4}, Ltas/internal/ipc/server/ServerManager$ClientHolder;->-get0(Ltas/internal/ipc/server/ServerManager$ClientHolder;)Ltas/internal/ipc/server/ServerManager$ClientHandler;

    move-result-object v21

    move-object/from16 v0, v21

    iget-object v0, v0, Ltas/internal/ipc/server/ServerManager$ClientHandler;->mSenders:Ljava/util/List;

    move-object/from16 v18, v0

    .line 857
    .restart local v18    # "senders":Ljava/util/List;, "Ljava/util/List<Ltas/internal/ipc/server/ServerManager$SenderHolder;>;"
    invoke-interface/range {v18 .. v18}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v20

    .restart local v20    # "sh$iterator":Ljava/util/Iterator;
    :cond_3c
    :goto_b
    invoke-interface/range {v20 .. v20}, Ljava/util/Iterator;->hasNext()Z

    move-result v21

    if-eqz v21, :cond_3b

    invoke-interface/range {v20 .. v20}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v19

    check-cast v19, Ltas/internal/ipc/server/ServerManager$SenderHolder;

    .line 858
    .restart local v19    # "sh":Ltas/internal/ipc/server/ServerManager$SenderHolder;
    if-eqz v19, :cond_3c

    invoke-static/range {v19 .. v19}, Ltas/internal/ipc/server/ServerManager$SenderHolder;->-get3(Ltas/internal/ipc/server/ServerManager$SenderHolder;)Ljava/util/List;

    move-result-object v21

    iget-object v0, v15, Ltas/internal/ipc/server/RemoteReceiver;->name:Ljava/lang/String;

    move-object/from16 v22, v0

    invoke-interface/range {v21 .. v22}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v21

    if-eqz v21, :cond_3c

    .line 859
    invoke-static/range {v19 .. v19}, Ltas/internal/ipc/server/ServerManager$SenderHolder;->-get3(Ltas/internal/ipc/server/ServerManager$SenderHolder;)Ljava/util/List;

    move-result-object v21

    invoke-static {v12}, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->-get0(Ltas/internal/ipc/server/ServerManager$ReceiverHolder;)Ltas/internal/ipc/server/RemoteReceiver;

    move-result-object v22

    move-object/from16 v0, v22

    iget-object v0, v0, Ltas/internal/ipc/server/RemoteReceiver;->name:Ljava/lang/String;

    move-object/from16 v22, v0

    invoke-interface/range {v21 .. v22}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v21

    if-nez v21, :cond_3c

    .line 861
    const/4 v8, 0x0

    .line 863
    .local v8, "holder":Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;
    invoke-static/range {v19 .. v19}, Ltas/internal/ipc/server/ServerManager$SenderHolder;->-get1(Ltas/internal/ipc/server/ServerManager$SenderHolder;)Ltas/internal/ipc/server/RemoteSender;

    move-result-object v21

    move-object/from16 v0, v21

    invoke-static {v12, v0}, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->-wrap0(Ltas/internal/ipc/server/ServerManager$ReceiverHolder;Ltas/internal/ipc/server/RemoteSender;)Z

    move-result v21

    if-eqz v21, :cond_3d

    .line 864
    invoke-static/range {v19 .. v19}, Ltas/internal/ipc/server/ServerManager$SenderHolder;->-get1(Ltas/internal/ipc/server/ServerManager$SenderHolder;)Ltas/internal/ipc/server/RemoteSender;

    move-result-object v21

    move-object/from16 v0, v21

    invoke-static {v12, v0}, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->-wrap2(Ltas/internal/ipc/server/ServerManager$ReceiverHolder;Ltas/internal/ipc/server/RemoteSender;)Z

    .line 866
    new-instance v8, Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;

    .end local v8    # "holder":Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;
    const/16 v21, 0x0

    move-object/from16 v0, v19

    move-object/from16 v1, v21

    invoke-direct {v8, v0, v12, v1}, Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;-><init>(Ltas/internal/ipc/server/ServerManager$SenderHolder;Ltas/internal/ipc/server/ServerManager$ReceiverHolder;Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;)V

    .line 868
    .local v8, "holder":Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;
    const/16 v21, 0x13

    move-object/from16 v0, p0

    move/from16 v1, v21

    invoke-direct {v0, v1, v8}, Ltas/internal/ipc/server/ServerManager$ClientHandler;->schedule(ILtas/internal/ipc/server/ServerManager$ClientHandler$Holder;)V

    .line 871
    .end local v8    # "holder":Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;
    :cond_3d
    invoke-static {v12}, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->-get0(Ltas/internal/ipc/server/ServerManager$ReceiverHolder;)Ltas/internal/ipc/server/RemoteReceiver;

    move-result-object v21

    move-object/from16 v0, v19

    move-object/from16 v1, v21

    invoke-static {v0, v1}, Ltas/internal/ipc/server/ServerManager$SenderHolder;->-wrap0(Ltas/internal/ipc/server/ServerManager$SenderHolder;Ltas/internal/ipc/server/RemoteReceiver;)Z

    move-result v21

    if-eqz v21, :cond_3c

    .line 872
    invoke-static {v12}, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->-get0(Ltas/internal/ipc/server/ServerManager$ReceiverHolder;)Ltas/internal/ipc/server/RemoteReceiver;

    move-result-object v21

    move-object/from16 v0, v19

    move-object/from16 v1, v21

    invoke-static {v0, v1}, Ltas/internal/ipc/server/ServerManager$SenderHolder;->-wrap2(Ltas/internal/ipc/server/ServerManager$SenderHolder;Ltas/internal/ipc/server/RemoteReceiver;)Z

    .line 873
    if-nez v8, :cond_3e

    .line 874
    new-instance v8, Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;

    const/16 v21, 0x0

    move-object/from16 v0, v19

    move-object/from16 v1, v21

    invoke-direct {v8, v0, v12, v1}, Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;-><init>(Ltas/internal/ipc/server/ServerManager$SenderHolder;Ltas/internal/ipc/server/ServerManager$ReceiverHolder;Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;)V

    .line 876
    :cond_3e
    invoke-static {v4}, Ltas/internal/ipc/server/ServerManager$ClientHolder;->-get0(Ltas/internal/ipc/server/ServerManager$ClientHolder;)Ltas/internal/ipc/server/ServerManager$ClientHandler;

    move-result-object v21

    .line 877
    const/16 v22, 0x11

    .line 876
    move-object/from16 v0, v21

    move/from16 v1, v22

    invoke-direct {v0, v1, v8}, Ltas/internal/ipc/server/ServerManager$ClientHandler;->schedule(ILtas/internal/ipc/server/ServerManager$ClientHandler$Holder;)V
    :try_end_13
    .catchall {:try_start_13 .. :try_end_13} :catchall_d

    goto/16 :goto_b

    .line 849
    .end local v4    # "client":Ltas/internal/ipc/server/ServerManager$ClientHolder;
    .end local v5    # "client$iterator":Ljava/util/Iterator;
    .end local v6    # "clients":Ljava/util/Collection;, "Ljava/util/Collection<Ltas/internal/ipc/server/ServerManager$ClientHolder;>;"
    .end local v18    # "senders":Ljava/util/List;, "Ljava/util/List<Ltas/internal/ipc/server/ServerManager$SenderHolder;>;"
    .end local v19    # "sh":Ltas/internal/ipc/server/ServerManager$SenderHolder;
    .end local v20    # "sh$iterator":Ljava/util/Iterator;
    :catchall_d
    move-exception v21

    monitor-exit v9

    throw v21

    .restart local v5    # "client$iterator":Ljava/util/Iterator;
    .restart local v6    # "clients":Ljava/util/Collection;, "Ljava/util/Collection<Ltas/internal/ipc/server/ServerManager$ClientHolder;>;"
    :cond_3f
    monitor-exit v9

    .line 883
    invoke-virtual {v15}, Ltas/internal/ipc/server/RemoteReceiver;->recycle()V

    goto/16 :goto_0

    .line 887
    .end local v5    # "client$iterator":Ljava/util/Iterator;
    .end local v6    # "clients":Ljava/util/Collection;, "Ljava/util/Collection<Ltas/internal/ipc/server/ServerManager$ClientHolder;>;"
    .end local v12    # "rh":Ltas/internal/ipc/server/ServerManager$ReceiverHolder;
    .end local v15    # "rr":Ltas/internal/ipc/server/RemoteReceiver;
    :pswitch_e
    move-object/from16 v0, p0

    iget-object v0, v0, Ltas/internal/ipc/server/ServerManager$ClientHandler;->mCallback:Ltas/internal/ipc/server/IServerCallback;

    move-object/from16 v21, v0

    if-eqz v21, :cond_40

    .line 888
    move-object/from16 v0, p0

    iget-object v0, v0, Ltas/internal/ipc/server/ServerManager$ClientHandler;->mCallback:Ltas/internal/ipc/server/IServerCallback;

    move-object/from16 v21, v0

    invoke-interface/range {v21 .. v21}, Ltas/internal/ipc/server/IServerCallback;->asBinder()Landroid/os/IBinder;

    move-result-object v21

    move-object/from16 v0, p0

    move-object/from16 v1, v21

    invoke-direct {v0, v1}, Ltas/internal/ipc/server/ServerManager$ClientHandler;->unlinkToDeath(Landroid/os/IBinder;)V

    .line 891
    :cond_40
    move-object/from16 v0, p1

    iget-object v0, v0, Landroid/os/Message;->obj:Ljava/lang/Object;

    move-object/from16 v21, v0

    check-cast v21, Ltas/internal/ipc/server/IServerCallback;

    move-object/from16 v0, v21

    move-object/from16 v1, p0

    iput-object v0, v1, Ltas/internal/ipc/server/ServerManager$ClientHandler;->mCallback:Ltas/internal/ipc/server/IServerCallback;

    .line 892
    move-object/from16 v0, p0

    iget-object v0, v0, Ltas/internal/ipc/server/ServerManager$ClientHandler;->mCallback:Ltas/internal/ipc/server/IServerCallback;

    move-object/from16 v21, v0

    if-nez v21, :cond_41

    .line 893
    const-string/jumbo v21, "TasIPC<ServerManager>"

    new-instance v22, Ljava/lang/StringBuilder;

    invoke-direct/range {v22 .. v22}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v23, "client:"

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    move-object/from16 v0, p0

    iget v0, v0, Ltas/internal/ipc/server/ServerManager$ClientHandler;->pid:I

    move/from16 v23, v0

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v22

    const-string/jumbo v23, " callback removed."

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    invoke-virtual/range {v22 .. v22}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v22

    invoke-static/range {v21 .. v22}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    goto/16 :goto_0

    .line 897
    :cond_41
    move-object/from16 v0, p0

    iget-object v0, v0, Ltas/internal/ipc/server/ServerManager$ClientHandler;->mCallback:Ltas/internal/ipc/server/IServerCallback;

    move-object/from16 v21, v0

    invoke-interface/range {v21 .. v21}, Ltas/internal/ipc/server/IServerCallback;->asBinder()Landroid/os/IBinder;

    move-result-object v21

    move-object/from16 v0, p0

    move-object/from16 v1, v21

    invoke-direct {v0, v1}, Ltas/internal/ipc/server/ServerManager$ClientHandler;->linkToDeath(Landroid/os/IBinder;)V

    .line 899
    const-string/jumbo v21, "TasIPC<ServerManager>"

    new-instance v22, Ljava/lang/StringBuilder;

    invoke-direct/range {v22 .. v22}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v23, "client:"

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    move-object/from16 v0, p0

    iget v0, v0, Ltas/internal/ipc/server/ServerManager$ClientHandler;->pid:I

    move/from16 v23, v0

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v22

    const-string/jumbo v23, " callback is set."

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    invoke-virtual/range {v22 .. v22}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v22

    invoke-static/range {v21 .. v22}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    goto/16 :goto_0

    .line 904
    :pswitch_f
    move-object/from16 v0, p1

    iget-object v14, v0, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v14, Ltas/internal/ipc/server/RemoteMessage;

    .line 905
    .local v14, "rmsg":Ltas/internal/ipc/server/RemoteMessage;
    move-object/from16 v0, p0

    iget-object v0, v0, Ltas/internal/ipc/server/ServerManager$ClientHandler;->mCallback:Ltas/internal/ipc/server/IServerCallback;

    move-object/from16 v21, v0

    if-nez v21, :cond_42

    .line 906
    invoke-virtual {v14}, Ltas/internal/ipc/server/RemoteMessage;->recycle()V

    goto/16 :goto_0

    .line 911
    :cond_42
    :try_start_14
    move-object/from16 v0, p0

    iget-object v0, v0, Ltas/internal/ipc/server/ServerManager$ClientHandler;->mCallback:Ltas/internal/ipc/server/IServerCallback;

    move-object/from16 v21, v0

    move-object/from16 v0, v21

    invoke-interface {v0, v14}, Ltas/internal/ipc/server/IServerCallback;->transmit(Ltas/internal/ipc/server/RemoteMessage;)V
    :try_end_14
    .catch Landroid/os/RemoteException; {:try_start_14 .. :try_end_14} :catch_0
    .catchall {:try_start_14 .. :try_end_14} :catchall_e

    .line 915
    invoke-virtual {v14}, Ltas/internal/ipc/server/RemoteMessage;->recycle()V

    goto/16 :goto_0

    .line 912
    :catch_0
    move-exception v7

    .line 913
    .local v7, "e":Landroid/os/RemoteException;
    :try_start_15
    invoke-virtual {v7}, Landroid/os/RemoteException;->printStackTrace()V
    :try_end_15
    .catchall {:try_start_15 .. :try_end_15} :catchall_e

    .line 915
    invoke-virtual {v14}, Ltas/internal/ipc/server/RemoteMessage;->recycle()V

    goto/16 :goto_0

    .line 914
    .end local v7    # "e":Landroid/os/RemoteException;
    :catchall_e
    move-exception v21

    .line 915
    invoke-virtual {v14}, Ltas/internal/ipc/server/RemoteMessage;->recycle()V

    .line 914
    throw v21

    .line 920
    .end local v14    # "rmsg":Ltas/internal/ipc/server/RemoteMessage;
    :pswitch_10
    move-object/from16 v0, p1

    iget-object v8, v0, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v8, Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;

    .line 921
    .restart local v8    # "holder":Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;
    move-object/from16 v0, p0

    iget-object v0, v0, Ltas/internal/ipc/server/ServerManager$ClientHandler;->mCallback:Ltas/internal/ipc/server/IServerCallback;

    move-object/from16 v21, v0

    if-eqz v21, :cond_1

    .line 922
    invoke-static {v8}, Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;->-get1(Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;)Ltas/internal/ipc/server/ServerManager$SenderHolder;

    move-result-object v21

    invoke-static/range {v21 .. v21}, Ltas/internal/ipc/server/ServerManager$SenderHolder;->-get1(Ltas/internal/ipc/server/ServerManager$SenderHolder;)Ltas/internal/ipc/server/RemoteSender;

    move-result-object v21

    invoke-static/range {v21 .. v21}, Ltas/internal/ipc/server/RemoteSender;->obtain(Ltas/internal/ipc/server/RemoteSender;)Ltas/internal/ipc/server/RemoteSender;

    move-result-object v17

    .line 923
    .local v17, "s":Ltas/internal/ipc/server/RemoteSender;
    invoke-static {v8}, Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;->-get0(Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;)Ltas/internal/ipc/server/ServerManager$ReceiverHolder;

    move-result-object v21

    invoke-static/range {v21 .. v21}, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->-get0(Ltas/internal/ipc/server/ServerManager$ReceiverHolder;)Ltas/internal/ipc/server/RemoteReceiver;

    move-result-object v21

    invoke-static/range {v21 .. v21}, Ltas/internal/ipc/server/RemoteReceiver;->obtain(Ltas/internal/ipc/server/RemoteReceiver;)Ltas/internal/ipc/server/RemoteReceiver;

    move-result-object v10

    .line 926
    .local v10, "r":Ltas/internal/ipc/server/RemoteReceiver;
    :try_start_16
    move-object/from16 v0, p0

    iget-object v0, v0, Ltas/internal/ipc/server/ServerManager$ClientHandler;->mCallback:Ltas/internal/ipc/server/IServerCallback;

    move-object/from16 v21, v0

    move-object/from16 v0, v21

    move-object/from16 v1, v17

    invoke-interface {v0, v1, v10}, Ltas/internal/ipc/server/IServerCallback;->onReceiverOnline(Ltas/internal/ipc/server/RemoteSender;Ltas/internal/ipc/server/RemoteReceiver;)V
    :try_end_16
    .catch Landroid/os/RemoteException; {:try_start_16 .. :try_end_16} :catch_1
    .catchall {:try_start_16 .. :try_end_16} :catchall_f

    .line 931
    invoke-virtual/range {v17 .. v17}, Ltas/internal/ipc/server/RemoteSender;->recycle()V

    .line 932
    invoke-virtual {v10}, Ltas/internal/ipc/server/RemoteReceiver;->recycle()V

    goto/16 :goto_0

    .line 927
    :catch_1
    move-exception v7

    .line 928
    .restart local v7    # "e":Landroid/os/RemoteException;
    :try_start_17
    invoke-virtual {v7}, Landroid/os/RemoteException;->printStackTrace()V

    .line 929
    invoke-static {v8}, Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;->-get1(Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;)Ltas/internal/ipc/server/ServerManager$SenderHolder;

    move-result-object v21

    invoke-static {v8}, Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;->-get0(Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;)Ltas/internal/ipc/server/ServerManager$ReceiverHolder;

    move-result-object v22

    invoke-static/range {v22 .. v22}, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->-get0(Ltas/internal/ipc/server/ServerManager$ReceiverHolder;)Ltas/internal/ipc/server/RemoteReceiver;

    move-result-object v22

    invoke-static/range {v21 .. v22}, Ltas/internal/ipc/server/ServerManager$SenderHolder;->-wrap2(Ltas/internal/ipc/server/ServerManager$SenderHolder;Ltas/internal/ipc/server/RemoteReceiver;)Z
    :try_end_17
    .catchall {:try_start_17 .. :try_end_17} :catchall_f

    .line 931
    invoke-virtual/range {v17 .. v17}, Ltas/internal/ipc/server/RemoteSender;->recycle()V

    .line 932
    invoke-virtual {v10}, Ltas/internal/ipc/server/RemoteReceiver;->recycle()V

    goto/16 :goto_0

    .line 930
    .end local v7    # "e":Landroid/os/RemoteException;
    :catchall_f
    move-exception v21

    .line 931
    invoke-virtual/range {v17 .. v17}, Ltas/internal/ipc/server/RemoteSender;->recycle()V

    .line 932
    invoke-virtual {v10}, Ltas/internal/ipc/server/RemoteReceiver;->recycle()V

    .line 930
    throw v21

    .line 938
    .end local v8    # "holder":Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;
    .end local v10    # "r":Ltas/internal/ipc/server/RemoteReceiver;
    .end local v17    # "s":Ltas/internal/ipc/server/RemoteSender;
    :pswitch_11
    move-object/from16 v0, p1

    iget-object v8, v0, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v8, Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;

    .line 939
    .restart local v8    # "holder":Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;
    move-object/from16 v0, p0

    iget-object v0, v0, Ltas/internal/ipc/server/ServerManager$ClientHandler;->mCallback:Ltas/internal/ipc/server/IServerCallback;

    move-object/from16 v21, v0

    if-eqz v21, :cond_1

    .line 940
    invoke-static {v8}, Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;->-get1(Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;)Ltas/internal/ipc/server/ServerManager$SenderHolder;

    move-result-object v21

    invoke-static/range {v21 .. v21}, Ltas/internal/ipc/server/ServerManager$SenderHolder;->-get1(Ltas/internal/ipc/server/ServerManager$SenderHolder;)Ltas/internal/ipc/server/RemoteSender;

    move-result-object v21

    invoke-static/range {v21 .. v21}, Ltas/internal/ipc/server/RemoteSender;->obtain(Ltas/internal/ipc/server/RemoteSender;)Ltas/internal/ipc/server/RemoteSender;

    move-result-object v17

    .line 941
    .restart local v17    # "s":Ltas/internal/ipc/server/RemoteSender;
    invoke-static {v8}, Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;->-get0(Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;)Ltas/internal/ipc/server/ServerManager$ReceiverHolder;

    move-result-object v21

    invoke-static/range {v21 .. v21}, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->-get0(Ltas/internal/ipc/server/ServerManager$ReceiverHolder;)Ltas/internal/ipc/server/RemoteReceiver;

    move-result-object v21

    invoke-static/range {v21 .. v21}, Ltas/internal/ipc/server/RemoteReceiver;->obtain(Ltas/internal/ipc/server/RemoteReceiver;)Ltas/internal/ipc/server/RemoteReceiver;

    move-result-object v10

    .line 944
    .restart local v10    # "r":Ltas/internal/ipc/server/RemoteReceiver;
    :try_start_18
    move-object/from16 v0, p0

    iget-object v0, v0, Ltas/internal/ipc/server/ServerManager$ClientHandler;->mCallback:Ltas/internal/ipc/server/IServerCallback;

    move-object/from16 v21, v0

    move-object/from16 v0, v21

    move-object/from16 v1, v17

    invoke-interface {v0, v1, v10}, Ltas/internal/ipc/server/IServerCallback;->onReceiverOffline(Ltas/internal/ipc/server/RemoteSender;Ltas/internal/ipc/server/RemoteReceiver;)V
    :try_end_18
    .catch Landroid/os/RemoteException; {:try_start_18 .. :try_end_18} :catch_2
    .catchall {:try_start_18 .. :try_end_18} :catchall_10

    .line 948
    invoke-virtual/range {v17 .. v17}, Ltas/internal/ipc/server/RemoteSender;->recycle()V

    .line 949
    invoke-virtual {v10}, Ltas/internal/ipc/server/RemoteReceiver;->recycle()V

    goto/16 :goto_0

    .line 945
    :catch_2
    move-exception v7

    .line 946
    .restart local v7    # "e":Landroid/os/RemoteException;
    :try_start_19
    invoke-virtual {v7}, Landroid/os/RemoteException;->printStackTrace()V
    :try_end_19
    .catchall {:try_start_19 .. :try_end_19} :catchall_10

    .line 948
    invoke-virtual/range {v17 .. v17}, Ltas/internal/ipc/server/RemoteSender;->recycle()V

    .line 949
    invoke-virtual {v10}, Ltas/internal/ipc/server/RemoteReceiver;->recycle()V

    goto/16 :goto_0

    .line 947
    .end local v7    # "e":Landroid/os/RemoteException;
    :catchall_10
    move-exception v21

    .line 948
    invoke-virtual/range {v17 .. v17}, Ltas/internal/ipc/server/RemoteSender;->recycle()V

    .line 949
    invoke-virtual {v10}, Ltas/internal/ipc/server/RemoteReceiver;->recycle()V

    .line 947
    throw v21

    .line 955
    .end local v8    # "holder":Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;
    .end local v10    # "r":Ltas/internal/ipc/server/RemoteReceiver;
    .end local v17    # "s":Ltas/internal/ipc/server/RemoteSender;
    :pswitch_12
    move-object/from16 v0, p1

    iget-object v8, v0, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v8, Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;

    .line 956
    .restart local v8    # "holder":Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;
    move-object/from16 v0, p0

    iget-object v0, v0, Ltas/internal/ipc/server/ServerManager$ClientHandler;->mCallback:Ltas/internal/ipc/server/IServerCallback;

    move-object/from16 v21, v0

    if-eqz v21, :cond_1

    .line 957
    invoke-static {v8}, Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;->-get1(Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;)Ltas/internal/ipc/server/ServerManager$SenderHolder;

    move-result-object v21

    invoke-static/range {v21 .. v21}, Ltas/internal/ipc/server/ServerManager$SenderHolder;->-get1(Ltas/internal/ipc/server/ServerManager$SenderHolder;)Ltas/internal/ipc/server/RemoteSender;

    move-result-object v21

    invoke-static/range {v21 .. v21}, Ltas/internal/ipc/server/RemoteSender;->obtain(Ltas/internal/ipc/server/RemoteSender;)Ltas/internal/ipc/server/RemoteSender;

    move-result-object v17

    .line 958
    .restart local v17    # "s":Ltas/internal/ipc/server/RemoteSender;
    invoke-static {v8}, Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;->-get0(Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;)Ltas/internal/ipc/server/ServerManager$ReceiverHolder;

    move-result-object v21

    invoke-static/range {v21 .. v21}, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->-get0(Ltas/internal/ipc/server/ServerManager$ReceiverHolder;)Ltas/internal/ipc/server/RemoteReceiver;

    move-result-object v21

    invoke-static/range {v21 .. v21}, Ltas/internal/ipc/server/RemoteReceiver;->obtain(Ltas/internal/ipc/server/RemoteReceiver;)Ltas/internal/ipc/server/RemoteReceiver;

    move-result-object v10

    .line 961
    .restart local v10    # "r":Ltas/internal/ipc/server/RemoteReceiver;
    :try_start_1a
    move-object/from16 v0, p0

    iget-object v0, v0, Ltas/internal/ipc/server/ServerManager$ClientHandler;->mCallback:Ltas/internal/ipc/server/IServerCallback;

    move-object/from16 v21, v0

    move-object/from16 v0, v21

    move-object/from16 v1, v17

    invoke-interface {v0, v1, v10}, Ltas/internal/ipc/server/IServerCallback;->onReceiverUpdate(Ltas/internal/ipc/server/RemoteSender;Ltas/internal/ipc/server/RemoteReceiver;)V
    :try_end_1a
    .catch Landroid/os/RemoteException; {:try_start_1a .. :try_end_1a} :catch_3
    .catchall {:try_start_1a .. :try_end_1a} :catchall_11

    .line 965
    invoke-virtual/range {v17 .. v17}, Ltas/internal/ipc/server/RemoteSender;->recycle()V

    .line 966
    invoke-virtual {v10}, Ltas/internal/ipc/server/RemoteReceiver;->recycle()V

    goto/16 :goto_0

    .line 962
    :catch_3
    move-exception v7

    .line 963
    .restart local v7    # "e":Landroid/os/RemoteException;
    :try_start_1b
    invoke-virtual {v7}, Landroid/os/RemoteException;->printStackTrace()V
    :try_end_1b
    .catchall {:try_start_1b .. :try_end_1b} :catchall_11

    .line 965
    invoke-virtual/range {v17 .. v17}, Ltas/internal/ipc/server/RemoteSender;->recycle()V

    .line 966
    invoke-virtual {v10}, Ltas/internal/ipc/server/RemoteReceiver;->recycle()V

    goto/16 :goto_0

    .line 964
    .end local v7    # "e":Landroid/os/RemoteException;
    :catchall_11
    move-exception v21

    .line 965
    invoke-virtual/range {v17 .. v17}, Ltas/internal/ipc/server/RemoteSender;->recycle()V

    .line 966
    invoke-virtual {v10}, Ltas/internal/ipc/server/RemoteReceiver;->recycle()V

    .line 964
    throw v21

    .line 972
    .end local v8    # "holder":Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;
    .end local v10    # "r":Ltas/internal/ipc/server/RemoteReceiver;
    .end local v17    # "s":Ltas/internal/ipc/server/RemoteSender;
    :pswitch_13
    move-object/from16 v0, p1

    iget-object v8, v0, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v8, Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;

    .line 973
    .restart local v8    # "holder":Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;
    move-object/from16 v0, p0

    iget-object v0, v0, Ltas/internal/ipc/server/ServerManager$ClientHandler;->mCallback:Ltas/internal/ipc/server/IServerCallback;

    move-object/from16 v21, v0

    if-eqz v21, :cond_1

    .line 974
    invoke-static {v8}, Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;->-get1(Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;)Ltas/internal/ipc/server/ServerManager$SenderHolder;

    move-result-object v21

    invoke-static/range {v21 .. v21}, Ltas/internal/ipc/server/ServerManager$SenderHolder;->-get1(Ltas/internal/ipc/server/ServerManager$SenderHolder;)Ltas/internal/ipc/server/RemoteSender;

    move-result-object v21

    invoke-static/range {v21 .. v21}, Ltas/internal/ipc/server/RemoteSender;->obtain(Ltas/internal/ipc/server/RemoteSender;)Ltas/internal/ipc/server/RemoteSender;

    move-result-object v17

    .line 975
    .restart local v17    # "s":Ltas/internal/ipc/server/RemoteSender;
    invoke-static {v8}, Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;->-get0(Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;)Ltas/internal/ipc/server/ServerManager$ReceiverHolder;

    move-result-object v21

    invoke-static/range {v21 .. v21}, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->-get0(Ltas/internal/ipc/server/ServerManager$ReceiverHolder;)Ltas/internal/ipc/server/RemoteReceiver;

    move-result-object v21

    invoke-static/range {v21 .. v21}, Ltas/internal/ipc/server/RemoteReceiver;->obtain(Ltas/internal/ipc/server/RemoteReceiver;)Ltas/internal/ipc/server/RemoteReceiver;

    move-result-object v10

    .line 978
    .restart local v10    # "r":Ltas/internal/ipc/server/RemoteReceiver;
    :try_start_1c
    move-object/from16 v0, p0

    iget-object v0, v0, Ltas/internal/ipc/server/ServerManager$ClientHandler;->mCallback:Ltas/internal/ipc/server/IServerCallback;

    move-object/from16 v21, v0

    move-object/from16 v0, v21

    move-object/from16 v1, v17

    invoke-interface {v0, v10, v1}, Ltas/internal/ipc/server/IServerCallback;->onSenderOnline(Ltas/internal/ipc/server/RemoteReceiver;Ltas/internal/ipc/server/RemoteSender;)V
    :try_end_1c
    .catch Landroid/os/RemoteException; {:try_start_1c .. :try_end_1c} :catch_4
    .catchall {:try_start_1c .. :try_end_1c} :catchall_12

    .line 983
    invoke-virtual/range {v17 .. v17}, Ltas/internal/ipc/server/RemoteSender;->recycle()V

    .line 984
    invoke-virtual {v10}, Ltas/internal/ipc/server/RemoteReceiver;->recycle()V

    goto/16 :goto_0

    .line 979
    :catch_4
    move-exception v7

    .line 980
    .restart local v7    # "e":Landroid/os/RemoteException;
    :try_start_1d
    invoke-virtual {v7}, Landroid/os/RemoteException;->printStackTrace()V

    .line 981
    invoke-static {v8}, Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;->-get0(Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;)Ltas/internal/ipc/server/ServerManager$ReceiverHolder;

    move-result-object v21

    invoke-static {v8}, Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;->-get1(Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;)Ltas/internal/ipc/server/ServerManager$SenderHolder;

    move-result-object v22

    invoke-static/range {v22 .. v22}, Ltas/internal/ipc/server/ServerManager$SenderHolder;->-get1(Ltas/internal/ipc/server/ServerManager$SenderHolder;)Ltas/internal/ipc/server/RemoteSender;

    move-result-object v22

    invoke-static/range {v21 .. v22}, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->-wrap2(Ltas/internal/ipc/server/ServerManager$ReceiverHolder;Ltas/internal/ipc/server/RemoteSender;)Z
    :try_end_1d
    .catchall {:try_start_1d .. :try_end_1d} :catchall_12

    .line 983
    invoke-virtual/range {v17 .. v17}, Ltas/internal/ipc/server/RemoteSender;->recycle()V

    .line 984
    invoke-virtual {v10}, Ltas/internal/ipc/server/RemoteReceiver;->recycle()V

    goto/16 :goto_0

    .line 982
    .end local v7    # "e":Landroid/os/RemoteException;
    :catchall_12
    move-exception v21

    .line 983
    invoke-virtual/range {v17 .. v17}, Ltas/internal/ipc/server/RemoteSender;->recycle()V

    .line 984
    invoke-virtual {v10}, Ltas/internal/ipc/server/RemoteReceiver;->recycle()V

    .line 982
    throw v21

    .line 990
    .end local v8    # "holder":Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;
    .end local v10    # "r":Ltas/internal/ipc/server/RemoteReceiver;
    .end local v17    # "s":Ltas/internal/ipc/server/RemoteSender;
    :pswitch_14
    move-object/from16 v0, p1

    iget-object v8, v0, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v8, Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;

    .line 991
    .restart local v8    # "holder":Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;
    move-object/from16 v0, p0

    iget-object v0, v0, Ltas/internal/ipc/server/ServerManager$ClientHandler;->mCallback:Ltas/internal/ipc/server/IServerCallback;

    move-object/from16 v21, v0

    if-eqz v21, :cond_1

    .line 992
    invoke-static {v8}, Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;->-get1(Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;)Ltas/internal/ipc/server/ServerManager$SenderHolder;

    move-result-object v21

    invoke-static/range {v21 .. v21}, Ltas/internal/ipc/server/ServerManager$SenderHolder;->-get1(Ltas/internal/ipc/server/ServerManager$SenderHolder;)Ltas/internal/ipc/server/RemoteSender;

    move-result-object v21

    invoke-static/range {v21 .. v21}, Ltas/internal/ipc/server/RemoteSender;->obtain(Ltas/internal/ipc/server/RemoteSender;)Ltas/internal/ipc/server/RemoteSender;

    move-result-object v17

    .line 993
    .restart local v17    # "s":Ltas/internal/ipc/server/RemoteSender;
    invoke-static {v8}, Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;->-get0(Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;)Ltas/internal/ipc/server/ServerManager$ReceiverHolder;

    move-result-object v21

    invoke-static/range {v21 .. v21}, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->-get0(Ltas/internal/ipc/server/ServerManager$ReceiverHolder;)Ltas/internal/ipc/server/RemoteReceiver;

    move-result-object v21

    invoke-static/range {v21 .. v21}, Ltas/internal/ipc/server/RemoteReceiver;->obtain(Ltas/internal/ipc/server/RemoteReceiver;)Ltas/internal/ipc/server/RemoteReceiver;

    move-result-object v10

    .line 996
    .restart local v10    # "r":Ltas/internal/ipc/server/RemoteReceiver;
    :try_start_1e
    move-object/from16 v0, p0

    iget-object v0, v0, Ltas/internal/ipc/server/ServerManager$ClientHandler;->mCallback:Ltas/internal/ipc/server/IServerCallback;

    move-object/from16 v21, v0

    move-object/from16 v0, v21

    move-object/from16 v1, v17

    invoke-interface {v0, v10, v1}, Ltas/internal/ipc/server/IServerCallback;->onSenderOffline(Ltas/internal/ipc/server/RemoteReceiver;Ltas/internal/ipc/server/RemoteSender;)V
    :try_end_1e
    .catch Landroid/os/RemoteException; {:try_start_1e .. :try_end_1e} :catch_5
    .catchall {:try_start_1e .. :try_end_1e} :catchall_13

    .line 1000
    invoke-virtual/range {v17 .. v17}, Ltas/internal/ipc/server/RemoteSender;->recycle()V

    .line 1001
    invoke-virtual {v10}, Ltas/internal/ipc/server/RemoteReceiver;->recycle()V

    goto/16 :goto_0

    .line 997
    :catch_5
    move-exception v7

    .line 998
    .restart local v7    # "e":Landroid/os/RemoteException;
    :try_start_1f
    invoke-virtual {v7}, Landroid/os/RemoteException;->printStackTrace()V
    :try_end_1f
    .catchall {:try_start_1f .. :try_end_1f} :catchall_13

    .line 1000
    invoke-virtual/range {v17 .. v17}, Ltas/internal/ipc/server/RemoteSender;->recycle()V

    .line 1001
    invoke-virtual {v10}, Ltas/internal/ipc/server/RemoteReceiver;->recycle()V

    goto/16 :goto_0

    .line 999
    .end local v7    # "e":Landroid/os/RemoteException;
    :catchall_13
    move-exception v21

    .line 1000
    invoke-virtual/range {v17 .. v17}, Ltas/internal/ipc/server/RemoteSender;->recycle()V

    .line 1001
    invoke-virtual {v10}, Ltas/internal/ipc/server/RemoteReceiver;->recycle()V

    .line 999
    throw v21

    .line 1007
    .end local v8    # "holder":Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;
    .end local v10    # "r":Ltas/internal/ipc/server/RemoteReceiver;
    .end local v17    # "s":Ltas/internal/ipc/server/RemoteSender;
    :pswitch_15
    move-object/from16 v0, p1

    iget-object v8, v0, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v8, Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;

    .line 1008
    .restart local v8    # "holder":Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;
    move-object/from16 v0, p0

    iget-object v0, v0, Ltas/internal/ipc/server/ServerManager$ClientHandler;->mCallback:Ltas/internal/ipc/server/IServerCallback;

    move-object/from16 v21, v0

    if-eqz v21, :cond_1

    .line 1009
    invoke-static {v8}, Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;->-get1(Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;)Ltas/internal/ipc/server/ServerManager$SenderHolder;

    move-result-object v21

    invoke-static/range {v21 .. v21}, Ltas/internal/ipc/server/ServerManager$SenderHolder;->-get1(Ltas/internal/ipc/server/ServerManager$SenderHolder;)Ltas/internal/ipc/server/RemoteSender;

    move-result-object v21

    invoke-static/range {v21 .. v21}, Ltas/internal/ipc/server/RemoteSender;->obtain(Ltas/internal/ipc/server/RemoteSender;)Ltas/internal/ipc/server/RemoteSender;

    move-result-object v17

    .line 1010
    .restart local v17    # "s":Ltas/internal/ipc/server/RemoteSender;
    invoke-static {v8}, Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;->-get0(Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;)Ltas/internal/ipc/server/ServerManager$ReceiverHolder;

    move-result-object v21

    invoke-static/range {v21 .. v21}, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->-get0(Ltas/internal/ipc/server/ServerManager$ReceiverHolder;)Ltas/internal/ipc/server/RemoteReceiver;

    move-result-object v21

    invoke-static/range {v21 .. v21}, Ltas/internal/ipc/server/RemoteReceiver;->obtain(Ltas/internal/ipc/server/RemoteReceiver;)Ltas/internal/ipc/server/RemoteReceiver;

    move-result-object v10

    .line 1013
    .restart local v10    # "r":Ltas/internal/ipc/server/RemoteReceiver;
    :try_start_20
    move-object/from16 v0, p0

    iget-object v0, v0, Ltas/internal/ipc/server/ServerManager$ClientHandler;->mCallback:Ltas/internal/ipc/server/IServerCallback;

    move-object/from16 v21, v0

    move-object/from16 v0, v21

    move-object/from16 v1, v17

    invoke-interface {v0, v10, v1}, Ltas/internal/ipc/server/IServerCallback;->onSenderUpdate(Ltas/internal/ipc/server/RemoteReceiver;Ltas/internal/ipc/server/RemoteSender;)V
    :try_end_20
    .catch Landroid/os/RemoteException; {:try_start_20 .. :try_end_20} :catch_6
    .catchall {:try_start_20 .. :try_end_20} :catchall_14

    .line 1017
    invoke-virtual/range {v17 .. v17}, Ltas/internal/ipc/server/RemoteSender;->recycle()V

    .line 1018
    invoke-virtual {v10}, Ltas/internal/ipc/server/RemoteReceiver;->recycle()V

    goto/16 :goto_0

    .line 1014
    :catch_6
    move-exception v7

    .line 1015
    .restart local v7    # "e":Landroid/os/RemoteException;
    :try_start_21
    invoke-virtual {v7}, Landroid/os/RemoteException;->printStackTrace()V
    :try_end_21
    .catchall {:try_start_21 .. :try_end_21} :catchall_14

    .line 1017
    invoke-virtual/range {v17 .. v17}, Ltas/internal/ipc/server/RemoteSender;->recycle()V

    .line 1018
    invoke-virtual {v10}, Ltas/internal/ipc/server/RemoteReceiver;->recycle()V

    goto/16 :goto_0

    .line 1016
    .end local v7    # "e":Landroid/os/RemoteException;
    :catchall_14
    move-exception v21

    .line 1017
    invoke-virtual/range {v17 .. v17}, Ltas/internal/ipc/server/RemoteSender;->recycle()V

    .line 1018
    invoke-virtual {v10}, Ltas/internal/ipc/server/RemoteReceiver;->recycle()V

    .line 1016
    throw v21

    .line 1024
    .end local v8    # "holder":Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;
    .end local v10    # "r":Ltas/internal/ipc/server/RemoteReceiver;
    .end local v17    # "s":Ltas/internal/ipc/server/RemoteSender;
    :pswitch_16
    monitor-enter v9

    .line 1025
    :try_start_22
    move-object/from16 v0, p0

    iget-object v0, v0, Ltas/internal/ipc/server/ServerManager$ClientHandler;->mSenders:Ljava/util/List;

    move-object/from16 v21, v0

    invoke-interface/range {v21 .. v21}, Ljava/util/List;->clear()V

    .line 1026
    move-object/from16 v0, p0

    iget-object v0, v0, Ltas/internal/ipc/server/ServerManager$ClientHandler;->mReceivers:Ljava/util/List;

    move-object/from16 v21, v0

    invoke-interface/range {v21 .. v21}, Ljava/util/List;->clear()V

    .line 1027
    move-object/from16 v0, p0

    iget-object v0, v0, Ltas/internal/ipc/server/ServerManager$ClientHandler;->mHT:Landroid/os/HandlerThread;

    move-object/from16 v21, v0

    invoke-virtual/range {v21 .. v21}, Landroid/os/HandlerThread;->quitSafely()Z

    .line 1028
    const/16 v21, 0x0

    move-object/from16 v0, v21

    move-object/from16 v1, p0

    iput-object v0, v1, Ltas/internal/ipc/server/ServerManager$ClientHandler;->mHT:Landroid/os/HandlerThread;

    .line 1029
    const/16 v21, 0x0

    move-object/from16 v0, v21

    move-object/from16 v1, p0

    iput-object v0, v1, Ltas/internal/ipc/server/ServerManager$ClientHandler;->mCallback:Ltas/internal/ipc/server/IServerCallback;

    .line 1030
    invoke-static {v9}, Ltas/internal/ipc/server/ServerManager;->-get0(Ltas/internal/ipc/server/ServerManager;)Landroid/util/ArrayMap;

    move-result-object v21

    move-object/from16 v0, p0

    iget v0, v0, Ltas/internal/ipc/server/ServerManager$ClientHandler;->pid:I

    move/from16 v22, v0

    invoke-static/range {v22 .. v22}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v22

    invoke-virtual/range {v21 .. v22}, Landroid/util/ArrayMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 1031
    const-string/jumbo v21, "TasIPC<ServerManager>"

    new-instance v22, Ljava/lang/StringBuilder;

    invoke-direct/range {v22 .. v22}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v23, "client:"

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    move-object/from16 v0, p0

    iget v0, v0, Ltas/internal/ipc/server/ServerManager$ClientHandler;->pid:I

    move/from16 v23, v0

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v22

    const-string/jumbo v23, " quit."

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    invoke-virtual/range {v22 .. v22}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v22

    invoke-static/range {v21 .. v22}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_22
    .catchall {:try_start_22 .. :try_end_22} :catchall_15

    goto/16 :goto_1

    .line 1024
    :catchall_15
    move-exception v21

    monitor-exit v9

    throw v21

    .line 303
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
        :pswitch_1
        :pswitch_2
        :pswitch_3
        :pswitch_4
        :pswitch_5
        :pswitch_6
        :pswitch_7
        :pswitch_a
        :pswitch_b
        :pswitch_8
        :pswitch_9
        :pswitch_c
        :pswitch_d
        :pswitch_e
        :pswitch_f
        :pswitch_10
        :pswitch_11
        :pswitch_13
        :pswitch_14
        :pswitch_12
        :pswitch_15
        :pswitch_16
    .end packed-switch
.end method
