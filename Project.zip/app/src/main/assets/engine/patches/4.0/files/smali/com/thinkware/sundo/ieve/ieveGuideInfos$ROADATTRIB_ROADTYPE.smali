.class public final enum Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADTYPE;
.super Ljava/lang/Enum;
.source "ieveGuideInfos.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/thinkware/sundo/ieve/ieveGuideInfos;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "ROADATTRIB_ROADTYPE"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum",
        "<",
        "Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADTYPE;",
        ">;"
    }
.end annotation


# static fields
.field public static final enum CARONLY:Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADTYPE;

.field public static final enum CITYROAD:Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADTYPE;

.field public static final enum HIGHWAY:Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADTYPE;

.field public static final enum NATIONROAD:Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADTYPE;

.field public static final enum NONE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADTYPE;

.field public static final enum NORMALROAD:Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADTYPE;

.field public static final enum URBANROAD:Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADTYPE;

.field private static final synthetic b:[Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADTYPE;


# instance fields
.field private final a:I


# direct methods
.method static constructor <clinit>()V
    .locals 9

    .prologue
    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v4, 0x0

    .line 5
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADTYPE;

    const-string v1, "NONE"

    invoke-direct {v0, v1, v4, v4}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADTYPE;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADTYPE;->NONE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADTYPE;

    .line 6
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADTYPE;

    const-string v1, "HIGHWAY"

    invoke-direct {v0, v1, v5, v5}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADTYPE;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADTYPE;->HIGHWAY:Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADTYPE;

    .line 7
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADTYPE;

    const-string v1, "CITYROAD"

    invoke-direct {v0, v1, v6, v6}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADTYPE;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADTYPE;->CITYROAD:Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADTYPE;

    .line 8
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADTYPE;

    const-string v1, "NATIONROAD"

    invoke-direct {v0, v1, v7, v7}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADTYPE;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADTYPE;->NATIONROAD:Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADTYPE;

    .line 9
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADTYPE;

    const-string v1, "URBANROAD"

    invoke-direct {v0, v1, v8, v8}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADTYPE;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADTYPE;->URBANROAD:Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADTYPE;

    .line 10
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADTYPE;

    const-string v1, "NORMALROAD"

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADTYPE;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADTYPE;->NORMALROAD:Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADTYPE;

    .line 11
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADTYPE;

    const-string v1, "CARONLY"

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADTYPE;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADTYPE;->CARONLY:Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADTYPE;

    .line 4
    const/4 v0, 0x7

    new-array v0, v0, [Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADTYPE;

    sget-object v1, Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADTYPE;->NONE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADTYPE;

    aput-object v1, v0, v4

    sget-object v1, Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADTYPE;->HIGHWAY:Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADTYPE;

    aput-object v1, v0, v5

    sget-object v1, Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADTYPE;->CITYROAD:Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADTYPE;

    aput-object v1, v0, v6

    sget-object v1, Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADTYPE;->NATIONROAD:Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADTYPE;

    aput-object v1, v0, v7

    sget-object v1, Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADTYPE;->URBANROAD:Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADTYPE;

    aput-object v1, v0, v8

    const/4 v1, 0x5

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADTYPE;->NORMALROAD:Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADTYPE;

    aput-object v2, v0, v1

    const/4 v1, 0x6

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADTYPE;->CARONLY:Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADTYPE;

    aput-object v2, v0, v1

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADTYPE;->b:[Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADTYPE;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .locals 0
    .param p3, "value"    # I

    .prologue
    .line 13
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    iput p3, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADTYPE;->a:I

    return-void
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADTYPE;
    .locals 1

    .prologue
    .line 1
    const-class v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADTYPE;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object v0

    check-cast v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADTYPE;

    return-object v0
.end method

.method public static values()[Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADTYPE;
    .locals 4

    .prologue
    const/4 v3, 0x0

    .line 1
    sget-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADTYPE;->b:[Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADTYPE;

    array-length v1, v0

    new-array v2, v1, [Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADTYPE;

    invoke-static {v0, v3, v2, v3, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    return-object v2
.end method


# virtual methods
.method public getValue()I
    .locals 1

    .prologue
    .line 15
    iget v0, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADTYPE;->a:I

    return v0
.end method
