.class Ltas/internal/ipc/server/ServerManager$1;
.super Ljava/lang/Thread;
.source "ServerManager.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ltas/internal/ipc/server/ServerManager;->dumpAsync()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Ltas/internal/ipc/server/ServerManager;


# direct methods
.method constructor <init>(Ltas/internal/ipc/server/ServerManager;Ljava/lang/String;)V
    .locals 0
    .param p1, "this$0"    # Ltas/internal/ipc/server/ServerManager;
    .param p2, "$anonymous0"    # Ljava/lang/String;

    .prologue
    .line 1189
    iput-object p1, p0, Ltas/internal/ipc/server/ServerManager$1;->this$0:Ltas/internal/ipc/server/ServerManager;

    invoke-direct {p0, p2}, Ljava/lang/Thread;-><init>(Ljava/lang/String;)V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 1

    .prologue
    .line 1190
    iget-object v0, p0, Ltas/internal/ipc/server/ServerManager$1;->this$0:Ltas/internal/ipc/server/ServerManager;

    invoke-virtual {v0}, Ltas/internal/ipc/server/ServerManager;->dump()V

    return-void
.end method
