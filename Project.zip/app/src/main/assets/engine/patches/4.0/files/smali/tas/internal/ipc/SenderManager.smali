.class Ltas/internal/ipc/SenderManager;
.super Ljava/lang/Object;
.source "SenderManager.java"

# interfaces
.implements Ltas/internal/ipc/server/ServerConnection$SenderCallback;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ltas/internal/ipc/SenderManager$SenderWrapper;,
        Ltas/internal/ipc/SenderManager$RemoteReplier;,
        Ltas/internal/ipc/SenderManager$ReceiverWrapper;,
        Ltas/internal/ipc/SenderManager$ReceiverConnectionWrapper;
    }
.end annotation


# static fields
.field private static final DBG:Z = true

.field private static final DBG_TRANSMIT:Z = false

.field private static final TAG:Ljava/lang/String; = "TasIPC<SenderManager>"

.field private static sId:I

.field private static sThis:Ltas/internal/ipc/SenderManager;


# instance fields
.field private mContext:Landroid/content/Context;

.field private mHT:Landroid/os/HandlerThread;

.field private mLooper:Landroid/os/Looper;

.field private mMultiReceiverThread:Z

.field private final mSenders:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List",
            "<",
            "Ltas/internal/ipc/SenderManager$SenderWrapper;",
            ">;"
        }
    .end annotation
.end field

.field private mServer:Ltas/internal/ipc/server/ServerConnection;


# direct methods
.method static synthetic -get0(Ltas/internal/ipc/SenderManager;)Landroid/content/Context;
    .locals 1

    iget-object v0, p0, Ltas/internal/ipc/SenderManager;->mContext:Landroid/content/Context;

    return-object v0
.end method

.method static synthetic -get1(Ltas/internal/ipc/SenderManager;)Landroid/os/HandlerThread;
    .locals 1

    iget-object v0, p0, Ltas/internal/ipc/SenderManager;->mHT:Landroid/os/HandlerThread;

    return-object v0
.end method

.method static synthetic -get2(Ltas/internal/ipc/SenderManager;)Landroid/os/Looper;
    .locals 1

    iget-object v0, p0, Ltas/internal/ipc/SenderManager;->mLooper:Landroid/os/Looper;

    return-object v0
.end method

.method static synthetic -get3(Ltas/internal/ipc/SenderManager;)Z
    .locals 1

    iget-boolean v0, p0, Ltas/internal/ipc/SenderManager;->mMultiReceiverThread:Z

    return v0
.end method

.method static synthetic -get4(Ltas/internal/ipc/SenderManager;)Ljava/util/List;
    .locals 1

    iget-object v0, p0, Ltas/internal/ipc/SenderManager;->mSenders:Ljava/util/List;

    return-object v0
.end method

.method static synthetic -set0(Ltas/internal/ipc/SenderManager;Landroid/os/HandlerThread;)Landroid/os/HandlerThread;
    .locals 0

    iput-object p1, p0, Ltas/internal/ipc/SenderManager;->mHT:Landroid/os/HandlerThread;

    return-object p1
.end method

.method static synthetic -set1(Ltas/internal/ipc/SenderManager;Landroid/os/Looper;)Landroid/os/Looper;
    .locals 0

    iput-object p1, p0, Ltas/internal/ipc/SenderManager;->mLooper:Landroid/os/Looper;

    return-object p1
.end method

.method static synthetic -wrap0(Ltas/internal/ipc/SenderManager;Ltas/internal/ipc/Sender;Ltas/internal/ipc/server/RemoteReceiver;)V
    .locals 0
    .param p1, "ms"    # Ltas/internal/ipc/Sender;
    .param p2, "r"    # Ltas/internal/ipc/server/RemoteReceiver;

    .prologue
    invoke-direct {p0, p1, p2}, Ltas/internal/ipc/SenderManager;->dispatchOffline(Ltas/internal/ipc/Sender;Ltas/internal/ipc/server/RemoteReceiver;)V

    return-void
.end method

.method static synthetic -wrap1(Ltas/internal/ipc/SenderManager;Ltas/internal/ipc/Sender;Ltas/internal/ipc/server/RemoteReceiver;)V
    .locals 0
    .param p1, "ms"    # Ltas/internal/ipc/Sender;
    .param p2, "r"    # Ltas/internal/ipc/server/RemoteReceiver;

    .prologue
    invoke-direct {p0, p1, p2}, Ltas/internal/ipc/SenderManager;->dispatchOnline(Ltas/internal/ipc/Sender;Ltas/internal/ipc/server/RemoteReceiver;)V

    return-void
.end method

.method static synthetic -wrap10(Ltas/internal/ipc/SenderManager;Ltas/internal/ipc/SenderManager$SenderWrapper;)V
    .locals 0
    .param p1, "sender"    # Ltas/internal/ipc/SenderManager$SenderWrapper;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/ipc/SenderManager;->watchAnonymousReceiverFromServer(Ltas/internal/ipc/SenderManager$SenderWrapper;)V

    return-void
.end method

.method static synthetic -wrap11(Ltas/internal/ipc/SenderManager;Ltas/internal/ipc/SenderManager$SenderWrapper;Ljava/lang/String;)V
    .locals 0
    .param p1, "sender"    # Ltas/internal/ipc/SenderManager$SenderWrapper;
    .param p2, "target"    # Ljava/lang/String;

    .prologue
    invoke-direct {p0, p1, p2}, Ltas/internal/ipc/SenderManager;->watchReceiverFromServer(Ltas/internal/ipc/SenderManager$SenderWrapper;Ljava/lang/String;)V

    return-void
.end method

.method static synthetic -wrap2(Ltas/internal/ipc/SenderManager;Ltas/internal/ipc/Sender;Ltas/ipc/SenderSession;)V
    .locals 0
    .param p1, "ms"    # Ltas/internal/ipc/Sender;
    .param p2, "s"    # Ltas/ipc/SenderSession;

    .prologue
    invoke-direct {p0, p1, p2}, Ltas/internal/ipc/SenderManager;->dispatchReply(Ltas/internal/ipc/Sender;Ltas/ipc/SenderSession;)V

    return-void
.end method

.method static synthetic -wrap3(Ltas/internal/ipc/SenderManager;Ltas/internal/ipc/Sender;Ltas/internal/ipc/server/RemoteReceiver;)V
    .locals 0
    .param p1, "ms"    # Ltas/internal/ipc/Sender;
    .param p2, "r"    # Ltas/internal/ipc/server/RemoteReceiver;

    .prologue
    invoke-direct {p0, p1, p2}, Ltas/internal/ipc/SenderManager;->dispatchUpdate(Ltas/internal/ipc/Sender;Ltas/internal/ipc/server/RemoteReceiver;)V

    return-void
.end method

.method static synthetic -wrap4(Ltas/internal/ipc/SenderManager;Ltas/internal/ipc/server/RemoteSender;Ltas/internal/ipc/SenderManager$ReceiverWrapper;)V
    .locals 0
    .param p1, "s"    # Ltas/internal/ipc/server/RemoteSender;
    .param p2, "rw"    # Ltas/internal/ipc/SenderManager$ReceiverWrapper;

    .prologue
    invoke-direct {p0, p1, p2}, Ltas/internal/ipc/SenderManager;->onReceiverConnected(Ltas/internal/ipc/server/RemoteSender;Ltas/internal/ipc/SenderManager$ReceiverWrapper;)V

    return-void
.end method

.method static synthetic -wrap5(Ltas/internal/ipc/SenderManager;Ltas/internal/ipc/SenderManager$ReceiverWrapper;)V
    .locals 0
    .param p1, "rw"    # Ltas/internal/ipc/SenderManager$ReceiverWrapper;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/ipc/SenderManager;->onReceiverDied(Ltas/internal/ipc/SenderManager$ReceiverWrapper;)V

    return-void
.end method

.method static synthetic -wrap6(Ltas/internal/ipc/SenderManager;Ltas/internal/ipc/server/RemoteSender;Ltas/internal/ipc/SenderManager$ReceiverWrapper;)V
    .locals 0
    .param p1, "s"    # Ltas/internal/ipc/server/RemoteSender;
    .param p2, "rw"    # Ltas/internal/ipc/SenderManager$ReceiverWrapper;

    .prologue
    invoke-direct {p0, p1, p2}, Ltas/internal/ipc/SenderManager;->onReceiverDisconnected(Ltas/internal/ipc/server/RemoteSender;Ltas/internal/ipc/SenderManager$ReceiverWrapper;)V

    return-void
.end method

.method static synthetic -wrap7(Ltas/internal/ipc/SenderManager;Ltas/internal/ipc/SenderManager$SenderWrapper;)V
    .locals 0
    .param p1, "sender"    # Ltas/internal/ipc/SenderManager$SenderWrapper;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/ipc/SenderManager;->registerToServer(Ltas/internal/ipc/SenderManager$SenderWrapper;)V

    return-void
.end method

.method static synthetic -wrap8(Ltas/internal/ipc/SenderManager;Ltas/internal/ipc/server/RemoteMessage;)V
    .locals 0
    .param p1, "rmsg"    # Ltas/internal/ipc/server/RemoteMessage;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/ipc/SenderManager;->transmitToServer(Ltas/internal/ipc/server/RemoteMessage;)V

    return-void
.end method

.method static synthetic -wrap9(Ltas/internal/ipc/SenderManager;Ltas/internal/ipc/SenderManager$SenderWrapper;)V
    .locals 0
    .param p1, "sender"    # Ltas/internal/ipc/SenderManager$SenderWrapper;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/ipc/SenderManager;->updateToServer(Ltas/internal/ipc/SenderManager$SenderWrapper;)V

    return-void
.end method

.method static constructor <clinit>()V
    .locals 1

    .prologue
    .line 48
    const/4 v0, 0x1

    sput v0, Ltas/internal/ipc/SenderManager;->sId:I

    .line 34
    return-void
.end method

.method private constructor <init>()V
    .locals 1

    .prologue
    .line 61
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 41
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 40
    iput-object v0, p0, Ltas/internal/ipc/SenderManager;->mSenders:Ljava/util/List;

    .line 47
    const/4 v0, 0x0

    iput-boolean v0, p0, Ltas/internal/ipc/SenderManager;->mMultiReceiverThread:Z

    .line 61
    return-void
.end method

.method private connectToServer(Landroid/content/Context;)V
    .locals 2
    .param p1, "context"    # Landroid/content/Context;

    .prologue
    .line 644
    iget-object v0, p0, Ltas/internal/ipc/SenderManager;->mServer:Ltas/internal/ipc/server/ServerConnection;

    if-eqz v0, :cond_0

    .line 645
    iget-object v0, p0, Ltas/internal/ipc/SenderManager;->mServer:Ltas/internal/ipc/server/ServerConnection;

    invoke-virtual {v0, p1}, Ltas/internal/ipc/server/ServerConnection;->setContext(Landroid/content/Context;)V

    .line 646
    iget-object v0, p0, Ltas/internal/ipc/SenderManager;->mServer:Ltas/internal/ipc/server/ServerConnection;

    invoke-virtual {v0}, Ltas/internal/ipc/server/ServerConnection;->connect()V

    .line 647
    return-void

    .line 650
    :cond_0
    new-instance v0, Ltas/internal/ipc/SenderManager$1;

    iget-object v1, p0, Ltas/internal/ipc/SenderManager;->mContext:Landroid/content/Context;

    invoke-direct {v0, p0, v1}, Ltas/internal/ipc/SenderManager$1;-><init>(Ltas/internal/ipc/SenderManager;Landroid/content/Context;)V

    iput-object v0, p0, Ltas/internal/ipc/SenderManager;->mServer:Ltas/internal/ipc/server/ServerConnection;

    .line 678
    iget-object v0, p0, Ltas/internal/ipc/SenderManager;->mServer:Ltas/internal/ipc/server/ServerConnection;

    invoke-virtual {v0, p0}, Ltas/internal/ipc/server/ServerConnection;->setSenderCallback(Ltas/internal/ipc/server/ServerConnection$SenderCallback;)V

    .line 679
    iget-object v0, p0, Ltas/internal/ipc/SenderManager;->mServer:Ltas/internal/ipc/server/ServerConnection;

    invoke-virtual {v0}, Ltas/internal/ipc/server/ServerConnection;->connect()V

    .line 643
    return-void
.end method

.method private disconnectAll()V
    .locals 3

    .prologue
    .line 361
    iget-object v2, p0, Ltas/internal/ipc/SenderManager;->mSenders:Ljava/util/List;

    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    .local v1, "sw$iterator":Ljava/util/Iterator;
    :cond_0
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/ipc/SenderManager$SenderWrapper;

    .line 362
    .local v0, "sw":Ltas/internal/ipc/SenderManager$SenderWrapper;
    if-eqz v0, :cond_0

    invoke-static {v0}, Ltas/internal/ipc/SenderManager$SenderWrapper;->-wrap1(Ltas/internal/ipc/SenderManager$SenderWrapper;)V

    goto :goto_0

    .line 360
    .end local v0    # "sw":Ltas/internal/ipc/SenderManager$SenderWrapper;
    :cond_1
    return-void
.end method

.method private disconnectFromServer()V
    .locals 1

    .prologue
    .line 683
    iget-object v0, p0, Ltas/internal/ipc/SenderManager;->mServer:Ltas/internal/ipc/server/ServerConnection;

    invoke-virtual {v0}, Ltas/internal/ipc/server/ServerConnection;->disconnect()V

    .line 682
    return-void
.end method

.method private dispatchOffline(Ltas/internal/ipc/Sender;Ltas/internal/ipc/server/RemoteReceiver;)V
    .locals 6
    .param p1, "ms"    # Ltas/internal/ipc/Sender;
    .param p2, "r"    # Ltas/internal/ipc/server/RemoteReceiver;

    .prologue
    .line 299
    invoke-virtual {p2}, Ltas/internal/ipc/server/RemoteReceiver;->getid()J

    move-result-wide v2

    invoke-virtual {p1, v2, v3}, Ltas/internal/ipc/Sender;->removeSession(J)Ltas/ipc/SenderSession;

    move-result-object v0

    .line 300
    .local v0, "session":Ltas/ipc/SenderSession;
    if-eqz v0, :cond_0

    .line 301
    const-string/jumbo v1, "TasIPC<SenderManager>"

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "delete session id : "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-wide v4, v0, Ltas/ipc/SenderSession;->id:J

    invoke-virtual {v2, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 302
    const/4 v1, 0x0

    iput-boolean v1, v0, Ltas/ipc/SenderSession;->online:Z

    .line 303
    iget-object v1, p1, Ltas/internal/ipc/Sender;->mDispatcher:Ltas/internal/ipc/Dispatcher;

    const/16 v2, 0x66

    invoke-virtual {v1, v2, v0}, Ltas/internal/ipc/Dispatcher;->dispatch(ILtas/ipc/SenderSession;)V

    .line 298
    :cond_0
    return-void
.end method

.method private dispatchOnline(Ltas/internal/ipc/Sender;Ltas/internal/ipc/server/RemoteReceiver;)V
    .locals 8
    .param p1, "ms"    # Ltas/internal/ipc/Sender;
    .param p2, "r"    # Ltas/internal/ipc/server/RemoteReceiver;

    .prologue
    .line 285
    invoke-virtual {p2}, Ltas/internal/ipc/server/RemoteReceiver;->getid()J

    move-result-wide v2

    invoke-virtual {p1, v2, v3}, Ltas/internal/ipc/Sender;->getSession(J)Ltas/ipc/SenderSession;

    move-result-object v0

    .line 286
    .local v0, "session":Ltas/ipc/SenderSession;
    if-nez v0, :cond_0

    .line 287
    new-instance v0, Ltas/ipc/SenderSession;

    .line 288
    .end local v0    # "session":Ltas/ipc/SenderSession;
    invoke-virtual {p2}, Ltas/internal/ipc/server/RemoteReceiver;->getid()J

    move-result-wide v2

    iget-object v4, p2, Ltas/internal/ipc/server/RemoteReceiver;->pkg:Ljava/lang/String;

    iget-object v5, p2, Ltas/internal/ipc/server/RemoteReceiver;->name:Ljava/lang/String;

    iget-boolean v6, p2, Ltas/internal/ipc/server/RemoteReceiver;->p2pMode:Z

    iget-object v7, p2, Ltas/internal/ipc/server/RemoteReceiver;->extra:Landroid/os/Bundle;

    move-object v1, p1

    .line 287
    invoke-direct/range {v0 .. v7}, Ltas/ipc/SenderSession;-><init>(Ltas/internal/ipc/Sender;JLjava/lang/String;Ljava/lang/String;ZLandroid/os/Bundle;)V

    .line 289
    .restart local v0    # "session":Ltas/ipc/SenderSession;
    invoke-virtual {p2}, Ltas/internal/ipc/server/RemoteReceiver;->getid()J

    move-result-wide v2

    invoke-virtual {p1, v2, v3, v0}, Ltas/internal/ipc/Sender;->addSession(JLtas/ipc/SenderSession;)V

    .line 291
    const-string/jumbo v1, "TasIPC<SenderManager>"

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v3, p2, Ltas/internal/ipc/server/RemoteReceiver;->name:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string/jumbo v3, " new session id : "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-wide v4, v0, Ltas/ipc/SenderSession;->id:J

    invoke-virtual {v2, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 294
    :cond_0
    const/4 v1, 0x1

    iput-boolean v1, v0, Ltas/ipc/SenderSession;->online:Z

    .line 295
    iget-object v1, p1, Ltas/internal/ipc/Sender;->mDispatcher:Ltas/internal/ipc/Dispatcher;

    const/16 v2, 0x65

    invoke-virtual {v1, v2, v0}, Ltas/internal/ipc/Dispatcher;->dispatch(ILtas/ipc/SenderSession;)V

    .line 284
    return-void
.end method

.method private dispatchReply(Ltas/internal/ipc/Sender;Ltas/ipc/SenderSession;)V
    .locals 2
    .param p1, "ms"    # Ltas/internal/ipc/Sender;
    .param p2, "s"    # Ltas/ipc/SenderSession;

    .prologue
    .line 319
    iget-object v0, p1, Ltas/internal/ipc/Sender;->mDispatcher:Ltas/internal/ipc/Dispatcher;

    const/16 v1, 0x68

    invoke-virtual {v0, v1, p2}, Ltas/internal/ipc/Dispatcher;->dispatch(ILtas/ipc/SenderSession;)V

    .line 318
    return-void
.end method

.method private dispatchUpdate(Ltas/internal/ipc/Sender;Ltas/internal/ipc/server/RemoteReceiver;)V
    .locals 4
    .param p1, "ms"    # Ltas/internal/ipc/Sender;
    .param p2, "r"    # Ltas/internal/ipc/server/RemoteReceiver;

    .prologue
    .line 308
    invoke-virtual {p2}, Ltas/internal/ipc/server/RemoteReceiver;->getid()J

    move-result-wide v2

    invoke-virtual {p1, v2, v3}, Ltas/internal/ipc/Sender;->getSession(J)Ltas/ipc/SenderSession;

    move-result-object v0

    .line 309
    .local v0, "session":Ltas/ipc/SenderSession;
    if-eqz v0, :cond_1

    .line 310
    iget-object v1, v0, Ltas/ipc/SenderSession;->extra:Landroid/os/Bundle;

    invoke-virtual {v1}, Landroid/os/Bundle;->clear()V

    .line 311
    iget-object v1, p2, Ltas/internal/ipc/server/RemoteReceiver;->extra:Landroid/os/Bundle;

    if-eqz v1, :cond_0

    .line 312
    iget-object v1, v0, Ltas/ipc/SenderSession;->extra:Landroid/os/Bundle;

    iget-object v2, p2, Ltas/internal/ipc/server/RemoteReceiver;->extra:Landroid/os/Bundle;

    invoke-virtual {v1, v2}, Landroid/os/Bundle;->putAll(Landroid/os/Bundle;)V

    .line 314
    :cond_0
    iget-object v1, p1, Ltas/internal/ipc/Sender;->mDispatcher:Ltas/internal/ipc/Dispatcher;

    const/16 v2, 0x67

    invoke-virtual {v1, v2, v0}, Ltas/internal/ipc/Dispatcher;->dispatch(ILtas/ipc/SenderSession;)V

    .line 307
    :cond_1
    return-void
.end method

.method private findSender(J)Ltas/internal/ipc/SenderManager$SenderWrapper;
    .locals 5
    .param p1, "id"    # J

    .prologue
    const/4 v4, 0x0

    .line 392
    iget-object v2, p0, Ltas/internal/ipc/SenderManager;->mSenders:Ljava/util/List;

    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    .local v1, "sw$iterator":Ljava/util/Iterator;
    :cond_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/ipc/SenderManager$SenderWrapper;

    .line 393
    .local v0, "sw":Ltas/internal/ipc/SenderManager$SenderWrapper;
    if-eqz v0, :cond_0

    invoke-virtual {v0}, Ltas/internal/ipc/SenderManager$SenderWrapper;->getid()J

    move-result-wide v2

    cmp-long v2, v2, p1

    if-nez v2, :cond_0

    .line 394
    return-object v0

    .line 397
    .end local v0    # "sw":Ltas/internal/ipc/SenderManager$SenderWrapper;
    :cond_1
    return-object v4
.end method

.method private findSender(Ljava/lang/String;)Ltas/internal/ipc/SenderManager$SenderWrapper;
    .locals 4
    .param p1, "name"    # Ljava/lang/String;

    .prologue
    const/4 v3, 0x0

    .line 383
    iget-object v2, p0, Ltas/internal/ipc/SenderManager;->mSenders:Ljava/util/List;

    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    .local v1, "sw$iterator":Ljava/util/Iterator;
    :cond_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/ipc/SenderManager$SenderWrapper;

    .line 384
    .local v0, "sw":Ltas/internal/ipc/SenderManager$SenderWrapper;
    if-eqz v0, :cond_0

    iget-object v2, v0, Ltas/internal/ipc/SenderManager$SenderWrapper;->name:Ljava/lang/String;

    invoke-virtual {v2, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_0

    .line 385
    return-object v0

    .line 388
    .end local v0    # "sw":Ltas/internal/ipc/SenderManager$SenderWrapper;
    :cond_1
    return-object v3
.end method

.method private static genId()I
    .locals 2

    .prologue
    .line 49
    sget v0, Ltas/internal/ipc/SenderManager;->sId:I

    add-int/lit8 v1, v0, 0x1

    sput v1, Ltas/internal/ipc/SenderManager;->sId:I

    return v0
.end method

.method static get()Ltas/internal/ipc/SenderManager;
    .locals 2

    .prologue
    .line 53
    const-class v1, Ltas/internal/ipc/SenderManager;

    monitor-enter v1

    .line 54
    :try_start_0
    sget-object v0, Ltas/internal/ipc/SenderManager;->sThis:Ltas/internal/ipc/SenderManager;

    if-nez v0, :cond_0

    .line 55
    new-instance v0, Ltas/internal/ipc/SenderManager;

    invoke-direct {v0}, Ltas/internal/ipc/SenderManager;-><init>()V

    sput-object v0, Ltas/internal/ipc/SenderManager;->sThis:Ltas/internal/ipc/SenderManager;

    .line 57
    :cond_0
    sget-object v0, Ltas/internal/ipc/SenderManager;->sThis:Ltas/internal/ipc/SenderManager;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit v1

    return-object v0

    .line 53
    :catchall_0
    move-exception v0

    monitor-exit v1

    throw v0
.end method

.method private onReceiverConnected(Ltas/internal/ipc/server/RemoteSender;Ltas/internal/ipc/SenderManager$ReceiverWrapper;)V
    .locals 4
    .param p1, "s"    # Ltas/internal/ipc/server/RemoteSender;
    .param p2, "rw"    # Ltas/internal/ipc/SenderManager$ReceiverWrapper;

    .prologue
    .line 367
    const-string/jumbo v1, "TasIPC<SenderManager>"

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "receiver ["

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, p2, Ltas/internal/ipc/SenderManager$ReceiverWrapper;->name:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string/jumbo v3, "] connected."

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 368
    invoke-virtual {p1}, Ltas/internal/ipc/server/RemoteSender;->getid()J

    move-result-wide v2

    invoke-direct {p0, v2, v3}, Ltas/internal/ipc/SenderManager;->findSender(J)Ltas/internal/ipc/SenderManager$SenderWrapper;

    move-result-object v0

    .line 369
    .local v0, "sw":Ltas/internal/ipc/SenderManager$SenderWrapper;
    if-eqz v0, :cond_0

    invoke-static {v0, p2}, Ltas/internal/ipc/SenderManager$SenderWrapper;->-wrap3(Ltas/internal/ipc/SenderManager$SenderWrapper;Ltas/internal/ipc/SenderManager$ReceiverWrapper;)V

    .line 366
    :cond_0
    return-void
.end method

.method private onReceiverDied(Ltas/internal/ipc/SenderManager$ReceiverWrapper;)V
    .locals 0
    .param p1, "rw"    # Ltas/internal/ipc/SenderManager$ReceiverWrapper;

    .prologue
    .line 378
    return-void
.end method

.method private onReceiverDisconnected(Ltas/internal/ipc/server/RemoteSender;Ltas/internal/ipc/SenderManager$ReceiverWrapper;)V
    .locals 4
    .param p1, "s"    # Ltas/internal/ipc/server/RemoteSender;
    .param p2, "rw"    # Ltas/internal/ipc/SenderManager$ReceiverWrapper;

    .prologue
    .line 373
    const-string/jumbo v1, "TasIPC<SenderManager>"

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "receiver ["

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, p2, Ltas/internal/ipc/SenderManager$ReceiverWrapper;->name:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string/jumbo v3, "] disconnected."

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 374
    invoke-virtual {p1}, Ltas/internal/ipc/server/RemoteSender;->getid()J

    move-result-wide v2

    invoke-direct {p0, v2, v3}, Ltas/internal/ipc/SenderManager;->findSender(J)Ltas/internal/ipc/SenderManager$SenderWrapper;

    move-result-object v0

    .line 375
    .local v0, "sw":Ltas/internal/ipc/SenderManager$SenderWrapper;
    if-eqz v0, :cond_0

    invoke-static {v0, p2}, Ltas/internal/ipc/SenderManager$SenderWrapper;->-wrap2(Ltas/internal/ipc/SenderManager$SenderWrapper;Ltas/internal/ipc/SenderManager$ReceiverWrapper;)V

    .line 372
    :cond_0
    return-void
.end method

.method private registerToServer(Ltas/internal/ipc/SenderManager$SenderWrapper;)V
    .locals 2
    .param p1, "sender"    # Ltas/internal/ipc/SenderManager$SenderWrapper;

    .prologue
    .line 687
    iget-object v0, p0, Ltas/internal/ipc/SenderManager;->mServer:Ltas/internal/ipc/server/ServerConnection;

    invoke-static {p1}, Ltas/internal/ipc/server/RemoteSender;->obtain(Ltas/internal/ipc/server/RemoteSender;)Ltas/internal/ipc/server/RemoteSender;

    move-result-object v1

    invoke-virtual {v0, v1}, Ltas/internal/ipc/server/ServerConnection;->registerSender(Ltas/internal/ipc/server/RemoteSender;)V

    .line 686
    return-void
.end method

.method private transmitToServer(Ltas/internal/ipc/server/RemoteMessage;)V
    .locals 1
    .param p1, "rmsg"    # Ltas/internal/ipc/server/RemoteMessage;

    .prologue
    .line 699
    iget-object v0, p0, Ltas/internal/ipc/SenderManager;->mServer:Ltas/internal/ipc/server/ServerConnection;

    invoke-virtual {v0, p1}, Ltas/internal/ipc/server/ServerConnection;->transmit(Ltas/internal/ipc/server/RemoteMessage;)V

    .line 698
    return-void
.end method

.method private unregisterToServer(Ltas/internal/ipc/SenderManager$SenderWrapper;)V
    .locals 2
    .param p1, "sender"    # Ltas/internal/ipc/SenderManager$SenderWrapper;

    .prologue
    .line 691
    iget-object v0, p0, Ltas/internal/ipc/SenderManager;->mServer:Ltas/internal/ipc/server/ServerConnection;

    invoke-static {p1}, Ltas/internal/ipc/server/RemoteSender;->obtain(Ltas/internal/ipc/server/RemoteSender;)Ltas/internal/ipc/server/RemoteSender;

    move-result-object v1

    invoke-virtual {v0, v1}, Ltas/internal/ipc/server/ServerConnection;->unregisterSender(Ltas/internal/ipc/server/RemoteSender;)V

    .line 690
    return-void
.end method

.method private unwatchAnonymousReceiverFromServer(Ltas/internal/ipc/SenderManager$SenderWrapper;)V
    .locals 2
    .param p1, "sender"    # Ltas/internal/ipc/SenderManager$SenderWrapper;

    .prologue
    .line 719
    iget-object v0, p0, Ltas/internal/ipc/SenderManager;->mServer:Ltas/internal/ipc/server/ServerConnection;

    invoke-static {p1}, Ltas/internal/ipc/server/RemoteSender;->obtain(Ltas/internal/ipc/server/RemoteSender;)Ltas/internal/ipc/server/RemoteSender;

    move-result-object v1

    invoke-virtual {v0, v1}, Ltas/internal/ipc/server/ServerConnection;->stopWatchingAnonymousReceiver(Ltas/internal/ipc/server/RemoteSender;)V

    .line 718
    return-void
.end method

.method private unwatchAnonymousReceiverLocked(Ltas/internal/ipc/Sender;)V
    .locals 5
    .param p1, "sender"    # Ltas/internal/ipc/Sender;

    .prologue
    .line 273
    iget-object v3, p1, Ltas/internal/ipc/Sender;->mToken:Ltas/internal/ipc/SenderManager$SenderWrapper;

    .line 274
    .local v3, "sw":Ltas/internal/ipc/SenderManager$SenderWrapper;
    invoke-static {v3}, Ltas/internal/ipc/SenderManager$SenderWrapper;->-get4(Ltas/internal/ipc/SenderManager$SenderWrapper;)I

    move-result v4

    if-nez v4, :cond_1

    .line 275
    invoke-direct {p0, v3}, Ltas/internal/ipc/SenderManager;->unwatchAnonymousReceiverFromServer(Ltas/internal/ipc/SenderManager$SenderWrapper;)V

    .line 272
    :cond_0
    return-void

    .line 277
    :cond_1
    invoke-static {v3}, Ltas/internal/ipc/SenderManager$SenderWrapper;->-get2(Ltas/internal/ipc/SenderManager$SenderWrapper;)Landroid/util/ArrayMap;

    move-result-object v4

    invoke-virtual {v4}, Landroid/util/ArrayMap;->values()Ljava/util/Collection;

    move-result-object v2

    .line 278
    .local v2, "rws":Ljava/util/Collection;, "Ljava/util/Collection<Ltas/internal/ipc/SenderManager$ReceiverWrapper;>;"
    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    .local v1, "rw$iterator":Ljava/util/Iterator;
    :cond_2
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_0

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/ipc/SenderManager$ReceiverWrapper;

    .line 279
    .local v0, "rw":Ltas/internal/ipc/SenderManager$ReceiverWrapper;
    if-eqz v0, :cond_2

    invoke-direct {p0, p1, v0}, Ltas/internal/ipc/SenderManager;->dispatchOffline(Ltas/internal/ipc/Sender;Ltas/internal/ipc/server/RemoteReceiver;)V

    goto :goto_0
.end method

.method private unwatchReceiverFromServer(Ltas/internal/ipc/SenderManager$SenderWrapper;Ljava/lang/String;)V
    .locals 2
    .param p1, "sender"    # Ltas/internal/ipc/SenderManager$SenderWrapper;
    .param p2, "target"    # Ljava/lang/String;

    .prologue
    .line 709
    invoke-static {p1}, Ltas/internal/ipc/server/RemoteSender;->obtain(Ltas/internal/ipc/server/RemoteSender;)Ltas/internal/ipc/server/RemoteSender;

    move-result-object v0

    .line 710
    .local v0, "s":Ltas/internal/ipc/server/RemoteSender;
    iput-object p2, v0, Ltas/internal/ipc/server/RemoteSender;->target:Ljava/lang/String;

    .line 711
    iget-object v1, p0, Ltas/internal/ipc/SenderManager;->mServer:Ltas/internal/ipc/server/ServerConnection;

    invoke-virtual {v1, v0}, Ltas/internal/ipc/server/ServerConnection;->stopWatchingReceiver(Ltas/internal/ipc/server/RemoteSender;)V

    .line 708
    return-void
.end method

.method private unwatchReceiverLocked(Ltas/internal/ipc/Sender;Ljava/lang/String;)V
    .locals 8
    .param p1, "sender"    # Ltas/internal/ipc/Sender;
    .param p2, "receiver"    # Ljava/lang/String;

    .prologue
    .line 223
    iget-object v5, p1, Ltas/internal/ipc/Sender;->mToken:Ltas/internal/ipc/SenderManager$SenderWrapper;

    .line 224
    .local v5, "sw":Ltas/internal/ipc/SenderManager$SenderWrapper;
    invoke-static {v5}, Ltas/internal/ipc/SenderManager$SenderWrapper;->-get5(Ltas/internal/ipc/SenderManager$SenderWrapper;)Landroid/util/ArrayMap;

    move-result-object v6

    invoke-virtual {v6, p2}, Landroid/util/ArrayMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    .line 225
    .local v1, "ref":Ljava/lang/Integer;
    if-eqz v1, :cond_1

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v6

    add-int/lit8 v0, v6, -0x1

    .line 226
    .local v0, "dec":I
    :goto_0
    invoke-static {v5}, Ltas/internal/ipc/SenderManager$SenderWrapper;->-get5(Ltas/internal/ipc/SenderManager$SenderWrapper;)Landroid/util/ArrayMap;

    move-result-object v6

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-virtual {v6, p2, v7}, Landroid/util/ArrayMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 228
    if-nez v0, :cond_2

    .line 229
    invoke-direct {p0, v5, p2}, Ltas/internal/ipc/SenderManager;->unwatchReceiverFromServer(Ltas/internal/ipc/SenderManager$SenderWrapper;Ljava/lang/String;)V

    .line 222
    :cond_0
    return-void

    .line 225
    .end local v0    # "dec":I
    :cond_1
    const/4 v0, 0x0

    .restart local v0    # "dec":I
    goto :goto_0

    .line 231
    :cond_2
    invoke-static {v5}, Ltas/internal/ipc/SenderManager$SenderWrapper;->-get2(Ltas/internal/ipc/SenderManager$SenderWrapper;)Landroid/util/ArrayMap;

    move-result-object v6

    invoke-virtual {v6}, Landroid/util/ArrayMap;->values()Ljava/util/Collection;

    move-result-object v4

    .line 232
    .local v4, "rws":Ljava/util/Collection;, "Ljava/util/Collection<Ltas/internal/ipc/SenderManager$ReceiverWrapper;>;"
    invoke-interface {v4}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v3

    .local v3, "rw$iterator":Ljava/util/Iterator;
    :cond_3
    :goto_1
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_0

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ltas/internal/ipc/SenderManager$ReceiverWrapper;

    .line 233
    .local v2, "rw":Ltas/internal/ipc/SenderManager$ReceiverWrapper;
    if-eqz v2, :cond_3

    iget-object v6, v2, Ltas/internal/ipc/SenderManager$ReceiverWrapper;->name:Ljava/lang/String;

    invoke-virtual {v6, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_3

    .line 234
    invoke-direct {p0, p1, v2}, Ltas/internal/ipc/SenderManager;->dispatchOffline(Ltas/internal/ipc/Sender;Ltas/internal/ipc/server/RemoteReceiver;)V

    goto :goto_1
.end method

.method private updateToServer(Ltas/internal/ipc/SenderManager$SenderWrapper;)V
    .locals 2
    .param p1, "sender"    # Ltas/internal/ipc/SenderManager$SenderWrapper;

    .prologue
    .line 695
    iget-object v0, p0, Ltas/internal/ipc/SenderManager;->mServer:Ltas/internal/ipc/server/ServerConnection;

    invoke-static {p1}, Ltas/internal/ipc/server/RemoteSender;->obtain(Ltas/internal/ipc/server/RemoteSender;)Ltas/internal/ipc/server/RemoteSender;

    move-result-object v1

    invoke-virtual {v0, v1}, Ltas/internal/ipc/server/ServerConnection;->updateSender(Ltas/internal/ipc/server/RemoteSender;)V

    .line 694
    return-void
.end method

.method private watchAnonymousReceiverFromServer(Ltas/internal/ipc/SenderManager$SenderWrapper;)V
    .locals 2
    .param p1, "sender"    # Ltas/internal/ipc/SenderManager$SenderWrapper;

    .prologue
    .line 715
    iget-object v0, p0, Ltas/internal/ipc/SenderManager;->mServer:Ltas/internal/ipc/server/ServerConnection;

    invoke-static {p1}, Ltas/internal/ipc/server/RemoteSender;->obtain(Ltas/internal/ipc/server/RemoteSender;)Ltas/internal/ipc/server/RemoteSender;

    move-result-object v1

    invoke-virtual {v0, v1}, Ltas/internal/ipc/server/ServerConnection;->startWatchingAnonymousReceiver(Ltas/internal/ipc/server/RemoteSender;)V

    .line 714
    return-void
.end method

.method private watchAnonymousReceiverLocked(Ltas/internal/ipc/Sender;)V
    .locals 6
    .param p1, "sender"    # Ltas/internal/ipc/Sender;

    .prologue
    .line 261
    iget-object v3, p1, Ltas/internal/ipc/Sender;->mToken:Ltas/internal/ipc/SenderManager$SenderWrapper;

    .line 262
    .local v3, "sw":Ltas/internal/ipc/SenderManager$SenderWrapper;
    invoke-static {v3}, Ltas/internal/ipc/SenderManager$SenderWrapper;->-get4(Ltas/internal/ipc/SenderManager$SenderWrapper;)I

    move-result v4

    const/4 v5, 0x1

    if-ne v4, v5, :cond_1

    .line 263
    invoke-direct {p0, v3}, Ltas/internal/ipc/SenderManager;->watchAnonymousReceiverFromServer(Ltas/internal/ipc/SenderManager$SenderWrapper;)V

    .line 260
    :cond_0
    return-void

    .line 265
    :cond_1
    invoke-static {v3}, Ltas/internal/ipc/SenderManager$SenderWrapper;->-get2(Ltas/internal/ipc/SenderManager$SenderWrapper;)Landroid/util/ArrayMap;

    move-result-object v4

    invoke-virtual {v4}, Landroid/util/ArrayMap;->values()Ljava/util/Collection;

    move-result-object v2

    .line 266
    .local v2, "rws":Ljava/util/Collection;, "Ljava/util/Collection<Ltas/internal/ipc/SenderManager$ReceiverWrapper;>;"
    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    .local v1, "rw$iterator":Ljava/util/Iterator;
    :cond_2
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_0

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/ipc/SenderManager$ReceiverWrapper;

    .line 267
    .local v0, "rw":Ltas/internal/ipc/SenderManager$ReceiverWrapper;
    if-eqz v0, :cond_2

    invoke-direct {p0, p1, v0}, Ltas/internal/ipc/SenderManager;->dispatchOnline(Ltas/internal/ipc/Sender;Ltas/internal/ipc/server/RemoteReceiver;)V

    goto :goto_0
.end method

.method private watchReceiverFromServer(Ltas/internal/ipc/SenderManager$SenderWrapper;Ljava/lang/String;)V
    .locals 2
    .param p1, "sender"    # Ltas/internal/ipc/SenderManager$SenderWrapper;
    .param p2, "target"    # Ljava/lang/String;

    .prologue
    .line 703
    invoke-static {p1}, Ltas/internal/ipc/server/RemoteSender;->obtain(Ltas/internal/ipc/server/RemoteSender;)Ltas/internal/ipc/server/RemoteSender;

    move-result-object v0

    .line 704
    .local v0, "s":Ltas/internal/ipc/server/RemoteSender;
    iput-object p2, v0, Ltas/internal/ipc/server/RemoteSender;->target:Ljava/lang/String;

    .line 705
    iget-object v1, p0, Ltas/internal/ipc/SenderManager;->mServer:Ltas/internal/ipc/server/ServerConnection;

    invoke-virtual {v1, v0}, Ltas/internal/ipc/server/ServerConnection;->startWatchingReceiver(Ltas/internal/ipc/server/RemoteSender;)V

    .line 702
    return-void
.end method

.method private watchReceiverLocked(Ltas/internal/ipc/Sender;Ljava/lang/String;)V
    .locals 8
    .param p1, "sender"    # Ltas/internal/ipc/Sender;
    .param p2, "receiver"    # Ljava/lang/String;

    .prologue
    .line 206
    iget-object v5, p1, Ltas/internal/ipc/Sender;->mToken:Ltas/internal/ipc/SenderManager$SenderWrapper;

    .line 207
    .local v5, "sw":Ltas/internal/ipc/SenderManager$SenderWrapper;
    invoke-static {v5}, Ltas/internal/ipc/SenderManager$SenderWrapper;->-get5(Ltas/internal/ipc/SenderManager$SenderWrapper;)Landroid/util/ArrayMap;

    move-result-object v6

    invoke-virtual {v6, p2}, Landroid/util/ArrayMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    .line 208
    .local v1, "ref":Ljava/lang/Integer;
    if-eqz v1, :cond_1

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v6

    add-int/lit8 v0, v6, 0x1

    .line 209
    .local v0, "inc":I
    :goto_0
    invoke-static {v5}, Ltas/internal/ipc/SenderManager$SenderWrapper;->-get5(Ltas/internal/ipc/SenderManager$SenderWrapper;)Landroid/util/ArrayMap;

    move-result-object v6

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-virtual {v6, p2, v7}, Landroid/util/ArrayMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 210
    const/4 v6, 0x1

    if-ne v0, v6, :cond_2

    .line 211
    invoke-direct {p0, v5, p2}, Ltas/internal/ipc/SenderManager;->watchReceiverFromServer(Ltas/internal/ipc/SenderManager$SenderWrapper;Ljava/lang/String;)V

    .line 205
    :cond_0
    return-void

    .line 208
    .end local v0    # "inc":I
    :cond_1
    const/4 v0, 0x1

    .restart local v0    # "inc":I
    goto :goto_0

    .line 213
    :cond_2
    invoke-static {v5}, Ltas/internal/ipc/SenderManager$SenderWrapper;->-get2(Ltas/internal/ipc/SenderManager$SenderWrapper;)Landroid/util/ArrayMap;

    move-result-object v6

    invoke-virtual {v6}, Landroid/util/ArrayMap;->values()Ljava/util/Collection;

    move-result-object v4

    .line 214
    .local v4, "rws":Ljava/util/Collection;, "Ljava/util/Collection<Ltas/internal/ipc/SenderManager$ReceiverWrapper;>;"
    invoke-interface {v4}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v3

    .local v3, "rw$iterator":Ljava/util/Iterator;
    :cond_3
    :goto_1
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_0

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ltas/internal/ipc/SenderManager$ReceiverWrapper;

    .line 215
    .local v2, "rw":Ltas/internal/ipc/SenderManager$ReceiverWrapper;
    if-eqz v2, :cond_3

    iget-object v6, v2, Ltas/internal/ipc/SenderManager$ReceiverWrapper;->name:Ljava/lang/String;

    invoke-virtual {v6, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_3

    .line 216
    invoke-direct {p0, p1, v2}, Ltas/internal/ipc/SenderManager;->dispatchOnline(Ltas/internal/ipc/Sender;Ltas/internal/ipc/server/RemoteReceiver;)V

    goto :goto_1
.end method


# virtual methods
.method initialize(Ltas/internal/ipc/Sender;)V
    .locals 5
    .param p1, "sender"    # Ltas/internal/ipc/Sender;

    .prologue
    const/4 v4, 0x0

    .line 66
    const-string/jumbo v1, "TasIPC<SenderManager>"

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v3, p1, Ltas/internal/ipc/Sender;->name:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string/jumbo v3, "@"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {p1}, Ltas/internal/ipc/Sender;->hashCode()I

    move-result v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string/jumbo v3, " init."

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 69
    iget-object v1, p0, Ltas/internal/ipc/SenderManager;->mContext:Landroid/content/Context;

    if-nez v1, :cond_0

    .line 70
    invoke-virtual {p1}, Ltas/internal/ipc/Sender;->getContext()Landroid/content/Context;

    move-result-object v1

    iput-object v1, p0, Ltas/internal/ipc/SenderManager;->mContext:Landroid/content/Context;

    .line 73
    :cond_0
    iget-object v1, p0, Ltas/internal/ipc/SenderManager;->mContext:Landroid/content/Context;

    invoke-direct {p0, v1}, Ltas/internal/ipc/SenderManager;->connectToServer(Landroid/content/Context;)V

    .line 75
    iget-object v1, p1, Ltas/internal/ipc/Sender;->name:Ljava/lang/String;

    invoke-direct {p0, v1}, Ltas/internal/ipc/SenderManager;->findSender(Ljava/lang/String;)Ltas/internal/ipc/SenderManager$SenderWrapper;

    move-result-object v0

    .line 76
    .local v0, "sw":Ltas/internal/ipc/SenderManager$SenderWrapper;
    if-nez v0, :cond_1

    .line 77
    new-instance v0, Ltas/internal/ipc/SenderManager$SenderWrapper;

    .end local v0    # "sw":Ltas/internal/ipc/SenderManager$SenderWrapper;
    invoke-direct {v0, p0, p1, v4}, Ltas/internal/ipc/SenderManager$SenderWrapper;-><init>(Ltas/internal/ipc/SenderManager;Ltas/internal/ipc/Sender;Ltas/internal/ipc/SenderManager$SenderWrapper;)V

    .line 78
    .restart local v0    # "sw":Ltas/internal/ipc/SenderManager$SenderWrapper;
    iget-object v1, p0, Ltas/internal/ipc/SenderManager;->mSenders:Ljava/util/List;

    invoke-interface {v1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 80
    :cond_1
    iput-object v0, p1, Ltas/internal/ipc/Sender;->mToken:Ltas/internal/ipc/SenderManager$SenderWrapper;

    .line 64
    return-void
.end method

.method isMultiReceiverThread()Z
    .locals 1

    .prologue
    .line 558
    iget-boolean v0, p0, Ltas/internal/ipc/SenderManager;->mMultiReceiverThread:Z

    return v0
.end method

.method offline(Ltas/internal/ipc/Sender;)V
    .locals 7
    .param p1, "sender"    # Ltas/internal/ipc/Sender;

    .prologue
    const/4 v6, 0x0

    .line 134
    iget-object v0, p1, Ltas/internal/ipc/Sender;->mToken:Ltas/internal/ipc/SenderManager$SenderWrapper;

    .line 135
    .local v0, "sw":Ltas/internal/ipc/SenderManager$SenderWrapper;
    if-eqz v0, :cond_4

    invoke-static {v0}, Ltas/internal/ipc/SenderManager$SenderWrapper;->-get1(Ltas/internal/ipc/SenderManager$SenderWrapper;)Ljava/util/List;

    move-result-object v3

    invoke-interface {v3, p1}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_4

    .line 137
    const-string/jumbo v3, "TasIPC<SenderManager>"

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v5, p1, Ltas/internal/ipc/Sender;->name:Ljava/lang/String;

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string/jumbo v5, "@"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {p1}, Ltas/internal/ipc/Sender;->hashCode()I

    move-result v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string/jumbo v5, " offline."

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v3, v4}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 140
    iget-object v3, p1, Ltas/internal/ipc/Sender;->mDispatcher:Ltas/internal/ipc/Dispatcher;

    invoke-virtual {v3}, Ltas/internal/ipc/Dispatcher;->deactivate()V

    .line 141
    invoke-static {v0}, Ltas/internal/ipc/SenderManager$SenderWrapper;->-get1(Ltas/internal/ipc/SenderManager$SenderWrapper;)Ljava/util/List;

    move-result-object v3

    invoke-interface {v3, p1}, Ljava/util/List;->remove(Ljava/lang/Object;)Z

    .line 143
    invoke-static {v0}, Ltas/internal/ipc/SenderManager$SenderWrapper;->-get5(Ltas/internal/ipc/SenderManager$SenderWrapper;)Landroid/util/ArrayMap;

    move-result-object v4

    monitor-enter v4

    .line 144
    :try_start_0
    iget-object v3, p1, Ltas/internal/ipc/Sender;->mWatchList:Ljava/util/List;

    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v2

    .local v2, "watch$iterator":Ljava/util/Iterator;
    :cond_0
    :goto_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_1

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    .line 145
    .local v1, "watch":Ljava/lang/String;
    if-eqz v1, :cond_0

    invoke-direct {p0, p1, v1}, Ltas/internal/ipc/SenderManager;->unwatchReceiverLocked(Ltas/internal/ipc/Sender;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    .line 143
    .end local v1    # "watch":Ljava/lang/String;
    .end local v2    # "watch$iterator":Ljava/util/Iterator;
    :catchall_0
    move-exception v3

    monitor-exit v4

    throw v3

    .line 148
    .restart local v2    # "watch$iterator":Ljava/util/Iterator;
    :cond_1
    :try_start_1
    invoke-static {v0}, Ltas/internal/ipc/SenderManager$SenderWrapper;->-get3(Ltas/internal/ipc/SenderManager$SenderWrapper;)Z

    move-result v3

    if-eqz v3, :cond_2

    .line 149
    invoke-direct {p0, p1}, Ltas/internal/ipc/SenderManager;->unwatchAnonymousReceiverLocked(Ltas/internal/ipc/Sender;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :cond_2
    monitor-exit v4

    .line 153
    invoke-virtual {v0}, Ltas/internal/ipc/SenderManager$SenderWrapper;->dec()I

    .line 154
    invoke-virtual {v0}, Ltas/internal/ipc/SenderManager$SenderWrapper;->ref()I

    move-result v3

    if-nez v3, :cond_3

    .line 155
    invoke-direct {p0, v0}, Ltas/internal/ipc/SenderManager;->unregisterToServer(Ltas/internal/ipc/SenderManager$SenderWrapper;)V

    .line 158
    :cond_3
    iput-boolean v6, p1, Ltas/internal/ipc/Sender;->mOnline:Z

    .line 133
    .end local v2    # "watch$iterator":Ljava/util/Iterator;
    :cond_4
    return-void
.end method

.method public onReceiverOffline(Ltas/internal/ipc/server/RemoteSender;Ltas/internal/ipc/server/RemoteReceiver;)V
    .locals 5
    .param p1, "s"    # Ltas/internal/ipc/server/RemoteSender;
    .param p2, "r"    # Ltas/internal/ipc/server/RemoteReceiver;

    .prologue
    .line 330
    const-string/jumbo v2, "TasIPC<SenderManager>"

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v4, "receiver ["

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget-object v4, p2, Ltas/internal/ipc/server/RemoteReceiver;->name:Ljava/lang/String;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string/jumbo v4, "] offline."

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 331
    invoke-virtual {p1}, Ltas/internal/ipc/server/RemoteSender;->getid()J

    move-result-wide v2

    invoke-direct {p0, v2, v3}, Ltas/internal/ipc/SenderManager;->findSender(J)Ltas/internal/ipc/SenderManager$SenderWrapper;

    move-result-object v1

    .line 332
    .local v1, "sw":Ltas/internal/ipc/SenderManager$SenderWrapper;
    if-nez v1, :cond_0

    .line 333
    const-string/jumbo v2, "TasIPC<SenderManager>"

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v4, "local sender not found => "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget-object v4, p1, Ltas/internal/ipc/server/RemoteSender;->name:Ljava/lang/String;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 334
    return-void

    .line 336
    :cond_0
    invoke-virtual {v1, p2}, Ltas/internal/ipc/SenderManager$SenderWrapper;->findReceiver(Ltas/internal/ipc/server/RemoteReceiver;)Ltas/internal/ipc/SenderManager$ReceiverWrapper;

    move-result-object v0

    .line 337
    .local v0, "rw":Ltas/internal/ipc/SenderManager$ReceiverWrapper;
    if-nez v0, :cond_1

    .line 338
    const-string/jumbo v2, "TasIPC<SenderManager>"

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v4, "receiver wrapper not found => "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget-object v4, p2, Ltas/internal/ipc/server/RemoteReceiver;->name:Ljava/lang/String;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 339
    return-void

    .line 341
    :cond_1
    invoke-static {v1, v0}, Ltas/internal/ipc/SenderManager$SenderWrapper;->-wrap2(Ltas/internal/ipc/SenderManager$SenderWrapper;Ltas/internal/ipc/SenderManager$ReceiverWrapper;)V

    .line 329
    return-void
.end method

.method public onReceiverOnline(Ltas/internal/ipc/server/RemoteSender;Ltas/internal/ipc/server/RemoteReceiver;)V
    .locals 3
    .param p1, "s"    # Ltas/internal/ipc/server/RemoteSender;
    .param p2, "r"    # Ltas/internal/ipc/server/RemoteReceiver;

    .prologue
    .line 324
    const-string/jumbo v0, "TasIPC<SenderManager>"

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "receiver ["

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p2, Ltas/internal/ipc/server/RemoteReceiver;->name:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string/jumbo v2, "] online."

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 325
    new-instance v0, Ltas/internal/ipc/SenderManager$ReceiverWrapper;

    invoke-direct {v0, p0, p1, p2}, Ltas/internal/ipc/SenderManager$ReceiverWrapper;-><init>(Ltas/internal/ipc/SenderManager;Ltas/internal/ipc/server/RemoteSender;Ltas/internal/ipc/server/RemoteReceiver;)V

    invoke-virtual {v0}, Ltas/internal/ipc/SenderManager$ReceiverWrapper;->connect()V

    .line 323
    return-void
.end method

.method public onReceiverUpdate(Ltas/internal/ipc/server/RemoteSender;Ltas/internal/ipc/server/RemoteReceiver;)V
    .locals 5
    .param p1, "s"    # Ltas/internal/ipc/server/RemoteSender;
    .param p2, "r"    # Ltas/internal/ipc/server/RemoteReceiver;

    .prologue
    .line 346
    const-string/jumbo v2, "TasIPC<SenderManager>"

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v4, "receiver ["

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget-object v4, p2, Ltas/internal/ipc/server/RemoteReceiver;->name:Ljava/lang/String;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string/jumbo v4, "] update."

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 347
    invoke-virtual {p1}, Ltas/internal/ipc/server/RemoteSender;->getid()J

    move-result-wide v2

    invoke-direct {p0, v2, v3}, Ltas/internal/ipc/SenderManager;->findSender(J)Ltas/internal/ipc/SenderManager$SenderWrapper;

    move-result-object v1

    .line 348
    .local v1, "sw":Ltas/internal/ipc/SenderManager$SenderWrapper;
    if-nez v1, :cond_0

    .line 349
    const-string/jumbo v2, "TasIPC<SenderManager>"

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v4, "local sender not found => "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget-object v4, p1, Ltas/internal/ipc/server/RemoteSender;->name:Ljava/lang/String;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 350
    return-void

    .line 352
    :cond_0
    invoke-virtual {v1, p2}, Ltas/internal/ipc/SenderManager$SenderWrapper;->findReceiver(Ltas/internal/ipc/server/RemoteReceiver;)Ltas/internal/ipc/SenderManager$ReceiverWrapper;

    move-result-object v0

    .line 353
    .local v0, "rw":Ltas/internal/ipc/SenderManager$ReceiverWrapper;
    if-nez v0, :cond_1

    .line 354
    const-string/jumbo v2, "TasIPC<SenderManager>"

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v4, "receiver wrapper not found => "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget-object v4, p2, Ltas/internal/ipc/server/RemoteReceiver;->name:Ljava/lang/String;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 355
    return-void

    .line 357
    :cond_1
    invoke-static {v1, v0}, Ltas/internal/ipc/SenderManager$SenderWrapper;->-wrap4(Ltas/internal/ipc/SenderManager$SenderWrapper;Ltas/internal/ipc/SenderManager$ReceiverWrapper;)V

    .line 345
    return-void
.end method

.method online(Ltas/internal/ipc/Sender;)V
    .locals 7
    .param p1, "sender"    # Ltas/internal/ipc/Sender;

    .prologue
    const/4 v6, 0x1

    .line 98
    iget-object v0, p1, Ltas/internal/ipc/Sender;->mToken:Ltas/internal/ipc/SenderManager$SenderWrapper;

    .line 99
    .local v0, "sw":Ltas/internal/ipc/SenderManager$SenderWrapper;
    if-eqz v0, :cond_0

    invoke-static {v0}, Ltas/internal/ipc/SenderManager$SenderWrapper;->-get1(Ltas/internal/ipc/SenderManager$SenderWrapper;)Ljava/util/List;

    move-result-object v3

    invoke-interface {v3, p1}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_1

    .line 97
    :cond_0
    :goto_0
    return-void

    .line 101
    :cond_1
    const-string/jumbo v3, "TasIPC<SenderManager>"

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v5, p1, Ltas/internal/ipc/Sender;->name:Ljava/lang/String;

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string/jumbo v5, "@"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {p1}, Ltas/internal/ipc/Sender;->hashCode()I

    move-result v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string/jumbo v5, " online."

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v3, v4}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 104
    iget-object v3, p1, Ltas/internal/ipc/Sender;->mDispatcher:Ltas/internal/ipc/Dispatcher;

    if-nez v3, :cond_2

    .line 106
    new-instance v3, Ltas/internal/ipc/Dispatcher;

    iget-object v4, p1, Ltas/internal/ipc/Sender;->mLooper:Landroid/os/Looper;

    invoke-direct {v3, v4, p1}, Ltas/internal/ipc/Dispatcher;-><init>(Landroid/os/Looper;Ltas/internal/ipc/Sender;)V

    .line 105
    iput-object v3, p1, Ltas/internal/ipc/Sender;->mDispatcher:Ltas/internal/ipc/Dispatcher;

    .line 108
    :cond_2
    iget-object v3, p1, Ltas/internal/ipc/Sender;->mDispatcher:Ltas/internal/ipc/Dispatcher;

    invoke-virtual {v3}, Ltas/internal/ipc/Dispatcher;->activate()V

    .line 109
    invoke-static {v0}, Ltas/internal/ipc/SenderManager$SenderWrapper;->-get1(Ltas/internal/ipc/SenderManager$SenderWrapper;)Ljava/util/List;

    move-result-object v3

    invoke-interface {v3, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 110
    invoke-virtual {v0}, Ltas/internal/ipc/SenderManager$SenderWrapper;->inc()I

    .line 112
    invoke-virtual {v0}, Ltas/internal/ipc/SenderManager$SenderWrapper;->ref()I

    move-result v3

    if-ne v3, v6, :cond_4

    .line 113
    iget-object v3, p1, Ltas/internal/ipc/Sender;->mExtra:Landroid/os/Bundle;

    invoke-static {v0, v3}, Ltas/internal/ipc/SenderManager$SenderWrapper;->-set0(Ltas/internal/ipc/SenderManager$SenderWrapper;Landroid/os/Bundle;)Landroid/os/Bundle;

    move-result-object v3

    iput-object v3, v0, Ltas/internal/ipc/SenderManager$SenderWrapper;->extra:Landroid/os/Bundle;

    .line 114
    invoke-direct {p0, v0}, Ltas/internal/ipc/SenderManager;->registerToServer(Ltas/internal/ipc/SenderManager$SenderWrapper;)V

    .line 119
    :goto_1
    invoke-static {v0}, Ltas/internal/ipc/SenderManager$SenderWrapper;->-get5(Ltas/internal/ipc/SenderManager$SenderWrapper;)Landroid/util/ArrayMap;

    move-result-object v4

    monitor-enter v4

    .line 120
    :try_start_0
    iget-object v3, p1, Ltas/internal/ipc/Sender;->mWatchList:Ljava/util/List;

    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v2

    .local v2, "watch$iterator":Ljava/util/Iterator;
    :cond_3
    :goto_2
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_5

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    .line 121
    .local v1, "watch":Ljava/lang/String;
    if-eqz v1, :cond_3

    invoke-direct {p0, p1, v1}, Ltas/internal/ipc/SenderManager;->watchReceiverLocked(Ltas/internal/ipc/Sender;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_2

    .line 119
    .end local v1    # "watch":Ljava/lang/String;
    .end local v2    # "watch$iterator":Ljava/util/Iterator;
    :catchall_0
    move-exception v3

    monitor-exit v4

    throw v3

    .line 116
    :cond_4
    invoke-static {v0}, Ltas/internal/ipc/SenderManager$SenderWrapper;->-get0(Ltas/internal/ipc/SenderManager$SenderWrapper;)Landroid/os/Bundle;

    move-result-object v3

    iput-object v3, p1, Ltas/internal/ipc/Sender;->mExtra:Landroid/os/Bundle;

    goto :goto_1

    .line 124
    .restart local v2    # "watch$iterator":Ljava/util/Iterator;
    :cond_5
    :try_start_1
    invoke-static {v0}, Ltas/internal/ipc/SenderManager$SenderWrapper;->-get3(Ltas/internal/ipc/SenderManager$SenderWrapper;)Z

    move-result v3

    if-eqz v3, :cond_6

    .line 125
    invoke-direct {p0, p1}, Ltas/internal/ipc/SenderManager;->watchAnonymousReceiverLocked(Ltas/internal/ipc/Sender;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :cond_6
    monitor-exit v4

    .line 129
    iput-boolean v6, p1, Ltas/internal/ipc/Sender;->mOnline:Z

    goto/16 :goto_0
.end method

.method release(Ltas/internal/ipc/Sender;)V
    .locals 4
    .param p1, "sender"    # Ltas/internal/ipc/Sender;

    .prologue
    .line 85
    const-string/jumbo v1, "TasIPC<SenderManager>"

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v3, p1, Ltas/internal/ipc/Sender;->name:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string/jumbo v3, "@"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {p1}, Ltas/internal/ipc/Sender;->hashCode()I

    move-result v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string/jumbo v3, " release."

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 88
    invoke-virtual {p0, p1}, Ltas/internal/ipc/SenderManager;->offline(Ltas/internal/ipc/Sender;)V

    .line 89
    iget-object v0, p1, Ltas/internal/ipc/Sender;->mToken:Ltas/internal/ipc/SenderManager$SenderWrapper;

    .line 90
    .local v0, "sw":Ltas/internal/ipc/SenderManager$SenderWrapper;
    invoke-virtual {v0}, Ltas/internal/ipc/SenderManager$SenderWrapper;->ref()I

    move-result v1

    if-nez v1, :cond_0

    .line 91
    iget-object v1, p0, Ltas/internal/ipc/SenderManager;->mSenders:Ljava/util/List;

    invoke-interface {v1, v0}, Ljava/util/List;->remove(Ljava/lang/Object;)Z

    .line 93
    :cond_0
    const/4 v1, 0x0

    iput-object v1, p1, Ltas/internal/ipc/Sender;->mToken:Ltas/internal/ipc/SenderManager$SenderWrapper;

    .line 94
    invoke-direct {p0}, Ltas/internal/ipc/SenderManager;->disconnectFromServer()V

    .line 83
    return-void
.end method

.method setMultiReceiverThread(Z)V
    .locals 0
    .param p1, "multi"    # Z

    .prologue
    .line 554
    iput-boolean p1, p0, Ltas/internal/ipc/SenderManager;->mMultiReceiverThread:Z

    .line 553
    return-void
.end method

.method unwatchAnonymousReceiver(Ltas/internal/ipc/Sender;)V
    .locals 3
    .param p1, "sender"    # Ltas/internal/ipc/Sender;

    .prologue
    .line 252
    iget-object v0, p1, Ltas/internal/ipc/Sender;->mToken:Ltas/internal/ipc/SenderManager$SenderWrapper;

    .line 253
    .local v0, "sw":Ltas/internal/ipc/SenderManager$SenderWrapper;
    invoke-static {v0}, Ltas/internal/ipc/SenderManager$SenderWrapper;->-get5(Ltas/internal/ipc/SenderManager$SenderWrapper;)Landroid/util/ArrayMap;

    move-result-object v2

    monitor-enter v2

    .line 254
    const/4 v1, 0x0

    :try_start_0
    invoke-static {v0, v1}, Ltas/internal/ipc/SenderManager$SenderWrapper;->-set1(Ltas/internal/ipc/SenderManager$SenderWrapper;Z)Z

    .line 255
    invoke-static {v0}, Ltas/internal/ipc/SenderManager$SenderWrapper;->-get4(Ltas/internal/ipc/SenderManager$SenderWrapper;)I

    move-result v1

    add-int/lit8 v1, v1, -0x1

    invoke-static {v0, v1}, Ltas/internal/ipc/SenderManager$SenderWrapper;->-set2(Ltas/internal/ipc/SenderManager$SenderWrapper;I)I

    .line 256
    invoke-direct {p0, p1}, Ltas/internal/ipc/SenderManager;->unwatchAnonymousReceiverLocked(Ltas/internal/ipc/Sender;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit v2

    .line 251
    return-void

    .line 253
    :catchall_0
    move-exception v1

    monitor-exit v2

    throw v1
.end method

.method unwatchReceiver(Ltas/internal/ipc/Sender;Ljava/lang/String;)V
    .locals 4
    .param p1, "sender"    # Ltas/internal/ipc/Sender;
    .param p2, "receiver"    # Ljava/lang/String;

    .prologue
    .line 186
    invoke-virtual {p1, p2}, Ltas/internal/ipc/Sender;->isWatchingReceiver(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_0

    .line 187
    return-void

    .line 191
    :cond_0
    const-string/jumbo v1, "TasIPC<SenderManager>"

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v3, p1, Ltas/internal/ipc/Sender;->name:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string/jumbo v3, "@"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {p1}, Ltas/internal/ipc/Sender;->hashCode()I

    move-result v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    .line 192
    const-string/jumbo v3, " un-watches "

    .line 191
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 195
    iget-object v1, p1, Ltas/internal/ipc/Sender;->mWatchList:Ljava/util/List;

    invoke-interface {v1, p2}, Ljava/util/List;->remove(Ljava/lang/Object;)Z

    .line 197
    iget-object v0, p1, Ltas/internal/ipc/Sender;->mToken:Ltas/internal/ipc/SenderManager$SenderWrapper;

    .line 198
    .local v0, "sw":Ltas/internal/ipc/SenderManager$SenderWrapper;
    if-eqz v0, :cond_1

    .line 199
    invoke-static {v0}, Ltas/internal/ipc/SenderManager$SenderWrapper;->-get5(Ltas/internal/ipc/SenderManager$SenderWrapper;)Landroid/util/ArrayMap;

    move-result-object v1

    monitor-enter v1

    .line 200
    :try_start_0
    invoke-direct {p0, p1, p2}, Ltas/internal/ipc/SenderManager;->unwatchReceiverLocked(Ltas/internal/ipc/Sender;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit v1

    .line 185
    :cond_1
    return-void

    .line 199
    :catchall_0
    move-exception v2

    monitor-exit v1

    throw v2
.end method

.method watchAnonymousReceiver(Ltas/internal/ipc/Sender;)V
    .locals 3
    .param p1, "sender"    # Ltas/internal/ipc/Sender;

    .prologue
    .line 241
    iget-object v0, p1, Ltas/internal/ipc/Sender;->mToken:Ltas/internal/ipc/SenderManager$SenderWrapper;

    .line 242
    .local v0, "sw":Ltas/internal/ipc/SenderManager$SenderWrapper;
    invoke-static {v0}, Ltas/internal/ipc/SenderManager$SenderWrapper;->-get5(Ltas/internal/ipc/SenderManager$SenderWrapper;)Landroid/util/ArrayMap;

    move-result-object v2

    monitor-enter v2

    .line 243
    const/4 v1, 0x1

    :try_start_0
    invoke-static {v0, v1}, Ltas/internal/ipc/SenderManager$SenderWrapper;->-set1(Ltas/internal/ipc/SenderManager$SenderWrapper;Z)Z

    .line 244
    invoke-static {v0}, Ltas/internal/ipc/SenderManager$SenderWrapper;->-get4(Ltas/internal/ipc/SenderManager$SenderWrapper;)I

    move-result v1

    add-int/lit8 v1, v1, 0x1

    invoke-static {v0, v1}, Ltas/internal/ipc/SenderManager$SenderWrapper;->-set2(Ltas/internal/ipc/SenderManager$SenderWrapper;I)I

    .line 245
    iget-boolean v1, p1, Ltas/internal/ipc/Sender;->mOnline:Z

    if-eqz v1, :cond_0

    .line 246
    invoke-direct {p0, p1}, Ltas/internal/ipc/SenderManager;->watchAnonymousReceiverLocked(Ltas/internal/ipc/Sender;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_0
    monitor-exit v2

    .line 240
    return-void

    .line 242
    :catchall_0
    move-exception v1

    monitor-exit v2

    throw v1
.end method

.method watchReceiver(Ltas/internal/ipc/Sender;Ljava/lang/String;)V
    .locals 4
    .param p1, "sender"    # Ltas/internal/ipc/Sender;
    .param p2, "receiver"    # Ljava/lang/String;

    .prologue
    .line 163
    invoke-virtual {p1, p2}, Ltas/internal/ipc/Sender;->isWatchingReceiver(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_0

    .line 164
    return-void

    .line 168
    :cond_0
    const-string/jumbo v1, "TasIPC<SenderManager>"

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v3, p1, Ltas/internal/ipc/Sender;->name:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string/jumbo v3, "@"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {p1}, Ltas/internal/ipc/Sender;->hashCode()I

    move-result v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    .line 169
    const-string/jumbo v3, " watches "

    .line 168
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 172
    iget-object v1, p1, Ltas/internal/ipc/Sender;->mWatchList:Ljava/util/List;

    invoke-interface {v1, p2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 173
    iget-boolean v1, p1, Ltas/internal/ipc/Sender;->mOnline:Z

    if-nez v1, :cond_1

    .line 174
    return-void

    .line 177
    :cond_1
    iget-object v0, p1, Ltas/internal/ipc/Sender;->mToken:Ltas/internal/ipc/SenderManager$SenderWrapper;

    .line 178
    .local v0, "sw":Ltas/internal/ipc/SenderManager$SenderWrapper;
    if-eqz v0, :cond_2

    .line 179
    invoke-static {v0}, Ltas/internal/ipc/SenderManager$SenderWrapper;->-get5(Ltas/internal/ipc/SenderManager$SenderWrapper;)Landroid/util/ArrayMap;

    move-result-object v1

    monitor-enter v1

    .line 180
    :try_start_0
    invoke-direct {p0, p1, p2}, Ltas/internal/ipc/SenderManager;->watchReceiverLocked(Ltas/internal/ipc/Sender;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit v1

    .line 162
    :cond_2
    return-void

    .line 179
    :catchall_0
    move-exception v2

    monitor-exit v1

    throw v2
.end method
