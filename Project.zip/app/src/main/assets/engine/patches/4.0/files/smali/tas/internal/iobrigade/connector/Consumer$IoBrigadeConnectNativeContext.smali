.class final Ltas/internal/iobrigade/connector/Consumer$IoBrigadeConnectNativeContext;
.super Ljava/lang/Object;
.source "Consumer.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltas/internal/iobrigade/connector/Consumer;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x10
    name = "IoBrigadeConnectNativeContext"
.end annotation


# instance fields
.field private mConsumerHandler:Landroid/os/Handler;

.field final synthetic this$0:Ltas/internal/iobrigade/connector/Consumer;


# direct methods
.method public constructor <init>(Ltas/internal/iobrigade/connector/Consumer;I)V
    .locals 3
    .param p2, "attr"    # I

    .prologue
    .line 33
    .local p0, "this":Ltas/internal/iobrigade/connector/Consumer$IoBrigadeConnectNativeContext;, "Ltas/internal/iobrigade/connector/Consumer<TT;>.IoBrigadeConnectNativeContext;"
    .local p1, "this$0":Ltas/internal/iobrigade/connector/Consumer;, "Ltas/internal/iobrigade/connector/Consumer<TT;>;"
    iput-object p1, p0, Ltas/internal/iobrigade/connector/Consumer$IoBrigadeConnectNativeContext;->this$0:Ltas/internal/iobrigade/connector/Consumer;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 35
    invoke-static {}, Ltas/internal/iobrigade/connector/Consumer;->-get0()Ljava/lang/String;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {p1}, Ltas/internal/iobrigade/connector/Consumer;->-get1(Ltas/internal/iobrigade/connector/Consumer;)Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    .line 36
    const-string/jumbo v2, " is instantiated"

    .line 35
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 37
    invoke-static {p1}, Ltas/internal/iobrigade/connector/Consumer;->-get1(Ltas/internal/iobrigade/connector/Consumer;)Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v0

    .line 39
    new-instance v1, Ljava/lang/ref/WeakReference;

    invoke-direct {v1, p0}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    .line 40
    const-class v2, Ltas/internal/iobrigade/connector/IOData;

    .line 37
    invoke-direct {p0, v0, p2, v1, v2}, Ltas/internal/iobrigade/connector/Consumer$IoBrigadeConnectNativeContext;->nativeInit(Ljava/lang/String;ILjava/lang/ref/WeakReference;Ljava/lang/Class;)V

    .line 33
    return-void
.end method

.method private native nativeFinalize()V
.end method

.method private native nativeInit(Ljava/lang/String;ILjava/lang/ref/WeakReference;Ljava/lang/Class;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "I",
            "Ljava/lang/ref/WeakReference",
            "<",
            "Ltas/internal/iobrigade/connector/Consumer",
            "<TT;>.IoBrigadeConnectNativeContext;>;",
            "Ljava/lang/Class",
            "<*>;)V"
        }
    .end annotation
.end method

.method private native nativeRelease()V
.end method

.method private onSomethingHappen(Ltas/internal/iobrigade/connector/IOData;)V
    .locals 3
    .param p1, "data"    # Ltas/internal/iobrigade/connector/IOData;

    .prologue
    .line 58
    .local p0, "this":Ltas/internal/iobrigade/connector/Consumer$IoBrigadeConnectNativeContext;, "Ltas/internal/iobrigade/connector/Consumer<TT;>.IoBrigadeConnectNativeContext;"
    iget-object v2, p0, Ltas/internal/iobrigade/connector/Consumer$IoBrigadeConnectNativeContext;->mConsumerHandler:Landroid/os/Handler;

    if-eqz v2, :cond_0

    .line 59
    sget v1, Ltas/internal/iobrigade/connector/IOData;->ID:I

    .line 60
    .local v1, "what":I
    iget-object v2, p0, Ltas/internal/iobrigade/connector/Consumer$IoBrigadeConnectNativeContext;->mConsumerHandler:Landroid/os/Handler;

    invoke-static {v2, v1, p1}, Landroid/os/Message;->obtain(Landroid/os/Handler;ILjava/lang/Object;)Landroid/os/Message;

    move-result-object v0

    .line 61
    .local v0, "lmsg":Landroid/os/Message;
    iget-object v2, p0, Ltas/internal/iobrigade/connector/Consumer$IoBrigadeConnectNativeContext;->mConsumerHandler:Landroid/os/Handler;

    invoke-virtual {v2, v0}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    .line 57
    .end local v0    # "lmsg":Landroid/os/Message;
    .end local v1    # "what":I
    :cond_0
    return-void
.end method


# virtual methods
.method protected finalize()V
    .locals 1
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Throwable;
        }
    .end annotation

    .prologue
    .line 51
    .local p0, "this":Ltas/internal/iobrigade/connector/Consumer$IoBrigadeConnectNativeContext;, "Ltas/internal/iobrigade/connector/Consumer<TT;>.IoBrigadeConnectNativeContext;"
    :try_start_0
    invoke-direct {p0}, Ltas/internal/iobrigade/connector/Consumer$IoBrigadeConnectNativeContext;->nativeFinalize()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 53
    invoke-super {p0}, Ljava/lang/Object;->finalize()V

    .line 49
    return-void

    .line 52
    :catchall_0
    move-exception v0

    .line 53
    invoke-super {p0}, Ljava/lang/Object;->finalize()V

    .line 52
    throw v0
.end method

.method public native nativeNotifyConsumerReady(Ljava/lang/String;)V
.end method

.method public native nativeSendMsgTo(Ljava/lang/String;Ljava/lang/String;)V
.end method

.method public release()V
    .locals 0

    .prologue
    .line 45
    .local p0, "this":Ltas/internal/iobrigade/connector/Consumer$IoBrigadeConnectNativeContext;, "Ltas/internal/iobrigade/connector/Consumer<TT;>.IoBrigadeConnectNativeContext;"
    invoke-direct {p0}, Ltas/internal/iobrigade/connector/Consumer$IoBrigadeConnectNativeContext;->nativeRelease()V

    .line 44
    return-void
.end method

.method public setHandler(Landroid/os/Handler;)V
    .locals 0
    .param p1, "h"    # Landroid/os/Handler;

    .prologue
    .line 31
    .local p0, "this":Ltas/internal/iobrigade/connector/Consumer$IoBrigadeConnectNativeContext;, "Ltas/internal/iobrigade/connector/Consumer<TT;>.IoBrigadeConnectNativeContext;"
    iput-object p1, p0, Ltas/internal/iobrigade/connector/Consumer$IoBrigadeConnectNativeContext;->mConsumerHandler:Landroid/os/Handler;

    return-void
.end method
