.class public Ltas/internal/iobrigade/connector/Attributes$cumulate_type;
.super Ljava/lang/Object;
.source "Attributes.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltas/internal/iobrigade/connector/Attributes;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "cumulate_type"
.end annotation


# static fields
.field public static CUMULATE:I

.field public static DEFAULT:I

.field public static LASTONLY:I


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .prologue
    .line 6
    const/4 v0, 0x0

    sput v0, Ltas/internal/iobrigade/connector/Attributes$cumulate_type;->DEFAULT:I

    .line 7
    const/4 v0, 0x1

    sput v0, Ltas/internal/iobrigade/connector/Attributes$cumulate_type;->LASTONLY:I

    .line 8
    const/4 v0, 0x2

    sput v0, Ltas/internal/iobrigade/connector/Attributes$cumulate_type;->CUMULATE:I

    .line 5
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .prologue
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
