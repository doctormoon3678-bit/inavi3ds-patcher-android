.class Lcom/thinkware/sundo/ieve/ieveCameraView$1;
.super Ljava/lang/Object;
.source "ieveCameraView.java"

# interfaces
.implements Landroid/hardware/Camera$ErrorCallback;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/thinkware/sundo/ieve/ieveCameraView;->c()Z
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/thinkware/sundo/ieve/ieveCameraView;


# direct methods
.method constructor <init>(Lcom/thinkware/sundo/ieve/ieveCameraView;)V
    .locals 0

    .prologue
    .line 1
    iput-object p1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$1;->a:Lcom/thinkware/sundo/ieve/ieveCameraView;

    .line 357
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onError(ILandroid/hardware/Camera;)V
    .locals 4
    .param p1, "arg0"    # I
    .param p2, "arg1"    # Landroid/hardware/Camera;

    .prologue
    .line 361
    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Camera onError: arg0["

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "], arg1["

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {p2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "]"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x0

    new-array v2, v2, [Ljava/lang/Object;

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    .line 362
    .local v0, "text":Ljava/lang/String;
    invoke-static {}, Lcom/thinkware/sundo/ieve/ieveCameraView;->a()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 363
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$1;->a:Lcom/thinkware/sundo/ieve/ieveCameraView;

    invoke-static {v1}, Lcom/thinkware/sundo/ieve/ieveCameraView;->a(Lcom/thinkware/sundo/ieve/ieveCameraView;)Landroid/os/Handler;

    move-result-object v1

    if-eqz v1, :cond_0

    iget-object v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$1;->a:Lcom/thinkware/sundo/ieve/ieveCameraView;

    invoke-static {v1}, Lcom/thinkware/sundo/ieve/ieveCameraView;->a(Lcom/thinkware/sundo/ieve/ieveCameraView;)Landroid/os/Handler;

    move-result-object v1

    iget-object v2, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$1;->a:Lcom/thinkware/sundo/ieve/ieveCameraView;

    invoke-static {v2}, Lcom/thinkware/sundo/ieve/ieveCameraView;->a(Lcom/thinkware/sundo/ieve/ieveCameraView;)Landroid/os/Handler;

    move-result-object v2

    const/16 v3, 0x3ed

    invoke-static {v2, v3, v0}, Landroid/os/Message;->obtain(Landroid/os/Handler;ILjava/lang/Object;)Landroid/os/Message;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    .line 364
    :cond_0
    return-void
.end method
