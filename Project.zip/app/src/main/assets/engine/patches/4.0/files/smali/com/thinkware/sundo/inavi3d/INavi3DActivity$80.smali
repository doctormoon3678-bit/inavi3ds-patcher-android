.class Lcom/thinkware/sundo/inavi3d/INavi3DActivity$80;
.super Ljava/lang/Object;
.source "INavi3DActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->_InitIeveThread()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;


# direct methods
.method constructor <init>(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)V
    .locals 0

    .prologue
    .line 18680
    iput-object p1, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$80;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 12

    .prologue
    const/4 v9, 0x0

    .line 18684
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$80;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    invoke-static {v0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$2600(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)Lcom/thinkware/sundo/ieve/IEVE;

    move-result-object v0

    if-nez v0, :cond_1

    .line 18710
    :cond_0
    :goto_0
    return-void

    .line 18689
    :cond_1
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v2

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->kStorageRoot:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, "/res"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .line 18690
    .local v1, "respath":Ljava/lang/String;
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v2

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->kStorageRoot:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, "/res"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    .line 18691
    .local v8, "encryptfolder":Ljava/lang/String;
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v10

    .line 18693
    .local v10, "nStartTime":J
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$80;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    invoke-static {v0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$2600(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)Lcom/thinkware/sundo/ieve/IEVE;

    move-result-object v0

    new-instance v2, Landroid/graphics/Rect;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$80;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    invoke-static {v3}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$22900(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)I

    move-result v3

    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$80;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    invoke-static {v4}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$23000(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)I

    move-result v4

    invoke-direct {v2, v9, v9, v3, v4}, Landroid/graphics/Rect;-><init>(IIII)V

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$80;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    invoke-static {v3}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$100(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)Lcom/thinkware/sundo/ieve/ieveNScreenManager;

    move-result-object v3

    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$80;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    invoke-static {v4}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$23100(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)I

    move-result v4

    iget-object v5, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$80;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    invoke-static {v5}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$23200(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)I

    move-result v5

    iget-object v6, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$80;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    invoke-static {v6}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$23300(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)I

    move-result v6

    iget-object v7, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$80;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    invoke-static {v7}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$23400(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)I

    move-result v7

    invoke-virtual/range {v0 .. v8}, Lcom/thinkware/sundo/ieve/IEVE;->initialize(Ljava/lang/String;Landroid/graphics/Rect;Lcom/thinkware/sundo/ieve/ieveNScreenManager;IIIILjava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_2

    .line 18694
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$80;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    const/4 v2, 0x0

    invoke-static {v0, v2}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$2602(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;Lcom/thinkware/sundo/ieve/IEVE;)Lcom/thinkware/sundo/ieve/IEVE;

    .line 18695
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$80;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    const-string v2, "IEVE\uc5d4\uc9c4 \ucd08\uae30\ud654\ub97c \uc2e4\ud328\ud558\uc600\uc2b5\ub2c8\ub2e4."

    invoke-static {v0, v2, v9}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    goto/16 :goto_0

    .line 18699
    :cond_2
    const-string v0, "PerformTick"

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "IEVE.initialize : "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v4

    sub-long/2addr v4, v10

    invoke-virtual {v2, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " m_nIeveWidth : "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$80;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    invoke-static {v3}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$22900(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)I

    move-result v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " m_nIeveHeight : "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$80;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    invoke-static {v3}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$23000(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)I

    move-result v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v2}, Lcom/thinkware/sundo/inavi3d/LOGTW;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 18702
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$80;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    invoke-static {v0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$23500(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)V

    .line 18705
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getARCameraStatus()I

    move-result v0

    if-nez v0, :cond_0

    .line 18706
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$80;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    invoke-static {v0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$2600(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)Lcom/thinkware/sundo/ieve/IEVE;

    move-result-object v0

    const/16 v2, 0x7112

    invoke-virtual {v0, v2, v9}, Lcom/thinkware/sundo/ieve/IEVE;->setIEVEConfigValue(II)V

    goto/16 :goto_0
.end method
