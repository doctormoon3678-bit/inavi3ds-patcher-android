.class public Ltas/camera/id/Fastview;
.super Ltas/camera/CameraId;
.source "Fastview.java"


# static fields
.field public static final ERR_PGL_EXCEPTION:I = -0x3e7

.field public static final SET_CLEAR_SCREEN:I = 0x7d6

.field public static final SET_DISABLE:I = 0x7d2

.field public static final SET_ENABLE:I = 0x7d1

.field public static final SET_PGL_DATA:I = 0x7d5

.field public static final SET_PGL_DISABLE:I = 0x7d4

.field public static final SET_PGL_ENABLE:I = 0x7d3


# instance fields
.field private final proxy:Ltas/internal/camera/client/CameraProxy;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ltas/internal/camera/client/CameraProxy",
            "<",
            "Ltas/camera/id/Fastview;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 1
    .param p1, "context"    # Landroid/content/Context;

    .prologue
    .line 31
    invoke-direct {p0}, Ltas/camera/CameraId;-><init>()V

    .line 32
    new-instance v0, Ltas/internal/camera/client/CameraProxy;

    invoke-direct {v0, p1, p0}, Ltas/internal/camera/client/CameraProxy;-><init>(Landroid/content/Context;Ltas/camera/CameraId;)V

    iput-object v0, p0, Ltas/camera/id/Fastview;->proxy:Ltas/internal/camera/client/CameraProxy;

    .line 31
    return-void
.end method


# virtual methods
.method protected proxy()Ltas/internal/camera/client/CameraProxy;
    .locals 1

    .prologue
    .line 36
    iget-object v0, p0, Ltas/camera/id/Fastview;->proxy:Ltas/internal/camera/client/CameraProxy;

    return-object v0
.end method

.method public setListener(Ltas/camera/BaseListener;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ltas/camera/BaseListener",
            "<",
            "Ltas/camera/id/Fastview;",
            ">;)V"
        }
    .end annotation

    .prologue
    .line 40
    .local p1, "l":Ltas/camera/BaseListener;, "Ltas/camera/BaseListener<Ltas/camera/id/Fastview;>;"
    iget-object v0, p0, Ltas/camera/id/Fastview;->proxy:Ltas/internal/camera/client/CameraProxy;

    invoke-virtual {v0, p1}, Ltas/internal/camera/client/CameraProxy;->setListener(Ltas/camera/BaseListener;)V

    .line 39
    return-void
.end method
