.class Ltas/internal/ipc/server/ServerManager$ClientHolder;
.super Ljava/lang/Object;
.source "ServerManager.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltas/internal/ipc/server/ServerManager;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "ClientHolder"
.end annotation


# instance fields
.field private handler:Ltas/internal/ipc/server/ServerManager$ClientHandler;

.field private thread:Landroid/os/HandlerThread;


# direct methods
.method static synthetic -get0(Ltas/internal/ipc/server/ServerManager$ClientHolder;)Ltas/internal/ipc/server/ServerManager$ClientHandler;
    .locals 1

    iget-object v0, p0, Ltas/internal/ipc/server/ServerManager$ClientHolder;->handler:Ltas/internal/ipc/server/ServerManager$ClientHandler;

    return-object v0
.end method

.method private constructor <init>(Ltas/internal/ipc/server/ServerManager;I)V
    .locals 6
    .param p1, "m"    # Ltas/internal/ipc/server/ServerManager;
    .param p2, "pid"    # I

    .prologue
    .line 1080
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1082
    new-instance v0, Landroid/os/HandlerThread;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "TasIPC-"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/HandlerThread;-><init>(Ljava/lang/String;)V

    iput-object v0, p0, Ltas/internal/ipc/server/ServerManager$ClientHolder;->thread:Landroid/os/HandlerThread;

    .line 1083
    iget-object v0, p0, Ltas/internal/ipc/server/ServerManager$ClientHolder;->thread:Landroid/os/HandlerThread;

    invoke-virtual {v0}, Landroid/os/HandlerThread;->start()V

    .line 1084
    new-instance v0, Ltas/internal/ipc/server/ServerManager$ClientHandler;

    iget-object v2, p0, Ltas/internal/ipc/server/ServerManager$ClientHolder;->thread:Landroid/os/HandlerThread;

    iget-object v1, p0, Ltas/internal/ipc/server/ServerManager$ClientHolder;->thread:Landroid/os/HandlerThread;

    invoke-virtual {v1}, Landroid/os/HandlerThread;->getThreadId()I

    move-result v4

    const/4 v5, 0x0

    move-object v1, p1

    move v3, p2

    invoke-direct/range {v0 .. v5}, Ltas/internal/ipc/server/ServerManager$ClientHandler;-><init>(Ltas/internal/ipc/server/ServerManager;Landroid/os/HandlerThread;IILtas/internal/ipc/server/ServerManager$ClientHandler;)V

    iput-object v0, p0, Ltas/internal/ipc/server/ServerManager$ClientHolder;->handler:Ltas/internal/ipc/server/ServerManager$ClientHandler;

    .line 1080
    return-void
.end method

.method synthetic constructor <init>(Ltas/internal/ipc/server/ServerManager;ILtas/internal/ipc/server/ServerManager$ClientHolder;)V
    .locals 0
    .param p1, "m"    # Ltas/internal/ipc/server/ServerManager;
    .param p2, "pid"    # I

    .prologue
    invoke-direct {p0, p1, p2}, Ltas/internal/ipc/server/ServerManager$ClientHolder;-><init>(Ltas/internal/ipc/server/ServerManager;I)V

    return-void
.end method
