.class public abstract Ltas/internal/camera/InputSource;
.super Ljava/lang/Object;
.source "InputSource.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ltas/internal/camera/InputSource$Dummy;,
        Ltas/internal/camera/InputSource$Hook;
    }
.end annotation


# instance fields
.field final hook:Ltas/internal/camera/InputSource$Hook;


# direct methods
.method public constructor <init>(I)V
    .locals 2
    .param p1, "maxinputs"    # I

    .prologue
    .line 22
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 23
    new-instance v0, Ltas/internal/camera/InputSource$Hook;

    const/4 v1, 0x0

    invoke-direct {v0, p0, p1, v1}, Ltas/internal/camera/InputSource$Hook;-><init>(Ltas/internal/camera/InputSource;ILtas/internal/camera/InputSource$Hook;)V

    iput-object v0, p0, Ltas/internal/camera/InputSource;->hook:Ltas/internal/camera/InputSource$Hook;

    .line 22
    return-void
.end method

.method public constructor <init>(Ljava/lang/Class;Ljava/lang/String;)V
    .locals 2
    .param p2, "camid"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Class",
            "<*>;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .prologue
    .line 30
    .local p1, "camcls":Ljava/lang/Class;, "Ljava/lang/Class<*>;"
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 32
    new-instance v0, Ltas/internal/camera/InputSource$Hook;

    const/4 v1, 0x0

    invoke-direct {v0, p0, p1, p2, v1}, Ltas/internal/camera/InputSource$Hook;-><init>(Ltas/internal/camera/InputSource;Ljava/lang/Class;Ljava/lang/String;Ltas/internal/camera/InputSource$Hook;)V

    iput-object v0, p0, Ltas/internal/camera/InputSource;->hook:Ltas/internal/camera/InputSource$Hook;

    .line 31
    return-void
.end method

.method public static createDummy(I)Ltas/internal/camera/InputSource;
    .locals 1
    .param p0, "maxinputs"    # I

    .prologue
    .line 321
    new-instance v0, Ltas/internal/camera/InputSource$Dummy;

    invoke-direct {v0, p0}, Ltas/internal/camera/InputSource$Dummy;-><init>(I)V

    return-object v0
.end method

.method public static createDummy(Ljava/lang/Class;Ljava/lang/String;)Ltas/internal/camera/InputSource;
    .locals 1
    .param p1, "camid"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Class",
            "<*>;",
            "Ljava/lang/String;",
            ")",
            "Ltas/internal/camera/InputSource;"
        }
    .end annotation

    .prologue
    .line 326
    .local p0, "camcls":Ljava/lang/Class;, "Ljava/lang/Class<*>;"
    new-instance v0, Ltas/internal/camera/InputSource$Dummy;

    invoke-direct {v0, p0, p1}, Ltas/internal/camera/InputSource$Dummy;-><init>(Ljava/lang/Class;Ljava/lang/String;)V

    return-object v0
.end method


# virtual methods
.method public addInput(ILtas/internal/camera/InputSource;)V
    .locals 1
    .param p1, "port"    # I
    .param p2, "input"    # Ltas/internal/camera/InputSource;

    .prologue
    .line 106
    iget-object v0, p0, Ltas/internal/camera/InputSource;->hook:Ltas/internal/camera/InputSource$Hook;

    invoke-static {v0, p1, p2}, Ltas/internal/camera/InputSource$Hook;->-wrap6(Ltas/internal/camera/InputSource$Hook;ILtas/internal/camera/InputSource;)V

    .line 105
    return-void
.end method

.method public camid()Ljava/lang/String;
    .locals 1

    .prologue
    .line 39
    iget-object v0, p0, Ltas/internal/camera/InputSource;->hook:Ltas/internal/camera/InputSource$Hook;

    invoke-static {v0}, Ltas/internal/camera/InputSource$Hook;->-wrap2(Ltas/internal/camera/InputSource$Hook;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public camname()Ljava/lang/String;
    .locals 1

    .prologue
    .line 46
    iget-object v0, p0, Ltas/internal/camera/InputSource;->hook:Ltas/internal/camera/InputSource$Hook;

    invoke-static {v0}, Ltas/internal/camera/InputSource$Hook;->-wrap3(Ltas/internal/camera/InputSource$Hook;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getCurrInput(Z)Ltas/internal/camera/InputSource;
    .locals 1
    .param p1, "recursive"    # Z

    .prologue
    .line 118
    iget-object v0, p0, Ltas/internal/camera/InputSource;->hook:Ltas/internal/camera/InputSource$Hook;

    invoke-static {v0, p1}, Ltas/internal/camera/InputSource$Hook;->-wrap4(Ltas/internal/camera/InputSource$Hook;Z)Ltas/internal/camera/InputSource;

    move-result-object v0

    return-object v0
.end method

.method public getParent()Ltas/internal/camera/InputSource;
    .locals 1

    .prologue
    .line 60
    iget-object v0, p0, Ltas/internal/camera/InputSource;->hook:Ltas/internal/camera/InputSource$Hook;

    invoke-static {v0}, Ltas/internal/camera/InputSource$Hook;->-wrap5(Ltas/internal/camera/InputSource$Hook;)Ltas/internal/camera/InputSource;

    move-result-object v0

    return-object v0
.end method

.method public initializeInputQueue()V
    .locals 1

    .prologue
    .line 90
    iget-object v0, p0, Ltas/internal/camera/InputSource;->hook:Ltas/internal/camera/InputSource$Hook;

    invoke-static {v0}, Ltas/internal/camera/InputSource$Hook;->-wrap7(Ltas/internal/camera/InputSource$Hook;)V

    .line 89
    return-void
.end method

.method public initializeStateQueue()V
    .locals 1

    .prologue
    .line 70
    iget-object v0, p0, Ltas/internal/camera/InputSource;->hook:Ltas/internal/camera/InputSource$Hook;

    invoke-static {v0}, Ltas/internal/camera/InputSource$Hook;->-wrap8(Ltas/internal/camera/InputSource$Hook;)V

    .line 69
    return-void
.end method

.method public isOpened()Z
    .locals 1

    .prologue
    .line 148
    iget-object v0, p0, Ltas/internal/camera/InputSource;->hook:Ltas/internal/camera/InputSource$Hook;

    invoke-virtual {v0}, Ltas/internal/camera/InputSource$Hook;->isOpened()Z

    move-result v0

    return v0
.end method

.method public isPlugged()Z
    .locals 1

    .prologue
    .line 141
    iget-object v0, p0, Ltas/internal/camera/InputSource;->hook:Ltas/internal/camera/InputSource$Hook;

    invoke-static {v0}, Ltas/internal/camera/InputSource$Hook;->-wrap0(Ltas/internal/camera/InputSource$Hook;)Z

    move-result v0

    return v0
.end method

.method public notifyInput(Ltas/internal/camera/InputSource;)V
    .locals 1
    .param p1, "input"    # Ltas/internal/camera/InputSource;

    .prologue
    .line 100
    iget-object v0, p0, Ltas/internal/camera/InputSource;->hook:Ltas/internal/camera/InputSource$Hook;

    invoke-static {v0, p1}, Ltas/internal/camera/InputSource$Hook;->-wrap9(Ltas/internal/camera/InputSource$Hook;Ltas/internal/camera/InputSource;)V

    .line 99
    return-void
.end method

.method public notifyState(I)V
    .locals 1
    .param p1, "state"    # I

    .prologue
    .line 80
    iget-object v0, p0, Ltas/internal/camera/InputSource;->hook:Ltas/internal/camera/InputSource$Hook;

    invoke-static {v0, p1}, Ltas/internal/camera/InputSource$Hook;->-wrap10(Ltas/internal/camera/InputSource$Hook;I)V

    .line 79
    return-void
.end method

.method public obtainMessage(I)Ltas/camera/CameraMessage;
    .locals 1
    .param p1, "what"    # I

    .prologue
    .line 244
    new-instance v0, Ltas/camera/CameraMessage;

    invoke-direct {v0, p1}, Ltas/camera/CameraMessage;-><init>(I)V

    return-object v0
.end method

.method protected onClose(Ltas/internal/camera/InputSource;)V
    .locals 0
    .param p1, "target"    # Ltas/internal/camera/InputSource;

    .prologue
    .line 309
    return-void
.end method

.method protected onCommand(Ltas/internal/camera/InputSource;Ltas/camera/CameraCommand;Ljava/lang/String;)I
    .locals 1
    .param p1, "target"    # Ltas/internal/camera/InputSource;
    .param p2, "cmd"    # Ltas/camera/CameraCommand;
    .param p3, "proc"    # Ljava/lang/String;

    .prologue
    .line 278
    const/16 v0, -0x9

    return v0
.end method

.method protected onOpen(Ltas/internal/camera/InputSource;)V
    .locals 0
    .param p1, "target"    # Ltas/internal/camera/InputSource;

    .prologue
    .line 303
    return-void
.end method

.method protected onPlug()V
    .locals 0

    .prologue
    .line 291
    return-void
.end method

.method protected onRequest(Ljava/lang/String;)I
    .locals 1
    .param p1, "proc"    # Ljava/lang/String;

    .prologue
    .line 267
    const/4 v0, 0x0

    return v0
.end method

.method protected onStateChanged(I)Z
    .locals 1
    .param p1, "state"    # I

    .prologue
    .line 285
    const/4 v0, 0x1

    return v0
.end method

.method protected onSystemMasterClear(Ljava/lang/String;)V
    .locals 0
    .param p1, "reason"    # Ljava/lang/String;

    .prologue
    .line 315
    return-void
.end method

.method protected onSystemShutdown()V
    .locals 0

    .prologue
    .line 312
    return-void
.end method

.method protected onUnplug()V
    .locals 0

    .prologue
    .line 297
    return-void
.end method

.method public plug()V
    .locals 1

    .prologue
    .line 127
    iget-object v0, p0, Ltas/internal/camera/InputSource;->hook:Ltas/internal/camera/InputSource$Hook;

    invoke-static {v0}, Ltas/internal/camera/InputSource$Hook;->-wrap11(Ltas/internal/camera/InputSource$Hook;)V

    .line 126
    return-void
.end method

.method public port()I
    .locals 1

    .prologue
    .line 53
    iget-object v0, p0, Ltas/internal/camera/InputSource;->hook:Ltas/internal/camera/InputSource$Hook;

    invoke-static {v0}, Ltas/internal/camera/InputSource$Hook;->-wrap1(Ltas/internal/camera/InputSource$Hook;)I

    move-result v0

    return v0
.end method

.method public reportExtraState(IILjava/lang/String;)V
    .locals 1
    .param p1, "state"    # I
    .param p2, "flag"    # I
    .param p3, "proc"    # Ljava/lang/String;

    .prologue
    .line 254
    iget-object v0, p0, Ltas/internal/camera/InputSource;->hook:Ltas/internal/camera/InputSource$Hook;

    invoke-static {v0, p1, p2, p3}, Ltas/internal/camera/InputSource$Hook;->-wrap12(Ltas/internal/camera/InputSource$Hook;IILjava/lang/String;)V

    .line 253
    return-void
.end method

.method public reportExtraState(ILjava/lang/String;)V
    .locals 2
    .param p1, "state"    # I
    .param p2, "proc"    # Ljava/lang/String;

    .prologue
    .line 258
    iget-object v0, p0, Ltas/internal/camera/InputSource;->hook:Ltas/internal/camera/InputSource$Hook;

    const/4 v1, 0x0

    invoke-static {v0, p1, v1, p2}, Ltas/internal/camera/InputSource$Hook;->-wrap12(Ltas/internal/camera/InputSource$Hook;IILjava/lang/String;)V

    .line 257
    return-void
.end method

.method public sendMessage(Ljava/lang/String;ZI)V
    .locals 1
    .param p1, "proc"    # Ljava/lang/String;
    .param p2, "now"    # Z
    .param p3, "what"    # I

    .prologue
    .line 168
    invoke-virtual {p0, p3}, Ltas/internal/camera/InputSource;->obtainMessage(I)Ltas/camera/CameraMessage;

    move-result-object v0

    .line 169
    .local v0, "msg":Ltas/camera/CameraMessage;
    invoke-virtual {p0, v0, p1, p2}, Ltas/internal/camera/InputSource;->sendMessage(Ltas/camera/CameraMessage;Ljava/lang/String;Z)V

    .line 167
    return-void
.end method

.method public sendMessage(Ljava/lang/String;ZII)V
    .locals 1
    .param p1, "proc"    # Ljava/lang/String;
    .param p2, "now"    # Z
    .param p3, "what"    # I
    .param p4, "arg1"    # I

    .prologue
    .line 174
    invoke-virtual {p0, p3}, Ltas/internal/camera/InputSource;->obtainMessage(I)Ltas/camera/CameraMessage;

    move-result-object v0

    .line 175
    .local v0, "msg":Ltas/camera/CameraMessage;
    iput p4, v0, Ltas/camera/CameraMessage;->arg1:I

    .line 176
    invoke-virtual {p0, v0, p1, p2}, Ltas/internal/camera/InputSource;->sendMessage(Ltas/camera/CameraMessage;Ljava/lang/String;Z)V

    .line 173
    return-void
.end method

.method public sendMessage(Ljava/lang/String;ZIII)V
    .locals 1
    .param p1, "proc"    # Ljava/lang/String;
    .param p2, "now"    # Z
    .param p3, "what"    # I
    .param p4, "arg1"    # I
    .param p5, "arg2"    # I

    .prologue
    .line 181
    invoke-virtual {p0, p3}, Ltas/internal/camera/InputSource;->obtainMessage(I)Ltas/camera/CameraMessage;

    move-result-object v0

    .line 182
    .local v0, "msg":Ltas/camera/CameraMessage;
    iput p4, v0, Ltas/camera/CameraMessage;->arg1:I

    .line 183
    iput p5, v0, Ltas/camera/CameraMessage;->arg2:I

    .line 184
    invoke-virtual {p0, v0, p1, p2}, Ltas/internal/camera/InputSource;->sendMessage(Ltas/camera/CameraMessage;Ljava/lang/String;Z)V

    .line 180
    return-void
.end method

.method public varargs sendMessage(Ljava/lang/String;ZIII[I)V
    .locals 1
    .param p1, "proc"    # Ljava/lang/String;
    .param p2, "now"    # Z
    .param p3, "what"    # I
    .param p4, "arg1"    # I
    .param p5, "arg2"    # I
    .param p6, "args"    # [I

    .prologue
    .line 190
    invoke-virtual {p0, p3}, Ltas/internal/camera/InputSource;->obtainMessage(I)Ltas/camera/CameraMessage;

    move-result-object v0

    .line 191
    .local v0, "msg":Ltas/camera/CameraMessage;
    iput p4, v0, Ltas/camera/CameraMessage;->arg1:I

    .line 192
    iput p5, v0, Ltas/camera/CameraMessage;->arg2:I

    .line 193
    iput-object p6, v0, Ltas/camera/CameraMessage;->args:[I

    .line 194
    invoke-virtual {p0, v0, p1, p2}, Ltas/internal/camera/InputSource;->sendMessage(Ltas/camera/CameraMessage;Ljava/lang/String;Z)V

    .line 189
    return-void
.end method

.method public sendMessage(Ljava/lang/String;ZIII[ILjava/lang/String;Ljava/lang/String;[BLandroid/os/Bundle;)V
    .locals 1
    .param p1, "proc"    # Ljava/lang/String;
    .param p2, "now"    # Z
    .param p3, "what"    # I
    .param p4, "arg1"    # I
    .param p5, "arg2"    # I
    .param p6, "args"    # [I
    .param p7, "str1"    # Ljava/lang/String;
    .param p8, "str2"    # Ljava/lang/String;
    .param p9, "bytes"    # [B
    .param p10, "bundle"    # Landroid/os/Bundle;

    .prologue
    .line 232
    invoke-virtual {p0, p3}, Ltas/internal/camera/InputSource;->obtainMessage(I)Ltas/camera/CameraMessage;

    move-result-object v0

    .line 233
    .local v0, "msg":Ltas/camera/CameraMessage;
    iput p4, v0, Ltas/camera/CameraMessage;->arg1:I

    .line 234
    iput p5, v0, Ltas/camera/CameraMessage;->arg2:I

    .line 235
    iput-object p6, v0, Ltas/camera/CameraMessage;->args:[I

    .line 236
    iput-object p7, v0, Ltas/camera/CameraMessage;->str1:Ljava/lang/String;

    .line 237
    iput-object p8, v0, Ltas/camera/CameraMessage;->str2:Ljava/lang/String;

    .line 238
    iput-object p9, v0, Ltas/camera/CameraMessage;->bytes:[B

    .line 239
    iput-object p10, v0, Ltas/camera/CameraMessage;->extra:Landroid/os/Bundle;

    .line 240
    invoke-virtual {p0, v0, p1, p2}, Ltas/internal/camera/InputSource;->sendMessage(Ltas/camera/CameraMessage;Ljava/lang/String;Z)V

    .line 231
    return-void
.end method

.method public sendMessage(Ljava/lang/String;ZILandroid/os/Bundle;)V
    .locals 1
    .param p1, "proc"    # Ljava/lang/String;
    .param p2, "now"    # Z
    .param p3, "what"    # I
    .param p4, "bundle"    # Landroid/os/Bundle;

    .prologue
    .line 222
    invoke-virtual {p0, p3}, Ltas/internal/camera/InputSource;->obtainMessage(I)Ltas/camera/CameraMessage;

    move-result-object v0

    .line 223
    .local v0, "msg":Ltas/camera/CameraMessage;
    iput-object p4, v0, Ltas/camera/CameraMessage;->extra:Landroid/os/Bundle;

    .line 224
    invoke-virtual {p0, v0, p1, p2}, Ltas/internal/camera/InputSource;->sendMessage(Ltas/camera/CameraMessage;Ljava/lang/String;Z)V

    .line 221
    return-void
.end method

.method public sendMessage(Ljava/lang/String;ZILjava/lang/String;)V
    .locals 1
    .param p1, "proc"    # Ljava/lang/String;
    .param p2, "now"    # Z
    .param p3, "what"    # I
    .param p4, "str1"    # Ljava/lang/String;

    .prologue
    .line 199
    invoke-virtual {p0, p3}, Ltas/internal/camera/InputSource;->obtainMessage(I)Ltas/camera/CameraMessage;

    move-result-object v0

    .line 200
    .local v0, "msg":Ltas/camera/CameraMessage;
    iput-object p4, v0, Ltas/camera/CameraMessage;->str1:Ljava/lang/String;

    .line 201
    invoke-virtual {p0, v0, p1, p2}, Ltas/internal/camera/InputSource;->sendMessage(Ltas/camera/CameraMessage;Ljava/lang/String;Z)V

    .line 198
    return-void
.end method

.method public sendMessage(Ljava/lang/String;ZILjava/lang/String;Ljava/lang/String;)V
    .locals 1
    .param p1, "proc"    # Ljava/lang/String;
    .param p2, "now"    # Z
    .param p3, "what"    # I
    .param p4, "str1"    # Ljava/lang/String;
    .param p5, "str2"    # Ljava/lang/String;

    .prologue
    .line 207
    invoke-virtual {p0, p3}, Ltas/internal/camera/InputSource;->obtainMessage(I)Ltas/camera/CameraMessage;

    move-result-object v0

    .line 208
    .local v0, "msg":Ltas/camera/CameraMessage;
    iput-object p4, v0, Ltas/camera/CameraMessage;->str1:Ljava/lang/String;

    .line 209
    iput-object p5, v0, Ltas/camera/CameraMessage;->str2:Ljava/lang/String;

    .line 210
    invoke-virtual {p0, v0, p1, p2}, Ltas/internal/camera/InputSource;->sendMessage(Ltas/camera/CameraMessage;Ljava/lang/String;Z)V

    .line 206
    return-void
.end method

.method public sendMessage(Ljava/lang/String;ZI[B)V
    .locals 1
    .param p1, "proc"    # Ljava/lang/String;
    .param p2, "now"    # Z
    .param p3, "what"    # I
    .param p4, "bytes"    # [B

    .prologue
    .line 215
    invoke-virtual {p0, p3}, Ltas/internal/camera/InputSource;->obtainMessage(I)Ltas/camera/CameraMessage;

    move-result-object v0

    .line 216
    .local v0, "msg":Ltas/camera/CameraMessage;
    iput-object p4, v0, Ltas/camera/CameraMessage;->bytes:[B

    .line 217
    invoke-virtual {p0, v0, p1, p2}, Ltas/internal/camera/InputSource;->sendMessage(Ltas/camera/CameraMessage;Ljava/lang/String;Z)V

    .line 214
    return-void
.end method

.method public sendMessage(Ltas/camera/CameraMessage;Ljava/lang/String;Z)V
    .locals 1
    .param p1, "msg"    # Ltas/camera/CameraMessage;
    .param p2, "proc"    # Ljava/lang/String;
    .param p3, "now"    # Z

    .prologue
    .line 163
    iget-object v0, p0, Ltas/internal/camera/InputSource;->hook:Ltas/internal/camera/InputSource$Hook;

    invoke-static {v0, p1, p2, p3}, Ltas/internal/camera/InputSource$Hook;->-wrap13(Ltas/internal/camera/InputSource$Hook;Ltas/camera/CameraMessage;Ljava/lang/String;Z)V

    .line 162
    return-void
.end method

.method public unplug()V
    .locals 1

    .prologue
    .line 134
    iget-object v0, p0, Ltas/internal/camera/InputSource;->hook:Ltas/internal/camera/InputSource$Hook;

    invoke-static {v0}, Ltas/internal/camera/InputSource$Hook;->-wrap14(Ltas/internal/camera/InputSource$Hook;)V

    .line 133
    return-void
.end method
