.class public abstract Ltas/internal/ipc/util/ServiceConnectionAbstract;
.super Ljava/lang/Object;
.source "ServiceConnectionAbstract.java"

# interfaces
.implements Landroid/content/ServiceConnection;
.implements Landroid/os/IBinder$DeathRecipient;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ltas/internal/ipc/util/ServiceConnectionAbstract$Callback;,
        Ltas/internal/ipc/util/ServiceConnectionAbstract$H;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T::",
        "Landroid/os/IInterface;",
        ">",
        "Ljava/lang/Object;",
        "Landroid/content/ServiceConnection;",
        "Landroid/os/IBinder$DeathRecipient;"
    }
.end annotation


# static fields
.field private static final DBG:Z = true

.field private static final MSG_DISCONNECT:I = 0x1

.field private static final MSG_LOCK:I = 0x0

.field public static final MSG_START:I = 0x64

.field private static final TAG:Ljava/lang/String; = "TasIPCUtil<ServiceConnection>"

.field private static final mSp:Ljava/util/concurrent/Semaphore;


# instance fields
.field private mBinding:Z

.field private mBound:Z

.field private mCallbacks:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List",
            "<",
            "Ltas/internal/ipc/util/ServiceConnectionAbstract$Callback;",
            ">;"
        }
    .end annotation
.end field

.field private mContext:Landroid/content/Context;

.field private mH:Ltas/internal/ipc/util/ServiceConnectionAbstract$H;

.field private mHT:Landroid/os/HandlerThread;

.field private final mLock:Ljava/lang/Object;

.field private mName:Ljava/lang/String;

.field private mRef:I

.field private mRemote:Landroid/os/IInterface;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TT;"
        }
    .end annotation
.end field


# direct methods
.method static synthetic -wrap0(Ltas/internal/ipc/util/ServiceConnectionAbstract;)V
    .locals 0

    invoke-direct {p0}, Ltas/internal/ipc/util/ServiceConnectionAbstract;->doDisconnect()V

    return-void
.end method

.method static synthetic -wrap1(Ltas/internal/ipc/util/ServiceConnectionAbstract;Landroid/os/Message;)V
    .locals 0
    .param p1, "msg"    # Landroid/os/Message;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/ipc/util/ServiceConnectionAbstract;->handleMessage(Landroid/os/Message;)V

    return-void
.end method

.method static synthetic -wrap2(Ltas/internal/ipc/util/ServiceConnectionAbstract;)V
    .locals 0

    invoke-direct {p0}, Ltas/internal/ipc/util/ServiceConnectionAbstract;->lock()V

    return-void
.end method

.method static constructor <clinit>()V
    .locals 2

    .prologue
    .line 315
    new-instance v0, Ljava/util/concurrent/Semaphore;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Ljava/util/concurrent/Semaphore;-><init>(I)V

    sput-object v0, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mSp:Ljava/util/concurrent/Semaphore;

    .line 28
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;)V
    .locals 1
    .param p1, "name"    # Ljava/lang/String;

    .prologue
    .line 54
    .local p0, "this":Ltas/internal/ipc/util/ServiceConnectionAbstract;, "Ltas/internal/ipc/util/ServiceConnectionAbstract<TT;>;"
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 45
    const/4 v0, 0x0

    iput v0, p0, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mRef:I

    .line 46
    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mLock:Ljava/lang/Object;

    .line 55
    iput-object p1, p0, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mName:Ljava/lang/String;

    .line 54
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Landroid/os/Looper;)V
    .locals 2
    .param p1, "name"    # Ljava/lang/String;
    .param p2, "l"    # Landroid/os/Looper;

    .prologue
    .line 59
    .local p0, "this":Ltas/internal/ipc/util/ServiceConnectionAbstract;, "Ltas/internal/ipc/util/ServiceConnectionAbstract<TT;>;"
    invoke-direct {p0, p1}, Ltas/internal/ipc/util/ServiceConnectionAbstract;-><init>(Ljava/lang/String;)V

    .line 60
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v0

    if-ne p2, v0, :cond_0

    .line 61
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 62
    const-string/jumbo v1, "don\'t create ServiceConnectionAbstract in the main looper."

    .line 61
    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 63
    :cond_0
    if-eqz p2, :cond_1

    .line 64
    new-instance v0, Ltas/internal/ipc/util/ServiceConnectionAbstract$H;

    invoke-direct {v0, p2, p0}, Ltas/internal/ipc/util/ServiceConnectionAbstract$H;-><init>(Landroid/os/Looper;Ltas/internal/ipc/util/ServiceConnectionAbstract;)V

    iput-object v0, p0, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mH:Ltas/internal/ipc/util/ServiceConnectionAbstract$H;

    .line 58
    :cond_1
    return-void
.end method

.method private cancelAll()V
    .locals 2

    .prologue
    .line 186
    .local p0, "this":Ltas/internal/ipc/util/ServiceConnectionAbstract;, "Ltas/internal/ipc/util/ServiceConnectionAbstract<TT;>;"
    iget-object v0, p0, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mH:Ltas/internal/ipc/util/ServiceConnectionAbstract$H;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Ltas/internal/ipc/util/ServiceConnectionAbstract$H;->removeCallbacksAndMessages(Ljava/lang/Object;)V

    .line 185
    return-void
.end method

.method private doConnectLocked(Landroid/content/Context;Landroid/content/ComponentName;I)V
    .locals 4
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "name"    # Landroid/content/ComponentName;
    .param p3, "flags"    # I

    .prologue
    .line 105
    .local p0, "this":Ltas/internal/ipc/util/ServiceConnectionAbstract;, "Ltas/internal/ipc/util/ServiceConnectionAbstract<TT;>;"
    const-string/jumbo v1, "TasIPCUtil<ServiceConnection>"

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "["

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, p0, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mName:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string/jumbo v3, "] connecting ..."

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 106
    iput-object p1, p0, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mContext:Landroid/content/Context;

    .line 107
    const/4 v1, 0x1

    iput-boolean v1, p0, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mBinding:Z

    .line 108
    new-instance v0, Landroid/content/Intent;

    invoke-direct {v0}, Landroid/content/Intent;-><init>()V

    .line 109
    .local v0, "intent":Landroid/content/Intent;
    invoke-virtual {v0, p2}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;

    .line 110
    invoke-virtual {p1, v0, p0, p3}, Landroid/content/Context;->bindService(Landroid/content/Intent;Landroid/content/ServiceConnection;I)Z

    .line 104
    return-void
.end method

.method private doDisconnect()V
    .locals 2

    .prologue
    .line 114
    .local p0, "this":Ltas/internal/ipc/util/ServiceConnectionAbstract;, "Ltas/internal/ipc/util/ServiceConnectionAbstract<TT;>;"
    iget-object v1, p0, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mLock:Ljava/lang/Object;

    monitor-enter v1

    .line 115
    :try_start_0
    iget v0, p0, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mRef:I

    add-int/lit8 v0, v0, -0x1

    iput v0, p0, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mRef:I

    .line 116
    iget v0, p0, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mRef:I

    if-nez v0, :cond_0

    iget-object v0, p0, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mContext:Landroid/content/Context;

    if-eqz v0, :cond_0

    iget-boolean v0, p0, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mBound:Z

    if-eqz v0, :cond_0

    .line 117
    invoke-direct {p0}, Ltas/internal/ipc/util/ServiceConnectionAbstract;->doDisconnectLocked()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_0
    monitor-exit v1

    .line 113
    return-void

    .line 114
    :catchall_0
    move-exception v0

    monitor-exit v1

    throw v0
.end method

.method private doDisconnectLocked()V
    .locals 3

    .prologue
    .line 123
    .local p0, "this":Ltas/internal/ipc/util/ServiceConnectionAbstract;, "Ltas/internal/ipc/util/ServiceConnectionAbstract<TT;>;"
    const-string/jumbo v0, "TasIPCUtil<ServiceConnection>"

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "["

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mName:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string/jumbo v2, "] disconnecting ..."

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 124
    iget-object v0, p0, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mContext:Landroid/content/Context;

    invoke-virtual {v0, p0}, Landroid/content/Context;->unbindService(Landroid/content/ServiceConnection;)V

    .line 125
    invoke-direct {p0}, Ltas/internal/ipc/util/ServiceConnectionAbstract;->unlinkToDeath()V

    .line 126
    const/4 v0, 0x0

    iput-boolean v0, p0, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mBound:Z

    .line 127
    const/4 v0, 0x0

    iput-object v0, p0, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mRemote:Landroid/os/IInterface;

    .line 122
    return-void
.end method

.method private handleMessage(Landroid/os/Message;)V
    .locals 3
    .param p1, "msg"    # Landroid/os/Message;

    .prologue
    .line 304
    .local p0, "this":Ltas/internal/ipc/util/ServiceConnectionAbstract;, "Ltas/internal/ipc/util/ServiceConnectionAbstract<TT;>;"
    iget-object v0, p0, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mRemote:Landroid/os/IInterface;

    if-nez v0, :cond_0

    iget-boolean v0, p0, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mBound:Z

    if-nez v0, :cond_0

    .line 306
    const-string/jumbo v0, "TasIPCUtil<ServiceConnection>"

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "["

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mName:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string/jumbo v2, "] not yet ready. wait..."

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 307
    invoke-direct {p0}, Ltas/internal/ipc/util/ServiceConnectionAbstract;->lock()V

    .line 310
    :cond_0
    iget-object v1, p0, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mLock:Ljava/lang/Object;

    monitor-enter v1

    .line 311
    :try_start_0
    iget-object v0, p0, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mRemote:Landroid/os/IInterface;

    invoke-virtual {p0, v0, p1}, Ltas/internal/ipc/util/ServiceConnectionAbstract;->handleMessage(Landroid/os/IInterface;Landroid/os/Message;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit v1

    .line 303
    return-void

    .line 310
    :catchall_0
    move-exception v0

    monitor-exit v1

    throw v0
.end method

.method private linkToDeath(Landroid/os/IBinder;)V
    .locals 3
    .param p1, "binder"    # Landroid/os/IBinder;

    .prologue
    .line 254
    .local p0, "this":Ltas/internal/ipc/util/ServiceConnectionAbstract;, "Ltas/internal/ipc/util/ServiceConnectionAbstract<TT;>;"
    const/4 v1, 0x0

    :try_start_0
    invoke-interface {p1, p0, v1}, Landroid/os/IBinder;->linkToDeath(Landroid/os/IBinder$DeathRecipient;I)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    .line 252
    :goto_0
    return-void

    .line 255
    :catch_0
    move-exception v0

    .line 256
    .local v0, "e":Landroid/os/RemoteException;
    const-string/jumbo v1, "TasIPCUtil<ServiceConnection>"

    const-string/jumbo v2, "failed to linkToDeath."

    invoke-static {v1, v2, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    goto :goto_0
.end method

.method private lock()V
    .locals 3

    .prologue
    .line 290
    .local p0, "this":Ltas/internal/ipc/util/ServiceConnectionAbstract;, "Ltas/internal/ipc/util/ServiceConnectionAbstract<TT;>;"
    sget-object v1, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mSp:Ljava/util/concurrent/Semaphore;

    invoke-virtual {v1}, Ljava/util/concurrent/Semaphore;->drainPermits()I

    .line 293
    :try_start_0
    sget-object v1, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mSp:Ljava/util/concurrent/Semaphore;

    invoke-virtual {v1}, Ljava/util/concurrent/Semaphore;->acquire()V
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0

    .line 289
    :goto_0
    return-void

    .line 294
    :catch_0
    move-exception v0

    .line 295
    .local v0, "e":Ljava/lang/InterruptedException;
    const-string/jumbo v1, "TasIPCUtil<ServiceConnection>"

    const-string/jumbo v2, "failed to lock."

    invoke-static {v1, v2, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    goto :goto_0
.end method

.method private scheduleInternal(I)V
    .locals 1
    .param p1, "what"    # I

    .prologue
    .line 190
    .local p0, "this":Ltas/internal/ipc/util/ServiceConnectionAbstract;, "Ltas/internal/ipc/util/ServiceConnectionAbstract<TT;>;"
    iget-object v0, p0, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mH:Ltas/internal/ipc/util/ServiceConnectionAbstract$H;

    invoke-virtual {v0, p1}, Ltas/internal/ipc/util/ServiceConnectionAbstract$H;->sendEmptyMessage(I)Z

    .line 189
    return-void
.end method

.method private scheduleInternal(IILjava/lang/Object;)V
    .locals 3
    .param p1, "what"    # I
    .param p2, "arg1"    # I
    .param p3, "obj"    # Ljava/lang/Object;

    .prologue
    .line 194
    .local p0, "this":Ltas/internal/ipc/util/ServiceConnectionAbstract;, "Ltas/internal/ipc/util/ServiceConnectionAbstract<TT;>;"
    iget-object v0, p0, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mH:Ltas/internal/ipc/util/ServiceConnectionAbstract$H;

    iget-object v1, p0, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mH:Ltas/internal/ipc/util/ServiceConnectionAbstract$H;

    const/4 v2, 0x0

    invoke-virtual {v1, p1, p2, v2, p3}, Ltas/internal/ipc/util/ServiceConnectionAbstract$H;->obtainMessage(IIILjava/lang/Object;)Landroid/os/Message;

    move-result-object v1

    invoke-virtual {v0, v1}, Ltas/internal/ipc/util/ServiceConnectionAbstract$H;->sendMessage(Landroid/os/Message;)Z

    .line 193
    return-void
.end method

.method private startBackgroundThread()V
    .locals 3

    .prologue
    .line 267
    .local p0, "this":Ltas/internal/ipc/util/ServiceConnectionAbstract;, "Ltas/internal/ipc/util/ServiceConnectionAbstract<TT;>;"
    iget-object v0, p0, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mH:Ltas/internal/ipc/util/ServiceConnectionAbstract$H;

    if-nez v0, :cond_0

    .line 268
    new-instance v0, Landroid/os/HandlerThread;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "TasServiceConnection-"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mName:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/HandlerThread;-><init>(Ljava/lang/String;)V

    iput-object v0, p0, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mHT:Landroid/os/HandlerThread;

    .line 269
    iget-object v0, p0, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mHT:Landroid/os/HandlerThread;

    invoke-virtual {v0}, Landroid/os/HandlerThread;->start()V

    .line 270
    new-instance v0, Ltas/internal/ipc/util/ServiceConnectionAbstract$H;

    iget-object v1, p0, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mHT:Landroid/os/HandlerThread;

    invoke-virtual {v1}, Landroid/os/HandlerThread;->getLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1, p0}, Ltas/internal/ipc/util/ServiceConnectionAbstract$H;-><init>(Landroid/os/Looper;Ltas/internal/ipc/util/ServiceConnectionAbstract;)V

    iput-object v0, p0, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mH:Ltas/internal/ipc/util/ServiceConnectionAbstract$H;

    .line 271
    const-string/jumbo v0, "TasIPCUtil<ServiceConnection>"

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "serverconn tid="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mHT:Landroid/os/HandlerThread;

    invoke-virtual {v2}, Landroid/os/HandlerThread;->getThreadId()I

    move-result v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 266
    :cond_0
    return-void
.end method

.method private stopBackgroundThread()V
    .locals 2

    .prologue
    .local p0, "this":Ltas/internal/ipc/util/ServiceConnectionAbstract;, "Ltas/internal/ipc/util/ServiceConnectionAbstract<TT;>;"
    const/4 v1, 0x0

    .line 276
    iget-object v0, p0, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mHT:Landroid/os/HandlerThread;

    if-eqz v0, :cond_0

    .line 277
    iget-object v0, p0, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mHT:Landroid/os/HandlerThread;

    invoke-virtual {v0}, Landroid/os/HandlerThread;->quitSafely()Z

    .line 278
    iput-object v1, p0, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mHT:Landroid/os/HandlerThread;

    .line 279
    iput-object v1, p0, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mH:Ltas/internal/ipc/util/ServiceConnectionAbstract$H;

    .line 275
    :cond_0
    return-void
.end method

.method private unlinkToDeath()V
    .locals 2

    .prologue
    .line 261
    .local p0, "this":Ltas/internal/ipc/util/ServiceConnectionAbstract;, "Ltas/internal/ipc/util/ServiceConnectionAbstract<TT;>;"
    iget-object v0, p0, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mRemote:Landroid/os/IInterface;

    if-eqz v0, :cond_0

    .line 262
    iget-object v0, p0, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mRemote:Landroid/os/IInterface;

    invoke-interface {v0}, Landroid/os/IInterface;->asBinder()Landroid/os/IBinder;

    move-result-object v0

    const/4 v1, 0x0

    invoke-interface {v0, p0, v1}, Landroid/os/IBinder;->unlinkToDeath(Landroid/os/IBinder$DeathRecipient;I)Z

    .line 260
    :cond_0
    return-void
.end method

.method private unlock()V
    .locals 1

    .prologue
    .line 300
    .local p0, "this":Ltas/internal/ipc/util/ServiceConnectionAbstract;, "Ltas/internal/ipc/util/ServiceConnectionAbstract<TT;>;"
    sget-object v0, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mSp:Ljava/util/concurrent/Semaphore;

    invoke-virtual {v0}, Ljava/util/concurrent/Semaphore;->release()V

    .line 299
    return-void
.end method

.method private verifyMsg(I)V
    .locals 3
    .param p1, "what"    # I

    .prologue
    .line 180
    .local p0, "this":Ltas/internal/ipc/util/ServiceConnectionAbstract;, "Ltas/internal/ipc/util/ServiceConnectionAbstract<TT;>;"
    const/16 v0, 0x64

    if-ge p1, v0, :cond_0

    .line 181
    new-instance v0, Ljava/lang/IllegalArgumentException;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "invalid msg="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 179
    :cond_0
    return-void
.end method


# virtual methods
.method public addCallback(Ltas/internal/ipc/util/ServiceConnectionAbstract$Callback;)V
    .locals 2
    .param p1, "cb"    # Ltas/internal/ipc/util/ServiceConnectionAbstract$Callback;

    .prologue
    .line 131
    .local p0, "this":Ltas/internal/ipc/util/ServiceConnectionAbstract;, "Ltas/internal/ipc/util/ServiceConnectionAbstract<TT;>;"
    if-nez p1, :cond_0

    .line 132
    return-void

    .line 134
    :cond_0
    iget-object v1, p0, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mLock:Ljava/lang/Object;

    monitor-enter v1

    .line 135
    :try_start_0
    iget-object v0, p0, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mCallbacks:Ljava/util/List;

    if-nez v0, :cond_1

    .line 136
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mCallbacks:Ljava/util/List;

    .line 138
    :cond_1
    iget-object v0, p0, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mCallbacks:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_2

    .line 139
    iget-object v0, p0, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mCallbacks:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 141
    :cond_2
    iget-boolean v0, p0, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mBound:Z

    if-eqz v0, :cond_3

    iget-object v0, p0, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mRemote:Landroid/os/IInterface;

    if-eqz v0, :cond_3

    .line 142
    invoke-interface {p1}, Ltas/internal/ipc/util/ServiceConnectionAbstract$Callback;->onConnected()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_3
    monitor-exit v1

    .line 130
    return-void

    .line 134
    :catchall_0
    move-exception v0

    monitor-exit v1

    throw v0
.end method

.method public final binderDied()V
    .locals 6

    .prologue
    .line 237
    .local p0, "this":Ltas/internal/ipc/util/ServiceConnectionAbstract;, "Ltas/internal/ipc/util/ServiceConnectionAbstract<TT;>;"
    iget-object v3, p0, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mLock:Ljava/lang/Object;

    monitor-enter v3

    .line 238
    :try_start_0
    const-string/jumbo v2, "TasIPCUtil<ServiceConnection>"

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v5, "["

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    iget-object v5, p0, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mName:Ljava/lang/String;

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string/jumbo v5, "] died."

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v2, v4}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 239
    const/4 v2, 0x0

    iput-boolean v2, p0, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mBound:Z

    .line 240
    const/4 v2, 0x0

    iput-object v2, p0, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mRemote:Landroid/os/IInterface;

    .line 241
    invoke-virtual {p0}, Ltas/internal/ipc/util/ServiceConnectionAbstract;->onDeath()V

    .line 242
    iget-object v2, p0, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mCallbacks:Ljava/util/List;

    if-eqz v2, :cond_1

    .line 243
    iget-object v2, p0, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mCallbacks:Ljava/util/List;

    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    .local v1, "cb$iterator":Ljava/util/Iterator;
    :cond_0
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/ipc/util/ServiceConnectionAbstract$Callback;

    .line 244
    .local v0, "cb":Ltas/internal/ipc/util/ServiceConnectionAbstract$Callback;
    if-eqz v0, :cond_0

    invoke-interface {v0}, Ltas/internal/ipc/util/ServiceConnectionAbstract$Callback;->onDeath()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    .line 237
    .end local v0    # "cb":Ltas/internal/ipc/util/ServiceConnectionAbstract$Callback;
    .end local v1    # "cb$iterator":Ljava/util/Iterator;
    :catchall_0
    move-exception v2

    monitor-exit v3

    throw v2

    .line 247
    :cond_1
    :try_start_1
    invoke-direct {p0}, Ltas/internal/ipc/util/ServiceConnectionAbstract;->cancelAll()V

    .line 248
    invoke-direct {p0}, Ltas/internal/ipc/util/ServiceConnectionAbstract;->unlock()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    monitor-exit v3

    .line 236
    return-void
.end method

.method public cancel(I)V
    .locals 1
    .param p1, "what"    # I

    .prologue
    .line 156
    .local p0, "this":Ltas/internal/ipc/util/ServiceConnectionAbstract;, "Ltas/internal/ipc/util/ServiceConnectionAbstract<TT;>;"
    invoke-direct {p0, p1}, Ltas/internal/ipc/util/ServiceConnectionAbstract;->verifyMsg(I)V

    .line 157
    iget-object v0, p0, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mH:Ltas/internal/ipc/util/ServiceConnectionAbstract$H;

    invoke-virtual {v0, p1}, Ltas/internal/ipc/util/ServiceConnectionAbstract$H;->removeMessages(I)V

    .line 155
    return-void
.end method

.method public connect(Landroid/content/Context;Landroid/content/ComponentName;I)V
    .locals 3
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "name"    # Landroid/content/ComponentName;
    .param p3, "flags"    # I

    .prologue
    .line 89
    .local p0, "this":Ltas/internal/ipc/util/ServiceConnectionAbstract;, "Ltas/internal/ipc/util/ServiceConnectionAbstract<TT;>;"
    invoke-direct {p0}, Ltas/internal/ipc/util/ServiceConnectionAbstract;->startBackgroundThread()V

    .line 90
    iget-object v1, p0, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mLock:Ljava/lang/Object;

    monitor-enter v1

    .line 91
    :try_start_0
    iget v0, p0, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mRef:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mRef:I

    .line 92
    iget v0, p0, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mRef:I

    const/4 v2, 0x1

    if-ne v0, v2, :cond_0

    iget-boolean v0, p0, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mBound:Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-eqz v0, :cond_1

    :cond_0
    :goto_0
    monitor-exit v1

    .line 88
    return-void

    .line 92
    :cond_1
    :try_start_1
    iget-boolean v0, p0, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mBinding:Z

    if-nez v0, :cond_0

    .line 93
    const/4 v0, 0x0

    invoke-direct {p0, v0}, Ltas/internal/ipc/util/ServiceConnectionAbstract;->scheduleInternal(I)V

    .line 94
    invoke-direct {p0, p1, p2, p3}, Ltas/internal/ipc/util/ServiceConnectionAbstract;->doConnectLocked(Landroid/content/Context;Landroid/content/ComponentName;I)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_0

    .line 90
    :catchall_0
    move-exception v0

    monitor-exit v1

    throw v0
.end method

.method public connect(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;I)V
    .locals 1
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "pkg"    # Ljava/lang/String;
    .param p3, "cls"    # Ljava/lang/String;
    .param p4, "flags"    # I

    .prologue
    .line 85
    .local p0, "this":Ltas/internal/ipc/util/ServiceConnectionAbstract;, "Ltas/internal/ipc/util/ServiceConnectionAbstract<TT;>;"
    new-instance v0, Landroid/content/ComponentName;

    invoke-direct {v0, p2, p3}, Landroid/content/ComponentName;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {p0, p1, v0, p4}, Ltas/internal/ipc/util/ServiceConnectionAbstract;->connect(Landroid/content/Context;Landroid/content/ComponentName;I)V

    .line 84
    return-void
.end method

.method public disconnect()V
    .locals 1

    .prologue
    .line 100
    .local p0, "this":Ltas/internal/ipc/util/ServiceConnectionAbstract;, "Ltas/internal/ipc/util/ServiceConnectionAbstract<TT;>;"
    const/4 v0, 0x1

    invoke-direct {p0, v0}, Ltas/internal/ipc/util/ServiceConnectionAbstract;->scheduleInternal(I)V

    .line 99
    return-void
.end method

.method protected getRemote()Landroid/os/IInterface;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TT;"
        }
    .end annotation

    .prologue
    .line 68
    .local p0, "this":Ltas/internal/ipc/util/ServiceConnectionAbstract;, "Ltas/internal/ipc/util/ServiceConnectionAbstract<TT;>;"
    iget-object v0, p0, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mRemote:Landroid/os/IInterface;

    return-object v0
.end method

.method public handleMessage(Landroid/os/IInterface;Landroid/os/Message;)V
    .locals 0
    .param p2, "msg"    # Landroid/os/Message;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;",
            "Landroid/os/Message;",
            ")V"
        }
    .end annotation

    .prologue
    .line 74
    .local p0, "this":Ltas/internal/ipc/util/ServiceConnectionAbstract;, "Ltas/internal/ipc/util/ServiceConnectionAbstract<TT;>;"
    .local p1, "remote":Landroid/os/IInterface;, "TT;"
    return-void
.end method

.method public hasMsg(I)Z
    .locals 1
    .param p1, "what"    # I

    .prologue
    .line 176
    .local p0, "this":Ltas/internal/ipc/util/ServiceConnectionAbstract;, "Ltas/internal/ipc/util/ServiceConnectionAbstract<TT;>;"
    iget-object v0, p0, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mH:Ltas/internal/ipc/util/ServiceConnectionAbstract$H;

    invoke-virtual {v0, p1}, Ltas/internal/ipc/util/ServiceConnectionAbstract$H;->hasMessages(I)Z

    move-result v0

    return v0
.end method

.method public isConnected()Z
    .locals 1

    .prologue
    .line 77
    .local p0, "this":Ltas/internal/ipc/util/ServiceConnectionAbstract;, "Ltas/internal/ipc/util/ServiceConnectionAbstract<TT;>;"
    iget-boolean v0, p0, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mBound:Z

    return v0
.end method

.method public isConnecting()Z
    .locals 1

    .prologue
    .line 81
    .local p0, "this":Ltas/internal/ipc/util/ServiceConnectionAbstract;, "Ltas/internal/ipc/util/ServiceConnectionAbstract<TT;>;"
    iget-boolean v0, p0, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mBinding:Z

    return v0
.end method

.method public abstract onConnected(Landroid/os/IBinder;)Landroid/os/IInterface;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/os/IBinder;",
            ")TT;"
        }
    .end annotation
.end method

.method public onDeath()V
    .locals 0

    .prologue
    .line 72
    .local p0, "this":Ltas/internal/ipc/util/ServiceConnectionAbstract;, "Ltas/internal/ipc/util/ServiceConnectionAbstract<TT;>;"
    return-void
.end method

.method public onDisconnected()V
    .locals 0

    .prologue
    .line 71
    .local p0, "this":Ltas/internal/ipc/util/ServiceConnectionAbstract;, "Ltas/internal/ipc/util/ServiceConnectionAbstract<TT;>;"
    return-void
.end method

.method public final onServiceConnected(Landroid/content/ComponentName;Landroid/os/IBinder;)V
    .locals 6
    .param p1, "name"    # Landroid/content/ComponentName;
    .param p2, "binder"    # Landroid/os/IBinder;

    .prologue
    .line 199
    .local p0, "this":Ltas/internal/ipc/util/ServiceConnectionAbstract;, "Ltas/internal/ipc/util/ServiceConnectionAbstract<TT;>;"
    iget-object v3, p0, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mLock:Ljava/lang/Object;

    monitor-enter v3

    .line 200
    :try_start_0
    const-string/jumbo v2, "TasIPCUtil<ServiceConnection>"

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v5, "["

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    iget-object v5, p0, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mName:Ljava/lang/String;

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string/jumbo v5, "] connected."

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v2, v4}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 201
    const/4 v2, 0x1

    iput-boolean v2, p0, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mBound:Z

    .line 202
    const/4 v2, 0x0

    iput-boolean v2, p0, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mBinding:Z

    .line 203
    invoke-virtual {p0, p2}, Ltas/internal/ipc/util/ServiceConnectionAbstract;->onConnected(Landroid/os/IBinder;)Landroid/os/IInterface;

    move-result-object v2

    iput-object v2, p0, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mRemote:Landroid/os/IInterface;

    .line 204
    iget-object v2, p0, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mRemote:Landroid/os/IInterface;

    if-nez v2, :cond_0

    .line 205
    new-instance v2, Ljava/lang/IllegalStateException;

    const-string/jumbo v4, "onConnected returns null."

    invoke-direct {v2, v4}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 199
    :catchall_0
    move-exception v2

    monitor-exit v3

    throw v2

    .line 208
    :cond_0
    :try_start_1
    invoke-direct {p0, p2}, Ltas/internal/ipc/util/ServiceConnectionAbstract;->linkToDeath(Landroid/os/IBinder;)V

    .line 209
    iget-object v2, p0, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mCallbacks:Ljava/util/List;

    if-eqz v2, :cond_2

    .line 210
    iget-object v2, p0, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mCallbacks:Ljava/util/List;

    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    .local v1, "cb$iterator":Ljava/util/Iterator;
    :cond_1
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_2

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/ipc/util/ServiceConnectionAbstract$Callback;

    .line 211
    .local v0, "cb":Ltas/internal/ipc/util/ServiceConnectionAbstract$Callback;
    if-eqz v0, :cond_1

    invoke-interface {v0}, Ltas/internal/ipc/util/ServiceConnectionAbstract$Callback;->onConnected()V

    goto :goto_0

    .line 214
    .end local v0    # "cb":Ltas/internal/ipc/util/ServiceConnectionAbstract$Callback;
    .end local v1    # "cb$iterator":Ljava/util/Iterator;
    :cond_2
    invoke-direct {p0}, Ltas/internal/ipc/util/ServiceConnectionAbstract;->unlock()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    monitor-exit v3

    .line 198
    return-void
.end method

.method public final onServiceDisconnected(Landroid/content/ComponentName;)V
    .locals 6
    .param p1, "name"    # Landroid/content/ComponentName;

    .prologue
    .line 220
    .local p0, "this":Ltas/internal/ipc/util/ServiceConnectionAbstract;, "Ltas/internal/ipc/util/ServiceConnectionAbstract<TT;>;"
    iget-object v3, p0, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mLock:Ljava/lang/Object;

    monitor-enter v3

    .line 221
    :try_start_0
    const-string/jumbo v2, "TasIPCUtil<ServiceConnection>"

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v5, "["

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    iget-object v5, p0, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mName:Ljava/lang/String;

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string/jumbo v5, "] disconnected."

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v2, v4}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 222
    const/4 v2, 0x0

    iput-boolean v2, p0, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mBound:Z

    .line 223
    const/4 v2, 0x0

    iput-object v2, p0, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mRemote:Landroid/os/IInterface;

    .line 224
    invoke-virtual {p0}, Ltas/internal/ipc/util/ServiceConnectionAbstract;->onDisconnected()V

    .line 225
    iget-object v2, p0, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mCallbacks:Ljava/util/List;

    if-eqz v2, :cond_1

    .line 226
    iget-object v2, p0, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mCallbacks:Ljava/util/List;

    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    .local v1, "cb$iterator":Ljava/util/Iterator;
    :cond_0
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/ipc/util/ServiceConnectionAbstract$Callback;

    .line 227
    .local v0, "cb":Ltas/internal/ipc/util/ServiceConnectionAbstract$Callback;
    if-eqz v0, :cond_0

    invoke-interface {v0}, Ltas/internal/ipc/util/ServiceConnectionAbstract$Callback;->onDisconnected()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    .line 220
    .end local v0    # "cb":Ltas/internal/ipc/util/ServiceConnectionAbstract$Callback;
    .end local v1    # "cb$iterator":Ljava/util/Iterator;
    :catchall_0
    move-exception v2

    monitor-exit v3

    throw v2

    .line 230
    :cond_1
    :try_start_1
    invoke-direct {p0}, Ltas/internal/ipc/util/ServiceConnectionAbstract;->cancelAll()V

    .line 231
    invoke-direct {p0}, Ltas/internal/ipc/util/ServiceConnectionAbstract;->unlock()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    monitor-exit v3

    .line 219
    return-void
.end method

.method public quitSafely()V
    .locals 0

    .prologue
    .line 284
    .local p0, "this":Ltas/internal/ipc/util/ServiceConnectionAbstract;, "Ltas/internal/ipc/util/ServiceConnectionAbstract<TT;>;"
    invoke-direct {p0}, Ltas/internal/ipc/util/ServiceConnectionAbstract;->cancelAll()V

    .line 285
    invoke-direct {p0}, Ltas/internal/ipc/util/ServiceConnectionAbstract;->unlock()V

    .line 286
    invoke-direct {p0}, Ltas/internal/ipc/util/ServiceConnectionAbstract;->stopBackgroundThread()V

    .line 283
    return-void
.end method

.method public removeCallback(Ltas/internal/ipc/util/ServiceConnectionAbstract$Callback;)V
    .locals 2
    .param p1, "cb"    # Ltas/internal/ipc/util/ServiceConnectionAbstract$Callback;

    .prologue
    .line 148
    .local p0, "this":Ltas/internal/ipc/util/ServiceConnectionAbstract;, "Ltas/internal/ipc/util/ServiceConnectionAbstract<TT;>;"
    iget-object v1, p0, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mLock:Ljava/lang/Object;

    monitor-enter v1

    .line 149
    :try_start_0
    iget-object v0, p0, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mCallbacks:Ljava/util/List;

    if-eqz v0, :cond_0

    iget-object v0, p0, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mCallbacks:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 150
    iget-object v0, p0, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mCallbacks:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->remove(Ljava/lang/Object;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_0
    monitor-exit v1

    .line 147
    return-void

    .line 148
    :catchall_0
    move-exception v0

    monitor-exit v1

    throw v0
.end method

.method public schedule(I)V
    .locals 1
    .param p1, "what"    # I

    .prologue
    .line 161
    .local p0, "this":Ltas/internal/ipc/util/ServiceConnectionAbstract;, "Ltas/internal/ipc/util/ServiceConnectionAbstract<TT;>;"
    invoke-direct {p0, p1}, Ltas/internal/ipc/util/ServiceConnectionAbstract;->verifyMsg(I)V

    .line 162
    iget-object v0, p0, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mH:Ltas/internal/ipc/util/ServiceConnectionAbstract$H;

    invoke-virtual {v0, p1}, Ltas/internal/ipc/util/ServiceConnectionAbstract$H;->sendEmptyMessage(I)Z

    .line 160
    return-void
.end method

.method public schedule(ILjava/lang/Object;)V
    .locals 3
    .param p1, "what"    # I
    .param p2, "obj"    # Ljava/lang/Object;

    .prologue
    .local p0, "this":Ltas/internal/ipc/util/ServiceConnectionAbstract;, "Ltas/internal/ipc/util/ServiceConnectionAbstract<TT;>;"
    const/4 v2, 0x0

    .line 166
    invoke-direct {p0, p1}, Ltas/internal/ipc/util/ServiceConnectionAbstract;->verifyMsg(I)V

    .line 167
    iget-object v0, p0, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mH:Ltas/internal/ipc/util/ServiceConnectionAbstract$H;

    iget-object v1, p0, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mH:Ltas/internal/ipc/util/ServiceConnectionAbstract$H;

    invoke-virtual {v1, p1, v2, v2, p2}, Ltas/internal/ipc/util/ServiceConnectionAbstract$H;->obtainMessage(IIILjava/lang/Object;)Landroid/os/Message;

    move-result-object v1

    invoke-virtual {v0, v1}, Ltas/internal/ipc/util/ServiceConnectionAbstract$H;->sendMessage(Landroid/os/Message;)Z

    .line 165
    return-void
.end method

.method public scheduleAtFrontOfQueue(ILjava/lang/Object;)V
    .locals 3
    .param p1, "what"    # I
    .param p2, "obj"    # Ljava/lang/Object;

    .prologue
    .local p0, "this":Ltas/internal/ipc/util/ServiceConnectionAbstract;, "Ltas/internal/ipc/util/ServiceConnectionAbstract<TT;>;"
    const/4 v2, 0x0

    .line 171
    invoke-direct {p0, p1}, Ltas/internal/ipc/util/ServiceConnectionAbstract;->verifyMsg(I)V

    .line 172
    iget-object v0, p0, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mH:Ltas/internal/ipc/util/ServiceConnectionAbstract$H;

    iget-object v1, p0, Ltas/internal/ipc/util/ServiceConnectionAbstract;->mH:Ltas/internal/ipc/util/ServiceConnectionAbstract$H;

    invoke-virtual {v1, p1, v2, v2, p2}, Ltas/internal/ipc/util/ServiceConnectionAbstract$H;->obtainMessage(IIILjava/lang/Object;)Landroid/os/Message;

    move-result-object v1

    invoke-virtual {v0, v1}, Ltas/internal/ipc/util/ServiceConnectionAbstract$H;->sendMessageAtFrontOfQueue(Landroid/os/Message;)Z

    .line 170
    return-void
.end method
