.class public final enum Ltas/internal/avm/AvmEnumerations$PGSCoordType;
.super Ljava/lang/Enum;
.source "AvmEnumerations.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltas/internal/avm/AvmEnumerations;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "PGSCoordType"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum",
        "<",
        "Ltas/internal/avm/AvmEnumerations$PGSCoordType;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Ltas/internal/avm/AvmEnumerations$PGSCoordType;

.field public static final enum PG_TYPE_COORD_IMAGE:Ltas/internal/avm/AvmEnumerations$PGSCoordType;

.field public static final enum PG_TYPE_COORD_UNKNOWN:Ltas/internal/avm/AvmEnumerations$PGSCoordType;

.field public static final enum PG_TYPE_COORD_WORLD:Ltas/internal/avm/AvmEnumerations$PGSCoordType;


# instance fields
.field private type:I


# direct methods
.method static constructor <clinit>()V
    .locals 6

    .prologue
    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v3, 0x0

    .line 328
    new-instance v0, Ltas/internal/avm/AvmEnumerations$PGSCoordType;

    const-string/jumbo v1, "PG_TYPE_COORD_WORLD"

    invoke-direct {v0, v1, v3, v3}, Ltas/internal/avm/AvmEnumerations$PGSCoordType;-><init>(Ljava/lang/String;II)V

    sput-object v0, Ltas/internal/avm/AvmEnumerations$PGSCoordType;->PG_TYPE_COORD_WORLD:Ltas/internal/avm/AvmEnumerations$PGSCoordType;

    .line 329
    new-instance v0, Ltas/internal/avm/AvmEnumerations$PGSCoordType;

    const-string/jumbo v1, "PG_TYPE_COORD_IMAGE"

    invoke-direct {v0, v1, v4, v4}, Ltas/internal/avm/AvmEnumerations$PGSCoordType;-><init>(Ljava/lang/String;II)V

    sput-object v0, Ltas/internal/avm/AvmEnumerations$PGSCoordType;->PG_TYPE_COORD_IMAGE:Ltas/internal/avm/AvmEnumerations$PGSCoordType;

    .line 330
    new-instance v0, Ltas/internal/avm/AvmEnumerations$PGSCoordType;

    const-string/jumbo v1, "PG_TYPE_COORD_UNKNOWN"

    const/16 v2, 0xff

    invoke-direct {v0, v1, v5, v2}, Ltas/internal/avm/AvmEnumerations$PGSCoordType;-><init>(Ljava/lang/String;II)V

    sput-object v0, Ltas/internal/avm/AvmEnumerations$PGSCoordType;->PG_TYPE_COORD_UNKNOWN:Ltas/internal/avm/AvmEnumerations$PGSCoordType;

    .line 327
    const/4 v0, 0x3

    new-array v0, v0, [Ltas/internal/avm/AvmEnumerations$PGSCoordType;

    sget-object v1, Ltas/internal/avm/AvmEnumerations$PGSCoordType;->PG_TYPE_COORD_WORLD:Ltas/internal/avm/AvmEnumerations$PGSCoordType;

    aput-object v1, v0, v3

    sget-object v1, Ltas/internal/avm/AvmEnumerations$PGSCoordType;->PG_TYPE_COORD_IMAGE:Ltas/internal/avm/AvmEnumerations$PGSCoordType;

    aput-object v1, v0, v4

    sget-object v1, Ltas/internal/avm/AvmEnumerations$PGSCoordType;->PG_TYPE_COORD_UNKNOWN:Ltas/internal/avm/AvmEnumerations$PGSCoordType;

    aput-object v1, v0, v5

    sput-object v0, Ltas/internal/avm/AvmEnumerations$PGSCoordType;->$VALUES:[Ltas/internal/avm/AvmEnumerations$PGSCoordType;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .locals 0
    .param p3, "type"    # I

    .prologue
    .line 333
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 334
    iput p3, p0, Ltas/internal/avm/AvmEnumerations$PGSCoordType;->type:I

    .line 333
    return-void
.end method

.method public static createFromOrdinalNumber(I)Ltas/internal/avm/AvmEnumerations$PGSCoordType;
    .locals 5
    .param p0, "number"    # I

    .prologue
    .line 351
    invoke-static {}, Ltas/internal/avm/AvmEnumerations$PGSCoordType;->values()[Ltas/internal/avm/AvmEnumerations$PGSCoordType;

    move-result-object v2

    const/4 v1, 0x0

    array-length v3, v2

    :goto_0
    if-ge v1, v3, :cond_1

    aget-object v0, v2, v1

    .line 352
    .local v0, "i":Ltas/internal/avm/AvmEnumerations$PGSCoordType;
    invoke-virtual {v0}, Ltas/internal/avm/AvmEnumerations$PGSCoordType;->ordinal()I

    move-result v4

    if-ne v4, p0, :cond_0

    .line 353
    return-object v0

    .line 351
    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    .line 356
    .end local v0    # "i":Ltas/internal/avm/AvmEnumerations$PGSCoordType;
    :cond_1
    sget-object v1, Ltas/internal/avm/AvmEnumerations$PGSCoordType;->PG_TYPE_COORD_UNKNOWN:Ltas/internal/avm/AvmEnumerations$PGSCoordType;

    return-object v1
.end method

.method public static createFromValue(I)Ltas/internal/avm/AvmEnumerations$PGSCoordType;
    .locals 5
    .param p0, "type"    # I

    .prologue
    .line 342
    invoke-static {}, Ltas/internal/avm/AvmEnumerations$PGSCoordType;->values()[Ltas/internal/avm/AvmEnumerations$PGSCoordType;

    move-result-object v2

    const/4 v1, 0x0

    array-length v3, v2

    :goto_0
    if-ge v1, v3, :cond_1

    aget-object v0, v2, v1

    .line 343
    .local v0, "i":Ltas/internal/avm/AvmEnumerations$PGSCoordType;
    invoke-virtual {v0}, Ltas/internal/avm/AvmEnumerations$PGSCoordType;->toInteger()I

    move-result v4

    if-ne v4, p0, :cond_0

    .line 344
    return-object v0

    .line 342
    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    .line 347
    .end local v0    # "i":Ltas/internal/avm/AvmEnumerations$PGSCoordType;
    :cond_1
    sget-object v1, Ltas/internal/avm/AvmEnumerations$PGSCoordType;->PG_TYPE_COORD_UNKNOWN:Ltas/internal/avm/AvmEnumerations$PGSCoordType;

    return-object v1
.end method

.method public static valueOf(Ljava/lang/String;)Ltas/internal/avm/AvmEnumerations$PGSCoordType;
    .locals 1
    .param p0, "name"    # Ljava/lang/String;

    .prologue
    .line 327
    const-class v0, Ltas/internal/avm/AvmEnumerations$PGSCoordType;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object v0

    check-cast v0, Ltas/internal/avm/AvmEnumerations$PGSCoordType;

    return-object v0
.end method

.method public static values()[Ltas/internal/avm/AvmEnumerations$PGSCoordType;
    .locals 1

    .prologue
    .line 327
    sget-object v0, Ltas/internal/avm/AvmEnumerations$PGSCoordType;->$VALUES:[Ltas/internal/avm/AvmEnumerations$PGSCoordType;

    return-object v0
.end method


# virtual methods
.method public toInteger()I
    .locals 1

    .prologue
    .line 338
    iget v0, p0, Ltas/internal/avm/AvmEnumerations$PGSCoordType;->type:I

    return v0
.end method
