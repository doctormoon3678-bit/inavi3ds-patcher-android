.class public Lcom/thinkware/sundo/ieve/ieveARView;
.super Landroid/opengl/GLSurfaceView;
.source "ieveARView.java"

# interfaces
.implements Landroid/opengl/GLSurfaceView$Renderer;


# static fields
.field private static final a:Ljava/lang/String;


# instance fields
.field private b:Landroid/content/Context;

.field private c:Landroid/view/SurfaceHolder;

.field private d:Lcom/thinkware/sundo/ieve/IEVE;

.field private e:I

.field private f:Z


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .prologue
    .line 17
    const-class v0, Lcom/thinkware/sundo/ieve/ieveARView;

    invoke-virtual {v0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveARView;->a:Ljava/lang/String;

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Lcom/thinkware/sundo/ieve/IEVE;)V
    .locals 5
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "ieve"    # Lcom/thinkware/sundo/ieve/IEVE;

    .prologue
    const/16 v4, 0x1e

    const/4 v3, 0x0

    const/4 v1, 0x0

    .line 28
    invoke-direct {p0, p1}, Landroid/opengl/GLSurfaceView;-><init>(Landroid/content/Context;)V

    .line 18
    iput-object v1, p0, Lcom/thinkware/sundo/ieve/ieveARView;->b:Landroid/content/Context;

    .line 19
    iput-object v1, p0, Lcom/thinkware/sundo/ieve/ieveARView;->c:Landroid/view/SurfaceHolder;

    .line 21
    iput-object v1, p0, Lcom/thinkware/sundo/ieve/ieveARView;->d:Lcom/thinkware/sundo/ieve/IEVE;

    .line 23
    iput v4, p0, Lcom/thinkware/sundo/ieve/ieveARView;->e:I

    .line 24
    const/4 v1, 0x1

    iput-boolean v1, p0, Lcom/thinkware/sundo/ieve/ieveARView;->f:Z

    .line 29
    sget-object v1, Lcom/thinkware/sundo/ieve/ieveARView;->a:Ljava/lang/String;

    const-string v2, "Constructor"

    invoke-static {v1, v2}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 30
    iput-object p1, p0, Lcom/thinkware/sundo/ieve/ieveARView;->b:Landroid/content/Context;

    .line 31
    iput-object p2, p0, Lcom/thinkware/sundo/ieve/ieveARView;->d:Lcom/thinkware/sundo/ieve/IEVE;

    .line 33
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/ieveARView;->b:Landroid/content/Context;

    if-nez v1, :cond_0

    .line 34
    const-string v1, "Context is null!"

    new-array v2, v3, [Ljava/lang/Object;

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    .line 35
    .local v0, "text":Ljava/lang/String;
    sget-object v1, Lcom/thinkware/sundo/ieve/ieveARView;->a:Ljava/lang/String;

    invoke-static {v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 49
    .end local v0    # "text":Ljava/lang/String;
    :goto_0
    return-void

    .line 38
    :cond_0
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/ieveARView;->d:Lcom/thinkware/sundo/ieve/IEVE;

    if-nez v1, :cond_1

    .line 39
    const-string v1, "IEVE is null!"

    new-array v2, v3, [Ljava/lang/Object;

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    .line 40
    .restart local v0    # "text":Ljava/lang/String;
    sget-object v1, Lcom/thinkware/sundo/ieve/ieveARView;->a:Ljava/lang/String;

    invoke-static {v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    .line 43
    .end local v0    # "text":Ljava/lang/String;
    :cond_1
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/ieveARView;->d:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-virtual {v1}, Lcom/thinkware/sundo/ieve/IEVE;->getDeviceModelType()I

    move-result v1

    packed-switch v1, :pswitch_data_0

    .line 45
    const/16 v1, 0x28

    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveARView;->e:I

    .line 48
    :goto_1
    invoke-direct {p0}, Lcom/thinkware/sundo/ieve/ieveARView;->a()V

    goto :goto_0

    .line 44
    :pswitch_0
    iput v4, p0, Lcom/thinkware/sundo/ieve/ieveARView;->e:I

    goto :goto_1

    .line 43
    nop

    :pswitch_data_0
    .packed-switch 0xa
        :pswitch_0
    .end packed-switch
.end method

.method private a()V
    .locals 6

    .prologue
    const/4 v4, 0x1

    .line 52
    const-string v1, ""

    .line 53
    .local v1, "text":Ljava/lang/String;
    invoke-virtual {p0}, Lcom/thinkware/sundo/ieve/ieveARView;->getHolder()Landroid/view/SurfaceHolder;

    move-result-object v2

    iput-object v2, p0, Lcom/thinkware/sundo/ieve/ieveARView;->c:Landroid/view/SurfaceHolder;

    .line 54
    iget-object v2, p0, Lcom/thinkware/sundo/ieve/ieveARView;->c:Landroid/view/SurfaceHolder;

    invoke-interface {v2, p0}, Landroid/view/SurfaceHolder;->addCallback(Landroid/view/SurfaceHolder$Callback;)V

    .line 55
    iget-object v2, p0, Lcom/thinkware/sundo/ieve/ieveARView;->c:Landroid/view/SurfaceHolder;

    invoke-interface {v2, v4}, Landroid/view/SurfaceHolder;->setFormat(I)V

    .line 59
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveARView$1;

    invoke-direct {v0, p0}, Lcom/thinkware/sundo/ieve/ieveARView$1;-><init>(Lcom/thinkware/sundo/ieve/ieveARView;)V

    .line 90
    .local v0, "mCostumChooser":Landroid/opengl/GLSurfaceView$EGLConfigChooser;
    invoke-virtual {p0, v4}, Lcom/thinkware/sundo/ieve/ieveARView;->setEGLContextClientVersion(I)V

    .line 92
    invoke-virtual {p0, v0}, Lcom/thinkware/sundo/ieve/ieveARView;->setEGLConfigChooser(Landroid/opengl/GLSurfaceView$EGLConfigChooser;)V

    .line 93
    invoke-virtual {p0, p0}, Lcom/thinkware/sundo/ieve/ieveARView;->setRenderer(Landroid/opengl/GLSurfaceView$Renderer;)V

    .line 94
    invoke-virtual {p0, v4}, Lcom/thinkware/sundo/ieve/ieveARView;->setRenderMode(I)V

    .line 95
    invoke-virtual {p0, v4}, Lcom/thinkware/sundo/ieve/ieveARView;->setZOrderMediaOverlay(Z)V

    .line 98
    const-string v3, "32Bit(%s), setEGLContextClientVersion(1), setRenderMode(RENDERMODE_CONTINUOUSLY), setZOrderMediaOverlay(true)"

    new-array v4, v4, [Ljava/lang/Object;

    const/4 v5, 0x0

    iget-boolean v2, p0, Lcom/thinkware/sundo/ieve/ieveARView;->f:Z

    if-eqz v2, :cond_0

    const-string v2, "T"

    :goto_0
    aput-object v2, v4, v5

    invoke-static {v3, v4}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    .line 99
    sget-object v2, Lcom/thinkware/sundo/ieve/ieveARView;->a:Ljava/lang/String;

    invoke-static {v2, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 101
    iget-object v2, p0, Lcom/thinkware/sundo/ieve/ieveARView;->b:Landroid/content/Context;

    invoke-virtual {v2}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v2

    const-string v3, "com.thinkware.sundo.ieves"

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 104
    return-void

    .line 98
    :cond_0
    const-string v2, "F"

    goto :goto_0
.end method

.method static synthetic a(Lcom/thinkware/sundo/ieve/ieveARView;)Z
    .locals 1

    .prologue
    .line 24
    iget-boolean v0, p0, Lcom/thinkware/sundo/ieve/ieveARView;->f:Z

    return v0
.end method


# virtual methods
.method public onDrawFrame(Ljavax/microedition/khronos/opengles/GL10;)V
    .locals 10
    .param p1, "gl"    # Ljavax/microedition/khronos/opengles/GL10;

    .prologue
    .line 126
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveARView;->d:Lcom/thinkware/sundo/ieve/IEVE;

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveARView;->d:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/IEVE;->getNative()Lcom/thinkware/sundo/ieve/ieveNative;

    move-result-object v0

    if-nez v0, :cond_1

    .line 134
    :cond_0
    :goto_0
    return-void

    .line 127
    :cond_1
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveARView;->d:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/IEVE;->getNative()Lcom/thinkware/sundo/ieve/ieveNative;

    move-result-object v0

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->onDrawFrame()V

    .line 128
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveARView;->d:Lcom/thinkware/sundo/ieve/IEVE;

    const/16 v1, 0x3e9

    const-string v2, "AR: %.1ffps"

    const/4 v3, 0x1

    new-array v3, v3, [Ljava/lang/Object;

    const/4 v4, 0x0

    iget-object v5, p0, Lcom/thinkware/sundo/ieve/ieveARView;->d:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-virtual {v5}, Lcom/thinkware/sundo/ieve/IEVE;->getFrameRateAR()D

    move-result-wide v8

    invoke-static {v8, v9}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v5

    aput-object v5, v3, v4

    invoke-static {v2, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    const/high16 v3, 0x44200000    # 640.0f

    const/high16 v4, 0x41c80000    # 25.0f

    const/high16 v5, 0x41a00000    # 20.0f

    const v6, -0xff0100

    invoke-virtual/range {v0 .. v6}, Lcom/thinkware/sundo/ieve/IEVE;->DebugPrint(ILjava/lang/String;FFFI)V

    .line 130
    :try_start_0
    iget v0, p0, Lcom/thinkware/sundo/ieve/ieveARView;->e:I

    int-to-long v0, v0

    invoke-static {v0, v1}, Ljava/lang/Thread;->sleep(J)V
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    .line 131
    :catch_0
    move-exception v7

    .line 132
    .local v7, "e":Ljava/lang/InterruptedException;
    invoke-virtual {v7}, Ljava/lang/InterruptedException;->printStackTrace()V

    goto :goto_0
.end method

.method public onSurfaceChanged(Ljavax/microedition/khronos/opengles/GL10;II)V
    .locals 2
    .param p1, "gl"    # Ljavax/microedition/khronos/opengles/GL10;
    .param p2, "width"    # I
    .param p3, "height"    # I

    .prologue
    .line 138
    sget-object v0, Lcom/thinkware/sundo/ieve/ieveARView;->a:Ljava/lang/String;

    const-string v1, "onSurfaceChanged"

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 139
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveARView;->d:Lcom/thinkware/sundo/ieve/IEVE;

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveARView;->d:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/IEVE;->getNative()Lcom/thinkware/sundo/ieve/ieveNative;

    move-result-object v0

    if-nez v0, :cond_1

    .line 141
    :cond_0
    :goto_0
    return-void

    .line 140
    :cond_1
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveARView;->d:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/IEVE;->getNative()Lcom/thinkware/sundo/ieve/ieveNative;

    move-result-object v0

    invoke-virtual {v0, p2, p3}, Lcom/thinkware/sundo/ieve/ieveNative;->onSurfaceChanged(II)V

    goto :goto_0
.end method

.method public onSurfaceCreated(Ljavax/microedition/khronos/opengles/GL10;Ljavax/microedition/khronos/egl/EGLConfig;)V
    .locals 2
    .param p1, "gl"    # Ljavax/microedition/khronos/opengles/GL10;
    .param p2, "config"    # Ljavax/microedition/khronos/egl/EGLConfig;

    .prologue
    .line 145
    sget-object v0, Lcom/thinkware/sundo/ieve/ieveARView;->a:Ljava/lang/String;

    const-string v1, "onSurfaceCreated"

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 146
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveARView;->d:Lcom/thinkware/sundo/ieve/IEVE;

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveARView;->d:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/IEVE;->getNative()Lcom/thinkware/sundo/ieve/ieveNative;

    move-result-object v0

    if-nez v0, :cond_1

    .line 148
    :cond_0
    :goto_0
    return-void

    .line 147
    :cond_1
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveARView;->d:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/IEVE;->getNative()Lcom/thinkware/sundo/ieve/ieveNative;

    move-result-object v0

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveNative;->onSurfaceCreated()V

    goto :goto_0
.end method

.method public surfaceChanged(Landroid/view/SurfaceHolder;III)V
    .locals 2
    .param p1, "surface"    # Landroid/view/SurfaceHolder;
    .param p2, "format"    # I
    .param p3, "width"    # I
    .param p4, "height"    # I

    .prologue
    .line 108
    invoke-super {p0, p1, p2, p3, p4}, Landroid/opengl/GLSurfaceView;->surfaceChanged(Landroid/view/SurfaceHolder;III)V

    .line 109
    sget-object v0, Lcom/thinkware/sundo/ieve/ieveARView;->a:Ljava/lang/String;

    const-string v1, "surfaceChanged"

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 110
    return-void
.end method

.method public surfaceCreated(Landroid/view/SurfaceHolder;)V
    .locals 2
    .param p1, "surface"    # Landroid/view/SurfaceHolder;

    .prologue
    .line 114
    invoke-super {p0, p1}, Landroid/opengl/GLSurfaceView;->surfaceCreated(Landroid/view/SurfaceHolder;)V

    .line 115
    sget-object v0, Lcom/thinkware/sundo/ieve/ieveARView;->a:Ljava/lang/String;

    const-string v1, "surfaceCreated"

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 116
    return-void
.end method

.method public surfaceDestroyed(Landroid/view/SurfaceHolder;)V
    .locals 2
    .param p1, "surface"    # Landroid/view/SurfaceHolder;

    .prologue
    .line 120
    invoke-super {p0, p1}, Landroid/opengl/GLSurfaceView;->surfaceDestroyed(Landroid/view/SurfaceHolder;)V

    .line 121
    sget-object v0, Lcom/thinkware/sundo/ieve/ieveARView;->a:Ljava/lang/String;

    const-string v1, "surfaceDestroyed"

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 122
    return-void
.end method
