.class Ltas/internal/camera/InputSourceInner;
.super Ljava/lang/Object;
.source "InputSourceInner.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ltas/internal/camera/InputSourceInner$StateQueue;,
        Ltas/internal/camera/InputSourceInner$NoInput;,
        Ltas/internal/camera/InputSourceInner$InputQueue;
    }
.end annotation


# static fields
.field private static final DBG:Z = true


# instance fields
.field private NO_INPUT:Ltas/internal/camera/InputSourceInner;

.field private TAG:Ljava/lang/String;

.field final camcls:Ljava/lang/String;

.field final camid:Ljava/lang/String;

.field final camidCompat:I

.field final camname:Ljava/lang/String;

.field channel:Ltas/internal/camera/InputChannel;

.field currinput:Ltas/internal/camera/InputSourceInner;

.field hook:Ltas/internal/camera/InputSource$Hook;

.field final inputname:Ljava/lang/String;

.field inputs:[Ltas/internal/camera/InputSourceInner;

.field private mInputQueue:Ltas/internal/camera/InputSourceInner$InputQueue;

.field private mStateQueue:Ltas/internal/camera/InputSourceInner$StateQueue;

.field myport:I

.field numinputs:I

.field private final opened:Ljava/util/concurrent/atomic/AtomicBoolean;

.field parent:Ltas/internal/camera/InputSourceInner;

.field private final plugged:Ljava/util/concurrent/atomic/AtomicBoolean;


# direct methods
.method static synthetic -wrap0(Ltas/internal/camera/InputSourceInner;Ltas/internal/camera/InputSourceInner;)Z
    .locals 1
    .param p1, "input"    # Ltas/internal/camera/InputSourceInner;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/camera/InputSourceInner;->handleInputChanged(Ltas/internal/camera/InputSourceInner;)Z

    move-result v0

    return v0
.end method

.method static synthetic -wrap1(Ltas/internal/camera/InputSourceInner;I)Z
    .locals 1
    .param p1, "state"    # I

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/camera/InputSourceInner;->handleStateChanged(I)Z

    move-result v0

    return v0
.end method

.method constructor <init>(Ltas/internal/camera/InputSource$Hook;Ljava/lang/Class;Ljava/lang/String;I)V
    .locals 6
    .param p1, "_hook"    # Ltas/internal/camera/InputSource$Hook;
    .param p3, "_camid"    # Ljava/lang/String;
    .param p4, "maxinputs"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ltas/internal/camera/InputSource$Hook;",
            "Ljava/lang/Class",
            "<*>;",
            "Ljava/lang/String;",
            "I)V"
        }
    .end annotation

    .prologue
    .local p2, "_camcls":Ljava/lang/Class;, "Ljava/lang/Class<*>;"
    const/4 v5, 0x0

    const/4 v3, 0x0

    .line 42
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 18
    const-string/jumbo v2, "TasCAM<InputSource>"

    iput-object v2, p0, Ltas/internal/camera/InputSourceInner;->TAG:Ljava/lang/String;

    .line 39
    new-instance v2, Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-direct {v2, v5}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    iput-object v2, p0, Ltas/internal/camera/InputSourceInner;->plugged:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 40
    new-instance v2, Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-direct {v2, v5}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    iput-object v2, p0, Ltas/internal/camera/InputSourceInner;->opened:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 44
    iput-object p1, p0, Ltas/internal/camera/InputSourceInner;->hook:Ltas/internal/camera/InputSource$Hook;

    .line 45
    iget-object v2, p0, Ltas/internal/camera/InputSourceInner;->hook:Ltas/internal/camera/InputSource$Hook;

    iget-object v2, v2, Ltas/internal/camera/InputSource$Hook;->input:Ltas/internal/camera/InputSource;

    invoke-virtual {v2}, Ltas/internal/camera/InputSource;->getClass()Ljava/lang/Class;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v2

    iput-object v2, p0, Ltas/internal/camera/InputSourceInner;->inputname:Ljava/lang/String;

    .line 46
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v4, p0, Ltas/internal/camera/InputSourceInner;->TAG:Ljava/lang/String;

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string/jumbo v4, "<"

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v4, p0, Ltas/internal/camera/InputSourceInner;->inputname:Ljava/lang/String;

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string/jumbo v4, ">"

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    iput-object v2, p0, Ltas/internal/camera/InputSourceInner;->TAG:Ljava/lang/String;

    .line 48
    if-eqz p2, :cond_3

    invoke-virtual {p2}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v2

    :goto_0
    iput-object v2, p0, Ltas/internal/camera/InputSourceInner;->camcls:Ljava/lang/String;

    .line 49
    if-eqz p2, :cond_0

    invoke-virtual {p2}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v3

    :cond_0
    iput-object v3, p0, Ltas/internal/camera/InputSourceInner;->camname:Ljava/lang/String;

    .line 51
    const/4 v0, -0x1

    .line 52
    .local v0, "_camidCompat":I
    if-eqz p3, :cond_1

    .line 54
    :try_start_0
    invoke-static {p3}, Ljava/lang/Integer;->valueOf(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I
    :try_end_0
    .catch Ljava/lang/NumberFormatException; {:try_start_0 .. :try_end_0} :catch_0

    move-result v0

    .line 60
    :cond_1
    :goto_1
    iput-object p3, p0, Ltas/internal/camera/InputSourceInner;->camid:Ljava/lang/String;

    .line 61
    iput v0, p0, Ltas/internal/camera/InputSourceInner;->camidCompat:I

    .line 63
    iput v5, p0, Ltas/internal/camera/InputSourceInner;->numinputs:I

    .line 64
    if-lez p4, :cond_2

    .line 65
    new-array v2, p4, [Ltas/internal/camera/InputSourceInner;

    iput-object v2, p0, Ltas/internal/camera/InputSourceInner;->inputs:[Ltas/internal/camera/InputSourceInner;

    .line 43
    :cond_2
    return-void

    .end local v0    # "_camidCompat":I
    :cond_3
    move-object v2, v3

    .line 48
    goto :goto_0

    .line 55
    .restart local v0    # "_camidCompat":I
    :catch_0
    move-exception v1

    .line 56
    .local v1, "e":Ljava/lang/NumberFormatException;
    iget-object v2, p0, Ltas/internal/camera/InputSourceInner;->TAG:Ljava/lang/String;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v4, p0, Ltas/internal/camera/InputSourceInner;->camname:Ljava/lang/String;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string/jumbo v4, " does compat with CAMERA SDK API 1"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_1
.end method

.method private handleInputChanged(Ltas/internal/camera/InputSourceInner;)Z
    .locals 1
    .param p1, "input"    # Ltas/internal/camera/InputSourceInner;

    .prologue
    .line 356
    invoke-direct {p0}, Ltas/internal/camera/InputSourceInner;->pauseChannel()V

    .line 357
    invoke-virtual {p1}, Ltas/internal/camera/InputSourceInner;->plug()V

    .line 358
    invoke-direct {p0}, Ltas/internal/camera/InputSourceInner;->resumeChannel()V

    .line 359
    const/4 v0, 0x1

    return v0
.end method

.method private handlePlug()V
    .locals 4

    .prologue
    .line 259
    iget-object v1, p0, Ltas/internal/camera/InputSourceInner;->TAG:Ljava/lang/String;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "plug - "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {p0}, Ltas/internal/camera/InputSourceInner;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 261
    iget-object v1, p0, Ltas/internal/camera/InputSourceInner;->plugged:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v2, 0x1

    invoke-virtual {v1, v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    .line 262
    iget-object v1, p0, Ltas/internal/camera/InputSourceInner;->hook:Ltas/internal/camera/InputSource$Hook;

    invoke-virtual {v1}, Ltas/internal/camera/InputSource$Hook;->onPlug()V

    .line 263
    iget-object v1, p0, Ltas/internal/camera/InputSourceInner;->inputs:[Ltas/internal/camera/InputSourceInner;

    if-eqz v1, :cond_1

    .line 264
    const/4 v1, 0x0

    invoke-virtual {p0, v1}, Ltas/internal/camera/InputSourceInner;->getCurrInput(Z)Ltas/internal/camera/InputSourceInner;

    move-result-object v0

    .line 265
    .local v0, "curr":Ltas/internal/camera/InputSourceInner;
    if-eqz v0, :cond_0

    invoke-direct {v0}, Ltas/internal/camera/InputSourceInner;->handlePlug()V

    .line 257
    .end local v0    # "curr":Ltas/internal/camera/InputSourceInner;
    :cond_0
    :goto_0
    return-void

    .line 267
    :cond_1
    invoke-direct {p0, p0}, Ltas/internal/camera/InputSourceInner;->notifyPlug(Ltas/internal/camera/InputSourceInner;)V

    goto :goto_0
.end method

.method private handleStateChanged(I)Z
    .locals 2
    .param p1, "state"    # I

    .prologue
    .line 349
    invoke-direct {p0}, Ltas/internal/camera/InputSourceInner;->pauseChannel()V

    .line 350
    iget-object v1, p0, Ltas/internal/camera/InputSourceInner;->hook:Ltas/internal/camera/InputSource$Hook;

    invoke-virtual {v1, p1}, Ltas/internal/camera/InputSource$Hook;->onStateChanged(I)Z

    move-result v0

    .line 351
    .local v0, "r":Z
    invoke-direct {p0}, Ltas/internal/camera/InputSourceInner;->resumeChannel()V

    .line 352
    return v0
.end method

.method private handleSwitchInput(Ltas/internal/camera/InputSourceInner;)V
    .locals 3
    .param p1, "input"    # Ltas/internal/camera/InputSourceInner;

    .prologue
    .line 242
    iget-object v0, p0, Ltas/internal/camera/InputSourceInner;->currinput:Ltas/internal/camera/InputSourceInner;

    if-ne v0, p1, :cond_0

    .line 243
    return-void

    .line 246
    :cond_0
    iget-object v0, p0, Ltas/internal/camera/InputSourceInner;->TAG:Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "input change - "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Ltas/internal/camera/InputSourceInner;->currinput:Ltas/internal/camera/InputSourceInner;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string/jumbo v2, " to "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 248
    iget-object v0, p0, Ltas/internal/camera/InputSourceInner;->currinput:Ltas/internal/camera/InputSourceInner;

    if-eqz v0, :cond_1

    .line 249
    iget-object v0, p0, Ltas/internal/camera/InputSourceInner;->currinput:Ltas/internal/camera/InputSourceInner;

    invoke-direct {v0}, Ltas/internal/camera/InputSourceInner;->handleUnplug()V

    .line 251
    :cond_1
    if-eqz p1, :cond_2

    .line 252
    invoke-direct {p1}, Ltas/internal/camera/InputSourceInner;->handlePlug()V

    .line 254
    :cond_2
    iput-object p1, p0, Ltas/internal/camera/InputSourceInner;->currinput:Ltas/internal/camera/InputSourceInner;

    .line 241
    return-void
.end method

.method private handleUnplug()V
    .locals 5

    .prologue
    const/4 v4, 0x0

    .line 273
    iget-object v1, p0, Ltas/internal/camera/InputSourceInner;->TAG:Ljava/lang/String;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "unplug - "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {p0}, Ltas/internal/camera/InputSourceInner;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 275
    iget-object v1, p0, Ltas/internal/camera/InputSourceInner;->plugged:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v1, v4}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    .line 276
    iget-object v1, p0, Ltas/internal/camera/InputSourceInner;->hook:Ltas/internal/camera/InputSource$Hook;

    invoke-virtual {v1}, Ltas/internal/camera/InputSource$Hook;->onUnplug()V

    .line 277
    iget-object v1, p0, Ltas/internal/camera/InputSourceInner;->inputs:[Ltas/internal/camera/InputSourceInner;

    if-eqz v1, :cond_1

    .line 278
    invoke-virtual {p0, v4}, Ltas/internal/camera/InputSourceInner;->getCurrInput(Z)Ltas/internal/camera/InputSourceInner;

    move-result-object v0

    .line 279
    .local v0, "curr":Ltas/internal/camera/InputSourceInner;
    if-eqz v0, :cond_0

    invoke-direct {v0}, Ltas/internal/camera/InputSourceInner;->handleUnplug()V

    .line 271
    .end local v0    # "curr":Ltas/internal/camera/InputSourceInner;
    :cond_0
    :goto_0
    return-void

    .line 281
    :cond_1
    invoke-direct {p0, p0}, Ltas/internal/camera/InputSourceInner;->notifyUnplug(Ltas/internal/camera/InputSourceInner;)V

    goto :goto_0
.end method

.method private initializeEventQueue()V
    .locals 1

    .prologue
    .line 340
    iget-object v0, p0, Ltas/internal/camera/InputSourceInner;->parent:Ltas/internal/camera/InputSourceInner;

    if-eqz v0, :cond_1

    .line 341
    iget-object v0, p0, Ltas/internal/camera/InputSourceInner;->parent:Ltas/internal/camera/InputSourceInner;

    invoke-direct {v0}, Ltas/internal/camera/InputSourceInner;->initializeEventQueue()V

    .line 339
    :cond_0
    :goto_0
    return-void

    .line 342
    :cond_1
    iget-object v0, p0, Ltas/internal/camera/InputSourceInner;->channel:Ltas/internal/camera/InputChannel;

    if-eqz v0, :cond_0

    .line 343
    iget-object v0, p0, Ltas/internal/camera/InputSourceInner;->channel:Ltas/internal/camera/InputChannel;

    invoke-virtual {v0}, Ltas/internal/camera/InputChannel;->initializeEventQueue()V

    goto :goto_0
.end method

.method private notifyPlug(Ltas/internal/camera/InputSourceInner;)V
    .locals 1
    .param p1, "input"    # Ltas/internal/camera/InputSourceInner;

    .prologue
    .line 286
    iget-object v0, p0, Ltas/internal/camera/InputSourceInner;->parent:Ltas/internal/camera/InputSourceInner;

    if-eqz v0, :cond_1

    .line 287
    iget-object v0, p0, Ltas/internal/camera/InputSourceInner;->parent:Ltas/internal/camera/InputSourceInner;

    invoke-direct {v0, p1}, Ltas/internal/camera/InputSourceInner;->notifyPlug(Ltas/internal/camera/InputSourceInner;)V

    .line 285
    :cond_0
    :goto_0
    return-void

    .line 288
    :cond_1
    iget-object v0, p0, Ltas/internal/camera/InputSourceInner;->channel:Ltas/internal/camera/InputChannel;

    if-eqz v0, :cond_0

    .line 289
    iget-object v0, p0, Ltas/internal/camera/InputSourceInner;->channel:Ltas/internal/camera/InputChannel;

    invoke-virtual {v0, p1}, Ltas/internal/camera/InputChannel;->notifyPlug(Ltas/internal/camera/InputSourceInner;)V

    goto :goto_0
.end method

.method private notifyUnplug(Ltas/internal/camera/InputSourceInner;)V
    .locals 1
    .param p1, "input"    # Ltas/internal/camera/InputSourceInner;

    .prologue
    .line 294
    iget-object v0, p0, Ltas/internal/camera/InputSourceInner;->parent:Ltas/internal/camera/InputSourceInner;

    if-eqz v0, :cond_1

    .line 295
    iget-object v0, p0, Ltas/internal/camera/InputSourceInner;->parent:Ltas/internal/camera/InputSourceInner;

    invoke-direct {v0, p1}, Ltas/internal/camera/InputSourceInner;->notifyUnplug(Ltas/internal/camera/InputSourceInner;)V

    .line 293
    :cond_0
    :goto_0
    return-void

    .line 296
    :cond_1
    iget-object v0, p0, Ltas/internal/camera/InputSourceInner;->channel:Ltas/internal/camera/InputChannel;

    if-eqz v0, :cond_0

    .line 297
    iget-object v0, p0, Ltas/internal/camera/InputSourceInner;->channel:Ltas/internal/camera/InputChannel;

    invoke-virtual {v0, p1}, Ltas/internal/camera/InputChannel;->notifyUnplug(Ltas/internal/camera/InputSourceInner;)V

    goto :goto_0
.end method

.method private onClose(Ltas/internal/camera/InputSourceInner;)V
    .locals 2
    .param p1, "input"    # Ltas/internal/camera/InputSourceInner;

    .prologue
    .line 227
    iget-object v0, p0, Ltas/internal/camera/InputSourceInner;->parent:Ltas/internal/camera/InputSourceInner;

    if-eqz v0, :cond_0

    .line 228
    iget-object v0, p0, Ltas/internal/camera/InputSourceInner;->parent:Ltas/internal/camera/InputSourceInner;

    invoke-direct {v0, p1}, Ltas/internal/camera/InputSourceInner;->onClose(Ltas/internal/camera/InputSourceInner;)V

    .line 230
    :cond_0
    iget-object v0, p0, Ltas/internal/camera/InputSourceInner;->hook:Ltas/internal/camera/InputSource$Hook;

    iget-object v1, p1, Ltas/internal/camera/InputSourceInner;->hook:Ltas/internal/camera/InputSource$Hook;

    iget-object v1, v1, Ltas/internal/camera/InputSource$Hook;->input:Ltas/internal/camera/InputSource;

    invoke-virtual {v0, v1}, Ltas/internal/camera/InputSource$Hook;->onClose(Ltas/internal/camera/InputSource;)V

    .line 226
    return-void
.end method

.method private onOpen(Ltas/internal/camera/InputSourceInner;)V
    .locals 2
    .param p1, "input"    # Ltas/internal/camera/InputSourceInner;

    .prologue
    .line 220
    iget-object v0, p0, Ltas/internal/camera/InputSourceInner;->parent:Ltas/internal/camera/InputSourceInner;

    if-eqz v0, :cond_0

    .line 221
    iget-object v0, p0, Ltas/internal/camera/InputSourceInner;->parent:Ltas/internal/camera/InputSourceInner;

    invoke-direct {v0, p1}, Ltas/internal/camera/InputSourceInner;->onOpen(Ltas/internal/camera/InputSourceInner;)V

    .line 223
    :cond_0
    iget-object v0, p0, Ltas/internal/camera/InputSourceInner;->hook:Ltas/internal/camera/InputSource$Hook;

    iget-object v1, p1, Ltas/internal/camera/InputSourceInner;->hook:Ltas/internal/camera/InputSource$Hook;

    iget-object v1, v1, Ltas/internal/camera/InputSource$Hook;->input:Ltas/internal/camera/InputSource;

    invoke-virtual {v0, v1}, Ltas/internal/camera/InputSource$Hook;->onOpen(Ltas/internal/camera/InputSource;)V

    .line 219
    return-void
.end method

.method private pauseChannel()V
    .locals 1

    .prologue
    .line 332
    iget-object v0, p0, Ltas/internal/camera/InputSourceInner;->parent:Ltas/internal/camera/InputSourceInner;

    if-eqz v0, :cond_1

    .line 333
    iget-object v0, p0, Ltas/internal/camera/InputSourceInner;->parent:Ltas/internal/camera/InputSourceInner;

    invoke-direct {v0}, Ltas/internal/camera/InputSourceInner;->pauseChannel()V

    .line 331
    :cond_0
    :goto_0
    return-void

    .line 334
    :cond_1
    iget-object v0, p0, Ltas/internal/camera/InputSourceInner;->channel:Ltas/internal/camera/InputChannel;

    if-eqz v0, :cond_0

    .line 335
    iget-object v0, p0, Ltas/internal/camera/InputSourceInner;->channel:Ltas/internal/camera/InputChannel;

    invoke-virtual {v0}, Ltas/internal/camera/InputChannel;->pause()V

    goto :goto_0
.end method

.method private reportExtraState(Ltas/internal/camera/InputSourceInner;IILjava/lang/String;)V
    .locals 1
    .param p1, "input"    # Ltas/internal/camera/InputSourceInner;
    .param p2, "state"    # I
    .param p3, "flag"    # I
    .param p4, "proc"    # Ljava/lang/String;

    .prologue
    .line 316
    iget-object v0, p0, Ltas/internal/camera/InputSourceInner;->parent:Ltas/internal/camera/InputSourceInner;

    if-eqz v0, :cond_1

    .line 317
    iget-object v0, p0, Ltas/internal/camera/InputSourceInner;->parent:Ltas/internal/camera/InputSourceInner;

    invoke-direct {v0, p1, p2, p3, p4}, Ltas/internal/camera/InputSourceInner;->reportExtraState(Ltas/internal/camera/InputSourceInner;IILjava/lang/String;)V

    .line 315
    :cond_0
    :goto_0
    return-void

    .line 318
    :cond_1
    iget-object v0, p0, Ltas/internal/camera/InputSourceInner;->channel:Ltas/internal/camera/InputChannel;

    if-eqz v0, :cond_0

    .line 319
    iget-object v0, p0, Ltas/internal/camera/InputSourceInner;->channel:Ltas/internal/camera/InputChannel;

    invoke-virtual {v0, p1, p2, p3, p4}, Ltas/internal/camera/InputChannel;->reportExtraState(Ltas/internal/camera/InputSourceInner;IILjava/lang/String;)V

    goto :goto_0
.end method

.method private resumeChannel()V
    .locals 1

    .prologue
    .line 324
    iget-object v0, p0, Ltas/internal/camera/InputSourceInner;->parent:Ltas/internal/camera/InputSourceInner;

    if-eqz v0, :cond_1

    .line 325
    iget-object v0, p0, Ltas/internal/camera/InputSourceInner;->parent:Ltas/internal/camera/InputSourceInner;

    invoke-direct {v0}, Ltas/internal/camera/InputSourceInner;->resumeChannel()V

    .line 323
    :cond_0
    :goto_0
    return-void

    .line 326
    :cond_1
    iget-object v0, p0, Ltas/internal/camera/InputSourceInner;->channel:Ltas/internal/camera/InputChannel;

    if-eqz v0, :cond_0

    .line 327
    iget-object v0, p0, Ltas/internal/camera/InputSourceInner;->channel:Ltas/internal/camera/InputChannel;

    invoke-virtual {v0}, Ltas/internal/camera/InputChannel;->resume()V

    goto :goto_0
.end method

.method private sendMessage(Ltas/internal/camera/InputSourceInner;Ltas/camera/CameraMessage;Ljava/lang/String;Z)V
    .locals 1
    .param p1, "input"    # Ltas/internal/camera/InputSourceInner;
    .param p2, "msg"    # Ltas/camera/CameraMessage;
    .param p3, "proc"    # Ljava/lang/String;
    .param p4, "now"    # Z

    .prologue
    .line 305
    iget-object v0, p0, Ltas/internal/camera/InputSourceInner;->parent:Ltas/internal/camera/InputSourceInner;

    if-eqz v0, :cond_1

    .line 306
    iget-object v0, p0, Ltas/internal/camera/InputSourceInner;->parent:Ltas/internal/camera/InputSourceInner;

    invoke-direct {v0, p1, p2, p3, p4}, Ltas/internal/camera/InputSourceInner;->sendMessage(Ltas/internal/camera/InputSourceInner;Ltas/camera/CameraMessage;Ljava/lang/String;Z)V

    .line 304
    :cond_0
    :goto_0
    return-void

    .line 307
    :cond_1
    iget-object v0, p0, Ltas/internal/camera/InputSourceInner;->channel:Ltas/internal/camera/InputChannel;

    if-eqz v0, :cond_0

    .line 308
    iget-object v0, p0, Ltas/internal/camera/InputSourceInner;->channel:Ltas/internal/camera/InputChannel;

    invoke-virtual {v0, p1, p2, p3, p4}, Ltas/internal/camera/InputChannel;->sendMessage(Ltas/internal/camera/InputSourceInner;Ltas/camera/CameraMessage;Ljava/lang/String;Z)V

    goto :goto_0
.end method

.method private switchinput(Ltas/internal/camera/InputSourceInner;)V
    .locals 1
    .param p1, "input"    # Ltas/internal/camera/InputSourceInner;

    .prologue
    .line 234
    iget-object v0, p0, Ltas/internal/camera/InputSourceInner;->NO_INPUT:Ltas/internal/camera/InputSourceInner;

    if-eq p1, v0, :cond_0

    .line 235
    invoke-direct {p0, p1}, Ltas/internal/camera/InputSourceInner;->handleSwitchInput(Ltas/internal/camera/InputSourceInner;)V

    .line 233
    :goto_0
    return-void

    .line 237
    :cond_0
    const/4 v0, 0x0

    invoke-direct {p0, v0}, Ltas/internal/camera/InputSourceInner;->handleSwitchInput(Ltas/internal/camera/InputSourceInner;)V

    goto :goto_0
.end method


# virtual methods
.method addInput(ILtas/internal/camera/InputSourceInner;)V
    .locals 3
    .param p1, "port"    # I
    .param p2, "input"    # Ltas/internal/camera/InputSourceInner;

    .prologue
    .line 90
    if-eqz p2, :cond_0

    iget-object v0, p2, Ltas/internal/camera/InputSourceInner;->parent:Ltas/internal/camera/InputSourceInner;

    if-nez v0, :cond_0

    .line 91
    iput-object p0, p2, Ltas/internal/camera/InputSourceInner;->parent:Ltas/internal/camera/InputSourceInner;

    .line 92
    iput p1, p2, Ltas/internal/camera/InputSourceInner;->myport:I

    .line 93
    iget-object v0, p0, Ltas/internal/camera/InputSourceInner;->inputs:[Ltas/internal/camera/InputSourceInner;

    iget v1, p0, Ltas/internal/camera/InputSourceInner;->numinputs:I

    add-int/lit8 v2, v1, 0x1

    iput v2, p0, Ltas/internal/camera/InputSourceInner;->numinputs:I

    aput-object p2, v0, v1

    .line 89
    return-void

    .line 95
    :cond_0
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 96
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "tas: add input failed - "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    .line 97
    const-string/jumbo v2, " , parent - "

    .line 96
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    .line 97
    invoke-virtual {p0}, Ltas/internal/camera/InputSourceInner;->toString()Ljava/lang/String;

    move-result-object v2

    .line 96
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .line 95
    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method collectInputs(Ljava/util/List;I)V
    .locals 4
    .param p2, "camid"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List",
            "<",
            "Ltas/internal/camera/InputSourceInner;",
            ">;I)V"
        }
    .end annotation

    .prologue
    .line 429
    .local p1, "list":Ljava/util/List;, "Ljava/util/List<Ltas/internal/camera/InputSourceInner;>;"
    invoke-virtual {p0, p2}, Ltas/internal/camera/InputSourceInner;->isCamid(I)Z

    move-result v1

    if-eqz v1, :cond_0

    .line 430
    invoke-interface {p1, p0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 431
    return-void

    .line 433
    :cond_0
    iget-object v1, p0, Ltas/internal/camera/InputSourceInner;->inputs:[Ltas/internal/camera/InputSourceInner;

    if-nez v1, :cond_1

    .line 434
    return-void

    .line 436
    :cond_1
    iget-object v2, p0, Ltas/internal/camera/InputSourceInner;->inputs:[Ltas/internal/camera/InputSourceInner;

    const/4 v1, 0x0

    array-length v3, v2

    :goto_0
    if-ge v1, v3, :cond_3

    aget-object v0, v2, v1

    .line 437
    .local v0, "input":Ltas/internal/camera/InputSourceInner;
    if-eqz v0, :cond_2

    invoke-virtual {v0, p1, p2}, Ltas/internal/camera/InputSourceInner;->collectInputs(Ljava/util/List;I)V

    .line 436
    :cond_2
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    .line 428
    .end local v0    # "input":Ltas/internal/camera/InputSourceInner;
    :cond_3
    return-void
.end method

.method command(Ltas/internal/camera/InputSourceInner;Ltas/internal/camera/InputParams;Ljava/lang/String;)I
    .locals 3
    .param p1, "input"    # Ltas/internal/camera/InputSourceInner;
    .param p2, "params"    # Ltas/internal/camera/InputParams;
    .param p3, "proc"    # Ljava/lang/String;

    .prologue
    .line 407
    iget-object v0, p0, Ltas/internal/camera/InputSourceInner;->TAG:Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "command - "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 408
    iget-object v0, p0, Ltas/internal/camera/InputSourceInner;->hook:Ltas/internal/camera/InputSource$Hook;

    iget-object v1, p1, Ltas/internal/camera/InputSourceInner;->hook:Ltas/internal/camera/InputSource$Hook;

    iget-object v1, v1, Ltas/internal/camera/InputSource$Hook;->input:Ltas/internal/camera/InputSource;

    iget-object v2, p2, Ltas/internal/camera/InputParams;->cmd:Ltas/camera/CameraCommand;

    invoke-virtual {v0, v1, v2, p3}, Ltas/internal/camera/InputSource$Hook;->onCommand(Ltas/internal/camera/InputSource;Ltas/camera/CameraCommand;Ljava/lang/String;)I

    move-result v0

    return v0
.end method

.method findInput(Ljava/lang/String;)Ltas/internal/camera/InputSourceInner;
    .locals 6
    .param p1, "_camcls"    # Ljava/lang/String;

    .prologue
    const/4 v5, 0x0

    .line 412
    invoke-virtual {p0, p1}, Ltas/internal/camera/InputSourceInner;->isCamcls(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_0

    .line 413
    return-object p0

    .line 415
    :cond_0
    iget-object v2, p0, Ltas/internal/camera/InputSourceInner;->inputs:[Ltas/internal/camera/InputSourceInner;

    if-nez v2, :cond_1

    .line 416
    return-object v5

    .line 418
    :cond_1
    const/4 v1, 0x0

    .line 419
    .local v1, "input":Ltas/internal/camera/InputSourceInner;
    iget-object v3, p0, Ltas/internal/camera/InputSourceInner;->inputs:[Ltas/internal/camera/InputSourceInner;

    const/4 v2, 0x0

    array-length v4, v3

    .end local v1    # "input":Ltas/internal/camera/InputSourceInner;
    :goto_0
    if-ge v2, v4, :cond_4

    aget-object v0, v3, v2

    .line 420
    .local v0, "i":Ltas/internal/camera/InputSourceInner;
    if-eqz v0, :cond_2

    invoke-virtual {v0, p1}, Ltas/internal/camera/InputSourceInner;->findInput(Ljava/lang/String;)Ltas/internal/camera/InputSourceInner;

    move-result-object v1

    .line 421
    :goto_1
    if-eqz v1, :cond_3

    .line 422
    return-object v1

    .line 420
    :cond_2
    const/4 v1, 0x0

    .restart local v1    # "input":Ltas/internal/camera/InputSourceInner;
    goto :goto_1

    .line 419
    .end local v1    # "input":Ltas/internal/camera/InputSourceInner;
    :cond_3
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    .line 425
    .end local v0    # "i":Ltas/internal/camera/InputSourceInner;
    :cond_4
    return-object v5
.end method

.method getCurrInput(Z)Ltas/internal/camera/InputSourceInner;
    .locals 2
    .param p1, "recursive"    # Z

    .prologue
    .line 110
    iget-object v0, p0, Ltas/internal/camera/InputSourceInner;->currinput:Ltas/internal/camera/InputSourceInner;

    .line 111
    .local v0, "curr":Ltas/internal/camera/InputSourceInner;
    if-eqz p1, :cond_0

    .line 112
    move-object v1, v0

    .line 113
    .local v1, "next":Ltas/internal/camera/InputSourceInner;
    :goto_0
    if-eqz v1, :cond_0

    .line 114
    move-object v0, v1

    .line 115
    iget-object v1, v1, Ltas/internal/camera/InputSourceInner;->currinput:Ltas/internal/camera/InputSourceInner;

    goto :goto_0

    .line 118
    .end local v1    # "next":Ltas/internal/camera/InputSourceInner;
    :cond_0
    return-object v0
.end method

.method getParent()Ltas/internal/camera/InputSourceInner;
    .locals 1

    .prologue
    .line 106
    iget-object v0, p0, Ltas/internal/camera/InputSourceInner;->parent:Ltas/internal/camera/InputSourceInner;

    return-object v0
.end method

.method handleClose()V
    .locals 3

    .prologue
    .line 213
    iget-object v0, p0, Ltas/internal/camera/InputSourceInner;->TAG:Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "close - "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {p0}, Ltas/internal/camera/InputSourceInner;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 215
    iget-object v0, p0, Ltas/internal/camera/InputSourceInner;->opened:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    .line 216
    invoke-direct {p0, p0}, Ltas/internal/camera/InputSourceInner;->onClose(Ltas/internal/camera/InputSourceInner;)V

    .line 211
    return-void
.end method

.method handleOpen()V
    .locals 3

    .prologue
    .line 205
    iget-object v0, p0, Ltas/internal/camera/InputSourceInner;->TAG:Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "open - "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {p0}, Ltas/internal/camera/InputSourceInner;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 207
    iget-object v0, p0, Ltas/internal/camera/InputSourceInner;->opened:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    .line 208
    invoke-direct {p0, p0}, Ltas/internal/camera/InputSourceInner;->onOpen(Ltas/internal/camera/InputSourceInner;)V

    .line 203
    return-void
.end method

.method hasQueue()Z
    .locals 7

    .prologue
    const/4 v6, 0x1

    const/4 v2, 0x0

    .line 383
    iget-object v1, p0, Ltas/internal/camera/InputSourceInner;->mStateQueue:Ltas/internal/camera/InputSourceInner$StateQueue;

    if-nez v1, :cond_0

    iget-object v1, p0, Ltas/internal/camera/InputSourceInner;->mInputQueue:Ltas/internal/camera/InputSourceInner$InputQueue;

    if-eqz v1, :cond_1

    .line 384
    :cond_0
    return v6

    .line 386
    :cond_1
    iget-object v1, p0, Ltas/internal/camera/InputSourceInner;->inputs:[Ltas/internal/camera/InputSourceInner;

    if-nez v1, :cond_2

    .line 387
    return v2

    .line 389
    :cond_2
    iget-object v3, p0, Ltas/internal/camera/InputSourceInner;->inputs:[Ltas/internal/camera/InputSourceInner;

    array-length v4, v3

    move v1, v2

    :goto_0
    if-ge v1, v4, :cond_4

    aget-object v0, v3, v1

    .line 390
    .local v0, "input":Ltas/internal/camera/InputSourceInner;
    invoke-virtual {v0}, Ltas/internal/camera/InputSourceInner;->hasQueue()Z

    move-result v5

    if-eqz v5, :cond_3

    .line 391
    return v6

    .line 389
    :cond_3
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    .line 394
    .end local v0    # "input":Ltas/internal/camera/InputSourceInner;
    :cond_4
    return v2
.end method

.method initializeInputQueue()V
    .locals 2

    .prologue
    const/4 v1, 0x0

    .line 372
    iget-object v0, p0, Ltas/internal/camera/InputSourceInner;->mStateQueue:Ltas/internal/camera/InputSourceInner$StateQueue;

    if-eqz v0, :cond_0

    .line 373
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string/jumbo v1, "already has inputqueue"

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 376
    :cond_0
    new-instance v0, Ltas/internal/camera/InputSourceInner$NoInput;

    invoke-direct {v0, p0, v1}, Ltas/internal/camera/InputSourceInner$NoInput;-><init>(Ltas/internal/camera/InputSourceInner;Ltas/internal/camera/InputSourceInner$NoInput;)V

    iget-object v0, v0, Ltas/internal/camera/InputSourceInner$NoInput;->hook:Ltas/internal/camera/InputSource$Hook;

    iget-object v0, v0, Ltas/internal/camera/InputSource$Hook;->impl:Ltas/internal/camera/InputSourceInner;

    iput-object v0, p0, Ltas/internal/camera/InputSourceInner;->NO_INPUT:Ltas/internal/camera/InputSourceInner;

    .line 378
    new-instance v0, Ltas/internal/camera/InputSourceInner$InputQueue;

    invoke-direct {v0, p0, v1}, Ltas/internal/camera/InputSourceInner$InputQueue;-><init>(Ltas/internal/camera/InputSourceInner;Ltas/internal/camera/InputSourceInner$InputQueue;)V

    iput-object v0, p0, Ltas/internal/camera/InputSourceInner;->mInputQueue:Ltas/internal/camera/InputSourceInner$InputQueue;

    .line 379
    invoke-direct {p0}, Ltas/internal/camera/InputSourceInner;->initializeEventQueue()V

    .line 371
    return-void
.end method

.method initializeStateQueue()V
    .locals 2

    .prologue
    const/4 v1, 0x0

    .line 363
    iget-object v0, p0, Ltas/internal/camera/InputSourceInner;->mInputQueue:Ltas/internal/camera/InputSourceInner$InputQueue;

    if-eqz v0, :cond_0

    .line 364
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string/jumbo v1, "already has statequeue"

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 367
    :cond_0
    new-instance v0, Ltas/internal/camera/InputSourceInner$StateQueue;

    invoke-direct {v0, p0, v1}, Ltas/internal/camera/InputSourceInner$StateQueue;-><init>(Ltas/internal/camera/InputSourceInner;Ltas/internal/camera/InputSourceInner$StateQueue;)V

    iput-object v0, p0, Ltas/internal/camera/InputSourceInner;->mStateQueue:Ltas/internal/camera/InputSourceInner$StateQueue;

    .line 368
    invoke-direct {p0}, Ltas/internal/camera/InputSourceInner;->initializeEventQueue()V

    .line 362
    return-void
.end method

.method isCamcls(Ljava/lang/String;)Z
    .locals 1
    .param p1, "_camcls"    # Ljava/lang/String;

    .prologue
    .line 78
    iget-object v0, p0, Ltas/internal/camera/InputSourceInner;->camcls:Ljava/lang/String;

    if-eqz v0, :cond_0

    iget-object v0, p0, Ltas/internal/camera/InputSourceInner;->camcls:Ljava/lang/String;

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    :goto_0
    return v0

    :cond_0
    const/4 v0, 0x0

    goto :goto_0
.end method

.method isCamid(I)Z
    .locals 1
    .param p1, "_camid"    # I

    .prologue
    .line 70
    iget v0, p0, Ltas/internal/camera/InputSourceInner;->camidCompat:I

    if-ne v0, p1, :cond_0

    const/4 v0, 0x1

    :goto_0
    return v0

    :cond_0
    const/4 v0, 0x0

    goto :goto_0
.end method

.method isCamid(Ljava/lang/String;)Z
    .locals 1
    .param p1, "_camid"    # Ljava/lang/String;

    .prologue
    .line 74
    iget-object v0, p0, Ltas/internal/camera/InputSourceInner;->camid:Ljava/lang/String;

    if-eqz v0, :cond_0

    iget-object v0, p0, Ltas/internal/camera/InputSourceInner;->camid:Ljava/lang/String;

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    :goto_0
    return v0

    :cond_0
    const/4 v0, 0x0

    goto :goto_0
.end method

.method isOpened()Z
    .locals 1

    .prologue
    .line 86
    iget-object v0, p0, Ltas/internal/camera/InputSourceInner;->opened:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v0

    return v0
.end method

.method isPlugged()Z
    .locals 1

    .prologue
    .line 82
    iget-object v0, p0, Ltas/internal/camera/InputSourceInner;->plugged:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v0

    return v0
.end method

.method notifyInput(Ltas/internal/camera/InputSourceInner;)V
    .locals 1
    .param p1, "input"    # Ltas/internal/camera/InputSourceInner;

    .prologue
    .line 130
    iget-object v0, p0, Ltas/internal/camera/InputSourceInner;->mInputQueue:Ltas/internal/camera/InputSourceInner$InputQueue;

    if-eqz v0, :cond_1

    .line 131
    if-nez p1, :cond_0

    .line 132
    iget-object p1, p0, Ltas/internal/camera/InputSourceInner;->NO_INPUT:Ltas/internal/camera/InputSourceInner;

    .line 135
    :cond_0
    iget-object v0, p0, Ltas/internal/camera/InputSourceInner;->mInputQueue:Ltas/internal/camera/InputSourceInner$InputQueue;

    invoke-virtual {v0, p1}, Ltas/internal/camera/InputSourceInner$InputQueue;->offer(Ljava/lang/Object;)V

    .line 129
    :cond_1
    return-void
.end method

.method notifyState(I)V
    .locals 2
    .param p1, "state"    # I

    .prologue
    .line 122
    iget-object v0, p0, Ltas/internal/camera/InputSourceInner;->mStateQueue:Ltas/internal/camera/InputSourceInner$StateQueue;

    if-eqz v0, :cond_0

    .line 123
    iget-object v0, p0, Ltas/internal/camera/InputSourceInner;->mStateQueue:Ltas/internal/camera/InputSourceInner$StateQueue;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-virtual {v0, v1}, Ltas/internal/camera/InputSourceInner$StateQueue;->offer(Ljava/lang/Object;)V

    .line 121
    :goto_0
    return-void

    .line 125
    :cond_0
    invoke-direct {p0, p1}, Ltas/internal/camera/InputSourceInner;->handleStateChanged(I)Z

    goto :goto_0
.end method

.method onSystemMasterClear(Ljava/lang/String;)V
    .locals 4
    .param p1, "reason"    # Ljava/lang/String;

    .prologue
    .line 452
    iget-object v1, p0, Ltas/internal/camera/InputSourceInner;->hook:Ltas/internal/camera/InputSource$Hook;

    invoke-virtual {v1, p1}, Ltas/internal/camera/InputSource$Hook;->onSystemMasterClear(Ljava/lang/String;)V

    .line 453
    iget-object v1, p0, Ltas/internal/camera/InputSourceInner;->inputs:[Ltas/internal/camera/InputSourceInner;

    if-nez v1, :cond_0

    .line 454
    return-void

    .line 456
    :cond_0
    iget-object v2, p0, Ltas/internal/camera/InputSourceInner;->inputs:[Ltas/internal/camera/InputSourceInner;

    const/4 v1, 0x0

    array-length v3, v2

    :goto_0
    if-ge v1, v3, :cond_2

    aget-object v0, v2, v1

    .line 457
    .local v0, "i":Ltas/internal/camera/InputSourceInner;
    if-eqz v0, :cond_1

    invoke-virtual {v0, p1}, Ltas/internal/camera/InputSourceInner;->onSystemMasterClear(Ljava/lang/String;)V

    .line 456
    :cond_1
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    .line 451
    .end local v0    # "i":Ltas/internal/camera/InputSourceInner;
    :cond_2
    return-void
.end method

.method onSystemShutdown()V
    .locals 4

    .prologue
    .line 442
    iget-object v1, p0, Ltas/internal/camera/InputSourceInner;->hook:Ltas/internal/camera/InputSource$Hook;

    invoke-virtual {v1}, Ltas/internal/camera/InputSource$Hook;->onSystemShutdown()V

    .line 443
    iget-object v1, p0, Ltas/internal/camera/InputSourceInner;->inputs:[Ltas/internal/camera/InputSourceInner;

    if-nez v1, :cond_0

    .line 444
    return-void

    .line 446
    :cond_0
    iget-object v2, p0, Ltas/internal/camera/InputSourceInner;->inputs:[Ltas/internal/camera/InputSourceInner;

    const/4 v1, 0x0

    array-length v3, v2

    :goto_0
    if-ge v1, v3, :cond_2

    aget-object v0, v2, v1

    .line 447
    .local v0, "i":Ltas/internal/camera/InputSourceInner;
    if-eqz v0, :cond_1

    invoke-virtual {v0}, Ltas/internal/camera/InputSourceInner;->onSystemShutdown()V

    .line 446
    :cond_1
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    .line 441
    .end local v0    # "i":Ltas/internal/camera/InputSourceInner;
    :cond_2
    return-void
.end method

.method plug()V
    .locals 1

    .prologue
    .line 140
    iget-object v0, p0, Ltas/internal/camera/InputSourceInner;->parent:Ltas/internal/camera/InputSourceInner;

    if-eqz v0, :cond_0

    .line 141
    iget-object v0, p0, Ltas/internal/camera/InputSourceInner;->parent:Ltas/internal/camera/InputSourceInner;

    invoke-direct {v0, p0}, Ltas/internal/camera/InputSourceInner;->switchinput(Ltas/internal/camera/InputSourceInner;)V

    .line 139
    :goto_0
    return-void

    .line 143
    :cond_0
    invoke-direct {p0}, Ltas/internal/camera/InputSourceInner;->handlePlug()V

    goto :goto_0
.end method

.method port()I
    .locals 1

    .prologue
    .line 102
    iget v0, p0, Ltas/internal/camera/InputSourceInner;->myport:I

    return v0
.end method

.method reportExtraState(IILjava/lang/String;)V
    .locals 4
    .param p1, "state"    # I
    .param p2, "flag"    # I
    .param p3, "proc"    # Ljava/lang/String;

    .prologue
    .line 183
    iget-object v1, p0, Ltas/internal/camera/InputSourceInner;->camcls:Ljava/lang/String;

    if-eqz v1, :cond_0

    .line 184
    invoke-direct {p0, p0, p1, p2, p3}, Ltas/internal/camera/InputSourceInner;->reportExtraState(Ltas/internal/camera/InputSourceInner;IILjava/lang/String;)V

    .line 185
    return-void

    .line 188
    :cond_0
    iget-object v1, p0, Ltas/internal/camera/InputSourceInner;->currinput:Ltas/internal/camera/InputSourceInner;

    if-eqz v1, :cond_1

    .line 189
    iget-object v1, p0, Ltas/internal/camera/InputSourceInner;->currinput:Ltas/internal/camera/InputSourceInner;

    invoke-virtual {v1, p1, p2, p3}, Ltas/internal/camera/InputSourceInner;->reportExtraState(IILjava/lang/String;)V

    .line 190
    return-void

    .line 193
    :cond_1
    iget-object v1, p0, Ltas/internal/camera/InputSourceInner;->inputs:[Ltas/internal/camera/InputSourceInner;

    if-nez v1, :cond_2

    .line 194
    iget-object v1, p0, Ltas/internal/camera/InputSourceInner;->TAG:Ljava/lang/String;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "no input found. cancel reportExtraState - "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 195
    return-void

    .line 198
    :cond_2
    iget-object v2, p0, Ltas/internal/camera/InputSourceInner;->inputs:[Ltas/internal/camera/InputSourceInner;

    const/4 v1, 0x0

    array-length v3, v2

    :goto_0
    if-ge v1, v3, :cond_4

    aget-object v0, v2, v1

    .line 199
    .local v0, "input":Ltas/internal/camera/InputSourceInner;
    if-eqz v0, :cond_3

    invoke-virtual {v0, p1, p2, p3}, Ltas/internal/camera/InputSourceInner;->reportExtraState(IILjava/lang/String;)V

    .line 198
    :cond_3
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    .line 182
    .end local v0    # "input":Ltas/internal/camera/InputSourceInner;
    :cond_4
    return-void
.end method

.method request(Ljava/lang/String;)I
    .locals 2
    .param p1, "proc"    # Ljava/lang/String;

    .prologue
    .line 398
    iget-object v0, p0, Ltas/internal/camera/InputSourceInner;->TAG:Ljava/lang/String;

    const-string/jumbo v1, "request"

    invoke-static {v0, v1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 399
    iget-object v0, p0, Ltas/internal/camera/InputSourceInner;->plugged:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v0

    if-nez v0, :cond_0

    .line 400
    const/16 v0, -0xc

    return v0

    .line 402
    :cond_0
    iget-object v0, p0, Ltas/internal/camera/InputSourceInner;->hook:Ltas/internal/camera/InputSource$Hook;

    invoke-virtual {v0, p1}, Ltas/internal/camera/InputSource$Hook;->onRequest(Ljava/lang/String;)I

    move-result v0

    return v0
.end method

.method sendMessage(Ltas/camera/CameraMessage;Ljava/lang/String;Z)V
    .locals 4
    .param p1, "msg"    # Ltas/camera/CameraMessage;
    .param p2, "proc"    # Ljava/lang/String;
    .param p3, "now"    # Z

    .prologue
    .line 162
    iget-object v1, p0, Ltas/internal/camera/InputSourceInner;->camcls:Ljava/lang/String;

    if-eqz v1, :cond_0

    .line 163
    invoke-direct {p0, p0, p1, p2, p3}, Ltas/internal/camera/InputSourceInner;->sendMessage(Ltas/internal/camera/InputSourceInner;Ltas/camera/CameraMessage;Ljava/lang/String;Z)V

    .line 164
    return-void

    .line 167
    :cond_0
    iget-object v1, p0, Ltas/internal/camera/InputSourceInner;->currinput:Ltas/internal/camera/InputSourceInner;

    if-eqz v1, :cond_1

    .line 168
    iget-object v1, p0, Ltas/internal/camera/InputSourceInner;->currinput:Ltas/internal/camera/InputSourceInner;

    invoke-virtual {v1, p1, p2, p3}, Ltas/internal/camera/InputSourceInner;->sendMessage(Ltas/camera/CameraMessage;Ljava/lang/String;Z)V

    .line 169
    return-void

    .line 172
    :cond_1
    iget-object v1, p0, Ltas/internal/camera/InputSourceInner;->inputs:[Ltas/internal/camera/InputSourceInner;

    if-nez v1, :cond_2

    .line 173
    iget-object v1, p0, Ltas/internal/camera/InputSourceInner;->TAG:Ljava/lang/String;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "no input found. cancel sendMessage - "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 174
    return-void

    .line 177
    :cond_2
    iget-object v2, p0, Ltas/internal/camera/InputSourceInner;->inputs:[Ltas/internal/camera/InputSourceInner;

    const/4 v1, 0x0

    array-length v3, v2

    :goto_0
    if-ge v1, v3, :cond_4

    aget-object v0, v2, v1

    .line 178
    .local v0, "input":Ltas/internal/camera/InputSourceInner;
    if-eqz v0, :cond_3

    invoke-virtual {v0, p1, p2, p3}, Ltas/internal/camera/InputSourceInner;->sendMessage(Ltas/camera/CameraMessage;Ljava/lang/String;Z)V

    .line 177
    :cond_3
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    .line 161
    .end local v0    # "input":Ltas/internal/camera/InputSourceInner;
    :cond_4
    return-void
.end method

.method public toString()Ljava/lang/String;
    .locals 3

    .prologue
    const/4 v1, 0x0

    .line 523
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 524
    const-string/jumbo v2, "input="

    .line 523
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 524
    iget-object v2, p0, Ltas/internal/camera/InputSourceInner;->inputname:Ljava/lang/String;

    .line 523
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 525
    const-string/jumbo v2, " cam="

    .line 523
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 525
    iget-object v2, p0, Ltas/internal/camera/InputSourceInner;->camname:Ljava/lang/String;

    .line 523
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 526
    const-string/jumbo v2, " id="

    .line 523
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 526
    iget-object v2, p0, Ltas/internal/camera/InputSourceInner;->camid:Ljava/lang/String;

    .line 523
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 527
    const-string/jumbo v2, " idCompat="

    .line 523
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 527
    iget v2, p0, Ltas/internal/camera/InputSourceInner;->camidCompat:I

    .line 523
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 528
    const-string/jumbo v2, " port="

    .line 523
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 528
    iget v2, p0, Ltas/internal/camera/InputSourceInner;->myport:I

    .line 523
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 529
    const-string/jumbo v2, " plugged="

    .line 523
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 529
    iget-object v2, p0, Ltas/internal/camera/InputSourceInner;->plugged:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v2

    .line 523
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 530
    const-string/jumbo v2, " parent="

    .line 523
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    .line 531
    iget-object v0, p0, Ltas/internal/camera/InputSourceInner;->parent:Ltas/internal/camera/InputSourceInner;

    if-eqz v0, :cond_1

    iget-object v0, p0, Ltas/internal/camera/InputSourceInner;->parent:Ltas/internal/camera/InputSourceInner;

    iget-object v0, v0, Ltas/internal/camera/InputSourceInner;->inputname:Ljava/lang/String;

    .line 523
    :goto_0
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 532
    const-string/jumbo v2, " numinputs="

    .line 523
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 532
    iget v2, p0, Ltas/internal/camera/InputSourceInner;->numinputs:I

    .line 523
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 533
    const-string/jumbo v2, " currinput="

    .line 523
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 534
    iget-object v2, p0, Ltas/internal/camera/InputSourceInner;->currinput:Ltas/internal/camera/InputSourceInner;

    if-eqz v2, :cond_0

    iget-object v1, p0, Ltas/internal/camera/InputSourceInner;->currinput:Ltas/internal/camera/InputSourceInner;

    iget-object v1, v1, Ltas/internal/camera/InputSourceInner;->inputname:Ljava/lang/String;

    .line 523
    :cond_0
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0

    :cond_1
    move-object v0, v1

    .line 531
    goto :goto_0
.end method

.method unplug()V
    .locals 3

    .prologue
    const/4 v1, 0x0

    .line 148
    iget-object v0, p0, Ltas/internal/camera/InputSourceInner;->parent:Ltas/internal/camera/InputSourceInner;

    if-eqz v0, :cond_1

    .line 149
    iget-object v0, p0, Ltas/internal/camera/InputSourceInner;->parent:Ltas/internal/camera/InputSourceInner;

    iget-object v0, v0, Ltas/internal/camera/InputSourceInner;->currinput:Ltas/internal/camera/InputSourceInner;

    if-eq v0, p0, :cond_0

    .line 150
    iget-object v0, p0, Ltas/internal/camera/InputSourceInner;->TAG:Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "ignore unplug - because already unplugged - "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    .line 151
    invoke-virtual {p0}, Ltas/internal/camera/InputSourceInner;->toString()Ljava/lang/String;

    move-result-object v2

    .line 150
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 152
    return-void

    .line 154
    :cond_0
    iget-object v0, p0, Ltas/internal/camera/InputSourceInner;->parent:Ltas/internal/camera/InputSourceInner;

    invoke-direct {v0, v1}, Ltas/internal/camera/InputSourceInner;->switchinput(Ltas/internal/camera/InputSourceInner;)V

    .line 147
    :goto_0
    return-void

    .line 156
    :cond_1
    invoke-direct {p0}, Ltas/internal/camera/InputSourceInner;->handleUnplug()V

    goto :goto_0
.end method
