.class public Lcom/thinkware/sundo/ieve/ieveExifTag;
.super Ljava/lang/Object;
.source "ieveExifTag.java"


# instance fields
.field private a:I

.field private b:I

.field public carangle:I

.field public carspeedhmh:I

.field public date:Ljava/util/Date;

.field public latitude:D

.field public longitude:D

.field public safecamera:I

.field public speedlimit:I


# direct methods
.method public constructor <init>()V
    .locals 0

    .prologue
    .line 23
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 24
    invoke-direct {p0}, Lcom/thinkware/sundo/ieve/ieveExifTag;->a()V

    .line 25
    return-void
.end method

.method public constructor <init>(Ljava/util/Date;DDIIII)V
    .locals 0
    .param p1, "_date"    # Ljava/util/Date;
    .param p2, "_latitude"    # D
    .param p4, "_longitude"    # D
    .param p6, "_carangle"    # I
    .param p7, "_carspeed"    # I
    .param p8, "_speedlimit"    # I
    .param p9, "_safecamera"    # I

    .prologue
    .line 27
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 28
    iput-object p1, p0, Lcom/thinkware/sundo/ieve/ieveExifTag;->date:Ljava/util/Date;

    .line 29
    iput-wide p2, p0, Lcom/thinkware/sundo/ieve/ieveExifTag;->latitude:D

    .line 30
    iput-wide p4, p0, Lcom/thinkware/sundo/ieve/ieveExifTag;->longitude:D

    .line 31
    iput p6, p0, Lcom/thinkware/sundo/ieve/ieveExifTag;->carangle:I

    .line 32
    iput p7, p0, Lcom/thinkware/sundo/ieve/ieveExifTag;->carspeedhmh:I

    .line 33
    iput p8, p0, Lcom/thinkware/sundo/ieve/ieveExifTag;->speedlimit:I

    .line 34
    iput p9, p0, Lcom/thinkware/sundo/ieve/ieveExifTag;->safecamera:I

    .line 35
    return-void
.end method

.method private a()V
    .locals 4

    .prologue
    const-wide/16 v2, 0x0

    const/4 v1, 0x0

    .line 38
    const/4 v0, 0x0

    iput-object v0, p0, Lcom/thinkware/sundo/ieve/ieveExifTag;->date:Ljava/util/Date;

    .line 39
    iput-wide v2, p0, Lcom/thinkware/sundo/ieve/ieveExifTag;->latitude:D

    .line 40
    iput-wide v2, p0, Lcom/thinkware/sundo/ieve/ieveExifTag;->longitude:D

    .line 41
    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveExifTag;->carangle:I

    .line 42
    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveExifTag;->carspeedhmh:I

    .line 43
    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveExifTag;->speedlimit:I

    .line 44
    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveExifTag;->safecamera:I

    .line 46
    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveExifTag;->a:I

    .line 47
    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveExifTag;->b:I

    .line 48
    return-void
.end method


# virtual methods
.method public copy(Lcom/thinkware/sundo/ieve/ieveExifTag;)V
    .locals 2
    .param p1, "exif"    # Lcom/thinkware/sundo/ieve/ieveExifTag;

    .prologue
    .line 51
    iget-object v0, p1, Lcom/thinkware/sundo/ieve/ieveExifTag;->date:Ljava/util/Date;

    iput-object v0, p0, Lcom/thinkware/sundo/ieve/ieveExifTag;->date:Ljava/util/Date;

    .line 52
    iget-wide v0, p1, Lcom/thinkware/sundo/ieve/ieveExifTag;->latitude:D

    iput-wide v0, p0, Lcom/thinkware/sundo/ieve/ieveExifTag;->latitude:D

    .line 53
    iget-wide v0, p1, Lcom/thinkware/sundo/ieve/ieveExifTag;->longitude:D

    iput-wide v0, p0, Lcom/thinkware/sundo/ieve/ieveExifTag;->longitude:D

    .line 54
    iget v0, p1, Lcom/thinkware/sundo/ieve/ieveExifTag;->carangle:I

    iput v0, p0, Lcom/thinkware/sundo/ieve/ieveExifTag;->carangle:I

    .line 55
    iget v0, p1, Lcom/thinkware/sundo/ieve/ieveExifTag;->carspeedhmh:I

    iput v0, p0, Lcom/thinkware/sundo/ieve/ieveExifTag;->carspeedhmh:I

    .line 56
    iget v0, p1, Lcom/thinkware/sundo/ieve/ieveExifTag;->speedlimit:I

    iput v0, p0, Lcom/thinkware/sundo/ieve/ieveExifTag;->speedlimit:I

    .line 57
    iget v0, p1, Lcom/thinkware/sundo/ieve/ieveExifTag;->safecamera:I

    iput v0, p0, Lcom/thinkware/sundo/ieve/ieveExifTag;->safecamera:I

    .line 59
    iget v0, p1, Lcom/thinkware/sundo/ieve/ieveExifTag;->a:I

    iput v0, p0, Lcom/thinkware/sundo/ieve/ieveExifTag;->a:I

    .line 60
    iget v0, p1, Lcom/thinkware/sundo/ieve/ieveExifTag;->b:I

    iput v0, p0, Lcom/thinkware/sundo/ieve/ieveExifTag;->b:I

    .line 61
    return-void
.end method

.method public getImageHeight()I
    .locals 1

    .prologue
    .line 68
    iget v0, p0, Lcom/thinkware/sundo/ieve/ieveExifTag;->b:I

    return v0
.end method

.method public getImageWidth()I
    .locals 1

    .prologue
    .line 64
    iget v0, p0, Lcom/thinkware/sundo/ieve/ieveExifTag;->a:I

    return v0
.end method

.method public readFile(Ljava/lang/String;)Z
    .locals 13
    .param p1, "pathname"    # Ljava/lang/String;

    .prologue
    const/4 v12, 0x4

    const/4 v5, 0x1

    const-wide/high16 v10, -0x4010000000000000L    # -1.0

    const/4 v6, 0x0

    .line 73
    :try_start_0
    new-instance v1, Landroid/media/ExifInterface;

    invoke-direct {v1, p1}, Landroid/media/ExifInterface;-><init>(Ljava/lang/String;)V

    .line 74
    .local v1, "exif":Landroid/media/ExifInterface;
    new-instance v4, Ljava/text/SimpleDateFormat;

    const-string v7, "yyyy:MM:dd HH:mm:ss"

    invoke-direct {v4, v7}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;)V

    .line 75
    .local v4, "sdf":Ljava/text/SimpleDateFormat;
    const-string v7, "DateTime"

    invoke-virtual {v1, v7}, Landroid/media/ExifInterface;->getAttribute(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v4, v7}, Ljava/text/SimpleDateFormat;->parse(Ljava/lang/String;)Ljava/util/Date;

    move-result-object v7

    iput-object v7, p0, Lcom/thinkware/sundo/ieve/ieveExifTag;->date:Ljava/util/Date;

    .line 76
    const-string v7, "GPSLatitude"

    invoke-virtual {v1, v7}, Landroid/media/ExifInterface;->getAttribute(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-static {v7}, Lcom/thinkware/sundo/ieve/b;->a(Ljava/lang/String;)D

    move-result-wide v8

    iput-wide v8, p0, Lcom/thinkware/sundo/ieve/ieveExifTag;->latitude:D

    .line 77
    const-string v7, "GPSLongitude"

    invoke-virtual {v1, v7}, Landroid/media/ExifInterface;->getAttribute(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-static {v7}, Lcom/thinkware/sundo/ieve/b;->a(Ljava/lang/String;)D

    move-result-wide v8

    iput-wide v8, p0, Lcom/thinkware/sundo/ieve/ieveExifTag;->longitude:D

    .line 78
    const-string v7, "GPSLatitudeRef"

    invoke-virtual {v1, v7}, Landroid/media/ExifInterface;->getAttribute(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    const-string v8, "S"

    if-ne v7, v8, :cond_0

    iget-wide v8, p0, Lcom/thinkware/sundo/ieve/ieveExifTag;->latitude:D

    mul-double/2addr v8, v10

    iput-wide v8, p0, Lcom/thinkware/sundo/ieve/ieveExifTag;->latitude:D

    .line 79
    :cond_0
    const-string v7, "GPSLongitudeRef"

    invoke-virtual {v1, v7}, Landroid/media/ExifInterface;->getAttribute(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    const-string v8, "W"

    if-ne v7, v8, :cond_1

    iget-wide v8, p0, Lcom/thinkware/sundo/ieve/ieveExifTag;->longitude:D

    mul-double/2addr v8, v10

    iput-wide v8, p0, Lcom/thinkware/sundo/ieve/ieveExifTag;->longitude:D

    .line 80
    :cond_1
    const-string v7, "UserComment"

    invoke-virtual {v1, v7}, Landroid/media/ExifInterface;->getAttribute(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 81
    .local v3, "sCars":Ljava/lang/String;
    if-eqz v3, :cond_2

    .line 82
    const-string v7, ":"

    const/4 v8, 0x4

    invoke-virtual {v3, v7, v8}, Ljava/lang/String;->split(Ljava/lang/String;I)[Ljava/lang/String;

    move-result-object v2

    .line 83
    .local v2, "sCar":[Ljava/lang/String;
    array-length v7, v2

    if-ne v7, v12, :cond_2

    .line 84
    const/4 v7, 0x0

    aget-object v7, v2, v7

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/Integer;->intValue()I

    move-result v7

    iput v7, p0, Lcom/thinkware/sundo/ieve/ieveExifTag;->carangle:I

    .line 85
    const/4 v7, 0x1

    aget-object v7, v2, v7

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/Integer;->intValue()I

    move-result v7

    iput v7, p0, Lcom/thinkware/sundo/ieve/ieveExifTag;->carspeedhmh:I

    .line 86
    const/4 v7, 0x2

    aget-object v7, v2, v7

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/Integer;->intValue()I

    move-result v7

    iput v7, p0, Lcom/thinkware/sundo/ieve/ieveExifTag;->speedlimit:I

    .line 87
    const/4 v7, 0x3

    aget-object v7, v2, v7

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/Integer;->intValue()I

    move-result v7

    iput v7, p0, Lcom/thinkware/sundo/ieve/ieveExifTag;->safecamera:I

    .line 90
    .end local v2    # "sCar":[Ljava/lang/String;
    :cond_2
    const-string v7, "ImageWidth"

    const/4 v8, 0x0

    invoke-virtual {v1, v7, v8}, Landroid/media/ExifInterface;->getAttributeInt(Ljava/lang/String;I)I

    move-result v7

    iput v7, p0, Lcom/thinkware/sundo/ieve/ieveExifTag;->a:I

    .line 91
    const-string v7, "ImageLength"

    const/4 v8, 0x0

    invoke-virtual {v1, v7, v8}, Landroid/media/ExifInterface;->getAttributeInt(Ljava/lang/String;I)I

    move-result v7

    iput v7, p0, Lcom/thinkware/sundo/ieve/ieveExifTag;->b:I
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/text/ParseException; {:try_start_0 .. :try_end_0} :catch_1

    .line 99
    .end local v1    # "exif":Landroid/media/ExifInterface;
    .end local v3    # "sCars":Ljava/lang/String;
    .end local v4    # "sdf":Ljava/text/SimpleDateFormat;
    :goto_0
    return v5

    .line 92
    :catch_0
    move-exception v0

    .line 93
    .local v0, "e":Ljava/io/IOException;
    invoke-virtual {v0}, Ljava/io/IOException;->printStackTrace()V

    move v5, v6

    .line 94
    goto :goto_0

    .line 95
    .end local v0    # "e":Ljava/io/IOException;
    :catch_1
    move-exception v0

    .line 96
    .local v0, "e":Ljava/text/ParseException;
    invoke-virtual {v0}, Ljava/text/ParseException;->printStackTrace()V

    move v5, v6

    .line 97
    goto :goto_0
.end method

.method public writeFile(Ljava/lang/String;II)Z
    .locals 10
    .param p1, "pathname"    # Ljava/lang/String;
    .param p2, "width"    # I
    .param p3, "height"    # I

    .prologue
    const-wide/16 v8, 0x0

    .line 104
    new-instance v2, Ljava/text/SimpleDateFormat;

    const-string v3, "yyyy:MM:dd HH:mm:ss"

    invoke-direct {v2, v3}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;)V

    .line 106
    .local v2, "sdf":Ljava/text/SimpleDateFormat;
    :try_start_0
    new-instance v1, Landroid/media/ExifInterface;

    invoke-direct {v1, p1}, Landroid/media/ExifInterface;-><init>(Ljava/lang/String;)V

    .line 107
    .local v1, "exif":Landroid/media/ExifInterface;
    const-string v3, "DateTime"

    iget-object v4, p0, Lcom/thinkware/sundo/ieve/ieveExifTag;->date:Ljava/util/Date;

    invoke-virtual {v2, v4}, Ljava/text/SimpleDateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v3, v4}, Landroid/media/ExifInterface;->setAttribute(Ljava/lang/String;Ljava/lang/String;)V

    .line 108
    const-string v3, "GPSLatitude"

    iget-wide v4, p0, Lcom/thinkware/sundo/ieve/ieveExifTag;->latitude:D

    invoke-static {v4, v5}, Lcom/thinkware/sundo/ieve/b;->a(D)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v3, v4}, Landroid/media/ExifInterface;->setAttribute(Ljava/lang/String;Ljava/lang/String;)V

    .line 109
    const-string v3, "GPSLongitude"

    iget-wide v4, p0, Lcom/thinkware/sundo/ieve/ieveExifTag;->longitude:D

    invoke-static {v4, v5}, Lcom/thinkware/sundo/ieve/b;->a(D)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v3, v4}, Landroid/media/ExifInterface;->setAttribute(Ljava/lang/String;Ljava/lang/String;)V

    .line 110
    const-string v4, "GPSLatitudeRef"

    iget-wide v6, p0, Lcom/thinkware/sundo/ieve/ieveExifTag;->latitude:D

    cmpl-double v3, v6, v8

    if-lez v3, :cond_0

    const-string v3, "N"

    :goto_0
    invoke-virtual {v1, v4, v3}, Landroid/media/ExifInterface;->setAttribute(Ljava/lang/String;Ljava/lang/String;)V

    .line 111
    const-string v4, "GPSLongitudeRef"

    iget-wide v6, p0, Lcom/thinkware/sundo/ieve/ieveExifTag;->longitude:D

    cmpl-double v3, v6, v8

    if-lez v3, :cond_1

    const-string v3, "E"

    :goto_1
    invoke-virtual {v1, v4, v3}, Landroid/media/ExifInterface;->setAttribute(Ljava/lang/String;Ljava/lang/String;)V

    .line 112
    const-string v3, "ImageLength"

    invoke-static {p3}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v3, v4}, Landroid/media/ExifInterface;->setAttribute(Ljava/lang/String;Ljava/lang/String;)V

    .line 113
    const-string v3, "ImageWidth"

    invoke-static {p2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v3, v4}, Landroid/media/ExifInterface;->setAttribute(Ljava/lang/String;Ljava/lang/String;)V

    .line 114
    const-string v3, "Make"

    const-string v4, "Thinkware"

    invoke-virtual {v1, v3, v4}, Landroid/media/ExifInterface;->setAttribute(Ljava/lang/String;Ljava/lang/String;)V

    .line 115
    const-string v3, "Model"

    const-string v4, "ARC-100"

    invoke-virtual {v1, v3, v4}, Landroid/media/ExifInterface;->setAttribute(Ljava/lang/String;Ljava/lang/String;)V

    .line 116
    const-string v3, "UserComment"

    .line 117
    new-instance v4, Ljava/lang/StringBuilder;

    iget v5, p0, Lcom/thinkware/sundo/ieve/ieveExifTag;->carangle:I

    invoke-static {v5}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v5

    invoke-static {v5}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v5

    invoke-direct {v4, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string v5, ":"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    .line 118
    iget v5, p0, Lcom/thinkware/sundo/ieve/ieveExifTag;->carspeedhmh:I

    invoke-static {v5}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string v5, ":"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    .line 119
    iget v5, p0, Lcom/thinkware/sundo/ieve/ieveExifTag;->speedlimit:I

    invoke-static {v5}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string v5, ":"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    .line 120
    iget v5, p0, Lcom/thinkware/sundo/ieve/ieveExifTag;->safecamera:I

    invoke-static {v5}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    .line 117
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    .line 116
    invoke-virtual {v1, v3, v4}, Landroid/media/ExifInterface;->setAttribute(Ljava/lang/String;Ljava/lang/String;)V

    .line 121
    invoke-virtual {v1}, Landroid/media/ExifInterface;->saveAttributes()V

    .line 126
    const/4 v3, 0x1

    .end local v1    # "exif":Landroid/media/ExifInterface;
    :goto_2
    return v3

    .line 110
    .restart local v1    # "exif":Landroid/media/ExifInterface;
    :cond_0
    const-string v3, "S"

    goto :goto_0

    .line 111
    :cond_1
    const-string v3, "W"
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_1

    .line 122
    .end local v1    # "exif":Landroid/media/ExifInterface;
    :catch_0
    move-exception v0

    .line 123
    .local v0, "e":Ljava/io/IOException;
    invoke-virtual {v0}, Ljava/io/IOException;->printStackTrace()V

    .line 124
    const/4 v3, 0x0

    goto :goto_2
.end method
