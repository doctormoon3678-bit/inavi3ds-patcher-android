.class public interface abstract Ltas/camera/CameraListener;
.super Ljava/lang/Object;
.source "CameraListener.java"

# interfaces
.implements Ltas/camera/CameraStateListener;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ltas/camera/CameraId;",
        ">",
        "Ljava/lang/Object;",
        "Ltas/camera/CameraStateListener",
        "<TT;>;"
    }
.end annotation


# virtual methods
.method public abstract onCommandResult(Ltas/camera/CameraId;II)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;II)V"
        }
    .end annotation
.end method

.method public abstract onExtraMessage(Ltas/camera/CameraId;Ltas/camera/CameraMessage;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;",
            "Ltas/camera/CameraMessage;",
            ")V"
        }
    .end annotation
.end method

.method public abstract onRequestResult(Ltas/camera/CameraId;I)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;I)V"
        }
    .end annotation
.end method
