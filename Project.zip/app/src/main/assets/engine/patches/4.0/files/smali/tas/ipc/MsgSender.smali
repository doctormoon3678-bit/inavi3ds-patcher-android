.class public Ltas/ipc/MsgSender;
.super Ljava/lang/Object;
.source "MsgSender.java"


# instance fields
.field private IMPL:Ltas/internal/ipc/Sender;


# direct methods
.method public constructor <init>(Landroid/content/Context;Ljava/lang/String;Landroid/os/Looper;)V
    .locals 1
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "name"    # Ljava/lang/String;
    .param p3, "looper"    # Landroid/os/Looper;

    .prologue
    .line 29
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 31
    new-instance v0, Ltas/internal/ipc/Sender;

    invoke-direct {v0, p1, p2, p3}, Ltas/internal/ipc/Sender;-><init>(Landroid/content/Context;Ljava/lang/String;Landroid/os/Looper;)V

    iput-object v0, p0, Ltas/ipc/MsgSender;->IMPL:Ltas/internal/ipc/Sender;

    .line 30
    return-void
.end method


# virtual methods
.method public destroySession(I)V
    .locals 4
    .param p1, "id"    # I

    .prologue
    .line 93
    iget-object v0, p0, Ltas/ipc/MsgSender;->IMPL:Ltas/internal/ipc/Sender;

    int-to-long v2, p1

    invoke-virtual {v0, v2, v3}, Ltas/internal/ipc/Sender;->destroySession(J)V

    .line 92
    return-void
.end method

.method public getExtra()Landroid/os/Bundle;
    .locals 1

    .prologue
    .line 101
    iget-object v0, p0, Ltas/ipc/MsgSender;->IMPL:Ltas/internal/ipc/Sender;

    invoke-virtual {v0}, Ltas/internal/ipc/Sender;->getExtra()Landroid/os/Bundle;

    move-result-object v0

    return-object v0
.end method

.method public isOnline()Z
    .locals 1

    .prologue
    .line 49
    iget-object v0, p0, Ltas/ipc/MsgSender;->IMPL:Ltas/internal/ipc/Sender;

    invoke-virtual {v0}, Ltas/internal/ipc/Sender;->isOnline()Z

    move-result v0

    return v0
.end method

.method public offline()V
    .locals 1

    .prologue
    .line 45
    iget-object v0, p0, Ltas/ipc/MsgSender;->IMPL:Ltas/internal/ipc/Sender;

    invoke-virtual {v0}, Ltas/internal/ipc/Sender;->offline()V

    .line 44
    return-void
.end method

.method public online()V
    .locals 1

    .prologue
    .line 38
    iget-object v0, p0, Ltas/ipc/MsgSender;->IMPL:Ltas/internal/ipc/Sender;

    invoke-virtual {v0}, Ltas/internal/ipc/Sender;->online()V

    .line 37
    return-void
.end method

.method public peekExtra()Landroid/os/Bundle;
    .locals 1

    .prologue
    .line 108
    iget-object v0, p0, Ltas/ipc/MsgSender;->IMPL:Ltas/internal/ipc/Sender;

    invoke-virtual {v0}, Ltas/internal/ipc/Sender;->peekExtra()Landroid/os/Bundle;

    move-result-object v0

    return-object v0
.end method

.method public release()V
    .locals 1

    .prologue
    .line 130
    iget-object v0, p0, Ltas/ipc/MsgSender;->IMPL:Ltas/internal/ipc/Sender;

    invoke-virtual {v0}, Ltas/internal/ipc/Sender;->release()V

    .line 129
    return-void
.end method

.method public requestAnonymousSession(Ltas/ipc/SenderSession$Callback;)V
    .locals 1
    .param p1, "cb"    # Ltas/ipc/SenderSession$Callback;

    .prologue
    .line 70
    if-eqz p1, :cond_0

    .line 71
    iget-object v0, p0, Ltas/ipc/MsgSender;->IMPL:Ltas/internal/ipc/Sender;

    invoke-virtual {v0, p1}, Ltas/internal/ipc/Sender;->requestAnonymousSession(Ltas/ipc/SenderSession$Callback;)V

    .line 69
    :cond_0
    return-void
.end method

.method public requestAnonymousSessionLazily(Ltas/ipc/SenderSession$Callback;)Ltas/ipc/SenderSession;
    .locals 1
    .param p1, "cb"    # Ltas/ipc/SenderSession$Callback;

    .prologue
    .line 86
    iget-object v0, p0, Ltas/ipc/MsgSender;->IMPL:Ltas/internal/ipc/Sender;

    invoke-virtual {v0, p1}, Ltas/internal/ipc/Sender;->requestAnonymousSessionLazily(Ltas/ipc/SenderSession$Callback;)Ltas/ipc/SenderSession;

    move-result-object v0

    return-object v0
.end method

.method public requestSession(Ljava/lang/String;Ltas/ipc/SenderSession$Callback;)V
    .locals 1
    .param p1, "name"    # Ljava/lang/String;
    .param p2, "cb"    # Ltas/ipc/SenderSession$Callback;

    .prologue
    .line 59
    if-eqz p1, :cond_0

    if-eqz p2, :cond_0

    .line 60
    iget-object v0, p0, Ltas/ipc/MsgSender;->IMPL:Ltas/internal/ipc/Sender;

    invoke-virtual {v0, p1, p2}, Ltas/internal/ipc/Sender;->requestSession(Ljava/lang/String;Ltas/ipc/SenderSession$Callback;)V

    .line 58
    :cond_0
    return-void
.end method

.method public setExtra(Landroid/os/Bundle;)V
    .locals 1
    .param p1, "extra"    # Landroid/os/Bundle;

    .prologue
    .line 116
    iget-object v0, p0, Ltas/ipc/MsgSender;->IMPL:Ltas/internal/ipc/Sender;

    invoke-virtual {v0, p1}, Ltas/internal/ipc/Sender;->setExtra(Landroid/os/Bundle;)V

    .line 115
    return-void
.end method

.method public update()V
    .locals 1

    .prologue
    .line 126
    iget-object v0, p0, Ltas/ipc/MsgSender;->IMPL:Ltas/internal/ipc/Sender;

    invoke-virtual {v0}, Ltas/internal/ipc/Sender;->update()V

    .line 125
    return-void
.end method
