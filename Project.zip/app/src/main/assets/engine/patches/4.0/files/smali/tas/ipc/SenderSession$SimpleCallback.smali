.class public Ltas/ipc/SenderSession$SimpleCallback;
.super Ljava/lang/Object;
.source "SenderSession.java"

# interfaces
.implements Ltas/ipc/SenderSession$Callback;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltas/ipc/SenderSession;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "SimpleCallback"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    .prologue
    .line 197
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onReceiverOffline(Ltas/ipc/SenderSession;)V
    .locals 0
    .param p1, "session"    # Ltas/ipc/SenderSession;

    .prologue
    .line 202
    return-void
.end method

.method public onReceiverOnline(Ltas/ipc/SenderSession;)V
    .locals 0
    .param p1, "session"    # Ltas/ipc/SenderSession;

    .prologue
    .line 199
    return-void
.end method

.method public onReceiverUpdate(Ltas/ipc/SenderSession;Landroid/os/Bundle;)V
    .locals 0
    .param p1, "session"    # Ltas/ipc/SenderSession;
    .param p2, "extra"    # Landroid/os/Bundle;

    .prologue
    .line 206
    return-void
.end method

.method public onReply(Ltas/ipc/SenderSession;ILtas/ipc/MsgData;)V
    .locals 0
    .param p1, "session"    # Ltas/ipc/SenderSession;
    .param p2, "what"    # I
    .param p3, "msg"    # Ltas/ipc/MsgData;

    .prologue
    .line 210
    return-void
.end method
