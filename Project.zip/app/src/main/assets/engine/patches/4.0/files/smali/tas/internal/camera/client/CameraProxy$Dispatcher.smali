.class Ltas/internal/camera/client/CameraProxy$Dispatcher;
.super Landroid/os/Handler;
.source "CameraProxy.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltas/internal/camera/client/CameraProxy;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "Dispatcher"
.end annotation


# static fields
.field private static final MSG_CABLE_STATE:I = 0x0

.field private static final MSG_CAMERA_MESSAGE:I = 0x15

.field private static final MSG_CAMERA_STATE:I = 0x1

.field private static final MSG_COMMAND_RESULT:I = 0x14

.field private static final MSG_EXTRA_STATE:I = 0xa

.field private static final MSG_MEDIA_SERVER_DIED:I = 0xc

.field private static final MSG_REQUEST_RESULT:I = 0xb


# instance fields
.field private final mProxy:Ljava/lang/ref/WeakReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference",
            "<",
            "Ltas/internal/camera/client/CameraProxy;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static synthetic -wrap0(Ltas/internal/camera/client/CameraProxy$Dispatcher;Z)V
    .locals 0
    .param p1, "plugged"    # Z

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/camera/client/CameraProxy$Dispatcher;->dispatchCableState(Z)V

    return-void
.end method

.method static synthetic -wrap1(Ltas/internal/camera/client/CameraProxy$Dispatcher;Ltas/internal/camera/client/ServerConnection$Holder;)V
    .locals 0
    .param p1, "holder"    # Ltas/internal/camera/client/ServerConnection$Holder;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/camera/client/CameraProxy$Dispatcher;->dispatchCameraMessage(Ltas/internal/camera/client/ServerConnection$Holder;)V

    return-void
.end method

.method static synthetic -wrap2(Ltas/internal/camera/client/CameraProxy$Dispatcher;Z)V
    .locals 0
    .param p1, "opened"    # Z

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/camera/client/CameraProxy$Dispatcher;->dispatchCameraState(Z)V

    return-void
.end method

.method static synthetic -wrap3(Ltas/internal/camera/client/CameraProxy$Dispatcher;II)V
    .locals 0
    .param p1, "cmd"    # I
    .param p2, "result"    # I

    .prologue
    invoke-direct {p0, p1, p2}, Ltas/internal/camera/client/CameraProxy$Dispatcher;->dispatchCommandResult(II)V

    return-void
.end method

.method static synthetic -wrap4(Ltas/internal/camera/client/CameraProxy$Dispatcher;II)V
    .locals 0
    .param p1, "state"    # I
    .param p2, "flag"    # I

    .prologue
    invoke-direct {p0, p1, p2}, Ltas/internal/camera/client/CameraProxy$Dispatcher;->dispatchExtraState(II)V

    return-void
.end method

.method static synthetic -wrap5(Ltas/internal/camera/client/CameraProxy$Dispatcher;)V
    .locals 0

    invoke-direct {p0}, Ltas/internal/camera/client/CameraProxy$Dispatcher;->dispatchMediaServerDied()V

    return-void
.end method

.method static synthetic -wrap6(Ltas/internal/camera/client/CameraProxy$Dispatcher;I)V
    .locals 0
    .param p1, "result"    # I

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/camera/client/CameraProxy$Dispatcher;->dispatchRequestResult(I)V

    return-void
.end method

.method private constructor <init>(Landroid/os/Looper;Ltas/internal/camera/client/CameraProxy;)V
    .locals 1
    .param p1, "looper"    # Landroid/os/Looper;
    .param p2, "proxy"    # Ltas/internal/camera/client/CameraProxy;

    .prologue
    .line 239
    .local p0, "this":Ltas/internal/camera/client/CameraProxy$Dispatcher;, "Ltas/internal/camera/client/CameraProxy<TT;>.Dispatcher;"
    invoke-direct {p0, p1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 240
    new-instance v0, Ljava/lang/ref/WeakReference;

    invoke-direct {v0, p2}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    iput-object v0, p0, Ltas/internal/camera/client/CameraProxy$Dispatcher;->mProxy:Ljava/lang/ref/WeakReference;

    .line 238
    return-void
.end method

.method synthetic constructor <init>(Landroid/os/Looper;Ltas/internal/camera/client/CameraProxy;Ltas/internal/camera/client/CameraProxy$Dispatcher;)V
    .locals 0
    .param p1, "looper"    # Landroid/os/Looper;
    .param p2, "proxy"    # Ltas/internal/camera/client/CameraProxy;

    .prologue
    .local p0, "this":Ltas/internal/camera/client/CameraProxy$Dispatcher;, "Ltas/internal/camera/client/CameraProxy<TT;>.Dispatcher;"
    invoke-direct {p0, p1, p2}, Ltas/internal/camera/client/CameraProxy$Dispatcher;-><init>(Landroid/os/Looper;Ltas/internal/camera/client/CameraProxy;)V

    return-void
.end method

.method private dispatchCableState(Z)V
    .locals 2
    .param p1, "plugged"    # Z

    .prologue
    .local p0, "this":Ltas/internal/camera/client/CameraProxy$Dispatcher;, "Ltas/internal/camera/client/CameraProxy<TT;>.Dispatcher;"
    const/4 v1, 0x0

    .line 244
    if-eqz p1, :cond_0

    const/4 v0, 0x1

    :goto_0
    invoke-virtual {p0, v1, v0, v1}, Ltas/internal/camera/client/CameraProxy$Dispatcher;->obtainMessage(III)Landroid/os/Message;

    move-result-object v0

    invoke-virtual {p0, v0}, Ltas/internal/camera/client/CameraProxy$Dispatcher;->sendMessage(Landroid/os/Message;)Z

    .line 243
    return-void

    :cond_0
    move v0, v1

    .line 244
    goto :goto_0
.end method

.method private dispatchCameraMessage(Ltas/internal/camera/client/ServerConnection$Holder;)V
    .locals 1
    .param p1, "holder"    # Ltas/internal/camera/client/ServerConnection$Holder;

    .prologue
    .line 252
    .local p0, "this":Ltas/internal/camera/client/CameraProxy$Dispatcher;, "Ltas/internal/camera/client/CameraProxy<TT;>.Dispatcher;"
    const/16 v0, 0x15

    invoke-virtual {p0, v0, p1}, Ltas/internal/camera/client/CameraProxy$Dispatcher;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object v0

    invoke-virtual {p0, v0}, Ltas/internal/camera/client/CameraProxy$Dispatcher;->sendMessage(Landroid/os/Message;)Z

    .line 251
    return-void
.end method

.method private dispatchCameraState(Z)V
    .locals 3
    .param p1, "opened"    # Z

    .prologue
    .local p0, "this":Ltas/internal/camera/client/CameraProxy$Dispatcher;, "Ltas/internal/camera/client/CameraProxy<TT;>.Dispatcher;"
    const/4 v1, 0x1

    const/4 v2, 0x0

    .line 248
    if-eqz p1, :cond_0

    move v0, v1

    :goto_0
    invoke-virtual {p0, v1, v0, v2}, Ltas/internal/camera/client/CameraProxy$Dispatcher;->obtainMessage(III)Landroid/os/Message;

    move-result-object v0

    invoke-virtual {p0, v0}, Ltas/internal/camera/client/CameraProxy$Dispatcher;->sendMessage(Landroid/os/Message;)Z

    .line 247
    return-void

    :cond_0
    move v0, v2

    .line 248
    goto :goto_0
.end method

.method private dispatchCommandResult(II)V
    .locals 1
    .param p1, "cmd"    # I
    .param p2, "result"    # I

    .prologue
    .line 260
    .local p0, "this":Ltas/internal/camera/client/CameraProxy$Dispatcher;, "Ltas/internal/camera/client/CameraProxy<TT;>.Dispatcher;"
    const/16 v0, 0x14

    invoke-virtual {p0, v0, p1, p2}, Ltas/internal/camera/client/CameraProxy$Dispatcher;->obtainMessage(III)Landroid/os/Message;

    move-result-object v0

    invoke-virtual {p0, v0}, Ltas/internal/camera/client/CameraProxy$Dispatcher;->sendMessage(Landroid/os/Message;)Z

    .line 259
    return-void
.end method

.method private dispatchExtraState(II)V
    .locals 1
    .param p1, "state"    # I
    .param p2, "flag"    # I

    .prologue
    .line 268
    .local p0, "this":Ltas/internal/camera/client/CameraProxy$Dispatcher;, "Ltas/internal/camera/client/CameraProxy<TT;>.Dispatcher;"
    const/16 v0, 0xa

    invoke-virtual {p0, v0, p1, p2}, Ltas/internal/camera/client/CameraProxy$Dispatcher;->obtainMessage(III)Landroid/os/Message;

    move-result-object v0

    invoke-virtual {p0, v0}, Ltas/internal/camera/client/CameraProxy$Dispatcher;->sendMessage(Landroid/os/Message;)Z

    .line 267
    return-void
.end method

.method private dispatchMediaServerDied()V
    .locals 1

    .prologue
    .line 264
    .local p0, "this":Ltas/internal/camera/client/CameraProxy$Dispatcher;, "Ltas/internal/camera/client/CameraProxy<TT;>.Dispatcher;"
    const/16 v0, 0xc

    invoke-virtual {p0, v0}, Ltas/internal/camera/client/CameraProxy$Dispatcher;->sendEmptyMessage(I)Z

    .line 263
    return-void
.end method

.method private dispatchRequestResult(I)V
    .locals 2
    .param p1, "result"    # I

    .prologue
    .line 256
    .local p0, "this":Ltas/internal/camera/client/CameraProxy$Dispatcher;, "Ltas/internal/camera/client/CameraProxy<TT;>.Dispatcher;"
    const/16 v0, 0xb

    const/4 v1, 0x0

    invoke-virtual {p0, v0, p1, v1}, Ltas/internal/camera/client/CameraProxy$Dispatcher;->obtainMessage(III)Landroid/os/Message;

    move-result-object v0

    invoke-virtual {p0, v0}, Ltas/internal/camera/client/CameraProxy$Dispatcher;->sendMessage(Landroid/os/Message;)Z

    .line 255
    return-void
.end method

.method private onCableState(Z)V
    .locals 2
    .param p1, "plugged"    # Z

    .prologue
    .line 272
    .local p0, "this":Ltas/internal/camera/client/CameraProxy$Dispatcher;, "Ltas/internal/camera/client/CameraProxy<TT;>.Dispatcher;"
    iget-object v1, p0, Ltas/internal/camera/client/CameraProxy$Dispatcher;->mProxy:Ljava/lang/ref/WeakReference;

    invoke-virtual {v1}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/camera/client/CameraProxy;

    .line 273
    .local v0, "proxy":Ltas/internal/camera/client/CameraProxy;
    if-eqz v0, :cond_0

    .line 274
    invoke-static {v0, p1}, Ltas/internal/camera/client/CameraProxy;->-wrap0(Ltas/internal/camera/client/CameraProxy;Z)V

    .line 271
    :cond_0
    return-void
.end method

.method private onCameraMessage(Ltas/internal/camera/client/ServerConnection$Holder;)V
    .locals 2
    .param p1, "holder"    # Ltas/internal/camera/client/ServerConnection$Holder;

    .prologue
    .line 307
    .local p0, "this":Ltas/internal/camera/client/CameraProxy$Dispatcher;, "Ltas/internal/camera/client/CameraProxy<TT;>.Dispatcher;"
    iget-object v1, p0, Ltas/internal/camera/client/CameraProxy$Dispatcher;->mProxy:Ljava/lang/ref/WeakReference;

    invoke-virtual {v1}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/camera/client/CameraProxy;

    .line 308
    .local v0, "proxy":Ltas/internal/camera/client/CameraProxy;
    if-eqz v0, :cond_0

    .line 309
    iget-object v1, p1, Ltas/internal/camera/client/ServerConnection$Holder;->msg:Ltas/camera/CameraMessage;

    invoke-static {v0, v1}, Ltas/internal/camera/client/CameraProxy;->-wrap1(Ltas/internal/camera/client/CameraProxy;Ltas/camera/CameraMessage;)V

    .line 311
    :cond_0
    invoke-virtual {p1}, Ltas/internal/camera/client/ServerConnection$Holder;->recycle()V

    .line 306
    return-void
.end method

.method private onCameraState(Z)V
    .locals 2
    .param p1, "opened"    # Z

    .prologue
    .line 279
    .local p0, "this":Ltas/internal/camera/client/CameraProxy$Dispatcher;, "Ltas/internal/camera/client/CameraProxy<TT;>.Dispatcher;"
    iget-object v1, p0, Ltas/internal/camera/client/CameraProxy$Dispatcher;->mProxy:Ljava/lang/ref/WeakReference;

    invoke-virtual {v1}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/camera/client/CameraProxy;

    .line 280
    .local v0, "proxy":Ltas/internal/camera/client/CameraProxy;
    if-eqz v0, :cond_0

    .line 281
    invoke-static {v0, p1}, Ltas/internal/camera/client/CameraProxy;->-wrap2(Ltas/internal/camera/client/CameraProxy;Z)V

    .line 278
    :cond_0
    return-void
.end method

.method private onCommandResult(II)V
    .locals 2
    .param p1, "cmd"    # I
    .param p2, "result"    # I

    .prologue
    .line 300
    .local p0, "this":Ltas/internal/camera/client/CameraProxy$Dispatcher;, "Ltas/internal/camera/client/CameraProxy<TT;>.Dispatcher;"
    iget-object v1, p0, Ltas/internal/camera/client/CameraProxy$Dispatcher;->mProxy:Ljava/lang/ref/WeakReference;

    invoke-virtual {v1}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/camera/client/CameraProxy;

    .line 301
    .local v0, "proxy":Ltas/internal/camera/client/CameraProxy;
    if-eqz v0, :cond_0

    .line 302
    invoke-static {v0, p1, p2}, Ltas/internal/camera/client/CameraProxy;->-wrap3(Ltas/internal/camera/client/CameraProxy;II)V

    .line 299
    :cond_0
    return-void
.end method

.method private onExtraState(II)V
    .locals 2
    .param p1, "state"    # I
    .param p2, "flag"    # I

    .prologue
    .line 286
    .local p0, "this":Ltas/internal/camera/client/CameraProxy$Dispatcher;, "Ltas/internal/camera/client/CameraProxy<TT;>.Dispatcher;"
    iget-object v1, p0, Ltas/internal/camera/client/CameraProxy$Dispatcher;->mProxy:Ljava/lang/ref/WeakReference;

    invoke-virtual {v1}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/camera/client/CameraProxy;

    .line 287
    .local v0, "proxy":Ltas/internal/camera/client/CameraProxy;
    if-eqz v0, :cond_0

    .line 288
    invoke-static {v0, p1, p2}, Ltas/internal/camera/client/CameraProxy;->-wrap4(Ltas/internal/camera/client/CameraProxy;II)V

    .line 285
    :cond_0
    return-void
.end method

.method private onMediaServerDied()V
    .locals 2

    .prologue
    .line 315
    .local p0, "this":Ltas/internal/camera/client/CameraProxy$Dispatcher;, "Ltas/internal/camera/client/CameraProxy<TT;>.Dispatcher;"
    iget-object v1, p0, Ltas/internal/camera/client/CameraProxy$Dispatcher;->mProxy:Ljava/lang/ref/WeakReference;

    invoke-virtual {v1}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/camera/client/CameraProxy;

    .line 316
    .local v0, "proxy":Ltas/internal/camera/client/CameraProxy;
    if-eqz v0, :cond_0

    .line 317
    invoke-static {v0}, Ltas/internal/camera/client/CameraProxy;->-wrap5(Ltas/internal/camera/client/CameraProxy;)V

    .line 314
    :cond_0
    return-void
.end method

.method private onRequestResult(I)V
    .locals 2
    .param p1, "result"    # I

    .prologue
    .line 293
    .local p0, "this":Ltas/internal/camera/client/CameraProxy$Dispatcher;, "Ltas/internal/camera/client/CameraProxy<TT;>.Dispatcher;"
    iget-object v1, p0, Ltas/internal/camera/client/CameraProxy$Dispatcher;->mProxy:Ljava/lang/ref/WeakReference;

    invoke-virtual {v1}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/camera/client/CameraProxy;

    .line 294
    .local v0, "proxy":Ltas/internal/camera/client/CameraProxy;
    if-eqz v0, :cond_0

    .line 295
    invoke-static {v0, p1}, Ltas/internal/camera/client/CameraProxy;->-wrap6(Ltas/internal/camera/client/CameraProxy;I)V

    .line 292
    :cond_0
    return-void
.end method


# virtual methods
.method public handleMessage(Landroid/os/Message;)V
    .locals 3
    .param p1, "msg"    # Landroid/os/Message;

    .prologue
    .local p0, "this":Ltas/internal/camera/client/CameraProxy$Dispatcher;, "Ltas/internal/camera/client/CameraProxy<TT;>.Dispatcher;"
    const/4 v1, 0x0

    const/4 v0, 0x1

    .line 322
    iget v2, p1, Landroid/os/Message;->what:I

    sparse-switch v2, :sswitch_data_0

    .line 321
    :goto_0
    return-void

    .line 324
    :sswitch_0
    iget v2, p1, Landroid/os/Message;->arg1:I

    if-ne v2, v0, :cond_0

    :goto_1
    invoke-direct {p0, v0}, Ltas/internal/camera/client/CameraProxy$Dispatcher;->onCableState(Z)V

    goto :goto_0

    :cond_0
    move v0, v1

    goto :goto_1

    .line 328
    :sswitch_1
    iget v2, p1, Landroid/os/Message;->arg1:I

    if-ne v2, v0, :cond_1

    :goto_2
    invoke-direct {p0, v0}, Ltas/internal/camera/client/CameraProxy$Dispatcher;->onCameraState(Z)V

    goto :goto_0

    :cond_1
    move v0, v1

    goto :goto_2

    .line 332
    :sswitch_2
    iget v0, p1, Landroid/os/Message;->arg1:I

    iget v1, p1, Landroid/os/Message;->arg2:I

    invoke-direct {p0, v0, v1}, Ltas/internal/camera/client/CameraProxy$Dispatcher;->onExtraState(II)V

    goto :goto_0

    .line 336
    :sswitch_3
    iget v0, p1, Landroid/os/Message;->arg1:I

    invoke-direct {p0, v0}, Ltas/internal/camera/client/CameraProxy$Dispatcher;->onRequestResult(I)V

    goto :goto_0

    .line 340
    :sswitch_4
    iget v0, p1, Landroid/os/Message;->arg1:I

    iget v1, p1, Landroid/os/Message;->arg2:I

    invoke-direct {p0, v0, v1}, Ltas/internal/camera/client/CameraProxy$Dispatcher;->onCommandResult(II)V

    goto :goto_0

    .line 344
    :sswitch_5
    iget-object v0, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v0, Ltas/internal/camera/client/ServerConnection$Holder;

    invoke-direct {p0, v0}, Ltas/internal/camera/client/CameraProxy$Dispatcher;->onCameraMessage(Ltas/internal/camera/client/ServerConnection$Holder;)V

    goto :goto_0

    .line 348
    :sswitch_6
    invoke-direct {p0}, Ltas/internal/camera/client/CameraProxy$Dispatcher;->onMediaServerDied()V

    goto :goto_0

    .line 322
    :sswitch_data_0
    .sparse-switch
        0x0 -> :sswitch_0
        0x1 -> :sswitch_1
        0xa -> :sswitch_2
        0xb -> :sswitch_3
        0xc -> :sswitch_6
        0x14 -> :sswitch_4
        0x15 -> :sswitch_5
    .end sparse-switch
.end method
