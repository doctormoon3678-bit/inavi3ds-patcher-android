.class Lcom/thinkware/sundo/ieve/IEVE$1;
.super Landroid/os/Handler;
.source "IEVE.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/thinkware/sundo/ieve/IEVE;->a()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/thinkware/sundo/ieve/IEVE;

.field private b:Z

.field private c:[B

.field private d:I

.field private e:D

.field private f:D

.field private g:D


# direct methods
.method constructor <init>(Lcom/thinkware/sundo/ieve/IEVE;)V
    .locals 2

    .prologue
    const/4 v1, 0x0

    .line 1
    iput-object p1, p0, Lcom/thinkware/sundo/ieve/IEVE$1;->a:Lcom/thinkware/sundo/ieve/IEVE;

    .line 415
    invoke-direct {p0}, Landroid/os/Handler;-><init>()V

    .line 416
    iput-boolean v1, p0, Lcom/thinkware/sundo/ieve/IEVE$1;->b:Z

    .line 417
    const/4 v0, 0x0

    iput-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE$1;->c:[B

    .line 418
    iput v1, p0, Lcom/thinkware/sundo/ieve/IEVE$1;->d:I

    .line 419
    invoke-virtual {p1}, Lcom/thinkware/sundo/ieve/IEVE;->getFreqCountIEVE()D

    move-result-wide v0

    iput-wide v0, p0, Lcom/thinkware/sundo/ieve/IEVE$1;->e:D

    .line 420
    const-wide/16 v0, 0x0

    iput-wide v0, p0, Lcom/thinkware/sundo/ieve/IEVE$1;->f:D

    .line 421
    const-wide/high16 v0, 0x402e000000000000L    # 15.0

    iput-wide v0, p0, Lcom/thinkware/sundo/ieve/IEVE$1;->g:D

    return-void
.end method

.method static synthetic a(Lcom/thinkware/sundo/ieve/IEVE$1;)Lcom/thinkware/sundo/ieve/IEVE;
    .locals 1

    .prologue
    .line 415
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE$1;->a:Lcom/thinkware/sundo/ieve/IEVE;

    return-object v0
.end method


# virtual methods
.method public handleMessage(Landroid/os/Message;)V
    .locals 28
    .param p1, "msg"    # Landroid/os/Message;

    .prologue
    .line 425
    invoke-super/range {p0 .. p1}, Landroid/os/Handler;->handleMessage(Landroid/os/Message;)V

    .line 426
    move-object/from16 v0, p1

    iget v4, v0, Landroid/os/Message;->what:I

    sparse-switch v4, :sswitch_data_0

    .line 595
    :cond_0
    :goto_0
    :sswitch_0
    return-void

    .line 428
    :sswitch_1
    move-object/from16 v0, p1

    iget v0, v0, Landroid/os/Message;->arg1:I

    move/from16 v18, v0

    .line 429
    .local v18, "status":I
    move-object/from16 v0, p0

    iget-object v4, v0, Lcom/thinkware/sundo/ieve/IEVE$1;->a:Lcom/thinkware/sundo/ieve/IEVE;

    move/from16 v0, v18

    invoke-static {v4, v0}, Lcom/thinkware/sundo/ieve/IEVE;->a(Lcom/thinkware/sundo/ieve/IEVE;I)V

    .line 430
    move-object/from16 v0, p0

    iget-object v4, v0, Lcom/thinkware/sundo/ieve/IEVE$1;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-virtual {v4}, Lcom/thinkware/sundo/ieve/IEVE;->checkDebugMode()V

    goto :goto_0

    .line 433
    .end local v18    # "status":I
    :sswitch_2
    move-object/from16 v0, p0

    iget-object v4, v0, Lcom/thinkware/sundo/ieve/IEVE$1;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v4}, Lcom/thinkware/sundo/ieve/IEVE;->a(Lcom/thinkware/sundo/ieve/IEVE;)Landroid/os/Handler;

    move-result-object v4

    new-instance v7, Lcom/thinkware/sundo/ieve/IEVE$1$1;

    move-object/from16 v0, p0

    invoke-direct {v7, v0}, Lcom/thinkware/sundo/ieve/IEVE$1$1;-><init>(Lcom/thinkware/sundo/ieve/IEVE$1;)V

    .line 438
    const-wide/16 v8, 0xbb8

    .line 433
    invoke-virtual {v4, v7, v8, v9}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    goto :goto_0

    .line 442
    :sswitch_3
    move-object/from16 v0, p0

    iget-object v4, v0, Lcom/thinkware/sundo/ieve/IEVE$1;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v4}, Lcom/thinkware/sundo/ieve/IEVE;->b(Lcom/thinkware/sundo/ieve/IEVE;)Lcom/thinkware/sundo/ieve/ieveTextView;

    move-result-object v4

    if-eqz v4, :cond_0

    move-object/from16 v0, p0

    iget-object v4, v0, Lcom/thinkware/sundo/ieve/IEVE$1;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v4}, Lcom/thinkware/sundo/ieve/IEVE;->b(Lcom/thinkware/sundo/ieve/IEVE;)Lcom/thinkware/sundo/ieve/ieveTextView;

    move-result-object v4

    invoke-virtual {v4}, Lcom/thinkware/sundo/ieve/ieveTextView;->invalidate()V

    goto :goto_0

    .line 446
    :sswitch_4
    const-string v7, "java_IEVE"

    move-object/from16 v0, p1

    iget-object v4, v0, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v4, Ljava/lang/String;

    invoke-static {v7, v4}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 447
    move-object/from16 v0, p0

    iget-object v4, v0, Lcom/thinkware/sundo/ieve/IEVE$1;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v4}, Lcom/thinkware/sundo/ieve/IEVE;->c(Lcom/thinkware/sundo/ieve/IEVE;)Landroid/os/Handler;

    move-result-object v4

    if-eqz v4, :cond_0

    move-object/from16 v0, p0

    iget-object v4, v0, Lcom/thinkware/sundo/ieve/IEVE$1;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v4}, Lcom/thinkware/sundo/ieve/IEVE;->c(Lcom/thinkware/sundo/ieve/IEVE;)Landroid/os/Handler;

    move-result-object v4

    move-object/from16 v0, p1

    invoke-virtual {v4, v0}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto :goto_0

    .line 451
    :sswitch_5
    const-string v7, "java_IEVE"

    move-object/from16 v0, p1

    iget-object v4, v0, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v4, Ljava/lang/String;

    invoke-static {v7, v4}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 452
    move-object/from16 v0, p0

    iget-object v4, v0, Lcom/thinkware/sundo/ieve/IEVE$1;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v4}, Lcom/thinkware/sundo/ieve/IEVE;->c(Lcom/thinkware/sundo/ieve/IEVE;)Landroid/os/Handler;

    move-result-object v4

    if-eqz v4, :cond_1

    move-object/from16 v0, p0

    iget-object v4, v0, Lcom/thinkware/sundo/ieve/IEVE$1;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v4}, Lcom/thinkware/sundo/ieve/IEVE;->c(Lcom/thinkware/sundo/ieve/IEVE;)Landroid/os/Handler;

    move-result-object v4

    move-object/from16 v0, p1

    invoke-virtual {v4, v0}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    .line 453
    :cond_1
    move-object/from16 v0, p0

    iget-object v4, v0, Lcom/thinkware/sundo/ieve/IEVE$1;->a:Lcom/thinkware/sundo/ieve/IEVE;

    const/4 v7, 0x0

    invoke-static {v4, v7}, Lcom/thinkware/sundo/ieve/IEVE;->b(Lcom/thinkware/sundo/ieve/IEVE;I)V

    goto/16 :goto_0

    .line 457
    :sswitch_6
    move-object/from16 v0, p0

    iget-object v4, v0, Lcom/thinkware/sundo/ieve/IEVE$1;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v4}, Lcom/thinkware/sundo/ieve/IEVE;->d(Lcom/thinkware/sundo/ieve/IEVE;)Lcom/thinkware/sundo/ieve/ieveCameraView;

    move-result-object v4

    if-eqz v4, :cond_0

    .line 458
    move-object/from16 v0, p0

    iget-object v4, v0, Lcom/thinkware/sundo/ieve/IEVE$1;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v4}, Lcom/thinkware/sundo/ieve/IEVE;->e(Lcom/thinkware/sundo/ieve/IEVE;)Z

    move-result v4

    if-nez v4, :cond_0

    .line 459
    move-object/from16 v0, p0

    iget-object v4, v0, Lcom/thinkware/sundo/ieve/IEVE$1;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-virtual {v4}, Lcom/thinkware/sundo/ieve/IEVE;->isEnableModeDR()Z

    move-result v4

    if-nez v4, :cond_2

    .line 460
    move-object/from16 v0, p0

    iget-object v4, v0, Lcom/thinkware/sundo/ieve/IEVE$1;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-virtual {v4}, Lcom/thinkware/sundo/ieve/IEVE;->isEnableModeRecogFCWS()Z

    move-result v4

    if-nez v4, :cond_2

    .line 461
    move-object/from16 v0, p0

    iget-object v4, v0, Lcom/thinkware/sundo/ieve/IEVE$1;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-virtual {v4}, Lcom/thinkware/sundo/ieve/IEVE;->isEnableModeRecogFVSA()Z

    move-result v4

    if-nez v4, :cond_2

    .line 462
    move-object/from16 v0, p0

    iget-object v4, v0, Lcom/thinkware/sundo/ieve/IEVE$1;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-virtual {v4}, Lcom/thinkware/sundo/ieve/IEVE;->isEnableModeRecogLDWS()Z

    move-result v4

    if-nez v4, :cond_2

    .line 463
    move-object/from16 v0, p0

    iget-object v4, v0, Lcom/thinkware/sundo/ieve/IEVE$1;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-virtual {v4}, Lcom/thinkware/sundo/ieve/IEVE;->isEnableModeRecogPCWS()Z

    move-result v4

    if-nez v4, :cond_2

    .line 464
    move-object/from16 v0, p0

    iget-object v4, v0, Lcom/thinkware/sundo/ieve/IEVE$1;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-virtual {v4}, Lcom/thinkware/sundo/ieve/IEVE;->isEnableModeRecogPLCA()Z

    move-result v4

    if-nez v4, :cond_2

    .line 465
    move-object/from16 v0, p0

    iget-object v4, v0, Lcom/thinkware/sundo/ieve/IEVE$1;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-virtual {v4}, Lcom/thinkware/sundo/ieve/IEVE;->isEnableModeRecogTLCA()Z

    move-result v4

    if-eqz v4, :cond_0

    .line 467
    :cond_2
    move-object/from16 v0, p0

    iget-boolean v4, v0, Lcom/thinkware/sundo/ieve/IEVE$1;->b:Z

    if-nez v4, :cond_9

    .line 468
    const/4 v4, 0x1

    move-object/from16 v0, p0

    iput-boolean v4, v0, Lcom/thinkware/sundo/ieve/IEVE$1;->b:Z

    .line 469
    move-object/from16 v0, p1

    iget-object v4, v0, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v4, [B

    move-object/from16 v0, p0

    iput-object v4, v0, Lcom/thinkware/sundo/ieve/IEVE$1;->c:[B

    .line 471
    move-object/from16 v0, p0

    iget-object v4, v0, Lcom/thinkware/sundo/ieve/IEVE$1;->a:Lcom/thinkware/sundo/ieve/IEVE;

    move-object/from16 v0, p0

    iget-object v7, v0, Lcom/thinkware/sundo/ieve/IEVE$1;->c:[B

    invoke-static {v4, v7}, Lcom/thinkware/sundo/ieve/IEVE;->a(Lcom/thinkware/sundo/ieve/IEVE;[B)I

    .line 474
    move-object/from16 v0, p0

    iget-object v4, v0, Lcom/thinkware/sundo/ieve/IEVE$1;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-virtual {v4}, Lcom/thinkware/sundo/ieve/IEVE;->isEnableModeRecogFCWS()Z

    move-result v4

    if-nez v4, :cond_3

    move-object/from16 v0, p0

    iget-object v4, v0, Lcom/thinkware/sundo/ieve/IEVE$1;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-virtual {v4}, Lcom/thinkware/sundo/ieve/IEVE;->isEnableModeRecogPCWS()Z

    move-result v4

    if-eqz v4, :cond_5

    .line 475
    :cond_3
    const/16 v17, 0x0

    .line 476
    .local v17, "holdadas":Z
    move-object/from16 v0, p0

    iget-object v4, v0, Lcom/thinkware/sundo/ieve/IEVE$1;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v4}, Lcom/thinkware/sundo/ieve/IEVE;->f(Lcom/thinkware/sundo/ieve/IEVE;)Lcom/thinkware/sundo/ieve/ieveNative;

    move-result-object v4

    invoke-virtual {v4}, Lcom/thinkware/sundo/ieve/ieveNative;->GetCarShadowGPS()Z

    move-result v14

    .line 477
    .local v14, "gpsshadow":Z
    move-object/from16 v0, p0

    iget-object v4, v0, Lcom/thinkware/sundo/ieve/IEVE$1;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v4}, Lcom/thinkware/sundo/ieve/IEVE;->f(Lcom/thinkware/sundo/ieve/IEVE;)Lcom/thinkware/sundo/ieve/ieveNative;

    move-result-object v4

    invoke-virtual {v4}, Lcom/thinkware/sundo/ieve/ieveNative;->GetCarStatusGPS()I

    move-result v15

    .line 478
    .local v15, "gpsstatus":I
    move-object/from16 v0, p0

    iget-object v4, v0, Lcom/thinkware/sundo/ieve/IEVE$1;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v4}, Lcom/thinkware/sundo/ieve/IEVE;->g(Lcom/thinkware/sundo/ieve/IEVE;)I

    move-result v4

    if-eqz v4, :cond_8

    .line 479
    if-eqz v14, :cond_4

    const/4 v4, 0x2

    if-eq v15, v4, :cond_4

    const/4 v4, 0x3

    if-eq v15, v4, :cond_4

    const/16 v17, 0x1

    .line 484
    :cond_4
    :goto_1
    move-object/from16 v0, p0

    iget-object v4, v0, Lcom/thinkware/sundo/ieve/IEVE$1;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v4}, Lcom/thinkware/sundo/ieve/IEVE;->h(Lcom/thinkware/sundo/ieve/IEVE;)Lcom/stradvision/pdvdtest/SV_ADAS;

    move-result-object v4

    move/from16 v0, v17

    invoke-virtual {v4, v0}, Lcom/stradvision/pdvdtest/SV_ADAS;->HoldADAS(Z)V

    .line 485
    move-object/from16 v0, p0

    iget-object v4, v0, Lcom/thinkware/sundo/ieve/IEVE$1;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v4}, Lcom/thinkware/sundo/ieve/IEVE;->h(Lcom/thinkware/sundo/ieve/IEVE;)Lcom/stradvision/pdvdtest/SV_ADAS;

    move-result-object v4

    move-object/from16 v0, p0

    iget-object v7, v0, Lcom/thinkware/sundo/ieve/IEVE$1;->c:[B

    invoke-virtual {v4, v7}, Lcom/stradvision/pdvdtest/SV_ADAS;->PDVDLD([B)V

    .line 489
    .end local v14    # "gpsshadow":Z
    .end local v15    # "gpsstatus":I
    .end local v17    # "holdadas":Z
    :cond_5
    move-object/from16 v0, p0

    iget v4, v0, Lcom/thinkware/sundo/ieve/IEVE$1;->d:I

    rem-int/lit16 v4, v4, 0x96

    if-nez v4, :cond_7

    .line 490
    move-object/from16 v0, p0

    iget-object v4, v0, Lcom/thinkware/sundo/ieve/IEVE$1;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-virtual {v4}, Lcom/thinkware/sundo/ieve/IEVE;->getFreqCountIEVE()D

    move-result-wide v20

    .line 491
    .local v20, "uptime_msec_base":D
    move-object/from16 v0, p0

    iget-wide v8, v0, Lcom/thinkware/sundo/ieve/IEVE$1;->f:D

    sub-double v22, v20, v8

    .line 492
    .local v22, "uptime_msec_period":D
    const-wide/16 v8, 0x0

    cmpl-double v4, v22, v8

    if-lez v4, :cond_6

    const-wide v8, 0x408f400000000000L    # 1000.0

    move-object/from16 v0, p0

    iget v4, v0, Lcom/thinkware/sundo/ieve/IEVE$1;->d:I

    int-to-double v10, v4

    mul-double/2addr v8, v10

    div-double v8, v8, v22

    move-object/from16 v0, p0

    iput-wide v8, v0, Lcom/thinkware/sundo/ieve/IEVE$1;->g:D

    .line 493
    :cond_6
    move-wide/from16 v0, v20

    move-object/from16 v2, p0

    iput-wide v0, v2, Lcom/thinkware/sundo/ieve/IEVE$1;->f:D

    .line 494
    const/4 v4, 0x0

    move-object/from16 v0, p0

    iput v4, v0, Lcom/thinkware/sundo/ieve/IEVE$1;->d:I

    .line 495
    const-string v4, "java_IEVE"

    const-string v7, "PERFORM[FPS:%.1f]"

    const/4 v8, 0x1

    new-array v8, v8, [Ljava/lang/Object;

    const/4 v9, 0x0

    move-object/from16 v0, p0

    iget-wide v10, v0, Lcom/thinkware/sundo/ieve/IEVE$1;->g:D

    invoke-static {v10, v11}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v10

    aput-object v10, v8, v9

    invoke-static {v7, v8}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v7

    invoke-static {v4, v7}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 497
    .end local v20    # "uptime_msec_base":D
    .end local v22    # "uptime_msec_period":D
    :cond_7
    move-object/from16 v0, p0

    iget v4, v0, Lcom/thinkware/sundo/ieve/IEVE$1;->d:I

    add-int/lit8 v4, v4, 0x1

    move-object/from16 v0, p0

    iput v4, v0, Lcom/thinkware/sundo/ieve/IEVE$1;->d:I

    .line 498
    move-object/from16 v0, p0

    iget-object v4, v0, Lcom/thinkware/sundo/ieve/IEVE$1;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-virtual {v4}, Lcom/thinkware/sundo/ieve/IEVE;->getFreqCountIEVE()D

    move-result-wide v8

    move-object/from16 v0, p0

    iput-wide v8, v0, Lcom/thinkware/sundo/ieve/IEVE$1;->e:D

    .line 500
    const/4 v4, 0x0

    move-object/from16 v0, p0

    iput-boolean v4, v0, Lcom/thinkware/sundo/ieve/IEVE$1;->b:Z

    goto/16 :goto_0

    .line 482
    .restart local v14    # "gpsshadow":Z
    .restart local v15    # "gpsstatus":I
    .restart local v17    # "holdadas":Z
    :cond_8
    if-eqz v14, :cond_4

    const/16 v17, 0x1

    goto/16 :goto_1

    .line 502
    .end local v14    # "gpsshadow":Z
    .end local v15    # "gpsstatus":I
    .end local v17    # "holdadas":Z
    :cond_9
    move-object/from16 v0, p0

    iget-object v4, v0, Lcom/thinkware/sundo/ieve/IEVE$1;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v4}, Lcom/thinkware/sundo/ieve/IEVE;->b(Lcom/thinkware/sundo/ieve/IEVE;)Lcom/thinkware/sundo/ieve/ieveTextView;

    move-result-object v4

    if-eqz v4, :cond_0

    .line 503
    move-object/from16 v0, p0

    iget-object v4, v0, Lcom/thinkware/sundo/ieve/IEVE$1;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-virtual {v4}, Lcom/thinkware/sundo/ieve/IEVE;->getFreqCountIEVE()D

    move-result-wide v8

    move-object/from16 v0, p0

    iget-wide v10, v0, Lcom/thinkware/sundo/ieve/IEVE$1;->e:D

    sub-double v24, v8, v10

    .line 504
    .local v24, "uptime_msec_proc":D
    const-string v4, "Passed while running perform[%.1fsec]"

    const/4 v7, 0x1

    new-array v7, v7, [Ljava/lang/Object;

    const/4 v8, 0x0

    invoke-static/range {v24 .. v25}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v9

    aput-object v9, v7, v8

    invoke-static {v4, v7}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v6

    .line 505
    .local v6, "dbgtxt":Ljava/lang/String;
    const-string v4, "java_IEVE"

    invoke-static {v4, v6}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 506
    move-object/from16 v0, p0

    iget-object v4, v0, Lcom/thinkware/sundo/ieve/IEVE$1;->a:Lcom/thinkware/sundo/ieve/IEVE;

    const/16 v5, 0x711

    const/high16 v7, 0x44000000    # 512.0f

    const/high16 v8, 0x42480000    # 50.0f

    const/high16 v9, 0x41900000    # 18.0f

    const/high16 v10, -0x10000

    invoke-virtual/range {v4 .. v10}, Lcom/thinkware/sundo/ieve/IEVE;->DebugPrint(ILjava/lang/String;FFFI)V

    goto/16 :goto_0

    .line 512
    .end local v6    # "dbgtxt":Ljava/lang/String;
    .end local v24    # "uptime_msec_proc":D
    :sswitch_7
    const-string v4, "java_IEVE"

    const-string v7, "IEVE_HMSG_PREVIEW_STOP, ResetADAS"

    invoke-static {v4, v7}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 513
    move-object/from16 v0, p0

    iget-object v4, v0, Lcom/thinkware/sundo/ieve/IEVE$1;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v4}, Lcom/thinkware/sundo/ieve/IEVE;->f(Lcom/thinkware/sundo/ieve/IEVE;)Lcom/thinkware/sundo/ieve/ieveNative;

    move-result-object v4

    invoke-virtual {v4}, Lcom/thinkware/sundo/ieve/ieveNative;->ResetADAS()V

    goto/16 :goto_0

    .line 527
    :sswitch_8
    move-object/from16 v0, p0

    iget-object v4, v0, Lcom/thinkware/sundo/ieve/IEVE$1;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v4}, Lcom/thinkware/sundo/ieve/IEVE;->b(Lcom/thinkware/sundo/ieve/IEVE;)Lcom/thinkware/sundo/ieve/ieveTextView;

    move-result-object v4

    if-eqz v4, :cond_0

    .line 528
    move-object/from16 v0, p1

    iget v5, v0, Landroid/os/Message;->arg1:I

    .line 529
    .local v5, "intvalue":I
    const/16 v4, 0xfa0

    if-ne v5, v4, :cond_0

    .line 530
    move-object/from16 v0, p1

    iget-object v6, v0, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v6, Ljava/lang/String;

    .line 531
    .restart local v6    # "dbgtxt":Ljava/lang/String;
    move-object/from16 v0, p0

    iget-object v4, v0, Lcom/thinkware/sundo/ieve/IEVE$1;->a:Lcom/thinkware/sundo/ieve/IEVE;

    const/4 v7, 0x0

    const/high16 v8, 0x43870000    # 270.0f

    const/high16 v9, 0x41f00000    # 30.0f

    const/high16 v10, -0x10000

    invoke-virtual/range {v4 .. v10}, Lcom/thinkware/sundo/ieve/IEVE;->DebugPrint(ILjava/lang/String;FFFI)V

    goto/16 :goto_0

    .line 537
    .end local v5    # "intvalue":I
    .end local v6    # "dbgtxt":Ljava/lang/String;
    :sswitch_9
    move-object/from16 v0, p1

    iget v4, v0, Landroid/os/Message;->arg1:I

    if-eqz v4, :cond_b

    .line 538
    move-object/from16 v0, p0

    iget-object v4, v0, Lcom/thinkware/sundo/ieve/IEVE$1;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v4}, Lcom/thinkware/sundo/ieve/IEVE;->i(Lcom/thinkware/sundo/ieve/IEVE;)Lcom/thinkware/sundo/ieve/ieveDebugImageView;

    move-result-object v4

    if-nez v4, :cond_a

    move-object/from16 v0, p0

    iget-object v4, v0, Lcom/thinkware/sundo/ieve/IEVE$1;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v4}, Lcom/thinkware/sundo/ieve/IEVE;->j(Lcom/thinkware/sundo/ieve/IEVE;)V

    .line 539
    :cond_a
    move-object/from16 v0, p1

    iget v4, v0, Landroid/os/Message;->arg1:I

    const v7, 0xffff

    and-int v27, v4, v7

    .line 540
    .local v27, "width":I
    move-object/from16 v0, p1

    iget v4, v0, Landroid/os/Message;->arg1:I

    shr-int/lit8 v4, v4, 0x10

    const v7, 0xffff

    and-int v16, v4, v7

    .line 541
    .local v16, "height":I
    move-object/from16 v0, p0

    iget-object v4, v0, Lcom/thinkware/sundo/ieve/IEVE$1;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v4}, Lcom/thinkware/sundo/ieve/IEVE;->i(Lcom/thinkware/sundo/ieve/IEVE;)Lcom/thinkware/sundo/ieve/ieveDebugImageView;

    move-result-object v7

    move-object/from16 v0, p1

    iget-object v4, v0, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v4, [I

    move/from16 v0, v27

    move/from16 v1, v16

    invoke-virtual {v7, v0, v1, v4}, Lcom/thinkware/sundo/ieve/ieveDebugImageView;->setBitmap(II[I)V

    goto/16 :goto_0

    .line 544
    .end local v16    # "height":I
    .end local v27    # "width":I
    :cond_b
    move-object/from16 v0, p0

    iget-object v4, v0, Lcom/thinkware/sundo/ieve/IEVE$1;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v4}, Lcom/thinkware/sundo/ieve/IEVE;->k(Lcom/thinkware/sundo/ieve/IEVE;)V

    goto/16 :goto_0

    .line 549
    :sswitch_a
    move-object/from16 v0, p1

    iget v5, v0, Landroid/os/Message;->arg1:I

    .line 550
    .restart local v5    # "intvalue":I
    move-object/from16 v0, p1

    iget v0, v0, Landroid/os/Message;->arg2:I

    move/from16 v26, v0

    .line 551
    .local v26, "value":I
    sparse-switch v5, :sswitch_data_1

    goto/16 :goto_0

    .line 560
    :sswitch_b
    const/4 v4, 0x1

    move/from16 v0, v26

    if-ne v0, v4, :cond_c

    move-object/from16 v0, p0

    iget-object v7, v0, Lcom/thinkware/sundo/ieve/IEVE$1;->a:Lcom/thinkware/sundo/ieve/IEVE;

    const/4 v9, -0x1

    const/4 v10, 0x1

    const/4 v11, 0x1

    const/4 v12, 0x0

    move v8, v5

    invoke-static/range {v7 .. v12}, Lcom/thinkware/sundo/ieve/IEVE;->a(Lcom/thinkware/sundo/ieve/IEVE;IIZZZ)V

    goto/16 :goto_0

    .line 561
    :cond_c
    move-object/from16 v0, p0

    iget-object v4, v0, Lcom/thinkware/sundo/ieve/IEVE$1;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v4, v5}, Lcom/thinkware/sundo/ieve/IEVE;->c(Lcom/thinkware/sundo/ieve/IEVE;I)V

    goto/16 :goto_0

    .line 568
    :sswitch_c
    const/4 v4, 0x1

    move/from16 v0, v26

    if-ne v0, v4, :cond_e

    .line 569
    move-object/from16 v0, p0

    iget-object v4, v0, Lcom/thinkware/sundo/ieve/IEVE$1;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v4}, Lcom/thinkware/sundo/ieve/IEVE;->l(Lcom/thinkware/sundo/ieve/IEVE;)I

    move-result v4

    const/16 v7, 0xc8

    if-lt v4, v7, :cond_d

    move-object/from16 v0, p0

    iget-object v4, v0, Lcom/thinkware/sundo/ieve/IEVE$1;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v4}, Lcom/thinkware/sundo/ieve/IEVE;->l(Lcom/thinkware/sundo/ieve/IEVE;)I

    move-result v4

    const/16 v7, 0x2bc

    if-ge v4, v7, :cond_d

    .line 570
    move-object/from16 v0, p0

    iget-object v7, v0, Lcom/thinkware/sundo/ieve/IEVE$1;->a:Lcom/thinkware/sundo/ieve/IEVE;

    const/4 v9, -0x1

    const/4 v10, 0x1

    const/4 v11, 0x1

    const/4 v12, 0x0

    move-object/from16 v0, p0

    iget-object v4, v0, Lcom/thinkware/sundo/ieve/IEVE$1;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v4}, Lcom/thinkware/sundo/ieve/IEVE;->l(Lcom/thinkware/sundo/ieve/IEVE;)I

    move-result v4

    int-to-float v4, v4

    const/high16 v8, 0x447a0000    # 1000.0f

    div-float v13, v4, v8

    move v8, v5

    invoke-static/range {v7 .. v13}, Lcom/thinkware/sundo/ieve/IEVE;->a(Lcom/thinkware/sundo/ieve/IEVE;IIZZZF)V

    goto/16 :goto_0

    .line 573
    :cond_d
    move-object/from16 v0, p0

    iget-object v7, v0, Lcom/thinkware/sundo/ieve/IEVE$1;->a:Lcom/thinkware/sundo/ieve/IEVE;

    const/4 v9, -0x1

    const/4 v10, 0x1

    const/4 v11, 0x1

    const/4 v12, 0x0

    move v8, v5

    invoke-static/range {v7 .. v12}, Lcom/thinkware/sundo/ieve/IEVE;->a(Lcom/thinkware/sundo/ieve/IEVE;IIZZZ)V

    goto/16 :goto_0

    .line 576
    :cond_e
    move-object/from16 v0, p0

    iget-object v4, v0, Lcom/thinkware/sundo/ieve/IEVE$1;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v4, v5}, Lcom/thinkware/sundo/ieve/IEVE;->c(Lcom/thinkware/sundo/ieve/IEVE;I)V

    goto/16 :goto_0

    .line 579
    :sswitch_d
    const/4 v4, 0x1

    move/from16 v0, v26

    if-ne v0, v4, :cond_0

    .line 580
    move-object/from16 v0, p0

    iget-object v4, v0, Lcom/thinkware/sundo/ieve/IEVE$1;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v4}, Lcom/thinkware/sundo/ieve/IEVE;->c(Lcom/thinkware/sundo/ieve/IEVE;)Landroid/os/Handler;

    move-result-object v4

    if-eqz v4, :cond_f

    .line 581
    const-string v4, "Found auto vanishing point"

    const/4 v7, 0x0

    new-array v7, v7, [Ljava/lang/Object;

    invoke-static {v4, v7}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v19

    .line 582
    .local v19, "text":Ljava/lang/String;
    move-object/from16 v0, p0

    iget-object v4, v0, Lcom/thinkware/sundo/ieve/IEVE$1;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v4}, Lcom/thinkware/sundo/ieve/IEVE;->c(Lcom/thinkware/sundo/ieve/IEVE;)Landroid/os/Handler;

    move-result-object v4

    move-object/from16 v0, p0

    iget-object v7, v0, Lcom/thinkware/sundo/ieve/IEVE$1;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v7}, Lcom/thinkware/sundo/ieve/IEVE;->c(Lcom/thinkware/sundo/ieve/IEVE;)Landroid/os/Handler;

    move-result-object v7

    const/16 v8, 0x457

    move-object/from16 v0, p1

    iget v9, v0, Landroid/os/Message;->arg1:I

    move-object/from16 v0, p1

    iget v10, v0, Landroid/os/Message;->arg2:I

    move-object/from16 v0, v19

    invoke-static {v7, v8, v9, v10, v0}, Landroid/os/Message;->obtain(Landroid/os/Handler;IIILjava/lang/Object;)Landroid/os/Message;

    move-result-object v7

    invoke-virtual {v4, v7}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    .line 585
    .end local v19    # "text":Ljava/lang/String;
    :cond_f
    const-string v4, "java_IEVE"

    const-string v7, "VPToSV[%d * 4,%d * 3]"

    const/4 v8, 0x2

    new-array v8, v8, [Ljava/lang/Object;

    const/4 v9, 0x0

    move-object/from16 v0, p0

    iget-object v10, v0, Lcom/thinkware/sundo/ieve/IEVE$1;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v10}, Lcom/thinkware/sundo/ieve/IEVE;->f(Lcom/thinkware/sundo/ieve/IEVE;)Lcom/thinkware/sundo/ieve/ieveNative;

    move-result-object v10

    invoke-virtual {v10}, Lcom/thinkware/sundo/ieve/ieveNative;->GetVanishingPointXFromImage()I

    move-result v10

    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v10

    aput-object v10, v8, v9

    const/4 v9, 0x1

    move-object/from16 v0, p0

    iget-object v10, v0, Lcom/thinkware/sundo/ieve/IEVE$1;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v10}, Lcom/thinkware/sundo/ieve/IEVE;->f(Lcom/thinkware/sundo/ieve/IEVE;)Lcom/thinkware/sundo/ieve/ieveNative;

    move-result-object v10

    invoke-virtual {v10}, Lcom/thinkware/sundo/ieve/ieveNative;->GetVanishingPointYFromImage()I

    move-result v10

    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v10

    aput-object v10, v8, v9

    invoke-static {v7, v8}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v7

    invoke-static {v4, v7}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 586
    move-object/from16 v0, p0

    iget-object v4, v0, Lcom/thinkware/sundo/ieve/IEVE$1;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v4}, Lcom/thinkware/sundo/ieve/IEVE;->h(Lcom/thinkware/sundo/ieve/IEVE;)Lcom/stradvision/pdvdtest/SV_ADAS;

    move-result-object v4

    move-object/from16 v0, p0

    iget-object v7, v0, Lcom/thinkware/sundo/ieve/IEVE$1;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v7}, Lcom/thinkware/sundo/ieve/IEVE;->f(Lcom/thinkware/sundo/ieve/IEVE;)Lcom/thinkware/sundo/ieve/ieveNative;

    move-result-object v7

    invoke-virtual {v7}, Lcom/thinkware/sundo/ieve/ieveNative;->GetVanishingPointXFromImage()I

    move-result v7

    mul-int/lit8 v7, v7, 0x4

    move-object/from16 v0, p0

    iget-object v8, v0, Lcom/thinkware/sundo/ieve/IEVE$1;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v8}, Lcom/thinkware/sundo/ieve/IEVE;->f(Lcom/thinkware/sundo/ieve/IEVE;)Lcom/thinkware/sundo/ieve/ieveNative;

    move-result-object v8

    invoke-virtual {v8}, Lcom/thinkware/sundo/ieve/ieveNative;->GetVanishingPointYFromImage()I

    move-result v8

    mul-int/lit8 v8, v8, 0x3

    invoke-virtual {v4, v7, v8}, Lcom/stradvision/pdvdtest/SV_ADAS;->SetVanishingPoint(II)V

    goto/16 :goto_0

    .line 426
    nop

    :sswitch_data_0
    .sparse-switch
        0x3ed -> :sswitch_5
        0x3f2 -> :sswitch_6
        0x3fc -> :sswitch_0
        0x44b -> :sswitch_7
        0x4af -> :sswitch_4
        0x776 -> :sswitch_2
        0x7ce -> :sswitch_1
        0x7cf -> :sswitch_3
        0x125c -> :sswitch_8
        0x125d -> :sswitch_9
        0x125e -> :sswitch_a
    .end sparse-switch

    .line 551
    :sswitch_data_1
    .sparse-switch
        0x0 -> :sswitch_b
        0x1 -> :sswitch_b
        0x2 -> :sswitch_b
        0x3 -> :sswitch_b
        0x4 -> :sswitch_c
        0x5 -> :sswitch_c
        0x6 -> :sswitch_b
        0x7 -> :sswitch_c
        0x8 -> :sswitch_c
        0x9 -> :sswitch_b
        0xa -> :sswitch_b
        0x6011 -> :sswitch_d
    .end sparse-switch
.end method
