.class public Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/StradvisionViewAR;
.super Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/GuideView;
.source "StradvisionViewAR.java"


# static fields
.field private static final ZOOM_MODE_WIDTH:I = 0x2b6


# instance fields
.field private mIsDebug:Z

.field private mIsFullMode:Z

.field private paint_fcw:Landroid/graphics/Paint;

.field private paint_fcw_line:Landroid/graphics/Paint;

.field private paint_fps:Landroid/graphics/Paint;

.field private paint_ld:Landroid/graphics/Paint;

.field private paint_pd:Landroid/graphics/Paint;

.field private paint_vd:Landroid/graphics/Paint;


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 1
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "attrs"    # Landroid/util/AttributeSet;

    .prologue
    .line 40
    const/4 v0, 0x0

    invoke-direct {p0, p1, p2, v0}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/StradvisionViewAR;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    .line 41
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .locals 5
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "attrs"    # Landroid/util/AttributeSet;
    .param p3, "defStyle"    # I

    .prologue
    const/high16 v4, 0x40a00000    # 5.0f

    const/4 v1, 0x1

    const/4 v3, 0x0

    const/16 v2, 0xff

    .line 44
    invoke-direct {p0, p1, p2, p3}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/GuideView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    .line 21
    new-instance v0, Landroid/graphics/Paint;

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/StradvisionViewAR;->paint_pd:Landroid/graphics/Paint;

    .line 22
    new-instance v0, Landroid/graphics/Paint;

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/StradvisionViewAR;->paint_vd:Landroid/graphics/Paint;

    .line 23
    new-instance v0, Landroid/graphics/Paint;

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/StradvisionViewAR;->paint_fcw:Landroid/graphics/Paint;

    .line 24
    new-instance v0, Landroid/graphics/Paint;

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/StradvisionViewAR;->paint_ld:Landroid/graphics/Paint;

    .line 25
    new-instance v0, Landroid/graphics/Paint;

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/StradvisionViewAR;->paint_fcw_line:Landroid/graphics/Paint;

    .line 26
    new-instance v0, Landroid/graphics/Paint;

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/StradvisionViewAR;->paint_fps:Landroid/graphics/Paint;

    .line 28
    iput-boolean v3, p0, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/StradvisionViewAR;->mIsDebug:Z

    .line 29
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/StradvisionViewAR;->mIsFullMode:Z

    .line 46
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/StradvisionViewAR;->paint_ld:Landroid/graphics/Paint;

    invoke-virtual {v0, v2, v3, v2, v2}, Landroid/graphics/Paint;->setARGB(IIII)V

    .line 47
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/StradvisionViewAR;->paint_ld:Landroid/graphics/Paint;

    sget-object v1, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 48
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/StradvisionViewAR;->paint_ld:Landroid/graphics/Paint;

    invoke-virtual {v0, v4}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 50
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/StradvisionViewAR;->paint_fcw_line:Landroid/graphics/Paint;

    invoke-virtual {v0, v2, v3, v3, v2}, Landroid/graphics/Paint;->setARGB(IIII)V

    .line 51
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/StradvisionViewAR;->paint_fcw_line:Landroid/graphics/Paint;

    sget-object v1, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 52
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/StradvisionViewAR;->paint_fcw_line:Landroid/graphics/Paint;

    invoke-virtual {v0, v4}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 54
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/StradvisionViewAR;->paint_fcw:Landroid/graphics/Paint;

    sget-object v1, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 55
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/StradvisionViewAR;->paint_fcw:Landroid/graphics/Paint;

    const/high16 v1, 0x41200000    # 10.0f

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 56
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/StradvisionViewAR;->paint_fcw:Landroid/graphics/Paint;

    const/16 v1, 0x64

    invoke-static {v1, v2, v3, v3}, Landroid/graphics/Color;->argb(IIII)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setColor(I)V

    .line 58
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/StradvisionViewAR;->paint_pd:Landroid/graphics/Paint;

    invoke-virtual {v0, v2, v2, v2, v3}, Landroid/graphics/Paint;->setARGB(IIII)V

    .line 59
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/StradvisionViewAR;->paint_pd:Landroid/graphics/Paint;

    sget-object v1, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 60
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/StradvisionViewAR;->paint_pd:Landroid/graphics/Paint;

    invoke-virtual {v0, v4}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 62
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/StradvisionViewAR;->paint_vd:Landroid/graphics/Paint;

    invoke-virtual {v0, v2, v3, v2, v3}, Landroid/graphics/Paint;->setARGB(IIII)V

    .line 63
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/StradvisionViewAR;->paint_vd:Landroid/graphics/Paint;

    sget-object v1, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 64
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/StradvisionViewAR;->paint_vd:Landroid/graphics/Paint;

    invoke-virtual {v0, v4}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 66
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/StradvisionViewAR;->paint_fps:Landroid/graphics/Paint;

    const/4 v1, -0x1

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setColor(I)V

    .line 67
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/StradvisionViewAR;->paint_fps:Landroid/graphics/Paint;

    sget-object v1, Landroid/graphics/Paint$Align;->LEFT:Landroid/graphics/Paint$Align;

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setTextAlign(Landroid/graphics/Paint$Align;)V

    .line 68
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/StradvisionViewAR;->paint_fps:Landroid/graphics/Paint;

    const/high16 v1, 0x41b00000    # 22.0f

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 70
    invoke-direct {p0}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/StradvisionViewAR;->checkDebug()V

    .line 71
    return-void
.end method

.method private checkDebug()V
    .locals 5

    .prologue
    const/4 v4, 0x1

    .line 74
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    sget-object v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->SD_EXT_STORAGE_PATH:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "/inavi3d/res/debug/drawfcws.dat"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .line 76
    .local v1, "strDebugPath":Ljava/lang/String;
    new-instance v0, Ljava/io/File;

    invoke-direct {v0, v1}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 77
    .local v0, "files":Ljava/io/File;
    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v2

    if-ne v2, v4, :cond_0

    .line 78
    invoke-virtual {p0, v4}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/StradvisionViewAR;->setStradVisionViewDebug(Z)V

    .line 82
    :goto_0
    return-void

    .line 80
    :cond_0
    const/4 v2, 0x0

    invoke-virtual {p0, v2}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/StradvisionViewAR;->setStradVisionViewDebug(Z)V

    goto :goto_0
.end method


# virtual methods
.method public isStradVisionViewDebug()Z
    .locals 1

    .prologue
    .line 137
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/StradvisionViewAR;->mIsDebug:Z

    return v0
.end method

.method public isStradVisionViewFullMode()Z
    .locals 1

    .prologue
    .line 145
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/StradvisionViewAR;->mIsFullMode:Z

    return v0
.end method

.method protected onDraw(Landroid/graphics/Canvas;)V
    .locals 9
    .param p1, "canvas"    # Landroid/graphics/Canvas;

    .prologue
    const/4 v5, 0x1

    .line 99
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v1

    invoke-virtual {v1}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->is_support_scale()Z

    move-result v1

    if-eqz v1, :cond_0

    .line 100
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INaviScaleManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INaviScaleManager;

    move-result-object v1

    invoke-virtual {v1, p1}, Lcom/thinkware/sundo/inavi3d/INaviScaleManager;->setCanvasFilter(Landroid/graphics/Canvas;)V

    .line 102
    :cond_0
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v1

    invoke-virtual {v1}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->GetIEVE()Lcom/thinkware/sundo/ieve/IEVE;

    move-result-object v6

    .line 103
    .local v6, "ieve":Lcom/thinkware/sundo/ieve/IEVE;
    if-eqz v6, :cond_2

    invoke-virtual {v6}, Lcom/thinkware/sundo/ieve/IEVE;->isInitialized()Z

    move-result v1

    if-ne v1, v5, :cond_2

    .line 104
    invoke-virtual {v6}, Lcom/thinkware/sundo/ieve/IEVE;->getStradVision()Lcom/stradvision/pdvdtest/SV_ADAS;

    move-result-object v0

    .line 106
    .local v0, "sv_adas":Lcom/stradvision/pdvdtest/SV_ADAS;
    if-eqz v0, :cond_2

    .line 107
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/StradvisionViewAR;->getWidth()I

    move-result v8

    .line 108
    .local v8, "scr_w":I
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/StradvisionViewAR;->getHeight()I

    move-result v7

    .line 109
    .local v7, "scr_h":I
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/StradvisionViewAR;->isStradVisionViewFullMode()Z

    move-result v1

    if-nez v1, :cond_1

    .line 110
    const/16 v8, 0x2b6

    .line 112
    :cond_1
    int-to-float v1, v8

    iget v4, v6, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_IMAGESIZE_HD720_WIDTH:I

    int-to-float v4, v4

    div-float v2, v1, v4

    .line 113
    .local v2, "scale_ratio_w":F
    int-to-float v1, v7

    iget v4, v6, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_IMAGESIZE_HD720_HEIGHT:I

    int-to-float v4, v4

    div-float v3, v1, v4

    .line 116
    .local v3, "scale_ratio_h":F
    invoke-virtual {v0, p1, v2, v3}, Lcom/stradvision/pdvdtest/SV_ADAS;->DrawGUIADAS(Landroid/graphics/Canvas;FF)V

    .line 120
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/StradvisionViewAR;->isStradVisionViewDebug()Z

    move-result v1

    if-ne v1, v5, :cond_2

    .line 123
    invoke-virtual {v0, p1, v2, v3}, Lcom/stradvision/pdvdtest/SV_ADAS;->DebugDrawResultTTC(Landroid/graphics/Canvas;FF)V

    .line 124
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/StradvisionViewAR;->paint_pd:Landroid/graphics/Paint;

    iget-object v5, p0, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/StradvisionViewAR;->paint_vd:Landroid/graphics/Paint;

    move-object v1, p1

    invoke-virtual/range {v0 .. v5}, Lcom/stradvision/pdvdtest/SV_ADAS;->DebugDrawResultPDVD(Landroid/graphics/Canvas;FFLandroid/graphics/Paint;Landroid/graphics/Paint;)V

    .line 125
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/StradvisionViewAR;->paint_fcw_line:Landroid/graphics/Paint;

    iget-object v5, p0, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/StradvisionViewAR;->paint_ld:Landroid/graphics/Paint;

    move-object v1, p1

    invoke-virtual/range {v0 .. v5}, Lcom/stradvision/pdvdtest/SV_ADAS;->DebugDrawResultLD(Landroid/graphics/Canvas;FFLandroid/graphics/Paint;Landroid/graphics/Paint;)V

    .line 130
    .end local v0    # "sv_adas":Lcom/stradvision/pdvdtest/SV_ADAS;
    .end local v2    # "scale_ratio_w":F
    .end local v3    # "scale_ratio_h":F
    .end local v7    # "scr_h":I
    .end local v8    # "scr_w":I
    :cond_2
    return-void
.end method

.method public recycleBitmap()V
    .locals 0

    .prologue
    .line 94
    return-void
.end method

.method public setStradVisionViewDebug(Z)V
    .locals 0
    .param p1, "isDebug"    # Z

    .prologue
    .line 133
    iput-boolean p1, p0, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/StradvisionViewAR;->mIsDebug:Z

    .line 134
    return-void
.end method

.method public setStradVisionViewFullMode(Z)V
    .locals 0
    .param p1, "isFullMode"    # Z

    .prologue
    .line 141
    iput-boolean p1, p0, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/StradvisionViewAR;->mIsFullMode:Z

    .line 142
    return-void
.end method
