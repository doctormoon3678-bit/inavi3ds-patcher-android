.class public interface abstract Ltas/internal/ipc/util/ServiceConnectionAbstract$Callback;
.super Ljava/lang/Object;
.source "ServiceConnectionAbstract.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltas/internal/ipc/util/ServiceConnectionAbstract;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "Callback"
.end annotation


# virtual methods
.method public abstract onConnected()V
.end method

.method public abstract onDeath()V
.end method

.method public abstract onDisconnected()V
.end method
