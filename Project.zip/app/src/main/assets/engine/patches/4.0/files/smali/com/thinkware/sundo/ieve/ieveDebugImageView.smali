.class public Lcom/thinkware/sundo/ieve/ieveDebugImageView;
.super Landroid/view/View;
.source "ieveDebugImageView.java"


# static fields
.field private static final a:Ljava/lang/String;


# instance fields
.field private b:Landroid/content/Context;

.field private c:Landroid/graphics/Paint;

.field private d:Landroid/graphics/Rect;

.field private e:Landroid/graphics/PointF;

.field public mBmpImg:Landroid/graphics/Bitmap;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .prologue
    .line 15
    const-class v0, Lcom/thinkware/sundo/ieve/ieveDebugImageView;

    invoke-virtual {v0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveDebugImageView;->a:Ljava/lang/String;

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/graphics/Rect;)V
    .locals 4
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "sizescreen"    # Landroid/graphics/Rect;

    .prologue
    const/4 v0, 0x0

    .line 28
    invoke-direct {p0, p1}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    .line 16
    iput-object v0, p0, Lcom/thinkware/sundo/ieve/ieveDebugImageView;->b:Landroid/content/Context;

    .line 17
    iput-object v0, p0, Lcom/thinkware/sundo/ieve/ieveDebugImageView;->c:Landroid/graphics/Paint;

    .line 20
    iput-object v0, p0, Lcom/thinkware/sundo/ieve/ieveDebugImageView;->d:Landroid/graphics/Rect;

    .line 21
    iput-object v0, p0, Lcom/thinkware/sundo/ieve/ieveDebugImageView;->e:Landroid/graphics/PointF;

    .line 24
    iput-object v0, p0, Lcom/thinkware/sundo/ieve/ieveDebugImageView;->mBmpImg:Landroid/graphics/Bitmap;

    .line 29
    sget-object v0, Lcom/thinkware/sundo/ieve/ieveDebugImageView;->a:Ljava/lang/String;

    const-string v1, "Constructor"

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 30
    iput-object p1, p0, Lcom/thinkware/sundo/ieve/ieveDebugImageView;->b:Landroid/content/Context;

    .line 31
    new-instance v0, Landroid/graphics/Paint;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Lcom/thinkware/sundo/ieve/ieveDebugImageView;->c:Landroid/graphics/Paint;

    .line 32
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveDebugImageView;->b:Landroid/content/Context;

    if-nez v0, :cond_0

    .line 33
    sget-object v0, Lcom/thinkware/sundo/ieve/ieveDebugImageView;->a:Ljava/lang/String;

    const-string v1, "Context is null!"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 40
    :goto_0
    return-void

    .line 37
    :cond_0
    new-instance v0, Landroid/graphics/Rect;

    invoke-direct {v0, p2}, Landroid/graphics/Rect;-><init>(Landroid/graphics/Rect;)V

    iput-object v0, p0, Lcom/thinkware/sundo/ieve/ieveDebugImageView;->d:Landroid/graphics/Rect;

    .line 38
    new-instance v0, Landroid/graphics/PointF;

    iget-object v1, p0, Lcom/thinkware/sundo/ieve/ieveDebugImageView;->d:Landroid/graphics/Rect;

    invoke-virtual {v1}, Landroid/graphics/Rect;->width()I

    move-result v1

    int-to-float v1, v1

    const/high16 v2, 0x44800000    # 1024.0f

    div-float/2addr v1, v2

    iget-object v2, p0, Lcom/thinkware/sundo/ieve/ieveDebugImageView;->d:Landroid/graphics/Rect;

    invoke-virtual {v2}, Landroid/graphics/Rect;->height()I

    move-result v2

    int-to-float v2, v2

    const/high16 v3, 0x44160000    # 600.0f

    div-float/2addr v2, v3

    invoke-direct {v0, v1, v2}, Landroid/graphics/PointF;-><init>(FF)V

    iput-object v0, p0, Lcom/thinkware/sundo/ieve/ieveDebugImageView;->e:Landroid/graphics/PointF;

    .line 39
    invoke-virtual {p0}, Lcom/thinkware/sundo/ieve/ieveDebugImageView;->postInvalidate()V

    goto :goto_0
.end method


# virtual methods
.method protected dispatchDraw(Landroid/graphics/Canvas;)V
    .locals 4
    .param p1, "canvas"    # Landroid/graphics/Canvas;

    .prologue
    const/4 v3, 0x0

    const/16 v2, 0xff

    .line 49
    invoke-super {p0, p1}, Landroid/view/View;->dispatchDraw(Landroid/graphics/Canvas;)V

    .line 51
    invoke-virtual {p1, v3}, Landroid/graphics/Canvas;->drawColor(I)V

    .line 52
    new-instance v0, Landroid/graphics/PaintFlagsDrawFilter;

    const/4 v1, 0x2

    invoke-direct {v0, v3, v1}, Landroid/graphics/PaintFlagsDrawFilter;-><init>(II)V

    invoke-virtual {p1, v0}, Landroid/graphics/Canvas;->setDrawFilter(Landroid/graphics/DrawFilter;)V

    .line 53
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveDebugImageView;->e:Landroid/graphics/PointF;

    iget v0, v0, Landroid/graphics/PointF;->x:F

    iget-object v1, p0, Lcom/thinkware/sundo/ieve/ieveDebugImageView;->e:Landroid/graphics/PointF;

    iget v1, v1, Landroid/graphics/PointF;->y:F

    invoke-virtual {p1, v0, v1}, Landroid/graphics/Canvas;->scale(FF)V

    .line 55
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveDebugImageView;->c:Landroid/graphics/Paint;

    invoke-virtual {v0, v2, v2, v2, v2}, Landroid/graphics/Paint;->setARGB(IIII)V

    .line 58
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveDebugImageView;->mBmpImg:Landroid/graphics/Bitmap;

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveDebugImageView;->mBmpImg:Landroid/graphics/Bitmap;

    const/high16 v1, 0x42a40000    # 82.0f

    const/high16 v2, 0x42640000    # 57.0f

    iget-object v3, p0, Lcom/thinkware/sundo/ieve/ieveDebugImageView;->c:Landroid/graphics/Paint;

    invoke-virtual {p1, v0, v1, v2, v3}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;FFLandroid/graphics/Paint;)V

    .line 59
    :cond_0
    invoke-virtual {p0}, Lcom/thinkware/sundo/ieve/ieveDebugImageView;->postInvalidate()V

    .line 60
    return-void
.end method

.method public finalize()V
    .locals 2

    .prologue
    .line 43
    sget-object v0, Lcom/thinkware/sundo/ieve/ieveDebugImageView;->a:Ljava/lang/String;

    const-string v1, "finalize"

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 44
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveDebugImageView;->mBmpImg:Landroid/graphics/Bitmap;

    if-eqz v0, :cond_0

    const/4 v0, 0x0

    iput-object v0, p0, Lcom/thinkware/sundo/ieve/ieveDebugImageView;->mBmpImg:Landroid/graphics/Bitmap;

    .line 45
    :cond_0
    return-void
.end method

.method public setBitmap(II[I)V
    .locals 8
    .param p1, "width"    # I
    .param p2, "height"    # I
    .param p3, "buffer"    # [I

    .prologue
    const/4 v2, 0x0

    .line 63
    if-eqz p1, :cond_0

    if-eqz p2, :cond_0

    if-nez p3, :cond_2

    .line 64
    :cond_0
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveDebugImageView;->mBmpImg:Landroid/graphics/Bitmap;

    if-eqz v0, :cond_1

    const/4 v0, 0x0

    iput-object v0, p0, Lcom/thinkware/sundo/ieve/ieveDebugImageView;->mBmpImg:Landroid/graphics/Bitmap;

    .line 72
    :cond_1
    :goto_0
    return-void

    .line 67
    :cond_2
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveDebugImageView;->mBmpImg:Landroid/graphics/Bitmap;

    if-eqz v0, :cond_3

    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveDebugImageView;->mBmpImg:Landroid/graphics/Bitmap;

    invoke-virtual {v0}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v0

    if-ne v0, p1, :cond_3

    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveDebugImageView;->mBmpImg:Landroid/graphics/Bitmap;

    invoke-virtual {v0}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v0

    if-eq v0, p2, :cond_4

    .line 68
    :cond_3
    sget-object v0, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    invoke-static {p1, p2, v0}, Landroid/graphics/Bitmap;->createBitmap(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    move-result-object v0

    iput-object v0, p0, Lcom/thinkware/sundo/ieve/ieveDebugImageView;->mBmpImg:Landroid/graphics/Bitmap;

    .line 70
    :cond_4
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveDebugImageView;->mBmpImg:Landroid/graphics/Bitmap;

    if-eqz v0, :cond_1

    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveDebugImageView;->mBmpImg:Landroid/graphics/Bitmap;

    move-object v1, p3

    move v3, p1

    move v4, v2

    move v5, v2

    move v6, p1

    move v7, p2

    invoke-virtual/range {v0 .. v7}, Landroid/graphics/Bitmap;->setPixels([IIIIIII)V

    goto :goto_0
.end method
