.class public interface abstract Ltas/util/backlight/KBacklight$BrightnessObserver;
.super Ljava/lang/Object;
.source "KBacklight.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltas/util/backlight/KBacklight;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "BrightnessObserver"
.end annotation


# virtual methods
.method public abstract onKBrightnessChanged(I)V
.end method
