.class public Ltas/internal/ipc/util/SyncdPool;
.super Ljava/lang/Object;
.source "SyncdPool.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ltas/internal/ipc/util/SyncdPool$Callback;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation


# static fields
.field private static final MAX_POOL_SIZE:I = 0x32


# instance fields
.field private mCallback:Ltas/internal/ipc/util/SyncdPool$Callback;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ltas/internal/ipc/util/SyncdPool$Callback",
            "<TT;>;"
        }
    .end annotation
.end field

.field private mMaxPoolSize:I

.field private mPool:Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TT;"
        }
    .end annotation
.end field

.field private mPoolSize:I

.field private final mPoolSync:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Ltas/internal/ipc/util/SyncdPool$Callback;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ltas/internal/ipc/util/SyncdPool$Callback",
            "<TT;>;)V"
        }
    .end annotation

    .prologue
    .line 26
    .local p0, "this":Ltas/internal/ipc/util/SyncdPool;, "Ltas/internal/ipc/util/SyncdPool<TT;>;"
    .local p1, "cb":Ltas/internal/ipc/util/SyncdPool$Callback;, "Ltas/internal/ipc/util/SyncdPool$Callback<TT;>;"
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 14
    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, Ltas/internal/ipc/util/SyncdPool;->mPoolSync:Ljava/lang/Object;

    .line 16
    const/4 v0, 0x0

    iput v0, p0, Ltas/internal/ipc/util/SyncdPool;->mPoolSize:I

    .line 27
    iput-object p1, p0, Ltas/internal/ipc/util/SyncdPool;->mCallback:Ltas/internal/ipc/util/SyncdPool$Callback;

    .line 28
    const/16 v0, 0x32

    iput v0, p0, Ltas/internal/ipc/util/SyncdPool;->mMaxPoolSize:I

    .line 26
    return-void
.end method

.method public constructor <init>(Ltas/internal/ipc/util/SyncdPool$Callback;I)V
    .locals 2
    .param p2, "maxPoolSize"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ltas/internal/ipc/util/SyncdPool$Callback",
            "<TT;>;I)V"
        }
    .end annotation

    .prologue
    .local p0, "this":Ltas/internal/ipc/util/SyncdPool;, "Ltas/internal/ipc/util/SyncdPool<TT;>;"
    .local p1, "cb":Ltas/internal/ipc/util/SyncdPool$Callback;, "Ltas/internal/ipc/util/SyncdPool$Callback<TT;>;"
    const/4 v1, 0x0

    .line 31
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 14
    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, Ltas/internal/ipc/util/SyncdPool;->mPoolSync:Ljava/lang/Object;

    .line 16
    iput v1, p0, Ltas/internal/ipc/util/SyncdPool;->mPoolSize:I

    .line 32
    iput-object p1, p0, Ltas/internal/ipc/util/SyncdPool;->mCallback:Ltas/internal/ipc/util/SyncdPool$Callback;

    .line 33
    if-lez p2, :cond_0

    .end local p2    # "maxPoolSize":I
    :goto_0
    iput p2, p0, Ltas/internal/ipc/util/SyncdPool;->mMaxPoolSize:I

    .line 31
    return-void

    .line 33
    .restart local p2    # "maxPoolSize":I
    :cond_0
    const/16 p2, 0x32

    goto :goto_0
.end method


# virtual methods
.method public allocate()Ljava/lang/Object;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TT;"
        }
    .end annotation

    .prologue
    .line 37
    .local p0, "this":Ltas/internal/ipc/util/SyncdPool;, "Ltas/internal/ipc/util/SyncdPool<TT;>;"
    iget-object v2, p0, Ltas/internal/ipc/util/SyncdPool;->mPoolSync:Ljava/lang/Object;

    monitor-enter v2

    .line 38
    const/4 v0, 0x0

    .line 39
    .local v0, "t":Ljava/lang/Object;, "TT;"
    :try_start_0
    iget-object v1, p0, Ltas/internal/ipc/util/SyncdPool;->mPool:Ljava/lang/Object;

    if-eqz v1, :cond_0

    .line 40
    iget-object v0, p0, Ltas/internal/ipc/util/SyncdPool;->mPool:Ljava/lang/Object;

    .line 41
    iget-object v1, p0, Ltas/internal/ipc/util/SyncdPool;->mCallback:Ltas/internal/ipc/util/SyncdPool$Callback;

    invoke-interface {v1, v0}, Ltas/internal/ipc/util/SyncdPool$Callback;->getNext(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    iput-object v1, p0, Ltas/internal/ipc/util/SyncdPool;->mPool:Ljava/lang/Object;

    .line 42
    iget-object v1, p0, Ltas/internal/ipc/util/SyncdPool;->mCallback:Ltas/internal/ipc/util/SyncdPool$Callback;

    const/4 v3, 0x0

    invoke-interface {v1, v0, v3}, Ltas/internal/ipc/util/SyncdPool$Callback;->setNext(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 43
    iget v1, p0, Ltas/internal/ipc/util/SyncdPool;->mPoolSize:I

    add-int/lit8 v1, v1, -0x1

    iput v1, p0, Ltas/internal/ipc/util/SyncdPool;->mPoolSize:I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :goto_0
    monitor-exit v2

    .line 47
    return-object v0

    .line 45
    :cond_0
    :try_start_1
    iget-object v1, p0, Ltas/internal/ipc/util/SyncdPool;->mCallback:Ltas/internal/ipc/util/SyncdPool$Callback;

    invoke-interface {v1}, Ltas/internal/ipc/util/SyncdPool$Callback;->newInstance()Ljava/lang/Object;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    move-result-object v0

    goto :goto_0

    .line 37
    .end local v0    # "t":Ljava/lang/Object;, "TT;"
    :catchall_0
    move-exception v1

    monitor-exit v2

    throw v1
.end method

.method public recycle(Ljava/lang/Object;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    .prologue
    .line 52
    .local p0, "this":Ltas/internal/ipc/util/SyncdPool;, "Ltas/internal/ipc/util/SyncdPool<TT;>;"
    .local p1, "t":Ljava/lang/Object;, "TT;"
    iget-object v1, p0, Ltas/internal/ipc/util/SyncdPool;->mPoolSync:Ljava/lang/Object;

    monitor-enter v1

    .line 53
    :try_start_0
    iget v0, p0, Ltas/internal/ipc/util/SyncdPool;->mPoolSize:I

    iget v2, p0, Ltas/internal/ipc/util/SyncdPool;->mMaxPoolSize:I

    if-ge v0, v2, :cond_0

    .line 54
    iget-object v0, p0, Ltas/internal/ipc/util/SyncdPool;->mCallback:Ltas/internal/ipc/util/SyncdPool$Callback;

    iget-object v2, p0, Ltas/internal/ipc/util/SyncdPool;->mPool:Ljava/lang/Object;

    invoke-interface {v0, p1, v2}, Ltas/internal/ipc/util/SyncdPool$Callback;->setNext(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 55
    iput-object p1, p0, Ltas/internal/ipc/util/SyncdPool;->mPool:Ljava/lang/Object;

    .line 56
    iget v0, p0, Ltas/internal/ipc/util/SyncdPool;->mPoolSize:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Ltas/internal/ipc/util/SyncdPool;->mPoolSize:I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_0
    monitor-exit v1

    .line 51
    return-void

    .line 52
    :catchall_0
    move-exception v0

    monitor-exit v1

    throw v0
.end method
