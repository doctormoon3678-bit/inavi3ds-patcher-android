.class public Ltas/internal/camera/server/ServerInComing;
.super Ljava/lang/Object;
.source "ServerInComing.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ltas/internal/camera/server/ServerInComing$Proxy;
    }
.end annotation


# static fields
.field private static final DBG:Z = true

.field private static final TAG:Ljava/lang/String; = "TasCAM<Server>"


# instance fields
.field private mContext:Landroid/content/Context;

.field private mInputManager:Ltas/internal/camera/InputManager;

.field private mOutGoing:Ltas/internal/camera/server/ServerOutGoing;

.field private mProxy:Ltas/internal/camera/server/ServerInComing$Proxy;


# direct methods
.method static synthetic -wrap0(Ltas/internal/camera/server/ServerInComing;ILtas/internal/camera/InputParams;)I
    .locals 1
    .param p1, "pid"    # I
    .param p2, "params"    # Ltas/internal/camera/InputParams;

    .prologue
    invoke-direct {p0, p1, p2}, Ltas/internal/camera/server/ServerInComing;->command(ILtas/internal/camera/InputParams;)I

    move-result v0

    return v0
.end method

.method static synthetic -wrap1(Ltas/internal/camera/server/ServerInComing;ILtas/internal/camera/InputParams;)I
    .locals 1
    .param p1, "pid"    # I
    .param p2, "params"    # Ltas/internal/camera/InputParams;

    .prologue
    invoke-direct {p0, p1, p2}, Ltas/internal/camera/server/ServerInComing;->request(ILtas/internal/camera/InputParams;)I

    move-result v0

    return v0
.end method

.method static synthetic -wrap2(Ltas/internal/camera/server/ServerInComing;ILtas/internal/camera/InputParams;)V
    .locals 0
    .param p1, "pid"    # I
    .param p2, "params"    # Ltas/internal/camera/InputParams;

    .prologue
    invoke-direct {p0, p1, p2}, Ltas/internal/camera/server/ServerInComing;->cancel(ILtas/internal/camera/InputParams;)V

    return-void
.end method

.method static synthetic -wrap3(Ltas/internal/camera/server/ServerInComing;ILtas/internal/camera/server/IServerCallback;)V
    .locals 0
    .param p1, "pid"    # I
    .param p2, "cb"    # Ltas/internal/camera/server/IServerCallback;

    .prologue
    invoke-direct {p0, p1, p2}, Ltas/internal/camera/server/ServerInComing;->setCallback(ILtas/internal/camera/server/IServerCallback;)V

    return-void
.end method

.method static synthetic -wrap4(Ltas/internal/camera/server/ServerInComing;ILtas/internal/camera/InputParams;)V
    .locals 0
    .param p1, "pid"    # I
    .param p2, "params"    # Ltas/internal/camera/InputParams;

    .prologue
    invoke-direct {p0, p1, p2}, Ltas/internal/camera/server/ServerInComing;->unwatch(ILtas/internal/camera/InputParams;)V

    return-void
.end method

.method static synthetic -wrap5(Ltas/internal/camera/server/ServerInComing;ILtas/internal/camera/InputParams;)V
    .locals 0
    .param p1, "pid"    # I
    .param p2, "params"    # Ltas/internal/camera/InputParams;

    .prologue
    invoke-direct {p0, p1, p2}, Ltas/internal/camera/server/ServerInComing;->watch(ILtas/internal/camera/InputParams;)V

    return-void
.end method

.method constructor <init>(Ltas/internal/camera/server/ServerOutGoing;)V
    .locals 1
    .param p1, "_server"    # Ltas/internal/camera/server/ServerOutGoing;

    .prologue
    .line 32
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 33
    iput-object p1, p0, Ltas/internal/camera/server/ServerInComing;->mOutGoing:Ltas/internal/camera/server/ServerOutGoing;

    .line 34
    invoke-virtual {p1}, Ltas/internal/camera/server/ServerOutGoing;->getContext()Landroid/content/Context;

    move-result-object v0

    iput-object v0, p0, Ltas/internal/camera/server/ServerInComing;->mContext:Landroid/content/Context;

    .line 35
    new-instance v0, Ltas/internal/camera/server/ServerInComing$Proxy;

    invoke-direct {v0, p0}, Ltas/internal/camera/server/ServerInComing$Proxy;-><init>(Ltas/internal/camera/server/ServerInComing;)V

    iput-object v0, p0, Ltas/internal/camera/server/ServerInComing;->mProxy:Ltas/internal/camera/server/ServerInComing$Proxy;

    .line 32
    return-void
.end method

.method private cancel(ILtas/internal/camera/InputParams;)V
    .locals 2
    .param p1, "pid"    # I
    .param p2, "params"    # Ltas/internal/camera/InputParams;

    .prologue
    .line 73
    iget-object v1, p0, Ltas/internal/camera/server/ServerInComing;->mOutGoing:Ltas/internal/camera/server/ServerOutGoing;

    invoke-virtual {v1, p1}, Ltas/internal/camera/server/ServerOutGoing;->getClientName(I)Ljava/lang/String;

    move-result-object v0

    .line 74
    .local v0, "name":Ljava/lang/String;
    if-eqz v0, :cond_0

    iget-object v1, p0, Ltas/internal/camera/server/ServerInComing;->mInputManager:Ltas/internal/camera/InputManager;

    invoke-virtual {v1, v0, p2}, Ltas/internal/camera/InputManager;->cancel(Ljava/lang/String;Ltas/internal/camera/InputParams;)V

    .line 72
    :cond_0
    return-void
.end method

.method private command(ILtas/internal/camera/InputParams;)I
    .locals 2
    .param p1, "pid"    # I
    .param p2, "params"    # Ltas/internal/camera/InputParams;

    .prologue
    .line 78
    iget-object v1, p0, Ltas/internal/camera/server/ServerInComing;->mOutGoing:Ltas/internal/camera/server/ServerOutGoing;

    invoke-virtual {v1, p1}, Ltas/internal/camera/server/ServerOutGoing;->getClientName(I)Ljava/lang/String;

    move-result-object v0

    .line 79
    .local v0, "name":Ljava/lang/String;
    if-eqz v0, :cond_0

    .line 80
    iget-object v1, p0, Ltas/internal/camera/server/ServerInComing;->mInputManager:Ltas/internal/camera/InputManager;

    invoke-virtual {v1, v0, p2}, Ltas/internal/camera/InputManager;->command(Ljava/lang/String;Ltas/internal/camera/InputParams;)I

    move-result v1

    .line 79
    :goto_0
    return v1

    .line 80
    :cond_0
    const/4 v1, -0x1

    goto :goto_0
.end method

.method private request(ILtas/internal/camera/InputParams;)I
    .locals 2
    .param p1, "pid"    # I
    .param p2, "params"    # Ltas/internal/camera/InputParams;

    .prologue
    .line 67
    iget-object v1, p0, Ltas/internal/camera/server/ServerInComing;->mOutGoing:Ltas/internal/camera/server/ServerOutGoing;

    invoke-virtual {v1, p1}, Ltas/internal/camera/server/ServerOutGoing;->getClientName(I)Ljava/lang/String;

    move-result-object v0

    .line 68
    .local v0, "name":Ljava/lang/String;
    if-eqz v0, :cond_0

    .line 69
    iget-object v1, p0, Ltas/internal/camera/server/ServerInComing;->mInputManager:Ltas/internal/camera/InputManager;

    invoke-virtual {v1, v0, p2}, Ltas/internal/camera/InputManager;->request(Ljava/lang/String;Ltas/internal/camera/InputParams;)I

    move-result v1

    .line 68
    :goto_0
    return v1

    .line 69
    :cond_0
    const/4 v1, -0x1

    goto :goto_0
.end method

.method private setCallback(ILtas/internal/camera/server/IServerCallback;)V
    .locals 1
    .param p1, "pid"    # I
    .param p2, "cb"    # Ltas/internal/camera/server/IServerCallback;

    .prologue
    .line 51
    iget-object v0, p0, Ltas/internal/camera/server/ServerInComing;->mOutGoing:Ltas/internal/camera/server/ServerOutGoing;

    invoke-virtual {v0, p1, p2}, Ltas/internal/camera/server/ServerOutGoing;->addClientCallback(ILtas/internal/camera/server/IServerCallback;)V

    .line 50
    return-void
.end method

.method private unwatch(ILtas/internal/camera/InputParams;)V
    .locals 2
    .param p1, "pid"    # I
    .param p2, "params"    # Ltas/internal/camera/InputParams;

    .prologue
    .line 63
    iget-object v0, p0, Ltas/internal/camera/server/ServerInComing;->mOutGoing:Ltas/internal/camera/server/ServerOutGoing;

    iget-object v1, p2, Ltas/internal/camera/InputParams;->cam:Ljava/lang/String;

    invoke-virtual {v0, p1, v1}, Ltas/internal/camera/server/ServerOutGoing;->removeClientConcern(ILjava/lang/String;)V

    .line 62
    return-void
.end method

.method private watch(ILtas/internal/camera/InputParams;)V
    .locals 3
    .param p1, "pid"    # I
    .param p2, "params"    # Ltas/internal/camera/InputParams;

    .prologue
    .line 55
    iget-object v1, p0, Ltas/internal/camera/server/ServerInComing;->mInputManager:Ltas/internal/camera/InputManager;

    iget-object v2, p2, Ltas/internal/camera/InputParams;->cam:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ltas/internal/camera/InputManager;->findInput(Ljava/lang/String;)Ltas/internal/camera/InputSource;

    move-result-object v0

    .line 56
    .local v0, "input":Ltas/internal/camera/InputSource;
    if-eqz v0, :cond_0

    .line 57
    iget-object v1, p0, Ltas/internal/camera/server/ServerInComing;->mOutGoing:Ltas/internal/camera/server/ServerOutGoing;

    iget-object v2, p2, Ltas/internal/camera/InputParams;->cam:Ljava/lang/String;

    invoke-virtual {v1, p1, v2}, Ltas/internal/camera/server/ServerOutGoing;->addClientConcern(ILjava/lang/String;)V

    .line 59
    :cond_0
    iget-object v1, p0, Ltas/internal/camera/server/ServerInComing;->mOutGoing:Ltas/internal/camera/server/ServerOutGoing;

    iget-object v2, p2, Ltas/internal/camera/InputParams;->cam:Ljava/lang/String;

    invoke-virtual {v1, p1, v2, v0}, Ltas/internal/camera/server/ServerOutGoing;->notifyInitialState(ILjava/lang/String;Ltas/internal/camera/InputSource;)V

    .line 54
    return-void
.end method


# virtual methods
.method public getContext()Landroid/content/Context;
    .locals 1

    .prologue
    .line 43
    iget-object v0, p0, Ltas/internal/camera/server/ServerInComing;->mContext:Landroid/content/Context;

    return-object v0
.end method

.method public getIBinder()Landroid/os/IBinder;
    .locals 1

    .prologue
    .line 47
    iget-object v0, p0, Ltas/internal/camera/server/ServerInComing;->mProxy:Ltas/internal/camera/server/ServerInComing$Proxy;

    return-object v0
.end method

.method public setInputManager(Ltas/internal/camera/InputManager;)V
    .locals 0
    .param p1, "mgr"    # Ltas/internal/camera/InputManager;

    .prologue
    .line 39
    iput-object p1, p0, Ltas/internal/camera/server/ServerInComing;->mInputManager:Ltas/internal/camera/InputManager;

    .line 38
    return-void
.end method
