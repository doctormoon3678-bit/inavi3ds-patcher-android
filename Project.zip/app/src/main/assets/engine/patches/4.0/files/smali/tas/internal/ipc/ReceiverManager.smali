.class Ltas/internal/ipc/ReceiverManager;
.super Ljava/lang/Object;
.source "ReceiverManager.java"

# interfaces
.implements Ltas/internal/ipc/server/ServerConnection$ReceiverCallback;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;,
        Ltas/internal/ipc/ReceiverManager$Replier;
    }
.end annotation


# static fields
.field private static final DBG:Z = true

.field private static final DBG_TRANSMIT:Z = false

.field private static final TAG:Ljava/lang/String; = "TasIPC<ReceiverManager>"

.field private static sId:I

.field private static sThis:Ltas/internal/ipc/ReceiverManager;


# instance fields
.field private final mReceivers:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List",
            "<",
            "Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;",
            ">;"
        }
    .end annotation
.end field

.field private mServer:Ltas/internal/ipc/server/ServerConnection;


# direct methods
.method static synthetic -get0(Ltas/internal/ipc/ReceiverManager;)Ljava/util/List;
    .locals 1

    iget-object v0, p0, Ltas/internal/ipc/ReceiverManager;->mReceivers:Ljava/util/List;

    return-object v0
.end method

.method static synthetic -wrap0(Ltas/internal/ipc/ReceiverManager;Ltas/internal/ipc/Receiver;Ltas/internal/ipc/server/RemoteSender;)V
    .locals 0
    .param p1, "mr"    # Ltas/internal/ipc/Receiver;
    .param p2, "s"    # Ltas/internal/ipc/server/RemoteSender;

    .prologue
    invoke-direct {p0, p1, p2}, Ltas/internal/ipc/ReceiverManager;->dispatchOffline(Ltas/internal/ipc/Receiver;Ltas/internal/ipc/server/RemoteSender;)V

    return-void
.end method

.method static synthetic -wrap1(Ltas/internal/ipc/ReceiverManager;Ltas/internal/ipc/Receiver;Ltas/internal/ipc/server/RemoteSender;)V
    .locals 0
    .param p1, "mr"    # Ltas/internal/ipc/Receiver;
    .param p2, "s"    # Ltas/internal/ipc/server/RemoteSender;

    .prologue
    invoke-direct {p0, p1, p2}, Ltas/internal/ipc/ReceiverManager;->dispatchOnline(Ltas/internal/ipc/Receiver;Ltas/internal/ipc/server/RemoteSender;)V

    return-void
.end method

.method static synthetic -wrap2(Ltas/internal/ipc/ReceiverManager;Ltas/internal/ipc/Receiver;Ltas/internal/ipc/server/RemoteMessage;)V
    .locals 0
    .param p1, "mr"    # Ltas/internal/ipc/Receiver;
    .param p2, "rmsg"    # Ltas/internal/ipc/server/RemoteMessage;

    .prologue
    invoke-direct {p0, p1, p2}, Ltas/internal/ipc/ReceiverManager;->dispatchReceive(Ltas/internal/ipc/Receiver;Ltas/internal/ipc/server/RemoteMessage;)V

    return-void
.end method

.method static synthetic -wrap3(Ltas/internal/ipc/ReceiverManager;Ltas/internal/ipc/Receiver;Ltas/internal/ipc/server/RemoteSender;)V
    .locals 0
    .param p1, "mr"    # Ltas/internal/ipc/Receiver;
    .param p2, "s"    # Ltas/internal/ipc/server/RemoteSender;

    .prologue
    invoke-direct {p0, p1, p2}, Ltas/internal/ipc/ReceiverManager;->dispatchUpdate(Ltas/internal/ipc/Receiver;Ltas/internal/ipc/server/RemoteSender;)V

    return-void
.end method

.method static synthetic -wrap4(Ltas/internal/ipc/ReceiverManager;Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;)V
    .locals 0
    .param p1, "receiver"    # Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/ipc/ReceiverManager;->registerToServer(Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;)V

    return-void
.end method

.method static synthetic -wrap5(Ltas/internal/ipc/ReceiverManager;Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;)V
    .locals 0
    .param p1, "receiver"    # Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/ipc/ReceiverManager;->updateToServer(Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;)V

    return-void
.end method

.method static synthetic -wrap6(Ltas/internal/ipc/ReceiverManager;Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;)V
    .locals 0
    .param p1, "receiver"    # Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/ipc/ReceiverManager;->watchAnonymousSenderFromServer(Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;)V

    return-void
.end method

.method static synthetic -wrap7(Ltas/internal/ipc/ReceiverManager;Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;Ljava/lang/String;)V
    .locals 0
    .param p1, "receiver"    # Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;
    .param p2, "target"    # Ljava/lang/String;

    .prologue
    invoke-direct {p0, p1, p2}, Ltas/internal/ipc/ReceiverManager;->watchSenderFromServer(Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;Ljava/lang/String;)V

    return-void
.end method

.method static constructor <clinit>()V
    .locals 1

    .prologue
    .line 41
    const/4 v0, 0x1

    sput v0, Ltas/internal/ipc/ReceiverManager;->sId:I

    .line 32
    return-void
.end method

.method private constructor <init>()V
    .locals 1

    .prologue
    .line 54
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 39
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 38
    iput-object v0, p0, Ltas/internal/ipc/ReceiverManager;->mReceivers:Ljava/util/List;

    .line 54
    return-void
.end method

.method private connectToServer(Landroid/content/Context;)V
    .locals 1
    .param p1, "context"    # Landroid/content/Context;

    .prologue
    .line 619
    iget-object v0, p0, Ltas/internal/ipc/ReceiverManager;->mServer:Ltas/internal/ipc/server/ServerConnection;

    if-eqz v0, :cond_0

    .line 620
    iget-object v0, p0, Ltas/internal/ipc/ReceiverManager;->mServer:Ltas/internal/ipc/server/ServerConnection;

    invoke-virtual {v0, p1}, Ltas/internal/ipc/server/ServerConnection;->setContext(Landroid/content/Context;)V

    .line 621
    iget-object v0, p0, Ltas/internal/ipc/ReceiverManager;->mServer:Ltas/internal/ipc/server/ServerConnection;

    invoke-virtual {v0}, Ltas/internal/ipc/server/ServerConnection;->connect()V

    .line 622
    return-void

    .line 625
    :cond_0
    new-instance v0, Ltas/internal/ipc/ReceiverManager$1;

    invoke-direct {v0, p0, p1}, Ltas/internal/ipc/ReceiverManager$1;-><init>(Ltas/internal/ipc/ReceiverManager;Landroid/content/Context;)V

    iput-object v0, p0, Ltas/internal/ipc/ReceiverManager;->mServer:Ltas/internal/ipc/server/ServerConnection;

    .line 653
    iget-object v0, p0, Ltas/internal/ipc/ReceiverManager;->mServer:Ltas/internal/ipc/server/ServerConnection;

    invoke-virtual {v0, p0}, Ltas/internal/ipc/server/ServerConnection;->setReceiverCallback(Ltas/internal/ipc/server/ServerConnection$ReceiverCallback;)V

    .line 654
    iget-object v0, p0, Ltas/internal/ipc/ReceiverManager;->mServer:Ltas/internal/ipc/server/ServerConnection;

    invoke-virtual {v0}, Ltas/internal/ipc/server/ServerConnection;->connect()V

    .line 618
    return-void
.end method

.method private disconnectFromServer()V
    .locals 1

    .prologue
    .line 658
    iget-object v0, p0, Ltas/internal/ipc/ReceiverManager;->mServer:Ltas/internal/ipc/server/ServerConnection;

    invoke-virtual {v0}, Ltas/internal/ipc/server/ServerConnection;->disconnect()V

    .line 657
    return-void
.end method

.method private dispatchOffline(Ltas/internal/ipc/Receiver;Ltas/internal/ipc/server/RemoteSender;)V
    .locals 6
    .param p1, "mr"    # Ltas/internal/ipc/Receiver;
    .param p2, "s"    # Ltas/internal/ipc/server/RemoteSender;

    .prologue
    .line 355
    invoke-virtual {p2}, Ltas/internal/ipc/server/RemoteSender;->getid()J

    move-result-wide v2

    invoke-virtual {p1, v2, v3}, Ltas/internal/ipc/Receiver;->removeSession(J)Ltas/ipc/ReceiverSession;

    move-result-object v0

    .line 356
    .local v0, "session":Ltas/ipc/ReceiverSession;
    if-eqz v0, :cond_0

    .line 357
    const-string/jumbo v1, "TasIPC<ReceiverManager>"

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "delete session id : "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-wide v4, v0, Ltas/ipc/ReceiverSession;->id:J

    invoke-virtual {v2, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 358
    const/4 v1, 0x0

    iput-boolean v1, v0, Ltas/ipc/ReceiverSession;->online:Z

    .line 359
    iget-object v1, p1, Ltas/internal/ipc/Receiver;->mDispatcher:Ltas/internal/ipc/Dispatcher;

    const/16 v2, 0xca

    invoke-virtual {v1, v2, v0}, Ltas/internal/ipc/Dispatcher;->dispatch(ILtas/ipc/ReceiverSession;)V

    .line 354
    :cond_0
    return-void
.end method

.method private dispatchOnline(Ltas/internal/ipc/Receiver;Ltas/internal/ipc/server/RemoteSender;)V
    .locals 7
    .param p1, "mr"    # Ltas/internal/ipc/Receiver;
    .param p2, "s"    # Ltas/internal/ipc/server/RemoteSender;

    .prologue
    .line 341
    invoke-virtual {p2}, Ltas/internal/ipc/server/RemoteSender;->getid()J

    move-result-wide v2

    invoke-virtual {p1, v2, v3}, Ltas/internal/ipc/Receiver;->getSession(J)Ltas/ipc/ReceiverSession;

    move-result-object v0

    .line 342
    .local v0, "session":Ltas/ipc/ReceiverSession;
    if-nez v0, :cond_0

    .line 343
    new-instance v0, Ltas/ipc/ReceiverSession;

    .line 344
    .end local v0    # "session":Ltas/ipc/ReceiverSession;
    invoke-virtual {p2}, Ltas/internal/ipc/server/RemoteSender;->getid()J

    move-result-wide v2

    iget-object v4, p2, Ltas/internal/ipc/server/RemoteSender;->pkg:Ljava/lang/String;

    iget-object v5, p2, Ltas/internal/ipc/server/RemoteSender;->name:Ljava/lang/String;

    iget-object v6, p2, Ltas/internal/ipc/server/RemoteSender;->extra:Landroid/os/Bundle;

    move-object v1, p1

    .line 343
    invoke-direct/range {v0 .. v6}, Ltas/ipc/ReceiverSession;-><init>(Ltas/internal/ipc/Receiver;JLjava/lang/String;Ljava/lang/String;Landroid/os/Bundle;)V

    .line 345
    .restart local v0    # "session":Ltas/ipc/ReceiverSession;
    invoke-virtual {p2}, Ltas/internal/ipc/server/RemoteSender;->getid()J

    move-result-wide v2

    invoke-virtual {p1, v2, v3, v0}, Ltas/internal/ipc/Receiver;->addSession(JLtas/ipc/ReceiverSession;)V

    .line 347
    const-string/jumbo v1, "TasIPC<ReceiverManager>"

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v3, p2, Ltas/internal/ipc/server/RemoteSender;->name:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string/jumbo v3, " new session id : "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-wide v4, v0, Ltas/ipc/ReceiverSession;->id:J

    invoke-virtual {v2, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 350
    :cond_0
    const/4 v1, 0x1

    iput-boolean v1, v0, Ltas/ipc/ReceiverSession;->online:Z

    .line 351
    iget-object v1, p1, Ltas/internal/ipc/Receiver;->mDispatcher:Ltas/internal/ipc/Dispatcher;

    const/16 v2, 0xc9

    invoke-virtual {v1, v2, v0}, Ltas/internal/ipc/Dispatcher;->dispatch(ILtas/ipc/ReceiverSession;)V

    .line 340
    return-void
.end method

.method private dispatchReceive(Ltas/internal/ipc/Receiver;Ltas/internal/ipc/server/RemoteMessage;)V
    .locals 4
    .param p1, "mr"    # Ltas/internal/ipc/Receiver;
    .param p2, "rmsg"    # Ltas/internal/ipc/server/RemoteMessage;

    .prologue
    .line 375
    iget-object v1, p2, Ltas/internal/ipc/server/RemoteMessage;->sender:Ltas/internal/ipc/server/RemoteSender;

    invoke-virtual {v1}, Ltas/internal/ipc/server/RemoteSender;->getid()J

    move-result-wide v2

    invoke-virtual {p1, v2, v3}, Ltas/internal/ipc/Receiver;->getSession(J)Ltas/ipc/ReceiverSession;

    move-result-object v0

    .line 376
    .local v0, "session":Ltas/ipc/ReceiverSession;
    if-eqz v0, :cond_0

    .line 377
    iget-object v1, v0, Ltas/ipc/ReceiverSession;->q:Ljava/util/Queue;

    iget-object v2, p2, Ltas/internal/ipc/server/RemoteMessage;->msg:Ltas/ipc/MsgData;

    invoke-static {v2}, Ltas/ipc/MsgData;->obtain(Ltas/ipc/MsgData;)Ltas/ipc/MsgData;

    move-result-object v2

    invoke-interface {v1, v2}, Ljava/util/Queue;->offer(Ljava/lang/Object;)Z

    .line 378
    iget-object v1, p1, Ltas/internal/ipc/Receiver;->mDispatcher:Ltas/internal/ipc/Dispatcher;

    const/16 v2, 0xcc

    invoke-virtual {v1, v2, v0}, Ltas/internal/ipc/Dispatcher;->dispatch(ILtas/ipc/ReceiverSession;)V

    .line 374
    :cond_0
    return-void
.end method

.method private dispatchUpdate(Ltas/internal/ipc/Receiver;Ltas/internal/ipc/server/RemoteSender;)V
    .locals 4
    .param p1, "mr"    # Ltas/internal/ipc/Receiver;
    .param p2, "s"    # Ltas/internal/ipc/server/RemoteSender;

    .prologue
    .line 364
    invoke-virtual {p2}, Ltas/internal/ipc/server/RemoteSender;->getid()J

    move-result-wide v2

    invoke-virtual {p1, v2, v3}, Ltas/internal/ipc/Receiver;->getSession(J)Ltas/ipc/ReceiverSession;

    move-result-object v0

    .line 365
    .local v0, "session":Ltas/ipc/ReceiverSession;
    if-eqz v0, :cond_1

    .line 366
    iget-object v1, v0, Ltas/ipc/ReceiverSession;->extra:Landroid/os/Bundle;

    invoke-virtual {v1}, Landroid/os/Bundle;->clear()V

    .line 367
    iget-object v1, p2, Ltas/internal/ipc/server/RemoteSender;->extra:Landroid/os/Bundle;

    if-eqz v1, :cond_0

    .line 368
    iget-object v1, v0, Ltas/ipc/ReceiverSession;->extra:Landroid/os/Bundle;

    iget-object v2, p2, Ltas/internal/ipc/server/RemoteSender;->extra:Landroid/os/Bundle;

    invoke-virtual {v1, v2}, Landroid/os/Bundle;->putAll(Landroid/os/Bundle;)V

    .line 370
    :cond_0
    iget-object v1, p1, Ltas/internal/ipc/Receiver;->mDispatcher:Ltas/internal/ipc/Dispatcher;

    const/16 v2, 0xcb

    invoke-virtual {v1, v2, v0}, Ltas/internal/ipc/Dispatcher;->dispatch(ILtas/ipc/ReceiverSession;)V

    .line 363
    :cond_1
    return-void
.end method

.method private static genId()I
    .locals 2

    .prologue
    .line 42
    sget v0, Ltas/internal/ipc/ReceiverManager;->sId:I

    add-int/lit8 v1, v0, 0x1

    sput v1, Ltas/internal/ipc/ReceiverManager;->sId:I

    return v0
.end method

.method static get()Ltas/internal/ipc/ReceiverManager;
    .locals 2

    .prologue
    .line 46
    const-class v1, Ltas/internal/ipc/ReceiverManager;

    monitor-enter v1

    .line 47
    :try_start_0
    sget-object v0, Ltas/internal/ipc/ReceiverManager;->sThis:Ltas/internal/ipc/ReceiverManager;

    if-nez v0, :cond_0

    .line 48
    new-instance v0, Ltas/internal/ipc/ReceiverManager;

    invoke-direct {v0}, Ltas/internal/ipc/ReceiverManager;-><init>()V

    sput-object v0, Ltas/internal/ipc/ReceiverManager;->sThis:Ltas/internal/ipc/ReceiverManager;

    .line 50
    :cond_0
    sget-object v0, Ltas/internal/ipc/ReceiverManager;->sThis:Ltas/internal/ipc/ReceiverManager;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit v1

    return-object v0

    .line 46
    :catchall_0
    move-exception v0

    monitor-exit v1

    throw v0
.end method

.method private onReceive(Ltas/internal/ipc/server/RemoteMessage;)V
    .locals 4
    .param p1, "rmsg"    # Ltas/internal/ipc/server/RemoteMessage;

    .prologue
    .line 332
    iget-object v0, p1, Ltas/internal/ipc/server/RemoteMessage;->receiver:Ltas/internal/ipc/server/RemoteReceiver;

    .line 333
    .local v0, "receiver":Ltas/internal/ipc/server/RemoteReceiver;
    invoke-virtual {v0}, Ltas/internal/ipc/server/RemoteReceiver;->getid()J

    move-result-wide v2

    invoke-virtual {p0, v2, v3}, Ltas/internal/ipc/ReceiverManager;->findReceiver(J)Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;

    move-result-object v1

    .line 334
    .local v1, "rw":Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;
    if-eqz v1, :cond_0

    .line 335
    invoke-static {v1, p1}, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->-wrap1(Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;Ltas/internal/ipc/server/RemoteMessage;)V

    .line 337
    :cond_0
    invoke-virtual {p1}, Ltas/internal/ipc/server/RemoteMessage;->recycle()V

    .line 331
    return-void
.end method

.method private registerToServer(Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;)V
    .locals 2
    .param p1, "receiver"    # Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;

    .prologue
    .line 662
    iget-object v0, p0, Ltas/internal/ipc/ReceiverManager;->mServer:Ltas/internal/ipc/server/ServerConnection;

    invoke-static {p1}, Ltas/internal/ipc/server/RemoteReceiver;->obtain(Ltas/internal/ipc/server/RemoteReceiver;)Ltas/internal/ipc/server/RemoteReceiver;

    move-result-object v1

    invoke-virtual {v0, v1}, Ltas/internal/ipc/server/ServerConnection;->registerReceiver(Ltas/internal/ipc/server/RemoteReceiver;)V

    .line 661
    return-void
.end method

.method private startReceiverService(Ltas/internal/ipc/Receiver;)V
    .locals 3
    .param p1, "receiver"    # Ltas/internal/ipc/Receiver;

    .prologue
    .line 603
    iget-object v2, p1, Ltas/internal/ipc/Receiver;->srvcls:Ljava/lang/Class;

    if-eqz v2, :cond_0

    .line 604
    invoke-virtual {p1}, Ltas/internal/ipc/Receiver;->getContext()Landroid/content/Context;

    move-result-object v0

    .line 605
    .local v0, "context":Landroid/content/Context;
    new-instance v1, Landroid/content/Intent;

    iget-object v2, p1, Ltas/internal/ipc/Receiver;->srvcls:Ljava/lang/Class;

    invoke-direct {v1, v0, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 606
    .local v1, "intent":Landroid/content/Intent;
    invoke-virtual {v0, v1}, Landroid/content/Context;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;

    .line 602
    .end local v0    # "context":Landroid/content/Context;
    .end local v1    # "intent":Landroid/content/Intent;
    :cond_0
    return-void
.end method

.method private stopReceiverService(Ltas/internal/ipc/Receiver;)V
    .locals 3
    .param p1, "receiver"    # Ltas/internal/ipc/Receiver;

    .prologue
    .line 611
    iget-object v2, p1, Ltas/internal/ipc/Receiver;->srvcls:Ljava/lang/Class;

    if-eqz v2, :cond_0

    .line 612
    invoke-virtual {p1}, Ltas/internal/ipc/Receiver;->getContext()Landroid/content/Context;

    move-result-object v0

    .line 613
    .local v0, "context":Landroid/content/Context;
    new-instance v1, Landroid/content/Intent;

    iget-object v2, p1, Ltas/internal/ipc/Receiver;->srvcls:Ljava/lang/Class;

    invoke-direct {v1, v0, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 614
    .local v1, "intent":Landroid/content/Intent;
    invoke-virtual {v0, v1}, Landroid/content/Context;->stopService(Landroid/content/Intent;)Z

    .line 610
    .end local v0    # "context":Landroid/content/Context;
    .end local v1    # "intent":Landroid/content/Intent;
    :cond_0
    return-void
.end method

.method private unregisterToServer(Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;)V
    .locals 2
    .param p1, "receiver"    # Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;

    .prologue
    .line 666
    iget-object v0, p0, Ltas/internal/ipc/ReceiverManager;->mServer:Ltas/internal/ipc/server/ServerConnection;

    invoke-static {p1}, Ltas/internal/ipc/server/RemoteReceiver;->obtain(Ltas/internal/ipc/server/RemoteReceiver;)Ltas/internal/ipc/server/RemoteReceiver;

    move-result-object v1

    invoke-virtual {v0, v1}, Ltas/internal/ipc/server/ServerConnection;->unregisterReceiver(Ltas/internal/ipc/server/RemoteReceiver;)V

    .line 665
    return-void
.end method

.method private unwatchAnonymousSenderFromServer(Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;)V
    .locals 2
    .param p1, "receiver"    # Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;

    .prologue
    .line 690
    iget-object v0, p0, Ltas/internal/ipc/ReceiverManager;->mServer:Ltas/internal/ipc/server/ServerConnection;

    invoke-static {p1}, Ltas/internal/ipc/server/RemoteReceiver;->obtain(Ltas/internal/ipc/server/RemoteReceiver;)Ltas/internal/ipc/server/RemoteReceiver;

    move-result-object v1

    invoke-virtual {v0, v1}, Ltas/internal/ipc/server/ServerConnection;->stopWatchingAnonymousSender(Ltas/internal/ipc/server/RemoteReceiver;)V

    .line 689
    return-void
.end method

.method private unwatchAnonymousSenderLocked(Ltas/internal/ipc/Receiver;)V
    .locals 5
    .param p1, "receiver"    # Ltas/internal/ipc/Receiver;

    .prologue
    .line 279
    iget-object v3, p1, Ltas/internal/ipc/Receiver;->mToken:Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;

    .line 280
    .local v3, "rw":Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;
    invoke-static {v3}, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->-get4(Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;)I

    move-result v4

    if-nez v4, :cond_1

    .line 281
    invoke-direct {p0, v3}, Ltas/internal/ipc/ReceiverManager;->unwatchAnonymousSenderFromServer(Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;)V

    .line 278
    :cond_0
    return-void

    .line 283
    :cond_1
    invoke-static {v3}, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->-get2(Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;)Landroid/util/ArrayMap;

    move-result-object v4

    invoke-virtual {v4}, Landroid/util/ArrayMap;->values()Ljava/util/Collection;

    move-result-object v2

    .line 284
    .local v2, "rss":Ljava/util/Collection;, "Ljava/util/Collection<Ltas/internal/ipc/server/RemoteSender;>;"
    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    .local v1, "rs$iterator":Ljava/util/Iterator;
    :cond_2
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_0

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/ipc/server/RemoteSender;

    .line 285
    .local v0, "rs":Ltas/internal/ipc/server/RemoteSender;
    if-eqz v0, :cond_2

    invoke-direct {p0, p1, v0}, Ltas/internal/ipc/ReceiverManager;->dispatchOffline(Ltas/internal/ipc/Receiver;Ltas/internal/ipc/server/RemoteSender;)V

    goto :goto_0
.end method

.method private unwatchSenderFromServer(Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;Ljava/lang/String;)V
    .locals 2
    .param p1, "receiver"    # Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;
    .param p2, "target"    # Ljava/lang/String;

    .prologue
    .line 680
    invoke-static {p1}, Ltas/internal/ipc/server/RemoteReceiver;->obtain(Ltas/internal/ipc/server/RemoteReceiver;)Ltas/internal/ipc/server/RemoteReceiver;

    move-result-object v0

    .line 681
    .local v0, "r":Ltas/internal/ipc/server/RemoteReceiver;
    iput-object p2, v0, Ltas/internal/ipc/server/RemoteReceiver;->target:Ljava/lang/String;

    .line 682
    iget-object v1, p0, Ltas/internal/ipc/ReceiverManager;->mServer:Ltas/internal/ipc/server/ServerConnection;

    invoke-virtual {v1, v0}, Ltas/internal/ipc/server/ServerConnection;->stopWatchingSender(Ltas/internal/ipc/server/RemoteReceiver;)V

    .line 679
    return-void
.end method

.method private unwatchSenderLocked(Ltas/internal/ipc/Receiver;Ljava/lang/String;)V
    .locals 8
    .param p1, "receiver"    # Ltas/internal/ipc/Receiver;
    .param p2, "sender"    # Ljava/lang/String;

    .prologue
    .line 229
    iget-object v5, p1, Ltas/internal/ipc/Receiver;->mToken:Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;

    .line 230
    .local v5, "rw":Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;
    invoke-static {v5}, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->-get5(Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;)Landroid/util/ArrayMap;

    move-result-object v6

    invoke-virtual {v6, p2}, Landroid/util/ArrayMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    .line 231
    .local v1, "ref":Ljava/lang/Integer;
    if-eqz v1, :cond_1

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v6

    add-int/lit8 v0, v6, -0x1

    .line 232
    .local v0, "dec":I
    :goto_0
    invoke-static {v5}, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->-get5(Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;)Landroid/util/ArrayMap;

    move-result-object v6

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-virtual {v6, p2, v7}, Landroid/util/ArrayMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 234
    if-nez v0, :cond_2

    .line 235
    invoke-direct {p0, v5, p2}, Ltas/internal/ipc/ReceiverManager;->unwatchSenderFromServer(Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;Ljava/lang/String;)V

    .line 228
    :cond_0
    return-void

    .line 231
    .end local v0    # "dec":I
    :cond_1
    const/4 v0, 0x0

    .restart local v0    # "dec":I
    goto :goto_0

    .line 237
    :cond_2
    invoke-static {v5}, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->-get2(Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;)Landroid/util/ArrayMap;

    move-result-object v6

    invoke-virtual {v6}, Landroid/util/ArrayMap;->values()Ljava/util/Collection;

    move-result-object v4

    .line 238
    .local v4, "rss":Ljava/util/Collection;, "Ljava/util/Collection<Ltas/internal/ipc/server/RemoteSender;>;"
    invoke-interface {v4}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v3

    .local v3, "rs$iterator":Ljava/util/Iterator;
    :cond_3
    :goto_1
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_0

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ltas/internal/ipc/server/RemoteSender;

    .line 239
    .local v2, "rs":Ltas/internal/ipc/server/RemoteSender;
    if-eqz v2, :cond_3

    iget-object v6, v2, Ltas/internal/ipc/server/RemoteSender;->name:Ljava/lang/String;

    invoke-virtual {v6, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_3

    .line 240
    invoke-direct {p0, p1, v2}, Ltas/internal/ipc/ReceiverManager;->dispatchOffline(Ltas/internal/ipc/Receiver;Ltas/internal/ipc/server/RemoteSender;)V

    goto :goto_1
.end method

.method private updateToServer(Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;)V
    .locals 2
    .param p1, "receiver"    # Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;

    .prologue
    .line 670
    iget-object v0, p0, Ltas/internal/ipc/ReceiverManager;->mServer:Ltas/internal/ipc/server/ServerConnection;

    invoke-static {p1}, Ltas/internal/ipc/server/RemoteReceiver;->obtain(Ltas/internal/ipc/server/RemoteReceiver;)Ltas/internal/ipc/server/RemoteReceiver;

    move-result-object v1

    invoke-virtual {v0, v1}, Ltas/internal/ipc/server/ServerConnection;->updateReceiver(Ltas/internal/ipc/server/RemoteReceiver;)V

    .line 669
    return-void
.end method

.method private watchAnonymousSenderFromServer(Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;)V
    .locals 2
    .param p1, "receiver"    # Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;

    .prologue
    .line 686
    iget-object v0, p0, Ltas/internal/ipc/ReceiverManager;->mServer:Ltas/internal/ipc/server/ServerConnection;

    invoke-static {p1}, Ltas/internal/ipc/server/RemoteReceiver;->obtain(Ltas/internal/ipc/server/RemoteReceiver;)Ltas/internal/ipc/server/RemoteReceiver;

    move-result-object v1

    invoke-virtual {v0, v1}, Ltas/internal/ipc/server/ServerConnection;->startWatchingAnonymousSender(Ltas/internal/ipc/server/RemoteReceiver;)V

    .line 685
    return-void
.end method

.method private watchAnonymousSenderLocked(Ltas/internal/ipc/Receiver;)V
    .locals 6
    .param p1, "receiver"    # Ltas/internal/ipc/Receiver;

    .prologue
    .line 267
    iget-object v3, p1, Ltas/internal/ipc/Receiver;->mToken:Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;

    .line 268
    .local v3, "rw":Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;
    invoke-static {v3}, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->-get4(Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;)I

    move-result v4

    const/4 v5, 0x1

    if-ne v4, v5, :cond_1

    .line 269
    invoke-direct {p0, v3}, Ltas/internal/ipc/ReceiverManager;->watchAnonymousSenderFromServer(Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;)V

    .line 266
    :cond_0
    return-void

    .line 271
    :cond_1
    invoke-static {v3}, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->-get2(Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;)Landroid/util/ArrayMap;

    move-result-object v4

    invoke-virtual {v4}, Landroid/util/ArrayMap;->values()Ljava/util/Collection;

    move-result-object v2

    .line 272
    .local v2, "rss":Ljava/util/Collection;, "Ljava/util/Collection<Ltas/internal/ipc/server/RemoteSender;>;"
    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    .local v1, "rs$iterator":Ljava/util/Iterator;
    :cond_2
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_0

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/ipc/server/RemoteSender;

    .line 273
    .local v0, "rs":Ltas/internal/ipc/server/RemoteSender;
    if-eqz v0, :cond_2

    invoke-direct {p0, p1, v0}, Ltas/internal/ipc/ReceiverManager;->dispatchOnline(Ltas/internal/ipc/Receiver;Ltas/internal/ipc/server/RemoteSender;)V

    goto :goto_0
.end method

.method private watchSenderFromServer(Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;Ljava/lang/String;)V
    .locals 2
    .param p1, "receiver"    # Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;
    .param p2, "target"    # Ljava/lang/String;

    .prologue
    .line 674
    invoke-static {p1}, Ltas/internal/ipc/server/RemoteReceiver;->obtain(Ltas/internal/ipc/server/RemoteReceiver;)Ltas/internal/ipc/server/RemoteReceiver;

    move-result-object v0

    .line 675
    .local v0, "r":Ltas/internal/ipc/server/RemoteReceiver;
    iput-object p2, v0, Ltas/internal/ipc/server/RemoteReceiver;->target:Ljava/lang/String;

    .line 676
    iget-object v1, p0, Ltas/internal/ipc/ReceiverManager;->mServer:Ltas/internal/ipc/server/ServerConnection;

    invoke-virtual {v1, v0}, Ltas/internal/ipc/server/ServerConnection;->startWatchingSender(Ltas/internal/ipc/server/RemoteReceiver;)V

    .line 673
    return-void
.end method

.method private watchSenderLocked(Ltas/internal/ipc/Receiver;Ljava/lang/String;)V
    .locals 8
    .param p1, "receiver"    # Ltas/internal/ipc/Receiver;
    .param p2, "sender"    # Ljava/lang/String;

    .prologue
    .line 212
    iget-object v5, p1, Ltas/internal/ipc/Receiver;->mToken:Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;

    .line 213
    .local v5, "rw":Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;
    invoke-static {v5}, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->-get5(Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;)Landroid/util/ArrayMap;

    move-result-object v6

    invoke-virtual {v6, p2}, Landroid/util/ArrayMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    .line 214
    .local v1, "ref":Ljava/lang/Integer;
    if-eqz v1, :cond_1

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v6

    add-int/lit8 v0, v6, 0x1

    .line 215
    .local v0, "inc":I
    :goto_0
    invoke-static {v5}, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->-get5(Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;)Landroid/util/ArrayMap;

    move-result-object v6

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-virtual {v6, p2, v7}, Landroid/util/ArrayMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 216
    const/4 v6, 0x1

    if-ne v0, v6, :cond_2

    .line 217
    invoke-direct {p0, v5, p2}, Ltas/internal/ipc/ReceiverManager;->watchSenderFromServer(Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;Ljava/lang/String;)V

    .line 211
    :cond_0
    return-void

    .line 214
    .end local v0    # "inc":I
    :cond_1
    const/4 v0, 0x1

    .restart local v0    # "inc":I
    goto :goto_0

    .line 219
    :cond_2
    invoke-static {v5}, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->-get2(Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;)Landroid/util/ArrayMap;

    move-result-object v6

    invoke-virtual {v6}, Landroid/util/ArrayMap;->values()Ljava/util/Collection;

    move-result-object v4

    .line 220
    .local v4, "rss":Ljava/util/Collection;, "Ljava/util/Collection<Ltas/internal/ipc/server/RemoteSender;>;"
    invoke-interface {v4}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v3

    .local v3, "rs$iterator":Ljava/util/Iterator;
    :cond_3
    :goto_1
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_0

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ltas/internal/ipc/server/RemoteSender;

    .line 221
    .local v2, "rs":Ltas/internal/ipc/server/RemoteSender;
    if-eqz v2, :cond_3

    iget-object v6, v2, Ltas/internal/ipc/server/RemoteSender;->name:Ljava/lang/String;

    invoke-virtual {v6, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_3

    .line 222
    invoke-direct {p0, p1, v2}, Ltas/internal/ipc/ReceiverManager;->dispatchOnline(Ltas/internal/ipc/Receiver;Ltas/internal/ipc/server/RemoteSender;)V

    goto :goto_1
.end method


# virtual methods
.method findReceiver(J)Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;
    .locals 5
    .param p1, "id"    # J

    .prologue
    const/4 v4, 0x0

    .line 383
    iget-object v2, p0, Ltas/internal/ipc/ReceiverManager;->mReceivers:Ljava/util/List;

    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    .local v1, "rw$iterator":Ljava/util/Iterator;
    :cond_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;

    .line 384
    .local v0, "rw":Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;
    if-eqz v0, :cond_0

    invoke-virtual {v0}, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->getid()J

    move-result-wide v2

    cmp-long v2, v2, p1

    if-nez v2, :cond_0

    .line 385
    return-object v0

    .line 388
    .end local v0    # "rw":Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;
    :cond_1
    return-object v4
.end method

.method initialize(Ltas/internal/ipc/Receiver;)V
    .locals 7
    .param p1, "receiver"    # Ltas/internal/ipc/Receiver;

    .prologue
    const/4 v6, 0x0

    .line 59
    const-string/jumbo v3, "TasIPC<ReceiverManager>"

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v5, p1, Ltas/internal/ipc/Receiver;->name:Ljava/lang/String;

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string/jumbo v5, "@"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {p1}, Ltas/internal/ipc/Receiver;->hashCode()I

    move-result v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v4

    .line 60
    const-string/jumbo v5, " init."

    .line 59
    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v3, v4}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 63
    const/4 v2, 0x0

    .line 64
    .local v2, "rw":Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;
    iget-object v3, p0, Ltas/internal/ipc/ReceiverManager;->mReceivers:Ljava/util/List;

    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    .local v1, "found$iterator":Ljava/util/Iterator;
    :cond_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_1

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;

    .line 65
    .local v0, "found":Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;
    if-eqz v0, :cond_0

    iget-object v3, v0, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->name:Ljava/lang/String;

    iget-object v4, p1, Ltas/internal/ipc/Receiver;->name:Ljava/lang/String;

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_0

    .line 66
    move-object v2, v0

    .line 71
    .end local v0    # "found":Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;
    .end local v2    # "rw":Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;
    :cond_1
    if-nez v2, :cond_2

    .line 72
    new-instance v2, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;

    invoke-direct {v2, p0, p1, v6}, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;-><init>(Ltas/internal/ipc/ReceiverManager;Ltas/internal/ipc/Receiver;Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;)V

    .line 73
    .local v2, "rw":Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;
    iget-object v3, p0, Ltas/internal/ipc/ReceiverManager;->mReceivers:Ljava/util/List;

    invoke-interface {v3, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 74
    invoke-direct {p0, p1}, Ltas/internal/ipc/ReceiverManager;->startReceiverService(Ltas/internal/ipc/Receiver;)V

    .line 77
    .end local v2    # "rw":Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;
    :cond_2
    iput-object v2, p1, Ltas/internal/ipc/Receiver;->mToken:Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;

    .line 78
    invoke-virtual {p1}, Ltas/internal/ipc/Receiver;->getContext()Landroid/content/Context;

    move-result-object v3

    invoke-direct {p0, v3}, Ltas/internal/ipc/ReceiverManager;->connectToServer(Landroid/content/Context;)V

    .line 57
    return-void
.end method

.method offline(Ltas/internal/ipc/Receiver;)V
    .locals 7
    .param p1, "receiver"    # Ltas/internal/ipc/Receiver;

    .prologue
    const/4 v6, 0x0

    .line 139
    iget-object v0, p1, Ltas/internal/ipc/Receiver;->mToken:Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;

    .line 140
    .local v0, "rw":Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;
    if-eqz v0, :cond_4

    invoke-static {v0}, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->-get1(Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;)Ljava/util/List;

    move-result-object v3

    invoke-interface {v3, p1}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_4

    .line 142
    const-string/jumbo v3, "TasIPC<ReceiverManager>"

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v5, p1, Ltas/internal/ipc/Receiver;->name:Ljava/lang/String;

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string/jumbo v5, "@"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {p1}, Ltas/internal/ipc/Receiver;->hashCode()I

    move-result v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v4

    .line 143
    const-string/jumbo v5, " offline."

    .line 142
    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v3, v4}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 146
    iget-object v3, p1, Ltas/internal/ipc/Receiver;->mDispatcher:Ltas/internal/ipc/Dispatcher;

    invoke-virtual {v3}, Ltas/internal/ipc/Dispatcher;->deactivate()V

    .line 147
    invoke-static {v0}, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->-get1(Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;)Ljava/util/List;

    move-result-object v3

    invoke-interface {v3, p1}, Ljava/util/List;->remove(Ljava/lang/Object;)Z

    .line 149
    invoke-static {v0}, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->-get5(Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;)Landroid/util/ArrayMap;

    move-result-object v4

    monitor-enter v4

    .line 150
    :try_start_0
    iget-object v3, p1, Ltas/internal/ipc/Receiver;->mWatchList:Ljava/util/List;

    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v2

    .local v2, "watch$iterator":Ljava/util/Iterator;
    :cond_0
    :goto_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_1

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    .line 151
    .local v1, "watch":Ljava/lang/String;
    if-eqz v1, :cond_0

    invoke-direct {p0, p1, v1}, Ltas/internal/ipc/ReceiverManager;->unwatchSenderLocked(Ltas/internal/ipc/Receiver;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    .line 149
    .end local v1    # "watch":Ljava/lang/String;
    .end local v2    # "watch$iterator":Ljava/util/Iterator;
    :catchall_0
    move-exception v3

    monitor-exit v4

    throw v3

    .line 154
    .restart local v2    # "watch$iterator":Ljava/util/Iterator;
    :cond_1
    :try_start_1
    invoke-static {v0}, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->-get3(Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;)Z

    move-result v3

    if-eqz v3, :cond_2

    .line 155
    invoke-direct {p0, p1}, Ltas/internal/ipc/ReceiverManager;->unwatchAnonymousSenderLocked(Ltas/internal/ipc/Receiver;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :cond_2
    monitor-exit v4

    .line 159
    invoke-virtual {v0}, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->dec()I

    .line 160
    invoke-virtual {v0}, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->ref()I

    move-result v3

    if-nez v3, :cond_3

    .line 161
    invoke-direct {p0, v0}, Ltas/internal/ipc/ReceiverManager;->unregisterToServer(Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;)V

    .line 164
    :cond_3
    iput-boolean v6, p1, Ltas/internal/ipc/Receiver;->mOnline:Z

    .line 138
    .end local v2    # "watch$iterator":Ljava/util/Iterator;
    :cond_4
    return-void
.end method

.method public onSenderOffline(Ltas/internal/ipc/server/RemoteReceiver;Ltas/internal/ipc/server/RemoteSender;)V
    .locals 4
    .param p1, "r"    # Ltas/internal/ipc/server/RemoteReceiver;
    .param p2, "s"    # Ltas/internal/ipc/server/RemoteSender;

    .prologue
    .line 311
    const-string/jumbo v1, "TasIPC<ReceiverManager>"

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "sender ["

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, p2, Ltas/internal/ipc/server/RemoteSender;->name:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string/jumbo v3, "] offline"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 312
    invoke-virtual {p1}, Ltas/internal/ipc/server/RemoteReceiver;->getid()J

    move-result-wide v2

    invoke-virtual {p0, v2, v3}, Ltas/internal/ipc/ReceiverManager;->findReceiver(J)Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;

    move-result-object v0

    .line 313
    .local v0, "rw":Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;
    if-nez v0, :cond_0

    .line 314
    const-string/jumbo v1, "TasIPC<ReceiverManager>"

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "local receiver not found => "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, p1, Ltas/internal/ipc/server/RemoteReceiver;->name:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 315
    return-void

    .line 317
    :cond_0
    invoke-static {v0, p2}, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->-wrap2(Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;Ltas/internal/ipc/server/RemoteSender;)V

    .line 310
    return-void
.end method

.method public onSenderOnline(Ltas/internal/ipc/server/RemoteReceiver;Ltas/internal/ipc/server/RemoteSender;)V
    .locals 4
    .param p1, "r"    # Ltas/internal/ipc/server/RemoteReceiver;
    .param p2, "s"    # Ltas/internal/ipc/server/RemoteSender;

    .prologue
    .line 300
    const-string/jumbo v1, "TasIPC<ReceiverManager>"

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "sender ["

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, p2, Ltas/internal/ipc/server/RemoteSender;->name:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string/jumbo v3, "] online"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 301
    invoke-virtual {p1}, Ltas/internal/ipc/server/RemoteReceiver;->getid()J

    move-result-wide v2

    invoke-virtual {p0, v2, v3}, Ltas/internal/ipc/ReceiverManager;->findReceiver(J)Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;

    move-result-object v0

    .line 302
    .local v0, "rw":Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;
    if-nez v0, :cond_0

    .line 303
    const-string/jumbo v1, "TasIPC<ReceiverManager>"

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "local receiver not found => "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, p1, Ltas/internal/ipc/server/RemoteReceiver;->name:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 304
    return-void

    .line 306
    :cond_0
    invoke-static {v0, p2}, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->-wrap3(Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;Ltas/internal/ipc/server/RemoteSender;)V

    .line 299
    return-void
.end method

.method public onSenderUpdate(Ltas/internal/ipc/server/RemoteReceiver;Ltas/internal/ipc/server/RemoteSender;)V
    .locals 4
    .param p1, "r"    # Ltas/internal/ipc/server/RemoteReceiver;
    .param p2, "s"    # Ltas/internal/ipc/server/RemoteSender;

    .prologue
    .line 322
    const-string/jumbo v1, "TasIPC<ReceiverManager>"

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "sender ["

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, p2, Ltas/internal/ipc/server/RemoteSender;->name:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string/jumbo v3, "] update."

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 323
    invoke-virtual {p1}, Ltas/internal/ipc/server/RemoteReceiver;->getid()J

    move-result-wide v2

    invoke-virtual {p0, v2, v3}, Ltas/internal/ipc/ReceiverManager;->findReceiver(J)Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;

    move-result-object v0

    .line 324
    .local v0, "rw":Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;
    if-nez v0, :cond_0

    .line 325
    const-string/jumbo v1, "TasIPC<ReceiverManager>"

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "local receiver not found => "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, p1, Ltas/internal/ipc/server/RemoteReceiver;->name:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 326
    return-void

    .line 328
    :cond_0
    invoke-static {v0, p2}, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->-wrap4(Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;Ltas/internal/ipc/server/RemoteSender;)V

    .line 321
    return-void
.end method

.method online(Ltas/internal/ipc/Receiver;)V
    .locals 7
    .param p1, "receiver"    # Ltas/internal/ipc/Receiver;

    .prologue
    const/4 v6, 0x1

    .line 102
    iget-object v0, p1, Ltas/internal/ipc/Receiver;->mToken:Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;

    .line 103
    .local v0, "rw":Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;
    if-eqz v0, :cond_0

    invoke-static {v0}, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->-get1(Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;)Ljava/util/List;

    move-result-object v3

    invoke-interface {v3, p1}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_1

    .line 101
    :cond_0
    :goto_0
    return-void

    .line 105
    :cond_1
    const-string/jumbo v3, "TasIPC<ReceiverManager>"

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v5, p1, Ltas/internal/ipc/Receiver;->name:Ljava/lang/String;

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string/jumbo v5, "@"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {p1}, Ltas/internal/ipc/Receiver;->hashCode()I

    move-result v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v4

    .line 106
    const-string/jumbo v5, " online."

    .line 105
    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v3, v4}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 109
    iget-object v3, p1, Ltas/internal/ipc/Receiver;->mDispatcher:Ltas/internal/ipc/Dispatcher;

    if-nez v3, :cond_2

    .line 111
    new-instance v3, Ltas/internal/ipc/Dispatcher;

    iget-object v4, p1, Ltas/internal/ipc/Receiver;->mLooper:Landroid/os/Looper;

    invoke-direct {v3, v4, p1}, Ltas/internal/ipc/Dispatcher;-><init>(Landroid/os/Looper;Ltas/internal/ipc/Receiver;)V

    .line 110
    iput-object v3, p1, Ltas/internal/ipc/Receiver;->mDispatcher:Ltas/internal/ipc/Dispatcher;

    .line 113
    :cond_2
    iget-object v3, p1, Ltas/internal/ipc/Receiver;->mDispatcher:Ltas/internal/ipc/Dispatcher;

    invoke-virtual {v3}, Ltas/internal/ipc/Dispatcher;->activate()V

    .line 114
    invoke-static {v0}, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->-get1(Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;)Ljava/util/List;

    move-result-object v3

    invoke-interface {v3, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 115
    invoke-virtual {v0}, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->inc()I

    .line 117
    invoke-virtual {v0}, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->ref()I

    move-result v3

    if-ne v3, v6, :cond_4

    .line 118
    iget-object v3, p1, Ltas/internal/ipc/Receiver;->mExtra:Landroid/os/Bundle;

    invoke-static {v0, v3}, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->-set0(Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;Landroid/os/Bundle;)Landroid/os/Bundle;

    move-result-object v3

    iput-object v3, v0, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->extra:Landroid/os/Bundle;

    .line 119
    invoke-direct {p0, v0}, Ltas/internal/ipc/ReceiverManager;->registerToServer(Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;)V

    .line 124
    :goto_1
    invoke-static {v0}, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->-get5(Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;)Landroid/util/ArrayMap;

    move-result-object v4

    monitor-enter v4

    .line 125
    :try_start_0
    iget-object v3, p1, Ltas/internal/ipc/Receiver;->mWatchList:Ljava/util/List;

    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v2

    .local v2, "watch$iterator":Ljava/util/Iterator;
    :cond_3
    :goto_2
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_5

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    .line 126
    .local v1, "watch":Ljava/lang/String;
    if-eqz v1, :cond_3

    invoke-direct {p0, p1, v1}, Ltas/internal/ipc/ReceiverManager;->watchSenderLocked(Ltas/internal/ipc/Receiver;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_2

    .line 124
    .end local v1    # "watch":Ljava/lang/String;
    .end local v2    # "watch$iterator":Ljava/util/Iterator;
    :catchall_0
    move-exception v3

    monitor-exit v4

    throw v3

    .line 121
    :cond_4
    invoke-static {v0}, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->-get0(Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;)Landroid/os/Bundle;

    move-result-object v3

    iput-object v3, p1, Ltas/internal/ipc/Receiver;->mExtra:Landroid/os/Bundle;

    goto :goto_1

    .line 129
    .restart local v2    # "watch$iterator":Ljava/util/Iterator;
    :cond_5
    :try_start_1
    invoke-static {v0}, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->-get3(Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;)Z

    move-result v3

    if-eqz v3, :cond_6

    .line 130
    invoke-direct {p0, p1}, Ltas/internal/ipc/ReceiverManager;->watchAnonymousSenderLocked(Ltas/internal/ipc/Receiver;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :cond_6
    monitor-exit v4

    .line 134
    iput-boolean v6, p1, Ltas/internal/ipc/Receiver;->mOnline:Z

    goto/16 :goto_0
.end method

.method release(Ltas/internal/ipc/Receiver;)V
    .locals 4
    .param p1, "receiver"    # Ltas/internal/ipc/Receiver;

    .prologue
    .line 83
    const-string/jumbo v1, "TasIPC<ReceiverManager>"

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v3, p1, Ltas/internal/ipc/Receiver;->name:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string/jumbo v3, "@"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {p1}, Ltas/internal/ipc/Receiver;->hashCode()I

    move-result v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    .line 84
    const-string/jumbo v3, " release."

    .line 83
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 87
    invoke-virtual {p0, p1}, Ltas/internal/ipc/ReceiverManager;->offline(Ltas/internal/ipc/Receiver;)V

    .line 88
    iget-object v1, p0, Ltas/internal/ipc/ReceiverManager;->mReceivers:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_0

    .line 89
    invoke-direct {p0, p1}, Ltas/internal/ipc/ReceiverManager;->stopReceiverService(Ltas/internal/ipc/Receiver;)V

    .line 92
    :cond_0
    iget-object v0, p1, Ltas/internal/ipc/Receiver;->mToken:Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;

    .line 93
    .local v0, "rw":Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;
    invoke-virtual {v0}, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->ref()I

    move-result v1

    if-nez v1, :cond_1

    .line 94
    iget-object v1, p0, Ltas/internal/ipc/ReceiverManager;->mReceivers:Ljava/util/List;

    invoke-interface {v1, v0}, Ljava/util/List;->remove(Ljava/lang/Object;)Z

    .line 97
    :cond_1
    const/4 v1, 0x0

    iput-object v1, p1, Ltas/internal/ipc/Receiver;->mToken:Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;

    .line 98
    invoke-direct {p0}, Ltas/internal/ipc/ReceiverManager;->disconnectFromServer()V

    .line 81
    return-void
.end method

.method public declared-synchronized transmit(Ltas/internal/ipc/server/RemoteMessage;)V
    .locals 1
    .param p1, "rmsg"    # Ltas/internal/ipc/server/RemoteMessage;

    .prologue
    monitor-enter p0

    .line 295
    :try_start_0
    invoke-direct {p0, p1}, Ltas/internal/ipc/ReceiverManager;->onReceive(Ltas/internal/ipc/server/RemoteMessage;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit p0

    .line 291
    return-void

    :catchall_0
    move-exception v0

    monitor-exit p0

    throw v0
.end method

.method unwatchAnonymousSender(Ltas/internal/ipc/Receiver;)V
    .locals 3
    .param p1, "receiver"    # Ltas/internal/ipc/Receiver;

    .prologue
    .line 258
    iget-object v0, p1, Ltas/internal/ipc/Receiver;->mToken:Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;

    .line 259
    .local v0, "rw":Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;
    invoke-static {v0}, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->-get5(Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;)Landroid/util/ArrayMap;

    move-result-object v2

    monitor-enter v2

    .line 260
    const/4 v1, 0x0

    :try_start_0
    invoke-static {v0, v1}, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->-set1(Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;Z)Z

    .line 261
    invoke-static {v0}, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->-get4(Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;)I

    move-result v1

    add-int/lit8 v1, v1, -0x1

    invoke-static {v0, v1}, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->-set2(Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;I)I

    .line 262
    invoke-direct {p0, p1}, Ltas/internal/ipc/ReceiverManager;->unwatchAnonymousSenderLocked(Ltas/internal/ipc/Receiver;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit v2

    .line 257
    return-void

    .line 259
    :catchall_0
    move-exception v1

    monitor-exit v2

    throw v1
.end method

.method unwatchSender(Ltas/internal/ipc/Receiver;Ljava/lang/String;)V
    .locals 4
    .param p1, "receiver"    # Ltas/internal/ipc/Receiver;
    .param p2, "sender"    # Ljava/lang/String;

    .prologue
    .line 192
    invoke-virtual {p1, p2}, Ltas/internal/ipc/Receiver;->isWatchingSender(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_0

    .line 193
    return-void

    .line 197
    :cond_0
    const-string/jumbo v1, "TasIPC<ReceiverManager>"

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v3, p1, Ltas/internal/ipc/Receiver;->name:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string/jumbo v3, "@"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {p1}, Ltas/internal/ipc/Receiver;->hashCode()I

    move-result v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    .line 198
    const-string/jumbo v3, " un-watches "

    .line 197
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 201
    iget-object v1, p1, Ltas/internal/ipc/Receiver;->mWatchList:Ljava/util/List;

    invoke-interface {v1, p2}, Ljava/util/List;->remove(Ljava/lang/Object;)Z

    .line 203
    iget-object v0, p1, Ltas/internal/ipc/Receiver;->mToken:Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;

    .line 204
    .local v0, "rw":Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;
    if-eqz v0, :cond_1

    .line 205
    invoke-static {v0}, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->-get5(Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;)Landroid/util/ArrayMap;

    move-result-object v1

    monitor-enter v1

    .line 206
    :try_start_0
    invoke-direct {p0, p1, p2}, Ltas/internal/ipc/ReceiverManager;->unwatchSenderLocked(Ltas/internal/ipc/Receiver;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit v1

    .line 191
    :cond_1
    return-void

    .line 205
    :catchall_0
    move-exception v2

    monitor-exit v1

    throw v2
.end method

.method watchAnonymousSender(Ltas/internal/ipc/Receiver;)V
    .locals 3
    .param p1, "receiver"    # Ltas/internal/ipc/Receiver;

    .prologue
    .line 247
    iget-object v0, p1, Ltas/internal/ipc/Receiver;->mToken:Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;

    .line 248
    .local v0, "rw":Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;
    invoke-static {v0}, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->-get5(Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;)Landroid/util/ArrayMap;

    move-result-object v2

    monitor-enter v2

    .line 249
    const/4 v1, 0x1

    :try_start_0
    invoke-static {v0, v1}, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->-set1(Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;Z)Z

    .line 250
    invoke-static {v0}, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->-get4(Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;)I

    move-result v1

    add-int/lit8 v1, v1, 0x1

    invoke-static {v0, v1}, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->-set2(Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;I)I

    .line 251
    iget-boolean v1, p1, Ltas/internal/ipc/Receiver;->mOnline:Z

    if-eqz v1, :cond_0

    .line 252
    invoke-direct {p0, p1}, Ltas/internal/ipc/ReceiverManager;->watchAnonymousSenderLocked(Ltas/internal/ipc/Receiver;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_0
    monitor-exit v2

    .line 246
    return-void

    .line 248
    :catchall_0
    move-exception v1

    monitor-exit v2

    throw v1
.end method

.method watchSender(Ltas/internal/ipc/Receiver;Ljava/lang/String;)V
    .locals 4
    .param p1, "receiver"    # Ltas/internal/ipc/Receiver;
    .param p2, "sender"    # Ljava/lang/String;

    .prologue
    .line 169
    invoke-virtual {p1, p2}, Ltas/internal/ipc/Receiver;->isWatchingSender(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_0

    .line 170
    return-void

    .line 174
    :cond_0
    const-string/jumbo v1, "TasIPC<ReceiverManager>"

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, ""

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, p1, Ltas/internal/ipc/Receiver;->name:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string/jumbo v3, "@"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {p1}, Ltas/internal/ipc/Receiver;->hashCode()I

    move-result v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    .line 175
    const-string/jumbo v3, " watches "

    .line 174
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 178
    iget-object v1, p1, Ltas/internal/ipc/Receiver;->mWatchList:Ljava/util/List;

    invoke-interface {v1, p2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 179
    iget-boolean v1, p1, Ltas/internal/ipc/Receiver;->mOnline:Z

    if-nez v1, :cond_1

    .line 180
    return-void

    .line 183
    :cond_1
    iget-object v0, p1, Ltas/internal/ipc/Receiver;->mToken:Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;

    .line 184
    .local v0, "rw":Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;
    if-eqz v0, :cond_2

    .line 185
    invoke-static {v0}, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->-get5(Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;)Landroid/util/ArrayMap;

    move-result-object v1

    monitor-enter v1

    .line 186
    :try_start_0
    invoke-direct {p0, p1, p2}, Ltas/internal/ipc/ReceiverManager;->watchSenderLocked(Ltas/internal/ipc/Receiver;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit v1

    .line 168
    :cond_2
    return-void

    .line 185
    :catchall_0
    move-exception v2

    monitor-exit v1

    throw v2
.end method
