.class public Ltas/internal/camera/InputSource$Dummy;
.super Ltas/internal/camera/InputSource;
.source "InputSource.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltas/internal/camera/InputSource;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "Dummy"
.end annotation


# direct methods
.method public constructor <init>(I)V
    .locals 0
    .param p1, "maxinputs"    # I

    .prologue
    .line 330
    invoke-direct {p0, p1}, Ltas/internal/camera/InputSource;-><init>(I)V

    return-void
.end method

.method public constructor <init>(Ljava/lang/Class;Ljava/lang/String;)V
    .locals 0
    .param p2, "id"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Class",
            "<*>;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .prologue
    .line 331
    .local p1, "c":Ljava/lang/Class;, "Ljava/lang/Class<*>;"
    invoke-direct {p0, p1, p2}, Ltas/internal/camera/InputSource;-><init>(Ljava/lang/Class;Ljava/lang/String;)V

    return-void
.end method
