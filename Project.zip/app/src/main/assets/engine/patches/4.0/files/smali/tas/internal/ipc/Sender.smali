.class public Ltas/internal/ipc/Sender;
.super Ljava/lang/Object;
.source "Sender.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ltas/internal/ipc/Sender$AnonymousCallback;,
        Ltas/internal/ipc/Sender$AnonymousSession;
    }
.end annotation


# instance fields
.field private mAnonymousCallback:Ltas/internal/ipc/Sender$AnonymousCallback;

.field private mContext:Landroid/content/Context;

.field mDispatcher:Ltas/internal/ipc/Dispatcher;

.field mExtra:Landroid/os/Bundle;

.field mLooper:Landroid/os/Looper;

.field private mMgr:Ltas/internal/ipc/SenderManager;

.field mOnline:Z

.field private final mRequestedSessions:Landroid/util/ArrayMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/util/ArrayMap",
            "<",
            "Ljava/lang/String;",
            "Ltas/ipc/SenderSession$Callback;",
            ">;"
        }
    .end annotation
.end field

.field private final mSessions:Landroid/util/ArrayMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/util/ArrayMap",
            "<",
            "Ljava/lang/Long;",
            "Ltas/ipc/SenderSession;",
            ">;"
        }
    .end annotation
.end field

.field mToken:Ltas/internal/ipc/SenderManager$SenderWrapper;

.field final mWatchList:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List",
            "<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field public final name:Ljava/lang/String;

.field public final pkg:Ljava/lang/String;


# direct methods
.method public constructor <init>(Landroid/content/Context;Ljava/lang/String;Landroid/os/Looper;)V
    .locals 1
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "name"    # Ljava/lang/String;
    .param p3, "looper"    # Landroid/os/Looper;

    .prologue
    .line 44
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 29
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Ltas/internal/ipc/Sender;->mWatchList:Ljava/util/List;

    .line 39
    new-instance v0, Landroid/util/ArrayMap;

    invoke-direct {v0}, Landroid/util/ArrayMap;-><init>()V

    .line 38
    iput-object v0, p0, Ltas/internal/ipc/Sender;->mSessions:Landroid/util/ArrayMap;

    .line 42
    new-instance v0, Landroid/util/ArrayMap;

    invoke-direct {v0}, Landroid/util/ArrayMap;-><init>()V

    .line 41
    iput-object v0, p0, Ltas/internal/ipc/Sender;->mRequestedSessions:Landroid/util/ArrayMap;

    .line 45
    iput-object p1, p0, Ltas/internal/ipc/Sender;->mContext:Landroid/content/Context;

    .line 46
    iput-object p3, p0, Ltas/internal/ipc/Sender;->mLooper:Landroid/os/Looper;

    .line 47
    iput-object p2, p0, Ltas/internal/ipc/Sender;->name:Ljava/lang/String;

    .line 48
    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Ltas/internal/ipc/Sender;->pkg:Ljava/lang/String;

    .line 49
    invoke-virtual {p0}, Ltas/internal/ipc/Sender;->initialize()V

    .line 44
    return-void
.end method

.method public static isMultiReceiverThread()Z
    .locals 1

    .prologue
    .line 243
    invoke-static {}, Ltas/internal/ipc/SenderManager;->get()Ltas/internal/ipc/SenderManager;

    move-result-object v0

    invoke-virtual {v0}, Ltas/internal/ipc/SenderManager;->isMultiReceiverThread()Z

    move-result v0

    return v0
.end method

.method public static setMultiReceiverThread(Z)V
    .locals 1
    .param p0, "multi"    # Z

    .prologue
    .line 239
    invoke-static {}, Ltas/internal/ipc/SenderManager;->get()Ltas/internal/ipc/SenderManager;

    move-result-object v0

    invoke-virtual {v0, p0}, Ltas/internal/ipc/SenderManager;->setMultiReceiverThread(Z)V

    .line 238
    return-void
.end method


# virtual methods
.method addSession(JLtas/ipc/SenderSession;)V
    .locals 3
    .param p1, "id"    # J
    .param p3, "session"    # Ltas/ipc/SenderSession;

    .prologue
    .line 173
    iget-object v0, p0, Ltas/internal/ipc/Sender;->mSessions:Landroid/util/ArrayMap;

    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    invoke-virtual {v0, v1, p3}, Landroid/util/ArrayMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 172
    return-void
.end method

.method public destroyAnonymousSession()V
    .locals 2

    .prologue
    const/4 v1, 0x0

    .line 107
    iget-object v0, p0, Ltas/internal/ipc/Sender;->mMgr:Ltas/internal/ipc/SenderManager;

    if-eqz v0, :cond_0

    iget-object v0, p0, Ltas/internal/ipc/Sender;->mAnonymousCallback:Ltas/internal/ipc/Sender$AnonymousCallback;

    if-eqz v0, :cond_0

    .line 108
    iget-object v0, p0, Ltas/internal/ipc/Sender;->mAnonymousCallback:Ltas/internal/ipc/Sender$AnonymousCallback;

    invoke-static {v0, v1}, Ltas/internal/ipc/Sender$AnonymousCallback;->-wrap0(Ltas/internal/ipc/Sender$AnonymousCallback;Ltas/ipc/SenderSession$Callback;)V

    .line 109
    iput-object v1, p0, Ltas/internal/ipc/Sender;->mAnonymousCallback:Ltas/internal/ipc/Sender$AnonymousCallback;

    .line 110
    iget-object v0, p0, Ltas/internal/ipc/Sender;->mMgr:Ltas/internal/ipc/SenderManager;

    invoke-virtual {v0, p0}, Ltas/internal/ipc/SenderManager;->unwatchAnonymousReceiver(Ltas/internal/ipc/Sender;)V

    .line 106
    :cond_0
    return-void
.end method

.method public destroySession(J)V
    .locals 3
    .param p1, "id"    # J

    .prologue
    .line 76
    iget-object v1, p0, Ltas/internal/ipc/Sender;->mMgr:Ltas/internal/ipc/SenderManager;

    if-nez v1, :cond_0

    .line 77
    return-void

    .line 79
    :cond_0
    invoke-virtual {p0, p1, p2}, Ltas/internal/ipc/Sender;->removeSession(J)Ltas/ipc/SenderSession;

    move-result-object v0

    .line 80
    .local v0, "session":Ltas/ipc/SenderSession;
    if-eqz v0, :cond_1

    .line 81
    iget-object v1, p0, Ltas/internal/ipc/Sender;->mDispatcher:Ltas/internal/ipc/Dispatcher;

    const/16 v2, 0x66

    invoke-virtual {v1, v2, v0}, Ltas/internal/ipc/Dispatcher;->dispatch(ILtas/ipc/SenderSession;)V

    .line 82
    iget-object v1, p0, Ltas/internal/ipc/Sender;->mRequestedSessions:Landroid/util/ArrayMap;

    iget-object v2, v0, Ltas/ipc/SenderSession;->name:Ljava/lang/String;

    invoke-virtual {v1, v2}, Landroid/util/ArrayMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 83
    iget-object v1, p0, Ltas/internal/ipc/Sender;->mMgr:Ltas/internal/ipc/SenderManager;

    iget-object v2, v0, Ltas/ipc/SenderSession;->name:Ljava/lang/String;

    invoke-virtual {v1, p0, v2}, Ltas/internal/ipc/SenderManager;->unwatchReceiver(Ltas/internal/ipc/Sender;Ljava/lang/String;)V

    .line 75
    :cond_1
    return-void
.end method

.method dispatchOffline(Ltas/ipc/SenderSession;)V
    .locals 2
    .param p1, "session"    # Ltas/ipc/SenderSession;

    .prologue
    .line 199
    iget-object v0, p1, Ltas/ipc/SenderSession;->cb:Ltas/ipc/SenderSession$Callback;

    .line 200
    .local v0, "cb":Ltas/ipc/SenderSession$Callback;
    if-eqz v0, :cond_0

    .line 201
    invoke-interface {v0, p1}, Ltas/ipc/SenderSession$Callback;->onReceiverOffline(Ltas/ipc/SenderSession;)V

    .line 203
    :cond_0
    iget-object v1, p0, Ltas/internal/ipc/Sender;->mAnonymousCallback:Ltas/internal/ipc/Sender$AnonymousCallback;

    if-eqz v1, :cond_1

    .line 204
    iget-object v1, p0, Ltas/internal/ipc/Sender;->mAnonymousCallback:Ltas/internal/ipc/Sender$AnonymousCallback;

    invoke-virtual {v1, p1}, Ltas/internal/ipc/Sender$AnonymousCallback;->onReceiverOffline(Ltas/ipc/SenderSession;)V

    .line 198
    :cond_1
    return-void
.end method

.method dispatchOnline(Ltas/ipc/SenderSession;)V
    .locals 3
    .param p1, "session"    # Ltas/ipc/SenderSession;

    .prologue
    .line 185
    iget-object v0, p1, Ltas/ipc/SenderSession;->cb:Ltas/ipc/SenderSession$Callback;

    .line 186
    .local v0, "cb":Ltas/ipc/SenderSession$Callback;
    if-nez v0, :cond_0

    .line 187
    iget-object v1, p0, Ltas/internal/ipc/Sender;->mRequestedSessions:Landroid/util/ArrayMap;

    iget-object v2, p1, Ltas/ipc/SenderSession;->name:Ljava/lang/String;

    invoke-virtual {v1, v2}, Landroid/util/ArrayMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "cb":Ltas/ipc/SenderSession$Callback;
    check-cast v0, Ltas/ipc/SenderSession$Callback;

    .line 188
    .restart local v0    # "cb":Ltas/ipc/SenderSession$Callback;
    iput-object v0, p1, Ltas/ipc/SenderSession;->cb:Ltas/ipc/SenderSession$Callback;

    .line 190
    :cond_0
    if-eqz v0, :cond_1

    .line 191
    invoke-interface {v0, p1}, Ltas/ipc/SenderSession$Callback;->onReceiverOnline(Ltas/ipc/SenderSession;)V

    .line 193
    :cond_1
    iget-object v1, p0, Ltas/internal/ipc/Sender;->mAnonymousCallback:Ltas/internal/ipc/Sender$AnonymousCallback;

    if-eqz v1, :cond_2

    .line 194
    iget-object v1, p0, Ltas/internal/ipc/Sender;->mAnonymousCallback:Ltas/internal/ipc/Sender$AnonymousCallback;

    invoke-virtual {v1, p1}, Ltas/internal/ipc/Sender$AnonymousCallback;->onReceiverOnline(Ltas/ipc/SenderSession;)V

    .line 184
    :cond_2
    return-void
.end method

.method dispatchReply(Ltas/ipc/SenderSession;Ltas/ipc/MsgData;)V
    .locals 2
    .param p1, "session"    # Ltas/ipc/SenderSession;
    .param p2, "msg"    # Ltas/ipc/MsgData;

    .prologue
    .line 219
    iget-object v0, p1, Ltas/ipc/SenderSession;->cb:Ltas/ipc/SenderSession$Callback;

    .line 220
    .local v0, "cb":Ltas/ipc/SenderSession$Callback;
    if-eqz v0, :cond_0

    .line 221
    iget v1, p2, Ltas/ipc/MsgData;->what:I

    invoke-interface {v0, p1, v1, p2}, Ltas/ipc/SenderSession$Callback;->onReply(Ltas/ipc/SenderSession;ILtas/ipc/MsgData;)V

    .line 218
    :cond_0
    return-void
.end method

.method dispatchUpdate(Ltas/ipc/SenderSession;)V
    .locals 3
    .param p1, "session"    # Ltas/ipc/SenderSession;

    .prologue
    .line 209
    iget-object v0, p1, Ltas/ipc/SenderSession;->cb:Ltas/ipc/SenderSession$Callback;

    .line 210
    .local v0, "cb":Ltas/ipc/SenderSession$Callback;
    if-eqz v0, :cond_0

    .line 211
    iget-object v1, p1, Ltas/ipc/SenderSession;->extra:Landroid/os/Bundle;

    invoke-interface {v0, p1, v1}, Ltas/ipc/SenderSession$Callback;->onReceiverUpdate(Ltas/ipc/SenderSession;Landroid/os/Bundle;)V

    .line 213
    :cond_0
    iget-object v1, p0, Ltas/internal/ipc/Sender;->mAnonymousCallback:Ltas/internal/ipc/Sender$AnonymousCallback;

    if-eqz v1, :cond_1

    .line 214
    iget-object v1, p0, Ltas/internal/ipc/Sender;->mAnonymousCallback:Ltas/internal/ipc/Sender$AnonymousCallback;

    iget-object v2, p1, Ltas/ipc/SenderSession;->extra:Landroid/os/Bundle;

    invoke-virtual {v1, p1, v2}, Ltas/internal/ipc/Sender$AnonymousCallback;->onReceiverUpdate(Ltas/ipc/SenderSession;Landroid/os/Bundle;)V

    .line 208
    :cond_1
    return-void
.end method

.method public getContext()Landroid/content/Context;
    .locals 1

    .prologue
    .line 53
    iget-object v0, p0, Ltas/internal/ipc/Sender;->mContext:Landroid/content/Context;

    return-object v0
.end method

.method public getExtra()Landroid/os/Bundle;
    .locals 1

    .prologue
    .line 123
    iget-object v0, p0, Ltas/internal/ipc/Sender;->mExtra:Landroid/os/Bundle;

    if-nez v0, :cond_0

    .line 124
    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    iput-object v0, p0, Ltas/internal/ipc/Sender;->mExtra:Landroid/os/Bundle;

    .line 126
    :cond_0
    iget-object v0, p0, Ltas/internal/ipc/Sender;->mExtra:Landroid/os/Bundle;

    return-object v0
.end method

.method getSession(J)Ltas/ipc/SenderSession;
    .locals 3
    .param p1, "id"    # J

    .prologue
    .line 165
    iget-object v0, p0, Ltas/internal/ipc/Sender;->mSessions:Landroid/util/ArrayMap;

    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/util/ArrayMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/ipc/SenderSession;

    return-object v0
.end method

.method getSessions()Ljava/util/Collection;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Collection",
            "<",
            "Ltas/ipc/SenderSession;",
            ">;"
        }
    .end annotation

    .prologue
    .line 169
    iget-object v0, p0, Ltas/internal/ipc/Sender;->mSessions:Landroid/util/ArrayMap;

    invoke-virtual {v0}, Landroid/util/ArrayMap;->values()Ljava/util/Collection;

    move-result-object v0

    return-object v0
.end method

.method hasAnonymousSession()Z
    .locals 1

    .prologue
    .line 181
    iget-object v0, p0, Ltas/internal/ipc/Sender;->mAnonymousCallback:Ltas/internal/ipc/Sender$AnonymousCallback;

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    :goto_0
    return v0

    :cond_0
    const/4 v0, 0x0

    goto :goto_0
.end method

.method public initialize()V
    .locals 1

    .prologue
    .line 142
    iget-object v0, p0, Ltas/internal/ipc/Sender;->mMgr:Ltas/internal/ipc/SenderManager;

    if-nez v0, :cond_0

    .line 143
    invoke-static {}, Ltas/internal/ipc/SenderManager;->get()Ltas/internal/ipc/SenderManager;

    move-result-object v0

    iput-object v0, p0, Ltas/internal/ipc/Sender;->mMgr:Ltas/internal/ipc/SenderManager;

    .line 144
    iget-object v0, p0, Ltas/internal/ipc/Sender;->mMgr:Ltas/internal/ipc/SenderManager;

    invoke-virtual {v0, p0}, Ltas/internal/ipc/SenderManager;->initialize(Ltas/internal/ipc/Sender;)V

    .line 141
    :cond_0
    return-void
.end method

.method public isInitialized()Z
    .locals 1

    .prologue
    .line 157
    iget-object v0, p0, Ltas/internal/ipc/Sender;->mMgr:Ltas/internal/ipc/SenderManager;

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    :goto_0
    return v0

    :cond_0
    const/4 v0, 0x0

    goto :goto_0
.end method

.method public isOnline()Z
    .locals 1

    .prologue
    .line 65
    iget-boolean v0, p0, Ltas/internal/ipc/Sender;->mOnline:Z

    return v0
.end method

.method isWatchingReceiver(Ljava/lang/String;)Z
    .locals 1
    .param p1, "receiver"    # Ljava/lang/String;

    .prologue
    .line 161
    iget-object v0, p0, Ltas/internal/ipc/Sender;->mWatchList:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v0

    return v0
.end method

.method public offline()V
    .locals 1

    .prologue
    .line 61
    iget-object v0, p0, Ltas/internal/ipc/Sender;->mMgr:Ltas/internal/ipc/SenderManager;

    if-eqz v0, :cond_0

    iget-object v0, p0, Ltas/internal/ipc/Sender;->mMgr:Ltas/internal/ipc/SenderManager;

    invoke-virtual {v0, p0}, Ltas/internal/ipc/SenderManager;->offline(Ltas/internal/ipc/Sender;)V

    .line 60
    :cond_0
    return-void
.end method

.method public online()V
    .locals 1

    .prologue
    .line 57
    iget-object v0, p0, Ltas/internal/ipc/Sender;->mMgr:Ltas/internal/ipc/SenderManager;

    if-eqz v0, :cond_0

    iget-object v0, p0, Ltas/internal/ipc/Sender;->mMgr:Ltas/internal/ipc/SenderManager;

    invoke-virtual {v0, p0}, Ltas/internal/ipc/SenderManager;->online(Ltas/internal/ipc/Sender;)V

    .line 56
    :cond_0
    return-void
.end method

.method public peekExtra()Landroid/os/Bundle;
    .locals 1

    .prologue
    .line 130
    iget-object v0, p0, Ltas/internal/ipc/Sender;->mExtra:Landroid/os/Bundle;

    return-object v0
.end method

.method public release()V
    .locals 2

    .prologue
    const/4 v1, 0x0

    .line 149
    iget-object v0, p0, Ltas/internal/ipc/Sender;->mMgr:Ltas/internal/ipc/SenderManager;

    if-eqz v0, :cond_0

    .line 150
    iget-object v0, p0, Ltas/internal/ipc/Sender;->mMgr:Ltas/internal/ipc/SenderManager;

    invoke-virtual {v0, p0}, Ltas/internal/ipc/SenderManager;->release(Ltas/internal/ipc/Sender;)V

    .line 151
    iput-object v1, p0, Ltas/internal/ipc/Sender;->mMgr:Ltas/internal/ipc/SenderManager;

    .line 152
    iget-object v0, p0, Ltas/internal/ipc/Sender;->mWatchList:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->clear()V

    .line 148
    :cond_0
    return-void
.end method

.method removeSession(J)Ltas/ipc/SenderSession;
    .locals 3
    .param p1, "id"    # J

    .prologue
    .line 177
    iget-object v0, p0, Ltas/internal/ipc/Sender;->mSessions:Landroid/util/ArrayMap;

    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/util/ArrayMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/ipc/SenderSession;

    return-object v0
.end method

.method public requestAnonymousSession(Ltas/ipc/SenderSession$Callback;)V
    .locals 2
    .param p1, "cb"    # Ltas/ipc/SenderSession$Callback;

    .prologue
    const/4 v1, 0x0

    .line 88
    iget-object v0, p0, Ltas/internal/ipc/Sender;->mMgr:Ltas/internal/ipc/SenderManager;

    if-eqz v0, :cond_1

    .line 89
    iget-object v0, p0, Ltas/internal/ipc/Sender;->mAnonymousCallback:Ltas/internal/ipc/Sender$AnonymousCallback;

    if-nez v0, :cond_0

    .line 90
    new-instance v0, Ltas/internal/ipc/Sender$AnonymousCallback;

    invoke-direct {v0, p0, v1}, Ltas/internal/ipc/Sender$AnonymousCallback;-><init>(Ltas/internal/ipc/Sender;Ltas/internal/ipc/Sender$AnonymousCallback;)V

    iput-object v0, p0, Ltas/internal/ipc/Sender;->mAnonymousCallback:Ltas/internal/ipc/Sender$AnonymousCallback;

    .line 92
    :cond_0
    iget-object v0, p0, Ltas/internal/ipc/Sender;->mAnonymousCallback:Ltas/internal/ipc/Sender$AnonymousCallback;

    invoke-static {v0, p1}, Ltas/internal/ipc/Sender$AnonymousCallback;->-wrap0(Ltas/internal/ipc/Sender$AnonymousCallback;Ltas/ipc/SenderSession$Callback;)V

    .line 93
    iget-object v0, p0, Ltas/internal/ipc/Sender;->mMgr:Ltas/internal/ipc/SenderManager;

    invoke-virtual {v0, p0}, Ltas/internal/ipc/SenderManager;->watchAnonymousReceiver(Ltas/internal/ipc/Sender;)V

    .line 87
    :cond_1
    return-void
.end method

.method public requestAnonymousSessionLazily(Ltas/ipc/SenderSession$Callback;)Ltas/ipc/SenderSession;
    .locals 2
    .param p1, "cb"    # Ltas/ipc/SenderSession$Callback;

    .prologue
    const/4 v1, 0x0

    .line 98
    invoke-virtual {p0, p1}, Ltas/internal/ipc/Sender;->requestAnonymousSession(Ltas/ipc/SenderSession$Callback;)V

    .line 99
    iget-object v0, p0, Ltas/internal/ipc/Sender;->mAnonymousCallback:Ltas/internal/ipc/Sender$AnonymousCallback;

    if-eqz v0, :cond_0

    .line 100
    iget-object v0, p0, Ltas/internal/ipc/Sender;->mAnonymousCallback:Ltas/internal/ipc/Sender$AnonymousCallback;

    invoke-static {v0}, Ltas/internal/ipc/Sender$AnonymousCallback;->-wrap1(Ltas/internal/ipc/Sender$AnonymousCallback;)V

    .line 101
    iget-object v0, p0, Ltas/internal/ipc/Sender;->mAnonymousCallback:Ltas/internal/ipc/Sender$AnonymousCallback;

    invoke-static {v0}, Ltas/internal/ipc/Sender$AnonymousCallback;->-get0(Ltas/internal/ipc/Sender$AnonymousCallback;)Ltas/internal/ipc/Sender$AnonymousSession;

    move-result-object v0

    return-object v0

    .line 103
    :cond_0
    return-object v1
.end method

.method public requestSession(Ljava/lang/String;Ltas/ipc/SenderSession$Callback;)V
    .locals 1
    .param p1, "name"    # Ljava/lang/String;
    .param p2, "cb"    # Ltas/ipc/SenderSession$Callback;

    .prologue
    .line 69
    iget-object v0, p0, Ltas/internal/ipc/Sender;->mMgr:Ltas/internal/ipc/SenderManager;

    if-eqz v0, :cond_0

    iget-object v0, p0, Ltas/internal/ipc/Sender;->mRequestedSessions:Landroid/util/ArrayMap;

    invoke-virtual {v0, p1}, Landroid/util/ArrayMap;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    .line 68
    :cond_0
    :goto_0
    return-void

    .line 70
    :cond_1
    iget-object v0, p0, Ltas/internal/ipc/Sender;->mRequestedSessions:Landroid/util/ArrayMap;

    invoke-virtual {v0, p1, p2}, Landroid/util/ArrayMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 71
    iget-object v0, p0, Ltas/internal/ipc/Sender;->mMgr:Ltas/internal/ipc/SenderManager;

    invoke-virtual {v0, p0, p1}, Ltas/internal/ipc/SenderManager;->watchReceiver(Ltas/internal/ipc/Sender;Ljava/lang/String;)V

    goto :goto_0
.end method

.method public send(Ltas/ipc/SenderSession;Ltas/ipc/MsgData;)V
    .locals 1
    .param p1, "session"    # Ltas/ipc/SenderSession;
    .param p2, "msg"    # Ltas/ipc/MsgData;

    .prologue
    .line 115
    iget-object v0, p0, Ltas/internal/ipc/Sender;->mToken:Ltas/internal/ipc/SenderManager$SenderWrapper;

    if-nez v0, :cond_0

    .line 116
    invoke-virtual {p2}, Ltas/ipc/MsgData;->recycle()V

    .line 117
    return-void

    .line 119
    :cond_0
    iget-object v0, p0, Ltas/internal/ipc/Sender;->mToken:Ltas/internal/ipc/SenderManager$SenderWrapper;

    invoke-virtual {v0, p0, p1, p2}, Ltas/internal/ipc/SenderManager$SenderWrapper;->send(Ltas/internal/ipc/Sender;Ltas/ipc/SenderSession;Ltas/ipc/MsgData;)V

    .line 114
    return-void
.end method

.method public setExtra(Landroid/os/Bundle;)V
    .locals 0
    .param p1, "extra"    # Landroid/os/Bundle;

    .prologue
    .line 134
    iput-object p1, p0, Ltas/internal/ipc/Sender;->mExtra:Landroid/os/Bundle;

    .line 133
    return-void
.end method

.method public update()V
    .locals 1

    .prologue
    .line 138
    iget-object v0, p0, Ltas/internal/ipc/Sender;->mToken:Ltas/internal/ipc/SenderManager$SenderWrapper;

    if-eqz v0, :cond_0

    iget-object v0, p0, Ltas/internal/ipc/Sender;->mToken:Ltas/internal/ipc/SenderManager$SenderWrapper;

    invoke-virtual {v0, p0}, Ltas/internal/ipc/SenderManager$SenderWrapper;->update(Ltas/internal/ipc/Sender;)V

    .line 137
    :cond_0
    return-void
.end method
