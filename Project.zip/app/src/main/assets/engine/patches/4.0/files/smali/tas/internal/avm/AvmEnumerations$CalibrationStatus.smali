.class public final enum Ltas/internal/avm/AvmEnumerations$CalibrationStatus;
.super Ljava/lang/Enum;
.source "AvmEnumerations.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltas/internal/avm/AvmEnumerations;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "CalibrationStatus"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum",
        "<",
        "Ltas/internal/avm/AvmEnumerations$CalibrationStatus;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Ltas/internal/avm/AvmEnumerations$CalibrationStatus;

.field public static final enum CALIBRATED:Ltas/internal/avm/AvmEnumerations$CalibrationStatus;

.field public static final enum CALIBRATED_UNKNOWN:Ltas/internal/avm/AvmEnumerations$CalibrationStatus;

.field public static final enum NOT_CALIBRATED:Ltas/internal/avm/AvmEnumerations$CalibrationStatus;


# instance fields
.field private status:I


# direct methods
.method static constructor <clinit>()V
    .locals 6

    .prologue
    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v3, 0x0

    .line 65
    new-instance v0, Ltas/internal/avm/AvmEnumerations$CalibrationStatus;

    const-string/jumbo v1, "NOT_CALIBRATED"

    invoke-direct {v0, v1, v3, v3}, Ltas/internal/avm/AvmEnumerations$CalibrationStatus;-><init>(Ljava/lang/String;II)V

    sput-object v0, Ltas/internal/avm/AvmEnumerations$CalibrationStatus;->NOT_CALIBRATED:Ltas/internal/avm/AvmEnumerations$CalibrationStatus;

    .line 66
    new-instance v0, Ltas/internal/avm/AvmEnumerations$CalibrationStatus;

    const-string/jumbo v1, "CALIBRATED"

    invoke-direct {v0, v1, v4, v4}, Ltas/internal/avm/AvmEnumerations$CalibrationStatus;-><init>(Ljava/lang/String;II)V

    sput-object v0, Ltas/internal/avm/AvmEnumerations$CalibrationStatus;->CALIBRATED:Ltas/internal/avm/AvmEnumerations$CalibrationStatus;

    .line 67
    new-instance v0, Ltas/internal/avm/AvmEnumerations$CalibrationStatus;

    const-string/jumbo v1, "CALIBRATED_UNKNOWN"

    const/4 v2, -0x1

    invoke-direct {v0, v1, v5, v2}, Ltas/internal/avm/AvmEnumerations$CalibrationStatus;-><init>(Ljava/lang/String;II)V

    sput-object v0, Ltas/internal/avm/AvmEnumerations$CalibrationStatus;->CALIBRATED_UNKNOWN:Ltas/internal/avm/AvmEnumerations$CalibrationStatus;

    .line 64
    const/4 v0, 0x3

    new-array v0, v0, [Ltas/internal/avm/AvmEnumerations$CalibrationStatus;

    sget-object v1, Ltas/internal/avm/AvmEnumerations$CalibrationStatus;->NOT_CALIBRATED:Ltas/internal/avm/AvmEnumerations$CalibrationStatus;

    aput-object v1, v0, v3

    sget-object v1, Ltas/internal/avm/AvmEnumerations$CalibrationStatus;->CALIBRATED:Ltas/internal/avm/AvmEnumerations$CalibrationStatus;

    aput-object v1, v0, v4

    sget-object v1, Ltas/internal/avm/AvmEnumerations$CalibrationStatus;->CALIBRATED_UNKNOWN:Ltas/internal/avm/AvmEnumerations$CalibrationStatus;

    aput-object v1, v0, v5

    sput-object v0, Ltas/internal/avm/AvmEnumerations$CalibrationStatus;->$VALUES:[Ltas/internal/avm/AvmEnumerations$CalibrationStatus;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .locals 0
    .param p3, "status"    # I

    .prologue
    .line 70
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 71
    iput p3, p0, Ltas/internal/avm/AvmEnumerations$CalibrationStatus;->status:I

    .line 70
    return-void
.end method

.method public static createFromValue(I)Ltas/internal/avm/AvmEnumerations$CalibrationStatus;
    .locals 5
    .param p0, "status"    # I

    .prologue
    .line 85
    invoke-static {}, Ltas/internal/avm/AvmEnumerations$CalibrationStatus;->values()[Ltas/internal/avm/AvmEnumerations$CalibrationStatus;

    move-result-object v2

    const/4 v1, 0x0

    array-length v3, v2

    :goto_0
    if-ge v1, v3, :cond_1

    aget-object v0, v2, v1

    .line 86
    .local v0, "i":Ltas/internal/avm/AvmEnumerations$CalibrationStatus;
    invoke-virtual {v0}, Ltas/internal/avm/AvmEnumerations$CalibrationStatus;->toInteger()I

    move-result v4

    if-ne v4, p0, :cond_0

    .line 87
    return-object v0

    .line 85
    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    .line 91
    .end local v0    # "i":Ltas/internal/avm/AvmEnumerations$CalibrationStatus;
    :cond_1
    sget-object v1, Ltas/internal/avm/AvmEnumerations$CalibrationStatus;->CALIBRATED_UNKNOWN:Ltas/internal/avm/AvmEnumerations$CalibrationStatus;

    return-object v1
.end method

.method public static getRandomForTest()Ltas/internal/avm/AvmEnumerations$CalibrationStatus;
    .locals 4

    .prologue
    .line 79
    invoke-static {}, Ljava/util/concurrent/ThreadLocalRandom;->current()Ljava/util/concurrent/ThreadLocalRandom;

    move-result-object v1

    .line 80
    .local v1, "random":Ljava/util/concurrent/ThreadLocalRandom;
    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {v1, v2, v3}, Ljava/util/concurrent/ThreadLocalRandom;->nextInt(II)I

    move-result v0

    .line 81
    .local v0, "rand":I
    invoke-static {v0}, Ltas/internal/avm/AvmEnumerations$CalibrationStatus;->createFromValue(I)Ltas/internal/avm/AvmEnumerations$CalibrationStatus;

    move-result-object v2

    return-object v2
.end method

.method public static valueOf(Ljava/lang/String;)Ltas/internal/avm/AvmEnumerations$CalibrationStatus;
    .locals 1
    .param p0, "name"    # Ljava/lang/String;

    .prologue
    .line 64
    const-class v0, Ltas/internal/avm/AvmEnumerations$CalibrationStatus;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object v0

    check-cast v0, Ltas/internal/avm/AvmEnumerations$CalibrationStatus;

    return-object v0
.end method

.method public static values()[Ltas/internal/avm/AvmEnumerations$CalibrationStatus;
    .locals 1

    .prologue
    .line 64
    sget-object v0, Ltas/internal/avm/AvmEnumerations$CalibrationStatus;->$VALUES:[Ltas/internal/avm/AvmEnumerations$CalibrationStatus;

    return-object v0
.end method


# virtual methods
.method public toInteger()I
    .locals 1

    .prologue
    .line 75
    iget v0, p0, Ltas/internal/avm/AvmEnumerations$CalibrationStatus;->status:I

    return v0
.end method
