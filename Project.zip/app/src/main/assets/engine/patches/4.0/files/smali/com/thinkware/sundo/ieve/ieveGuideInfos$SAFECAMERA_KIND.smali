.class public final enum Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;
.super Ljava/lang/Enum;
.source "ieveGuideInfos.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/thinkware/sundo/ieve/ieveGuideInfos;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "SAFECAMERA_KIND"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum",
        "<",
        "Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;",
        ">;"
    }
.end annotation


# static fields
.field public static final enum BOX_OVERSPEED_CAMERA:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;

.field public static final enum FIX_BUS_CAMERA:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;

.field public static final enum FIX_OVERSPEED_CAMERA:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;

.field public static final enum FIX_OVERSPEED_SIGNAL_CAMERA:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;

.field public static final enum FIX_SIGNAL_CAMERA:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;

.field public static final enum FIX_TRAFFIC_CAMERA:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;

.field public static final enum INTERRUPT_CAMERA:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;

.field public static final enum MOV_BUS_CAMERA:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;

.field public static final enum MOV_OVERSPEED_CAMERA:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;

.field public static final enum NONE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;

.field public static final enum OVERLOAD_CAMERA:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;

.field public static final enum SAFEAREA_CAMERA_TUNNEL_CCTV:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;

.field public static final enum SAFEAREA_END_CAMERA:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;

.field public static final enum SAFEAREA_END_CAMERA_CHANGE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;

.field public static final enum SAFEAREA_START_CAMERA:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;

.field public static final enum SAFEAREA_START_CAMERA_CHANGE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;

.field public static final enum STOPAGE_CAMERA:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;

.field public static final enum USER_CAMERA:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;

.field private static final synthetic b:[Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;


# instance fields
.field private final a:I


# direct methods
.method static constructor <clinit>()V
    .locals 9

    .prologue
    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v4, 0x0

    .line 116
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;

    const-string v1, "NONE"

    invoke-direct {v0, v1, v4, v4}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;->NONE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;

    .line 117
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;

    const-string v1, "FIX_OVERSPEED_CAMERA"

    invoke-direct {v0, v1, v5, v5}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;->FIX_OVERSPEED_CAMERA:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;

    .line 118
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;

    const-string v1, "FIX_OVERSPEED_SIGNAL_CAMERA"

    invoke-direct {v0, v1, v6, v6}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;->FIX_OVERSPEED_SIGNAL_CAMERA:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;

    .line 119
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;

    const-string v1, "FIX_SIGNAL_CAMERA"

    invoke-direct {v0, v1, v7, v7}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;->FIX_SIGNAL_CAMERA:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;

    .line 120
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;

    const-string v1, "FIX_BUS_CAMERA"

    invoke-direct {v0, v1, v8, v8}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;->FIX_BUS_CAMERA:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;

    .line 121
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;

    const-string v1, "FIX_TRAFFIC_CAMERA"

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;->FIX_TRAFFIC_CAMERA:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;

    .line 122
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;

    const-string v1, "MOV_OVERSPEED_CAMERA"

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;->MOV_OVERSPEED_CAMERA:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;

    .line 123
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;

    const-string v1, "MOV_BUS_CAMERA"

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;->MOV_BUS_CAMERA:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;

    .line 124
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;

    const-string v1, "STOPAGE_CAMERA"

    const/16 v2, 0x8

    const/16 v3, 0x8

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;->STOPAGE_CAMERA:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;

    .line 125
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;

    const-string v1, "OVERLOAD_CAMERA"

    const/16 v2, 0x9

    const/16 v3, 0x9

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;->OVERLOAD_CAMERA:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;

    .line 126
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;

    const-string v1, "INTERRUPT_CAMERA"

    const/16 v2, 0xa

    const/16 v3, 0xa

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;->INTERRUPT_CAMERA:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;

    .line 127
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;

    const-string v1, "SAFEAREA_START_CAMERA"

    const/16 v2, 0xb

    const/16 v3, 0xb

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;->SAFEAREA_START_CAMERA:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;

    .line 128
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;

    const-string v1, "SAFEAREA_END_CAMERA"

    const/16 v2, 0xc

    const/16 v3, 0xc

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;->SAFEAREA_END_CAMERA:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;

    .line 129
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;

    const-string v1, "BOX_OVERSPEED_CAMERA"

    const/16 v2, 0xd

    const/16 v3, 0xd

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;->BOX_OVERSPEED_CAMERA:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;

    .line 130
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;

    const-string v1, "USER_CAMERA"

    const/16 v2, 0xe

    const/16 v3, 0xe

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;->USER_CAMERA:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;

    .line 131
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;

    const-string v1, "SAFEAREA_START_CAMERA_CHANGE"

    const/16 v2, 0xf

    const/16 v3, 0xf

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;->SAFEAREA_START_CAMERA_CHANGE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;

    .line 132
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;

    const-string v1, "SAFEAREA_END_CAMERA_CHANGE"

    const/16 v2, 0x10

    const/16 v3, 0x10

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;->SAFEAREA_END_CAMERA_CHANGE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;

    .line 133
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;

    const-string v1, "SAFEAREA_CAMERA_TUNNEL_CCTV"

    const/16 v2, 0x11

    const/16 v3, 0x11

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;->SAFEAREA_CAMERA_TUNNEL_CCTV:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;

    .line 115
    const/16 v0, 0x12

    new-array v0, v0, [Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;

    sget-object v1, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;->NONE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;

    aput-object v1, v0, v4

    sget-object v1, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;->FIX_OVERSPEED_CAMERA:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;

    aput-object v1, v0, v5

    sget-object v1, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;->FIX_OVERSPEED_SIGNAL_CAMERA:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;

    aput-object v1, v0, v6

    sget-object v1, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;->FIX_SIGNAL_CAMERA:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;

    aput-object v1, v0, v7

    sget-object v1, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;->FIX_BUS_CAMERA:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;

    aput-object v1, v0, v8

    const/4 v1, 0x5

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;->FIX_TRAFFIC_CAMERA:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;

    aput-object v2, v0, v1

    const/4 v1, 0x6

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;->MOV_OVERSPEED_CAMERA:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;

    aput-object v2, v0, v1

    const/4 v1, 0x7

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;->MOV_BUS_CAMERA:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;

    aput-object v2, v0, v1

    const/16 v1, 0x8

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;->STOPAGE_CAMERA:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;

    aput-object v2, v0, v1

    const/16 v1, 0x9

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;->OVERLOAD_CAMERA:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;

    aput-object v2, v0, v1

    const/16 v1, 0xa

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;->INTERRUPT_CAMERA:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;

    aput-object v2, v0, v1

    const/16 v1, 0xb

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;->SAFEAREA_START_CAMERA:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;

    aput-object v2, v0, v1

    const/16 v1, 0xc

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;->SAFEAREA_END_CAMERA:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;

    aput-object v2, v0, v1

    const/16 v1, 0xd

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;->BOX_OVERSPEED_CAMERA:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;

    aput-object v2, v0, v1

    const/16 v1, 0xe

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;->USER_CAMERA:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;

    aput-object v2, v0, v1

    const/16 v1, 0xf

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;->SAFEAREA_START_CAMERA_CHANGE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;

    aput-object v2, v0, v1

    const/16 v1, 0x10

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;->SAFEAREA_END_CAMERA_CHANGE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;

    aput-object v2, v0, v1

    const/16 v1, 0x11

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;->SAFEAREA_CAMERA_TUNNEL_CCTV:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;

    aput-object v2, v0, v1

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;->b:[Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .locals 0
    .param p3, "value"    # I

    .prologue
    .line 135
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    iput p3, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;->a:I

    return-void
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;
    .locals 1

    .prologue
    .line 1
    const-class v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object v0

    check-cast v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;

    return-object v0
.end method

.method public static values()[Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;
    .locals 4

    .prologue
    const/4 v3, 0x0

    .line 1
    sget-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;->b:[Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;

    array-length v1, v0

    new-array v2, v1, [Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;

    invoke-static {v0, v3, v2, v3, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    return-object v2
.end method


# virtual methods
.method public getValue()I
    .locals 1

    .prologue
    .line 137
    iget v0, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERA_KIND;->a:I

    return v0
.end method
