.class public Ltas/internal/ipc/server/ServerConnection;
.super Ljava/lang/Object;
.source "ServerConnection.java"

# interfaces
.implements Ltas/internal/ipc/util/ServiceConnectionAbstract$Callback;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ltas/internal/ipc/server/ServerConnection$SenderCallback;,
        Ltas/internal/ipc/server/ServerConnection$ReceiverCallback;,
        Ltas/internal/ipc/server/ServerConnection$Connection;,
        Ltas/internal/ipc/server/ServerConnection$ServerCallback;
    }
.end annotation


# static fields
.field private static C:Ltas/internal/ipc/server/ServerConnection$Connection; = null

.field private static final DBG:Z = true

.field private static final TAG:Ljava/lang/String; = "TasIPC<ServerConnection>"


# instance fields
.field private mContext:Landroid/content/Context;

.field private mReconnecting:Z


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 2
    .param p1, "context"    # Landroid/content/Context;

    .prologue
    const/4 v1, 0x0

    .line 48
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 49
    iput-object p1, p0, Ltas/internal/ipc/server/ServerConnection;->mContext:Landroid/content/Context;

    .line 50
    sget-object v0, Ltas/internal/ipc/server/ServerConnection;->C:Ltas/internal/ipc/server/ServerConnection$Connection;

    if-nez v0, :cond_0

    .line 51
    new-instance v0, Ltas/internal/ipc/server/ServerConnection$Connection;

    invoke-direct {v0, v1}, Ltas/internal/ipc/server/ServerConnection$Connection;-><init>(Ltas/internal/ipc/server/ServerConnection$Connection;)V

    sput-object v0, Ltas/internal/ipc/server/ServerConnection;->C:Ltas/internal/ipc/server/ServerConnection$Connection;

    .line 53
    :cond_0
    sget-object v0, Ltas/internal/ipc/server/ServerConnection;->C:Ltas/internal/ipc/server/ServerConnection$Connection;

    invoke-virtual {v0, p0}, Ltas/internal/ipc/server/ServerConnection$Connection;->addCallback(Ltas/internal/ipc/util/ServiceConnectionAbstract$Callback;)V

    .line 48
    return-void
.end method


# virtual methods
.method public connect()V
    .locals 2

    .prologue
    .line 65
    sget-object v0, Ltas/internal/ipc/server/ServerConnection;->C:Ltas/internal/ipc/server/ServerConnection$Connection;

    iget-object v1, p0, Ltas/internal/ipc/server/ServerConnection;->mContext:Landroid/content/Context;

    invoke-static {v0, v1}, Ltas/internal/ipc/server/ServerConnection$Connection;->-wrap0(Ltas/internal/ipc/server/ServerConnection$Connection;Landroid/content/Context;)V

    .line 64
    return-void
.end method

.method public disconnect()V
    .locals 1

    .prologue
    .line 69
    sget-object v0, Ltas/internal/ipc/server/ServerConnection;->C:Ltas/internal/ipc/server/ServerConnection$Connection;

    invoke-virtual {v0}, Ltas/internal/ipc/server/ServerConnection$Connection;->disconnect()V

    .line 68
    return-void
.end method

.method public isConnected()Z
    .locals 1

    .prologue
    .line 61
    sget-object v0, Ltas/internal/ipc/server/ServerConnection;->C:Ltas/internal/ipc/server/ServerConnection$Connection;

    invoke-virtual {v0}, Ltas/internal/ipc/server/ServerConnection$Connection;->isConnected()Z

    move-result v0

    return v0
.end method

.method public onConnected()V
    .locals 1

    .prologue
    .line 74
    iget-boolean v0, p0, Ltas/internal/ipc/server/ServerConnection;->mReconnecting:Z

    if-eqz v0, :cond_0

    .line 75
    const/4 v0, 0x0

    iput-boolean v0, p0, Ltas/internal/ipc/server/ServerConnection;->mReconnecting:Z

    .line 76
    invoke-virtual {p0}, Ltas/internal/ipc/server/ServerConnection;->onReconnected()V

    .line 73
    :cond_0
    return-void
.end method

.method public onDeath()V
    .locals 1

    .prologue
    .line 90
    const/4 v0, 0x1

    iput-boolean v0, p0, Ltas/internal/ipc/server/ServerConnection;->mReconnecting:Z

    .line 91
    invoke-virtual {p0}, Ltas/internal/ipc/server/ServerConnection;->prepareReconnection()V

    .line 89
    return-void
.end method

.method public onDisconnected()V
    .locals 1

    .prologue
    .line 82
    iget-boolean v0, p0, Ltas/internal/ipc/server/ServerConnection;->mReconnecting:Z

    if-nez v0, :cond_0

    .line 83
    const/4 v0, 0x1

    iput-boolean v0, p0, Ltas/internal/ipc/server/ServerConnection;->mReconnecting:Z

    .line 84
    invoke-virtual {p0}, Ltas/internal/ipc/server/ServerConnection;->prepareReconnection()V

    .line 81
    :cond_0
    return-void
.end method

.method protected onReconnected()V
    .locals 0

    .prologue
    .line 94
    return-void
.end method

.method protected prepareReconnection()V
    .locals 0

    .prologue
    .line 97
    return-void
.end method

.method public registerReceiver(Ltas/internal/ipc/server/RemoteReceiver;)V
    .locals 1
    .param p1, "receiver"    # Ltas/internal/ipc/server/RemoteReceiver;

    .prologue
    .line 101
    sget-object v0, Ltas/internal/ipc/server/ServerConnection;->C:Ltas/internal/ipc/server/ServerConnection$Connection;

    invoke-static {v0, p1}, Ltas/internal/ipc/server/ServerConnection$Connection;->-wrap1(Ltas/internal/ipc/server/ServerConnection$Connection;Ltas/internal/ipc/server/RemoteReceiver;)V

    .line 100
    return-void
.end method

.method public registerSender(Ltas/internal/ipc/server/RemoteSender;)V
    .locals 1
    .param p1, "sender"    # Ltas/internal/ipc/server/RemoteSender;

    .prologue
    .line 113
    sget-object v0, Ltas/internal/ipc/server/ServerConnection;->C:Ltas/internal/ipc/server/ServerConnection$Connection;

    invoke-static {v0, p1}, Ltas/internal/ipc/server/ServerConnection$Connection;->-wrap2(Ltas/internal/ipc/server/ServerConnection$Connection;Ltas/internal/ipc/server/RemoteSender;)V

    .line 112
    return-void
.end method

.method public setContext(Landroid/content/Context;)V
    .locals 0
    .param p1, "context"    # Landroid/content/Context;

    .prologue
    .line 57
    iput-object p1, p0, Ltas/internal/ipc/server/ServerConnection;->mContext:Landroid/content/Context;

    .line 56
    return-void
.end method

.method public setReceiverCallback(Ltas/internal/ipc/server/ServerConnection$ReceiverCallback;)V
    .locals 1
    .param p1, "cb"    # Ltas/internal/ipc/server/ServerConnection$ReceiverCallback;

    .prologue
    .line 165
    sget-object v0, Ltas/internal/ipc/server/ServerConnection;->C:Ltas/internal/ipc/server/ServerConnection$Connection;

    invoke-static {v0, p1}, Ltas/internal/ipc/server/ServerConnection$Connection;->-wrap3(Ltas/internal/ipc/server/ServerConnection$Connection;Ltas/internal/ipc/server/ServerConnection$ReceiverCallback;)V

    .line 164
    return-void
.end method

.method public setSenderCallback(Ltas/internal/ipc/server/ServerConnection$SenderCallback;)V
    .locals 1
    .param p1, "cb"    # Ltas/internal/ipc/server/ServerConnection$SenderCallback;

    .prologue
    .line 161
    sget-object v0, Ltas/internal/ipc/server/ServerConnection;->C:Ltas/internal/ipc/server/ServerConnection$Connection;

    invoke-static {v0, p1}, Ltas/internal/ipc/server/ServerConnection$Connection;->-wrap4(Ltas/internal/ipc/server/ServerConnection$Connection;Ltas/internal/ipc/server/ServerConnection$SenderCallback;)V

    .line 160
    return-void
.end method

.method public startWatchingAnonymousReceiver(Ltas/internal/ipc/server/RemoteSender;)V
    .locals 1
    .param p1, "sender"    # Ltas/internal/ipc/server/RemoteSender;

    .prologue
    .line 133
    sget-object v0, Ltas/internal/ipc/server/ServerConnection;->C:Ltas/internal/ipc/server/ServerConnection$Connection;

    invoke-static {v0, p1}, Ltas/internal/ipc/server/ServerConnection$Connection;->-wrap5(Ltas/internal/ipc/server/ServerConnection$Connection;Ltas/internal/ipc/server/RemoteSender;)V

    .line 132
    return-void
.end method

.method public startWatchingAnonymousSender(Ltas/internal/ipc/server/RemoteReceiver;)V
    .locals 1
    .param p1, "receiver"    # Ltas/internal/ipc/server/RemoteReceiver;

    .prologue
    .line 149
    sget-object v0, Ltas/internal/ipc/server/ServerConnection;->C:Ltas/internal/ipc/server/ServerConnection$Connection;

    invoke-static {v0, p1}, Ltas/internal/ipc/server/ServerConnection$Connection;->-wrap6(Ltas/internal/ipc/server/ServerConnection$Connection;Ltas/internal/ipc/server/RemoteReceiver;)V

    .line 148
    return-void
.end method

.method public startWatchingReceiver(Ltas/internal/ipc/server/RemoteSender;)V
    .locals 1
    .param p1, "sender"    # Ltas/internal/ipc/server/RemoteSender;

    .prologue
    .line 125
    sget-object v0, Ltas/internal/ipc/server/ServerConnection;->C:Ltas/internal/ipc/server/ServerConnection$Connection;

    invoke-static {v0, p1}, Ltas/internal/ipc/server/ServerConnection$Connection;->-wrap7(Ltas/internal/ipc/server/ServerConnection$Connection;Ltas/internal/ipc/server/RemoteSender;)V

    .line 124
    return-void
.end method

.method public startWatchingSender(Ltas/internal/ipc/server/RemoteReceiver;)V
    .locals 1
    .param p1, "receiver"    # Ltas/internal/ipc/server/RemoteReceiver;

    .prologue
    .line 141
    sget-object v0, Ltas/internal/ipc/server/ServerConnection;->C:Ltas/internal/ipc/server/ServerConnection$Connection;

    invoke-static {v0, p1}, Ltas/internal/ipc/server/ServerConnection$Connection;->-wrap8(Ltas/internal/ipc/server/ServerConnection$Connection;Ltas/internal/ipc/server/RemoteReceiver;)V

    .line 140
    return-void
.end method

.method public stopWatchingAnonymousReceiver(Ltas/internal/ipc/server/RemoteSender;)V
    .locals 1
    .param p1, "sender"    # Ltas/internal/ipc/server/RemoteSender;

    .prologue
    .line 137
    sget-object v0, Ltas/internal/ipc/server/ServerConnection;->C:Ltas/internal/ipc/server/ServerConnection$Connection;

    invoke-static {v0, p1}, Ltas/internal/ipc/server/ServerConnection$Connection;->-wrap9(Ltas/internal/ipc/server/ServerConnection$Connection;Ltas/internal/ipc/server/RemoteSender;)V

    .line 136
    return-void
.end method

.method public stopWatchingAnonymousSender(Ltas/internal/ipc/server/RemoteReceiver;)V
    .locals 1
    .param p1, "receiver"    # Ltas/internal/ipc/server/RemoteReceiver;

    .prologue
    .line 153
    sget-object v0, Ltas/internal/ipc/server/ServerConnection;->C:Ltas/internal/ipc/server/ServerConnection$Connection;

    invoke-static {v0, p1}, Ltas/internal/ipc/server/ServerConnection$Connection;->-wrap10(Ltas/internal/ipc/server/ServerConnection$Connection;Ltas/internal/ipc/server/RemoteReceiver;)V

    .line 152
    return-void
.end method

.method public stopWatchingReceiver(Ltas/internal/ipc/server/RemoteSender;)V
    .locals 1
    .param p1, "sender"    # Ltas/internal/ipc/server/RemoteSender;

    .prologue
    .line 129
    sget-object v0, Ltas/internal/ipc/server/ServerConnection;->C:Ltas/internal/ipc/server/ServerConnection$Connection;

    invoke-static {v0, p1}, Ltas/internal/ipc/server/ServerConnection$Connection;->-wrap11(Ltas/internal/ipc/server/ServerConnection$Connection;Ltas/internal/ipc/server/RemoteSender;)V

    .line 128
    return-void
.end method

.method public stopWatchingSender(Ltas/internal/ipc/server/RemoteReceiver;)V
    .locals 1
    .param p1, "receiver"    # Ltas/internal/ipc/server/RemoteReceiver;

    .prologue
    .line 145
    sget-object v0, Ltas/internal/ipc/server/ServerConnection;->C:Ltas/internal/ipc/server/ServerConnection$Connection;

    invoke-static {v0, p1}, Ltas/internal/ipc/server/ServerConnection$Connection;->-wrap12(Ltas/internal/ipc/server/ServerConnection$Connection;Ltas/internal/ipc/server/RemoteReceiver;)V

    .line 144
    return-void
.end method

.method public transmit(Ltas/internal/ipc/server/RemoteMessage;)V
    .locals 1
    .param p1, "msg"    # Ltas/internal/ipc/server/RemoteMessage;

    .prologue
    .line 157
    sget-object v0, Ltas/internal/ipc/server/ServerConnection;->C:Ltas/internal/ipc/server/ServerConnection$Connection;

    invoke-static {v0, p1}, Ltas/internal/ipc/server/ServerConnection$Connection;->-wrap13(Ltas/internal/ipc/server/ServerConnection$Connection;Ltas/internal/ipc/server/RemoteMessage;)V

    .line 156
    return-void
.end method

.method public unregisterReceiver(Ltas/internal/ipc/server/RemoteReceiver;)V
    .locals 1
    .param p1, "receiver"    # Ltas/internal/ipc/server/RemoteReceiver;

    .prologue
    .line 105
    sget-object v0, Ltas/internal/ipc/server/ServerConnection;->C:Ltas/internal/ipc/server/ServerConnection$Connection;

    invoke-static {v0, p1}, Ltas/internal/ipc/server/ServerConnection$Connection;->-wrap14(Ltas/internal/ipc/server/ServerConnection$Connection;Ltas/internal/ipc/server/RemoteReceiver;)V

    .line 104
    return-void
.end method

.method public unregisterSender(Ltas/internal/ipc/server/RemoteSender;)V
    .locals 1
    .param p1, "sender"    # Ltas/internal/ipc/server/RemoteSender;

    .prologue
    .line 117
    sget-object v0, Ltas/internal/ipc/server/ServerConnection;->C:Ltas/internal/ipc/server/ServerConnection$Connection;

    invoke-static {v0, p1}, Ltas/internal/ipc/server/ServerConnection$Connection;->-wrap15(Ltas/internal/ipc/server/ServerConnection$Connection;Ltas/internal/ipc/server/RemoteSender;)V

    .line 116
    return-void
.end method

.method public updateReceiver(Ltas/internal/ipc/server/RemoteReceiver;)V
    .locals 1
    .param p1, "receiver"    # Ltas/internal/ipc/server/RemoteReceiver;

    .prologue
    .line 109
    sget-object v0, Ltas/internal/ipc/server/ServerConnection;->C:Ltas/internal/ipc/server/ServerConnection$Connection;

    invoke-static {v0, p1}, Ltas/internal/ipc/server/ServerConnection$Connection;->-wrap16(Ltas/internal/ipc/server/ServerConnection$Connection;Ltas/internal/ipc/server/RemoteReceiver;)V

    .line 108
    return-void
.end method

.method public updateSender(Ltas/internal/ipc/server/RemoteSender;)V
    .locals 1
    .param p1, "sender"    # Ltas/internal/ipc/server/RemoteSender;

    .prologue
    .line 121
    sget-object v0, Ltas/internal/ipc/server/ServerConnection;->C:Ltas/internal/ipc/server/ServerConnection$Connection;

    invoke-static {v0, p1}, Ltas/internal/ipc/server/ServerConnection$Connection;->-wrap17(Ltas/internal/ipc/server/ServerConnection$Connection;Ltas/internal/ipc/server/RemoteSender;)V

    .line 120
    return-void
.end method
