.class public interface abstract Ltas/internal/camera/util/CameraMonitor$Callback;
.super Ljava/lang/Object;
.source "CameraMonitor.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltas/internal/camera/util/CameraMonitor;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "Callback"
.end annotation


# virtual methods
.method public abstract onCameraOpen(Ltas/internal/camera/util/CameraMonitor;I)V
.end method

.method public abstract onCameraRelease(Ltas/internal/camera/util/CameraMonitor;I)V
.end method

.method public abstract onMonitorBinderDied(Ltas/internal/camera/util/CameraMonitor;)V
.end method

.method public abstract onMonitorConnected(Ltas/internal/camera/util/CameraMonitor;)V
.end method

.method public abstract onMonitorDisconnected(Ltas/internal/camera/util/CameraMonitor;)V
.end method

.method public abstract onMonitorError(Ltas/internal/camera/util/CameraMonitor;II)V
.end method

.method public abstract onMonitorReconnected(Ltas/internal/camera/util/CameraMonitor;)V
.end method
