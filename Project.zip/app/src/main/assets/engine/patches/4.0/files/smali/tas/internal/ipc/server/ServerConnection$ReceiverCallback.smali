.class public interface abstract Ltas/internal/ipc/server/ServerConnection$ReceiverCallback;
.super Ljava/lang/Object;
.source "ServerConnection.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltas/internal/ipc/server/ServerConnection;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "ReceiverCallback"
.end annotation


# virtual methods
.method public abstract onSenderOffline(Ltas/internal/ipc/server/RemoteReceiver;Ltas/internal/ipc/server/RemoteSender;)V
.end method

.method public abstract onSenderOnline(Ltas/internal/ipc/server/RemoteReceiver;Ltas/internal/ipc/server/RemoteSender;)V
.end method

.method public abstract onSenderUpdate(Ltas/internal/ipc/server/RemoteReceiver;Ltas/internal/ipc/server/RemoteSender;)V
.end method

.method public abstract transmit(Ltas/internal/ipc/server/RemoteMessage;)V
.end method
