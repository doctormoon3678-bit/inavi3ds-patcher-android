.class public interface abstract Ltas/internal/iobrigade/connector/IRemoteIOEvent;
.super Ljava/lang/Object;
.source "IRemoteIOEvent.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation


# virtual methods
.method public abstract onRemoteEvent(Ltas/internal/iobrigade/connector/IOData;)V
.end method
