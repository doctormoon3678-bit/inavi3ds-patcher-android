.class Lcom/thinkware/sundo/ieve/ieveCameraView$a;
.super Landroid/os/HandlerThread;
.source "ieveCameraView.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/thinkware/sundo/ieve/ieveCameraView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "a"
.end annotation


# instance fields
.field final synthetic a:Lcom/thinkware/sundo/ieve/ieveCameraView;

.field private b:Landroid/os/Handler;

.field private c:Landroid/hardware/Camera;

.field private d:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Lcom/thinkware/sundo/ieve/ieveCameraView;)V
    .locals 2

    .prologue
    const/4 v1, 0x0

    .line 59
    iput-object p1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$a;->a:Lcom/thinkware/sundo/ieve/ieveCameraView;

    .line 60
    const-string v0, "ieveCameraHandlerThread"

    invoke-direct {p0, v0}, Landroid/os/HandlerThread;-><init>(Ljava/lang/String;)V

    .line 55
    iput-object v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$a;->b:Landroid/os/Handler;

    .line 56
    iput-object v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$a;->c:Landroid/hardware/Camera;

    .line 57
    iput-object v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$a;->d:Ljava/lang/Object;

    .line 61
    invoke-static {}, Lcom/thinkware/sundo/ieve/ieveCameraView;->a()Ljava/lang/String;

    move-result-object v0

    const-string v1, "Constructor"

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 63
    invoke-virtual {p0}, Lcom/thinkware/sundo/ieve/ieveCameraView$a;->start()V

    .line 64
    new-instance v0, Landroid/os/Handler;

    invoke-virtual {p0}, Lcom/thinkware/sundo/ieve/ieveCameraView$a;->getLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object v0, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$a;->b:Landroid/os/Handler;

    .line 65
    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$a;->d:Ljava/lang/Object;

    .line 66
    return-void
.end method

.method static synthetic a(Lcom/thinkware/sundo/ieve/ieveCameraView$a;)Ljava/lang/Object;
    .locals 1

    .prologue
    .line 57
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$a;->d:Ljava/lang/Object;

    return-object v0
.end method

.method static synthetic a(Lcom/thinkware/sundo/ieve/ieveCameraView$a;Landroid/hardware/Camera;)V
    .locals 0

    .prologue
    .line 56
    iput-object p1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$a;->c:Landroid/hardware/Camera;

    return-void
.end method


# virtual methods
.method public a()Landroid/hardware/Camera;
    .locals 4

    .prologue
    .line 70
    iget-object v2, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$a;->d:Ljava/lang/Object;

    monitor-enter v2

    .line 71
    :try_start_0
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$a;->b:Landroid/os/Handler;

    if-nez v1, :cond_0

    iget-object v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$a;->c:Landroid/hardware/Camera;

    monitor-exit v2

    .line 93
    :goto_0
    return-object v1

    .line 72
    :cond_0
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$a;->b:Landroid/os/Handler;

    new-instance v3, Lcom/thinkware/sundo/ieve/ieveCameraView$a$1;

    invoke-direct {v3, p0}, Lcom/thinkware/sundo/ieve/ieveCameraView$a$1;-><init>(Lcom/thinkware/sundo/ieve/ieveCameraView$a;)V

    invoke-virtual {v1, v3}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 87
    :try_start_1
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$a;->d:Ljava/lang/Object;

    invoke-virtual {v1}, Ljava/lang/Object;->wait()V
    :try_end_1
    .catch Ljava/lang/InterruptedException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 70
    :goto_1
    :try_start_2
    monitor-exit v2
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 93
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$a;->c:Landroid/hardware/Camera;

    goto :goto_0

    .line 88
    :catch_0
    move-exception v0

    .line 89
    .local v0, "e":Ljava/lang/InterruptedException;
    :try_start_3
    invoke-virtual {v0}, Ljava/lang/InterruptedException;->printStackTrace()V

    goto :goto_1

    .line 70
    .end local v0    # "e":Ljava/lang/InterruptedException;
    :catchall_0
    move-exception v1

    monitor-exit v2
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    throw v1
.end method

.method public a(I)Landroid/hardware/Camera;
    .locals 4
    .param p1, "cameraid"    # I

    .prologue
    .line 97
    iget-object v2, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$a;->d:Ljava/lang/Object;

    monitor-enter v2

    .line 98
    :try_start_0
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$a;->b:Landroid/os/Handler;

    if-nez v1, :cond_0

    iget-object v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$a;->c:Landroid/hardware/Camera;

    monitor-exit v2

    .line 120
    :goto_0
    return-object v1

    .line 99
    :cond_0
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$a;->b:Landroid/os/Handler;

    new-instance v3, Lcom/thinkware/sundo/ieve/ieveCameraView$a$2;

    invoke-direct {v3, p0, p1}, Lcom/thinkware/sundo/ieve/ieveCameraView$a$2;-><init>(Lcom/thinkware/sundo/ieve/ieveCameraView$a;I)V

    invoke-virtual {v1, v3}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 114
    :try_start_1
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$a;->d:Ljava/lang/Object;

    invoke-virtual {v1}, Ljava/lang/Object;->wait()V
    :try_end_1
    .catch Ljava/lang/InterruptedException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 97
    :goto_1
    :try_start_2
    monitor-exit v2
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 120
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$a;->c:Landroid/hardware/Camera;

    goto :goto_0

    .line 115
    :catch_0
    move-exception v0

    .line 116
    .local v0, "e":Ljava/lang/InterruptedException;
    :try_start_3
    invoke-virtual {v0}, Ljava/lang/InterruptedException;->printStackTrace()V

    goto :goto_1

    .line 97
    .end local v0    # "e":Ljava/lang/InterruptedException;
    :catchall_0
    move-exception v1

    monitor-exit v2
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    throw v1
.end method

.method public b()V
    .locals 2

    .prologue
    const/4 v1, 0x0

    .line 124
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$a;->b:Landroid/os/Handler;

    if-eqz v0, :cond_0

    .line 125
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$a;->b:Landroid/os/Handler;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacksAndMessages(Ljava/lang/Object;)V

    .line 126
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$a;->b:Landroid/os/Handler;

    invoke-virtual {v0}, Landroid/os/Handler;->getLooper()Landroid/os/Looper;

    move-result-object v0

    invoke-virtual {v0}, Landroid/os/Looper;->quit()V

    .line 127
    iput-object v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$a;->b:Landroid/os/Handler;

    .line 136
    :cond_0
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$a;->c:Landroid/hardware/Camera;

    if-eqz v0, :cond_1

    .line 137
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$a;->c:Landroid/hardware/Camera;

    invoke-virtual {v0}, Landroid/hardware/Camera;->release()V

    .line 138
    iput-object v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$a;->c:Landroid/hardware/Camera;

    .line 140
    :cond_1
    return-void
.end method
