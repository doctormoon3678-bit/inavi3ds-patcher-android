.class Ltas/internal/ipc/SenderManager$RemoteReplier;
.super Ltas/internal/ipc/server/IRemoteTransmitter$Stub;
.source "SenderManager.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltas/internal/ipc/SenderManager;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "RemoteReplier"
.end annotation


# instance fields
.field private M:Ljava/lang/ref/WeakReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference",
            "<",
            "Ltas/internal/ipc/SenderManager$SenderWrapper;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Ltas/internal/ipc/SenderManager$SenderWrapper;)V
    .locals 1
    .param p1, "m"    # Ltas/internal/ipc/SenderManager$SenderWrapper;

    .prologue
    .line 538
    invoke-direct {p0}, Ltas/internal/ipc/server/IRemoteTransmitter$Stub;-><init>()V

    .line 539
    new-instance v0, Ljava/lang/ref/WeakReference;

    invoke-direct {v0, p1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    iput-object v0, p0, Ltas/internal/ipc/SenderManager$RemoteReplier;->M:Ljava/lang/ref/WeakReference;

    .line 538
    return-void
.end method


# virtual methods
.method public transmit(Ltas/internal/ipc/server/RemoteMessage;)V
    .locals 2
    .param p1, "msg"    # Ltas/internal/ipc/server/RemoteMessage;

    .prologue
    .line 544
    iget-object v1, p0, Ltas/internal/ipc/SenderManager$RemoteReplier;->M:Ljava/lang/ref/WeakReference;

    invoke-virtual {v1}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/ipc/SenderManager$SenderWrapper;

    .line 545
    .local v0, "m":Ltas/internal/ipc/SenderManager$SenderWrapper;
    if-eqz v0, :cond_0

    .line 546
    invoke-static {v0, p1}, Ltas/internal/ipc/SenderManager$SenderWrapper;->-wrap5(Ltas/internal/ipc/SenderManager$SenderWrapper;Ltas/internal/ipc/server/RemoteMessage;)V

    .line 543
    :goto_0
    return-void

    .line 548
    :cond_0
    invoke-virtual {p1}, Ltas/internal/ipc/server/RemoteMessage;->recycle()V

    goto :goto_0
.end method
