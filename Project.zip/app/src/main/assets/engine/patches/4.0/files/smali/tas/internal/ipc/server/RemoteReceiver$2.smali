.class final Ltas/internal/ipc/server/RemoteReceiver$2;
.super Ljava/lang/Object;
.source "RemoteReceiver.java"

# interfaces
.implements Ltas/internal/ipc/util/SyncdPool$Callback;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltas/internal/ipc/server/RemoteReceiver;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ltas/internal/ipc/util/SyncdPool$Callback",
        "<",
        "Ltas/internal/ipc/server/RemoteReceiver;",
        ">;"
    }
.end annotation


# direct methods
.method constructor <init>()V
    .locals 0

    .prologue
    .line 69
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public bridge synthetic getNext(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1
    .param p1, "r"    # Ljava/lang/Object;

    .prologue
    .line 77
    check-cast p1, Ltas/internal/ipc/server/RemoteReceiver;

    .end local p1    # "r":Ljava/lang/Object;
    invoke-virtual {p0, p1}, Ltas/internal/ipc/server/RemoteReceiver$2;->getNext(Ltas/internal/ipc/server/RemoteReceiver;)Ltas/internal/ipc/server/RemoteReceiver;

    move-result-object v0

    return-object v0
.end method

.method public getNext(Ltas/internal/ipc/server/RemoteReceiver;)Ltas/internal/ipc/server/RemoteReceiver;
    .locals 1
    .param p1, "r"    # Ltas/internal/ipc/server/RemoteReceiver;

    .prologue
    .line 78
    invoke-static {p1}, Ltas/internal/ipc/server/RemoteReceiver;->-get0(Ltas/internal/ipc/server/RemoteReceiver;)Ltas/internal/ipc/server/RemoteReceiver;

    move-result-object v0

    return-object v0
.end method

.method public bridge synthetic newInstance()Ljava/lang/Object;
    .locals 1

    .prologue
    .line 70
    invoke-virtual {p0}, Ltas/internal/ipc/server/RemoteReceiver$2;->newInstance()Ltas/internal/ipc/server/RemoteReceiver;

    move-result-object v0

    return-object v0
.end method

.method public newInstance()Ltas/internal/ipc/server/RemoteReceiver;
    .locals 3

    .prologue
    const/4 v1, 0x0

    .line 71
    new-instance v0, Ltas/internal/ipc/server/RemoteReceiver;

    invoke-direct {v0, v1, v1}, Ltas/internal/ipc/server/RemoteReceiver;-><init>(Ltas/internal/ipc/server/RemoteReceiver;Ltas/internal/ipc/server/RemoteReceiver;)V

    .line 72
    .local v0, "r":Ltas/internal/ipc/server/RemoteReceiver;
    const/4 v1, 0x1

    invoke-static {v0, v1}, Ltas/internal/ipc/server/RemoteReceiver;->-set0(Ltas/internal/ipc/server/RemoteReceiver;Z)Z

    .line 73
    invoke-static {}, Ltas/internal/ipc/server/RemoteReceiver;->-get1()I

    move-result v1

    add-int/lit8 v2, v1, 0x1

    invoke-static {v2}, Ltas/internal/ipc/server/RemoteReceiver;->-set3(I)I

    invoke-static {v0, v1}, Ltas/internal/ipc/server/RemoteReceiver;->-set2(Ltas/internal/ipc/server/RemoteReceiver;I)I

    .line 74
    return-object v0
.end method

.method public bridge synthetic setNext(Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 0
    .param p1, "r"    # Ljava/lang/Object;
    .param p2, "next"    # Ljava/lang/Object;

    .prologue
    .line 81
    check-cast p1, Ltas/internal/ipc/server/RemoteReceiver;

    .end local p1    # "r":Ljava/lang/Object;
    check-cast p2, Ltas/internal/ipc/server/RemoteReceiver;

    .end local p2    # "next":Ljava/lang/Object;
    invoke-virtual {p0, p1, p2}, Ltas/internal/ipc/server/RemoteReceiver$2;->setNext(Ltas/internal/ipc/server/RemoteReceiver;Ltas/internal/ipc/server/RemoteReceiver;)V

    return-void
.end method

.method public setNext(Ltas/internal/ipc/server/RemoteReceiver;Ltas/internal/ipc/server/RemoteReceiver;)V
    .locals 0
    .param p1, "r"    # Ltas/internal/ipc/server/RemoteReceiver;
    .param p2, "next"    # Ltas/internal/ipc/server/RemoteReceiver;

    .prologue
    .line 82
    invoke-static {p1, p2}, Ltas/internal/ipc/server/RemoteReceiver;->-set1(Ltas/internal/ipc/server/RemoteReceiver;Ltas/internal/ipc/server/RemoteReceiver;)Ltas/internal/ipc/server/RemoteReceiver;

    .line 81
    return-void
.end method
