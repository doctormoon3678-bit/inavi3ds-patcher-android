.class Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR$8;
.super Ljava/lang/Object;
.source "DestArriveGuideAR.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;->SetData(Lcom/thinkware/sundo/inavi3d/Struct/DestInfo;Lcom/thinkware/sundo/inavi3d/OBD2/OBD2GoalInfo;Lcom/thinkware/sundo/inavi3d/INavi3DActivity;Z)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;


# direct methods
.method constructor <init>(Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;)V
    .locals 0

    .prologue
    .line 1185
    iput-object p1, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR$8;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 8

    .prologue
    const/4 v7, 0x1

    const/4 v6, 0x0

    .line 1190
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR$8;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;->DestInfoTitleLayout1:Landroid/widget/RelativeLayout;

    invoke-virtual {v3, v6}, Landroid/widget/RelativeLayout;->setVisibility(I)V

    .line 1191
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR$8;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;->DestInfoTitleLayout2:Landroid/widget/RelativeLayout;

    const/16 v4, 0x8

    invoke-virtual {v3, v4}, Landroid/widget/RelativeLayout;->setVisibility(I)V

    .line 1192
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR$8;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;

    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR$8;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;

    invoke-static {v4}, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;->access$500(Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;)Landroid/content/res/Resources;

    move-result-object v4

    const v5, 0x7f02000d

    invoke-virtual {v4, v5}, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v4

    invoke-virtual {v3, v4}, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 1193
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR$8;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;->DestInfoDetail:Landroid/widget/Button;

    invoke-virtual {v3, v6}, Landroid/widget/Button;->setVisibility(I)V

    .line 1194
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR$8;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;->DestInfoAround:Landroid/widget/Button;

    invoke-virtual {v3, v6}, Landroid/widget/Button;->setVisibility(I)V

    .line 1195
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR$8;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;->DestInfoRoadview:Landroid/widget/Button;

    invoke-virtual {v3, v6}, Landroid/widget/Button;->setVisibility(I)V

    .line 1196
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR$8;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;->DestInfoFivepin:Landroid/widget/Button;

    invoke-virtual {v3, v6}, Landroid/widget/Button;->setVisibility(I)V

    .line 1198
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR$8;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;->DestInfoTitle:Landroid/widget/TextView;

    if-eqz v3, :cond_0

    .line 1199
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR$8;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;->DestInfoTitle:Landroid/widget/TextView;

    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR$8;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;

    invoke-static {v4}, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;->access$600(Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1200
    :cond_0
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR$8;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;->DestInfoDetail:Landroid/widget/Button;

    invoke-virtual {v3}, Landroid/widget/Button;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    .line 1201
    .local v0, "drawable":Landroid/graphics/drawable/Drawable;
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR$8;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;

    invoke-static {v3}, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;->access$700(Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;)I

    move-result v3

    if-nez v3, :cond_1

    .line 1203
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR$8;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;->DestInfoDetail:Landroid/widget/Button;

    invoke-virtual {v3, v6}, Landroid/widget/Button;->setEnabled(Z)V

    .line 1204
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR$8;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;->DestInfoDetail:Landroid/widget/Button;

    invoke-virtual {v3, v6}, Landroid/widget/Button;->setClickable(Z)V

    .line 1205
    const/16 v3, 0x4b

    invoke-virtual {v0, v3}, Landroid/graphics/drawable/Drawable;->setAlpha(I)V

    .line 1211
    :goto_0
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR$8;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;->DestInfoAround:Landroid/widget/Button;

    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR$8;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;

    invoke-static {v4}, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;->access$800(Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 1213
    new-instance v1, Landroid/widget/RelativeLayout$LayoutParams;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR$8;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;->DestInfoDetail:Landroid/widget/Button;

    invoke-virtual {v3}, Landroid/widget/Button;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v3

    invoke-direct {v1, v3}, Landroid/widget/RelativeLayout$LayoutParams;-><init>(Landroid/view/ViewGroup$LayoutParams;)V

    .line 1214
    .local v1, "params":Landroid/widget/RelativeLayout$LayoutParams;
    const/16 v3, 0x113

    const/16 v4, 0x165

    invoke-virtual {v1, v3, v4, v6, v6}, Landroid/widget/RelativeLayout$LayoutParams;->setMargins(IIII)V

    .line 1215
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR$8;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;->DestInfoDetail:Landroid/widget/Button;

    invoke-virtual {v3, v1}, Landroid/widget/Button;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 1216
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR$8;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;->DestInfoDetail:Landroid/widget/Button;

    invoke-virtual {v3}, Landroid/widget/Button;->requestLayout()V

    .line 1218
    new-instance v2, Landroid/widget/RelativeLayout$LayoutParams;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR$8;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;->DestInfoAround:Landroid/widget/Button;

    invoke-virtual {v3}, Landroid/widget/Button;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v3

    invoke-direct {v2, v3}, Landroid/widget/RelativeLayout$LayoutParams;-><init>(Landroid/view/ViewGroup$LayoutParams;)V

    .line 1219
    .local v2, "params1":Landroid/widget/RelativeLayout$LayoutParams;
    const/16 v3, 0xa

    const/16 v4, 0x19c

    invoke-virtual {v2, v3, v4, v6, v6}, Landroid/widget/RelativeLayout$LayoutParams;->setMargins(IIII)V

    .line 1220
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR$8;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;->DestInfoAround:Landroid/widget/Button;

    invoke-virtual {v3, v2}, Landroid/widget/Button;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 1221
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR$8;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;->DestInfoAround:Landroid/widget/Button;

    invoke-virtual {v3}, Landroid/widget/Button;->requestLayout()V

    .line 1222
    return-void

    .line 1207
    .end local v1    # "params":Landroid/widget/RelativeLayout$LayoutParams;
    .end local v2    # "params1":Landroid/widget/RelativeLayout$LayoutParams;
    :cond_1
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR$8;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;->DestInfoDetail:Landroid/widget/Button;

    invoke-virtual {v3, v7}, Landroid/widget/Button;->setEnabled(Z)V

    .line 1208
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR$8;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;->DestInfoDetail:Landroid/widget/Button;

    invoke-virtual {v3, v7}, Landroid/widget/Button;->setClickable(Z)V

    .line 1209
    const/16 v3, 0xff

    invoke-virtual {v0, v3}, Landroid/graphics/drawable/Drawable;->setAlpha(I)V

    goto :goto_0
.end method
