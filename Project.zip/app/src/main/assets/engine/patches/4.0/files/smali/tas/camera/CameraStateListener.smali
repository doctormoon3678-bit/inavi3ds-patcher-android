.class public interface abstract Ltas/camera/CameraStateListener;
.super Ljava/lang/Object;
.source "CameraStateListener.java"

# interfaces
.implements Ltas/camera/BaseListener;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ltas/camera/CameraId;",
        ">",
        "Ljava/lang/Object;",
        "Ltas/camera/BaseListener;"
    }
.end annotation


# virtual methods
.method public abstract onCableState(Ltas/camera/CameraId;Z)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;Z)V"
        }
    .end annotation
.end method

.method public abstract onExtraState(Ltas/camera/CameraId;II)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;II)V"
        }
    .end annotation
.end method
