.class Lcom/thinkware/sundo/ieve/ieveCameraView$2$1;
.super Landroid/os/AsyncTask;
.source "ieveCameraView.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a([B)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Landroid/os/AsyncTask",
        "<",
        "Ljava/lang/Void;",
        "Ljava/lang/Void;",
        "Ljava/lang/Boolean;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic a:Lcom/thinkware/sundo/ieve/ieveCameraView$2;

.field private final synthetic b:[B


# direct methods
.method constructor <init>(Lcom/thinkware/sundo/ieve/ieveCameraView$2;[B)V
    .locals 0

    .prologue
    .line 1
    iput-object p1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$1;->a:Lcom/thinkware/sundo/ieve/ieveCameraView$2;

    iput-object p2, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$1;->b:[B

    .line 592
    invoke-direct {p0}, Landroid/os/AsyncTask;-><init>()V

    return-void
.end method


# virtual methods
.method protected varargs a([Ljava/lang/Void;)Ljava/lang/Boolean;
    .locals 14
    .param p1, "params"    # [Ljava/lang/Void;

    .prologue
    const/4 v5, 0x0

    const/4 v13, 0x1

    const/4 v12, 0x0

    .line 613
    invoke-static {}, Lcom/thinkware/sundo/ieve/ieveCameraView;->a()Ljava/lang/String;

    move-result-object v1

    const-string v2, "saveSnapshot:doInBackground[Run taking Snapshot...]"

    invoke-static {v1, v2}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 614
    const/4 v11, 0x1

    .line 617
    .local v11, "success_encode":Z
    new-instance v10, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v10}, Ljava/io/ByteArrayOutputStream;-><init>()V

    .line 618
    .local v10, "stream":Ljava/io/ByteArrayOutputStream;
    new-instance v0, Landroid/graphics/YuvImage;

    iget-object v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$1;->b:[B

    iget-object v2, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$1;->a:Lcom/thinkware/sundo/ieve/ieveCameraView$2;

    invoke-static {v2}, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a(Lcom/thinkware/sundo/ieve/ieveCameraView$2;)Lcom/thinkware/sundo/ieve/ieveCameraView;

    move-result-object v2

    invoke-static {v2}, Lcom/thinkware/sundo/ieve/ieveCameraView;->p(Lcom/thinkware/sundo/ieve/ieveCameraView;)I

    move-result v2

    iget-object v3, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$1;->a:Lcom/thinkware/sundo/ieve/ieveCameraView$2;

    invoke-static {v3}, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a(Lcom/thinkware/sundo/ieve/ieveCameraView$2;)Lcom/thinkware/sundo/ieve/ieveCameraView;

    move-result-object v3

    invoke-static {v3}, Lcom/thinkware/sundo/ieve/ieveCameraView;->q(Lcom/thinkware/sundo/ieve/ieveCameraView;)I

    move-result v3

    iget-object v4, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$1;->a:Lcom/thinkware/sundo/ieve/ieveCameraView$2;

    invoke-static {v4}, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a(Lcom/thinkware/sundo/ieve/ieveCameraView$2;)Lcom/thinkware/sundo/ieve/ieveCameraView;

    move-result-object v4

    invoke-static {v4}, Lcom/thinkware/sundo/ieve/ieveCameraView;->r(Lcom/thinkware/sundo/ieve/ieveCameraView;)I

    move-result v4

    invoke-direct/range {v0 .. v5}, Landroid/graphics/YuvImage;-><init>([BIII[I)V

    .line 619
    .local v0, "yuv":Landroid/graphics/YuvImage;
    new-instance v1, Landroid/graphics/Rect;

    iget-object v2, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$1;->a:Lcom/thinkware/sundo/ieve/ieveCameraView$2;

    invoke-static {v2}, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a(Lcom/thinkware/sundo/ieve/ieveCameraView$2;)Lcom/thinkware/sundo/ieve/ieveCameraView;

    move-result-object v2

    invoke-static {v2}, Lcom/thinkware/sundo/ieve/ieveCameraView;->q(Lcom/thinkware/sundo/ieve/ieveCameraView;)I

    move-result v2

    iget-object v3, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$1;->a:Lcom/thinkware/sundo/ieve/ieveCameraView$2;

    invoke-static {v3}, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a(Lcom/thinkware/sundo/ieve/ieveCameraView$2;)Lcom/thinkware/sundo/ieve/ieveCameraView;

    move-result-object v3

    invoke-static {v3}, Lcom/thinkware/sundo/ieve/ieveCameraView;->r(Lcom/thinkware/sundo/ieve/ieveCameraView;)I

    move-result v3

    invoke-direct {v1, v12, v12, v2, v3}, Landroid/graphics/Rect;-><init>(IIII)V

    const/16 v2, 0x4b

    invoke-virtual {v0, v1, v2, v10}, Landroid/graphics/YuvImage;->compressToJpeg(Landroid/graphics/Rect;ILjava/io/OutputStream;)Z

    .line 620
    invoke-virtual {v10}, Ljava/io/ByteArrayOutputStream;->size()I

    move-result v1

    if-nez v1, :cond_1

    .line 621
    invoke-static {}, Lcom/thinkware/sundo/ieve/ieveCameraView;->a()Ljava/lang/String;

    move-result-object v1

    const-string v2, "saveSnapshot:doInBackground[Stream size 0]"

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 622
    const/4 v11, 0x0

    .line 663
    :cond_0
    :goto_0
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$1;->a:Lcom/thinkware/sundo/ieve/ieveCameraView$2;

    invoke-static {v1}, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a(Lcom/thinkware/sundo/ieve/ieveCameraView$2;)Lcom/thinkware/sundo/ieve/ieveCameraView;

    move-result-object v1

    invoke-static {v1, v5}, Lcom/thinkware/sundo/ieve/ieveCameraView;->a(Lcom/thinkware/sundo/ieve/ieveCameraView;Ljava/lang/String;)V

    .line 664
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$1;->a:Lcom/thinkware/sundo/ieve/ieveCameraView$2;

    invoke-static {v1}, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a(Lcom/thinkware/sundo/ieve/ieveCameraView$2;)Lcom/thinkware/sundo/ieve/ieveCameraView;

    move-result-object v1

    invoke-static {v1, v5}, Lcom/thinkware/sundo/ieve/ieveCameraView;->a(Lcom/thinkware/sundo/ieve/ieveCameraView;Lcom/thinkware/sundo/ieve/ieveExifTag;)V

    .line 665
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$1;->a:Lcom/thinkware/sundo/ieve/ieveCameraView$2;

    invoke-static {v1}, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a(Lcom/thinkware/sundo/ieve/ieveCameraView$2;)Lcom/thinkware/sundo/ieve/ieveCameraView;

    move-result-object v1

    invoke-static {v1, v12}, Lcom/thinkware/sundo/ieve/ieveCameraView;->c(Lcom/thinkware/sundo/ieve/ieveCameraView;Z)V

    .line 666
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$1;->a:Lcom/thinkware/sundo/ieve/ieveCameraView$2;

    invoke-static {v1}, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a(Lcom/thinkware/sundo/ieve/ieveCameraView$2;)Lcom/thinkware/sundo/ieve/ieveCameraView;

    move-result-object v1

    invoke-static {v1, v12}, Lcom/thinkware/sundo/ieve/ieveCameraView;->b(Lcom/thinkware/sundo/ieve/ieveCameraView;Z)V

    .line 667
    invoke-static {}, Lcom/thinkware/sundo/ieve/ieveCameraView;->a()Ljava/lang/String;

    move-result-object v1

    const-string v2, "saveSnapshot:doInBackground[Done]"

    invoke-static {v1, v2}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 669
    invoke-static {v11}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v1

    return-object v1

    .line 625
    :cond_1
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$1;->a:Lcom/thinkware/sundo/ieve/ieveCameraView$2;

    invoke-static {v1}, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a(Lcom/thinkware/sundo/ieve/ieveCameraView$2;)Lcom/thinkware/sundo/ieve/ieveCameraView;

    move-result-object v1

    invoke-virtual {v10}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v2

    invoke-virtual {v10}, Ljava/io/ByteArrayOutputStream;->size()I

    move-result v3

    invoke-static {v2, v12, v3}, Landroid/graphics/BitmapFactory;->decodeByteArray([BII)Landroid/graphics/Bitmap;

    move-result-object v2

    invoke-static {v1, v2}, Lcom/thinkware/sundo/ieve/ieveCameraView;->a(Lcom/thinkware/sundo/ieve/ieveCameraView;Landroid/graphics/Bitmap;)V

    .line 626
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$1;->a:Lcom/thinkware/sundo/ieve/ieveCameraView$2;

    invoke-static {v1}, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a(Lcom/thinkware/sundo/ieve/ieveCameraView$2;)Lcom/thinkware/sundo/ieve/ieveCameraView;

    move-result-object v1

    invoke-static {v1}, Lcom/thinkware/sundo/ieve/ieveCameraView;->s(Lcom/thinkware/sundo/ieve/ieveCameraView;)Landroid/graphics/Bitmap;

    move-result-object v1

    invoke-virtual {v1}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v1

    if-eqz v1, :cond_2

    iget-object v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$1;->a:Lcom/thinkware/sundo/ieve/ieveCameraView$2;

    invoke-static {v1}, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a(Lcom/thinkware/sundo/ieve/ieveCameraView$2;)Lcom/thinkware/sundo/ieve/ieveCameraView;

    move-result-object v1

    invoke-static {v1}, Lcom/thinkware/sundo/ieve/ieveCameraView;->s(Lcom/thinkware/sundo/ieve/ieveCameraView;)Landroid/graphics/Bitmap;

    move-result-object v1

    invoke-virtual {v1}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v1

    if-eqz v1, :cond_2

    .line 627
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$1;->a:Lcom/thinkware/sundo/ieve/ieveCameraView$2;

    invoke-static {v1}, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a(Lcom/thinkware/sundo/ieve/ieveCameraView$2;)Lcom/thinkware/sundo/ieve/ieveCameraView;

    move-result-object v1

    invoke-static {v1}, Lcom/thinkware/sundo/ieve/ieveCameraView;->s(Lcom/thinkware/sundo/ieve/ieveCameraView;)Landroid/graphics/Bitmap;

    move-result-object v1

    invoke-virtual {v1}, Landroid/graphics/Bitmap;->getRowBytes()I

    move-result v1

    iget-object v2, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$1;->a:Lcom/thinkware/sundo/ieve/ieveCameraView$2;

    invoke-static {v2}, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a(Lcom/thinkware/sundo/ieve/ieveCameraView$2;)Lcom/thinkware/sundo/ieve/ieveCameraView;

    move-result-object v2

    invoke-static {v2}, Lcom/thinkware/sundo/ieve/ieveCameraView;->s(Lcom/thinkware/sundo/ieve/ieveCameraView;)Landroid/graphics/Bitmap;

    move-result-object v2

    invoke-virtual {v2}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v2

    mul-int/lit8 v2, v2, 0x4

    if-ne v1, v2, :cond_2

    iget-object v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$1;->a:Lcom/thinkware/sundo/ieve/ieveCameraView$2;

    invoke-static {v1}, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a(Lcom/thinkware/sundo/ieve/ieveCameraView$2;)Lcom/thinkware/sundo/ieve/ieveCameraView;

    move-result-object v1

    invoke-static {v1}, Lcom/thinkware/sundo/ieve/ieveCameraView;->s(Lcom/thinkware/sundo/ieve/ieveCameraView;)Landroid/graphics/Bitmap;

    move-result-object v1

    invoke-virtual {v1}, Landroid/graphics/Bitmap;->getByteCount()I

    move-result v1

    iget-object v2, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$1;->a:Lcom/thinkware/sundo/ieve/ieveCameraView$2;

    invoke-static {v2}, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a(Lcom/thinkware/sundo/ieve/ieveCameraView$2;)Lcom/thinkware/sundo/ieve/ieveCameraView;

    move-result-object v2

    invoke-static {v2}, Lcom/thinkware/sundo/ieve/ieveCameraView;->s(Lcom/thinkware/sundo/ieve/ieveCameraView;)Landroid/graphics/Bitmap;

    move-result-object v2

    invoke-virtual {v2}, Landroid/graphics/Bitmap;->getRowBytes()I

    move-result v2

    iget-object v3, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$1;->a:Lcom/thinkware/sundo/ieve/ieveCameraView$2;

    invoke-static {v3}, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a(Lcom/thinkware/sundo/ieve/ieveCameraView$2;)Lcom/thinkware/sundo/ieve/ieveCameraView;

    move-result-object v3

    invoke-static {v3}, Lcom/thinkware/sundo/ieve/ieveCameraView;->s(Lcom/thinkware/sundo/ieve/ieveCameraView;)Landroid/graphics/Bitmap;

    move-result-object v3

    invoke-virtual {v3}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v3

    mul-int/2addr v2, v3

    if-eq v1, v2, :cond_3

    .line 629
    :cond_2
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$1;->a:Lcom/thinkware/sundo/ieve/ieveCameraView$2;

    invoke-static {v1}, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a(Lcom/thinkware/sundo/ieve/ieveCameraView$2;)Lcom/thinkware/sundo/ieve/ieveCameraView;

    move-result-object v1

    invoke-virtual {v1}, Lcom/thinkware/sundo/ieve/ieveCameraView;->clearSnapshot()V

    .line 630
    invoke-static {}, Lcom/thinkware/sundo/ieve/ieveCameraView;->a()Ljava/lang/String;

    move-result-object v1

    const-string v2, "saveSnapshot:doInBackground[Failed make bitmap]"

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 631
    const/4 v11, 0x0

    .line 632
    goto/16 :goto_0

    .line 634
    :cond_3
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$1;->a:Lcom/thinkware/sundo/ieve/ieveCameraView$2;

    invoke-static {v1}, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a(Lcom/thinkware/sundo/ieve/ieveCameraView$2;)Lcom/thinkware/sundo/ieve/ieveCameraView;

    move-result-object v1

    invoke-static {v1}, Lcom/thinkware/sundo/ieve/ieveCameraView;->t(Lcom/thinkware/sundo/ieve/ieveCameraView;)Ljava/lang/String;

    move-result-object v1

    if-eqz v1, :cond_0

    .line 635
    const-string v1, "%s.jpg"

    new-array v2, v13, [Ljava/lang/Object;

    iget-object v3, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$1;->a:Lcom/thinkware/sundo/ieve/ieveCameraView$2;

    invoke-static {v3}, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a(Lcom/thinkware/sundo/ieve/ieveCameraView$2;)Lcom/thinkware/sundo/ieve/ieveCameraView;

    move-result-object v3

    invoke-static {v3}, Lcom/thinkware/sundo/ieve/ieveCameraView;->t(Lcom/thinkware/sundo/ieve/ieveCameraView;)Ljava/lang/String;

    move-result-object v3

    aput-object v3, v2, v12

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v9

    .line 636
    .local v9, "savename":Ljava/lang/String;
    new-instance v7, Ljava/io/File;

    invoke-direct {v7, v9}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 638
    .local v7, "file":Ljava/io/File;
    :try_start_0
    invoke-static {}, Lcom/thinkware/sundo/ieve/ieveCameraView;->a()Ljava/lang/String;

    move-result-object v1

    const-string v2, "saveSnapshot:doInBackground[Saving file...]"

    invoke-static {v1, v2}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 639
    new-instance v8, Ljava/io/FileOutputStream;

    invoke-direct {v8, v7}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    .line 640
    .local v8, "output":Ljava/io/FileOutputStream;
    invoke-virtual {v10}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v1

    invoke-virtual {v8, v1}, Ljava/io/FileOutputStream;->write([B)V

    .line 641
    invoke-virtual {v8}, Ljava/io/FileOutputStream;->flush()V

    .line 642
    invoke-virtual {v8}, Ljava/io/FileOutputStream;->close()V

    .line 643
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$1;->a:Lcom/thinkware/sundo/ieve/ieveCameraView$2;

    invoke-static {v1}, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a(Lcom/thinkware/sundo/ieve/ieveCameraView$2;)Lcom/thinkware/sundo/ieve/ieveCameraView;

    move-result-object v1

    invoke-static {v1}, Lcom/thinkware/sundo/ieve/ieveCameraView;->u(Lcom/thinkware/sundo/ieve/ieveCameraView;)Lcom/thinkware/sundo/ieve/ieveExifTag;

    move-result-object v1

    if-eqz v1, :cond_4

    .line 644
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$1;->a:Lcom/thinkware/sundo/ieve/ieveCameraView$2;

    invoke-static {v1}, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a(Lcom/thinkware/sundo/ieve/ieveCameraView$2;)Lcom/thinkware/sundo/ieve/ieveCameraView;

    move-result-object v1

    invoke-static {v1}, Lcom/thinkware/sundo/ieve/ieveCameraView;->u(Lcom/thinkware/sundo/ieve/ieveCameraView;)Lcom/thinkware/sundo/ieve/ieveExifTag;

    move-result-object v1

    iget-object v2, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$1;->a:Lcom/thinkware/sundo/ieve/ieveCameraView$2;

    invoke-static {v2}, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a(Lcom/thinkware/sundo/ieve/ieveCameraView$2;)Lcom/thinkware/sundo/ieve/ieveCameraView;

    move-result-object v2

    invoke-static {v2}, Lcom/thinkware/sundo/ieve/ieveCameraView;->q(Lcom/thinkware/sundo/ieve/ieveCameraView;)I

    move-result v2

    iget-object v3, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$1;->a:Lcom/thinkware/sundo/ieve/ieveCameraView$2;

    invoke-static {v3}, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a(Lcom/thinkware/sundo/ieve/ieveCameraView$2;)Lcom/thinkware/sundo/ieve/ieveCameraView;

    move-result-object v3

    invoke-static {v3}, Lcom/thinkware/sundo/ieve/ieveCameraView;->r(Lcom/thinkware/sundo/ieve/ieveCameraView;)I

    move-result v3

    invoke-virtual {v1, v9, v2, v3}, Lcom/thinkware/sundo/ieve/ieveExifTag;->writeFile(Ljava/lang/String;II)Z

    .line 650
    :cond_4
    invoke-static {}, Lcom/thinkware/sundo/ieve/ieveCameraView;->a()Ljava/lang/String;

    move-result-object v1

    const-string v2, "saveSnapshot:doInBackground[saved]"

    invoke-static {v1, v2}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_0
    .catch Ljava/io/FileNotFoundException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_1

    goto/16 :goto_0

    .line 651
    .end local v8    # "output":Ljava/io/FileOutputStream;
    :catch_0
    move-exception v6

    .line 652
    .local v6, "e":Ljava/io/FileNotFoundException;
    invoke-virtual {v6}, Ljava/io/FileNotFoundException;->printStackTrace()V

    .line 653
    invoke-static {}, Lcom/thinkware/sundo/ieve/ieveCameraView;->a()Ljava/lang/String;

    move-result-object v1

    const-string v2, "saveSnapshot:doInBackground[FileNotFoundException:%s]"

    new-array v3, v13, [Ljava/lang/Object;

    invoke-virtual {v6}, Ljava/io/FileNotFoundException;->getLocalizedMessage()Ljava/lang/String;

    move-result-object v4

    aput-object v4, v3, v12

    invoke-static {v2, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 654
    const/4 v11, 0x0

    goto/16 :goto_0

    .line 655
    .end local v6    # "e":Ljava/io/FileNotFoundException;
    :catch_1
    move-exception v6

    .line 656
    .local v6, "e":Ljava/io/IOException;
    invoke-virtual {v6}, Ljava/io/IOException;->printStackTrace()V

    .line 657
    invoke-static {}, Lcom/thinkware/sundo/ieve/ieveCameraView;->a()Ljava/lang/String;

    move-result-object v1

    const-string v2, "saveSnapshot:doInBackground[IOException:%s]"

    new-array v3, v13, [Ljava/lang/Object;

    invoke-virtual {v6}, Ljava/io/IOException;->getLocalizedMessage()Ljava/lang/String;

    move-result-object v4

    aput-object v4, v3, v12

    invoke-static {v2, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 658
    const/4 v11, 0x0

    goto/16 :goto_0
.end method

.method protected a(Ljava/lang/Boolean;)V
    .locals 5
    .param p1, "result"    # Ljava/lang/Boolean;

    .prologue
    .line 601
    invoke-super {p0, p1}, Landroid/os/AsyncTask;->onPostExecute(Ljava/lang/Object;)V

    .line 602
    invoke-static {}, Lcom/thinkware/sundo/ieve/ieveCameraView;->a()Ljava/lang/String;

    move-result-object v1

    const-string v2, "saveSnapshot:onPostExecute[%s]"

    const/4 v0, 0x1

    new-array v3, v0, [Ljava/lang/Object;

    const/4 v4, 0x0

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-eqz v0, :cond_0

    const-string v0, "succeed"

    :goto_0
    aput-object v0, v3, v4

    invoke-static {v2, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 603
    return-void

    .line 602
    :cond_0
    const-string v0, "failed"

    goto :goto_0
.end method

.method protected varargs synthetic doInBackground([Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .prologue
    .line 1
    check-cast p1, [Ljava/lang/Void;

    invoke-virtual {p0, p1}, Lcom/thinkware/sundo/ieve/ieveCameraView$2$1;->a([Ljava/lang/Void;)Ljava/lang/Boolean;

    move-result-object v0

    return-object v0
.end method

.method protected onCancelled()V
    .locals 2

    .prologue
    .line 595
    invoke-super {p0}, Landroid/os/AsyncTask;->onCancelled()V

    .line 596
    invoke-static {}, Lcom/thinkware/sundo/ieve/ieveCameraView;->a()Ljava/lang/String;

    move-result-object v0

    const-string v1, "saveSnapshot:onCancelled"

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 597
    return-void
.end method

.method protected synthetic onPostExecute(Ljava/lang/Object;)V
    .locals 0

    .prologue
    .line 1
    check-cast p1, Ljava/lang/Boolean;

    invoke-virtual {p0, p1}, Lcom/thinkware/sundo/ieve/ieveCameraView$2$1;->a(Ljava/lang/Boolean;)V

    return-void
.end method

.method protected onPreExecute()V
    .locals 2

    .prologue
    .line 607
    invoke-super {p0}, Landroid/os/AsyncTask;->onPreExecute()V

    .line 608
    invoke-static {}, Lcom/thinkware/sundo/ieve/ieveCameraView;->a()Ljava/lang/String;

    move-result-object v0

    const-string v1, "saveSnapshot:onPreExecute"

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 609
    return-void
.end method
