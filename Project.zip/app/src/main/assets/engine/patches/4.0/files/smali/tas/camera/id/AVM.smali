.class public Ltas/camera/id/AVM;
.super Ltas/camera/CameraId;
.source "AVM.java"


# static fields
.field public static final AVM_RESET:I = 0x7e2

.field public static final BOOTMODE_BEGIN:I = 0x460

.field public static final BOOTMODE_CALIBRATION:I = 0x464

.field public static final BOOTMODE_END:I = 0x46a

.field public static final BOOTMODE_NORMAL:I = 0x462

.field public static final BOOTMODE_UPGRADE:I = 0x463

.field public static final BOOTMODE_WAIT:I = 0x461

.field public static final CALI_STATUS_OKAY:I = 0x3eb

.field public static final DEVICE_CONNECTED:I = 0x3e9

.field public static final DEVICE_DISCONNECTED:I = 0x3ea

.field public static final FLAG_BY_USER:I = 0x46a

.field public static final FULL_FRONT:I = 0x450

.field public static final FULL_LEFT:I = 0x454

.field public static final FULL_REAR:I = 0x451

.field public static final FULL_RIGHT:I = 0x455

.field public static final GET_APP_VERSION:I = 0x7db

.field public static final GET_BOOT_MODE:I = 0x7e3

.field public static final GET_BRIGHTNESS:I = 0x7da

.field public static final GET_CALI_STATUS:I = 0x7de

.field public static final GET_CONN_STATUS:I = 0x7dd

.field public static final GET_CONTRAST:I = 0x7d8

.field public static final GET_HUE:I = 0x7d4

.field public static final GET_MICOM_VERSION:I = 0x7dc

.field public static final GET_PGL_DATA:I = 0x7e0

.field public static final GET_SATURATION:I = 0x7d6

.field public static final GET_VIEW_MODE:I = 0x7d2

.field public static final PIP_LEFT_REAR:I = 0x457

.field public static final PIP_RIGHT_REAR:I = 0x456

.field public static final PIP_TOP:I = 0x458

.field public static final PRESS_MODE_KEY:I = 0x7e4

.field public static final PRESS_MODE_LONGKEY:I = 0x7e6

.field public static final PRESS_PWR_KEY:I = 0x7e5

.field public static final PRESS_PWR_LONGKEY:I = 0x7e7

.field public static final SEND_KEY_EVENT:I = 0x7e1

.field public static final SET_BRIGHTNESS:I = 0x7d9

.field public static final SET_CONTRAST:I = 0x7d7

.field public static final SET_HUE:I = 0x7d3

.field public static final SET_NATIVE_DEBUG_MODE:I = 0x7df

.field public static final SET_SATURATION:I = 0x7d5

.field public static final SET_VIEW_MODE:I = 0x7d1

.field public static final TOP_FRONT:I = 0x44e

.field public static final TOP_LEFT:I = 0x452

.field public static final TOP_REAR:I = 0x44d

.field public static final TOP_RIGHT:I = 0x453

.field public static final TOP_SIDE:I = 0x44f

.field public static final VIEWMODE_BEGIN:I = 0x44c

.field public static final VIEWMODE_END:I = 0x460


# instance fields
.field private final proxy:Ltas/internal/camera/client/CameraProxy;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ltas/internal/camera/client/CameraProxy",
            "<",
            "Ltas/camera/id/AVM;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 1
    .param p1, "context"    # Landroid/content/Context;

    .prologue
    .line 74
    invoke-direct {p0}, Ltas/camera/CameraId;-><init>()V

    .line 75
    new-instance v0, Ltas/internal/camera/client/CameraProxy;

    invoke-direct {v0, p1, p0}, Ltas/internal/camera/client/CameraProxy;-><init>(Landroid/content/Context;Ltas/camera/CameraId;)V

    iput-object v0, p0, Ltas/camera/id/AVM;->proxy:Ltas/internal/camera/client/CameraProxy;

    .line 74
    return-void
.end method

.method public static bootModeToString(I)Ljava/lang/String;
    .locals 1
    .param p0, "bootmode"    # I

    .prologue
    .line 146
    packed-switch p0, :pswitch_data_0

    .line 151
    const-string/jumbo v0, "unknown"

    return-object v0

    .line 147
    :pswitch_0
    const-string/jumbo v0, "WAIT_MODE"

    return-object v0

    .line 148
    :pswitch_1
    const-string/jumbo v0, "NORMAL_MODE"

    return-object v0

    .line 149
    :pswitch_2
    const-string/jumbo v0, "UPGRADE_MODE"

    return-object v0

    .line 150
    :pswitch_3
    const-string/jumbo v0, "CALIBRATION_MODE"

    return-object v0

    .line 146
    nop

    :pswitch_data_0
    .packed-switch 0x461
        :pswitch_0
        :pswitch_1
        :pswitch_2
        :pswitch_3
    .end packed-switch
.end method

.method public static isViewMode_full(I)Z
    .locals 1
    .param p0, "viewmode"    # I

    .prologue
    .line 103
    packed-switch p0, :pswitch_data_0

    .line 111
    :pswitch_0
    const/4 v0, 0x0

    return v0

    .line 108
    :pswitch_1
    const/4 v0, 0x1

    return v0

    .line 103
    nop

    :pswitch_data_0
    .packed-switch 0x450
        :pswitch_1
        :pswitch_1
        :pswitch_0
        :pswitch_0
        :pswitch_1
        :pswitch_1
    .end packed-switch
.end method

.method public static isViewMode_pip(I)Z
    .locals 1
    .param p0, "viewmode"    # I

    .prologue
    .line 116
    packed-switch p0, :pswitch_data_0

    .line 123
    const/4 v0, 0x0

    return v0

    .line 120
    :pswitch_0
    const/4 v0, 0x1

    return v0

    .line 116
    nop

    :pswitch_data_0
    .packed-switch 0x456
        :pswitch_0
        :pswitch_0
        :pswitch_0
    .end packed-switch
.end method

.method public static isViewMode_top(I)Z
    .locals 1
    .param p0, "viewmode"    # I

    .prologue
    const/4 v0, 0x1

    .line 87
    packed-switch p0, :pswitch_data_0

    .line 98
    :pswitch_0
    const/4 v0, 0x0

    return v0

    .line 92
    :pswitch_1
    return v0

    .line 95
    :pswitch_2
    return v0

    .line 87
    :pswitch_data_0
    .packed-switch 0x44d
        :pswitch_1
        :pswitch_1
        :pswitch_2
        :pswitch_0
        :pswitch_0
        :pswitch_1
        :pswitch_1
    .end packed-switch
.end method

.method public static viewModeToString(I)Ljava/lang/String;
    .locals 1
    .param p0, "viewmode"    # I

    .prologue
    .line 128
    packed-switch p0, :pswitch_data_0

    .line 141
    const-string/jumbo v0, "unknown"

    return-object v0

    .line 129
    :pswitch_0
    const-string/jumbo v0, "TOP_REAR"

    return-object v0

    .line 130
    :pswitch_1
    const-string/jumbo v0, "TOP_FRONT"

    return-object v0

    .line 131
    :pswitch_2
    const-string/jumbo v0, "TOP_SIDE"

    return-object v0

    .line 132
    :pswitch_3
    const-string/jumbo v0, "FULL_FRONT"

    return-object v0

    .line 133
    :pswitch_4
    const-string/jumbo v0, "FULL_REAR"

    return-object v0

    .line 134
    :pswitch_5
    const-string/jumbo v0, "TOP_LEFT"

    return-object v0

    .line 135
    :pswitch_6
    const-string/jumbo v0, "TOP_RIGHT"

    return-object v0

    .line 136
    :pswitch_7
    const-string/jumbo v0, "FULL_LEFT"

    return-object v0

    .line 137
    :pswitch_8
    const-string/jumbo v0, "FULL_RIGHT"

    return-object v0

    .line 138
    :pswitch_9
    const-string/jumbo v0, "PIP_RIGHT_REAR"

    return-object v0

    .line 139
    :pswitch_a
    const-string/jumbo v0, "PIP_LEFT_REAR"

    return-object v0

    .line 140
    :pswitch_b
    const-string/jumbo v0, "PIP_TOP"

    return-object v0

    .line 128
    nop

    :pswitch_data_0
    .packed-switch 0x44d
        :pswitch_0
        :pswitch_1
        :pswitch_2
        :pswitch_3
        :pswitch_4
        :pswitch_5
        :pswitch_6
        :pswitch_7
        :pswitch_8
        :pswitch_9
        :pswitch_a
        :pswitch_b
    .end packed-switch
.end method


# virtual methods
.method protected proxy()Ltas/internal/camera/client/CameraProxy;
    .locals 1

    .prologue
    .line 79
    iget-object v0, p0, Ltas/camera/id/AVM;->proxy:Ltas/internal/camera/client/CameraProxy;

    return-object v0
.end method

.method public setListener(Ltas/camera/BaseListener;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ltas/camera/BaseListener",
            "<",
            "Ltas/camera/id/AVM;",
            ">;)V"
        }
    .end annotation

    .prologue
    .line 83
    .local p1, "l":Ltas/camera/BaseListener;, "Ltas/camera/BaseListener<Ltas/camera/id/AVM;>;"
    iget-object v0, p0, Ltas/camera/id/AVM;->proxy:Ltas/internal/camera/client/CameraProxy;

    invoke-virtual {v0, p1}, Ltas/internal/camera/client/CameraProxy;->setListener(Ltas/camera/BaseListener;)V

    .line 82
    return-void
.end method
