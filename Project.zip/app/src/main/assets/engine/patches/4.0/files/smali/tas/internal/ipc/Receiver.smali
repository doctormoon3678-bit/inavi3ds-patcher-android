.class public Ltas/internal/ipc/Receiver;
.super Ljava/lang/Object;
.source "Receiver.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ltas/internal/ipc/Receiver$ServiceBinder;
    }
.end annotation


# instance fields
.field private mAnonymousCallback:Ltas/ipc/ReceiverSession$Callback;

.field private mContext:Landroid/content/Context;

.field mDispatcher:Ltas/internal/ipc/Dispatcher;

.field mExtra:Landroid/os/Bundle;

.field mLooper:Landroid/os/Looper;

.field private mMgr:Ltas/internal/ipc/ReceiverManager;

.field mOnline:Z

.field private final mRequestedSessions:Landroid/util/ArrayMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/util/ArrayMap",
            "<",
            "Ljava/lang/String;",
            "Ltas/ipc/ReceiverSession$Callback;",
            ">;"
        }
    .end annotation
.end field

.field private final mSessions:Landroid/util/ArrayMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/util/ArrayMap",
            "<",
            "Ljava/lang/Long;",
            "Ltas/ipc/ReceiverSession;",
            ">;"
        }
    .end annotation
.end field

.field mToken:Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;

.field final mWatchList:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List",
            "<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field public final name:Ljava/lang/String;

.field public final pkg:Ljava/lang/String;

.field srvcls:Ljava/lang/Class;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/Class",
            "<+",
            "Ltas/ipc/MsgReceiverService;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Landroid/content/Context;Ljava/lang/String;Landroid/os/Looper;Ljava/lang/Class;)V
    .locals 1
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "name"    # Ljava/lang/String;
    .param p3, "looper"    # Landroid/os/Looper;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/lang/String;",
            "Landroid/os/Looper;",
            "Ljava/lang/Class",
            "<+",
            "Ltas/ipc/MsgReceiverService;",
            ">;)V"
        }
    .end annotation

    .prologue
    .line 50
    .local p4, "srvcls":Ljava/lang/Class;, "Ljava/lang/Class<+Ltas/ipc/MsgReceiverService;>;"
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 33
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Ltas/internal/ipc/Receiver;->mWatchList:Ljava/util/List;

    .line 43
    new-instance v0, Landroid/util/ArrayMap;

    invoke-direct {v0}, Landroid/util/ArrayMap;-><init>()V

    .line 42
    iput-object v0, p0, Ltas/internal/ipc/Receiver;->mSessions:Landroid/util/ArrayMap;

    .line 46
    new-instance v0, Landroid/util/ArrayMap;

    invoke-direct {v0}, Landroid/util/ArrayMap;-><init>()V

    .line 45
    iput-object v0, p0, Ltas/internal/ipc/Receiver;->mRequestedSessions:Landroid/util/ArrayMap;

    .line 52
    iput-object p1, p0, Ltas/internal/ipc/Receiver;->mContext:Landroid/content/Context;

    .line 53
    iput-object p3, p0, Ltas/internal/ipc/Receiver;->mLooper:Landroid/os/Looper;

    .line 54
    iput-object p4, p0, Ltas/internal/ipc/Receiver;->srvcls:Ljava/lang/Class;

    .line 55
    iput-object p2, p0, Ltas/internal/ipc/Receiver;->name:Ljava/lang/String;

    .line 56
    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Ltas/internal/ipc/Receiver;->pkg:Ljava/lang/String;

    .line 57
    invoke-virtual {p0}, Ltas/internal/ipc/Receiver;->initialize()V

    .line 51
    return-void
.end method

.method public static createServiceBinder()Landroid/os/IBinder;
    .locals 2

    .prologue
    .line 228
    new-instance v0, Ltas/internal/ipc/Receiver$ServiceBinder;

    invoke-static {}, Ltas/internal/ipc/ReceiverManager;->get()Ltas/internal/ipc/ReceiverManager;

    move-result-object v1

    invoke-direct {v0, v1}, Ltas/internal/ipc/Receiver$ServiceBinder;-><init>(Ltas/internal/ipc/ReceiverManager;)V

    return-object v0
.end method


# virtual methods
.method public acceptAnonymousSession(Ltas/ipc/ReceiverSession$Callback;)V
    .locals 1
    .param p1, "cb"    # Ltas/ipc/ReceiverSession$Callback;

    .prologue
    .line 100
    iget-object v0, p0, Ltas/internal/ipc/Receiver;->mMgr:Ltas/internal/ipc/ReceiverManager;

    if-eqz v0, :cond_0

    iget-object v0, p0, Ltas/internal/ipc/Receiver;->mAnonymousCallback:Ltas/ipc/ReceiverSession$Callback;

    if-nez v0, :cond_0

    .line 101
    iput-object p1, p0, Ltas/internal/ipc/Receiver;->mAnonymousCallback:Ltas/ipc/ReceiverSession$Callback;

    .line 102
    iget-object v0, p0, Ltas/internal/ipc/Receiver;->mMgr:Ltas/internal/ipc/ReceiverManager;

    invoke-virtual {v0, p0}, Ltas/internal/ipc/ReceiverManager;->watchAnonymousSender(Ltas/internal/ipc/Receiver;)V

    .line 99
    :cond_0
    return-void
.end method

.method public acceptSession(Ljava/lang/String;Ltas/ipc/ReceiverSession$Callback;)V
    .locals 1
    .param p1, "name"    # Ljava/lang/String;
    .param p2, "cb"    # Ltas/ipc/ReceiverSession$Callback;

    .prologue
    .line 81
    iget-object v0, p0, Ltas/internal/ipc/Receiver;->mMgr:Ltas/internal/ipc/ReceiverManager;

    if-eqz v0, :cond_0

    iget-object v0, p0, Ltas/internal/ipc/Receiver;->mRequestedSessions:Landroid/util/ArrayMap;

    invoke-virtual {v0, p1}, Landroid/util/ArrayMap;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    .line 80
    :cond_0
    :goto_0
    return-void

    .line 82
    :cond_1
    iget-object v0, p0, Ltas/internal/ipc/Receiver;->mRequestedSessions:Landroid/util/ArrayMap;

    invoke-virtual {v0, p1, p2}, Landroid/util/ArrayMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 83
    iget-object v0, p0, Ltas/internal/ipc/Receiver;->mMgr:Ltas/internal/ipc/ReceiverManager;

    invoke-virtual {v0, p0, p1}, Ltas/internal/ipc/ReceiverManager;->watchSender(Ltas/internal/ipc/Receiver;Ljava/lang/String;)V

    goto :goto_0
.end method

.method addSession(JLtas/ipc/ReceiverSession;)V
    .locals 3
    .param p1, "id"    # J
    .param p3, "session"    # Ltas/ipc/ReceiverSession;

    .prologue
    .line 172
    iget-object v0, p0, Ltas/internal/ipc/Receiver;->mSessions:Landroid/util/ArrayMap;

    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    invoke-virtual {v0, v1, p3}, Landroid/util/ArrayMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 171
    return-void
.end method

.method public destroyAnonymousSession()V
    .locals 2

    .prologue
    const/4 v1, 0x0

    .line 107
    iget-object v0, p0, Ltas/internal/ipc/Receiver;->mMgr:Ltas/internal/ipc/ReceiverManager;

    if-eqz v0, :cond_0

    iget-object v0, p0, Ltas/internal/ipc/Receiver;->mAnonymousCallback:Ltas/ipc/ReceiverSession$Callback;

    if-eqz v0, :cond_0

    .line 108
    iput-object v1, p0, Ltas/internal/ipc/Receiver;->mAnonymousCallback:Ltas/ipc/ReceiverSession$Callback;

    .line 109
    iget-object v0, p0, Ltas/internal/ipc/Receiver;->mMgr:Ltas/internal/ipc/ReceiverManager;

    invoke-virtual {v0, p0}, Ltas/internal/ipc/ReceiverManager;->unwatchAnonymousSender(Ltas/internal/ipc/Receiver;)V

    .line 106
    :cond_0
    return-void
.end method

.method public destroySession(J)V
    .locals 3
    .param p1, "id"    # J

    .prologue
    .line 88
    iget-object v1, p0, Ltas/internal/ipc/Receiver;->mMgr:Ltas/internal/ipc/ReceiverManager;

    if-nez v1, :cond_0

    .line 89
    return-void

    .line 91
    :cond_0
    invoke-virtual {p0, p1, p2}, Ltas/internal/ipc/Receiver;->removeSession(J)Ltas/ipc/ReceiverSession;

    move-result-object v0

    .line 92
    .local v0, "session":Ltas/ipc/ReceiverSession;
    if-eqz v0, :cond_1

    .line 93
    iget-object v1, p0, Ltas/internal/ipc/Receiver;->mDispatcher:Ltas/internal/ipc/Dispatcher;

    const/16 v2, 0xca

    invoke-virtual {v1, v2, v0}, Ltas/internal/ipc/Dispatcher;->dispatch(ILtas/ipc/ReceiverSession;)V

    .line 94
    iget-object v1, p0, Ltas/internal/ipc/Receiver;->mRequestedSessions:Landroid/util/ArrayMap;

    iget-object v2, v0, Ltas/ipc/ReceiverSession;->name:Ljava/lang/String;

    invoke-virtual {v1, v2}, Landroid/util/ArrayMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 95
    iget-object v1, p0, Ltas/internal/ipc/Receiver;->mMgr:Ltas/internal/ipc/ReceiverManager;

    iget-object v2, v0, Ltas/ipc/ReceiverSession;->name:Ljava/lang/String;

    invoke-virtual {v1, p0, v2}, Ltas/internal/ipc/ReceiverManager;->unwatchSender(Ltas/internal/ipc/Receiver;Ljava/lang/String;)V

    .line 87
    :cond_1
    return-void
.end method

.method dispatchOffline(Ltas/ipc/ReceiverSession;)V
    .locals 2
    .param p1, "session"    # Ltas/ipc/ReceiverSession;

    .prologue
    .line 198
    iget-object v0, p1, Ltas/ipc/ReceiverSession;->cb:Ltas/ipc/ReceiverSession$Callback;

    .line 199
    .local v0, "cb":Ltas/ipc/ReceiverSession$Callback;
    if-eqz v0, :cond_0

    .line 200
    invoke-interface {v0, p1}, Ltas/ipc/ReceiverSession$Callback;->onSenderOffline(Ltas/ipc/ReceiverSession;)V

    .line 202
    :cond_0
    iget-object v1, p0, Ltas/internal/ipc/Receiver;->mAnonymousCallback:Ltas/ipc/ReceiverSession$Callback;

    if-eqz v1, :cond_1

    .line 203
    iget-object v1, p0, Ltas/internal/ipc/Receiver;->mAnonymousCallback:Ltas/ipc/ReceiverSession$Callback;

    invoke-interface {v1, p1}, Ltas/ipc/ReceiverSession$Callback;->onSenderOffline(Ltas/ipc/ReceiverSession;)V

    .line 197
    :cond_1
    return-void
.end method

.method dispatchOnline(Ltas/ipc/ReceiverSession;)V
    .locals 3
    .param p1, "session"    # Ltas/ipc/ReceiverSession;

    .prologue
    .line 184
    iget-object v0, p1, Ltas/ipc/ReceiverSession;->cb:Ltas/ipc/ReceiverSession$Callback;

    .line 185
    .local v0, "cb":Ltas/ipc/ReceiverSession$Callback;
    if-nez v0, :cond_0

    .line 186
    iget-object v1, p0, Ltas/internal/ipc/Receiver;->mRequestedSessions:Landroid/util/ArrayMap;

    iget-object v2, p1, Ltas/ipc/ReceiverSession;->name:Ljava/lang/String;

    invoke-virtual {v1, v2}, Landroid/util/ArrayMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "cb":Ltas/ipc/ReceiverSession$Callback;
    check-cast v0, Ltas/ipc/ReceiverSession$Callback;

    .line 187
    .restart local v0    # "cb":Ltas/ipc/ReceiverSession$Callback;
    iput-object v0, p1, Ltas/ipc/ReceiverSession;->cb:Ltas/ipc/ReceiverSession$Callback;

    .line 189
    :cond_0
    if-eqz v0, :cond_1

    .line 190
    invoke-interface {v0, p1}, Ltas/ipc/ReceiverSession$Callback;->onSenderOnline(Ltas/ipc/ReceiverSession;)V

    .line 192
    :cond_1
    iget-object v1, p0, Ltas/internal/ipc/Receiver;->mAnonymousCallback:Ltas/ipc/ReceiverSession$Callback;

    if-eqz v1, :cond_2

    .line 193
    iget-object v1, p0, Ltas/internal/ipc/Receiver;->mAnonymousCallback:Ltas/ipc/ReceiverSession$Callback;

    invoke-interface {v1, p1}, Ltas/ipc/ReceiverSession$Callback;->onSenderOnline(Ltas/ipc/ReceiverSession;)V

    .line 183
    :cond_2
    return-void
.end method

.method dispatchReceive(Ltas/ipc/ReceiverSession;Ltas/ipc/MsgData;)V
    .locals 3
    .param p1, "session"    # Ltas/ipc/ReceiverSession;
    .param p2, "msg"    # Ltas/ipc/MsgData;

    .prologue
    .line 218
    iget-object v0, p1, Ltas/ipc/ReceiverSession;->cb:Ltas/ipc/ReceiverSession$Callback;

    .line 219
    .local v0, "cb":Ltas/ipc/ReceiverSession$Callback;
    if-eqz v0, :cond_0

    .line 220
    iget v1, p2, Ltas/ipc/MsgData;->what:I

    invoke-interface {v0, p1, v1, p2}, Ltas/ipc/ReceiverSession$Callback;->onReceive(Ltas/ipc/ReceiverSession;ILtas/ipc/MsgData;)V

    .line 222
    :cond_0
    iget-object v1, p0, Ltas/internal/ipc/Receiver;->mAnonymousCallback:Ltas/ipc/ReceiverSession$Callback;

    if-eqz v1, :cond_1

    .line 223
    iget-object v1, p0, Ltas/internal/ipc/Receiver;->mAnonymousCallback:Ltas/ipc/ReceiverSession$Callback;

    iget v2, p2, Ltas/ipc/MsgData;->what:I

    invoke-interface {v1, p1, v2, p2}, Ltas/ipc/ReceiverSession$Callback;->onReceive(Ltas/ipc/ReceiverSession;ILtas/ipc/MsgData;)V

    .line 217
    :cond_1
    return-void
.end method

.method dispatchUpdate(Ltas/ipc/ReceiverSession;)V
    .locals 3
    .param p1, "session"    # Ltas/ipc/ReceiverSession;

    .prologue
    .line 208
    iget-object v0, p1, Ltas/ipc/ReceiverSession;->cb:Ltas/ipc/ReceiverSession$Callback;

    .line 209
    .local v0, "cb":Ltas/ipc/ReceiverSession$Callback;
    if-eqz v0, :cond_0

    .line 210
    iget-object v1, p1, Ltas/ipc/ReceiverSession;->extra:Landroid/os/Bundle;

    invoke-interface {v0, p1, v1}, Ltas/ipc/ReceiverSession$Callback;->onSenderUpdate(Ltas/ipc/ReceiverSession;Landroid/os/Bundle;)V

    .line 212
    :cond_0
    iget-object v1, p0, Ltas/internal/ipc/Receiver;->mAnonymousCallback:Ltas/ipc/ReceiverSession$Callback;

    if-eqz v1, :cond_1

    .line 213
    iget-object v1, p0, Ltas/internal/ipc/Receiver;->mAnonymousCallback:Ltas/ipc/ReceiverSession$Callback;

    iget-object v2, p1, Ltas/ipc/ReceiverSession;->extra:Landroid/os/Bundle;

    invoke-interface {v1, p1, v2}, Ltas/ipc/ReceiverSession$Callback;->onSenderUpdate(Ltas/ipc/ReceiverSession;Landroid/os/Bundle;)V

    .line 207
    :cond_1
    return-void
.end method

.method public getContext()Landroid/content/Context;
    .locals 1

    .prologue
    .line 61
    iget-object v0, p0, Ltas/internal/ipc/Receiver;->mContext:Landroid/content/Context;

    return-object v0
.end method

.method public getExtra()Landroid/os/Bundle;
    .locals 1

    .prologue
    .line 122
    iget-object v0, p0, Ltas/internal/ipc/Receiver;->mExtra:Landroid/os/Bundle;

    if-nez v0, :cond_0

    .line 123
    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    iput-object v0, p0, Ltas/internal/ipc/Receiver;->mExtra:Landroid/os/Bundle;

    .line 125
    :cond_0
    iget-object v0, p0, Ltas/internal/ipc/Receiver;->mExtra:Landroid/os/Bundle;

    return-object v0
.end method

.method getSession(J)Ltas/ipc/ReceiverSession;
    .locals 3
    .param p1, "id"    # J

    .prologue
    .line 164
    iget-object v0, p0, Ltas/internal/ipc/Receiver;->mSessions:Landroid/util/ArrayMap;

    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/util/ArrayMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/ipc/ReceiverSession;

    return-object v0
.end method

.method getSessions()Ljava/util/Collection;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Collection",
            "<",
            "Ltas/ipc/ReceiverSession;",
            ">;"
        }
    .end annotation

    .prologue
    .line 168
    iget-object v0, p0, Ltas/internal/ipc/Receiver;->mSessions:Landroid/util/ArrayMap;

    invoke-virtual {v0}, Landroid/util/ArrayMap;->values()Ljava/util/Collection;

    move-result-object v0

    return-object v0
.end method

.method hasAnonymousSession()Z
    .locals 1

    .prologue
    .line 180
    iget-object v0, p0, Ltas/internal/ipc/Receiver;->mAnonymousCallback:Ltas/ipc/ReceiverSession$Callback;

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    :goto_0
    return v0

    :cond_0
    const/4 v0, 0x0

    goto :goto_0
.end method

.method public initialize()V
    .locals 1

    .prologue
    .line 141
    iget-object v0, p0, Ltas/internal/ipc/Receiver;->mMgr:Ltas/internal/ipc/ReceiverManager;

    if-nez v0, :cond_0

    .line 142
    invoke-static {}, Ltas/internal/ipc/ReceiverManager;->get()Ltas/internal/ipc/ReceiverManager;

    move-result-object v0

    iput-object v0, p0, Ltas/internal/ipc/Receiver;->mMgr:Ltas/internal/ipc/ReceiverManager;

    .line 143
    iget-object v0, p0, Ltas/internal/ipc/Receiver;->mMgr:Ltas/internal/ipc/ReceiverManager;

    invoke-virtual {v0, p0}, Ltas/internal/ipc/ReceiverManager;->initialize(Ltas/internal/ipc/Receiver;)V

    .line 140
    :cond_0
    return-void
.end method

.method public isInitialized()Z
    .locals 1

    .prologue
    .line 156
    iget-object v0, p0, Ltas/internal/ipc/Receiver;->mMgr:Ltas/internal/ipc/ReceiverManager;

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    :goto_0
    return v0

    :cond_0
    const/4 v0, 0x0

    goto :goto_0
.end method

.method public isOnline()Z
    .locals 1

    .prologue
    .line 77
    iget-boolean v0, p0, Ltas/internal/ipc/Receiver;->mOnline:Z

    return v0
.end method

.method public isP2pMode()Z
    .locals 1

    .prologue
    .line 65
    iget-object v0, p0, Ltas/internal/ipc/Receiver;->srvcls:Ljava/lang/Class;

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    :goto_0
    return v0

    :cond_0
    const/4 v0, 0x0

    goto :goto_0
.end method

.method isWatchingSender(Ljava/lang/String;)Z
    .locals 1
    .param p1, "sender"    # Ljava/lang/String;

    .prologue
    .line 160
    iget-object v0, p0, Ltas/internal/ipc/Receiver;->mWatchList:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v0

    return v0
.end method

.method public offline()V
    .locals 1

    .prologue
    .line 73
    iget-object v0, p0, Ltas/internal/ipc/Receiver;->mMgr:Ltas/internal/ipc/ReceiverManager;

    if-eqz v0, :cond_0

    iget-object v0, p0, Ltas/internal/ipc/Receiver;->mMgr:Ltas/internal/ipc/ReceiverManager;

    invoke-virtual {v0, p0}, Ltas/internal/ipc/ReceiverManager;->offline(Ltas/internal/ipc/Receiver;)V

    .line 72
    :cond_0
    return-void
.end method

.method public online()V
    .locals 1

    .prologue
    .line 69
    iget-object v0, p0, Ltas/internal/ipc/Receiver;->mMgr:Ltas/internal/ipc/ReceiverManager;

    if-eqz v0, :cond_0

    iget-object v0, p0, Ltas/internal/ipc/Receiver;->mMgr:Ltas/internal/ipc/ReceiverManager;

    invoke-virtual {v0, p0}, Ltas/internal/ipc/ReceiverManager;->online(Ltas/internal/ipc/Receiver;)V

    .line 68
    :cond_0
    return-void
.end method

.method public peekExtra()Landroid/os/Bundle;
    .locals 1

    .prologue
    .line 129
    iget-object v0, p0, Ltas/internal/ipc/Receiver;->mExtra:Landroid/os/Bundle;

    return-object v0
.end method

.method public release()V
    .locals 2

    .prologue
    const/4 v1, 0x0

    .line 148
    iget-object v0, p0, Ltas/internal/ipc/Receiver;->mMgr:Ltas/internal/ipc/ReceiverManager;

    if-eqz v0, :cond_0

    .line 149
    iget-object v0, p0, Ltas/internal/ipc/Receiver;->mMgr:Ltas/internal/ipc/ReceiverManager;

    invoke-virtual {v0, p0}, Ltas/internal/ipc/ReceiverManager;->release(Ltas/internal/ipc/Receiver;)V

    .line 150
    iput-object v1, p0, Ltas/internal/ipc/Receiver;->mMgr:Ltas/internal/ipc/ReceiverManager;

    .line 151
    iget-object v0, p0, Ltas/internal/ipc/Receiver;->mWatchList:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->clear()V

    .line 147
    :cond_0
    return-void
.end method

.method removeSession(J)Ltas/ipc/ReceiverSession;
    .locals 3
    .param p1, "id"    # J

    .prologue
    .line 176
    iget-object v0, p0, Ltas/internal/ipc/Receiver;->mSessions:Landroid/util/ArrayMap;

    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/util/ArrayMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/ipc/ReceiverSession;

    return-object v0
.end method

.method public reply(Ltas/ipc/ReceiverSession;Ltas/ipc/MsgData;)V
    .locals 1
    .param p1, "session"    # Ltas/ipc/ReceiverSession;
    .param p2, "msg"    # Ltas/ipc/MsgData;

    .prologue
    .line 114
    iget-object v0, p0, Ltas/internal/ipc/Receiver;->mToken:Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;

    if-nez v0, :cond_0

    .line 115
    invoke-virtual {p2}, Ltas/ipc/MsgData;->recycle()V

    .line 116
    return-void

    .line 118
    :cond_0
    iget-object v0, p0, Ltas/internal/ipc/Receiver;->mToken:Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;

    invoke-virtual {v0, p0, p1, p2}, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->reply(Ltas/internal/ipc/Receiver;Ltas/ipc/ReceiverSession;Ltas/ipc/MsgData;)V

    .line 113
    return-void
.end method

.method public setExtra(Landroid/os/Bundle;)V
    .locals 0
    .param p1, "extra"    # Landroid/os/Bundle;

    .prologue
    .line 133
    iput-object p1, p0, Ltas/internal/ipc/Receiver;->mExtra:Landroid/os/Bundle;

    .line 132
    return-void
.end method

.method public update()V
    .locals 1

    .prologue
    .line 137
    iget-object v0, p0, Ltas/internal/ipc/Receiver;->mToken:Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;

    if-eqz v0, :cond_0

    iget-object v0, p0, Ltas/internal/ipc/Receiver;->mToken:Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;

    invoke-virtual {v0, p0}, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->update(Ltas/internal/ipc/Receiver;)V

    .line 136
    :cond_0
    return-void
.end method
