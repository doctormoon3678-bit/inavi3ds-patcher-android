.class public Ltas/internal/camera/server/ServerInComing$Proxy;
.super Ltas/internal/camera/server/IServerService$Stub;
.source "ServerInComing.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltas/internal/camera/server/ServerInComing;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "Proxy"
.end annotation


# instance fields
.field private mM:Ljava/lang/ref/WeakReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference",
            "<",
            "Ltas/internal/camera/server/ServerInComing;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Ltas/internal/camera/server/ServerInComing;)V
    .locals 1
    .param p1, "m"    # Ltas/internal/camera/server/ServerInComing;

    .prologue
    .line 87
    invoke-direct {p0}, Ltas/internal/camera/server/IServerService$Stub;-><init>()V

    .line 88
    new-instance v0, Ljava/lang/ref/WeakReference;

    invoke-direct {v0, p1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    iput-object v0, p0, Ltas/internal/camera/server/ServerInComing$Proxy;->mM:Ljava/lang/ref/WeakReference;

    .line 87
    return-void
.end method


# virtual methods
.method public cancel(Ltas/internal/camera/server/RemoteMessage;)V
    .locals 3
    .param p1, "rmsg"    # Ltas/internal/camera/server/RemoteMessage;

    .prologue
    .line 130
    iget-object v1, p0, Ltas/internal/camera/server/ServerInComing$Proxy;->mM:Ljava/lang/ref/WeakReference;

    invoke-virtual {v1}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/camera/server/ServerInComing;

    .line 131
    .local v0, "m":Ltas/internal/camera/server/ServerInComing;
    if-eqz v0, :cond_0

    .line 132
    invoke-static {}, Ltas/internal/camera/server/ServerInComing$Proxy;->getCallingPid()I

    move-result v1

    iget-object v2, p1, Ltas/internal/camera/server/RemoteMessage;->params:Ltas/internal/camera/InputParams;

    invoke-static {v0, v1, v2}, Ltas/internal/camera/server/ServerInComing;->-wrap2(Ltas/internal/camera/server/ServerInComing;ILtas/internal/camera/InputParams;)V

    .line 134
    :cond_0
    invoke-virtual {p1}, Ltas/internal/camera/server/RemoteMessage;->recycle()V

    .line 129
    return-void
.end method

.method public command(Ltas/internal/camera/server/RemoteMessage;)I
    .locals 4
    .param p1, "rmsg"    # Ltas/internal/camera/server/RemoteMessage;

    .prologue
    .line 139
    iget-object v2, p0, Ltas/internal/camera/server/ServerInComing$Proxy;->mM:Ljava/lang/ref/WeakReference;

    invoke-virtual {v2}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/camera/server/ServerInComing;

    .line 140
    .local v0, "m":Ltas/internal/camera/server/ServerInComing;
    const/4 v1, -0x1

    .line 141
    .local v1, "result":I
    if-eqz v0, :cond_0

    .line 142
    invoke-static {}, Ltas/internal/camera/server/ServerInComing$Proxy;->getCallingPid()I

    move-result v2

    iget-object v3, p1, Ltas/internal/camera/server/RemoteMessage;->params:Ltas/internal/camera/InputParams;

    invoke-static {v0, v2, v3}, Ltas/internal/camera/server/ServerInComing;->-wrap0(Ltas/internal/camera/server/ServerInComing;ILtas/internal/camera/InputParams;)I

    move-result v1

    .line 144
    :cond_0
    invoke-virtual {p1}, Ltas/internal/camera/server/RemoteMessage;->recycle()V

    .line 145
    return v1
.end method

.method public request(Ltas/internal/camera/server/RemoteMessage;)I
    .locals 4
    .param p1, "rmsg"    # Ltas/internal/camera/server/RemoteMessage;

    .prologue
    .line 119
    iget-object v2, p0, Ltas/internal/camera/server/ServerInComing$Proxy;->mM:Ljava/lang/ref/WeakReference;

    invoke-virtual {v2}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/camera/server/ServerInComing;

    .line 120
    .local v0, "m":Ltas/internal/camera/server/ServerInComing;
    const/4 v1, -0x1

    .line 121
    .local v1, "result":I
    if-eqz v0, :cond_0

    .line 122
    invoke-static {}, Ltas/internal/camera/server/ServerInComing$Proxy;->getCallingPid()I

    move-result v2

    iget-object v3, p1, Ltas/internal/camera/server/RemoteMessage;->params:Ltas/internal/camera/InputParams;

    invoke-static {v0, v2, v3}, Ltas/internal/camera/server/ServerInComing;->-wrap1(Ltas/internal/camera/server/ServerInComing;ILtas/internal/camera/InputParams;)I

    move-result v1

    .line 124
    :cond_0
    invoke-virtual {p1}, Ltas/internal/camera/server/RemoteMessage;->recycle()V

    .line 125
    return v1
.end method

.method public setcallback(Ltas/internal/camera/server/IServerCallback;)V
    .locals 2
    .param p1, "cb"    # Ltas/internal/camera/server/IServerCallback;

    .prologue
    .line 93
    iget-object v1, p0, Ltas/internal/camera/server/ServerInComing$Proxy;->mM:Ljava/lang/ref/WeakReference;

    invoke-virtual {v1}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/camera/server/ServerInComing;

    .line 94
    .local v0, "m":Ltas/internal/camera/server/ServerInComing;
    if-eqz v0, :cond_0

    if-eqz p1, :cond_0

    .line 95
    invoke-static {}, Ltas/internal/camera/server/ServerInComing$Proxy;->getCallingPid()I

    move-result v1

    invoke-static {v0, v1, p1}, Ltas/internal/camera/server/ServerInComing;->-wrap3(Ltas/internal/camera/server/ServerInComing;ILtas/internal/camera/server/IServerCallback;)V

    .line 92
    :cond_0
    return-void
.end method

.method public unwatch(Ltas/internal/camera/server/RemoteMessage;)V
    .locals 3
    .param p1, "rmsg"    # Ltas/internal/camera/server/RemoteMessage;

    .prologue
    .line 110
    iget-object v1, p0, Ltas/internal/camera/server/ServerInComing$Proxy;->mM:Ljava/lang/ref/WeakReference;

    invoke-virtual {v1}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/camera/server/ServerInComing;

    .line 111
    .local v0, "m":Ltas/internal/camera/server/ServerInComing;
    if-eqz v0, :cond_0

    .line 112
    invoke-static {}, Ltas/internal/camera/server/ServerInComing$Proxy;->getCallingPid()I

    move-result v1

    iget-object v2, p1, Ltas/internal/camera/server/RemoteMessage;->params:Ltas/internal/camera/InputParams;

    invoke-static {v0, v1, v2}, Ltas/internal/camera/server/ServerInComing;->-wrap4(Ltas/internal/camera/server/ServerInComing;ILtas/internal/camera/InputParams;)V

    .line 114
    :cond_0
    invoke-virtual {p1}, Ltas/internal/camera/server/RemoteMessage;->recycle()V

    .line 109
    return-void
.end method

.method public watch(Ltas/internal/camera/server/RemoteMessage;)V
    .locals 3
    .param p1, "rmsg"    # Ltas/internal/camera/server/RemoteMessage;

    .prologue
    .line 101
    iget-object v1, p0, Ltas/internal/camera/server/ServerInComing$Proxy;->mM:Ljava/lang/ref/WeakReference;

    invoke-virtual {v1}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/camera/server/ServerInComing;

    .line 102
    .local v0, "m":Ltas/internal/camera/server/ServerInComing;
    if-eqz v0, :cond_0

    .line 103
    invoke-static {}, Ltas/internal/camera/server/ServerInComing$Proxy;->getCallingPid()I

    move-result v1

    iget-object v2, p1, Ltas/internal/camera/server/RemoteMessage;->params:Ltas/internal/camera/InputParams;

    invoke-static {v0, v1, v2}, Ltas/internal/camera/server/ServerInComing;->-wrap5(Ltas/internal/camera/server/ServerInComing;ILtas/internal/camera/InputParams;)V

    .line 105
    :cond_0
    invoke-virtual {p1}, Ltas/internal/camera/server/RemoteMessage;->recycle()V

    .line 100
    return-void
.end method
