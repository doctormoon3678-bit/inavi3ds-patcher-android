.class public Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;
.super Lcom/thinkware/sundo/inavi3d/MainActivity;
.source "UnitedSearchActivity.java"

# interfaces
.implements Landroid/view/View$OnClickListener;
.implements Landroid/widget/RadioGroup$OnCheckedChangeListener;
.implements Landroid/widget/TextView$OnEditorActionListener;
.implements Landroid/view/View$OnFocusChangeListener;
.implements Lcom/thinkware/sundo/inavi3d/ui/SIPLayout$SIPLayoutListener;
.implements Lcom/thinkware/sundo/inavi3d/ui/SIPQwertyLayout$SIPQwertyLayoutListener;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$OnceRunhandler;,
        Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$AntiClickhandler;
    }
.end annotation


# static fields
.field static final QUERY_HISTORY_MAX_COUNT:I = 0xc

.field static RET_NEED_ADDR_NAME_SELECT_MODE:I

.field static RET_NEED_ADMIN_SELECT_MODE:I

.field static RET_NEED_SANGHO_SELECT_MODE:I

.field static RET_SEARCH_FAIL:I

.field static RET_SEARCH_OK:I

.field static mActivity:Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;

.field static syncObjectRecommend:Ljava/lang/Object;


# instance fields
.field final EDIT_MAX_LENGTH:I

.field adtPopupString:Lcom/thinkware/sundo/inavi3d/ui/adapter/CustomAdapter$CustumRadioItemAdapter;

.field arrPopupData:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList",
            "<",
            "Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$AdminCandidate;",
            ">;"
        }
    .end annotation
.end field

.field arrPopupString:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList",
            "<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field bRetForLiveSearch:I

.field bShowPopup:Z

.field btnTabAddr:Landroid/widget/Button;

.field btnTabAround:Landroid/widget/Button;

.field btnTabICode:Landroid/widget/Button;

.field btnTabName:Landroid/widget/Button;

.field btnTabUnited:Landroid/widget/Button;

.field flipper:Landroid/widget/ViewFlipper;

.field layoutGapBottom:Landroid/widget/LinearLayout;

.field layoutGapMiddle:Landroid/widget/LinearLayout;

.field layoutGapTop:Landroid/widget/LinearLayout;

.field layoutRecommendFirst:Landroid/widget/LinearLayout;

.field layoutRecommendSecond:Landroid/widget/LinearLayout;

.field lstPopup:Landroid/widget/ListView;

.field private mAdminDlg:Landroid/app/Dialog;

.field mBtnErase:Landroid/widget/Button;

.field mBtnLive:Landroid/widget/Button;

.field mBtnSearch:Landroid/widget/ImageButton;

.field mBtnSetRegion:Landroid/widget/Button;

.field mEditInput:Landroid/widget/EditText;

.field private mHelpDialog:Landroid/app/Dialog;

.field private mLiveAgreeDialog:Landroid/app/Dialog;

.field mUnitedSearchTask:Lcom/thinkware/sundo/inavi3d/INaviTask;

.field mUnitedSearchTaskInterFace:Lcom/thinkware/sundo/inavi3d/INaviTask$iINaviTaskInterFace;

.field mWatcher:Landroid/text/TextWatcher;

.field m_ButtonArr:[Landroid/widget/Button;

.field m_CarDPXY:Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr$XYInfo;

.field m_CurrentDPXY:Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr$XYInfo;

.field m_ScrollViewRecommendFirst:Landroid/widget/HorizontalScrollView;

.field m_ScrollViewRecommendSecond:Landroid/widget/HorizontalScrollView;

.field m_SearchOption:Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;

.field m_StringColorIndex:Lcom/thinkware/sundo/inavi3d/ui/component/SrchResultColorIndex;

.field m_TempOption:Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;

.field m_ViewLineArr:[Landroid/view/View;

.field private m_bAddMode:Z

.field m_bCancleRecommend:Z

.field public m_bChangeBeforeKeyword:Z

.field m_bChangeClearKeyword:Z

.field m_bChangeKeyword:Z

.field m_bIsExistSpaceInKeyword:Z

.field m_bLiveSrch:Z

.field private m_bOnceRun:Z

.field m_bReSrch:Z

.field m_bSearchTimeCheck:Z

.field m_bShowOverFlowMsg:Z

.field public m_beforeParam:Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/UserDataMgr$beforeKeyParam;

.field m_btnDelHistory:Landroid/widget/Button;

.field m_btnHelpNew:Landroid/widget/Button;

.field m_btnRecent:Landroid/widget/TextView;

.field m_layoutHelpNew:Landroid/widget/LinearLayout;

.field m_layoutQueryHistory:Landroid/widget/LinearLayout;

.field m_layoutRecentWord:Landroid/widget/LinearLayout;

.field private m_nHistoryCount:I

.field m_nInputSpaceNum:I

.field m_nLocalNameIndex:I

.field m_nPrevBackKey:I

.field m_nSanghoIndex:I

.field m_strCurQuery:Ljava/lang/String;

.field m_strHistoryQuery:Ljava/lang/String;

.field m_strNewKeyword:Ljava/lang/String;

.field m_strPrevQuery:Ljava/lang/String;

.field m_strQuery:Ljava/lang/String;

.field private mode:I

.field nRetUnitedSearch:I

.field wordData:Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$RecommendedWordData;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .prologue
    .line 130
    const/4 v0, 0x0

    sput v0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->RET_SEARCH_FAIL:I

    .line 131
    const/4 v0, 0x1

    sput v0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->RET_SEARCH_OK:I

    .line 132
    const/4 v0, -0x2

    sput v0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->RET_NEED_ADDR_NAME_SELECT_MODE:I

    .line 133
    const/4 v0, -0x3

    sput v0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->RET_NEED_SANGHO_SELECT_MODE:I

    .line 134
    const/4 v0, -0x4

    sput v0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->RET_NEED_ADMIN_SELECT_MODE:I

    .line 676
    const/4 v0, 0x0

    sput-object v0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mActivity:Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;

    .line 1091
    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->syncObjectRecommend:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>()V
    .locals 4

    .prologue
    const/4 v3, -0x1

    const/4 v2, 0x0

    const/4 v1, 0x0

    .line 81
    invoke-direct {p0}, Lcom/thinkware/sundo/inavi3d/MainActivity;-><init>()V

    .line 84
    const/16 v0, 0x10

    iput v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->EDIT_MAX_LENGTH:I

    .line 99
    const-string v0, ""

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strQuery:Ljava/lang/String;

    .line 114
    iput v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_nHistoryCount:I

    .line 119
    iput v3, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_nSanghoIndex:I

    .line 120
    iput v3, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_nLocalNameIndex:I

    .line 125
    iput-object v2, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mHelpDialog:Landroid/app/Dialog;

    .line 137
    iput-object v2, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mAdminDlg:Landroid/app/Dialog;

    .line 144
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bLiveSrch:Z

    .line 145
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bReSrch:Z

    .line 148
    iput-object v2, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mLiveAgreeDialog:Landroid/app/Dialog;

    .line 163
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bIsExistSpaceInKeyword:Z

    .line 166
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bSearchTimeCheck:Z

    .line 169
    iput v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mode:I

    .line 170
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bAddMode:Z

    .line 172
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bOnceRun:Z

    .line 199
    const-string v0, ""

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strNewKeyword:Ljava/lang/String;

    .line 200
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bChangeKeyword:Z

    .line 201
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bChangeClearKeyword:Z

    .line 202
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bShowOverFlowMsg:Z

    .line 203
    iput v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_nInputSpaceNum:I

    .line 204
    iput v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_nPrevBackKey:I

    .line 295
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bChangeBeforeKeyword:Z

    .line 358
    new-instance v0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$3;

    invoke-direct {v0, p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$3;-><init>(Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;)V

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mWatcher:Landroid/text/TextWatcher;

    .line 1083
    new-instance v0, Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$RecommendedWordData;

    invoke-direct {v0}, Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$RecommendedWordData;-><init>()V

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->wordData:Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$RecommendedWordData;

    .line 1084
    const-string v0, ""

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strPrevQuery:Ljava/lang/String;

    .line 1085
    const-string v0, ""

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strCurQuery:Ljava/lang/String;

    .line 1086
    new-instance v0, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr$XYInfo;

    invoke-direct {v0}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr$XYInfo;-><init>()V

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_CurrentDPXY:Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr$XYInfo;

    .line 1087
    new-instance v0, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr$XYInfo;

    invoke-direct {v0}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr$XYInfo;-><init>()V

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_CarDPXY:Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr$XYInfo;

    .line 1088
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bCancleRecommend:Z

    .line 1089
    iput-object v2, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_ButtonArr:[Landroid/widget/Button;

    .line 1090
    iput-object v2, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_ViewLineArr:[Landroid/view/View;

    .line 1093
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/ui/component/SrchResultColorIndex;->getInstance()Lcom/thinkware/sundo/inavi3d/ui/component/SrchResultColorIndex;

    move-result-object v0

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_StringColorIndex:Lcom/thinkware/sundo/inavi3d/ui/component/SrchResultColorIndex;

    .line 2038
    iput v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->bRetForLiveSearch:I

    .line 2158
    iput-object v2, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mUnitedSearchTask:Lcom/thinkware/sundo/inavi3d/INaviTask;

    .line 2159
    new-instance v0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$19;

    invoke-direct {v0, p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$19;-><init>(Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;)V

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mUnitedSearchTaskInterFace:Lcom/thinkware/sundo/inavi3d/INaviTask$iINaviTaskInterFace;

    .line 2273
    iput v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->nRetUnitedSearch:I

    .line 2551
    return-void
.end method

.method private ChangeBeforeKeyword()V
    .locals 3

    .prologue
    .line 299
    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bChangeBeforeKeyword:Z

    .line 301
    const-string v0, "HYO"

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "HYO ChangeBeforeKeyword => before="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_beforeParam:Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/UserDataMgr$beforeKeyParam;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/UserDataMgr$beforeKeyParam;->strBeforeKeyword:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ", curIdx="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_beforeParam:Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/UserDataMgr$beforeKeyParam;

    iget v2, v2, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/UserDataMgr$beforeKeyParam;->nCurIndex:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/thinkware/sundo/inavi3d/LOGTW;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 304
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    const-string v1, ""

    invoke-virtual {v0, v1}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    .line 305
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_beforeParam:Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/UserDataMgr$beforeKeyParam;

    iget-object v1, v1, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/UserDataMgr$beforeKeyParam;->strBeforeKeyword:Ljava/lang/String;

    invoke-virtual {v0, v1}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    .line 307
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_beforeParam:Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/UserDataMgr$beforeKeyParam;

    iget v0, v0, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/UserDataMgr$beforeKeyParam;->nCurIndex:I

    if-ltz v0, :cond_0

    .line 308
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_beforeParam:Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/UserDataMgr$beforeKeyParam;

    iget v1, v1, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/UserDataMgr$beforeKeyParam;->nCurIndex:I

    invoke-virtual {v0, v1}, Landroid/widget/EditText;->setSelection(I)V

    .line 309
    :cond_0
    return-void
.end method

.method private ChangeEditClear()V
    .locals 2

    .prologue
    .line 230
    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bChangeClearKeyword:Z

    .line 231
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    const-string v1, ""

    invoke-virtual {v0, v1}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    .line 232
    return-void
.end method

.method private ChangeEditText()V
    .locals 2

    .prologue
    .line 208
    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bChangeKeyword:Z

    .line 209
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    const-string v1, ""

    invoke-virtual {v0, v1}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    .line 210
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strNewKeyword:Ljava/lang/String;

    invoke-virtual {v0, v1}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    .line 211
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strNewKeyword:Ljava/lang/String;

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/widget/EditText;->setSelection(I)V

    .line 212
    const-string v0, ""

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strNewKeyword:Ljava/lang/String;

    .line 213
    return-void
.end method

.method private ChangeFirstSpaceDelete()V
    .locals 4

    .prologue
    const/4 v3, 0x2

    .line 217
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    invoke-virtual {v1}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    .line 218
    .local v0, "strKey":Ljava/lang/String;
    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    .line 220
    iput v3, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_nInputSpaceNum:I

    .line 222
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    const-string v2, ""

    invoke-virtual {v1, v2}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    .line 223
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    invoke-virtual {v1, v0}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    .line 224
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v2

    invoke-virtual {v1, v2}, Landroid/widget/EditText;->setSelection(I)V

    .line 226
    iput v3, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_nInputSpaceNum:I

    .line 227
    return-void
.end method

.method private EraseSpaceInEditText()V
    .locals 10

    .prologue
    const/4 v9, 0x1

    .line 320
    iget-object v7, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    invoke-virtual {v7}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v5

    .line 321
    .local v5, "strKey":Ljava/lang/String;
    const-string v6, ""

    .line 322
    .local v6, "strNewKey":Ljava/lang/String;
    invoke-virtual {v5}, Ljava/lang/String;->length()I

    move-result v3

    .line 324
    .local v3, "nLen":I
    const/4 v0, 0x0

    .line 325
    .local v0, "bSpaceFound":Z
    const/4 v4, 0x0

    .line 328
    .local v4, "nSpaceCount":I
    invoke-virtual {p0, v9}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->enableRegionBtn(Z)V

    .line 331
    const/4 v2, 0x0

    .local v2, "ii":I
    :goto_0
    if-ge v2, v3, :cond_2

    .line 332
    invoke-virtual {v5, v2}, Ljava/lang/String;->charAt(I)C

    move-result v1

    .line 333
    .local v1, "ch":C
    const/16 v7, 0x20

    if-eq v1, v7, :cond_0

    .line 334
    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v7, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-static {v1}, Ljava/lang/Character;->toString(C)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    .line 331
    :goto_1
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    .line 336
    :cond_0
    add-int/lit8 v4, v4, 0x1

    .line 337
    if-ne v4, v9, :cond_1

    if-eqz v2, :cond_1

    add-int/lit8 v7, v3, -0x1

    if-eq v2, v7, :cond_1

    .line 338
    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v7, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-static {v1}, Ljava/lang/Character;->toString(C)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    goto :goto_1

    .line 340
    :cond_1
    const/4 v0, 0x1

    goto :goto_1

    .line 345
    .end local v1    # "ch":C
    :cond_2
    if-eqz v0, :cond_3

    .line 346
    iput-boolean v9, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bCancleRecommend:Z

    .line 347
    iget-object v7, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    const-string v8, ""

    invoke-virtual {v7, v8}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    .line 348
    iput-boolean v9, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bCancleRecommend:Z

    .line 349
    iget-object v7, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    invoke-virtual {v7, v6}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    .line 350
    iget-object v7, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    invoke-virtual {v6}, Ljava/lang/String;->length()I

    move-result v8

    invoke-virtual {v7, v8}, Landroid/widget/EditText;->setSelection(I)V

    .line 351
    iget-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bLiveSrch:Z

    if-nez v7, :cond_3

    .line 352
    invoke-virtual {p0, v9}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->enableRegionBtn(Z)V

    .line 356
    :cond_3
    return-void
.end method

.method private MakeAdminCandidatePopup()Z
    .locals 7

    .prologue
    const/4 v6, 0x0

    .line 175
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->arrPopupString:Ljava/util/ArrayList;

    invoke-virtual {v4}, Ljava/util/ArrayList;->clear()V

    .line 176
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->arrPopupData:Ljava/util/ArrayList;

    invoke-virtual {v4}, Ljava/util/ArrayList;->clear()V

    .line 177
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->USGetAdminCandidateCnt()I

    move-result v2

    .line 178
    .local v2, "nCnt":I
    new-instance v3, Ljava/util/TreeMap;

    invoke-direct {v3}, Ljava/util/TreeMap;-><init>()V

    .line 180
    .local v3, "tempSortingMap":Ljava/util/TreeMap;, "Ljava/util/TreeMap<Ljava/lang/String;Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$AdminCandidate;>;"
    const/4 v1, 0x0

    .local v1, "ii":I
    :goto_0
    if-ge v1, v2, :cond_0

    .line 182
    new-instance v0, Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$AdminCandidate;

    invoke-direct {v0}, Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$AdminCandidate;-><init>()V

    .line 183
    .local v0, "data":Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$AdminCandidate;
    invoke-static {v1, v0}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->USGetAdminCandidateData(ILcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$AdminCandidate;)I

    .line 185
    iget-object v4, v0, Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$AdminCandidate;->m_cpAdminName:Ljava/lang/String;

    invoke-virtual {v3, v4, v0}, Ljava/util/TreeMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 180
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    .line 188
    .end local v0    # "data":Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$AdminCandidate;
    :cond_0
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->arrPopupData:Ljava/util/ArrayList;

    invoke-virtual {v3}, Ljava/util/TreeMap;->values()Ljava/util/Collection;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 189
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->arrPopupString:Ljava/util/ArrayList;

    invoke-virtual {v3}, Ljava/util/TreeMap;->keySet()Ljava/util/Set;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 191
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->adtPopupString:Lcom/thinkware/sundo/inavi3d/ui/adapter/CustomAdapter$CustumRadioItemAdapter;

    invoke-virtual {v4, v6}, Lcom/thinkware/sundo/inavi3d/ui/adapter/CustomAdapter$CustumRadioItemAdapter;->SetCheckIndex(I)V

    .line 192
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->adtPopupString:Lcom/thinkware/sundo/inavi3d/ui/adapter/CustomAdapter$CustumRadioItemAdapter;

    invoke-virtual {v4}, Lcom/thinkware/sundo/inavi3d/ui/adapter/CustomAdapter$CustumRadioItemAdapter;->notifyDataSetChanged()V

    .line 194
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->lstPopup:Landroid/widget/ListView;

    invoke-virtual {v4, v6, v6}, Landroid/widget/ListView;->setSelectionFromTop(II)V

    .line 196
    const/4 v4, 0x1

    return v4
.end method

.method public static SetNetwork(Z)V
    .locals 3
    .param p0, "bNetwork"    # Z

    .prologue
    const/4 v2, 0x1

    .line 2605
    sget-object v0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mActivity:Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;

    if-nez v0, :cond_1

    .line 2618
    :cond_0
    :goto_0
    return-void

    .line 2607
    :cond_1
    if-ne p0, v2, :cond_0

    .line 2608
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->getInstance()Lcom/thinkware/sundo/inavi3d/InaviConfig;

    move-result-object v0

    const/16 v1, 0x11b

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->CNaviConfigGet(I)I

    move-result v0

    if-ne v0, v2, :cond_0

    .line 2609
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/livesearch/LiveSearchManager;->getInstance()Lcom/thinkware/sundo/inavi3d/livesearch/LiveSearchManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/livesearch/LiveSearchManager;->isAgreed()Z

    move-result v0

    if-ne v0, v2, :cond_2

    .line 2610
    sget-object v0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mActivity:Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;

    iput-boolean v2, v0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bLiveSrch:Z

    .line 2611
    sget-object v0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mActivity:Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mBtnLive:Landroid/widget/Button;

    invoke-virtual {v0, v2}, Landroid/widget/Button;->setSelected(Z)V

    .line 2612
    sget-object v0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mActivity:Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mBtnLive:Landroid/widget/Button;

    invoke-virtual {v0}, Landroid/widget/Button;->invalidate()V

    goto :goto_0

    .line 2614
    :cond_2
    sget-object v0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mActivity:Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;

    invoke-direct {v0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->showLiveProvisionPopup()V

    goto :goto_0
.end method

.method private ShowInputOverflowMsg()V
    .locals 7

    .prologue
    const/16 v6, 0x10

    const/4 v5, 0x1

    const/4 v4, 0x0

    .line 264
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    invoke-virtual {v1, v4}, Landroid/widget/EditText;->setEnabled(Z)V

    .line 266
    iput-boolean v4, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bShowOverFlowMsg:Z

    .line 268
    iget-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->bShowPopup:Z

    if-nez v1, :cond_0

    .line 269
    const/16 v1, 0x30

    const-string v2, "\uc54c\ub9bc"

    const-string v3, "\ub354 \uc774\uc0c1 \uc785\ub825\ud560 \uc218 \uc5c6\uc2b5\ub2c8\ub2e4."

    invoke-static {v1, p0, v2, v3, v4}, Lcom/thinkware/sundo/inavi3d/ui/popup/PopupManager;->ShowPopup(ILandroid/content/Context;Ljava/lang/String;Ljava/lang/String;I)Lcom/thinkware/sundo/inavi3d/ui/popup/InaviPopup;

    move-result-object v0

    .line 271
    .local v0, "popup":Lcom/thinkware/sundo/inavi3d/ui/popup/InaviPopup;
    new-instance v1, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$2;

    invoke-direct {v1, p0, v0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$2;-><init>(Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;Lcom/thinkware/sundo/inavi3d/ui/popup/InaviPopup;)V

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/inavi3d/ui/popup/InaviPopup;->SetokListner(Landroid/view/View$OnClickListener;)Z

    .line 279
    iput-boolean v5, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->bShowPopup:Z

    .line 283
    .end local v0    # "popup":Lcom/thinkware/sundo/inavi3d/ui/popup/InaviPopup;
    :goto_0
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strNewKeyword:Ljava/lang/String;

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v1

    if-le v1, v6, :cond_1

    .line 284
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strNewKeyword:Ljava/lang/String;

    invoke-virtual {v2, v4, v6}, Ljava/lang/String;->subSequence(II)Ljava/lang/CharSequence;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    .line 287
    :goto_1
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    invoke-virtual {v2}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v2

    invoke-interface {v2}, Landroid/text/Editable;->length()I

    move-result v2

    invoke-virtual {v1, v2}, Landroid/widget/EditText;->setSelection(I)V

    .line 289
    const-string v1, ""

    iput-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strNewKeyword:Ljava/lang/String;

    .line 291
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    invoke-virtual {v1, v5}, Landroid/widget/EditText;->setEnabled(Z)V

    .line 292
    return-void

    .line 281
    :cond_0
    iput-boolean v4, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->bShowPopup:Z

    goto :goto_0

    .line 286
    :cond_1
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strNewKeyword:Ljava/lang/String;

    invoke-virtual {v1, v2}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    goto :goto_1
.end method

.method private _ShowInputOverflowMsg()V
    .locals 6

    .prologue
    const/4 v5, 0x1

    const/4 v4, 0x0

    .line 235
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    invoke-virtual {v1, v4}, Landroid/widget/EditText;->setEnabled(Z)V

    .line 236
    iput-boolean v4, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bShowOverFlowMsg:Z

    .line 237
    iget-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->bShowPopup:Z

    if-nez v1, :cond_0

    .line 238
    const/16 v1, 0x30

    const-string v2, "\uc54c\ub9bc"

    const-string v3, "\ub354 \uc774\uc0c1 \uc785\ub825\ud560 \uc218 \uc5c6\uc2b5\ub2c8\ub2e4."

    invoke-static {v1, p0, v2, v3, v4}, Lcom/thinkware/sundo/inavi3d/ui/popup/PopupManager;->ShowPopup(ILandroid/content/Context;Ljava/lang/String;Ljava/lang/String;I)Lcom/thinkware/sundo/inavi3d/ui/popup/InaviPopup;

    move-result-object v0

    .line 240
    .local v0, "popup":Lcom/thinkware/sundo/inavi3d/ui/popup/InaviPopup;
    new-instance v1, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$1;

    invoke-direct {v1, p0, v0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$1;-><init>(Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;Lcom/thinkware/sundo/inavi3d/ui/popup/InaviPopup;)V

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/inavi3d/ui/popup/InaviPopup;->SetokListner(Landroid/view/View$OnClickListener;)Z

    .line 248
    iput-boolean v5, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->bShowPopup:Z

    .line 260
    .end local v0    # "popup":Lcom/thinkware/sundo/inavi3d/ui/popup/InaviPopup;
    :goto_0
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    invoke-virtual {v1, v5}, Landroid/widget/EditText;->setEnabled(Z)V

    .line 261
    return-void

    .line 250
    :cond_0
    iput-boolean v4, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->bShowPopup:Z

    goto :goto_0
.end method

.method static synthetic access$000(Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;)V
    .locals 0
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;

    .prologue
    .line 81
    invoke-direct {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->ShowInputOverflowMsg()V

    return-void
.end method

.method static synthetic access$100(Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;)V
    .locals 0
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;

    .prologue
    .line 81
    invoke-direct {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->ChangeEditText()V

    return-void
.end method

.method static synthetic access$1000(Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;)Landroid/app/Dialog;
    .locals 1
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;

    .prologue
    .line 81
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mLiveAgreeDialog:Landroid/app/Dialog;

    return-object v0
.end method

.method static synthetic access$1100(Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;)V
    .locals 0
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;

    .prologue
    .line 81
    invoke-direct {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->tabButtonEnable()V

    return-void
.end method

.method static synthetic access$1200(Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;)V
    .locals 0
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;

    .prologue
    .line 81
    invoke-direct {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->loadQueryHistory()V

    return-void
.end method

.method static synthetic access$1300(Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;)Z
    .locals 1
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;

    .prologue
    .line 81
    invoke-direct {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->MakeAdminCandidatePopup()Z

    move-result v0

    return v0
.end method

.method static synthetic access$1402(Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;Z)Z
    .locals 0
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;
    .param p1, "x1"    # Z

    .prologue
    .line 81
    iput-boolean p1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bOnceRun:Z

    return p1
.end method

.method static synthetic access$200(Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;)V
    .locals 0
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;

    .prologue
    .line 81
    invoke-direct {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->ChangeEditClear()V

    return-void
.end method

.method static synthetic access$300(Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;)V
    .locals 0
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;

    .prologue
    .line 81
    invoke-direct {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->ChangeFirstSpaceDelete()V

    return-void
.end method

.method static synthetic access$400(Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;)V
    .locals 0
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;

    .prologue
    .line 81
    invoke-direct {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->ChangeBeforeKeyword()V

    return-void
.end method

.method static synthetic access$500(Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;Ljava/lang/String;)V
    .locals 0
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;
    .param p1, "x1"    # Ljava/lang/String;

    .prologue
    .line 81
    invoke-direct {p0, p1}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->loadRecommendWord(Ljava/lang/String;)V

    return-void
.end method

.method static synthetic access$600(Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;)V
    .locals 0
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;

    .prologue
    .line 81
    invoke-direct {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->hideRecommendedWord()V

    return-void
.end method

.method static synthetic access$700(Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;)V
    .locals 0
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;

    .prologue
    .line 81
    invoke-direct {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->EraseSpaceInEditText()V

    return-void
.end method

.method static synthetic access$800(Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;)Landroid/app/Dialog;
    .locals 1
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;

    .prologue
    .line 81
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mAdminDlg:Landroid/app/Dialog;

    return-object v0
.end method

.method static synthetic access$900(Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;)I
    .locals 1
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;

    .prologue
    .line 81
    iget v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mode:I

    return v0
.end method

.method private convertToLocalHorizontalCoordinate(Landroid/widget/EditText;F)F
    .locals 2
    .param p1, "textView2"    # Landroid/widget/EditText;
    .param p2, "x"    # F

    .prologue
    .line 653
    invoke-virtual {p1}, Landroid/widget/EditText;->getTotalPaddingLeft()I

    move-result v0

    int-to-float v0, v0

    sub-float/2addr p2, v0

    .line 655
    const/4 v0, 0x0

    invoke-static {v0, p2}, Ljava/lang/Math;->max(FF)F

    move-result p2

    .line 656
    invoke-virtual {p1}, Landroid/widget/EditText;->getWidth()I

    move-result v0

    invoke-virtual {p1}, Landroid/widget/EditText;->getTotalPaddingRight()I

    move-result v1

    sub-int/2addr v0, v1

    add-int/lit8 v0, v0, -0x1

    int-to-float v0, v0

    invoke-static {v0, p2}, Ljava/lang/Math;->min(FF)F

    move-result p2

    .line 657
    invoke-virtual {p1}, Landroid/widget/EditText;->getScrollX()I

    move-result v0

    int-to-float v0, v0

    add-float/2addr p2, v0

    .line 658
    return p2
.end method

.method private getLineAtCoordinate(Landroid/widget/EditText;F)I
    .locals 2
    .param p1, "textView2"    # Landroid/widget/EditText;
    .param p2, "y"    # F

    .prologue
    .line 662
    invoke-virtual {p1}, Landroid/widget/EditText;->getTotalPaddingTop()I

    move-result v0

    int-to-float v0, v0

    sub-float/2addr p2, v0

    .line 664
    const/4 v0, 0x0

    invoke-static {v0, p2}, Ljava/lang/Math;->max(FF)F

    move-result p2

    .line 665
    invoke-virtual {p1}, Landroid/widget/EditText;->getHeight()I

    move-result v0

    invoke-virtual {p1}, Landroid/widget/EditText;->getTotalPaddingBottom()I

    move-result v1

    sub-int/2addr v0, v1

    add-int/lit8 v0, v0, -0x1

    int-to-float v0, v0

    invoke-static {v0, p2}, Ljava/lang/Math;->min(FF)F

    move-result p2

    .line 666
    invoke-virtual {p1}, Landroid/widget/EditText;->getScrollY()I

    move-result v0

    int-to-float v0, v0

    add-float/2addr p2, v0

    .line 667
    invoke-virtual {p1}, Landroid/widget/EditText;->getLayout()Landroid/text/Layout;

    move-result-object v0

    float-to-int v1, p2

    invoke-virtual {v0, v1}, Landroid/text/Layout;->getLineForVertical(I)I

    move-result v0

    return v0
.end method

.method private getOffsetAtCoordinate(Landroid/widget/EditText;IF)I
    .locals 1
    .param p1, "textView2"    # Landroid/widget/EditText;
    .param p2, "line"    # I
    .param p3, "x"    # F

    .prologue
    .line 648
    invoke-direct {p0, p1, p3}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->convertToLocalHorizontalCoordinate(Landroid/widget/EditText;F)F

    move-result p3

    .line 649
    invoke-virtual {p1}, Landroid/widget/EditText;->getLayout()Landroid/text/Layout;

    move-result-object v0

    invoke-virtual {v0, p2, p3}, Landroid/text/Layout;->getOffsetForHorizontal(IF)I

    move-result v0

    return v0
.end method

.method private hideRecommendedWord()V
    .locals 3

    .prologue
    const/16 v2, 0x8

    .line 1270
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_layoutRecentWord:Landroid/widget/LinearLayout;

    invoke-virtual {v0}, Landroid/widget/LinearLayout;->getVisibility()I

    move-result v0

    if-eqz v0, :cond_0

    .line 1271
    const-string v0, ""

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strPrevQuery:Ljava/lang/String;

    .line 1272
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_layoutHelpNew:Landroid/widget/LinearLayout;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setVisibility(I)V

    .line 1273
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->layoutGapTop:Landroid/widget/LinearLayout;

    invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->setVisibility(I)V

    .line 1274
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->layoutGapMiddle:Landroid/widget/LinearLayout;

    invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->setVisibility(I)V

    .line 1275
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->layoutGapBottom:Landroid/widget/LinearLayout;

    invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->setVisibility(I)V

    .line 1276
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_ScrollViewRecommendFirst:Landroid/widget/HorizontalScrollView;

    invoke-virtual {v0, v2}, Landroid/widget/HorizontalScrollView;->setVisibility(I)V

    .line 1277
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_ScrollViewRecommendSecond:Landroid/widget/HorizontalScrollView;

    invoke-virtual {v0, v2}, Landroid/widget/HorizontalScrollView;->setVisibility(I)V

    .line 1279
    :cond_0
    return-void
.end method

.method private loadQueryHistory()V
    .locals 14

    .prologue
    .line 1283
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->USGetQueryHistoryCount()I

    move-result v4

    .line 1285
    .local v4, "nCount":I
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_layoutRecentWord:Landroid/widget/LinearLayout;

    invoke-virtual {v10}, Landroid/widget/LinearLayout;->getVisibility()I

    move-result v10

    if-eqz v10, :cond_0

    .line 1286
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_layoutRecentWord:Landroid/widget/LinearLayout;

    const/4 v11, 0x0

    invoke-virtual {v10, v11}, Landroid/widget/LinearLayout;->setVisibility(I)V

    .line 1289
    :cond_0
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_layoutQueryHistory:Landroid/widget/LinearLayout;

    invoke-virtual {v10}, Landroid/widget/LinearLayout;->removeAllViews()V

    .line 1294
    new-instance v6, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v10, -0x2

    const/4 v11, -0x1

    invoke-direct {v6, v10, v11}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 1298
    .local v6, "params":Landroid/widget/LinearLayout$LayoutParams;
    const/16 v10, 0x11

    iput v10, v6, Landroid/widget/LinearLayout$LayoutParams;->gravity:I

    .line 1300
    const/4 v1, 0x0

    .local v1, "i":I
    :goto_0
    if-ge v1, v4, :cond_3

    .line 1301
    new-instance v0, Landroid/widget/Button;

    invoke-direct {v0, p0}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    .line 1302
    .local v0, "btn":Landroid/widget/Button;
    invoke-static {v1}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->USGetQueryHistory(I)Ljava/lang/String;

    move-result-object v8

    .line 1304
    .local v8, "strQuery":Ljava/lang/String;
    move-object v7, v8

    .line 1306
    .local v7, "strOrginal":Ljava/lang/String;
    move-object v9, v8

    .line 1307
    .local v9, "strQueryInButton":Ljava/lang/String;
    invoke-virtual {v8}, Ljava/lang/String;->length()I

    move-result v5

    .line 1309
    .local v5, "nLen":I
    const/16 v10, 0xa

    if-le v5, v10, :cond_1

    .line 1310
    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x0

    const/16 v12, 0xa

    invoke-virtual {v8, v11, v12}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    const-string v11, "..."

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    .line 1312
    :cond_1
    invoke-virtual {v0, v8}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 1313
    const/4 v10, 0x0

    const/high16 v11, 0x41c00000    # 24.0f

    invoke-virtual {v0, v10, v11}, Landroid/widget/Button;->setTextSize(IF)V

    .line 1314
    const/16 v10, 0x6c

    const/16 v11, 0x88

    const/16 v12, 0xb0

    invoke-static {v10, v11, v12}, Landroid/graphics/Color;->rgb(III)I

    move-result v10

    invoke-virtual {v0, v10}, Landroid/widget/Button;->setTextColor(I)V

    .line 1315
    invoke-virtual {v0, v6}, Landroid/widget/Button;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 1316
    const v10, 0x7f02053b

    invoke-virtual {v0, v10}, Landroid/widget/Button;->setBackgroundResource(I)V

    .line 1317
    const/16 v10, 0xa5

    invoke-virtual {v0, v10}, Landroid/widget/Button;->setWidth(I)V

    .line 1318
    const/16 v10, 0xf

    const/4 v11, 0x0

    const/16 v12, 0xf

    const/4 v13, 0x0

    invoke-virtual {v0, v10, v11, v12, v13}, Landroid/widget/Button;->setPadding(IIII)V

    .line 1320
    new-instance v10, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$7;

    invoke-direct {v10, p0, v7}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$7;-><init>(Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;Ljava/lang/String;)V

    invoke-virtual {v0, v10}, Landroid/widget/Button;->setOnLongClickListener(Landroid/view/View$OnLongClickListener;)V

    .line 1361
    new-instance v10, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$8;

    invoke-direct {v10, p0, v7}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$8;-><init>(Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;Ljava/lang/String;)V

    invoke-virtual {v0, v10}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 1404
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_layoutQueryHistory:Landroid/widget/LinearLayout;

    invoke-virtual {v10, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 1406
    add-int/lit8 v10, v4, -0x1

    if-ge v1, v10, :cond_2

    .line 1407
    new-instance v2, Landroid/widget/ImageView;

    invoke-direct {v2, p0}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    .line 1408
    .local v2, "line":Landroid/widget/ImageView;
    const v10, 0x7f020c01

    invoke-virtual {v2, v10}, Landroid/widget/ImageView;->setImageResource(I)V

    .line 1409
    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v10, -0x2

    const/4 v11, -0x2

    const/high16 v12, 0x41800000    # 16.0f

    invoke-direct {v3, v10, v11, v12}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    .line 1412
    .local v3, "lineParams":Landroid/widget/LinearLayout$LayoutParams;
    const/16 v10, 0x10

    iput v10, v3, Landroid/widget/LinearLayout$LayoutParams;->gravity:I

    .line 1413
    invoke-virtual {v2, v3}, Landroid/widget/ImageView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 1414
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_layoutQueryHistory:Landroid/widget/LinearLayout;

    invoke-virtual {v10, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 1415
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v10

    invoke-virtual {v10}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->getScaleType()I

    move-result v10

    const/4 v11, 0x2

    if-lt v10, v11, :cond_2

    .line 1416
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INaviScaleManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INaviScaleManager;

    move-result-object v10

    invoke-virtual {v10, v2}, Lcom/thinkware/sundo/inavi3d/INaviScaleManager;->restoreScale1Pixel(Landroid/view/View;)V

    .line 1300
    .end local v2    # "line":Landroid/widget/ImageView;
    .end local v3    # "lineParams":Landroid/widget/LinearLayout$LayoutParams;
    :cond_2
    add-int/lit8 v1, v1, 0x1

    goto/16 :goto_0

    .line 1421
    .end local v0    # "btn":Landroid/widget/Button;
    .end local v5    # "nLen":I
    .end local v7    # "strOrginal":Ljava/lang/String;
    .end local v8    # "strQuery":Ljava/lang/String;
    .end local v9    # "strQueryInButton":Ljava/lang/String;
    :cond_3
    if-gtz v4, :cond_4

    .line 1424
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_btnDelHistory:Landroid/widget/Button;

    const/16 v11, 0x8

    invoke-virtual {v10, v11}, Landroid/widget/Button;->setVisibility(I)V

    .line 1430
    :goto_1
    return-void

    .line 1428
    :cond_4
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_btnDelHistory:Landroid/widget/Button;

    const/4 v11, 0x0

    invoke-virtual {v10, v11}, Landroid/widget/Button;->setVisibility(I)V

    goto :goto_1
.end method

.method private loadRecommendWord(Ljava/lang/String;)V
    .locals 4
    .param p1, "strQuery"    # Ljava/lang/String;

    .prologue
    const/4 v2, 0x1

    const/4 v3, 0x0

    .line 1097
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bCancleRecommend:Z

    if-eqz v0, :cond_1

    .line 1098
    iput-boolean v3, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bCancleRecommend:Z

    .line 1266
    :cond_0
    :goto_0
    return-void

    .line 1102
    :cond_1
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strPrevQuery:Ljava/lang/String;

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_0

    .line 1105
    iput-object p1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strPrevQuery:Ljava/lang/String;

    .line 1106
    invoke-static {v2}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->USRecommendedBreak(Z)I

    .line 1107
    new-instance v0, Lcom/thinkware/sundo/inavi3d/INaviTask;

    new-instance v1, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$6;

    invoke-direct {v1, p0, p1}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$6;-><init>(Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;Ljava/lang/String;)V

    invoke-direct {v0, v1, v3}, Lcom/thinkware/sundo/inavi3d/INaviTask;-><init>(Lcom/thinkware/sundo/inavi3d/INaviTask$iINaviTaskInterFace;Z)V

    new-array v1, v2, [Ljava/lang/Object;

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    aput-object v2, v1, v3

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/inavi3d/INaviTask;->execute([Ljava/lang/Object;)Landroid/os/AsyncTask;

    goto :goto_0
.end method

.method private showLiveProvisionPopup()V
    .locals 3

    .prologue
    .line 2597
    const-string v1, "Live"

    const-string v2, "showLiveProvisionPopup()"

    invoke-static {v1, v2}, Lcom/thinkware/sundo/inavi3d/LOGTW;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 2599
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mLiveAgreeDialog:Landroid/app/Dialog;

    const v2, 0x7f0a031a

    invoke-virtual {v1, v2}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    .line 2600
    .local v0, "txtLiveTerm":Landroid/widget/TextView;
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/livesearch/LiveSearchManager;->getInstance()Lcom/thinkware/sundo/inavi3d/livesearch/LiveSearchManager;

    move-result-object v1

    invoke-virtual {v1}, Lcom/thinkware/sundo/inavi3d/livesearch/LiveSearchManager;->getProvisionText()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2601
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mLiveAgreeDialog:Landroid/app/Dialog;

    invoke-virtual {v1}, Landroid/app/Dialog;->show()V

    .line 2602
    return-void
.end method

.method private tabButtonDesable()V
    .locals 3

    .prologue
    const/4 v2, 0x0

    const/4 v1, 0x0

    .line 1739
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabUnited:Landroid/widget/Button;

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setClickable(Z)V

    .line 1740
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabName:Landroid/widget/Button;

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setClickable(Z)V

    .line 1741
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabAddr:Landroid/widget/Button;

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setClickable(Z)V

    .line 1742
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabAround:Landroid/widget/Button;

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setClickable(Z)V

    .line 1743
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabICode:Landroid/widget/Button;

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setClickable(Z)V

    .line 1744
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabUnited:Landroid/widget/Button;

    invoke-virtual {v0, v2}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 1745
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabName:Landroid/widget/Button;

    invoke-virtual {v0, v2}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 1746
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabAddr:Landroid/widget/Button;

    invoke-virtual {v0, v2}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 1747
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabAround:Landroid/widget/Button;

    invoke-virtual {v0, v2}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 1748
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabICode:Landroid/widget/Button;

    invoke-virtual {v0, v2}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 1749
    return-void
.end method

.method private tabButtonEnable()V
    .locals 2

    .prologue
    const/4 v1, 0x1

    .line 1752
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabUnited:Landroid/widget/Button;

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setClickable(Z)V

    .line 1753
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabName:Landroid/widget/Button;

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setClickable(Z)V

    .line 1754
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabAddr:Landroid/widget/Button;

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setClickable(Z)V

    .line 1755
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabAround:Landroid/widget/Button;

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setClickable(Z)V

    .line 1756
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabICode:Landroid/widget/Button;

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setClickable(Z)V

    .line 1757
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabUnited:Landroid/widget/Button;

    invoke-virtual {v0, p0}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 1758
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabName:Landroid/widget/Button;

    invoke-virtual {v0, p0}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 1759
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabAddr:Landroid/widget/Button;

    invoke-virtual {v0, p0}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 1760
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabAround:Landroid/widget/Button;

    invoke-virtual {v0, p0}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 1761
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabICode:Landroid/widget/Button;

    invoke-virtual {v0, p0}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 1762
    return-void
.end method


# virtual methods
.method public DoLiveSearch()V
    .locals 4

    .prologue
    const/4 v2, 0x1

    const/4 v3, 0x0

    .line 2041
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strQuery:Ljava/lang/String;

    invoke-static {v0}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->USSetQuery(Ljava/lang/String;)V

    .line 2043
    new-instance v0, Lcom/thinkware/sundo/inavi3d/INaviTask;

    new-instance v1, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$18;

    invoke-direct {v1, p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$18;-><init>(Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;)V

    invoke-direct {v0, v1, v3, v2}, Lcom/thinkware/sundo/inavi3d/INaviTask;-><init>(Lcom/thinkware/sundo/inavi3d/INaviTask$iINaviTaskInterFace;ZZ)V

    new-array v1, v2, [Ljava/lang/Object;

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    aput-object v2, v1, v3

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/inavi3d/INaviTask;->execute([Ljava/lang/Object;)Landroid/os/AsyncTask;

    .line 2156
    return-void
.end method

.method public DoSearch()V
    .locals 3

    .prologue
    const/4 v2, 0x1

    .line 2374
    const-string v0, "wooks_t"

    const-string v1, "DoSearch:: start"

    invoke-static {v0, v1}, Lcom/thinkware/sundo/inavi3d/LOGTW;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 2376
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strQuery:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    if-ge v0, v2, :cond_0

    .line 2410
    :goto_0
    return-void

    .line 2379
    :cond_0
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strQuery:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strQuery:Ljava/lang/String;

    .line 2381
    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bSearchTimeCheck:Z

    .line 2383
    invoke-static {v2}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->USSetSubFacilityMerge(Z)V

    .line 2386
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strQuery:Ljava/lang/String;

    const-string v1, " "

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-ne v0, v2, :cond_1

    .line 2387
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strQuery:Ljava/lang/String;

    invoke-virtual {p0, v0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->IsIncludeAdminName(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_1

    .line 2388
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strQuery:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strQuery:Ljava/lang/String;

    .line 2392
    :cond_1
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strQuery:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->toUpperCase()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strQuery:Ljava/lang/String;

    .line 2393
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strQuery:Ljava/lang/String;

    invoke-static {v0}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->USSetQuery(Ljava/lang/String;)V

    .line 2396
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_SearchOption:Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;

    invoke-static {v0}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->USSetSearchOption(Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;)V

    .line 2406
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/ui/popup/PopupManager;->stopProgressDialog()V

    .line 2407
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/ui/popup/PopupManager;->startDialogStyleProgress()V

    .line 2408
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->DoUnitedSearch()V

    .line 2409
    const-string v0, "wooks_t"

    const-string v1, "DoSearch:: end"

    invoke-static {v0, v1}, Lcom/thinkware/sundo/inavi3d/LOGTW;->e(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_0
.end method

.method public DoUnitedSearch()V
    .locals 2

    .prologue
    .line 2276
    new-instance v0, Ljava/lang/Thread;

    new-instance v1, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$20;

    invoke-direct {v1, p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$20;-><init>(Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;)V

    invoke-direct {v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    .line 2371
    return-void
.end method

.method public IsAdminName(Ljava/lang/String;)Z
    .locals 2
    .param p1, "strName"    # Ljava/lang/String;

    .prologue
    .line 596
    invoke-virtual {p1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v1

    .line 599
    .local v1, "strAdmin":Ljava/lang/String;
    const/4 v0, 0x0

    .line 600
    .local v0, "bRet":Z
    invoke-static {v1}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->USIsAdminName(Ljava/lang/String;)Z

    move-result v0

    .line 602
    return v0
.end method

.method public IsEnableSearchBtn()Z
    .locals 1

    .prologue
    .line 2564
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mBtnSearch:Landroid/widget/ImageButton;

    invoke-virtual {v0}, Landroid/widget/ImageButton;->isEnabled()Z

    move-result v0

    return v0
.end method

.method public IsEnableSpaceBtn()Z
    .locals 2

    .prologue
    const/4 v0, 0x0

    .line 2570
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    invoke-virtual {v1}, Landroid/widget/EditText;->length()I

    move-result v1

    if-gtz v1, :cond_1

    .line 2578
    :cond_0
    :goto_0
    return v0

    .line 2574
    :cond_1
    iget-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bIsExistSpaceInKeyword:Z

    if-eqz v1, :cond_2

    iget-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bLiveSrch:Z

    if-eqz v1, :cond_0

    .line 2578
    :cond_2
    const/4 v0, 0x1

    goto :goto_0
.end method

.method public IsIncludeAdminName(Ljava/lang/String;)Z
    .locals 5
    .param p1, "strQuery"    # Ljava/lang/String;

    .prologue
    const/4 v3, 0x0

    .line 580
    const/4 v0, -0x1

    .line 581
    .local v0, "idxBlank":I
    const-string v4, " "

    invoke-virtual {p1, v4}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result v0

    .line 582
    if-gez v0, :cond_1

    .line 591
    :cond_0
    :goto_0
    return v3

    .line 585
    :cond_1
    invoke-virtual {p1, v3, v0}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v1

    .line 586
    .local v1, "strName1":Ljava/lang/String;
    add-int/lit8 v4, v0, 0x1

    invoke-virtual {p1, v4}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v2

    .line 588
    .local v2, "strName2":Ljava/lang/String;
    invoke-virtual {p0, v1}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->IsAdminName(Ljava/lang/String;)Z

    move-result v4

    if-nez v4, :cond_2

    invoke-virtual {p0, v2}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->IsAdminName(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_0

    .line 591
    :cond_2
    const/4 v3, 0x1

    goto :goto_0
.end method

.method public IsValidQuery(Ljava/lang/String;)Z
    .locals 10
    .param p1, "strQuery"    # Ljava/lang/String;

    .prologue
    const/4 v7, 0x1

    const/4 v9, 0x2

    .line 610
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v4

    .line 612
    .local v4, "nLen":I
    const/4 v1, 0x0

    .line 613
    .local v1, "nChoCnt":I
    const/4 v3, 0x0

    .line 614
    .local v3, "nHanCnt":I
    const/4 v2, 0x0

    .line 616
    .local v2, "nEngNumCnt":I
    const/4 v6, 0x0

    .local v6, "oo":I
    :goto_0
    if-ge v6, v4, :cond_6

    .line 617
    invoke-virtual {p1, v6}, Ljava/lang/String;->charAt(I)C

    move-result v0

    .line 618
    .local v0, "ch":C
    const/16 v8, 0x30

    if-gt v8, v0, :cond_1

    const/16 v8, 0x3a

    if-gt v0, v8, :cond_1

    .line 619
    add-int/lit8 v2, v2, 0x1

    .line 616
    :cond_0
    :goto_1
    add-int/lit8 v6, v6, 0x1

    goto :goto_0

    .line 620
    :cond_1
    const/16 v8, 0x41

    if-gt v8, v0, :cond_2

    const/16 v8, 0x5a

    if-le v0, v8, :cond_3

    :cond_2
    const/16 v8, 0x61

    if-gt v8, v0, :cond_4

    const/16 v8, 0x7a

    if-gt v0, v8, :cond_4

    .line 621
    :cond_3
    add-int/lit8 v2, v2, 0x1

    goto :goto_1

    .line 622
    :cond_4
    const/16 v8, 0x3131

    if-gt v8, v0, :cond_5

    const/16 v8, 0x314e

    if-gt v0, v8, :cond_5

    .line 623
    add-int/lit8 v1, v1, 0x1

    goto :goto_1

    .line 625
    :cond_5
    move v5, v0

    .line 626
    .local v5, "nVal":I
    const v8, 0xac00

    if-gt v8, v5, :cond_0

    const v8, 0xd7a3

    if-gt v5, v8, :cond_0

    .line 627
    add-int/lit8 v3, v3, 0x1

    goto :goto_1

    .line 631
    .end local v0    # "ch":C
    .end local v5    # "nVal":I
    :cond_6
    if-ge v2, v9, :cond_7

    if-ge v1, v9, :cond_7

    if-ge v3, v7, :cond_7

    add-int v8, v2, v1

    if-lt v8, v9, :cond_8

    .line 634
    :cond_7
    :goto_2
    return v7

    :cond_8
    const/4 v7, 0x0

    goto :goto_2
.end method

.method ReadyLiveSearchAgreePopup()V
    .locals 6

    .prologue
    const v5, 0x7f030059

    .line 1583
    new-instance v1, Lcom/thinkware/sundo/inavi3d/ui/popup/InaviPopup;

    const-string v2, ""

    const-string v3, ""

    const/4 v4, 0x0

    invoke-direct {v1, p0, v2, v3, v4}, Lcom/thinkware/sundo/inavi3d/ui/popup/InaviPopup;-><init>(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;I)V

    iput-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mLiveAgreeDialog:Landroid/app/Dialog;

    .line 1584
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v1

    invoke-virtual {v1}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->is_support_scale()Z

    move-result v1

    if-eqz v1, :cond_0

    .line 1585
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mLiveAgreeDialog:Landroid/app/Dialog;

    invoke-virtual {v1, v5}, Landroid/app/Dialog;->setContentView(I)V

    .line 1586
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INaviScaleManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INaviScaleManager;

    move-result-object v1

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mLiveAgreeDialog:Landroid/app/Dialog;

    const v3, 0x7f0a02a0

    invoke-virtual {v2, v3}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/thinkware/sundo/inavi3d/INaviScaleManager;->scaleOnceDialog(Landroid/view/View;)V

    .line 1591
    :goto_0
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mLiveAgreeDialog:Landroid/app/Dialog;

    const v2, 0x7f0a00c7

    invoke-virtual {v1, v2}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    .line 1592
    .local v0, "Title":Landroid/widget/TextView;
    const-string v1, "\uc544\uc774\ub098\ube44 Live \uc11c\ube44\uc2a4 \uc57d\uad00 \ub3d9\uc758"

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1594
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mLiveAgreeDialog:Landroid/app/Dialog;

    const v2, 0x7f0a031b

    invoke-virtual {v1, v2}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    new-instance v2, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$12;

    invoke-direct {v2, p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$12;-><init>(Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;)V

    invoke-virtual {v1, v2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 1608
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mLiveAgreeDialog:Landroid/app/Dialog;

    const v2, 0x7f0a0315

    invoke-virtual {v1, v2}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    new-instance v2, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$13;

    invoke-direct {v2, p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$13;-><init>(Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;)V

    invoke-virtual {v1, v2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 1619
    return-void

    .line 1588
    .end local v0    # "Title":Landroid/widget/TextView;
    :cond_0
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mLiveAgreeDialog:Landroid/app/Dialog;

    invoke-virtual {v1, v5}, Landroid/app/Dialog;->setContentView(I)V

    goto :goto_0
.end method

.method ReadyPreAreaNameSearch()V
    .locals 5

    .prologue
    .line 1487
    new-instance v1, Lcom/thinkware/sundo/inavi3d/ui/popup/InaviPopup;

    const-string v2, ""

    const-string v3, ""

    const/4 v4, 0x0

    invoke-direct {v1, p0, v2, v3, v4}, Lcom/thinkware/sundo/inavi3d/ui/popup/InaviPopup;-><init>(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;I)V

    iput-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mAdminDlg:Landroid/app/Dialog;

    .line 1488
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mAdminDlg:Landroid/app/Dialog;

    const v2, 0x7f030058

    invoke-virtual {v1, v2}, Landroid/app/Dialog;->setContentView(I)V

    .line 1489
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v1

    invoke-virtual {v1}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->is_support_scale()Z

    move-result v1

    if-eqz v1, :cond_0

    .line 1490
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INaviScaleManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INaviScaleManager;

    move-result-object v1

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mAdminDlg:Landroid/app/Dialog;

    const v3, 0x7f0a02a0

    invoke-virtual {v2, v3}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/thinkware/sundo/inavi3d/INaviScaleManager;->scaleOnceDialog(Landroid/view/View;)V

    .line 1493
    :cond_0
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mAdminDlg:Landroid/app/Dialog;

    const v2, 0x7f0a0318

    invoke-virtual {v1, v2}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/ListView;

    iput-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->lstPopup:Landroid/widget/ListView;

    .line 1494
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->lstPopup:Landroid/widget/ListView;

    const/4 v2, 0x1

    invoke-virtual {v1, v2}, Landroid/widget/ListView;->setChoiceMode(I)V

    .line 1496
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mAdminDlg:Landroid/app/Dialog;

    const v2, 0x7f0a00c7

    invoke-virtual {v1, v2}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    .line 1497
    .local v0, "Title":Landroid/widget/TextView;
    const-string v1, "\uac80\uc0c9 \uc9c0\uc5ed \uc120\ud0dd"

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1499
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mAdminDlg:Landroid/app/Dialog;

    const v2, 0x7f0a0315

    invoke-virtual {v1, v2}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    new-instance v2, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$10;

    invoke-direct {v2, p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$10;-><init>(Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;)V

    invoke-virtual {v1, v2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 1508
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->arrPopupData:Ljava/util/ArrayList;

    .line 1509
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->arrPopupString:Ljava/util/ArrayList;

    .line 1510
    new-instance v1, Lcom/thinkware/sundo/inavi3d/ui/adapter/CustomAdapter$CustumRadioItemAdapter;

    const v2, 0x7f030054

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->arrPopupString:Ljava/util/ArrayList;

    invoke-direct {v1, p0, v2, v3}, Lcom/thinkware/sundo/inavi3d/ui/adapter/CustomAdapter$CustumRadioItemAdapter;-><init>(Landroid/content/Context;ILjava/util/ArrayList;)V

    iput-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->adtPopupString:Lcom/thinkware/sundo/inavi3d/ui/adapter/CustomAdapter$CustumRadioItemAdapter;

    .line 1511
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->lstPopup:Landroid/widget/ListView;

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->adtPopupString:Lcom/thinkware/sundo/inavi3d/ui/adapter/CustomAdapter$CustumRadioItemAdapter;

    invoke-virtual {v1, v2}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    .line 1512
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->lstPopup:Landroid/widget/ListView;

    new-instance v2, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$11;

    invoke-direct {v2, p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$11;-><init>(Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;)V

    invoke-virtual {v1, v2}, Landroid/widget/ListView;->setOnItemClickListener(Landroid/widget/AdapterView$OnItemClickListener;)V

    .line 1580
    return-void
.end method

.method public ShowPopupNoResult()V
    .locals 4

    .prologue
    .line 1652
    const/16 v0, 0x30

    const-string v1, "\uc54c\ub9bc"

    const-string v2, "\uac80\uc0c9 \uacb0\uacfc\uac00 \uc5c6\uc2b5\ub2c8\ub2e4.\n\uac80\uc0c9 \uc870\uac74\uc744 \ud655\uc778\ud574 \uc8fc\uc2ed\uc2dc\uc624."

    const/4 v3, 0x0

    invoke-static {v0, p0, v1, v2, v3}, Lcom/thinkware/sundo/inavi3d/ui/popup/PopupManager;->ShowPopup(ILandroid/content/Context;Ljava/lang/String;Ljava/lang/String;I)Lcom/thinkware/sundo/inavi3d/ui/popup/InaviPopup;

    .line 1654
    return-void
.end method

.method public ShowPopupNotify()V
    .locals 5

    .prologue
    .line 1623
    const/16 v1, 0x20

    const-string v2, "\uc54c\ub9bc"

    const-string v3, "\uac80\uc0c9 \uacb0\uacfc\uac00 \uc5c6\uc2b5\ub2c8\ub2e4.\n\uac80\uc0c9\uc5b4 \ub610\ub294 \uc9c0\uc5ed\uc124\uc815\uc744 \ud655\uc778\ud574\n\uc8fc\uc2ed\uc2dc\uc624."

    const/4 v4, 0x0

    invoke-static {v1, p0, v2, v3, v4}, Lcom/thinkware/sundo/inavi3d/ui/popup/PopupManager;->ShowPopup(ILandroid/content/Context;Ljava/lang/String;Ljava/lang/String;I)Lcom/thinkware/sundo/inavi3d/ui/popup/InaviPopup;

    move-result-object v0

    .line 1626
    .local v0, "popup2":Lcom/thinkware/sundo/inavi3d/ui/popup/InaviPopup;
    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/ui/popup/InaviPopup;->getOkButton()Landroid/widget/Button;

    move-result-object v1

    const-string v2, "\uc804\uad6d\uc73c\ub85c \uac80\uc0c9"

    invoke-virtual {v1, v2}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 1627
    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/ui/popup/InaviPopup;->getCancleButton()Landroid/widget/Button;

    move-result-object v1

    const-string v2, "\ucde8\uc18c"

    invoke-virtual {v1, v2}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 1628
    new-instance v1, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$14;

    invoke-direct {v1, p0, v0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$14;-><init>(Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;Lcom/thinkware/sundo/inavi3d/ui/popup/InaviPopup;)V

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/inavi3d/ui/popup/InaviPopup;->SetokListner(Landroid/view/View$OnClickListener;)Z

    .line 1642
    new-instance v1, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$15;

    invoke-direct {v1, p0, v0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$15;-><init>(Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;Lcom/thinkware/sundo/inavi3d/ui/popup/InaviPopup;)V

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/inavi3d/ui/popup/InaviPopup;->SetcancleListner(Landroid/view/View$OnClickListener;)Z

    .line 1648
    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/ui/popup/InaviPopup;->show()V

    .line 1649
    return-void
.end method

.method public doUnitedSearch()V
    .locals 7

    .prologue
    const/16 v6, 0x1773

    const/4 v5, 0x1

    const/4 v4, 0x0

    .line 1987
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mBtnErase:Landroid/widget/Button;

    invoke-virtual {v1, v4}, Landroid/widget/Button;->setClickable(Z)V

    .line 1989
    new-instance v0, Landroid/os/Handler;

    invoke-direct {v0}, Landroid/os/Handler;-><init>()V

    .line 1990
    .local v0, "h":Landroid/os/Handler;
    new-instance v1, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$AntiClickhandler;

    invoke-direct {v1, p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$AntiClickhandler;-><init>(Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;)V

    const-wide/16 v2, 0x3e8

    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 1994
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    invoke-virtual {v1}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    iput-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strQuery:Ljava/lang/String;

    .line 1996
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strQuery:Ljava/lang/String;

    const-string v2, "##\ub85c\uae45\uc2dc\uc791"

    invoke-virtual {v1, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_0

    .line 1997
    sget-object v1, Lcom/thinkware/sundo/inavi3d/GpsLogDriver;->mPath:Ljava/io/File;

    invoke-virtual {v1}, Ljava/io/File;->mkdir()Z

    .line 1998
    const-string v1, ""

    invoke-static {v6, v5, v1}, Lcom/thinkware/sundo/inavi3d/Inavi;->ProcessMessage(IILjava/lang/String;)I

    .line 1999
    const-string v1, "\ub85c\uae45\uc2dc\uc791 (/storage/emulated/0/inavi3d/gpslog/)"

    invoke-static {p0, v1, v5}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v1

    invoke-virtual {v1}, Landroid/widget/Toast;->show()V

    .line 2000
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strQuery:Ljava/lang/String;

    invoke-static {v1, v4}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->USSetQueryHistory(Ljava/lang/String;I)V

    .line 2027
    :goto_0
    return-void

    .line 2003
    :cond_0
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strQuery:Ljava/lang/String;

    const-string v2, "##\ub85c\uae45\uc911\ub2e8"

    invoke-virtual {v1, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_1

    .line 2004
    sget-object v1, Lcom/thinkware/sundo/inavi3d/GpsLogDriver;->mPath:Ljava/io/File;

    invoke-virtual {v1}, Ljava/io/File;->mkdir()Z

    .line 2005
    const-string v1, ""

    invoke-static {v6, v4, v1}, Lcom/thinkware/sundo/inavi3d/Inavi;->ProcessMessage(IILjava/lang/String;)I

    .line 2006
    const-string v1, "\ub85c\uae45\uc911\ub2e8 (/storage/emulated/0/inavi3d/gpslog/)"

    invoke-static {p0, v1, v5}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v1

    invoke-virtual {v1}, Landroid/widget/Toast;->show()V

    .line 2007
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strQuery:Ljava/lang/String;

    invoke-static {v1, v4}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->USSetQueryHistory(Ljava/lang/String;I)V

    goto :goto_0

    .line 2010
    :cond_1
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strQuery:Ljava/lang/String;

    const-string v2, "##\uc8fc\ucc28\uc7a5\uc2dc\uc791"

    invoke-virtual {v1, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_2

    .line 2011
    const/16 v1, 0x1775

    const-string v2, ""

    invoke-static {v1, v4, v2}, Lcom/thinkware/sundo/inavi3d/Inavi;->ProcessMessage(IILjava/lang/String;)I

    .line 2012
    const-string v1, "\uc9c0\ud558\uc8fc\ucc28\uc7a5 \uc9c4\uc785\ub370\uc774\ud130 \ubc84\ud2bc \ud65c\uc131\ud654!!"

    invoke-static {p0, v1, v5}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v1

    invoke-virtual {v1}, Landroid/widget/Toast;->show()V

    goto :goto_0

    .line 2015
    :cond_2
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strQuery:Ljava/lang/String;

    const-string v2, "##\uc8fc\ucc28\uc7a5\uc885\ub8cc"

    invoke-virtual {v1, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_3

    .line 2016
    const/16 v1, 0x1776

    const-string v2, ""

    invoke-static {v1, v4, v2}, Lcom/thinkware/sundo/inavi3d/Inavi;->ProcessMessage(IILjava/lang/String;)I

    .line 2017
    const-string v1, "\uc9c0\ud558\uc8fc\ucc28\uc7a5 \uc9c4\uc785\ub370\uc774\ud130 \ubc84\ud2bc \ube44\ud65c\uc131\ud654!!"

    invoke-static {p0, v1, v5}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v1

    invoke-virtual {v1}, Landroid/widget/Toast;->show()V

    goto :goto_0

    .line 2021
    :cond_3
    iput-boolean v4, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bReSrch:Z

    .line 2023
    iget-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bLiveSrch:Z

    if-eqz v1, :cond_4

    .line 2024
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->DoLiveSearch()V

    goto :goto_0

    .line 2026
    :cond_4
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->DoSearch()V

    goto :goto_0
.end method

.method enableRegionBtn(Z)V
    .locals 2
    .param p1, "enabled"    # Z

    .prologue
    .line 312
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mBtnSetRegion:Landroid/widget/Button;

    invoke-virtual {v0, p1}, Landroid/widget/Button;->setEnabled(Z)V

    .line 313
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mBtnSetRegion:Landroid/widget/Button;

    invoke-virtual {v0, p1}, Landroid/widget/Button;->setClickable(Z)V

    .line 314
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mBtnSetRegion:Landroid/widget/Button;

    if-eqz p1, :cond_0

    const/4 v0, -0x1

    :goto_0
    invoke-virtual {v1, v0}, Landroid/widget/Button;->setTextColor(I)V

    .line 315
    return-void

    .line 314
    :cond_0
    const v0, -0x777778

    goto :goto_0
.end method

.method public finish()V
    .locals 3

    .prologue
    const/4 v0, 0x0

    .line 1765
    invoke-super {p0}, Lcom/thinkware/sundo/inavi3d/MainActivity;->finish()V

    .line 1766
    invoke-virtual {p0, v0, v0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->overridePendingTransition(II)V

    .line 1767
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->bForceClosing:Z

    if-eqz v0, :cond_0

    .line 1775
    :goto_0
    return-void

    .line 1771
    :cond_0
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_SearchOption:Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;

    invoke-static {v0}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->USSetSearchOption(Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;)V

    .line 1772
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->USSaveSearchingOption()V

    .line 1774
    const-string v0, "HYO"

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "HYO USSaveSearchingOption()admincode="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_SearchOption:Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;

    iget v2, v2, Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;->m_nAdminCode:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/thinkware/sundo/inavi3d/LOGTW;->e(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_0
.end method

.method protected getContentViewId()I
    .locals 1

    .prologue
    .line 2559
    const v0, 0x7f0a027c

    return v0
.end method

.method public getOffsetForPosition(Landroid/widget/EditText;FF)I
    .locals 3
    .param p1, "textView"    # Landroid/widget/EditText;
    .param p2, "x"    # F
    .param p3, "y"    # F

    .prologue
    .line 639
    invoke-virtual {p1}, Landroid/widget/EditText;->getLayout()Landroid/text/Layout;

    move-result-object v2

    if-nez v2, :cond_0

    .line 640
    const/4 v1, -0x1

    .line 644
    :goto_0
    return v1

    .line 642
    :cond_0
    invoke-direct {p0, p1, p3}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->getLineAtCoordinate(Landroid/widget/EditText;F)I

    move-result v0

    .line 643
    .local v0, "line":I
    invoke-direct {p0, p1, v0, p2}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->getOffsetAtCoordinate(Landroid/widget/EditText;IF)I

    move-result v1

    .line 644
    .local v1, "offset":I
    goto :goto_0
.end method

.method protected onActivityResult(IILandroid/content/Intent;)V
    .locals 7
    .param p1, "requestCode"    # I
    .param p2, "resultCode"    # I
    .param p3, "data"    # Landroid/content/Intent;

    .prologue
    const/4 v6, -0x1

    const/4 v5, 0x0

    const/4 v4, 0x1

    .line 2414
    iget-boolean v3, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->bForceClosing:Z

    if-eqz v3, :cond_1

    .line 2502
    :cond_0
    :goto_0
    return-void

    .line 2418
    :cond_1
    packed-switch p1, :pswitch_data_0

    :pswitch_0
    goto :goto_0

    .line 2421
    :pswitch_1
    if-ne p2, v6, :cond_0

    .line 2422
    const-string v3, "SearchData"

    invoke-virtual {p3, v3}, Landroid/content/Intent;->getSerializableExtra(Ljava/lang/String;)Ljava/io/Serializable;

    move-result-object v3

    check-cast v3, Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;

    iput-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_SearchOption:Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;

    .line 2425
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_SearchOption:Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;

    iget v3, v3, Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;->m_nOption:I

    if-nez v3, :cond_3

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_SearchOption:Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;

    iget v3, v3, Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;->m_nAdminCode:I

    if-eqz v3, :cond_3

    .line 2426
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_SearchOption:Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;

    invoke-static {v3}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->USSetRegionQueryHistory(Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;)V

    .line 2431
    :cond_2
    :goto_1
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_SearchOption:Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;

    invoke-static {v3}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->USSetSearchOption(Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;)V

    .line 2432
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->setSearchOption()V

    goto :goto_0

    .line 2427
    :cond_3
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_SearchOption:Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;

    iget v3, v3, Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;->m_nOption:I

    if-ne v3, v4, :cond_2

    .line 2428
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_SearchOption:Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;

    invoke-static {v3}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->USSetRegionQueryHistory(Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;)V

    goto :goto_1

    .line 2437
    :pswitch_2
    if-ne p2, v6, :cond_0

    .line 2438
    new-instance v2, Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;

    invoke-direct {v2}, Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;-><init>()V

    .line 2439
    .local v2, "tempOption":Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;
    const-string v3, "SearchData"

    invoke-virtual {p3, v3}, Landroid/content/Intent;->getSerializableExtra(Ljava/lang/String;)Ljava/io/Serializable;

    move-result-object v2

    .end local v2    # "tempOption":Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;
    check-cast v2, Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;

    .line 2441
    .restart local v2    # "tempOption":Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strQuery:Ljava/lang/String;

    iput-object v3, v2, Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;->m_strQuery:Ljava/lang/String;

    .line 2443
    invoke-static {v2}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->USSetSearchOption(Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;)V

    .line 2444
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->USRunSanghoSearch()I

    move-result v1

    .line 2445
    .local v1, "nRet":I
    sget v3, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->RET_SEARCH_OK:I

    if-ne v1, v3, :cond_7

    .line 2446
    invoke-static {v4}, Lcom/thinkware/sundo/inavi3d/Inavi;->setULogSearch(Z)V

    .line 2450
    :cond_4
    :goto_2
    sget v3, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->RET_SEARCH_OK:I

    if-ne v1, v3, :cond_8

    .line 2452
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v3

    invoke-virtual {v3}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->supportRecommendedWord()Z

    move-result v3

    if-eqz v3, :cond_5

    .line 2453
    invoke-direct {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->hideRecommendedWord()V

    .line 2454
    :cond_5
    new-instance v0, Landroid/content/Intent;

    const-class v3, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchResultActivity;

    invoke-direct {v0, p0, v3}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 2458
    .local v0, "intent":Landroid/content/Intent;
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_SearchOption:Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;

    iget v3, v3, Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;->m_nAdminCode:I

    if-nez v3, :cond_6

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_SearchOption:Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;

    iget v3, v3, Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;->m_nOption:I

    if-nez v3, :cond_6

    .line 2459
    const-string v3, "RegionAll"

    invoke-virtual {v0, v3, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 2460
    const-string v3, "HYO"

    const-string v4, "HYO region all == 1"

    invoke-static {v3, v4}, Lcom/thinkware/sundo/inavi3d/LOGTW;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 2463
    :cond_6
    const-string v3, "mode"

    iget v4, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mode:I

    invoke-virtual {v0, v3, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 2465
    const/16 v3, 0x3eb

    invoke-virtual {p0, v0, v3}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->startActivityForResult(Landroid/content/Intent;I)V

    goto/16 :goto_0

    .line 2447
    .end local v0    # "intent":Landroid/content/Intent;
    :cond_7
    sget v3, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->RET_SEARCH_FAIL:I

    if-ne v1, v3, :cond_4

    .line 2448
    invoke-static {v5}, Lcom/thinkware/sundo/inavi3d/Inavi;->setULogSearch(Z)V

    goto :goto_2

    .line 2468
    :cond_8
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_SearchOption:Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;

    iget v3, v3, Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;->m_nAdminCode:I

    if-nez v3, :cond_9

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_SearchOption:Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;

    iget v3, v3, Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;->m_nOption:I

    if-ne v3, v4, :cond_a

    .line 2469
    :cond_9
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->ShowPopupNotify()V

    goto/16 :goto_0

    .line 2471
    :cond_a
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->ShowPopupNoResult()V

    goto/16 :goto_0

    .line 2477
    .end local v1    # "nRet":I
    .end local v2    # "tempOption":Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;
    :pswitch_3
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strQuery:Ljava/lang/String;

    invoke-static {v3, v5}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->USSetQueryHistory(Ljava/lang/String;I)V

    .line 2479
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v3

    invoke-virtual {v3}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->supportRecommendedWord()Z

    move-result v3

    if-nez v3, :cond_b

    .line 2480
    invoke-direct {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->loadQueryHistory()V

    .line 2483
    :cond_b
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    invoke-virtual {v3}, Landroid/widget/EditText;->selectAll()V

    .line 2484
    const-string v3, "HYO"

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "EditText SetSelection!!"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    iget-object v5, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    invoke-virtual {v5}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v3, v4}, Lcom/thinkware/sundo/inavi3d/LOGTW;->d(Ljava/lang/String;Ljava/lang/String;)V

    goto/16 :goto_0

    .line 2490
    :pswitch_4
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strQuery:Ljava/lang/String;

    invoke-static {v3, v5}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->USSetQueryHistory(Ljava/lang/String;I)V

    .line 2492
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v3

    invoke-virtual {v3}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->supportRecommendedWord()Z

    move-result v3

    if-nez v3, :cond_c

    .line 2493
    invoke-direct {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->loadQueryHistory()V

    .line 2496
    :cond_c
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    invoke-virtual {v3}, Landroid/widget/EditText;->selectAll()V

    .line 2497
    const-string v3, "HYO"

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "EditText SetSelection!!"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    iget-object v5, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    invoke-virtual {v5}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v3, v4}, Lcom/thinkware/sundo/inavi3d/LOGTW;->d(Ljava/lang/String;Ljava/lang/String;)V

    goto/16 :goto_0

    .line 2418
    nop

    :pswitch_data_0
    .packed-switch 0x3e9
        :pswitch_1
        :pswitch_2
        :pswitch_3
        :pswitch_0
        :pswitch_4
    .end packed-switch
.end method

.method public onCheckedChanged(Landroid/widget/RadioGroup;I)V
    .locals 0
    .param p1, "arg0"    # Landroid/widget/RadioGroup;
    .param p2, "arg1"    # I

    .prologue
    .line 2506
    return-void
.end method

.method public onClick(Landroid/view/View;)V
    .locals 12
    .param p1, "v"    # Landroid/view/View;

    .prologue
    const/16 v11, 0x11b

    const/high16 v10, 0x41f00000    # 30.0f

    const/high16 v7, 0x41d00000    # 26.0f

    const/4 v8, 0x1

    const/4 v9, 0x0

    .line 1782
    invoke-virtual {p1}, Landroid/view/View;->getId()I

    move-result v6

    sparse-switch v6, :sswitch_data_0

    .line 1953
    :cond_0
    :goto_0
    return-void

    .line 1786
    :sswitch_0
    iget-object v6, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabUnited:Landroid/widget/Button;

    invoke-virtual {v6, v9}, Landroid/widget/Button;->setSelected(Z)V

    .line 1787
    iget-object v6, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabUnited:Landroid/widget/Button;

    invoke-virtual {v6, v9, v7}, Landroid/widget/Button;->setTextSize(IF)V

    .line 1788
    iget-object v6, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabName:Landroid/widget/Button;

    invoke-virtual {v6, v8}, Landroid/widget/Button;->setSelected(Z)V

    .line 1789
    iget-object v6, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabName:Landroid/widget/Button;

    invoke-virtual {v6, v9, v10}, Landroid/widget/Button;->setTextSize(IF)V

    .line 1790
    iget-object v6, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabName:Landroid/widget/Button;

    invoke-virtual {v6}, Landroid/widget/Button;->postInvalidate()V

    .line 1791
    invoke-direct {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->tabButtonDesable()V

    .line 1792
    new-instance v0, Landroid/content/Intent;

    const-class v6, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;

    invoke-direct {v0, p0, v6}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 1794
    .local v0, "intent":Landroid/content/Intent;
    const-string v6, "mode"

    iget v7, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mode:I

    invoke-virtual {v0, v6, v7}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 1799
    new-instance v1, Landroid/content/Intent;

    const-class v6, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    invoke-direct {v1, p0, v6}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 1800
    .local v1, "mapIntent":Landroid/content/Intent;
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    move-result-object v6

    invoke-virtual {v6, p0, v1, v0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->startActivityToMap(Landroid/content/Context;Landroid/content/Intent;Landroid/content/Intent;)V

    .line 1801
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    move-result-object v6

    const/4 v7, 0x0

    invoke-virtual {v6, p0, v7}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->tabButtonClearTop(Landroid/content/Context;Landroid/content/Intent;)V

    goto :goto_0

    .line 1805
    .end local v0    # "intent":Landroid/content/Intent;
    .end local v1    # "mapIntent":Landroid/content/Intent;
    :sswitch_1
    iget-object v6, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabUnited:Landroid/widget/Button;

    invoke-virtual {v6, v9}, Landroid/widget/Button;->setSelected(Z)V

    .line 1806
    iget-object v6, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabUnited:Landroid/widget/Button;

    invoke-virtual {v6, v9, v7}, Landroid/widget/Button;->setTextSize(IF)V

    .line 1807
    iget-object v6, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabAddr:Landroid/widget/Button;

    invoke-virtual {v6, v8}, Landroid/widget/Button;->setSelected(Z)V

    .line 1808
    iget-object v6, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabAddr:Landroid/widget/Button;

    invoke-virtual {v6, v9, v10}, Landroid/widget/Button;->setTextSize(IF)V

    .line 1809
    iget-object v6, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabAddr:Landroid/widget/Button;

    invoke-virtual {v6}, Landroid/widget/Button;->postInvalidate()V

    .line 1810
    invoke-direct {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->tabButtonDesable()V

    .line 1811
    new-instance v0, Landroid/content/Intent;

    const-class v6, Lcom/thinkware/sundo/inavi3d/ui/AddressSearch;

    invoke-direct {v0, p0, v6}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 1813
    .restart local v0    # "intent":Landroid/content/Intent;
    const-string v6, "mode"

    iget v7, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mode:I

    invoke-virtual {v0, v6, v7}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 1815
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    move-result-object v6

    invoke-virtual {v6, p0, v0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->tabButtonClearTop(Landroid/content/Context;Landroid/content/Intent;)V

    goto :goto_0

    .line 1818
    .end local v0    # "intent":Landroid/content/Intent;
    :sswitch_2
    iget-object v6, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabUnited:Landroid/widget/Button;

    invoke-virtual {v6, v9}, Landroid/widget/Button;->setSelected(Z)V

    .line 1819
    iget-object v6, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabUnited:Landroid/widget/Button;

    invoke-virtual {v6, v9, v7}, Landroid/widget/Button;->setTextSize(IF)V

    .line 1820
    iget-object v6, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabAround:Landroid/widget/Button;

    invoke-virtual {v6, v8}, Landroid/widget/Button;->setSelected(Z)V

    .line 1821
    iget-object v6, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabAround:Landroid/widget/Button;

    invoke-virtual {v6, v9, v10}, Landroid/widget/Button;->setTextSize(IF)V

    .line 1822
    iget-object v6, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabAround:Landroid/widget/Button;

    invoke-virtual {v6}, Landroid/widget/Button;->postInvalidate()V

    .line 1823
    invoke-direct {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->tabButtonDesable()V

    .line 1824
    new-instance v0, Landroid/content/Intent;

    const-class v6, Lcom/thinkware/sundo/inavi3d/ui/AroundSrchActivity;

    invoke-direct {v0, p0, v6}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 1826
    .restart local v0    # "intent":Landroid/content/Intent;
    const-string v6, "mode"

    iget v7, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mode:I

    invoke-virtual {v0, v6, v7}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 1828
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    move-result-object v6

    invoke-virtual {v6, p0, v0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->tabButtonClearTop(Landroid/content/Context;Landroid/content/Intent;)V

    goto/16 :goto_0

    .line 1831
    .end local v0    # "intent":Landroid/content/Intent;
    :sswitch_3
    iget-object v6, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabUnited:Landroid/widget/Button;

    invoke-virtual {v6, v9}, Landroid/widget/Button;->setSelected(Z)V

    .line 1832
    iget-object v6, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabUnited:Landroid/widget/Button;

    invoke-virtual {v6, v9, v7}, Landroid/widget/Button;->setTextSize(IF)V

    .line 1833
    iget-object v6, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabICode:Landroid/widget/Button;

    invoke-virtual {v6, v8}, Landroid/widget/Button;->setSelected(Z)V

    .line 1834
    iget-object v6, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabICode:Landroid/widget/Button;

    invoke-virtual {v6, v9, v10}, Landroid/widget/Button;->setTextSize(IF)V

    .line 1835
    iget-object v6, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabICode:Landroid/widget/Button;

    invoke-virtual {v6}, Landroid/widget/Button;->postInvalidate()V

    .line 1836
    invoke-direct {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->tabButtonDesable()V

    .line 1837
    new-instance v0, Landroid/content/Intent;

    const-class v6, Lcom/thinkware/sundo/inavi3d/ui/ICodeSearchActivity;

    invoke-direct {v0, p0, v6}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 1839
    .restart local v0    # "intent":Landroid/content/Intent;
    const-string v6, "mode"

    iget v7, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mode:I

    invoke-virtual {v0, v6, v7}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 1841
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    move-result-object v6

    invoke-virtual {v6, p0, v0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->tabButtonClearTop(Landroid/content/Context;Landroid/content/Intent;)V

    goto/16 :goto_0

    .line 1845
    .end local v0    # "intent":Landroid/content/Intent;
    :sswitch_4
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->searchClear()V

    goto/16 :goto_0

    .line 1849
    :sswitch_5
    iget-boolean v6, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bLiveSrch:Z

    if-eqz v6, :cond_1

    .line 1851
    iput-boolean v9, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bLiveSrch:Z

    .line 1855
    invoke-direct {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->EraseSpaceInEditText()V

    .line 1856
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->getInstance()Lcom/thinkware/sundo/inavi3d/InaviConfig;

    move-result-object v6

    invoke-virtual {v6, v11, v9}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->CNaviConfigSet(II)Z

    .line 1857
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->getInstance()Lcom/thinkware/sundo/inavi3d/InaviConfig;

    move-result-object v6

    invoke-virtual {v6}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->SetConfigSave()Z

    .line 1891
    :goto_1
    iget-object v6, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mBtnLive:Landroid/widget/Button;

    iget-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bLiveSrch:Z

    invoke-virtual {v6, v7}, Landroid/widget/Button;->setSelected(Z)V

    .line 1893
    iget-boolean v6, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bLiveSrch:Z

    if-eqz v6, :cond_4

    .line 1894
    invoke-virtual {p0, v9}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->enableRegionBtn(Z)V

    goto/16 :goto_0

    .line 1861
    :cond_1
    invoke-virtual {p0, v9}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->enableRegionBtn(Z)V

    .line 1866
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v6

    invoke-virtual {v6}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->supportRSearch()Z

    move-result v6

    if-eqz v6, :cond_3

    .line 1867
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/livesearch/LiveSearchManager;->getInstance()Lcom/thinkware/sundo/inavi3d/livesearch/LiveSearchManager;

    move-result-object v6

    invoke-virtual {v6}, Lcom/thinkware/sundo/inavi3d/livesearch/LiveSearchManager;->isAgreed()Z

    move-result v6

    iput-boolean v6, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bLiveSrch:Z

    .line 1868
    iget-boolean v6, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bLiveSrch:Z

    if-nez v6, :cond_2

    .line 1869
    invoke-direct {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->showLiveProvisionPopup()V

    .line 1888
    :cond_2
    :goto_2
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/ui/SIPModel;->getInstance()Lcom/thinkware/sundo/inavi3d/ui/SIPModel;

    move-result-object v6

    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->IsEnableSpaceBtn()Z

    move-result v7

    invoke-virtual {v6, v7}, Lcom/thinkware/sundo/inavi3d/ui/SIPModel;->setSpaceButtonEnable(Z)V

    .line 1889
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->getInstance()Lcom/thinkware/sundo/inavi3d/InaviConfig;

    move-result-object v6

    invoke-virtual {v6, v11, v8}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->CNaviConfigSet(II)Z

    goto :goto_1

    .line 1873
    :cond_3
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->USGetLiveTermAgreed()Z

    move-result v6

    iput-boolean v6, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bLiveSrch:Z

    .line 1874
    iget-boolean v6, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bLiveSrch:Z

    if-nez v6, :cond_2

    .line 1875
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->_USGetLiveTerms()Ljava/lang/String;

    move-result-object v4

    .line 1877
    .local v4, "temp":Ljava/lang/String;
    const-string v6, "\uae40 \uc9c4\ubc94"

    const-string v7, "\uc774 \ud765\ubcf5"

    invoke-virtual {v4, v6, v7}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v4

    .line 1881
    const-string v6, "\uc11c\uc6b8\uc2dc \uc11c\ucd08\uad6c \uc591\uc7ac\ub3d9 275-7 \ud2b8\ub7ec\uc2a4\ud2b8\ud0c0\uc6cc 22\uce35"

    const-string v7, "\uacbd\uae30 \uc131\ub0a8\uc2dc \ubd84\ub2f9\uad6c \uc0bc\ud3c9\ub3d9 678 \uc0bc\ud658\ud558\uc774\ud399\uc2a4 A\ub3d9 9F"

    invoke-virtual {v4, v6, v7}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v4

    .line 1882
    iget-object v6, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mLiveAgreeDialog:Landroid/app/Dialog;

    const v7, 0x7f0a031a

    invoke-virtual {v6, v7}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v5

    check-cast v5, Landroid/widget/TextView;

    .line 1883
    .local v5, "txtLiveTerm":Landroid/widget/TextView;
    invoke-virtual {v5, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1885
    iget-object v6, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mLiveAgreeDialog:Landroid/app/Dialog;

    invoke-virtual {v6}, Landroid/app/Dialog;->show()V

    goto :goto_2

    .line 1896
    .end local v4    # "temp":Ljava/lang/String;
    .end local v5    # "txtLiveTerm":Landroid/widget/TextView;
    :cond_4
    invoke-virtual {p0, v8}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->enableRegionBtn(Z)V

    .line 1897
    iget-object v6, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    invoke-virtual {v6}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v6

    iput-object v6, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strQuery:Ljava/lang/String;

    .line 1899
    iget-object v6, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strQuery:Ljava/lang/String;

    invoke-virtual {v6}, Ljava/lang/String;->length()I

    move-result v6

    if-lt v6, v8, :cond_0

    .line 1903
    iget-object v6, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strQuery:Ljava/lang/String;

    const-string v7, " "

    invoke-virtual {v6, v7}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v6

    if-ne v6, v8, :cond_0

    .line 1904
    iget-object v6, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strQuery:Ljava/lang/String;

    invoke-virtual {p0, v6}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->IsIncludeAdminName(Ljava/lang/String;)Z

    move-result v6

    if-nez v6, :cond_5

    .line 1905
    invoke-virtual {p0, v8}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->enableRegionBtn(Z)V

    goto/16 :goto_0

    .line 1907
    :cond_5
    invoke-virtual {p0, v9}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->enableRegionBtn(Z)V

    goto/16 :goto_0

    .line 1914
    :sswitch_6
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->doUnitedSearch()V

    goto/16 :goto_0

    .line 1918
    :sswitch_7
    iget-object v6, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mHelpDialog:Landroid/app/Dialog;

    invoke-virtual {v6}, Landroid/app/Dialog;->show()V

    goto/16 :goto_0

    .line 1924
    :sswitch_8
    iget-object v6, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mHelpDialog:Landroid/app/Dialog;

    invoke-virtual {v6}, Landroid/app/Dialog;->dismiss()V

    goto/16 :goto_0

    .line 1928
    :sswitch_9
    new-instance v0, Landroid/content/Intent;

    const-class v6, Lcom/thinkware/sundo/inavi3d/ui/SetRegionRadiusActivity;

    invoke-direct {v0, p0, v6}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 1929
    .restart local v0    # "intent":Landroid/content/Intent;
    const-string v6, "SearchData"

    iget-object v7, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_SearchOption:Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;

    invoke-virtual {v0, v6, v7}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/io/Serializable;)Landroid/content/Intent;

    .line 1930
    const/16 v6, 0x3e9

    invoke-virtual {p0, v0, v6}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->startActivityForResult(Landroid/content/Intent;I)V

    goto/16 :goto_0

    .line 1934
    .end local v0    # "intent":Landroid/content/Intent;
    :sswitch_a
    const/16 v6, 0x20

    const-string v7, "\uc54c\ub9bc"

    const-string v8, "\ucd5c\uadfc \uac80\uc0c9\uc5b4\ub97c \ubaa8\ub450 \uc0ad\uc81c\ud558\uc2dc\uaca0\uc2b5\ub2c8\uae4c?"

    invoke-static {v6, p0, v7, v8, v9}, Lcom/thinkware/sundo/inavi3d/ui/popup/PopupManager;->ShowPopup(ILandroid/content/Context;Ljava/lang/String;Ljava/lang/String;I)Lcom/thinkware/sundo/inavi3d/ui/popup/InaviPopup;

    move-result-object v3

    .line 1937
    .local v3, "popup":Lcom/thinkware/sundo/inavi3d/ui/popup/InaviPopup;
    new-instance v2, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$17;

    invoke-direct {v2, p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$17;-><init>(Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;)V

    .line 1947
    .local v2, "ok":Landroid/view/View$OnClickListener;
    invoke-static {v2}, Lcom/thinkware/sundo/inavi3d/ui/popup/PopupManager;->SetokListner(Landroid/view/View$OnClickListener;)Z

    goto/16 :goto_0

    .line 1782
    nop

    :sswitch_data_0
    .sparse-switch
        0x7f0a0063 -> :sswitch_0
        0x7f0a0064 -> :sswitch_1
        0x7f0a0065 -> :sswitch_2
        0x7f0a0066 -> :sswitch_3
        0x7f0a0179 -> :sswitch_a
        0x7f0a027d -> :sswitch_5
        0x7f0a027e -> :sswitch_9
        0x7f0a0280 -> :sswitch_6
        0x7f0a0281 -> :sswitch_4
        0x7f0a0284 -> :sswitch_7
        0x7f0a070b -> :sswitch_8
        0x7f0a0937 -> :sswitch_6
    .end sparse-switch
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 15
    .param p1, "savedInstanceState"    # Landroid/os/Bundle;

    .prologue
    .line 680
    invoke-super/range {p0 .. p1}, Lcom/thinkware/sundo/inavi3d/MainActivity;->onCreate(Landroid/os/Bundle;)V

    .line 681
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v10

    if-nez v10, :cond_0

    .line 682
    const/4 v10, 0x1

    iput-boolean v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->bForceClosing:Z

    .line 683
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->finish()V

    .line 1080
    :goto_0
    return-void

    .line 687
    :cond_0
    sput-object p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mActivity:Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;

    .line 688
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v10

    invoke-virtual {v10}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->is_support_scale()Z

    move-result v10

    if-eqz v10, :cond_3

    .line 689
    const v10, 0x7f030042

    invoke-virtual {p0, v10}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->setContentView(I)V

    .line 691
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INaviScaleManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INaviScaleManager;

    move-result-object v10

    invoke-virtual {v10, p0}, Lcom/thinkware/sundo/inavi3d/INaviScaleManager;->scaleOnce(Landroid/app/Activity;)V

    .line 692
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v10

    invoke-virtual {v10}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->is_support_builtin_statusbar()Z

    move-result v10

    if-eqz v10, :cond_1

    .line 701
    :cond_1
    :goto_1
    new-instance v10, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/UserDataMgr$beforeKeyParam;

    invoke-direct {v10}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/UserDataMgr$beforeKeyParam;-><init>()V

    iput-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_beforeParam:Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/UserDataMgr$beforeKeyParam;

    .line 704
    const v10, 0x7f0a0062

    invoke-virtual {p0, v10}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->findViewById(I)Landroid/view/View;

    move-result-object v10

    check-cast v10, Landroid/widget/Button;

    iput-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabUnited:Landroid/widget/Button;

    .line 705
    const v10, 0x7f0a0063

    invoke-virtual {p0, v10}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->findViewById(I)Landroid/view/View;

    move-result-object v10

    check-cast v10, Landroid/widget/Button;

    iput-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabName:Landroid/widget/Button;

    .line 706
    const v10, 0x7f0a0064

    invoke-virtual {p0, v10}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->findViewById(I)Landroid/view/View;

    move-result-object v10

    check-cast v10, Landroid/widget/Button;

    iput-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabAddr:Landroid/widget/Button;

    .line 707
    const v10, 0x7f0a0065

    invoke-virtual {p0, v10}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->findViewById(I)Landroid/view/View;

    move-result-object v10

    check-cast v10, Landroid/widget/Button;

    iput-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabAround:Landroid/widget/Button;

    .line 708
    const v10, 0x7f0a0066

    invoke-virtual {p0, v10}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->findViewById(I)Landroid/view/View;

    move-result-object v10

    check-cast v10, Landroid/widget/Button;

    iput-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabICode:Landroid/widget/Button;

    .line 710
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabUnited:Landroid/widget/Button;

    const/4 v11, 0x1

    invoke-virtual {v10, v11}, Landroid/widget/Button;->setSelected(Z)V

    .line 712
    invoke-direct {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->tabButtonDesable()V

    .line 714
    const v10, 0x7f0a027d

    invoke-virtual {p0, v10}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->findViewById(I)Landroid/view/View;

    move-result-object v10

    check-cast v10, Landroid/widget/Button;

    iput-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mBtnLive:Landroid/widget/Button;

    .line 715
    const v10, 0x7f0a027e

    invoke-virtual {p0, v10}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->findViewById(I)Landroid/view/View;

    move-result-object v10

    check-cast v10, Landroid/widget/Button;

    iput-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mBtnSetRegion:Landroid/widget/Button;

    .line 716
    const v10, 0x7f0a0281

    invoke-virtual {p0, v10}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->findViewById(I)Landroid/view/View;

    move-result-object v10

    check-cast v10, Landroid/widget/Button;

    iput-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mBtnErase:Landroid/widget/Button;

    .line 718
    const v10, 0x7f0a0280

    invoke-virtual {p0, v10}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->findViewById(I)Landroid/view/View;

    move-result-object v10

    check-cast v10, Landroid/widget/ImageButton;

    iput-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mBtnSearch:Landroid/widget/ImageButton;

    .line 721
    const v10, 0x7f0a027f

    invoke-virtual {p0, v10}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->findViewById(I)Landroid/view/View;

    move-result-object v10

    check-cast v10, Landroid/widget/EditText;

    iput-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    .line 723
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    iget-object v11, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mWatcher:Landroid/text/TextWatcher;

    invoke-virtual {v10, v11}, Landroid/widget/EditText;->addTextChangedListener(Landroid/text/TextWatcher;)V

    .line 725
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    invoke-virtual {v10, p0}, Landroid/widget/EditText;->setOnEditorActionListener(Landroid/widget/TextView$OnEditorActionListener;)V

    .line 726
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    invoke-virtual {v10, p0}, Landroid/widget/EditText;->setOnFocusChangeListener(Landroid/view/View$OnFocusChangeListener;)V

    .line 729
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    const/4 v11, 0x1

    invoke-virtual {v10, v11}, Landroid/widget/EditText;->setTextIsSelectable(Z)V

    .line 730
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    const/4 v11, 0x0

    invoke-virtual {v10, v11}, Landroid/widget/EditText;->setLongClickable(Z)V

    .line 732
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    new-instance v11, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$4;

    invoke-direct {v11, p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$4;-><init>(Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;)V

    invoke-virtual {v10, v11}, Landroid/widget/EditText;->setOnKeyListener(Landroid/view/View$OnKeyListener;)V

    .line 744
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    new-instance v11, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$5;

    invoke-direct {v11, p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$5;-><init>(Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;)V

    invoke-virtual {v10, v11}, Landroid/widget/EditText;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    .line 771
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mBtnSetRegion:Landroid/widget/Button;

    invoke-virtual {v10, p0}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 772
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mBtnErase:Landroid/widget/Button;

    invoke-virtual {v10, p0}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 773
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mBtnSearch:Landroid/widget/ImageButton;

    invoke-virtual {v10, p0}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 774
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mBtnLive:Landroid/widget/Button;

    invoke-virtual {v10, p0}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 776
    const/4 v10, 0x0

    iput-boolean v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->bShowPopup:Z

    .line 778
    new-instance v10, Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;

    invoke-direct {v10}, Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;-><init>()V

    iput-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_SearchOption:Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;

    .line 781
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->USPrepareUnitedSrch()V

    .line 784
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_SearchOption:Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;

    invoke-static {v10}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->USGetSearchOption(Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;)V

    .line 787
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->setSearchOption()V

    .line 790
    new-instance v10, Lcom/thinkware/sundo/inavi3d/ui/popup/InaviPopup;

    const-string v11, ""

    const-string v12, ""

    const/4 v13, 0x0

    invoke-direct {v10, p0, v11, v12, v13}, Lcom/thinkware/sundo/inavi3d/ui/popup/InaviPopup;-><init>(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;I)V

    iput-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mHelpDialog:Landroid/app/Dialog;

    .line 791
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v10

    invoke-virtual {v10}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->is_support_scale()Z

    move-result v10

    if-eqz v10, :cond_4

    .line 792
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mHelpDialog:Landroid/app/Dialog;

    const v11, 0x7f030103

    invoke-virtual {v10, v11}, Landroid/app/Dialog;->setContentView(I)V

    .line 793
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INaviScaleManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INaviScaleManager;

    move-result-object v10

    iget-object v11, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mHelpDialog:Landroid/app/Dialog;

    const v12, 0x7f0a02a0

    invoke-virtual {v11, v12}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v11

    invoke-virtual {v10, v11}, Lcom/thinkware/sundo/inavi3d/INaviScaleManager;->scaleOnceDialog(Landroid/view/View;)V

    .line 797
    :goto_2
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mHelpDialog:Landroid/app/Dialog;

    const v11, 0x7f0a070b

    invoke-virtual {v10, v11}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v10

    invoke-virtual {v10, p0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 805
    const v10, 0x7f0a028f

    invoke-virtual {p0, v10}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->findViewById(I)Landroid/view/View;

    move-result-object v10

    check-cast v10, Landroid/widget/LinearLayout;

    iput-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_layoutRecentWord:Landroid/widget/LinearLayout;

    .line 806
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_layoutRecentWord:Landroid/widget/LinearLayout;

    const/4 v11, 0x0

    invoke-virtual {v10, v11}, Landroid/widget/LinearLayout;->setVisibility(I)V

    .line 808
    const v10, 0x7f0a0178

    invoke-virtual {p0, v10}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->findViewById(I)Landroid/view/View;

    move-result-object v10

    check-cast v10, Landroid/widget/LinearLayout;

    iput-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_layoutQueryHistory:Landroid/widget/LinearLayout;

    .line 809
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_layoutQueryHistory:Landroid/widget/LinearLayout;

    const/4 v11, 0x0

    invoke-virtual {v10, v11}, Landroid/widget/LinearLayout;->setVisibility(I)V

    .line 814
    const v10, 0x7f0a0290

    invoke-virtual {p0, v10}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->findViewById(I)Landroid/view/View;

    move-result-object v10

    check-cast v10, Landroid/widget/TextView;

    iput-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_btnRecent:Landroid/widget/TextView;

    .line 816
    const v10, 0x7f0a0179

    invoke-virtual {p0, v10}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->findViewById(I)Landroid/view/View;

    move-result-object v10

    check-cast v10, Landroid/widget/Button;

    iput-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_btnDelHistory:Landroid/widget/Button;

    .line 817
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_btnDelHistory:Landroid/widget/Button;

    invoke-virtual {v10, p0}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 822
    const v10, 0x7f0a0282

    invoke-virtual {p0, v10}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->findViewById(I)Landroid/view/View;

    move-result-object v10

    check-cast v10, Landroid/widget/LinearLayout;

    iput-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_layoutHelpNew:Landroid/widget/LinearLayout;

    .line 823
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_layoutHelpNew:Landroid/widget/LinearLayout;

    const/4 v11, 0x0

    invoke-virtual {v10, v11}, Landroid/widget/LinearLayout;->setVisibility(I)V

    .line 825
    const v10, 0x7f0a0284

    invoke-virtual {p0, v10}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->findViewById(I)Landroid/view/View;

    move-result-object v10

    check-cast v10, Landroid/widget/Button;

    iput-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_btnHelpNew:Landroid/widget/Button;

    .line 826
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_btnHelpNew:Landroid/widget/Button;

    invoke-virtual {v10, p0}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 828
    const v10, 0x7f0a0289

    invoke-virtual {p0, v10}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->findViewById(I)Landroid/view/View;

    move-result-object v10

    check-cast v10, Landroid/widget/HorizontalScrollView;

    iput-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_ScrollViewRecommendFirst:Landroid/widget/HorizontalScrollView;

    .line 829
    const v10, 0x7f0a028c

    invoke-virtual {p0, v10}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->findViewById(I)Landroid/view/View;

    move-result-object v10

    check-cast v10, Landroid/widget/HorizontalScrollView;

    iput-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_ScrollViewRecommendSecond:Landroid/widget/HorizontalScrollView;

    .line 831
    const v10, 0x7f0a028a

    invoke-virtual {p0, v10}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->findViewById(I)Landroid/view/View;

    move-result-object v10

    check-cast v10, Landroid/widget/LinearLayout;

    iput-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->layoutRecommendFirst:Landroid/widget/LinearLayout;

    .line 832
    const v10, 0x7f0a028d

    invoke-virtual {p0, v10}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->findViewById(I)Landroid/view/View;

    move-result-object v10

    check-cast v10, Landroid/widget/LinearLayout;

    iput-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->layoutRecommendSecond:Landroid/widget/LinearLayout;

    .line 834
    const v10, 0x7f0a0288

    invoke-virtual {p0, v10}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->findViewById(I)Landroid/view/View;

    move-result-object v10

    check-cast v10, Landroid/widget/LinearLayout;

    iput-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->layoutGapTop:Landroid/widget/LinearLayout;

    .line 835
    const v10, 0x7f0a028b

    invoke-virtual {p0, v10}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->findViewById(I)Landroid/view/View;

    move-result-object v10

    check-cast v10, Landroid/widget/LinearLayout;

    iput-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->layoutGapMiddle:Landroid/widget/LinearLayout;

    .line 836
    const v10, 0x7f0a028e

    invoke-virtual {p0, v10}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->findViewById(I)Landroid/view/View;

    move-result-object v10

    check-cast v10, Landroid/widget/LinearLayout;

    iput-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->layoutGapBottom:Landroid/widget/LinearLayout;

    .line 838
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_CurrentDPXY:Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr$XYInfo;

    invoke-static {v10}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->GetCurrentDPPositionXY(Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr$XYInfo;)V

    .line 839
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_CarDPXY:Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr$XYInfo;

    invoke-static {v10}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->GetCarDPPositionXY(Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr$XYInfo;)V

    .line 842
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_ButtonArr:[Landroid/widget/Button;

    if-nez v10, :cond_5

    .line 844
    const/16 v10, 0xa

    new-array v10, v10, [Landroid/widget/Button;

    iput-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_ButtonArr:[Landroid/widget/Button;

    .line 845
    const/16 v10, 0xa

    new-array v10, v10, [Landroid/view/View;

    iput-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_ViewLineArr:[Landroid/view/View;

    .line 847
    new-instance v8, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v10, 0x1

    const/4 v11, -0x2

    const/high16 v12, 0x41800000    # 16.0f

    invoke-direct {v8, v10, v11, v12}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    .line 849
    .local v8, "paramsLine":Landroid/widget/LinearLayout$LayoutParams;
    const/16 v10, 0x10

    iput v10, v8, Landroid/widget/LinearLayout$LayoutParams;->gravity:I

    .line 851
    new-instance v7, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v10, 0xcb

    const/4 v11, -0x1

    invoke-direct {v7, v10, v11}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 854
    .local v7, "paramsButton":Landroid/widget/LinearLayout$LayoutParams;
    const/4 v3, 0x0

    .local v3, "i":I
    :goto_3
    const/16 v10, 0xa

    if-ge v3, v10, :cond_5

    .line 855
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_ButtonArr:[Landroid/widget/Button;

    new-instance v11, Landroid/widget/Button;

    invoke-direct {v11, p0}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    aput-object v11, v10, v3

    .line 856
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_ButtonArr:[Landroid/widget/Button;

    aget-object v10, v10, v3

    const/4 v11, 0x0

    const/high16 v12, 0x41b00000    # 22.0f

    invoke-virtual {v10, v11, v12}, Landroid/widget/Button;->setTextSize(IF)V

    .line 857
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_ButtonArr:[Landroid/widget/Button;

    aget-object v10, v10, v3

    const/16 v11, 0xac

    const/16 v12, 0xbe

    const/16 v13, 0xd8

    invoke-static {v11, v12, v13}, Landroid/graphics/Color;->rgb(III)I

    move-result v11

    invoke-virtual {v10, v11}, Landroid/widget/Button;->setTextColor(I)V

    .line 858
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_ButtonArr:[Landroid/widget/Button;

    aget-object v10, v10, v3

    invoke-virtual {v10, v7}, Landroid/widget/Button;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 859
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_ButtonArr:[Landroid/widget/Button;

    aget-object v10, v10, v3

    const v11, 0x7f02053b

    invoke-virtual {v10, v11}, Landroid/widget/Button;->setBackgroundResource(I)V

    .line 860
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_ButtonArr:[Landroid/widget/Button;

    aget-object v10, v10, v3

    const/16 v11, 0x8

    invoke-virtual {v10, v11}, Landroid/widget/Button;->setVisibility(I)V

    .line 861
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_ButtonArr:[Landroid/widget/Button;

    aget-object v10, v10, v3

    const/16 v11, 0xa

    const/4 v12, 0x0

    const/16 v13, 0xa

    const/4 v14, 0x0

    invoke-virtual {v10, v11, v12, v13, v14}, Landroid/widget/Button;->setPadding(IIII)V

    .line 863
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_ViewLineArr:[Landroid/view/View;

    new-instance v11, Landroid/widget/ImageView;

    invoke-direct {v11, p0}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    aput-object v11, v10, v3

    .line 864
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_ViewLineArr:[Landroid/view/View;

    aget-object v10, v10, v3

    const v11, 0x7f020c01

    invoke-virtual {v10, v11}, Landroid/view/View;->setBackgroundResource(I)V

    .line 865
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_ViewLineArr:[Landroid/view/View;

    aget-object v10, v10, v3

    invoke-virtual {v10, v8}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 866
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_ViewLineArr:[Landroid/view/View;

    aget-object v10, v10, v3

    const/16 v11, 0x8

    invoke-virtual {v10, v11}, Landroid/view/View;->setVisibility(I)V

    .line 868
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v10

    invoke-virtual {v10}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->getScaleType()I

    move-result v10

    const/4 v11, 0x2

    if-lt v10, v11, :cond_2

    .line 869
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INaviScaleManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INaviScaleManager;

    move-result-object v10

    iget-object v11, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_ViewLineArr:[Landroid/view/View;

    aget-object v11, v11, v3

    invoke-virtual {v10, v11}, Lcom/thinkware/sundo/inavi3d/INaviScaleManager;->restoreScale1Pixel(Landroid/view/View;)V

    .line 854
    :cond_2
    add-int/lit8 v3, v3, 0x1

    goto/16 :goto_3

    .line 697
    .end local v3    # "i":I
    .end local v7    # "paramsButton":Landroid/widget/LinearLayout$LayoutParams;
    .end local v8    # "paramsLine":Landroid/widget/LinearLayout$LayoutParams;
    :cond_3
    const v10, 0x7f03015e

    invoke-virtual {p0, v10}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->setContentView(I)V

    goto/16 :goto_1

    .line 795
    :cond_4
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mHelpDialog:Landroid/app/Dialog;

    const v11, 0x7f030103

    invoke-virtual {v10, v11}, Landroid/app/Dialog;->setContentView(I)V

    goto/16 :goto_2

    .line 961
    :cond_5
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->ReadyPreAreaNameSearch()V

    .line 962
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->ReadyLiveSearchAgreePopup()V

    .line 964
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v10

    invoke-virtual {v10}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->supportRSearch()Z

    move-result v10

    if-nez v10, :cond_8

    .line 966
    const/4 v10, 0x0

    invoke-static {v10}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->USAskLiveAgreeTerm(Z)Z

    .line 967
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->USGetLiveTermAgreed()Z

    move-result v10

    const/4 v11, 0x1

    if-ne v10, v11, :cond_7

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->getInstance()Lcom/thinkware/sundo/inavi3d/InaviConfig;

    move-result-object v10

    const/16 v11, 0xe3

    invoke-virtual {v10, v11}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->CNaviConfigGet(I)I

    move-result v10

    const/4 v11, 0x1

    if-ne v10, v11, :cond_7

    .line 969
    const/4 v10, 0x1

    iput-boolean v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bLiveSrch:Z

    .line 991
    :goto_4
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mBtnLive:Landroid/widget/Button;

    iget-boolean v11, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bLiveSrch:Z

    invoke-virtual {v10, v11}, Landroid/widget/Button;->setSelected(Z)V

    .line 994
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->USGetQueryHistoryCount()I

    move-result v10

    if-lez v10, :cond_13

    const/4 v10, 0x0

    invoke-static {v10}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->USGetQueryHistory(I)Ljava/lang/String;

    move-result-object v10

    iput-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strHistoryQuery:Ljava/lang/String;

    if-eqz v10, :cond_13

    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strHistoryQuery:Ljava/lang/String;

    invoke-virtual {p0, v10}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->IsValidQuery(Ljava/lang/String;)Z

    move-result v10

    if-eqz v10, :cond_13

    .line 998
    const/4 v6, 0x0

    .line 999
    .local v6, "nSpaceCnt":I
    iget-boolean v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bLiveSrch:Z

    if-nez v10, :cond_d

    .line 1000
    iget-object v9, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strHistoryQuery:Ljava/lang/String;

    .line 1001
    .local v9, "strKey":Ljava/lang/String;
    invoke-virtual {v9}, Ljava/lang/String;->length()I

    move-result v5

    .line 1003
    .local v5, "nLen":I
    const/4 v4, 0x0

    .local v4, "ii":I
    :goto_5
    if-ge v4, v5, :cond_d

    .line 1004
    invoke-virtual {v9, v4}, Ljava/lang/String;->charAt(I)C

    move-result v1

    .line 1005
    .local v1, "ch":C
    const/16 v10, 0x20

    if-ne v1, v10, :cond_6

    .line 1006
    add-int/lit8 v6, v6, 0x1

    .line 1003
    :cond_6
    add-int/lit8 v4, v4, 0x1

    goto :goto_5

    .line 971
    .end local v1    # "ch":C
    .end local v4    # "ii":I
    .end local v5    # "nLen":I
    .end local v6    # "nSpaceCnt":I
    .end local v9    # "strKey":Ljava/lang/String;
    :cond_7
    const/4 v10, 0x0

    iput-boolean v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bLiveSrch:Z

    goto :goto_4

    .line 974
    :cond_8
    invoke-static {p0}, Lcom/thinkware/i3dlite/CommonDef;->IsNetworkAvailable(Landroid/content/Context;)Z

    move-result v0

    .line 975
    .local v0, "bNetwork":Z
    const/4 v10, 0x1

    if-ne v0, v10, :cond_9

    .line 979
    :cond_9
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/livesearch/LiveSearchManager;->getInstance()Lcom/thinkware/sundo/inavi3d/livesearch/LiveSearchManager;

    move-result-object v10

    invoke-virtual {v10}, Lcom/thinkware/sundo/inavi3d/livesearch/LiveSearchManager;->isAgreed()Z

    move-result v10

    const/4 v11, 0x1

    if-ne v10, v11, :cond_b

    .line 980
    if-eqz v0, :cond_a

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->getInstance()Lcom/thinkware/sundo/inavi3d/InaviConfig;

    move-result-object v10

    const/16 v11, 0x11b

    invoke-virtual {v10, v11}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->CNaviConfigGet(I)I

    move-result v10

    const/4 v11, 0x1

    if-ne v10, v11, :cond_a

    .line 981
    const/4 v10, 0x1

    iput-boolean v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bLiveSrch:Z

    goto :goto_4

    .line 983
    :cond_a
    const/4 v10, 0x0

    iput-boolean v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bLiveSrch:Z

    goto :goto_4

    .line 985
    :cond_b
    if-eqz v0, :cond_c

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->getInstance()Lcom/thinkware/sundo/inavi3d/InaviConfig;

    move-result-object v10

    const/16 v11, 0x11b

    invoke-virtual {v10, v11}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->CNaviConfigGet(I)I

    move-result v10

    const/4 v11, 0x1

    if-ne v10, v11, :cond_c

    .line 986
    invoke-direct {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->showLiveProvisionPopup()V

    goto :goto_4

    .line 988
    :cond_c
    const/4 v10, 0x0

    iput-boolean v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bLiveSrch:Z

    goto :goto_4

    .line 1010
    .end local v0    # "bNetwork":Z
    .restart local v6    # "nSpaceCnt":I
    :cond_d
    const/4 v10, 0x1

    iput-boolean v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bCancleRecommend:Z

    .line 1011
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    iget-object v11, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strHistoryQuery:Ljava/lang/String;

    invoke-virtual {v10, v11}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    .line 1014
    const/4 v10, 0x1

    if-le v6, v10, :cond_e

    .line 1015
    invoke-direct {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->EraseSpaceInEditText()V

    .line 1018
    :cond_e
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    invoke-virtual {v10}, Landroid/widget/EditText;->selectAll()V

    .line 1020
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    invoke-virtual {v10}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v10

    iput-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strHistoryQuery:Ljava/lang/String;

    .line 1022
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/ui/SIPModel;->getInstance()Lcom/thinkware/sundo/inavi3d/ui/SIPModel;

    move-result-object v10

    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->IsEnableSpaceBtn()Z

    move-result v11

    invoke-virtual {v10, v11}, Lcom/thinkware/sundo/inavi3d/ui/SIPModel;->setSpaceButtonEnable(Z)V

    .line 1034
    .end local v6    # "nSpaceCnt":I
    :goto_6
    iget-boolean v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bLiveSrch:Z

    if-eqz v10, :cond_14

    .line 1035
    const/4 v10, 0x0

    invoke-virtual {p0, v10}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->enableRegionBtn(Z)V

    .line 1048
    :cond_f
    :goto_7
    invoke-direct {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->loadQueryHistory()V

    .line 1055
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->getIntent()Landroid/content/Intent;

    move-result-object v10

    const-string v11, "mode"

    const/4 v12, 0x0

    invoke-virtual {v10, v11, v12}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v10

    iput v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mode:I

    .line 1056
    iget v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mode:I

    const/4 v11, 0x1

    if-eq v10, v11, :cond_10

    iget v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mode:I

    const/4 v11, 0x2

    if-eq v10, v11, :cond_10

    iget v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mode:I

    const/16 v11, 0xc

    if-eq v10, v11, :cond_10

    iget v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mode:I

    const/16 v11, 0xd

    if-eq v10, v11, :cond_10

    iget v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mode:I

    const/4 v11, 0x4

    if-eq v10, v11, :cond_10

    iget v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mode:I

    const/4 v11, 0x3

    if-eq v10, v11, :cond_10

    iget v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mode:I

    const/16 v11, 0xb

    if-ne v10, v11, :cond_11

    .line 1059
    :cond_10
    const/4 v10, 0x1

    iput-boolean v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bAddMode:Z

    .line 1065
    :cond_11
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->getIntent()Landroid/content/Intent;

    move-result-object v10

    const-string v11, "Query"

    invoke-virtual {v10, v11}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    if-eqz v10, :cond_12

    .line 1066
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->getIntent()Landroid/content/Intent;

    move-result-object v11

    const-string v12, "Query"

    invoke-virtual {v11, v12}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v10, v11}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    .line 1067
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->getIntent()Landroid/content/Intent;

    move-result-object v10

    const-string v11, "Query"

    invoke-virtual {v10, v11}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    iput-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strQuery:Ljava/lang/String;

    .line 1069
    const/4 v10, 0x0

    iput-boolean v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bReSrch:Z

    .line 1071
    iget-boolean v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bLiveSrch:Z

    if-eqz v10, :cond_16

    .line 1072
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->DoLiveSearch()V

    .line 1079
    :cond_12
    :goto_8
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    move-result-object v10

    const/4 v11, 0x0

    const/4 v12, 0x0

    invoke-virtual {v10, v11, v12}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->setWorkingDayInfo(Lcom/thinkware/sundo/inavi3d/ui/component/CustumDefine$GUISearchPointData;Z)V

    goto/16 :goto_0

    .line 1025
    :cond_13
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mBtnSearch:Landroid/widget/ImageButton;

    const/4 v11, 0x0

    invoke-virtual {v10, v11}, Landroid/widget/ImageButton;->setEnabled(Z)V

    .line 1026
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mBtnErase:Landroid/widget/Button;

    const/4 v11, 0x4

    invoke-virtual {v10, v11}, Landroid/widget/Button;->setVisibility(I)V

    .line 1028
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/ui/SIPModel;->getInstance()Lcom/thinkware/sundo/inavi3d/ui/SIPModel;

    move-result-object v10

    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->IsEnableSearchBtn()Z

    move-result v11

    invoke-virtual {v10, v11}, Lcom/thinkware/sundo/inavi3d/ui/SIPModel;->setSearchButtonEnable(Z)V

    .line 1029
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/ui/SIPModel;->getInstance()Lcom/thinkware/sundo/inavi3d/ui/SIPModel;

    move-result-object v10

    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->IsEnableSpaceBtn()Z

    move-result v11

    invoke-virtual {v10, v11}, Lcom/thinkware/sundo/inavi3d/ui/SIPModel;->setSpaceButtonEnable(Z)V

    goto/16 :goto_6

    .line 1037
    :cond_14
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    invoke-virtual {v10}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    .line 1039
    .local v2, "edtString":Ljava/lang/String;
    const-string v10, " "

    invoke-virtual {v2, v10}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v10

    const/4 v11, 0x1

    if-ne v10, v11, :cond_f

    .line 1040
    invoke-virtual {p0, v2}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->IsIncludeAdminName(Ljava/lang/String;)Z

    move-result v10

    if-nez v10, :cond_15

    .line 1041
    const/4 v10, 0x1

    invoke-virtual {p0, v10}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->enableRegionBtn(Z)V

    goto/16 :goto_7

    .line 1043
    :cond_15
    const/4 v10, 0x0

    invoke-virtual {p0, v10}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->enableRegionBtn(Z)V

    goto/16 :goto_7

    .line 1074
    .end local v2    # "edtString":Ljava/lang/String;
    :cond_16
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->DoSearch()V

    goto :goto_8
.end method

.method protected onDestroy()V
    .locals 4

    .prologue
    const/4 v3, 0x0

    .line 1449
    invoke-super {p0}, Lcom/thinkware/sundo/inavi3d/MainActivity;->onDestroy()V

    .line 1450
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->bForceClosing:Z

    if-eqz v0, :cond_0

    .line 1484
    :goto_0
    return-void

    .line 1453
    :cond_0
    const-string v0, "inavi3d_bona"

    const-string v1, "UnitedSearchActivity onDestroy 1"

    invoke-static {v0, v1}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 1454
    new-instance v0, Lcom/thinkware/sundo/inavi3d/INaviTask;

    new-instance v1, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$9;

    invoke-direct {v1, p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$9;-><init>(Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;)V

    invoke-direct {v0, v1, v3}, Lcom/thinkware/sundo/inavi3d/INaviTask;-><init>(Lcom/thinkware/sundo/inavi3d/INaviTask$iINaviTaskInterFace;Z)V

    const/4 v1, 0x1

    new-array v1, v1, [Ljava/lang/Object;

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    aput-object v2, v1, v3

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/inavi3d/INaviTask;->execute([Ljava/lang/Object;)Landroid/os/AsyncTask;

    goto :goto_0
.end method

.method public onEditorAction(Landroid/widget/TextView;ILandroid/view/KeyEvent;)Z
    .locals 6
    .param p1, "v"    # Landroid/widget/TextView;
    .param p2, "actionId"    # I
    .param p3, "event"    # Landroid/view/KeyEvent;

    .prologue
    const/16 v5, 0x1773

    const/4 v1, 0x0

    const/4 v2, 0x1

    .line 2510
    const/4 v3, 0x6

    if-eq p2, v3, :cond_0

    const/4 v3, 0x3

    if-eq p2, v3, :cond_0

    if-eqz p3, :cond_1

    invoke-virtual {p3}, Landroid/view/KeyEvent;->getKeyCode()I

    move-result v3

    const/16 v4, 0x42

    if-ne v3, v4, :cond_1

    .line 2513
    :cond_0
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    invoke-virtual {v3}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p0, v3}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->IsValidQuery(Ljava/lang/String;)Z

    move-result v3

    if-nez v3, :cond_2

    move v1, v2

    .line 2548
    :cond_1
    :goto_0
    return v1

    .line 2517
    :cond_2
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    invoke-virtual {v3}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v3

    iput-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strQuery:Ljava/lang/String;

    .line 2519
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strQuery:Ljava/lang/String;

    const-string v4, "##\ub85c\uae45\uc2dc\uc791"

    invoke-virtual {v3, v4}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v3

    if-eqz v3, :cond_3

    .line 2520
    const-string v3, ""

    invoke-static {v5, v2, v3}, Lcom/thinkware/sundo/inavi3d/Inavi;->ProcessMessage(IILjava/lang/String;)I

    .line 2521
    const-string v3, "\ub85c\uae45\uc2dc\uc791 (/storage/emulated/0/inavi3d/gpslog/)"

    invoke-static {p0, v3, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v2

    invoke-virtual {v2}, Landroid/widget/Toast;->show()V

    .line 2522
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strQuery:Ljava/lang/String;

    invoke-static {v2, v1}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->USSetQueryHistory(Ljava/lang/String;I)V

    goto :goto_0

    .line 2525
    :cond_3
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strQuery:Ljava/lang/String;

    const-string v4, "##\ub85c\uae45\uc911\ub2e8"

    invoke-virtual {v3, v4}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v3

    if-eqz v3, :cond_4

    .line 2526
    const-string v3, ""

    invoke-static {v5, v1, v3}, Lcom/thinkware/sundo/inavi3d/Inavi;->ProcessMessage(IILjava/lang/String;)I

    .line 2527
    const-string v3, "\ub85c\uae45\uc911\ub2e8 (/storage/emulated/0/inavi3d/gpslog/)"

    invoke-static {p0, v3, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v2

    invoke-virtual {v2}, Landroid/widget/Toast;->show()V

    .line 2528
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strQuery:Ljava/lang/String;

    invoke-static {v2, v1}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->USSetQueryHistory(Ljava/lang/String;I)V

    goto :goto_0

    .line 2532
    :cond_4
    iget-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bOnceRun:Z

    if-nez v1, :cond_6

    .line 2533
    iget-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bLiveSrch:Z

    if-eqz v1, :cond_5

    .line 2534
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->DoLiveSearch()V

    .line 2538
    :goto_1
    iput-boolean v2, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bOnceRun:Z

    .line 2543
    new-instance v0, Landroid/os/Handler;

    invoke-direct {v0}, Landroid/os/Handler;-><init>()V

    .line 2544
    .local v0, "h":Landroid/os/Handler;
    new-instance v1, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$OnceRunhandler;

    invoke-direct {v1, p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$OnceRunhandler;-><init>(Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;)V

    const-wide/16 v4, 0x3e8

    invoke-virtual {v0, v1, v4, v5}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    move v1, v2

    .line 2546
    goto :goto_0

    .line 2536
    .end local v0    # "h":Landroid/os/Handler;
    :cond_5
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->DoSearch()V

    goto :goto_1

    :cond_6
    move v1, v2

    .line 2540
    goto :goto_0
.end method

.method public onFocusChange(Landroid/view/View;Z)V
    .locals 3
    .param p1, "v"    # Landroid/view/View;
    .param p2, "hasFocus"    # Z

    .prologue
    const/4 v2, 0x0

    .line 1957
    invoke-virtual {p1}, Landroid/view/View;->getId()I

    move-result v0

    packed-switch v0, :pswitch_data_0

    .line 1966
    :goto_0
    return-void

    .line 1959
    :pswitch_0
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    const v1, 0x7f020be3

    invoke-virtual {v0, v1}, Landroid/widget/EditText;->setBackgroundResource(I)V

    .line 1960
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    const/16 v1, 0xf

    invoke-virtual {v0, v1, v2, v2, v2}, Landroid/widget/EditText;->setPadding(IIII)V

    goto :goto_0

    .line 1957
    nop

    :pswitch_data_0
    .packed-switch 0x7f0a027f
        :pswitch_0
    .end packed-switch
.end method

.method protected onResume()V
    .locals 7

    .prologue
    const/4 v4, 0x1

    const/4 v5, 0x0

    .line 1699
    invoke-virtual {p0, v5, v5}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->overridePendingTransition(II)V

    .line 1700
    invoke-super {p0}, Lcom/thinkware/sundo/inavi3d/MainActivity;->onResume()V

    .line 1701
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->bForceClosing:Z

    if-eqz v0, :cond_1

    .line 1736
    :cond_0
    :goto_0
    return-void

    .line 1706
    :cond_1
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->getIntent()Landroid/content/Intent;

    move-result-object v0

    const-string v1, "mode"

    invoke-virtual {v0, v1, v5}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v0

    iput v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mode:I

    .line 1707
    iget v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mode:I

    if-eq v0, v4, :cond_2

    iget v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mode:I

    const/4 v1, 0x2

    if-eq v0, v1, :cond_2

    iget v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mode:I

    const/16 v1, 0xc

    if-eq v0, v1, :cond_2

    iget v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mode:I

    const/16 v1, 0xd

    if-eq v0, v1, :cond_2

    iget v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mode:I

    const/4 v1, 0x4

    if-eq v0, v1, :cond_2

    iget v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mode:I

    const/4 v1, 0x3

    if-eq v0, v1, :cond_2

    iget v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mode:I

    const/16 v1, 0xb

    if-ne v0, v1, :cond_3

    .line 1710
    :cond_2
    iput-boolean v4, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bAddMode:Z

    .line 1716
    :cond_3
    const v0, 0x7f0a003c

    invoke-virtual {p0, v0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/RelativeLayout;

    .line 1718
    .local v2, "SIPBGlayout":Landroid/widget/RelativeLayout;
    invoke-virtual {v2, v5}, Landroid/widget/RelativeLayout;->setBackgroundColor(I)V

    .line 1720
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/ui/SIPModel;->getInstance()Lcom/thinkware/sundo/inavi3d/ui/SIPModel;

    move-result-object v0

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    const/16 v6, 0x10

    move-object v1, p0

    invoke-virtual/range {v0 .. v6}, Lcom/thinkware/sundo/inavi3d/ui/SIPModel;->addSIP(Landroid/content/Context;Landroid/view/ViewGroup;Landroid/widget/EditText;ZZI)V

    .line 1722
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    const v1, 0x7f020be5

    invoke-virtual {v0, v1}, Landroid/widget/EditText;->setBackgroundResource(I)V

    .line 1723
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    const/16 v1, 0xf

    invoke-virtual {v0, v1, v5, v5, v5}, Landroid/widget/EditText;->setPadding(IIII)V

    .line 1725
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabUnited:Landroid/widget/Button;

    new-instance v1, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$16;

    invoke-direct {v1, p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$16;-><init>(Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;)V

    const-wide/16 v4, 0x64

    invoke-virtual {v0, v1, v4, v5}, Landroid/widget/Button;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 1732
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v0

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->is_support_builtin_statusbar()Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_0
.end method

.method public onSearchClear()V
    .locals 0

    .prologue
    .line 2593
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->searchClear()V

    .line 2594
    return-void
.end method

.method public onSelectedSearch()V
    .locals 0

    .prologue
    .line 2588
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->doUnitedSearch()V

    .line 2589
    return-void
.end method

.method protected onStart()V
    .locals 2

    .prologue
    .line 1434
    invoke-super {p0}, Lcom/thinkware/sundo/inavi3d/MainActivity;->onStart()V

    .line 1435
    const-string v0, "inavi3d_bona"

    const-string v1, "MainMenu onStart"

    invoke-static {v0, v1}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 1436
    return-void
.end method

.method protected onStop()V
    .locals 2

    .prologue
    .line 1441
    sget-object v0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mActivity:Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;

    if-eqz v0, :cond_0

    .line 1442
    const/4 v0, 0x0

    sput-object v0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mActivity:Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;

    .line 1443
    :cond_0
    invoke-super {p0}, Lcom/thinkware/sundo/inavi3d/MainActivity;->onStop()V

    .line 1444
    const-string v0, "inavi3d_java"

    const-string v1, "MainMenu onStop"

    invoke-static {v0, v1}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 1445
    return-void
.end method

.method public searchClear()V
    .locals 2

    .prologue
    .line 1969
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    const-string v1, ""

    invoke-virtual {v0, v1}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    .line 1972
    const-string v0, ""

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strQuery:Ljava/lang/String;

    .line 1975
    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bIsExistSpaceInKeyword:Z

    .line 1976
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bLiveSrch:Z

    if-nez v0, :cond_0

    .line 1977
    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->enableRegionBtn(Z)V

    .line 1982
    :cond_0
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/ui/SIPModel;->getInstance()Lcom/thinkware/sundo/inavi3d/ui/SIPModel;

    move-result-object v0

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/ui/SIPModel;->clearText()V

    .line 1983
    return-void
.end method

.method setSearchOption()V
    .locals 4

    .prologue
    const/4 v2, 0x1

    .line 1657
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_SearchOption:Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;

    iget v1, v1, Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;->m_nOption:I

    if-nez v1, :cond_2

    .line 1658
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_SearchOption:Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;

    iget v1, v1, Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;->m_nAdminCode:I

    if-nez v1, :cond_1

    .line 1659
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mBtnSetRegion:Landroid/widget/Button;

    const-string v2, "\uc804\uad6d"

    invoke-virtual {v1, v2}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 1694
    :cond_0
    :goto_0
    return-void

    .line 1660
    :cond_1
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_SearchOption:Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;

    iget-object v1, v1, Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;->m_strOption:Ljava/lang/String;

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v1

    if-le v1, v2, :cond_0

    .line 1661
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mBtnSetRegion:Landroid/widget/Button;

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_SearchOption:Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;->m_strOption:Ljava/lang/String;

    invoke-virtual {v1, v2}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 1664
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_SearchOption:Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;

    iget-object v1, v1, Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;->m_strOption:Ljava/lang/String;

    const-string v2, "\uc138\uc885\ud2b9\ubcc4\uc790\uce58\uc2dc"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_0

    .line 1665
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mBtnSetRegion:Landroid/widget/Button;

    const-string v2, "\uc138\uc885\ud2b9\ubcc4\uc2dc"

    invoke-virtual {v1, v2}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    goto :goto_0

    .line 1667
    :cond_2
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_SearchOption:Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;

    iget v1, v1, Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;->m_nOption:I

    if-ne v1, v2, :cond_0

    .line 1668
    const/4 v0, 0x0

    .line 1670
    .local v0, "nRadiusKM":I
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_SearchOption:Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;

    iget v1, v1, Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;->m_nRadiusBoundary:I

    packed-switch v1, :pswitch_data_0

    .line 1689
    :goto_1
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mBtnSetRegion:Landroid/widget/Button;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " km"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    goto :goto_0

    .line 1672
    :pswitch_0
    const/4 v0, 0x1

    .line 1673
    goto :goto_1

    .line 1675
    :pswitch_1
    const/4 v0, 0x2

    .line 1676
    goto :goto_1

    .line 1678
    :pswitch_2
    const/4 v0, 0x5

    .line 1679
    goto :goto_1

    .line 1681
    :pswitch_3
    const/16 v0, 0x8

    .line 1682
    goto :goto_1

    .line 1684
    :pswitch_4
    const/16 v0, 0xa

    .line 1685
    goto :goto_1

    .line 1670
    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
        :pswitch_1
        :pswitch_2
        :pswitch_3
        :pswitch_4
    .end packed-switch
.end method

.method public showMaxLengthPopup()V
    .locals 0

    .prologue
    .line 2583
    invoke-direct {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->_ShowInputOverflowMsg()V

    .line 2584
    return-void
.end method
