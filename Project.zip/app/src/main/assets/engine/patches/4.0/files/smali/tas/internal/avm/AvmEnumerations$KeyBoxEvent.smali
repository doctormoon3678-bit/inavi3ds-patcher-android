.class public final enum Ltas/internal/avm/AvmEnumerations$KeyBoxEvent;
.super Ljava/lang/Enum;
.source "AvmEnumerations.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltas/internal/avm/AvmEnumerations;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "KeyBoxEvent"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum",
        "<",
        "Ltas/internal/avm/AvmEnumerations$KeyBoxEvent;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Ltas/internal/avm/AvmEnumerations$KeyBoxEvent;

.field public static final enum PRESS_MODE_KEY:Ltas/internal/avm/AvmEnumerations$KeyBoxEvent;

.field public static final enum PRESS_MODE_LONGKEY:Ltas/internal/avm/AvmEnumerations$KeyBoxEvent;

.field public static final enum PRESS_PWR_KEY:Ltas/internal/avm/AvmEnumerations$KeyBoxEvent;

.field public static final enum PRESS_PWR_LONGKEY:Ltas/internal/avm/AvmEnumerations$KeyBoxEvent;

.field public static final enum PRESS_UNKNOWN_KEY:Ltas/internal/avm/AvmEnumerations$KeyBoxEvent;


# instance fields
.field private key:I


# direct methods
.method static constructor <clinit>()V
    .locals 8

    .prologue
    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x1

    .line 163
    new-instance v0, Ltas/internal/avm/AvmEnumerations$KeyBoxEvent;

    const-string/jumbo v1, "PRESS_MODE_KEY"

    invoke-direct {v0, v1, v5, v3}, Ltas/internal/avm/AvmEnumerations$KeyBoxEvent;-><init>(Ljava/lang/String;II)V

    sput-object v0, Ltas/internal/avm/AvmEnumerations$KeyBoxEvent;->PRESS_MODE_KEY:Ltas/internal/avm/AvmEnumerations$KeyBoxEvent;

    .line 164
    new-instance v0, Ltas/internal/avm/AvmEnumerations$KeyBoxEvent;

    const-string/jumbo v1, "PRESS_PWR_KEY"

    invoke-direct {v0, v1, v3, v4}, Ltas/internal/avm/AvmEnumerations$KeyBoxEvent;-><init>(Ljava/lang/String;II)V

    sput-object v0, Ltas/internal/avm/AvmEnumerations$KeyBoxEvent;->PRESS_PWR_KEY:Ltas/internal/avm/AvmEnumerations$KeyBoxEvent;

    .line 165
    new-instance v0, Ltas/internal/avm/AvmEnumerations$KeyBoxEvent;

    const-string/jumbo v1, "PRESS_MODE_LONGKEY"

    const/16 v2, 0x11

    invoke-direct {v0, v1, v4, v2}, Ltas/internal/avm/AvmEnumerations$KeyBoxEvent;-><init>(Ljava/lang/String;II)V

    sput-object v0, Ltas/internal/avm/AvmEnumerations$KeyBoxEvent;->PRESS_MODE_LONGKEY:Ltas/internal/avm/AvmEnumerations$KeyBoxEvent;

    .line 166
    new-instance v0, Ltas/internal/avm/AvmEnumerations$KeyBoxEvent;

    const-string/jumbo v1, "PRESS_PWR_LONGKEY"

    const/16 v2, 0x12

    invoke-direct {v0, v1, v6, v2}, Ltas/internal/avm/AvmEnumerations$KeyBoxEvent;-><init>(Ljava/lang/String;II)V

    sput-object v0, Ltas/internal/avm/AvmEnumerations$KeyBoxEvent;->PRESS_PWR_LONGKEY:Ltas/internal/avm/AvmEnumerations$KeyBoxEvent;

    .line 167
    new-instance v0, Ltas/internal/avm/AvmEnumerations$KeyBoxEvent;

    const-string/jumbo v1, "PRESS_UNKNOWN_KEY"

    const/16 v2, 0xff

    invoke-direct {v0, v1, v7, v2}, Ltas/internal/avm/AvmEnumerations$KeyBoxEvent;-><init>(Ljava/lang/String;II)V

    sput-object v0, Ltas/internal/avm/AvmEnumerations$KeyBoxEvent;->PRESS_UNKNOWN_KEY:Ltas/internal/avm/AvmEnumerations$KeyBoxEvent;

    .line 162
    const/4 v0, 0x5

    new-array v0, v0, [Ltas/internal/avm/AvmEnumerations$KeyBoxEvent;

    sget-object v1, Ltas/internal/avm/AvmEnumerations$KeyBoxEvent;->PRESS_MODE_KEY:Ltas/internal/avm/AvmEnumerations$KeyBoxEvent;

    aput-object v1, v0, v5

    sget-object v1, Ltas/internal/avm/AvmEnumerations$KeyBoxEvent;->PRESS_PWR_KEY:Ltas/internal/avm/AvmEnumerations$KeyBoxEvent;

    aput-object v1, v0, v3

    sget-object v1, Ltas/internal/avm/AvmEnumerations$KeyBoxEvent;->PRESS_MODE_LONGKEY:Ltas/internal/avm/AvmEnumerations$KeyBoxEvent;

    aput-object v1, v0, v4

    sget-object v1, Ltas/internal/avm/AvmEnumerations$KeyBoxEvent;->PRESS_PWR_LONGKEY:Ltas/internal/avm/AvmEnumerations$KeyBoxEvent;

    aput-object v1, v0, v6

    sget-object v1, Ltas/internal/avm/AvmEnumerations$KeyBoxEvent;->PRESS_UNKNOWN_KEY:Ltas/internal/avm/AvmEnumerations$KeyBoxEvent;

    aput-object v1, v0, v7

    sput-object v0, Ltas/internal/avm/AvmEnumerations$KeyBoxEvent;->$VALUES:[Ltas/internal/avm/AvmEnumerations$KeyBoxEvent;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .locals 0
    .param p3, "key"    # I

    .prologue
    .line 170
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 171
    iput p3, p0, Ltas/internal/avm/AvmEnumerations$KeyBoxEvent;->key:I

    .line 170
    return-void
.end method

.method public static createFromOrdinalNumber(I)Ltas/internal/avm/AvmEnumerations$KeyBoxEvent;
    .locals 5
    .param p0, "number"    # I

    .prologue
    .line 194
    invoke-static {}, Ltas/internal/avm/AvmEnumerations$KeyBoxEvent;->values()[Ltas/internal/avm/AvmEnumerations$KeyBoxEvent;

    move-result-object v2

    const/4 v1, 0x0

    array-length v3, v2

    :goto_0
    if-ge v1, v3, :cond_1

    aget-object v0, v2, v1

    .line 195
    .local v0, "i":Ltas/internal/avm/AvmEnumerations$KeyBoxEvent;
    invoke-virtual {v0}, Ltas/internal/avm/AvmEnumerations$KeyBoxEvent;->ordinal()I

    move-result v4

    if-ne v4, p0, :cond_0

    .line 196
    return-object v0

    .line 194
    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    .line 199
    .end local v0    # "i":Ltas/internal/avm/AvmEnumerations$KeyBoxEvent;
    :cond_1
    sget-object v1, Ltas/internal/avm/AvmEnumerations$KeyBoxEvent;->PRESS_UNKNOWN_KEY:Ltas/internal/avm/AvmEnumerations$KeyBoxEvent;

    return-object v1
.end method

.method public static createFromValue(I)Ltas/internal/avm/AvmEnumerations$KeyBoxEvent;
    .locals 5
    .param p0, "key"    # I

    .prologue
    .line 185
    invoke-static {}, Ltas/internal/avm/AvmEnumerations$KeyBoxEvent;->values()[Ltas/internal/avm/AvmEnumerations$KeyBoxEvent;

    move-result-object v2

    const/4 v1, 0x0

    array-length v3, v2

    :goto_0
    if-ge v1, v3, :cond_1

    aget-object v0, v2, v1

    .line 186
    .local v0, "i":Ltas/internal/avm/AvmEnumerations$KeyBoxEvent;
    invoke-virtual {v0}, Ltas/internal/avm/AvmEnumerations$KeyBoxEvent;->toInteger()I

    move-result v4

    if-ne v4, p0, :cond_0

    .line 187
    return-object v0

    .line 185
    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    .line 190
    .end local v0    # "i":Ltas/internal/avm/AvmEnumerations$KeyBoxEvent;
    :cond_1
    sget-object v1, Ltas/internal/avm/AvmEnumerations$KeyBoxEvent;->PRESS_UNKNOWN_KEY:Ltas/internal/avm/AvmEnumerations$KeyBoxEvent;

    return-object v1
.end method

.method public static getRandomForTest()Ltas/internal/avm/AvmEnumerations$KeyBoxEvent;
    .locals 4

    .prologue
    .line 179
    invoke-static {}, Ljava/util/concurrent/ThreadLocalRandom;->current()Ljava/util/concurrent/ThreadLocalRandom;

    move-result-object v1

    .line 180
    .local v1, "random":Ljava/util/concurrent/ThreadLocalRandom;
    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {v1, v2, v3}, Ljava/util/concurrent/ThreadLocalRandom;->nextInt(II)I

    move-result v0

    .line 181
    .local v0, "rand":I
    invoke-static {v0}, Ltas/internal/avm/AvmEnumerations$KeyBoxEvent;->createFromOrdinalNumber(I)Ltas/internal/avm/AvmEnumerations$KeyBoxEvent;

    move-result-object v2

    return-object v2
.end method

.method public static valueOf(Ljava/lang/String;)Ltas/internal/avm/AvmEnumerations$KeyBoxEvent;
    .locals 1
    .param p0, "name"    # Ljava/lang/String;

    .prologue
    .line 162
    const-class v0, Ltas/internal/avm/AvmEnumerations$KeyBoxEvent;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object v0

    check-cast v0, Ltas/internal/avm/AvmEnumerations$KeyBoxEvent;

    return-object v0
.end method

.method public static values()[Ltas/internal/avm/AvmEnumerations$KeyBoxEvent;
    .locals 1

    .prologue
    .line 162
    sget-object v0, Ltas/internal/avm/AvmEnumerations$KeyBoxEvent;->$VALUES:[Ltas/internal/avm/AvmEnumerations$KeyBoxEvent;

    return-object v0
.end method


# virtual methods
.method public toInteger()I
    .locals 1

    .prologue
    .line 175
    iget v0, p0, Ltas/internal/avm/AvmEnumerations$KeyBoxEvent;->key:I

    return v0
.end method
