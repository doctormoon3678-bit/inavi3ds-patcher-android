.class public final enum Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADSPEC;
.super Ljava/lang/Enum;
.source "ieveGuideInfos.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/thinkware/sundo/ieve/ieveGuideInfos;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "ROADATTRIB_ROADSPEC"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum",
        "<",
        "Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADSPEC;",
        ">;"
    }
.end annotation


# static fields
.field public static final enum LINK_ATTR_CONNECTION:Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADSPEC;

.field public static final enum LINK_ATTR_JUNCTION:Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADSPEC;

.field public static final enum LINK_ATTR_MAINLINK1:Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADSPEC;

.field public static final enum LINK_ATTR_MAINLINK2:Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADSPEC;

.field public static final enum LINK_ATTR_RAMP:Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADSPEC;

.field public static final enum LINK_ATTR_SERVICEAREA:Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADSPEC;

.field public static final enum NONE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADSPEC;

.field private static final synthetic b:[Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADSPEC;


# instance fields
.field private final a:I


# direct methods
.method static constructor <clinit>()V
    .locals 9

    .prologue
    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v4, 0x0

    .line 19
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADSPEC;

    const-string v1, "NONE"

    invoke-direct {v0, v1, v4, v4}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADSPEC;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADSPEC;->NONE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADSPEC;

    .line 20
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADSPEC;

    const-string v1, "LINK_ATTR_MAINLINK1"

    invoke-direct {v0, v1, v5, v5}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADSPEC;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADSPEC;->LINK_ATTR_MAINLINK1:Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADSPEC;

    .line 21
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADSPEC;

    const-string v1, "LINK_ATTR_MAINLINK2"

    invoke-direct {v0, v1, v6, v6}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADSPEC;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADSPEC;->LINK_ATTR_MAINLINK2:Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADSPEC;

    .line 22
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADSPEC;

    const-string v1, "LINK_ATTR_CONNECTION"

    invoke-direct {v0, v1, v7, v7}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADSPEC;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADSPEC;->LINK_ATTR_CONNECTION:Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADSPEC;

    .line 23
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADSPEC;

    const-string v1, "LINK_ATTR_JUNCTION"

    invoke-direct {v0, v1, v8, v8}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADSPEC;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADSPEC;->LINK_ATTR_JUNCTION:Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADSPEC;

    .line 24
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADSPEC;

    const-string v1, "LINK_ATTR_RAMP"

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADSPEC;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADSPEC;->LINK_ATTR_RAMP:Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADSPEC;

    .line 25
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADSPEC;

    const-string v1, "LINK_ATTR_SERVICEAREA"

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADSPEC;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADSPEC;->LINK_ATTR_SERVICEAREA:Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADSPEC;

    .line 18
    const/4 v0, 0x7

    new-array v0, v0, [Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADSPEC;

    sget-object v1, Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADSPEC;->NONE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADSPEC;

    aput-object v1, v0, v4

    sget-object v1, Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADSPEC;->LINK_ATTR_MAINLINK1:Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADSPEC;

    aput-object v1, v0, v5

    sget-object v1, Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADSPEC;->LINK_ATTR_MAINLINK2:Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADSPEC;

    aput-object v1, v0, v6

    sget-object v1, Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADSPEC;->LINK_ATTR_CONNECTION:Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADSPEC;

    aput-object v1, v0, v7

    sget-object v1, Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADSPEC;->LINK_ATTR_JUNCTION:Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADSPEC;

    aput-object v1, v0, v8

    const/4 v1, 0x5

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADSPEC;->LINK_ATTR_RAMP:Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADSPEC;

    aput-object v2, v0, v1

    const/4 v1, 0x6

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADSPEC;->LINK_ATTR_SERVICEAREA:Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADSPEC;

    aput-object v2, v0, v1

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADSPEC;->b:[Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADSPEC;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .locals 0
    .param p3, "value"    # I

    .prologue
    .line 27
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    iput p3, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADSPEC;->a:I

    return-void
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADSPEC;
    .locals 1

    .prologue
    .line 1
    const-class v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADSPEC;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object v0

    check-cast v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADSPEC;

    return-object v0
.end method

.method public static values()[Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADSPEC;
    .locals 4

    .prologue
    const/4 v3, 0x0

    .line 1
    sget-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADSPEC;->b:[Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADSPEC;

    array-length v1, v0

    new-array v2, v1, [Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADSPEC;

    invoke-static {v0, v3, v2, v3, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    return-object v2
.end method


# virtual methods
.method public getValue()I
    .locals 1

    .prologue
    .line 29
    iget v0, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$ROADATTRIB_ROADSPEC;->a:I

    return v0
.end method
