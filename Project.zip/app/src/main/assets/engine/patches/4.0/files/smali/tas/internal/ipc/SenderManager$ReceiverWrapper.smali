.class Ltas/internal/ipc/SenderManager$ReceiverWrapper;
.super Ltas/internal/ipc/server/RemoteReceiver;
.source "SenderManager.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltas/internal/ipc/SenderManager;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "ReceiverWrapper"
.end annotation


# instance fields
.field connection:Ltas/internal/ipc/SenderManager$ReceiverConnectionWrapper;

.field sender:Ltas/internal/ipc/server/RemoteSender;

.field final synthetic this$0:Ltas/internal/ipc/SenderManager;


# direct methods
.method constructor <init>(Ltas/internal/ipc/SenderManager;Ltas/internal/ipc/server/RemoteSender;Ltas/internal/ipc/server/RemoteReceiver;)V
    .locals 6
    .param p1, "this$0"    # Ltas/internal/ipc/SenderManager;
    .param p2, "s"    # Ltas/internal/ipc/server/RemoteSender;
    .param p3, "r"    # Ltas/internal/ipc/server/RemoteReceiver;

    .prologue
    const/4 v1, 0x0

    .line 564
    iput-object p1, p0, Ltas/internal/ipc/SenderManager$ReceiverWrapper;->this$0:Ltas/internal/ipc/SenderManager;

    .line 565
    invoke-direct {p0, p3}, Ltas/internal/ipc/server/RemoteReceiver;-><init>(Ltas/internal/ipc/server/RemoteReceiver;)V

    .line 566
    iput-object p2, p0, Ltas/internal/ipc/SenderManager$ReceiverWrapper;->sender:Ltas/internal/ipc/server/RemoteSender;

    .line 567
    iget-boolean v0, p0, Ltas/internal/ipc/SenderManager$ReceiverWrapper;->p2pMode:Z

    if-eqz v0, :cond_0

    .line 568
    invoke-static {p1}, Ltas/internal/ipc/SenderManager;->-get3(Ltas/internal/ipc/SenderManager;)Z

    move-result v0

    if-eqz v0, :cond_1

    .line 569
    invoke-static {p1, v1}, Ltas/internal/ipc/SenderManager;->-set1(Ltas/internal/ipc/SenderManager;Landroid/os/Looper;)Landroid/os/Looper;

    .line 578
    :goto_0
    new-instance v0, Ltas/internal/ipc/SenderManager$ReceiverConnectionWrapper;

    .line 579
    invoke-static {p1}, Ltas/internal/ipc/SenderManager;->-get0(Ltas/internal/ipc/SenderManager;)Landroid/content/Context;

    move-result-object v2

    invoke-static {p1}, Ltas/internal/ipc/SenderManager;->-get2(Ltas/internal/ipc/SenderManager;)Landroid/os/Looper;

    move-result-object v5

    move-object v1, p1

    move-object v3, p2

    move-object v4, p0

    .line 578
    invoke-direct/range {v0 .. v5}, Ltas/internal/ipc/SenderManager$ReceiverConnectionWrapper;-><init>(Ltas/internal/ipc/SenderManager;Landroid/content/Context;Ltas/internal/ipc/server/RemoteSender;Ltas/internal/ipc/SenderManager$ReceiverWrapper;Landroid/os/Looper;)V

    iput-object v0, p0, Ltas/internal/ipc/SenderManager$ReceiverWrapper;->connection:Ltas/internal/ipc/SenderManager$ReceiverConnectionWrapper;

    .line 564
    :cond_0
    return-void

    .line 571
    :cond_1
    invoke-static {p1}, Ltas/internal/ipc/SenderManager;->-get1(Ltas/internal/ipc/SenderManager;)Landroid/os/HandlerThread;

    move-result-object v0

    if-nez v0, :cond_2

    .line 572
    new-instance v0, Landroid/os/HandlerThread;

    const-string/jumbo v1, "TasMsg-RConnection-Local"

    invoke-direct {v0, v1}, Landroid/os/HandlerThread;-><init>(Ljava/lang/String;)V

    invoke-static {p1, v0}, Ltas/internal/ipc/SenderManager;->-set0(Ltas/internal/ipc/SenderManager;Landroid/os/HandlerThread;)Landroid/os/HandlerThread;

    .line 573
    invoke-static {p1}, Ltas/internal/ipc/SenderManager;->-get1(Ltas/internal/ipc/SenderManager;)Landroid/os/HandlerThread;

    move-result-object v0

    invoke-virtual {v0}, Landroid/os/HandlerThread;->start()V

    .line 575
    :cond_2
    invoke-static {p1}, Ltas/internal/ipc/SenderManager;->-get1(Ltas/internal/ipc/SenderManager;)Landroid/os/HandlerThread;

    move-result-object v0

    invoke-virtual {v0}, Landroid/os/HandlerThread;->getLooper()Landroid/os/Looper;

    move-result-object v0

    invoke-static {p1, v0}, Ltas/internal/ipc/SenderManager;->-set1(Ltas/internal/ipc/SenderManager;Landroid/os/Looper;)Landroid/os/Looper;

    goto :goto_0
.end method


# virtual methods
.method connect()V
    .locals 2

    .prologue
    .line 598
    iget-object v0, p0, Ltas/internal/ipc/SenderManager$ReceiverWrapper;->connection:Ltas/internal/ipc/SenderManager$ReceiverConnectionWrapper;

    if-eqz v0, :cond_0

    .line 599
    iget-object v0, p0, Ltas/internal/ipc/SenderManager$ReceiverWrapper;->connection:Ltas/internal/ipc/SenderManager$ReceiverConnectionWrapper;

    invoke-virtual {v0}, Ltas/internal/ipc/SenderManager$ReceiverConnectionWrapper;->connect()V

    .line 597
    :goto_0
    return-void

    .line 601
    :cond_0
    iget-object v0, p0, Ltas/internal/ipc/SenderManager$ReceiverWrapper;->this$0:Ltas/internal/ipc/SenderManager;

    iget-object v1, p0, Ltas/internal/ipc/SenderManager$ReceiverWrapper;->sender:Ltas/internal/ipc/server/RemoteSender;

    invoke-static {v0, v1, p0}, Ltas/internal/ipc/SenderManager;->-wrap4(Ltas/internal/ipc/SenderManager;Ltas/internal/ipc/server/RemoteSender;Ltas/internal/ipc/SenderManager$ReceiverWrapper;)V

    goto :goto_0
.end method

.method disconnect()V
    .locals 2

    .prologue
    .line 606
    iget-object v0, p0, Ltas/internal/ipc/SenderManager$ReceiverWrapper;->connection:Ltas/internal/ipc/SenderManager$ReceiverConnectionWrapper;

    if-eqz v0, :cond_0

    .line 607
    iget-object v0, p0, Ltas/internal/ipc/SenderManager$ReceiverWrapper;->connection:Ltas/internal/ipc/SenderManager$ReceiverConnectionWrapper;

    invoke-virtual {v0}, Ltas/internal/ipc/SenderManager$ReceiverConnectionWrapper;->disconnect()V

    .line 605
    :goto_0
    return-void

    .line 609
    :cond_0
    iget-object v0, p0, Ltas/internal/ipc/SenderManager$ReceiverWrapper;->this$0:Ltas/internal/ipc/SenderManager;

    iget-object v1, p0, Ltas/internal/ipc/SenderManager$ReceiverWrapper;->sender:Ltas/internal/ipc/server/RemoteSender;

    invoke-static {v0, v1, p0}, Ltas/internal/ipc/SenderManager;->-wrap6(Ltas/internal/ipc/SenderManager;Ltas/internal/ipc/server/RemoteSender;Ltas/internal/ipc/SenderManager$ReceiverWrapper;)V

    goto :goto_0
.end method

.method send(Ltas/ipc/MsgData;)V
    .locals 2
    .param p1, "msg"    # Ltas/ipc/MsgData;

    .prologue
    .line 589
    iget-object v1, p0, Ltas/internal/ipc/SenderManager$ReceiverWrapper;->sender:Ltas/internal/ipc/server/RemoteSender;

    invoke-static {v1, p0, p1}, Ltas/internal/ipc/server/RemoteMessage;->obtain(Ltas/internal/ipc/server/RemoteSender;Ltas/internal/ipc/server/RemoteReceiver;Ltas/ipc/MsgData;)Ltas/internal/ipc/server/RemoteMessage;

    move-result-object v0

    .line 590
    .local v0, "rmsg":Ltas/internal/ipc/server/RemoteMessage;
    iget-object v1, p0, Ltas/internal/ipc/SenderManager$ReceiverWrapper;->connection:Ltas/internal/ipc/SenderManager$ReceiverConnectionWrapper;

    if-eqz v1, :cond_0

    .line 591
    iget-object v1, p0, Ltas/internal/ipc/SenderManager$ReceiverWrapper;->connection:Ltas/internal/ipc/SenderManager$ReceiverConnectionWrapper;

    invoke-virtual {v1, v0}, Ltas/internal/ipc/SenderManager$ReceiverConnectionWrapper;->transmit(Ltas/internal/ipc/server/RemoteMessage;)V

    .line 583
    :goto_0
    return-void

    .line 593
    :cond_0
    iget-object v1, p0, Ltas/internal/ipc/SenderManager$ReceiverWrapper;->this$0:Ltas/internal/ipc/SenderManager;

    invoke-static {v1, v0}, Ltas/internal/ipc/SenderManager;->-wrap8(Ltas/internal/ipc/SenderManager;Ltas/internal/ipc/server/RemoteMessage;)V

    goto :goto_0
.end method
