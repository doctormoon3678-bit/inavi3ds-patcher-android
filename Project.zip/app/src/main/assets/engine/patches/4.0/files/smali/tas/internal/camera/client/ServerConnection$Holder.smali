.class public Ltas/internal/camera/client/ServerConnection$Holder;
.super Ljava/lang/Object;
.source "ServerConnection.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltas/internal/camera/client/ServerConnection;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "Holder"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ltas/internal/camera/client/ServerConnection$Holder$1;
    }
.end annotation


# static fields
.field private static final CALLBACK:Ltas/internal/ipc/util/SyncdPool$Callback;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ltas/internal/ipc/util/SyncdPool$Callback",
            "<",
            "Ltas/internal/camera/client/ServerConnection$Holder;",
            ">;"
        }
    .end annotation
.end field

.field private static final sPool:Ltas/internal/ipc/util/SyncdPool;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ltas/internal/ipc/util/SyncdPool",
            "<",
            "Ltas/internal/camera/client/ServerConnection$Holder;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field public final cmd:Ltas/camera/CameraCommand;

.field private mAllocated:Z

.field public final msg:Ltas/camera/CameraMessage;

.field private next:Ltas/internal/camera/client/ServerConnection$Holder;

.field public proxy:Ltas/internal/camera/client/CameraProxy;


# direct methods
.method static synthetic -get0(Ltas/internal/camera/client/ServerConnection$Holder;)Ltas/internal/camera/client/ServerConnection$Holder;
    .locals 1

    iget-object v0, p0, Ltas/internal/camera/client/ServerConnection$Holder;->next:Ltas/internal/camera/client/ServerConnection$Holder;

    return-object v0
.end method

.method static synthetic -set0(Ltas/internal/camera/client/ServerConnection$Holder;Ltas/internal/camera/client/ServerConnection$Holder;)Ltas/internal/camera/client/ServerConnection$Holder;
    .locals 0

    iput-object p1, p0, Ltas/internal/camera/client/ServerConnection$Holder;->next:Ltas/internal/camera/client/ServerConnection$Holder;

    return-object p1
.end method

.method static constructor <clinit>()V
    .locals 2

    .prologue
    .line 468
    new-instance v0, Ltas/internal/camera/client/ServerConnection$Holder$1;

    invoke-direct {v0}, Ltas/internal/camera/client/ServerConnection$Holder$1;-><init>()V

    .line 467
    sput-object v0, Ltas/internal/camera/client/ServerConnection$Holder;->CALLBACK:Ltas/internal/ipc/util/SyncdPool$Callback;

    .line 483
    new-instance v0, Ltas/internal/ipc/util/SyncdPool;

    sget-object v1, Ltas/internal/camera/client/ServerConnection$Holder;->CALLBACK:Ltas/internal/ipc/util/SyncdPool$Callback;

    invoke-direct {v0, v1}, Ltas/internal/ipc/util/SyncdPool;-><init>(Ltas/internal/ipc/util/SyncdPool$Callback;)V

    .line 482
    sput-object v0, Ltas/internal/camera/client/ServerConnection$Holder;->sPool:Ltas/internal/ipc/util/SyncdPool;

    .line 416
    return-void
.end method

.method private constructor <init>()V
    .locals 1

    .prologue
    .line 465
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 419
    new-instance v0, Ltas/camera/CameraCommand;

    invoke-direct {v0}, Ltas/camera/CameraCommand;-><init>()V

    iput-object v0, p0, Ltas/internal/camera/client/ServerConnection$Holder;->cmd:Ltas/camera/CameraCommand;

    .line 420
    iget-object v0, p0, Ltas/internal/camera/client/ServerConnection$Holder;->cmd:Ltas/camera/CameraCommand;

    iput-object v0, p0, Ltas/internal/camera/client/ServerConnection$Holder;->msg:Ltas/camera/CameraMessage;

    .line 465
    return-void
.end method

.method synthetic constructor <init>(Ltas/internal/camera/client/ServerConnection$Holder;)V
    .locals 0

    .prologue
    invoke-direct {p0}, Ltas/internal/camera/client/ServerConnection$Holder;-><init>()V

    return-void
.end method

.method public static obtain()Ltas/internal/camera/client/ServerConnection$Holder;
    .locals 2

    .prologue
    .line 452
    sget-object v1, Ltas/internal/camera/client/ServerConnection$Holder;->sPool:Ltas/internal/ipc/util/SyncdPool;

    invoke-virtual {v1}, Ltas/internal/ipc/util/SyncdPool;->allocate()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/camera/client/ServerConnection$Holder;

    .line 453
    .local v0, "h":Ltas/internal/camera/client/ServerConnection$Holder;
    const/4 v1, 0x1

    iput-boolean v1, v0, Ltas/internal/camera/client/ServerConnection$Holder;->mAllocated:Z

    .line 454
    return-object v0
.end method

.method public static obtain(Ltas/internal/camera/client/CameraProxy;)Ltas/internal/camera/client/ServerConnection$Holder;
    .locals 1
    .param p0, "p"    # Ltas/internal/camera/client/CameraProxy;

    .prologue
    .line 428
    invoke-static {}, Ltas/internal/camera/client/ServerConnection$Holder;->obtain()Ltas/internal/camera/client/ServerConnection$Holder;

    move-result-object v0

    .line 429
    .local v0, "h":Ltas/internal/camera/client/ServerConnection$Holder;
    iput-object p0, v0, Ltas/internal/camera/client/ServerConnection$Holder;->proxy:Ltas/internal/camera/client/CameraProxy;

    .line 430
    return-object v0
.end method

.method public static obtain(Ltas/internal/camera/client/CameraProxy;Ltas/camera/CameraCommand;)Ltas/internal/camera/client/ServerConnection$Holder;
    .locals 2
    .param p0, "p"    # Ltas/internal/camera/client/CameraProxy;
    .param p1, "m"    # Ltas/camera/CameraCommand;

    .prologue
    .line 443
    invoke-static {}, Ltas/internal/camera/client/ServerConnection$Holder;->obtain()Ltas/internal/camera/client/ServerConnection$Holder;

    move-result-object v0

    .line 444
    .local v0, "h":Ltas/internal/camera/client/ServerConnection$Holder;
    iput-object p0, v0, Ltas/internal/camera/client/ServerConnection$Holder;->proxy:Ltas/internal/camera/client/CameraProxy;

    .line 445
    if-eqz p1, :cond_0

    .line 446
    iget-object v1, v0, Ltas/internal/camera/client/ServerConnection$Holder;->cmd:Ltas/camera/CameraCommand;

    invoke-virtual {v1, p1}, Ltas/camera/CameraCommand;->copy(Ltas/camera/CameraMessage;)V

    .line 448
    :cond_0
    return-object v0
.end method

.method public static obtain(Ltas/internal/camera/client/CameraProxy;Ltas/camera/CameraMessage;)Ltas/internal/camera/client/ServerConnection$Holder;
    .locals 2
    .param p0, "p"    # Ltas/internal/camera/client/CameraProxy;
    .param p1, "m"    # Ltas/camera/CameraMessage;

    .prologue
    .line 434
    invoke-static {}, Ltas/internal/camera/client/ServerConnection$Holder;->obtain()Ltas/internal/camera/client/ServerConnection$Holder;

    move-result-object v0

    .line 435
    .local v0, "h":Ltas/internal/camera/client/ServerConnection$Holder;
    iput-object p0, v0, Ltas/internal/camera/client/ServerConnection$Holder;->proxy:Ltas/internal/camera/client/CameraProxy;

    .line 436
    if-eqz p1, :cond_0

    .line 437
    iget-object v1, v0, Ltas/internal/camera/client/ServerConnection$Holder;->msg:Ltas/camera/CameraMessage;

    invoke-virtual {v1, p1}, Ltas/camera/CameraMessage;->copy(Ltas/camera/CameraMessage;)V

    .line 439
    :cond_0
    return-object v0
.end method


# virtual methods
.method public clear()V
    .locals 1

    .prologue
    .line 423
    const/4 v0, 0x0

    iput-object v0, p0, Ltas/internal/camera/client/ServerConnection$Holder;->proxy:Ltas/internal/camera/client/CameraProxy;

    .line 424
    iget-object v0, p0, Ltas/internal/camera/client/ServerConnection$Holder;->msg:Ltas/camera/CameraMessage;

    invoke-virtual {v0}, Ltas/camera/CameraMessage;->clear()V

    .line 422
    return-void
.end method

.method public recycle()V
    .locals 1

    .prologue
    .line 458
    iget-boolean v0, p0, Ltas/internal/camera/client/ServerConnection$Holder;->mAllocated:Z

    if-eqz v0, :cond_0

    .line 459
    const/4 v0, 0x0

    iput-boolean v0, p0, Ltas/internal/camera/client/ServerConnection$Holder;->mAllocated:Z

    .line 460
    invoke-virtual {p0}, Ltas/internal/camera/client/ServerConnection$Holder;->clear()V

    .line 461
    sget-object v0, Ltas/internal/camera/client/ServerConnection$Holder;->sPool:Ltas/internal/ipc/util/SyncdPool;

    invoke-virtual {v0, p0}, Ltas/internal/ipc/util/SyncdPool;->recycle(Ljava/lang/Object;)V

    .line 457
    :cond_0
    return-void
.end method
