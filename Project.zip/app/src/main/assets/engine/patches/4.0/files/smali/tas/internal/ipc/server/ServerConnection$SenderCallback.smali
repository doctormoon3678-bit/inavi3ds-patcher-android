.class public interface abstract Ltas/internal/ipc/server/ServerConnection$SenderCallback;
.super Ljava/lang/Object;
.source "ServerConnection.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltas/internal/ipc/server/ServerConnection;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "SenderCallback"
.end annotation


# virtual methods
.method public abstract onReceiverOffline(Ltas/internal/ipc/server/RemoteSender;Ltas/internal/ipc/server/RemoteReceiver;)V
.end method

.method public abstract onReceiverOnline(Ltas/internal/ipc/server/RemoteSender;Ltas/internal/ipc/server/RemoteReceiver;)V
.end method

.method public abstract onReceiverUpdate(Ltas/internal/ipc/server/RemoteSender;Ltas/internal/ipc/server/RemoteReceiver;)V
.end method
