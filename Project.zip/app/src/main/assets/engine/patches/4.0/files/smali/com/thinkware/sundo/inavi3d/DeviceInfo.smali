.class public Lcom/thinkware/sundo/inavi3d/DeviceInfo;
.super Ljava/lang/Object;
.source "DeviceInfo.java"


# static fields
.field public static final A3D_MODEL_OTHERS:I = 0xa

.field public static final A3D_MODEL_TW_CAMARO:I = 0xb

.field public static final A3D_MODEL_TW_CAMARO_FL:I = 0xc

.field public static final A3D_MODEL_TW_CUBE2:I = 0x4

.field public static final A3D_MODEL_TW_CUBE_FL:I = 0x8

.field public static final A3D_MODEL_TW_CUBE_LITE:I = 0x7

.field public static final A3D_MODEL_TW_DAVINCI:I = 0xa

.field public static final A3D_MODEL_TW_DIXIE:I = 0x1

.field public static final A3D_MODEL_TW_DIXON:I = 0x0

.field public static final A3D_MODEL_TW_LEO:I = 0x3

.field public static final A3D_MODEL_TW_MOWGLI:I = 0x9

.field public static final A3D_MODEL_TW_MX:I = 0x6

.field public static final A3D_MODEL_TW_RUNA:I = 0x5

.field public static final A3D_MODEL_TW_TAURUS:I = 0x2

.field public static final COUNT_OF_DEVICE:I = 0xa

.field private static final instance:Lcom/thinkware/sundo/inavi3d/DeviceInfo;

.field static phone_type:I


# instance fields
.field private final DRGPSMODE:Ljava/lang/String;

.field private final INNERGPSMODE:Ljava/lang/String;

.field final SOUND_TEMP_PATH:Ljava/lang/String;

.field public is_inner_storage:Z

.field public kEndingNaviWave:Ljava/lang/String;

.field public kInaviData:Ljava/lang/String;

.field public kInaviResPath:Ljava/lang/String;

.field public kLastBluetoothFile:Ljava/lang/String;

.field public kLogDriveFile:Ljava/lang/String;

.field public kMapdataPath:Ljava/lang/String;

.field public kStartNaviWave:Ljava/lang/String;

.field public kStorageRoot:Ljava/lang/String;

.field public kTpeg_data_path:Ljava/lang/String;

.field private m_IsCustomSetting:Z

.field private m_IsDAVINCIOrder:Z

.field private m_IsMoreKitKat:Z

.field private m_IsSetTop:Z

.field private m_IsSupportSystemUIService:Z

.field private m_Support_Deivce:Z

.field private m_deviceOEM:Ljava/lang/String;

.field private m_deviceUUID:Ljava/lang/String;

.field private m_device_model:I

.field private m_installred_Trip:Z

.field private m_supportAINA:Z

.field private m_supportDualRoute:Z

.field private m_supportEXPSearch:Z

.field private m_supportRSearch:Z

.field private m_supportRecommendedWord:Z

.field private m_support_BUGS:Z

.field private m_support_DMB:Z

.field private m_support_ExternaGPS:Z

.field private m_support_ExternaGPS_PowerOn:Z

.field private m_support_Manager:Z

.field private m_support_Remote:Z

.field private m_support_TBT:Z

.field private m_support_TPEG:Z

.field private m_support_air_mode:Z

.field private m_support_drivex_NIP:Z

.field private m_support_scale:Z

.field private m_support_scaletype:I

.field private m_support_supercap_poweroff:Z

.field private m_support_widedisplay:I

.field private m_use_drgps:Z


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .prologue
    .line 30
    const/4 v0, 0x0

    sput v0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->phone_type:I

    .line 210
    new-instance v0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    invoke-direct {v0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;-><init>()V

    sput-object v0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->instance:Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    return-void
.end method

.method private constructor <init>()V
    .locals 3

    .prologue
    const/4 v2, -0x1

    const/4 v0, 0x0

    const/4 v1, 0x0

    .line 21
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 33
    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->kStorageRoot:Ljava/lang/String;

    .line 34
    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->kMapdataPath:Ljava/lang/String;

    .line 35
    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->kInaviData:Ljava/lang/String;

    .line 36
    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->kInaviResPath:Ljava/lang/String;

    .line 37
    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->kTpeg_data_path:Ljava/lang/String;

    .line 38
    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->kStartNaviWave:Ljava/lang/String;

    .line 39
    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->kEndingNaviWave:Ljava/lang/String;

    .line 40
    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->kLastBluetoothFile:Ljava/lang/String;

    .line 41
    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->kLogDriveFile:Ljava/lang/String;

    .line 42
    const-string v0, "/TWRamdisk"

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->SOUND_TEMP_PATH:Ljava/lang/String;

    .line 44
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->is_inner_storage:Z

    .line 184
    const/16 v0, 0xd

    iput v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    .line 185
    const-string v0, ""

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_deviceOEM:Ljava/lang/String;

    .line 186
    const-string v0, ""

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_deviceUUID:Ljava/lang/String;

    .line 188
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_scale:Z

    .line 189
    iput v2, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_scaletype:I

    .line 190
    iput v2, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_widedisplay:I

    .line 192
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_Support_Deivce:Z

    .line 194
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_DMB:Z

    .line 195
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_TBT:Z

    .line 196
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_TPEG:Z

    .line 197
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_Remote:Z

    .line 199
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_ExternaGPS:Z

    .line 200
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_ExternaGPS_PowerOn:Z

    .line 201
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_Manager:Z

    .line 202
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_installred_Trip:Z

    .line 204
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportRSearch:Z

    .line 205
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportEXPSearch:Z

    .line 206
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportRecommendedWord:Z

    .line 208
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportDualRoute:Z

    .line 212
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_use_drgps:Z

    .line 213
    const-string v0, "0"

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->INNERGPSMODE:Ljava/lang/String;

    .line 214
    const-string v0, "1"

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->DRGPSMODE:Ljava/lang/String;

    .line 216
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportAINA:Z

    .line 218
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_air_mode:Z

    .line 222
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_supercap_poweroff:Z

    .line 225
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_drivex_NIP:Z

    .line 227
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_BUGS:Z

    .line 229
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_IsMoreKitKat:Z

    .line 230
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_IsSupportSystemUIService:Z

    .line 231
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_IsDAVINCIOrder:Z

    .line 232
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_IsSetTop:Z

    .line 233
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_IsCustomSetting:Z

    .line 22
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->Initialize()V

    .line 23
    return-void
.end method

.method public static GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;
    .locals 1

    .prologue
    .line 123
    sget-object v0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->instance:Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    return-object v0
.end method

.method private _InitDeviceAttribute()I
    .locals 9

    .prologue
    const/4 v8, 0x0

    const/4 v7, 0x1

    .line 243
    const-string v3, ""

    .line 245
    .local v3, "line":Ljava/lang/String;
    :try_start_0
    invoke-static {}, Ljava/lang/Runtime;->getRuntime()Ljava/lang/Runtime;

    move-result-object v4

    const-string v5, "getprop ro.product.devicecode"

    invoke-virtual {v4, v5}, Ljava/lang/Runtime;->exec(Ljava/lang/String;)Ljava/lang/Process;

    move-result-object v2

    .line 246
    .local v2, "ifc":Ljava/lang/Process;
    new-instance v0, Ljava/io/BufferedReader;

    new-instance v4, Ljava/io/InputStreamReader;

    invoke-virtual {v2}, Ljava/lang/Process;->getInputStream()Ljava/io/InputStream;

    move-result-object v5

    invoke-direct {v4, v5}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;)V

    invoke-direct {v0, v4}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V

    .line 247
    .local v0, "bis":Ljava/io/BufferedReader;
    invoke-virtual {v0}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    move-result-object v3

    .line 248
    iput-object v3, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_deviceOEM:Ljava/lang/String;

    .line 249
    invoke-virtual {v2}, Ljava/lang/Process;->destroy()V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_3

    .line 255
    .end local v0    # "bis":Ljava/io/BufferedReader;
    .end local v2    # "ifc":Ljava/lang/Process;
    :goto_0
    :try_start_1
    const-class v4, Landroid/os/Build;

    const-string v5, "SERIAL"

    invoke-virtual {v4, v5}, Ljava/lang/Class;->getField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v4

    const/4 v5, 0x0

    invoke-virtual {v4, v5}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    iput-object v4, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_deviceUUID:Ljava/lang/String;
    :try_end_1
    .catch Ljava/lang/IllegalAccessException; {:try_start_1 .. :try_end_1} :catch_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_1 .. :try_end_1} :catch_1
    .catch Ljava/lang/NoSuchFieldException; {:try_start_1 .. :try_end_1} :catch_2

    .line 267
    :goto_1
    const-string v4, "DeviceInfo"

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "_InitDeviceAttribute :: m_deviceOEM :: "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    iget-object v6, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_deviceOEM:Ljava/lang/String;

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-static {v4, v5}, Lcom/thinkware/sundo/inavi3d/LOGTW;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 270
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_deviceOEM:Ljava/lang/String;

    const-string v5, "D7A"

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_0

    .line 272
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_Support_Deivce:Z

    .line 273
    iput v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    .line 274
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_DMB:Z

    .line 275
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_TBT:Z

    .line 276
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_TPEG:Z

    .line 277
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_Remote:Z

    .line 278
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_ExternaGPS:Z

    .line 279
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_ExternaGPS_PowerOn:Z

    .line 280
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_Manager:Z

    .line 281
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportRSearch:Z

    .line 282
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportEXPSearch:Z

    .line 283
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportRecommendedWord:Z

    .line 284
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportAINA:Z

    .line 285
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_scale:Z

    .line 286
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_air_mode:Z

    .line 289
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_supercap_poweroff:Z

    .line 292
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_IsMoreKitKat:Z

    .line 293
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_IsSupportSystemUIService:Z

    .line 678
    :goto_2
    iget v4, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    return v4

    .line 256
    :catch_0
    move-exception v1

    .line 258
    .local v1, "e":Ljava/lang/IllegalAccessException;
    invoke-virtual {v1}, Ljava/lang/IllegalAccessException;->printStackTrace()V

    goto :goto_1

    .line 259
    .end local v1    # "e":Ljava/lang/IllegalAccessException;
    :catch_1
    move-exception v1

    .line 261
    .local v1, "e":Ljava/lang/IllegalArgumentException;
    invoke-virtual {v1}, Ljava/lang/IllegalArgumentException;->printStackTrace()V

    goto :goto_1

    .line 262
    .end local v1    # "e":Ljava/lang/IllegalArgumentException;
    :catch_2
    move-exception v1

    .line 264
    .local v1, "e":Ljava/lang/NoSuchFieldException;
    invoke-virtual {v1}, Ljava/lang/NoSuchFieldException;->printStackTrace()V

    goto :goto_1

    .line 295
    .end local v1    # "e":Ljava/lang/NoSuchFieldException;
    :cond_0
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_deviceOEM:Ljava/lang/String;

    const-string v5, "D9A"

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_1

    .line 297
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_Support_Deivce:Z

    .line 298
    iput v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    .line 299
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_DMB:Z

    .line 300
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_TBT:Z

    .line 301
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_TPEG:Z

    .line 302
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_Remote:Z

    .line 303
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_ExternaGPS:Z

    .line 304
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_ExternaGPS_PowerOn:Z

    .line 305
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_Manager:Z

    .line 306
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportRSearch:Z

    .line 307
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportEXPSearch:Z

    .line 308
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportRecommendedWord:Z

    .line 309
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportAINA:Z

    .line 310
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_scale:Z

    .line 311
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->SetUseDRConfig()Z

    .line 312
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_air_mode:Z

    .line 315
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_supercap_poweroff:Z

    .line 318
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_IsMoreKitKat:Z

    .line 319
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_IsSupportSystemUIService:Z

    goto :goto_2

    .line 322
    :cond_1
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_deviceOEM:Ljava/lang/String;

    const-string v5, "TAU"

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_2

    .line 324
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_Support_Deivce:Z

    .line 325
    const/4 v4, 0x2

    iput v4, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    .line 326
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_DMB:Z

    .line 327
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_TBT:Z

    .line 328
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_TPEG:Z

    .line 329
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_Remote:Z

    .line 330
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_ExternaGPS:Z

    .line 331
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_ExternaGPS_PowerOn:Z

    .line 332
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_Manager:Z

    .line 333
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportRSearch:Z

    .line 334
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportEXPSearch:Z

    .line 335
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportRecommendedWord:Z

    .line 336
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportDualRoute:Z

    .line 337
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportAINA:Z

    .line 338
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_scale:Z

    .line 339
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->SetUseDRConfig()Z

    .line 340
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_air_mode:Z

    .line 343
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_supercap_poweroff:Z

    .line 354
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_IsMoreKitKat:Z

    .line 355
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_IsSupportSystemUIService:Z

    goto :goto_2

    .line 358
    :cond_2
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_deviceOEM:Ljava/lang/String;

    const-string v5, "LEO"

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_3

    .line 360
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_Support_Deivce:Z

    .line 361
    const/4 v4, 0x3

    iput v4, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    .line 362
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_DMB:Z

    .line 363
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_TBT:Z

    .line 364
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_TPEG:Z

    .line 365
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_Remote:Z

    .line 366
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_ExternaGPS:Z

    .line 367
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_ExternaGPS_PowerOn:Z

    .line 368
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_Manager:Z

    .line 369
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportRSearch:Z

    .line 370
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportEXPSearch:Z

    .line 371
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportRecommendedWord:Z

    .line 372
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportDualRoute:Z

    .line 373
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportAINA:Z

    .line 374
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_scale:Z

    .line 375
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->SetUseDRConfig()Z

    .line 376
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_air_mode:Z

    .line 379
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_supercap_poweroff:Z

    .line 386
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_IsMoreKitKat:Z

    .line 387
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_IsSupportSystemUIService:Z

    goto/16 :goto_2

    .line 389
    :cond_3
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_deviceOEM:Ljava/lang/String;

    const-string v5, "CU2"

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_4

    .line 391
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_Support_Deivce:Z

    .line 392
    const/4 v4, 0x4

    iput v4, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    .line 393
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_DMB:Z

    .line 394
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_TBT:Z

    .line 395
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_TPEG:Z

    .line 396
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_Remote:Z

    .line 397
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_ExternaGPS:Z

    .line 398
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_ExternaGPS_PowerOn:Z

    .line 399
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_Manager:Z

    .line 400
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportRSearch:Z

    .line 401
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportEXPSearch:Z

    .line 402
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportRecommendedWord:Z

    .line 403
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportDualRoute:Z

    .line 404
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportAINA:Z

    .line 405
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_scale:Z

    .line 406
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_air_mode:Z

    .line 409
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_supercap_poweroff:Z

    .line 412
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_IsMoreKitKat:Z

    .line 413
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_IsSupportSystemUIService:Z

    .line 415
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_IsSetTop:Z

    goto/16 :goto_2

    .line 417
    :cond_4
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_deviceOEM:Ljava/lang/String;

    const-string v5, "RNA"

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_5

    .line 419
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_Support_Deivce:Z

    .line 420
    const/4 v4, 0x5

    iput v4, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    .line 421
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_DMB:Z

    .line 422
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_TBT:Z

    .line 423
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_TPEG:Z

    .line 424
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_Remote:Z

    .line 425
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_ExternaGPS:Z

    .line 426
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_ExternaGPS_PowerOn:Z

    .line 427
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_Manager:Z

    .line 428
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportRSearch:Z

    .line 429
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportEXPSearch:Z

    .line 430
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportRecommendedWord:Z

    .line 431
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportDualRoute:Z

    .line 432
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportAINA:Z

    .line 433
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_scale:Z

    .line 434
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_air_mode:Z

    .line 437
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_supercap_poweroff:Z

    .line 440
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_IsMoreKitKat:Z

    .line 441
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_IsSupportSystemUIService:Z

    goto/16 :goto_2

    .line 443
    :cond_5
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_deviceOEM:Ljava/lang/String;

    const-string v5, "MXB"

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_6

    .line 445
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_Support_Deivce:Z

    .line 446
    const/4 v4, 0x6

    iput v4, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    .line 447
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_DMB:Z

    .line 448
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_TBT:Z

    .line 449
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_TPEG:Z

    .line 450
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_Remote:Z

    .line 451
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_ExternaGPS:Z

    .line 452
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_ExternaGPS_PowerOn:Z

    .line 453
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_Manager:Z

    .line 454
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportRSearch:Z

    .line 455
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportEXPSearch:Z

    .line 456
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportRecommendedWord:Z

    .line 457
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportDualRoute:Z

    .line 458
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportAINA:Z

    .line 459
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_scale:Z

    .line 460
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_air_mode:Z

    .line 463
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_supercap_poweroff:Z

    .line 466
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_IsMoreKitKat:Z

    .line 467
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_IsSupportSystemUIService:Z

    goto/16 :goto_2

    .line 469
    :cond_6
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_deviceOEM:Ljava/lang/String;

    const-string v5, "CUL"

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_7

    .line 471
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_Support_Deivce:Z

    .line 472
    const/4 v4, 0x7

    iput v4, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    .line 473
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_DMB:Z

    .line 474
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_TBT:Z

    .line 475
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_TPEG:Z

    .line 476
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_Remote:Z

    .line 477
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_ExternaGPS:Z

    .line 478
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_ExternaGPS_PowerOn:Z

    .line 479
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_Manager:Z

    .line 480
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportRSearch:Z

    .line 481
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportEXPSearch:Z

    .line 482
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportRecommendedWord:Z

    .line 483
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportDualRoute:Z

    .line 484
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportAINA:Z

    .line 485
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_scale:Z

    .line 486
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_air_mode:Z

    .line 489
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_supercap_poweroff:Z

    .line 492
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_IsMoreKitKat:Z

    .line 493
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_IsSupportSystemUIService:Z

    .line 495
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_IsSetTop:Z

    goto/16 :goto_2

    .line 497
    :cond_7
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_deviceOEM:Ljava/lang/String;

    const-string v5, "CUF"

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_8

    .line 499
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_Support_Deivce:Z

    .line 500
    const/16 v4, 0x8

    iput v4, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    .line 501
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_DMB:Z

    .line 502
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_TBT:Z

    .line 503
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_TPEG:Z

    .line 504
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_Remote:Z

    .line 505
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_ExternaGPS:Z

    .line 506
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_ExternaGPS_PowerOn:Z

    .line 507
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_Manager:Z

    .line 508
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportRSearch:Z

    .line 509
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportEXPSearch:Z

    .line 510
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportRecommendedWord:Z

    .line 511
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportDualRoute:Z

    .line 512
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportAINA:Z

    .line 513
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_scale:Z

    .line 514
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_air_mode:Z

    .line 517
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_supercap_poweroff:Z

    .line 520
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_IsMoreKitKat:Z

    .line 521
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_IsSupportSystemUIService:Z

    .line 523
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_IsSetTop:Z

    goto/16 :goto_2

    .line 525
    :cond_8
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_deviceOEM:Ljava/lang/String;

    const-string v5, "MOW"

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_9

    .line 527
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_Support_Deivce:Z

    .line 528
    const/16 v4, 0x9

    iput v4, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    .line 529
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_DMB:Z

    .line 530
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_TBT:Z

    .line 531
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_TPEG:Z

    .line 532
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_Remote:Z

    .line 533
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_ExternaGPS:Z

    .line 534
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_ExternaGPS_PowerOn:Z

    .line 535
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_Manager:Z

    .line 536
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportRSearch:Z

    .line 537
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportEXPSearch:Z

    .line 538
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportRecommendedWord:Z

    .line 539
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportDualRoute:Z

    .line 540
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportAINA:Z

    .line 541
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_scale:Z

    .line 542
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_air_mode:Z

    .line 545
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_supercap_poweroff:Z

    .line 548
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_IsMoreKitKat:Z

    .line 549
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_IsSupportSystemUIService:Z

    goto/16 :goto_2

    .line 551
    :cond_9
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_deviceOEM:Ljava/lang/String;

    const-string v5, "DAV"

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_a

    .line 553
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_Support_Deivce:Z

    .line 554
    const/16 v4, 0xa

    iput v4, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    .line 555
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_DMB:Z

    .line 556
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_TBT:Z

    .line 557
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_TPEG:Z

    .line 558
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_Remote:Z

    .line 559
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_ExternaGPS:Z

    .line 560
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_ExternaGPS_PowerOn:Z

    .line 561
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_Manager:Z

    .line 562
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportRSearch:Z

    .line 563
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportEXPSearch:Z

    .line 564
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportRecommendedWord:Z

    .line 565
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportDualRoute:Z

    .line 566
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportAINA:Z

    .line 567
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_scale:Z

    .line 568
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->SetUseDRConfig()Z

    .line 569
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_air_mode:Z

    .line 572
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_supercap_poweroff:Z

    .line 578
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_IsMoreKitKat:Z

    .line 579
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_IsSupportSystemUIService:Z

    .line 581
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_drivex_NIP:Z

    .line 582
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_IsDAVINCIOrder:Z

    .line 583
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_IsSetTop:Z

    .line 584
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_IsCustomSetting:Z

    goto/16 :goto_2

    .line 587
    :cond_a
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_deviceOEM:Ljava/lang/String;

    const-string v5, "CAM"

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_b

    .line 589
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_Support_Deivce:Z

    .line 590
    const/16 v4, 0xb

    iput v4, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    .line 591
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_DMB:Z

    .line 592
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_TBT:Z

    .line 593
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_TPEG:Z

    .line 594
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_Remote:Z

    .line 595
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_ExternaGPS:Z

    .line 596
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_ExternaGPS_PowerOn:Z

    .line 597
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_Manager:Z

    .line 598
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportRSearch:Z

    .line 599
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportEXPSearch:Z

    .line 600
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportRecommendedWord:Z

    .line 601
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportDualRoute:Z

    .line 602
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportAINA:Z

    .line 603
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_scale:Z

    .line 604
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->SetUseDRConfig()Z

    .line 605
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_air_mode:Z

    .line 608
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_supercap_poweroff:Z

    .line 611
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_IsMoreKitKat:Z

    .line 612
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_IsSupportSystemUIService:Z

    .line 618
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_drivex_NIP:Z

    .line 619
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_IsDAVINCIOrder:Z

    .line 620
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_IsSetTop:Z

    .line 621
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_IsCustomSetting:Z

    goto/16 :goto_2

    .line 624
    :cond_b
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_deviceOEM:Ljava/lang/String;

    const-string v5, "CAF"

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_c

    .line 626
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_Support_Deivce:Z

    .line 627
    const/16 v4, 0xc

    iput v4, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    .line 628
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_DMB:Z

    .line 629
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_TBT:Z

    .line 630
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_TPEG:Z

    .line 631
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_Remote:Z

    .line 632
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_ExternaGPS:Z

    .line 633
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_ExternaGPS_PowerOn:Z

    .line 634
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_Manager:Z

    .line 635
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportRSearch:Z

    .line 636
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportEXPSearch:Z

    .line 637
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportRecommendedWord:Z

    .line 638
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportDualRoute:Z

    .line 639
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportAINA:Z

    .line 640
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_scale:Z

    .line 641
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->SetUseDRConfig()Z

    .line 642
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_air_mode:Z

    .line 645
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_supercap_poweroff:Z

    .line 648
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_IsMoreKitKat:Z

    .line 649
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_IsSupportSystemUIService:Z

    .line 655
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_drivex_NIP:Z

    .line 656
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_IsDAVINCIOrder:Z

    .line 657
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_IsSetTop:Z

    .line 658
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_IsCustomSetting:Z

    goto/16 :goto_2

    .line 663
    :cond_c
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_Support_Deivce:Z

    .line 664
    const/16 v4, 0xd

    iput v4, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    .line 665
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_DMB:Z

    .line 666
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_TBT:Z

    .line 667
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_TPEG:Z

    .line 668
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_Remote:Z

    .line 670
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_ExternaGPS:Z

    .line 671
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_ExternaGPS_PowerOn:Z

    .line 672
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_Manager:Z

    .line 673
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportAINA:Z

    goto/16 :goto_2

    .line 250
    :catch_3
    move-exception v4

    goto/16 :goto_0
.end method

.method private _InitStoragePath()I
    .locals 15

    .prologue
    const/16 v9, 0xc9

    const/4 v14, 0x1

    const/4 v10, 0x0

    .line 53
    sget-object v1, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->SD_EXT_STORAGE_PATH:Ljava/lang/String;

    .line 54
    .local v1, "SD_EXT_STORAGE_PATH":Ljava/lang/String;
    const/4 v11, 0x3

    new-array v3, v11, [Ljava/lang/String;

    const-string v11, "inavi3d"

    aput-object v11, v3, v10

    const-string v11, "sd/inavi3d"

    aput-object v11, v3, v14

    const/4 v11, 0x2

    const-string v12, "external_sd/inavi3d"

    aput-object v12, v3, v11

    .line 55
    .local v3, "Storage_Candidate":[Ljava/lang/String;
    const-string v0, "mapdata/mrdata"

    .line 57
    .local v0, "CheckDirectory":Ljava/lang/String;
    const/4 v7, 0x0

    .local v7, "i":I
    :goto_0
    array-length v11, v3

    if-ge v7, v11, :cond_0

    .line 58
    new-instance v11, Ljava/io/File;

    new-instance v12, Ljava/lang/StringBuilder;

    invoke-direct {v12}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v12, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    const-string v13, "/"

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    aget-object v13, v3, v7

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    const-string v13, "/"

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    const-string v13, "mapdata/mrdata"

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    invoke-virtual {v12}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v12

    invoke-direct {v11, v12}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    invoke-virtual {v11}, Ljava/io/File;->isDirectory()Z

    move-result v11

    if-eqz v11, :cond_1

    .line 59
    new-instance v11, Ljava/lang/StringBuilder;

    invoke-direct {v11}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v11, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    const-string v12, "/"

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    aget-object v12, v3, v7

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v11

    iput-object v11, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->kStorageRoot:Ljava/lang/String;

    .line 70
    :cond_0
    :goto_1
    iget-object v11, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->kStorageRoot:Ljava/lang/String;

    if-nez v11, :cond_4

    .line 71
    const-string v11, "inavi3d_java"

    const-string v12, "kStorageRoot: (null)"

    invoke-static {v11, v12}, Lcom/thinkware/sundo/inavi3d/LOGTW;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 74
    :goto_2
    iget-object v11, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->kStorageRoot:Ljava/lang/String;

    if-nez v11, :cond_5

    .line 119
    :goto_3
    return v9

    .line 61
    :cond_1
    new-instance v11, Ljava/io/File;

    new-instance v12, Ljava/lang/StringBuilder;

    invoke-direct {v12}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v12, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    const-string v13, "2/"

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    aget-object v13, v3, v7

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    const-string v13, "/"

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    const-string v13, "mapdata/mrdata"

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    invoke-virtual {v12}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v12

    invoke-direct {v11, v12}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    invoke-virtual {v11}, Ljava/io/File;->isDirectory()Z

    move-result v11

    if-eqz v11, :cond_2

    .line 62
    new-instance v11, Ljava/lang/StringBuilder;

    invoke-direct {v11}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v11, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    const-string v12, "2/"

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    aget-object v12, v3, v7

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v11

    iput-object v11, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->kStorageRoot:Ljava/lang/String;

    goto :goto_1

    .line 64
    :cond_2
    new-instance v11, Ljava/io/File;

    const-string v12, "extSdCard/inavi3d/mapdata/mrdata"

    invoke-direct {v11, v12}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    invoke-virtual {v11}, Ljava/io/File;->isDirectory()Z

    move-result v11

    if-eqz v11, :cond_3

    .line 65
    const-string v11, "extSdCard/inavi3d"

    iput-object v11, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->kStorageRoot:Ljava/lang/String;

    goto :goto_1

    .line 57
    :cond_3
    add-int/lit8 v7, v7, 0x1

    goto/16 :goto_0

    .line 73
    :cond_4
    const-string v11, "inavi3d_java"

    new-instance v12, Ljava/lang/StringBuilder;

    invoke-direct {v12}, Ljava/lang/StringBuilder;-><init>()V

    const-string v13, "kStorageRoot: "

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    iget-object v13, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->kStorageRoot:Ljava/lang/String;

    invoke-virtual {v13}, Ljava/lang/String;->toString()Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    invoke-virtual {v12}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v12

    invoke-static {v11, v12}, Lcom/thinkware/sundo/inavi3d/LOGTW;->d(Ljava/lang/String;Ljava/lang/String;)V

    goto/16 :goto_2

    .line 78
    :cond_5
    iput-boolean v10, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->is_inner_storage:Z

    .line 79
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->IsThinkwareDevice()Z

    move-result v11

    if-nez v11, :cond_6

    .line 80
    iget-object v11, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->kStorageRoot:Ljava/lang/String;

    new-instance v12, Ljava/lang/StringBuilder;

    invoke-direct {v12}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v12, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    const-string v13, "/inavi3d"

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    invoke-virtual {v12}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v11, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v11

    if-eqz v11, :cond_6

    .line 81
    iput-boolean v14, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->is_inner_storage:Z

    .line 84
    :cond_6
    const-string v11, "inavi3d_java"

    new-instance v12, Ljava/lang/StringBuilder;

    invoke-direct {v12}, Ljava/lang/StringBuilder;-><init>()V

    const-string v13, "is_inner_storage: "

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    iget-boolean v13, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->is_inner_storage:Z

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v12

    invoke-virtual {v12}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v12

    invoke-static {v11, v12}, Lcom/thinkware/sundo/inavi3d/LOGTW;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 87
    new-instance v11, Ljava/lang/StringBuilder;

    invoke-direct {v11}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v12, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->kStorageRoot:Ljava/lang/String;

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    const-string v12, "/mapdata"

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v11

    iput-object v11, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->kMapdataPath:Ljava/lang/String;

    .line 88
    new-instance v11, Ljava/lang/StringBuilder;

    invoke-direct {v11}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v12, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->kStorageRoot:Ljava/lang/String;

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    const-string v12, "/iNaviData"

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v11

    iput-object v11, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->kInaviData:Ljava/lang/String;

    .line 89
    new-instance v11, Ljava/lang/StringBuilder;

    invoke-direct {v11}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v12, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->kStorageRoot:Ljava/lang/String;

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    const-string v12, "/res"

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v11

    iput-object v11, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->kInaviResPath:Ljava/lang/String;

    .line 90
    new-instance v5, Ljava/io/File;

    iget-object v11, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->kInaviData:Ljava/lang/String;

    invoke-direct {v5, v11}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 91
    .local v5, "file":Ljava/io/File;
    invoke-virtual {v5}, Ljava/io/File;->isDirectory()Z

    move-result v11

    if-nez v11, :cond_7

    .line 92
    invoke-virtual {v5}, Ljava/io/File;->mkdir()Z

    .line 94
    :cond_7
    new-instance v11, Ljava/lang/StringBuilder;

    invoke-direct {v11}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v12, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->kStorageRoot:Ljava/lang/String;

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    const-string v12, "/"

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    const-string v12, "temp"

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v11

    iput-object v11, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->kTpeg_data_path:Ljava/lang/String;

    .line 95
    new-instance v6, Ljava/io/File;

    iget-object v11, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->kTpeg_data_path:Ljava/lang/String;

    invoke-direct {v6, v11}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 96
    .local v6, "file_tpeg_auto":Ljava/io/File;
    new-instance v11, Ljava/io/File;

    iget-object v12, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->kTpeg_data_path:Ljava/lang/String;

    invoke-direct {v11, v12}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    invoke-virtual {v11}, Ljava/io/File;->isDirectory()Z

    move-result v11

    if-nez v11, :cond_8

    .line 97
    invoke-virtual {v6}, Ljava/io/File;->mkdir()Z

    .line 99
    :cond_8
    new-instance v11, Ljava/lang/StringBuilder;

    invoke-direct {v11}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v12, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->kMapdataPath:Ljava/lang/String;

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    const-string v12, "/wave/msgsound/startnavi.wav"

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v11

    iput-object v11, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->kStartNaviWave:Ljava/lang/String;

    .line 100
    new-instance v11, Ljava/lang/StringBuilder;

    invoke-direct {v11}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v12, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->kMapdataPath:Ljava/lang/String;

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    const-string v12, "/wave/msgsound/endnavi.wav"

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v11

    iput-object v11, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->kEndingNaviWave:Ljava/lang/String;

    .line 103
    :try_start_0
    new-instance v8, Ljava/io/FileInputStream;

    iget-object v11, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->kStartNaviWave:Ljava/lang/String;

    invoke-direct {v8, v11}, Ljava/io/FileInputStream;-><init>(Ljava/lang/String;)V

    .line 104
    .local v8, "istr":Ljava/io/FileInputStream;
    invoke-virtual {v8}, Ljava/io/FileInputStream;->close()V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    .line 110
    new-instance v2, Ljava/io/File;

    const-string v9, "/TWRamdisk"

    invoke-direct {v2, v9}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 111
    .local v2, "SoundDirectory":Ljava/io/File;
    invoke-virtual {v2}, Ljava/io/File;->isDirectory()Z

    move-result v9

    if-nez v9, :cond_9

    .line 112
    invoke-virtual {v2}, Ljava/io/File;->mkdir()Z

    .line 115
    :cond_9
    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v11, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->kInaviData:Ljava/lang/String;

    invoke-virtual {v9, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    const-string v11, "/bsarddr.bin"

    invoke-virtual {v9, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    iput-object v9, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->kLastBluetoothFile:Ljava/lang/String;

    .line 117
    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v11, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->kInaviData:Ljava/lang/String;

    invoke-virtual {v9, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    const-string v11, "/GPSOnly.txt"

    invoke-virtual {v9, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    iput-object v9, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->kLogDriveFile:Ljava/lang/String;

    move v9, v10

    .line 119
    goto/16 :goto_3

    .line 105
    .end local v2    # "SoundDirectory":Ljava/io/File;
    .end local v8    # "istr":Ljava/io/FileInputStream;
    :catch_0
    move-exception v4

    .line 106
    .local v4, "e":Ljava/io/IOException;
    invoke-virtual {v4}, Ljava/io/IOException;->printStackTrace()V

    goto/16 :goto_3
.end method


# virtual methods
.method public GetDeviceModelType()I
    .locals 1

    .prologue
    .line 135
    iget v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    return v0
.end method

.method public GetDeviceOEM()Ljava/lang/String;
    .locals 1

    .prologue
    .line 126
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_deviceOEM:Ljava/lang/String;

    return-object v0
.end method

.method public GetDeviceUUID()Ljava/lang/String;
    .locals 1

    .prologue
    .line 129
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_deviceUUID:Ljava/lang/String;

    return-object v0
.end method

.method public GetUseDRConfig()Z
    .locals 1

    .prologue
    .line 735
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_use_drgps:Z

    return v0
.end method

.method public InitStoragePath()I
    .locals 1

    .prologue
    .line 47
    invoke-direct {p0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->_InitStoragePath()I

    move-result v0

    return v0
.end method

.method public Initialize()V
    .locals 0

    .prologue
    .line 26
    invoke-direct {p0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->_InitDeviceAttribute()I

    .line 28
    return-void
.end method

.method public IsCustomSetting()Z
    .locals 1

    .prologue
    .line 881
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_IsCustomSetting:Z

    return v0
.end method

.method public IsDAVINCICUBE()Z
    .locals 2

    .prologue
    const/4 v0, 0x1

    .line 875
    iget-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_IsDAVINCIOrder:Z

    if-ne v1, v0, :cond_0

    iget-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_IsSetTop:Z

    if-ne v1, v0, :cond_0

    .line 878
    :goto_0
    return v0

    :cond_0
    const/4 v0, 0x0

    goto :goto_0
.end method

.method public IsDAVINCIOrder()Z
    .locals 1

    .prologue
    .line 872
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_IsDAVINCIOrder:Z

    return v0
.end method

.method public IsIntalledTripApp()Z
    .locals 1

    .prologue
    .line 773
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_installred_Trip:Z

    return v0
.end method

.method public IsMoreKitKat()Z
    .locals 2

    .prologue
    const/4 v0, 0x1

    .line 779
    iget-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_IsMoreKitKat:Z

    if-ne v1, v0, :cond_0

    .line 782
    :goto_0
    return v0

    :cond_0
    const/4 v0, 0x0

    goto :goto_0
.end method

.method public IsThinkwareDevice()Z
    .locals 1

    .prologue
    .line 769
    const/4 v0, 0x1

    return v0
.end method

.method public SetUseDRConfig()Z
    .locals 8

    .prologue
    const/4 v4, 0x1

    const/4 v5, 0x0

    .line 713
    const-string v3, ""

    .line 715
    .local v3, "line":Ljava/lang/String;
    :try_start_0
    invoke-static {}, Ljava/lang/Runtime;->getRuntime()Ljava/lang/Runtime;

    move-result-object v6

    const-string v7, "getprop persist.sys.drgps"

    invoke-virtual {v6, v7}, Ljava/lang/Runtime;->exec(Ljava/lang/String;)Ljava/lang/Process;

    move-result-object v2

    .line 716
    .local v2, "ifc":Ljava/lang/Process;
    new-instance v0, Ljava/io/BufferedReader;

    new-instance v6, Ljava/io/InputStreamReader;

    invoke-virtual {v2}, Ljava/lang/Process;->getInputStream()Ljava/io/InputStream;

    move-result-object v7

    invoke-direct {v6, v7}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;)V

    invoke-direct {v0, v6}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V

    .line 717
    .local v0, "bis":Ljava/io/BufferedReader;
    invoke-virtual {v0}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    move-result-object v3

    .line 718
    invoke-virtual {v2}, Ljava/lang/Process;->destroy()V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    .line 722
    const-string v6, ""

    invoke-virtual {v3, v6}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v6

    if-eqz v6, :cond_0

    const-string v3, "0"

    .line 724
    :cond_0
    const-string v6, "1"

    invoke-virtual {v3, v6}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v6

    if-eqz v6, :cond_1

    .line 725
    iput-boolean v4, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_use_drgps:Z

    .line 730
    .end local v0    # "bis":Ljava/io/BufferedReader;
    .end local v2    # "ifc":Ljava/lang/Process;
    :goto_0
    return v4

    .line 719
    :catch_0
    move-exception v1

    .local v1, "e":Ljava/io/IOException;
    move v4, v5

    .line 720
    goto :goto_0

    .line 727
    .end local v1    # "e":Ljava/io/IOException;
    .restart local v0    # "bis":Ljava/io/BufferedReader;
    .restart local v2    # "ifc":Ljava/lang/Process;
    :cond_1
    iput-boolean v5, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_use_drgps:Z

    goto :goto_0
.end method

.method public checkTrip(Landroid/content/Context;)V
    .locals 6
    .param p1, "context"    # Landroid/content/Context;

    .prologue
    .line 808
    if-eqz p1, :cond_2

    .line 809
    const/4 v0, 0x0

    .line 810
    .local v0, "bHasTrip":Z
    invoke-virtual {p1}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v4

    const/16 v5, 0x2000

    invoke-virtual {v4, v5}, Landroid/content/pm/PackageManager;->getInstalledApplications(I)Ljava/util/List;

    move-result-object v3

    .line 811
    .local v3, "pkgList":Ljava/util/List;, "Ljava/util/List<Landroid/content/pm/ApplicationInfo;>;"
    invoke-interface {v3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    .local v1, "i$":Ljava/util/Iterator;
    :cond_0
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_1

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/content/pm/ApplicationInfo;

    .line 812
    .local v2, "info":Landroid/content/pm/ApplicationInfo;
    iget-object v4, v2, Landroid/content/pm/ApplicationInfo;->packageName:Ljava/lang/String;

    const-string v5, "com.thinkware.trip.main"

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_0

    .line 813
    const/4 v0, 0x1

    goto :goto_0

    .line 816
    .end local v2    # "info":Landroid/content/pm/ApplicationInfo;
    :cond_1
    iput-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_installred_Trip:Z

    .line 818
    .end local v0    # "bHasTrip":Z
    .end local v1    # "i$":Ljava/util/Iterator;
    .end local v3    # "pkgList":Ljava/util/List;, "Ljava/util/List<Landroid/content/pm/ApplicationInfo;>;"
    :cond_2
    return-void
.end method

.method public getScaleType()I
    .locals 2

    .prologue
    .line 838
    iget v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_scaletype:I

    const/4 v1, -0x1

    if-ne v0, v1, :cond_0

    .line 839
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INaviScaleManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INaviScaleManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/INaviScaleManager;->getScaleType()I

    move-result v0

    iput v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_scaletype:I

    .line 842
    :cond_0
    iget v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_scaletype:I

    return v0
.end method

.method public initializeCUBE2()V
    .locals 3

    .prologue
    const/4 v2, 0x0

    const/4 v1, 0x1

    .line 682
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INaviScaleManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INaviScaleManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/INaviScaleManager;->getScaleType()I

    move-result v0

    iput v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_scaletype:I

    .line 684
    iget v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_scaletype:I

    if-lez v0, :cond_0

    .line 685
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_Support_Deivce:Z

    .line 686
    const/4 v0, 0x5

    iput v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    .line 687
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_DMB:Z

    .line 688
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_TBT:Z

    .line 689
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_TPEG:Z

    .line 690
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_Remote:Z

    .line 691
    iput-boolean v2, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_ExternaGPS:Z

    .line 692
    iput-boolean v2, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_ExternaGPS_PowerOn:Z

    .line 693
    iput-boolean v2, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_Manager:Z

    .line 694
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportRSearch:Z

    .line 695
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportEXPSearch:Z

    .line 696
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportRecommendedWord:Z

    .line 697
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportDualRoute:Z

    .line 698
    iput-boolean v2, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportAINA:Z

    .line 699
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_scale:Z

    .line 700
    iput-boolean v2, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_air_mode:Z

    .line 703
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_supercap_poweroff:Z

    .line 709
    :cond_0
    return-void
.end method

.method public isNoSupportAR()Z
    .locals 2

    .prologue
    .line 859
    iget v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    const/4 v1, 0x7

    if-eq v0, v1, :cond_0

    iget v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    const/16 v1, 0x9

    if-ne v0, v1, :cond_1

    .line 860
    :cond_0
    const/4 v0, 0x1

    .line 861
    :goto_0
    return v0

    :cond_1
    const/4 v0, 0x0

    goto :goto_0
.end method

.method public isSupportAirMode()Z
    .locals 1

    .prologue
    .line 825
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_air_mode:Z

    return v0
.end method

.method public isSupportSuperCapPowerOff()Z
    .locals 1

    .prologue
    .line 855
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_supercap_poweroff:Z

    return v0
.end method

.method public isSupport_BUGS()Z
    .locals 1

    .prologue
    .line 869
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_BUGS:Z

    return v0
.end method

.method public isSupport_DriveX_NIP()Z
    .locals 1

    .prologue
    .line 865
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_drivex_NIP:Z

    return v0
.end method

.method public isWideDisplay()Z
    .locals 4

    .prologue
    const/4 v2, 0x0

    const/4 v1, 0x1

    .line 846
    iget v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_widedisplay:I

    const/4 v3, -0x1

    if-ne v0, v3, :cond_0

    .line 847
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INaviScaleManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INaviScaleManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/INaviScaleManager;->getWideDisplay()Z

    move-result v0

    if-eqz v0, :cond_1

    move v0, v1

    :goto_0
    iput v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_widedisplay:I

    .line 849
    :cond_0
    iget v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_widedisplay:I

    if-ne v0, v1, :cond_2

    :goto_1
    return v1

    :cond_1
    move v0, v2

    .line 847
    goto :goto_0

    :cond_2
    move v1, v2

    .line 849
    goto :goto_1
.end method

.method public isYtnDevice()Z
    .locals 2

    .prologue
    .line 886
    iget v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    const/16 v1, 0xa

    if-eq v0, v1, :cond_0

    iget v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    const/16 v1, 0xb

    if-eq v0, v1, :cond_0

    iget v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    const/16 v1, 0xc

    if-eq v0, v1, :cond_0

    iget v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    const/16 v1, 0xd

    if-ne v0, v1, :cond_1

    .line 890
    :cond_0
    const/4 v0, 0x1

    .line 892
    :goto_0
    return v0

    :cond_1
    const/4 v0, 0x0

    goto :goto_0
.end method

.method public is_SupportDevice()Z
    .locals 1

    .prologue
    .line 132
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_Support_Deivce:Z

    return v0
.end method

.method public is_support_DMB()Z
    .locals 1

    .prologue
    .line 139
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_DMB:Z

    return v0
.end method

.method public is_support_ExternaGPS()Z
    .locals 1

    .prologue
    .line 155
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_ExternaGPS:Z

    return v0
.end method

.method public is_support_ExternaGPS_PowerOn()Z
    .locals 1

    .prologue
    .line 159
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_ExternaGPS_PowerOn:Z

    return v0
.end method

.method public is_support_Manager()Z
    .locals 1

    .prologue
    .line 163
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_Manager:Z

    return v0
.end method

.method public is_support_Remote()Z
    .locals 1

    .prologue
    .line 151
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_Remote:Z

    return v0
.end method

.method public is_support_SystemUIService()Z
    .locals 2

    .prologue
    const/4 v0, 0x1

    .line 785
    iget-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_IsSupportSystemUIService:Z

    if-ne v1, v0, :cond_0

    .line 788
    :goto_0
    return v0

    :cond_0
    const/4 v0, 0x0

    goto :goto_0
.end method

.method public is_support_TBT()Z
    .locals 1

    .prologue
    .line 143
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_TBT:Z

    return v0
.end method

.method public is_support_TPEG()Z
    .locals 1

    .prologue
    .line 147
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_TPEG:Z

    return v0
.end method

.method public is_support_builtin_statusbar()Z
    .locals 1

    .prologue
    .line 834
    const/4 v0, 0x0

    return v0
.end method

.method public is_support_scale()Z
    .locals 1

    .prologue
    .line 830
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_scale:Z

    return v0
.end method

.method public supportAINA()Z
    .locals 1

    .prologue
    .line 821
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportAINA:Z

    return v0
.end method

.method public supportDualRoute()Z
    .locals 1

    .prologue
    .line 804
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportDualRoute:Z

    return v0
.end method

.method public supportEXPSearch()Z
    .locals 1

    .prologue
    .line 796
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportEXPSearch:Z

    return v0
.end method

.method public supportRSearch()Z
    .locals 1

    .prologue
    .line 791
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportRSearch:Z

    return v0
.end method

.method public supportRecommendedWord()Z
    .locals 1

    .prologue
    .line 801
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportRecommendedWord:Z

    return v0
.end method
