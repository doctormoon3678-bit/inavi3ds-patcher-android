.class public Ltas/camera/id/Rear;
.super Ltas/camera/CameraId;
.source "Rear.java"


# instance fields
.field private final proxy:Ltas/internal/camera/client/CameraProxy;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ltas/internal/camera/client/CameraProxy",
            "<",
            "Ltas/camera/id/Rear;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 1
    .param p1, "context"    # Landroid/content/Context;

    .prologue
    .line 20
    invoke-direct {p0}, Ltas/camera/CameraId;-><init>()V

    .line 21
    new-instance v0, Ltas/internal/camera/client/CameraProxy;

    invoke-direct {v0, p1, p0}, Ltas/internal/camera/client/CameraProxy;-><init>(Landroid/content/Context;Ltas/camera/CameraId;)V

    iput-object v0, p0, Ltas/camera/id/Rear;->proxy:Ltas/internal/camera/client/CameraProxy;

    .line 20
    return-void
.end method


# virtual methods
.method protected proxy()Ltas/internal/camera/client/CameraProxy;
    .locals 1

    .prologue
    .line 25
    iget-object v0, p0, Ltas/camera/id/Rear;->proxy:Ltas/internal/camera/client/CameraProxy;

    return-object v0
.end method

.method public setListener(Ltas/camera/BaseListener;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ltas/camera/BaseListener",
            "<",
            "Ltas/camera/id/Rear;",
            ">;)V"
        }
    .end annotation

    .prologue
    .line 29
    .local p1, "l":Ltas/camera/BaseListener;, "Ltas/camera/BaseListener<Ltas/camera/id/Rear;>;"
    iget-object v0, p0, Ltas/camera/id/Rear;->proxy:Ltas/internal/camera/client/CameraProxy;

    invoke-virtual {v0, p1}, Ltas/internal/camera/client/CameraProxy;->setListener(Ltas/camera/BaseListener;)V

    .line 28
    return-void
.end method
