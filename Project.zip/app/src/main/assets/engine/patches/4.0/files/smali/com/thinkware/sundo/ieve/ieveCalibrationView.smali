.class public Lcom/thinkware/sundo/ieve/ieveCalibrationView;
.super Landroid/view/View;
.source "ieveCalibrationView.java"


# static fields
.field private static final a:Ljava/lang/String;


# instance fields
.field private b:Landroid/content/Context;

.field private c:Landroid/graphics/Paint;

.field private d:Lcom/thinkware/sundo/ieve/IEVE;

.field private e:Lcom/thinkware/sundo/ieve/ieveCameraView;

.field private f:Landroid/graphics/Rect;

.field private g:Landroid/graphics/Point;

.field private h:Landroid/graphics/Point;

.field private i:Landroid/graphics/PointF;

.field private j:Landroid/graphics/PointF;

.field private k:Landroid/graphics/PointF;

.field private l:Landroid/graphics/PointF;

.field private m:Landroid/graphics/PointF;

.field private n:Landroid/graphics/Rect;

.field private o:Landroid/graphics/Rect;

.field private p:Landroid/graphics/Rect;

.field private q:Landroid/graphics/Rect;

.field private r:Z

.field private s:Landroid/graphics/Bitmap;

.field private t:Landroid/graphics/Bitmap;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .prologue
    .line 22
    const-class v0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;

    invoke-virtual {v0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->a:Ljava/lang/String;

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/graphics/Rect;Lcom/thinkware/sundo/ieve/ieveCameraView;Lcom/thinkware/sundo/ieve/IEVE;)V
    .locals 8
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "sizeview"    # Landroid/graphics/Rect;
    .param p3, "viewcamera"    # Lcom/thinkware/sundo/ieve/ieveCameraView;
    .param p4, "ieve"    # Lcom/thinkware/sundo/ieve/IEVE;

    .prologue
    const/16 v4, 0x78

    const/4 v7, 0x0

    const/high16 v6, 0x3f800000    # 1.0f

    const/4 v2, 0x0

    const/4 v5, 0x0

    .line 52
    invoke-direct {p0, p1}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    .line 23
    iput-object v2, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->b:Landroid/content/Context;

    .line 24
    iput-object v2, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->c:Landroid/graphics/Paint;

    .line 26
    iput-object v2, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->d:Lcom/thinkware/sundo/ieve/IEVE;

    .line 27
    iput-object v2, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->e:Lcom/thinkware/sundo/ieve/ieveCameraView;

    .line 30
    iput-object v2, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->f:Landroid/graphics/Rect;

    .line 31
    iput-object v2, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->g:Landroid/graphics/Point;

    .line 32
    iput-object v2, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->h:Landroid/graphics/Point;

    .line 33
    iput-object v2, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->i:Landroid/graphics/PointF;

    .line 34
    iput-object v2, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->j:Landroid/graphics/PointF;

    .line 35
    iput-object v2, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->k:Landroid/graphics/PointF;

    .line 36
    iput-object v2, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->l:Landroid/graphics/PointF;

    .line 37
    iput-object v2, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->m:Landroid/graphics/PointF;

    .line 40
    iput-object v2, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->n:Landroid/graphics/Rect;

    .line 41
    iput-object v2, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->o:Landroid/graphics/Rect;

    .line 42
    iput-object v2, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->p:Landroid/graphics/Rect;

    .line 43
    iput-object v2, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->q:Landroid/graphics/Rect;

    .line 46
    iput-boolean v5, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->r:Z

    .line 47
    iput-object v2, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->s:Landroid/graphics/Bitmap;

    .line 48
    iput-object v2, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->t:Landroid/graphics/Bitmap;

    .line 53
    sget-object v2, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->a:Ljava/lang/String;

    const-string v3, "Constructor"

    invoke-static {v2, v3}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 54
    iput-object p1, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->b:Landroid/content/Context;

    .line 55
    new-instance v2, Landroid/graphics/Paint;

    const/4 v3, 0x1

    invoke-direct {v2, v3}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v2, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->c:Landroid/graphics/Paint;

    .line 56
    iput-object p4, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->d:Lcom/thinkware/sundo/ieve/IEVE;

    .line 57
    iput-object p3, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->e:Lcom/thinkware/sundo/ieve/ieveCameraView;

    .line 58
    new-instance v2, Landroid/graphics/Rect;

    invoke-direct {v2, p2}, Landroid/graphics/Rect;-><init>(Landroid/graphics/Rect;)V

    iput-object v2, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->f:Landroid/graphics/Rect;

    .line 60
    iget-object v2, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->b:Landroid/content/Context;

    if-nez v2, :cond_0

    .line 61
    const-string v2, "Context is null!"

    new-array v3, v5, [Ljava/lang/Object;

    invoke-static {v2, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    .line 62
    .local v1, "text":Ljava/lang/String;
    sget-object v2, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->a:Ljava/lang/String;

    invoke-static {v2, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 104
    .end local v1    # "text":Ljava/lang/String;
    :goto_0
    return-void

    .line 65
    :cond_0
    iget-object v2, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->d:Lcom/thinkware/sundo/ieve/IEVE;

    if-nez v2, :cond_1

    .line 66
    const-string v2, "IEVE is null!"

    new-array v3, v5, [Ljava/lang/Object;

    invoke-static {v2, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    .line 67
    .restart local v1    # "text":Ljava/lang/String;
    sget-object v2, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->a:Ljava/lang/String;

    invoke-static {v2, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    .line 70
    .end local v1    # "text":Ljava/lang/String;
    :cond_1
    iget-object v2, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->d:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-virtual {v2}, Lcom/thinkware/sundo/ieve/IEVE;->isInitialized()Z

    move-result v2

    if-nez v2, :cond_2

    .line 71
    const-string v2, "IEVE is not initialized!"

    new-array v3, v5, [Ljava/lang/Object;

    invoke-static {v2, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    .line 72
    .restart local v1    # "text":Ljava/lang/String;
    sget-object v2, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->a:Ljava/lang/String;

    invoke-static {v2, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 73
    iget-object v2, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->d:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-virtual {v2}, Lcom/thinkware/sundo/ieve/IEVE;->getHandlerIeve()Landroid/os/Handler;

    move-result-object v2

    iget-object v3, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->d:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-virtual {v3}, Lcom/thinkware/sundo/ieve/IEVE;->getHandlerIeve()Landroid/os/Handler;

    move-result-object v3

    const/16 v4, 0x4af

    invoke-static {v3, v4, v1}, Landroid/os/Message;->obtain(Landroid/os/Handler;ILjava/lang/Object;)Landroid/os/Message;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto :goto_0

    .line 76
    .end local v1    # "text":Ljava/lang/String;
    :cond_2
    if-nez p3, :cond_3

    .line 77
    const-string v2, "Camera view is null!"

    new-array v3, v5, [Ljava/lang/Object;

    invoke-static {v2, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    .line 78
    .restart local v1    # "text":Ljava/lang/String;
    sget-object v2, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->a:Ljava/lang/String;

    invoke-static {v2, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 79
    iget-object v2, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->d:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-virtual {v2}, Lcom/thinkware/sundo/ieve/IEVE;->getHandlerIeve()Landroid/os/Handler;

    move-result-object v2

    iget-object v3, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->d:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-virtual {v3}, Lcom/thinkware/sundo/ieve/IEVE;->getHandlerIeve()Landroid/os/Handler;

    move-result-object v3

    const/16 v4, 0x4af

    invoke-static {v3, v4, v1}, Landroid/os/Message;->obtain(Landroid/os/Handler;ILjava/lang/Object;)Landroid/os/Message;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto :goto_0

    .line 83
    .end local v1    # "text":Ljava/lang/String;
    :cond_3
    invoke-virtual {p0}, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    invoke-virtual {v2}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v0

    .line 84
    .local v0, "dm":Landroid/util/DisplayMetrics;
    iput v6, v0, Landroid/util/DisplayMetrics;->density:F

    .line 85
    invoke-static {v5, v7, v0}, Landroid/util/TypedValue;->applyDimension(IFLandroid/util/DisplayMetrics;)F

    .line 86
    invoke-static {v5, v7, v0}, Landroid/util/TypedValue;->applyDimension(IFLandroid/util/DisplayMetrics;)F

    .line 88
    new-instance v2, Landroid/graphics/Point;

    const/16 v3, 0xa0

    invoke-direct {v2, v3, v4}, Landroid/graphics/Point;-><init>(II)V

    iput-object v2, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->g:Landroid/graphics/Point;

    .line 89
    new-instance v2, Landroid/graphics/Point;

    const/16 v3, 0xa0

    invoke-direct {v2, v3, v4}, Landroid/graphics/Point;-><init>(II)V

    iput-object v2, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->h:Landroid/graphics/Point;

    .line 90
    new-instance v2, Landroid/graphics/PointF;

    const/high16 v3, 0x43200000    # 160.0f

    const/high16 v4, 0x42f00000    # 120.0f

    invoke-direct {v2, v3, v4}, Landroid/graphics/PointF;-><init>(FF)V

    iput-object v2, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->i:Landroid/graphics/PointF;

    .line 91
    new-instance v2, Landroid/graphics/PointF;

    invoke-direct {v2, v7, v7}, Landroid/graphics/PointF;-><init>(FF)V

    iput-object v2, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->j:Landroid/graphics/PointF;

    .line 92
    new-instance v2, Landroid/graphics/PointF;

    invoke-direct {v2, v6, v6}, Landroid/graphics/PointF;-><init>(FF)V

    iput-object v2, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->k:Landroid/graphics/PointF;

    .line 93
    new-instance v2, Landroid/graphics/PointF;

    invoke-direct {v2, v6, v6}, Landroid/graphics/PointF;-><init>(FF)V

    iput-object v2, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->l:Landroid/graphics/PointF;

    .line 94
    new-instance v2, Landroid/graphics/PointF;

    invoke-direct {v2, v6, v6}, Landroid/graphics/PointF;-><init>(FF)V

    iput-object v2, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->m:Landroid/graphics/PointF;

    .line 96
    new-instance v2, Landroid/graphics/Rect;

    invoke-direct {v2, v5, v5, v5, v5}, Landroid/graphics/Rect;-><init>(IIII)V

    iput-object v2, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->n:Landroid/graphics/Rect;

    .line 97
    new-instance v2, Landroid/graphics/Rect;

    invoke-direct {v2, v5, v5, v5, v5}, Landroid/graphics/Rect;-><init>(IIII)V

    iput-object v2, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->o:Landroid/graphics/Rect;

    .line 98
    new-instance v2, Landroid/graphics/Rect;

    invoke-direct {v2, v5, v5, v5, v5}, Landroid/graphics/Rect;-><init>(IIII)V

    iput-object v2, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->p:Landroid/graphics/Rect;

    .line 99
    new-instance v2, Landroid/graphics/Rect;

    invoke-direct {v2, v5, v5, v5, v5}, Landroid/graphics/Rect;-><init>(IIII)V

    iput-object v2, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->q:Landroid/graphics/Rect;

    .line 101
    invoke-direct {p0}, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->a()V

    .line 102
    invoke-virtual {p0}, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->updateRoiPoints()V

    .line 103
    invoke-virtual {p0}, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->postInvalidate()V

    goto/16 :goto_0
.end method

.method private a()V
    .locals 8

    .prologue
    const/4 v7, 0x0

    .line 114
    sget-object v4, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->a:Ljava/lang/String;

    const-string v5, "loadBitmaps"

    invoke-static {v4, v5}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 116
    const/4 v3, 0x0

    .line 118
    .local v3, "resid_centerline":I
    :try_start_0
    const-string v0, ""

    .line 119
    .local v0, "context_packname":Ljava/lang/String;
    iget-object v4, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->b:Landroid/content/Context;

    invoke-virtual {v4}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v0

    .line 120
    iget-object v4, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->b:Landroid/content/Context;

    invoke-virtual {v4}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v4

    invoke-virtual {v4, v0}, Landroid/content/pm/PackageManager;->getResourcesForApplication(Ljava/lang/String;)Landroid/content/res/Resources;

    move-result-object v2

    .line 121
    .local v2, "res":Landroid/content/res/Resources;
    const-string v4, "ieve_center_line"

    const-string v5, "drawable"

    invoke-virtual {v2, v4, v5, v0}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I
    :try_end_0
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    move-result v3

    .line 128
    .end local v0    # "context_packname":Ljava/lang/String;
    .end local v2    # "res":Landroid/content/res/Resources;
    :goto_0
    if-eqz v3, :cond_0

    .line 129
    invoke-virtual {p0}, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->getResources()Landroid/content/res/Resources;

    move-result-object v4

    invoke-static {v4, v3}, Landroid/graphics/BitmapFactory;->decodeResource(Landroid/content/res/Resources;I)Landroid/graphics/Bitmap;

    move-result-object v4

    iput-object v4, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->t:Landroid/graphics/Bitmap;

    .line 130
    iget-object v4, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->p:Landroid/graphics/Rect;

    iget-object v5, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->t:Landroid/graphics/Bitmap;

    invoke-virtual {v5}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v5

    iget-object v6, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->t:Landroid/graphics/Bitmap;

    invoke-virtual {v6}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v6

    invoke-virtual {v4, v7, v7, v5, v6}, Landroid/graphics/Rect;->set(IIII)V

    .line 133
    :cond_0
    iget-object v4, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->l:Landroid/graphics/PointF;

    iget-object v5, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->f:Landroid/graphics/Rect;

    invoke-virtual {v5}, Landroid/graphics/Rect;->width()I

    move-result v5

    int-to-float v5, v5

    iget-object v6, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->d:Lcom/thinkware/sundo/ieve/IEVE;

    iget v6, v6, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_IMAGESIZE_VGA_WIDTH:I

    int-to-float v6, v6

    div-float/2addr v5, v6

    iput v5, v4, Landroid/graphics/PointF;->x:F

    .line 134
    iget-object v4, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->l:Landroid/graphics/PointF;

    iget-object v5, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->f:Landroid/graphics/Rect;

    invoke-virtual {v5}, Landroid/graphics/Rect;->height()I

    move-result v5

    int-to-float v5, v5

    iget-object v6, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->d:Lcom/thinkware/sundo/ieve/IEVE;

    iget v6, v6, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_IMAGESIZE_VGA_HEIGHT:I

    int-to-float v6, v6

    div-float/2addr v5, v6

    iput v5, v4, Landroid/graphics/PointF;->y:F

    .line 135
    iget-object v4, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->k:Landroid/graphics/PointF;

    iget-object v5, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->f:Landroid/graphics/Rect;

    invoke-virtual {v5}, Landroid/graphics/Rect;->width()I

    move-result v5

    int-to-float v5, v5

    iget-object v6, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->e:Lcom/thinkware/sundo/ieve/ieveCameraView;

    invoke-virtual {v6}, Lcom/thinkware/sundo/ieve/ieveCameraView;->getPreviewWidth()I

    move-result v6

    int-to-float v6, v6

    div-float/2addr v5, v6

    iput v5, v4, Landroid/graphics/PointF;->x:F

    .line 136
    iget-object v4, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->k:Landroid/graphics/PointF;

    iget-object v5, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->f:Landroid/graphics/Rect;

    invoke-virtual {v5}, Landroid/graphics/Rect;->height()I

    move-result v5

    int-to-float v5, v5

    iget-object v6, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->e:Lcom/thinkware/sundo/ieve/ieveCameraView;

    invoke-virtual {v6}, Lcom/thinkware/sundo/ieve/ieveCameraView;->getPreviewHeight()I

    move-result v6

    int-to-float v6, v6

    div-float/2addr v5, v6

    iput v5, v4, Landroid/graphics/PointF;->y:F

    .line 137
    iget-object v4, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->m:Landroid/graphics/PointF;

    iget-object v5, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->f:Landroid/graphics/Rect;

    invoke-virtual {v5}, Landroid/graphics/Rect;->width()I

    move-result v5

    int-to-float v5, v5

    iget-object v6, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->d:Lcom/thinkware/sundo/ieve/IEVE;

    iget v6, v6, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_IMAGESIZE_INFO_WIDTH:I

    int-to-float v6, v6

    div-float/2addr v5, v6

    iput v5, v4, Landroid/graphics/PointF;->x:F

    .line 138
    iget-object v4, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->m:Landroid/graphics/PointF;

    iget-object v5, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->f:Landroid/graphics/Rect;

    invoke-virtual {v5}, Landroid/graphics/Rect;->height()I

    move-result v5

    int-to-float v5, v5

    iget-object v6, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->d:Lcom/thinkware/sundo/ieve/IEVE;

    iget v6, v6, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_IMAGESIZE_INFO_HEIGHT:I

    int-to-float v6, v6

    div-float/2addr v5, v6

    iput v5, v4, Landroid/graphics/PointF;->y:F

    .line 140
    iget-object v4, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->n:Landroid/graphics/Rect;

    iput v7, v4, Landroid/graphics/Rect;->left:I

    .line 141
    iget-object v4, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->n:Landroid/graphics/Rect;

    iput v7, v4, Landroid/graphics/Rect;->top:I

    .line 142
    iget-object v4, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->n:Landroid/graphics/Rect;

    iget-object v5, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->e:Lcom/thinkware/sundo/ieve/ieveCameraView;

    invoke-virtual {v5}, Lcom/thinkware/sundo/ieve/ieveCameraView;->getPreviewWidth()I

    move-result v5

    iput v5, v4, Landroid/graphics/Rect;->right:I

    .line 143
    iget-object v4, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->n:Landroid/graphics/Rect;

    iget-object v5, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->e:Lcom/thinkware/sundo/ieve/ieveCameraView;

    invoke-virtual {v5}, Lcom/thinkware/sundo/ieve/ieveCameraView;->getPreviewHeight()I

    move-result v5

    iput v5, v4, Landroid/graphics/Rect;->bottom:I

    .line 144
    iget-object v4, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->o:Landroid/graphics/Rect;

    iput v7, v4, Landroid/graphics/Rect;->left:I

    .line 145
    iget-object v4, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->o:Landroid/graphics/Rect;

    iput v7, v4, Landroid/graphics/Rect;->top:I

    .line 146
    iget-object v4, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->o:Landroid/graphics/Rect;

    iget-object v5, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->k:Landroid/graphics/PointF;

    iget v5, v5, Landroid/graphics/PointF;->x:F

    iget-object v6, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->n:Landroid/graphics/Rect;

    invoke-virtual {v6}, Landroid/graphics/Rect;->width()I

    move-result v6

    int-to-float v6, v6

    mul-float/2addr v5, v6

    invoke-static {v5}, Lcom/thinkware/sundo/ieve/ieveMath;->ROUND_OFF(F)I

    move-result v5

    iput v5, v4, Landroid/graphics/Rect;->right:I

    .line 147
    iget-object v4, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->o:Landroid/graphics/Rect;

    iget-object v5, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->k:Landroid/graphics/PointF;

    iget v5, v5, Landroid/graphics/PointF;->y:F

    iget-object v6, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->n:Landroid/graphics/Rect;

    invoke-virtual {v6}, Landroid/graphics/Rect;->height()I

    move-result v6

    int-to-float v6, v6

    mul-float/2addr v5, v6

    invoke-static {v5}, Lcom/thinkware/sundo/ieve/ieveMath;->ROUND_OFF(F)I

    move-result v5

    iput v5, v4, Landroid/graphics/Rect;->bottom:I

    .line 149
    iget-object v4, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->i:Landroid/graphics/PointF;

    iget-object v5, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->d:Lcom/thinkware/sundo/ieve/IEVE;

    iget v5, v5, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_IMAGESIZE_QVGA_WIDTH_2:I

    int-to-float v5, v5

    iget-object v6, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->m:Landroid/graphics/PointF;

    iget v6, v6, Landroid/graphics/PointF;->x:F

    mul-float/2addr v5, v6

    iput v5, v4, Landroid/graphics/PointF;->x:F

    .line 150
    iget-object v4, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->i:Landroid/graphics/PointF;

    iget-object v5, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->d:Lcom/thinkware/sundo/ieve/IEVE;

    iget v5, v5, Lcom/thinkware/sundo/ieve/IEVE;->IEVE_IMAGESIZE_QVGA_HEIGHT_2:I

    int-to-float v5, v5

    iget-object v6, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->m:Landroid/graphics/PointF;

    iget v6, v6, Landroid/graphics/PointF;->y:F

    mul-float/2addr v5, v6

    iput v5, v4, Landroid/graphics/PointF;->y:F

    .line 151
    return-void

    .line 122
    :catch_0
    move-exception v1

    .line 123
    .local v1, "e":Landroid/content/pm/PackageManager$NameNotFoundException;
    sget-object v4, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->a:Ljava/lang/String;

    invoke-virtual {v1}, Landroid/content/pm/PackageManager$NameNotFoundException;->getMessage()Ljava/lang/String;

    move-result-object v5

    invoke-static {v4, v5}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 124
    invoke-virtual {v1}, Landroid/content/pm/PackageManager$NameNotFoundException;->printStackTrace()V

    goto/16 :goto_0
.end method


# virtual methods
.method protected dispatchDraw(Landroid/graphics/Canvas;)V
    .locals 12
    .param p1, "canvas"    # Landroid/graphics/Canvas;

    .prologue
    const/high16 v7, 0x40000000    # 2.0f

    const/4 v1, 0x0

    const/16 v6, 0x80

    const/4 v11, 0x0

    const/16 v10, 0xff

    .line 174
    invoke-super {p0, p1}, Landroid/view/View;->dispatchDraw(Landroid/graphics/Canvas;)V

    .line 176
    invoke-virtual {p1, v11}, Landroid/graphics/Canvas;->drawColor(I)V

    .line 177
    new-instance v0, Landroid/graphics/PaintFlagsDrawFilter;

    const/4 v3, 0x2

    invoke-direct {v0, v11, v3}, Landroid/graphics/PaintFlagsDrawFilter;-><init>(II)V

    invoke-virtual {p1, v0}, Landroid/graphics/Canvas;->setDrawFilter(Landroid/graphics/DrawFilter;)V

    .line 179
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->c:Landroid/graphics/Paint;

    invoke-virtual {v0, v10, v10, v10, v10}, Landroid/graphics/Paint;->setARGB(IIII)V

    .line 182
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->e:Lcom/thinkware/sundo/ieve/ieveCameraView;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveCameraView;->getBitmapSnapshot()Landroid/graphics/Bitmap;

    move-result-object v0

    iput-object v0, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->s:Landroid/graphics/Bitmap;

    .line 183
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->s:Landroid/graphics/Bitmap;

    if-eqz v0, :cond_0

    .line 184
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->c:Landroid/graphics/Paint;

    invoke-virtual {v0, v6, v10, v10, v10}, Landroid/graphics/Paint;->setARGB(IIII)V

    .line 185
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->o:Landroid/graphics/Rect;

    iput v11, v0, Landroid/graphics/Rect;->left:I

    .line 186
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->o:Landroid/graphics/Rect;

    iput v11, v0, Landroid/graphics/Rect;->top:I

    .line 187
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->o:Landroid/graphics/Rect;

    iget-object v3, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->k:Landroid/graphics/PointF;

    iget v3, v3, Landroid/graphics/PointF;->x:F

    iget-object v4, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->n:Landroid/graphics/Rect;

    invoke-virtual {v4}, Landroid/graphics/Rect;->width()I

    move-result v4

    int-to-float v4, v4

    mul-float/2addr v3, v4

    invoke-static {v3}, Lcom/thinkware/sundo/ieve/ieveMath;->ROUND_OFF(F)I

    move-result v3

    iput v3, v0, Landroid/graphics/Rect;->right:I

    .line 188
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->o:Landroid/graphics/Rect;

    iget-object v3, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->k:Landroid/graphics/PointF;

    iget v3, v3, Landroid/graphics/PointF;->y:F

    iget-object v4, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->n:Landroid/graphics/Rect;

    invoke-virtual {v4}, Landroid/graphics/Rect;->height()I

    move-result v4

    int-to-float v4, v4

    mul-float/2addr v3, v4

    invoke-static {v3}, Lcom/thinkware/sundo/ieve/ieveMath;->ROUND_OFF(F)I

    move-result v3

    iput v3, v0, Landroid/graphics/Rect;->bottom:I

    .line 189
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->o:Landroid/graphics/Rect;

    iget-object v3, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->j:Landroid/graphics/PointF;

    iget v3, v3, Landroid/graphics/PointF;->x:F

    invoke-static {v3}, Lcom/thinkware/sundo/ieve/ieveMath;->ROUND_OFF(F)I

    move-result v3

    iget-object v4, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->j:Landroid/graphics/PointF;

    iget v4, v4, Landroid/graphics/PointF;->y:F

    invoke-static {v4}, Lcom/thinkware/sundo/ieve/ieveMath;->ROUND_OFF(F)I

    move-result v4

    invoke-virtual {v0, v3, v4}, Landroid/graphics/Rect;->offset(II)V

    .line 190
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->s:Landroid/graphics/Bitmap;

    iget-object v3, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->n:Landroid/graphics/Rect;

    iget-object v4, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->o:Landroid/graphics/Rect;

    iget-object v5, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->c:Landroid/graphics/Paint;

    invoke-virtual {p1, v0, v3, v4, v5}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;Landroid/graphics/Rect;Landroid/graphics/Rect;Landroid/graphics/Paint;)V

    .line 194
    :cond_0
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->t:Landroid/graphics/Bitmap;

    if-eqz v0, :cond_1

    iget-boolean v0, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->r:Z

    if-eqz v0, :cond_1

    .line 195
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->e:Lcom/thinkware/sundo/ieve/ieveCameraView;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveCameraView;->getWidth()I

    move-result v0

    int-to-float v0, v0

    div-float v9, v0, v7

    .line 196
    .local v9, "mx":F
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->e:Lcom/thinkware/sundo/ieve/ieveCameraView;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveCameraView;->getHeight()I

    move-result v0

    int-to-float v0, v0

    div-float v2, v0, v7

    .line 197
    .local v2, "my":F
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->c:Landroid/graphics/Paint;

    const/16 v3, 0x40

    invoke-virtual {v0, v3, v6, v6, v6}, Landroid/graphics/Paint;->setARGB(IIII)V

    .line 198
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->e:Lcom/thinkware/sundo/ieve/ieveCameraView;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveCameraView;->getWidth()I

    move-result v0

    int-to-float v3, v0

    iget-object v5, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->c:Landroid/graphics/Paint;

    move-object v0, p1

    move v4, v2

    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 199
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->e:Lcom/thinkware/sundo/ieve/ieveCameraView;

    invoke-virtual {v0}, Lcom/thinkware/sundo/ieve/ieveCameraView;->getHeight()I

    move-result v0

    int-to-float v7, v0

    iget-object v8, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->c:Landroid/graphics/Paint;

    move-object v3, p1

    move v4, v9

    move v5, v1

    move v6, v9

    invoke-virtual/range {v3 .. v8}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 201
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->c:Landroid/graphics/Paint;

    invoke-virtual {v0, v10, v10, v10, v10}, Landroid/graphics/Paint;->setARGB(IIII)V

    .line 202
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->t:Landroid/graphics/Bitmap;

    iget-object v1, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->p:Landroid/graphics/Rect;

    iget-object v3, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->q:Landroid/graphics/Rect;

    iget-object v4, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->c:Landroid/graphics/Paint;

    invoke-virtual {p1, v0, v1, v3, v4}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;Landroid/graphics/Rect;Landroid/graphics/Rect;Landroid/graphics/Paint;)V

    .line 206
    .end local v2    # "my":F
    .end local v9    # "mx":F
    :cond_1
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->c:Landroid/graphics/Paint;

    invoke-virtual {v0, v10, v11, v10, v11}, Landroid/graphics/Paint;->setARGB(IIII)V

    .line 207
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->i:Landroid/graphics/PointF;

    iget v0, v0, Landroid/graphics/PointF;->x:F

    iget-object v1, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->j:Landroid/graphics/PointF;

    iget v1, v1, Landroid/graphics/PointF;->x:F

    sub-float/2addr v0, v1

    iget-object v1, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->i:Landroid/graphics/PointF;

    iget v1, v1, Landroid/graphics/PointF;->y:F

    iget-object v3, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->j:Landroid/graphics/PointF;

    iget v3, v3, Landroid/graphics/PointF;->y:F

    sub-float/2addr v1, v3

    iget-object v3, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->c:Landroid/graphics/Paint;

    invoke-virtual {p1, v0, v1, v3}, Landroid/graphics/Canvas;->drawPoint(FFLandroid/graphics/Paint;)V

    .line 209
    invoke-virtual {p0}, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->postInvalidate()V

    .line 210
    return-void
.end method

.method public enableDrawCenterMark(Z)V
    .locals 5
    .param p1, "enable"    # Z

    .prologue
    .line 154
    sget-object v1, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->a:Ljava/lang/String;

    const-string v2, "enableDrawCenterMark(%s)"

    const/4 v0, 0x1

    new-array v3, v0, [Ljava/lang/Object;

    const/4 v4, 0x0

    if-eqz p1, :cond_0

    const-string v0, "T"

    :goto_0
    aput-object v0, v3, v4

    invoke-static {v2, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 155
    iput-boolean p1, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->r:Z

    .line 156
    return-void

    .line 154
    :cond_0
    const-string v0, "F"

    goto :goto_0
.end method

.method public finalize()V
    .locals 3

    .prologue
    const/4 v2, 0x0

    .line 107
    sget-object v0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->a:Ljava/lang/String;

    const-string v1, "finalize"

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 109
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->s:Landroid/graphics/Bitmap;

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->s:Landroid/graphics/Bitmap;

    invoke-virtual {v0}, Landroid/graphics/Bitmap;->recycle()V

    iput-object v2, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->s:Landroid/graphics/Bitmap;

    .line 110
    :cond_0
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->t:Landroid/graphics/Bitmap;

    if-eqz v0, :cond_1

    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->t:Landroid/graphics/Bitmap;

    invoke-virtual {v0}, Landroid/graphics/Bitmap;->recycle()V

    iput-object v2, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->t:Landroid/graphics/Bitmap;

    .line 111
    :cond_1
    return-void
.end method

.method public updateRoiPoints()V
    .locals 10

    .prologue
    const/high16 v8, 0x40000000    # 2.0f

    .line 159
    iget-object v6, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->t:Landroid/graphics/Bitmap;

    if-eqz v6, :cond_0

    .line 160
    iget-object v6, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->l:Landroid/graphics/PointF;

    iget v6, v6, Landroid/graphics/PointF;->x:F

    iget-object v7, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->p:Landroid/graphics/Rect;

    invoke-virtual {v7}, Landroid/graphics/Rect;->width()I

    move-result v7

    int-to-float v7, v7

    mul-float v2, v6, v7

    .line 161
    .local v2, "dw":F
    iget-object v6, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->l:Landroid/graphics/PointF;

    iget v6, v6, Landroid/graphics/PointF;->y:F

    iget-object v7, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->p:Landroid/graphics/Rect;

    invoke-virtual {v7}, Landroid/graphics/Rect;->height()I

    move-result v7

    int-to-float v7, v7

    mul-float v1, v6, v7

    .line 162
    .local v1, "dh":F
    iget-object v6, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->f:Landroid/graphics/Rect;

    invoke-virtual {v6}, Landroid/graphics/Rect;->width()I

    move-result v6

    int-to-float v6, v6

    sub-float/2addr v6, v2

    div-float/2addr v6, v8

    invoke-static {v6}, Lcom/thinkware/sundo/ieve/ieveMath;->ROUND_OFF(F)I

    move-result v3

    .line 163
    .local v3, "l":I
    iget-object v6, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->f:Landroid/graphics/Rect;

    invoke-virtual {v6}, Landroid/graphics/Rect;->height()I

    move-result v6

    int-to-float v6, v6

    sub-float/2addr v6, v1

    div-float/2addr v6, v8

    invoke-static {v6}, Lcom/thinkware/sundo/ieve/ieveMath;->ROUND_OFF(F)I

    move-result v5

    .line 164
    .local v5, "t":I
    int-to-float v6, v3

    add-float/2addr v6, v2

    invoke-static {v6}, Lcom/thinkware/sundo/ieve/ieveMath;->ROUND_OFF(F)I

    move-result v4

    .line 165
    .local v4, "r":I
    iget-object v6, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->l:Landroid/graphics/PointF;

    iget v6, v6, Landroid/graphics/PointF;->y:F

    iget-object v7, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->p:Landroid/graphics/Rect;

    invoke-virtual {v7}, Landroid/graphics/Rect;->height()I

    move-result v7

    int-to-float v7, v7

    mul-float/2addr v6, v7

    int-to-float v7, v5

    add-float/2addr v6, v7

    invoke-static {v6}, Lcom/thinkware/sundo/ieve/ieveMath;->ROUND_OFF(F)I

    move-result v0

    .line 166
    .local v0, "b":I
    iget-object v6, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->q:Landroid/graphics/Rect;

    invoke-virtual {v6, v3, v5, v4, v0}, Landroid/graphics/Rect;->set(IIII)V

    .line 168
    .end local v0    # "b":I
    .end local v1    # "dh":F
    .end local v2    # "dw":F
    .end local v3    # "l":I
    .end local v4    # "r":I
    .end local v5    # "t":I
    :cond_0
    iget-object v6, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->g:Landroid/graphics/Point;

    iget-object v7, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->d:Lcom/thinkware/sundo/ieve/IEVE;

    const/16 v8, 0x7300

    invoke-virtual {v7, v8}, Lcom/thinkware/sundo/ieve/IEVE;->getIEVEConfigValue(I)I

    move-result v7

    iget-object v8, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->d:Lcom/thinkware/sundo/ieve/IEVE;

    const/16 v9, 0x7301

    invoke-virtual {v8, v9}, Lcom/thinkware/sundo/ieve/IEVE;->getIEVEConfigValue(I)I

    move-result v8

    invoke-virtual {v6, v7, v8}, Landroid/graphics/Point;->set(II)V

    .line 169
    iget-object v6, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->j:Landroid/graphics/PointF;

    iget-object v7, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->h:Landroid/graphics/Point;

    iget v7, v7, Landroid/graphics/Point;->x:I

    iget-object v8, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->g:Landroid/graphics/Point;

    iget v8, v8, Landroid/graphics/Point;->x:I

    sub-int/2addr v7, v8

    int-to-float v7, v7

    iget-object v8, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->m:Landroid/graphics/PointF;

    iget v8, v8, Landroid/graphics/PointF;->x:F

    mul-float/2addr v7, v8

    iget-object v8, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->h:Landroid/graphics/Point;

    iget v8, v8, Landroid/graphics/Point;->y:I

    iget-object v9, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->g:Landroid/graphics/Point;

    iget v9, v9, Landroid/graphics/Point;->y:I

    sub-int/2addr v8, v9

    int-to-float v8, v8

    iget-object v9, p0, Lcom/thinkware/sundo/ieve/ieveCalibrationView;->m:Landroid/graphics/PointF;

    iget v9, v9, Landroid/graphics/PointF;->y:F

    mul-float/2addr v8, v9

    invoke-virtual {v6, v7, v8}, Landroid/graphics/PointF;->set(FF)V

    .line 170
    return-void
.end method
