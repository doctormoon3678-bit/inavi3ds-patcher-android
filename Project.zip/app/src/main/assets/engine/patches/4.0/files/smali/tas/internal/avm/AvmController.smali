.class public Ltas/internal/avm/AvmController;
.super Ljava/lang/Object;
.source "AvmController.java"


# static fields
.field static final TAG:Ljava/lang/String; = "TAS.INTERNAL.AVM"

.field private static mListeners:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List",
            "<",
            "Ltas/internal/avm/IAvmStatusListener;",
            ">;"
        }
    .end annotation
.end field

.field private static mRunning:Z


# instance fields
.field private mAckCount:I

.field private mBootMode:Ltas/internal/avm/AvmEnumerations$BootMode;

.field private mMessageBuffer:[B

.field private mSetupData:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map",
            "<",
            "Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;",
            "Ljava/lang/Byte;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .prologue
    .line 28
    const/4 v0, 0x0

    sput-boolean v0, Ltas/internal/avm/AvmController;->mRunning:Z

    .line 34
    const-string/jumbo v0, "AvmControllerNative"

    invoke-static {v0}, Ljava/lang/System;->loadLibrary(Ljava/lang/String;)V

    .line 285
    invoke-static {}, Ltas/internal/avm/AvmController;->class_init_avm()V

    .line 23
    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .prologue
    .line 41
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 27
    const/16 v0, 0x78

    new-array v0, v0, [B

    iput-object v0, p0, Ltas/internal/avm/AvmController;->mMessageBuffer:[B

    .line 30
    const/4 v0, 0x0

    iput v0, p0, Ltas/internal/avm/AvmController;->mAckCount:I

    .line 42
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    sput-object v0, Ltas/internal/avm/AvmController;->mListeners:Ljava/util/List;

    .line 43
    sget-object v0, Ltas/internal/avm/AvmEnumerations$BootMode;->NORMAL_MODE:Ltas/internal/avm/AvmEnumerations$BootMode;

    iput-object v0, p0, Ltas/internal/avm/AvmController;->mBootMode:Ltas/internal/avm/AvmEnumerations$BootMode;

    .line 41
    return-void
.end method

.method public static addListener(Ltas/internal/avm/IAvmStatusListener;)V
    .locals 1
    .param p0, "listener"    # Ltas/internal/avm/IAvmStatusListener;

    .prologue
    .line 47
    sget-object v0, Ltas/internal/avm/AvmController;->mListeners:Ljava/util/List;

    invoke-interface {v0, p0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 46
    return-void
.end method

.method private static byteArrayToHex([B)Ljava/lang/String;
    .locals 11
    .param p0, "buffer"    # [B

    .prologue
    const/4 v10, 0x1

    const/4 v5, 0x0

    .line 87
    new-instance v3, Ljava/lang/StringBuilder;

    array-length v4, p0

    mul-int/lit8 v4, v4, 0x4

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(I)V

    .line 88
    .local v3, "sb":Ljava/lang/StringBuilder;
    const/4 v2, 0x0

    .line 89
    .local v2, "index":I
    array-length v6, p0

    move v4, v5

    :goto_0
    if-ge v4, v6, :cond_4

    aget-byte v0, p0, v4

    .line 90
    .local v0, "b":B
    if-ne v2, v10, :cond_2

    .line 91
    and-int/lit16 v7, v0, 0xff

    if-nez v7, :cond_0

    .line 92
    const-string/jumbo v7, " |  Info  |"

    invoke-virtual {v3, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 105
    :goto_1
    add-int/lit8 v2, v2, 0x1

    .line 89
    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    .line 93
    :cond_0
    and-int/lit16 v7, v0, 0xff

    if-ne v7, v10, :cond_1

    .line 94
    const-string/jumbo v7, " | Request |"

    invoke-virtual {v3, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_1

    .line 96
    :cond_1
    const-string/jumbo v7, " | ???? |"

    invoke-virtual {v3, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_1

    .line 99
    :cond_2
    const/4 v7, 0x2

    if-ne v2, v7, :cond_3

    .line 100
    and-int/lit16 v7, v0, 0xff

    invoke-static {v7}, Ltas/internal/avm/AvmEnumerations$MessageID;->createFromValue(I)Ltas/internal/avm/AvmEnumerations$MessageID;

    move-result-object v1

    .line 101
    .local v1, "id":Ltas/internal/avm/AvmEnumerations$MessageID;
    const-string/jumbo v7, " "

    invoke-virtual {v3, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v1}, Ltas/internal/avm/AvmEnumerations$MessageID;->name()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    const-string/jumbo v8, " "

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_1

    .line 103
    .end local v1    # "id":Ltas/internal/avm/AvmEnumerations$MessageID;
    :cond_3
    const-string/jumbo v7, " | 0x%02x"

    new-array v8, v10, [Ljava/lang/Object;

    and-int/lit16 v9, v0, 0xff

    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    aput-object v9, v8, v5

    invoke-static {v7, v8}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v3, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_1

    .line 108
    .end local v0    # "b":B
    :cond_4
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    return-object v4
.end method

.method private static native class_init_avm()V
.end method

.method public static getControllerState()Z
    .locals 1

    .prologue
    .line 66
    sget-boolean v0, Ltas/internal/avm/AvmController;->mRunning:Z

    return v0
.end method

.method private onBootModeReceived([B)V
    .locals 6
    .param p1, "mode"    # [B

    .prologue
    const/4 v5, 0x0

    .line 252
    const-string/jumbo v2, "TAS.INTERNAL.AVM"

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v4, "boot mode received "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    aget-byte v4, p1, v5

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 253
    aget-byte v2, p1, v5

    invoke-static {v2}, Ltas/internal/avm/AvmEnumerations$BootMode;->createFromValue(I)Ltas/internal/avm/AvmEnumerations$BootMode;

    move-result-object v2

    iput-object v2, p0, Ltas/internal/avm/AvmController;->mBootMode:Ltas/internal/avm/AvmEnumerations$BootMode;

    .line 254
    sget-object v2, Ltas/internal/avm/AvmController;->mListeners:Ljava/util/List;

    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    .local v1, "listener$iterator":Ljava/util/Iterator;
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_0

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/avm/IAvmStatusListener;

    .line 255
    .local v0, "listener":Ltas/internal/avm/IAvmStatusListener;
    iget-object v2, p0, Ltas/internal/avm/AvmController;->mBootMode:Ltas/internal/avm/AvmEnumerations$BootMode;

    invoke-interface {v0, v2}, Ltas/internal/avm/IAvmStatusListener;->onBootModeReceived(Ltas/internal/avm/AvmEnumerations$BootMode;)V

    goto :goto_0

    .line 251
    .end local v0    # "listener":Ltas/internal/avm/IAvmStatusListener;
    :cond_0
    return-void
.end method

.method private onCalibrationStatusReceived([B)V
    .locals 6
    .param p1, "value"    # [B

    .prologue
    .line 163
    const-string/jumbo v3, "TAS.INTERNAL.AVM"

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v5, "onCalibrationStatusReceived "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-static {p1}, Ljava/util/Arrays;->toString([B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v3, v4}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 165
    const/4 v3, 0x0

    aget-byte v3, p1, v3

    invoke-static {v3}, Ltas/internal/avm/AvmEnumerations$CalibrationStatus;->createFromValue(I)Ltas/internal/avm/AvmEnumerations$CalibrationStatus;

    move-result-object v2

    .line 167
    .local v2, "status":Ltas/internal/avm/AvmEnumerations$CalibrationStatus;
    sget-object v3, Ltas/internal/avm/AvmController;->mListeners:Ljava/util/List;

    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    .local v1, "listener$iterator":Ljava/util/Iterator;
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_0

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/avm/IAvmStatusListener;

    .line 168
    .local v0, "listener":Ltas/internal/avm/IAvmStatusListener;
    invoke-interface {v0, v2}, Ltas/internal/avm/IAvmStatusListener;->onCalibrationStatusReceived(Ltas/internal/avm/AvmEnumerations$CalibrationStatus;)V

    goto :goto_0

    .line 162
    .end local v0    # "listener":Ltas/internal/avm/IAvmStatusListener;
    :cond_0
    return-void
.end method

.method private onConnectionStatusChanged(I)V
    .locals 5
    .param p1, "sec"    # I

    .prologue
    .line 142
    const-string/jumbo v2, "TAS.INTERNAL.AVM"

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v4, "onConnectionStatusChanged "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 144
    iget-object v2, p0, Ltas/internal/avm/AvmController;->mBootMode:Ltas/internal/avm/AvmEnumerations$BootMode;

    sget-object v3, Ltas/internal/avm/AvmEnumerations$BootMode;->UPGRADE_MODE:Ltas/internal/avm/AvmEnumerations$BootMode;

    if-eq v2, v3, :cond_0

    .line 145
    iget-object v2, p0, Ltas/internal/avm/AvmController;->mBootMode:Ltas/internal/avm/AvmEnumerations$BootMode;

    sget-object v3, Ltas/internal/avm/AvmEnumerations$BootMode;->CALIBRATION_MODE:Ltas/internal/avm/AvmEnumerations$BootMode;

    if-ne v2, v3, :cond_1

    .line 146
    :cond_0
    const/4 p1, 0x1

    .line 147
    const-string/jumbo v2, "TAS.INTERNAL.AVM"

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v4, "BootMode = "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget-object v4, p0, Ltas/internal/avm/AvmController;->mBootMode:Ltas/internal/avm/AvmEnumerations$BootMode;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string/jumbo v4, ", fake connection status to "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 150
    :cond_1
    sget-object v2, Ltas/internal/avm/AvmController;->mListeners:Ljava/util/List;

    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    .local v1, "listener$iterator":Ljava/util/Iterator;
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_2

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/avm/IAvmStatusListener;

    .line 151
    .local v0, "listener":Ltas/internal/avm/IAvmStatusListener;
    invoke-interface {v0, p1}, Ltas/internal/avm/IAvmStatusListener;->onConnectionStatusChanged(I)V

    goto :goto_0

    .line 141
    .end local v0    # "listener":Ltas/internal/avm/IAvmStatusListener;
    :cond_2
    return-void
.end method

.method private onPGSReceived(III[B)V
    .locals 4
    .param p1, "viewId"    # I
    .param p2, "angle"    # I
    .param p3, "pointCount"    # I
    .param p4, "pointData"    # [B

    .prologue
    .line 260
    invoke-static {p1}, Ltas/internal/avm/AvmEnumerations$ViewMode;->createFromValue(I)Ltas/internal/avm/AvmEnumerations$ViewMode;

    move-result-object v2

    .line 261
    .local v2, "view":Ltas/internal/avm/AvmEnumerations$ViewMode;
    sget-object v3, Ltas/internal/avm/AvmController;->mListeners:Ljava/util/List;

    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    .local v1, "listener$iterator":Ljava/util/Iterator;
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_0

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/avm/IAvmStatusListener;

    .line 262
    .local v0, "listener":Ltas/internal/avm/IAvmStatusListener;
    invoke-interface {v0, v2, p4}, Ltas/internal/avm/IAvmStatusListener;->onPGSReceived(Ltas/internal/avm/AvmEnumerations$ViewMode;[B)V

    goto :goto_0

    .line 259
    .end local v0    # "listener":Ltas/internal/avm/IAvmStatusListener;
    :cond_0
    return-void
.end method

.method private onReportACK(D)V
    .locals 5
    .param p1, "latency"    # D

    .prologue
    .line 117
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v4, "ack("

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget v4, p0, Ltas/internal/avm/AvmController;->mAckCount:I

    add-int/lit8 v4, v4, 0x1

    iput v4, p0, Ltas/internal/avm/AvmController;->mAckCount:I

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string/jumbo v4, ")"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string/jumbo v4, " latency = "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, p1, p2}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 119
    .local v0, "ack":Ljava/lang/String;
    sget-object v3, Ltas/internal/avm/AvmController;->mListeners:Ljava/util/List;

    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v2

    .local v2, "listener$iterator":Ljava/util/Iterator;
    :goto_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_0

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ltas/internal/avm/IAvmStatusListener;

    .line 120
    .local v1, "listener":Ltas/internal/avm/IAvmStatusListener;
    invoke-interface {v1, v0}, Ltas/internal/avm/IAvmStatusListener;->onMessageReceived(Ljava/lang/String;)V

    goto :goto_0

    .line 116
    .end local v1    # "listener":Ltas/internal/avm/IAvmStatusListener;
    :cond_0
    return-void
.end method

.method private onReportAVM()V
    .locals 8

    .prologue
    .line 125
    iget-object v5, p0, Ltas/internal/avm/AvmController;->mMessageBuffer:[B

    iget-object v6, p0, Ltas/internal/avm/AvmController;->mMessageBuffer:[B

    array-length v6, v6

    invoke-direct {p0, v5, v6}, Ltas/internal/avm/AvmController;->tas_avm_read_buffer([BI)I

    move-result v1

    .line 128
    .local v1, "length":I
    const/4 v5, 0x2

    if-le v1, v5, :cond_0

    .line 129
    iget-object v5, p0, Ltas/internal/avm/AvmController;->mMessageBuffer:[B

    add-int/lit8 v6, v1, -0x2

    const/4 v7, 0x1

    invoke-static {v5, v7, v6}, Ljava/util/Arrays;->copyOfRange([BII)[B

    move-result-object v0

    .line 133
    .local v0, "buffer":[B
    :goto_0
    invoke-static {v0}, Ltas/internal/avm/AvmController;->byteArrayToHex([B)Ljava/lang/String;

    move-result-object v4

    .line 134
    .local v4, "msg":Ljava/lang/String;
    const-string/jumbo v5, "TAS.INTERNAL.AVM"

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v7, "message rcv "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-static {v0}, Ltas/internal/avm/AvmController;->byteArrayToHex([B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v5, v6}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 136
    sget-object v5, Ltas/internal/avm/AvmController;->mListeners:Ljava/util/List;

    invoke-interface {v5}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v3

    .local v3, "listener$iterator":Ljava/util/Iterator;
    :goto_1
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_1

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ltas/internal/avm/IAvmStatusListener;

    .line 137
    .local v2, "listener":Ltas/internal/avm/IAvmStatusListener;
    invoke-interface {v2, v4}, Ltas/internal/avm/IAvmStatusListener;->onMessageReceived(Ljava/lang/String;)V

    goto :goto_1

    .line 131
    .end local v0    # "buffer":[B
    .end local v2    # "listener":Ltas/internal/avm/IAvmStatusListener;
    .end local v3    # "listener$iterator":Ljava/util/Iterator;
    .end local v4    # "msg":Ljava/lang/String;
    :cond_0
    iget-object v5, p0, Ltas/internal/avm/AvmController;->mMessageBuffer:[B

    invoke-static {v5, v1}, Ljava/util/Arrays;->copyOf([BI)[B

    move-result-object v0

    .restart local v0    # "buffer":[B
    goto :goto_0

    .line 124
    .restart local v3    # "listener$iterator":Ljava/util/Iterator;
    .restart local v4    # "msg":Ljava/lang/String;
    :cond_1
    return-void
.end method

.method private onSetupDataReceived([B)V
    .locals 9
    .param p1, "values"    # [B

    .prologue
    .line 182
    new-instance v4, Ljava/util/EnumMap;

    const-class v5, Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;

    invoke-direct {v4, v5}, Ljava/util/EnumMap;-><init>(Ljava/lang/Class;)V

    iput-object v4, p0, Ltas/internal/avm/AvmController;->mSetupData:Ljava/util/Map;

    .line 184
    const/4 v3, 0x0

    .line 185
    .local v3, "typeIndex":I
    const/4 v4, 0x0

    array-length v5, p1

    :goto_0
    if-ge v4, v5, :cond_0

    aget-byte v0, p1, v4

    .line 186
    .local v0, "i":B
    iget-object v6, p0, Ltas/internal/avm/AvmController;->mSetupData:Ljava/util/Map;

    invoke-static {v3}, Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;->createFromOrdinalNumber(I)Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;

    move-result-object v7

    invoke-static {v0}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object v8

    invoke-interface {v6, v7, v8}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 187
    add-int/lit8 v3, v3, 0x1

    .line 185
    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    .line 190
    .end local v0    # "i":B
    :cond_0
    sget-object v4, Ltas/internal/avm/AvmController;->mListeners:Ljava/util/List;

    invoke-interface {v4}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v2

    .local v2, "listener$iterator":Ljava/util/Iterator;
    :goto_1
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_1

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ltas/internal/avm/IAvmStatusListener;

    .line 191
    .local v1, "listener":Ltas/internal/avm/IAvmStatusListener;
    iget-object v4, p0, Ltas/internal/avm/AvmController;->mSetupData:Ljava/util/Map;

    invoke-interface {v1, v4}, Ltas/internal/avm/IAvmStatusListener;->onSetupDataReceived(Ljava/util/Map;)V

    goto :goto_1

    .line 181
    .end local v1    # "listener":Ltas/internal/avm/IAvmStatusListener;
    :cond_1
    return-void
.end method

.method private onTopviewCoordReceived([B)V
    .locals 5
    .param p1, "coord"    # [B

    .prologue
    .line 156
    const-string/jumbo v2, "TAS.INTERNAL.AVM"

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v4, "onTopviewCoordReceived "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-static {p1}, Ljava/util/Arrays;->toString([B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 157
    sget-object v2, Ltas/internal/avm/AvmController;->mListeners:Ljava/util/List;

    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    .local v1, "listener$iterator":Ljava/util/Iterator;
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_0

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/avm/IAvmStatusListener;

    .line 158
    .local v0, "listener":Ltas/internal/avm/IAvmStatusListener;
    invoke-interface {v0, p1}, Ltas/internal/avm/IAvmStatusListener;->onTopViewCoordReceived([B)V

    goto :goto_0

    .line 155
    .end local v0    # "listener":Ltas/internal/avm/IAvmStatusListener;
    :cond_0
    return-void
.end method

.method private onUpgradeStatusReceived([B)V
    .locals 7
    .param p1, "status"    # [B

    .prologue
    const/4 v6, 0x0

    .line 173
    const-string/jumbo v3, "TAS.INTERNAL.AVM"

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v5, "upgrade status received "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    aget-byte v5, p1, v6

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v3, v4}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 174
    aget-byte v3, p1, v6

    invoke-static {v3}, Ltas/internal/avm/AvmEnumerations$UpgradeMode;->createFromValue(I)Ltas/internal/avm/AvmEnumerations$UpgradeMode;

    move-result-object v2

    .line 176
    .local v2, "mode":Ltas/internal/avm/AvmEnumerations$UpgradeMode;
    sget-object v3, Ltas/internal/avm/AvmController;->mListeners:Ljava/util/List;

    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    .local v1, "listener$iterator":Ljava/util/Iterator;
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_0

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/avm/IAvmStatusListener;

    .line 177
    .local v0, "listener":Ltas/internal/avm/IAvmStatusListener;
    invoke-interface {v0, v2}, Ltas/internal/avm/IAvmStatusListener;->onUpgradeStatusReceived(Ltas/internal/avm/AvmEnumerations$UpgradeMode;)V

    goto :goto_0

    .line 172
    .end local v0    # "listener":Ltas/internal/avm/IAvmStatusListener;
    :cond_0
    return-void
.end method

.method private onViewModeResponse([B)V
    .locals 8
    .param p1, "responseCode"    # [B

    .prologue
    const/4 v7, 0x0

    .line 267
    array-length v4, p1

    const/4 v5, 0x1

    if-eq v4, v5, :cond_0

    .line 268
    const-string/jumbo v4, "TAS.INTERNAL.AVM"

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v6, "view mode response should be 1 byte "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    array-length v6, p1

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-static {v4, v5}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 271
    :cond_0
    aget-byte v4, p1, v7

    not-int v2, v4

    .line 272
    .local v2, "response":I
    const-string/jumbo v4, "TAS.INTERNAL.AVM"

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v6, "received view mode: "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-static {v4, v5}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 274
    aget-byte v4, p1, v7

    not-int v4, v4

    invoke-static {v4}, Ltas/internal/avm/AvmEnumerations$ViewMode;->createFromValue(I)Ltas/internal/avm/AvmEnumerations$ViewMode;

    move-result-object v3

    .line 276
    .local v3, "v":Ltas/internal/avm/AvmEnumerations$ViewMode;
    sget-object v4, Ltas/internal/avm/AvmController;->mListeners:Ljava/util/List;

    invoke-interface {v4}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    .local v1, "listener$iterator":Ljava/util/Iterator;
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_1

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/avm/IAvmStatusListener;

    .line 277
    .local v0, "listener":Ltas/internal/avm/IAvmStatusListener;
    invoke-interface {v0, v3}, Ltas/internal/avm/IAvmStatusListener;->onViewModeAck(Ltas/internal/avm/AvmEnumerations$ViewMode;)V

    goto :goto_0

    .line 266
    .end local v0    # "listener":Ltas/internal/avm/IAvmStatusListener;
    :cond_1
    return-void
.end method

.method public static removeListener(Ltas/internal/avm/IAvmStatusListener;)V
    .locals 1
    .param p0, "listener"    # Ltas/internal/avm/IAvmStatusListener;

    .prologue
    .line 51
    sget-object v0, Ltas/internal/avm/AvmController;->mListeners:Ljava/util/List;

    invoke-interface {v0, p0}, Ljava/util/List;->remove(Ljava/lang/Object;)Z

    .line 50
    return-void
.end method

.method private setControllerState(Z)V
    .locals 0
    .param p1, "isRunning"    # Z

    .prologue
    .line 62
    sput-boolean p1, Ltas/internal/avm/AvmController;->mRunning:Z

    .line 61
    return-void
.end method

.method private native tas_avm_boot_mode_request()V
.end method

.method private native tas_avm_cvbs_out_ctrl(I)V
.end method

.method private native tas_avm_finalize()V
.end method

.method private native tas_avm_get_timeout()I
.end method

.method private native tas_avm_pgs_request(IIIII[B)V
.end method

.method private native tas_avm_read_buffer([BI)I
.end method

.method private native tas_avm_reset_request()V
.end method

.method private native tas_avm_send_keyevent(I)V
.end method

.method private native tas_avm_send_message(II[BI)I
.end method

.method private native tas_avm_set_debug_mode(Z)V
.end method

.method private native tas_avm_setup_data_request()V
.end method

.method private native tas_avm_setup_data_send(II)V
.end method

.method private native tas_avm_start()Z
.end method

.method private native tas_avm_topview_coord_request(I)V
.end method

.method private native tas_avm_viewmode_request(I)I
.end method


# virtual methods
.method public cvbsOutEnable(I)V
    .locals 0
    .param p1, "enable"    # I

    .prologue
    .line 196
    invoke-direct {p0, p1}, Ltas/internal/avm/AvmController;->tas_avm_cvbs_out_ctrl(I)V

    .line 195
    return-void
.end method

.method public finalizeAVM()V
    .locals 1

    .prologue
    .line 200
    invoke-static {}, Ltas/internal/avm/AvmController;->getControllerState()Z

    move-result v0

    if-eqz v0, :cond_0

    .line 201
    invoke-direct {p0}, Ltas/internal/avm/AvmController;->tas_avm_finalize()V

    .line 202
    const/4 v0, 0x0

    invoke-direct {p0, v0}, Ltas/internal/avm/AvmController;->setControllerState(Z)V

    .line 199
    :cond_0
    return-void
.end method

.method public getAvmConnectionTimeout()I
    .locals 1

    .prologue
    .line 38
    invoke-direct {p0}, Ltas/internal/avm/AvmController;->tas_avm_get_timeout()I

    move-result v0

    return v0
.end method

.method public requestBootMode()V
    .locals 0

    .prologue
    .line 226
    invoke-direct {p0}, Ltas/internal/avm/AvmController;->tas_avm_boot_mode_request()V

    .line 225
    return-void
.end method

.method public requestPGS(Ltas/internal/avm/AvmEnumerations$ViewMode;[B)V
    .locals 7
    .param p1, "viewId"    # Ltas/internal/avm/AvmEnumerations$ViewMode;
    .param p2, "points"    # [B

    .prologue
    .line 231
    const/4 v1, 0x0

    .line 232
    .local v1, "type":I
    sget-object v0, Ltas/internal/avm/AvmEnumerations$PGSCoordType;->PG_TYPE_COORD_WORLD:Ltas/internal/avm/AvmEnumerations$PGSCoordType;

    invoke-virtual {v0}, Ltas/internal/avm/AvmEnumerations$PGSCoordType;->toInteger()I

    move-result v2

    .line 233
    .local v2, "coordType":I
    const/4 v4, 0x0

    .line 235
    .local v4, "angle":I
    if-eqz p1, :cond_0

    if-nez p2, :cond_1

    .line 236
    :cond_0
    const-string/jumbo v0, "TAS.INTERNAL.AVM"

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v6, "inavlid arguments. view id = "

    invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string/jumbo v6, "PGSPoints = "

    invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v0, v3}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 237
    return-void

    .line 235
    :cond_1
    array-length v0, p2

    if-eqz v0, :cond_0

    .line 240
    array-length v0, p2

    div-int/lit8 v5, v0, 0x8

    .line 242
    .local v5, "pointCount":I
    invoke-virtual {p1}, Ltas/internal/avm/AvmEnumerations$ViewMode;->toInteger()I

    move-result v3

    move-object v0, p0

    move-object v6, p2

    invoke-direct/range {v0 .. v6}, Ltas/internal/avm/AvmController;->tas_avm_pgs_request(IIIII[B)V

    .line 229
    return-void
.end method

.method public requestSetupData()V
    .locals 0

    .prologue
    .line 207
    invoke-direct {p0}, Ltas/internal/avm/AvmController;->tas_avm_setup_data_request()V

    .line 206
    return-void
.end method

.method public requestTopviewCoord(Ltas/internal/avm/AvmEnumerations$ViewMode;)V
    .locals 1
    .param p1, "view"    # Ltas/internal/avm/AvmEnumerations$ViewMode;

    .prologue
    .line 247
    if-eqz p1, :cond_0

    .line 248
    invoke-virtual {p1}, Ltas/internal/avm/AvmEnumerations$ViewMode;->toInteger()I

    move-result v0

    invoke-direct {p0, v0}, Ltas/internal/avm/AvmController;->tas_avm_topview_coord_request(I)V

    .line 246
    :cond_0
    return-void
.end method

.method public requestViewMode(Ltas/internal/avm/AvmEnumerations$ViewMode;)V
    .locals 1
    .param p1, "mode"    # Ltas/internal/avm/AvmEnumerations$ViewMode;

    .prologue
    .line 74
    invoke-virtual {p1}, Ltas/internal/avm/AvmEnumerations$ViewMode;->toInteger()I

    move-result v0

    invoke-direct {p0, v0}, Ltas/internal/avm/AvmController;->tas_avm_viewmode_request(I)I

    .line 73
    return-void
.end method

.method public resetAVM()V
    .locals 0

    .prologue
    .line 70
    invoke-direct {p0}, Ltas/internal/avm/AvmController;->tas_avm_reset_request()V

    .line 69
    return-void
.end method

.method public sendKeyEvent(Ltas/internal/avm/AvmEnumerations$KeyBoxEvent;)V
    .locals 1
    .param p1, "key"    # Ltas/internal/avm/AvmEnumerations$KeyBoxEvent;

    .prologue
    .line 83
    invoke-virtual {p1}, Ltas/internal/avm/AvmEnumerations$KeyBoxEvent;->toInteger()I

    move-result v0

    invoke-direct {p0, v0}, Ltas/internal/avm/AvmController;->tas_avm_send_keyevent(I)V

    .line 82
    return-void
.end method

.method public sendMessage(II[BI)V
    .locals 0
    .param p1, "id"    # I
    .param p2, "type"    # I
    .param p3, "data"    # [B
    .param p4, "length"    # I

    .prologue
    .line 79
    invoke-direct {p0, p1, p2, p3, p4}, Ltas/internal/avm/AvmController;->tas_avm_send_message(II[BI)I

    .line 78
    return-void
.end method

.method public sendSetupData(Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;I)V
    .locals 4
    .param p1, "type"    # Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;
    .param p2, "val"    # I

    .prologue
    .line 211
    invoke-static {p1}, Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;->getMaxValue(Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;)I

    move-result v0

    .line 212
    .local v0, "max":I
    if-ge v0, p2, :cond_0

    .line 213
    const-string/jumbo v1, "TAS.INTERNAL.AVM"

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "setupdata cannot be exceed its max value ("

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string/jumbo v3, ")"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 214
    return-void

    .line 217
    :cond_0
    invoke-virtual {p1}, Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;->toInteger()I

    move-result v1

    invoke-direct {p0, v1, p2}, Ltas/internal/avm/AvmController;->tas_avm_setup_data_send(II)V

    .line 210
    return-void
.end method

.method public setDebugMode(Z)V
    .locals 3
    .param p1, "enable"    # Z

    .prologue
    .line 221
    const-string/jumbo v0, "TAS.INTERNAL.AVM"

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "debug mode "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 222
    invoke-direct {p0, p1}, Ltas/internal/avm/AvmController;->tas_avm_set_debug_mode(Z)V

    .line 220
    return-void
.end method

.method public startAVM()V
    .locals 1

    .prologue
    .line 55
    invoke-static {}, Ltas/internal/avm/AvmController;->getControllerState()Z

    move-result v0

    if-nez v0, :cond_0

    .line 56
    invoke-direct {p0}, Ltas/internal/avm/AvmController;->tas_avm_start()Z

    .line 57
    const/4 v0, 0x1

    invoke-direct {p0, v0}, Ltas/internal/avm/AvmController;->setControllerState(Z)V

    .line 54
    :cond_0
    return-void
.end method
