.class Ltas/util/power/Acc$1;
.super Landroid/os/UEventObserver;
.source "Acc.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ltas/util/power/Acc;-><init>()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Ltas/util/power/Acc;


# direct methods
.method constructor <init>(Ltas/util/power/Acc;)V
    .locals 0
    .param p1, "this$0"    # Ltas/util/power/Acc;

    .prologue
    .line 72
    iput-object p1, p0, Ltas/util/power/Acc$1;->this$0:Ltas/util/power/Acc;

    invoke-direct {p0}, Landroid/os/UEventObserver;-><init>()V

    return-void
.end method


# virtual methods
.method public onUEvent(Landroid/os/UEventObserver$UEvent;)V
    .locals 1
    .param p1, "event"    # Landroid/os/UEventObserver$UEvent;

    .prologue
    .line 74
    iget-object v0, p0, Ltas/util/power/Acc$1;->this$0:Ltas/util/power/Acc;

    invoke-static {v0, p1}, Ltas/util/power/Acc;->-wrap0(Ltas/util/power/Acc;Landroid/os/UEventObserver$UEvent;)V

    .line 73
    return-void
.end method
