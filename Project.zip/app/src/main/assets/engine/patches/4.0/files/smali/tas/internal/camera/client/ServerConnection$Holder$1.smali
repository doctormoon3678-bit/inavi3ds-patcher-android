.class final Ltas/internal/camera/client/ServerConnection$Holder$1;
.super Ljava/lang/Object;
.source "ServerConnection.java"

# interfaces
.implements Ltas/internal/ipc/util/SyncdPool$Callback;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltas/internal/camera/client/ServerConnection$Holder;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ltas/internal/ipc/util/SyncdPool$Callback",
        "<",
        "Ltas/internal/camera/client/ServerConnection$Holder;",
        ">;"
    }
.end annotation


# direct methods
.method constructor <init>()V
    .locals 0

    .prologue
    .line 468
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public bridge synthetic getNext(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1
    .param p1, "h"    # Ljava/lang/Object;

    .prologue
    .line 473
    check-cast p1, Ltas/internal/camera/client/ServerConnection$Holder;

    .end local p1    # "h":Ljava/lang/Object;
    invoke-virtual {p0, p1}, Ltas/internal/camera/client/ServerConnection$Holder$1;->getNext(Ltas/internal/camera/client/ServerConnection$Holder;)Ltas/internal/camera/client/ServerConnection$Holder;

    move-result-object v0

    return-object v0
.end method

.method public getNext(Ltas/internal/camera/client/ServerConnection$Holder;)Ltas/internal/camera/client/ServerConnection$Holder;
    .locals 1
    .param p1, "h"    # Ltas/internal/camera/client/ServerConnection$Holder;

    .prologue
    .line 474
    invoke-static {p1}, Ltas/internal/camera/client/ServerConnection$Holder;->-get0(Ltas/internal/camera/client/ServerConnection$Holder;)Ltas/internal/camera/client/ServerConnection$Holder;

    move-result-object v0

    return-object v0
.end method

.method public bridge synthetic newInstance()Ljava/lang/Object;
    .locals 1

    .prologue
    .line 469
    invoke-virtual {p0}, Ltas/internal/camera/client/ServerConnection$Holder$1;->newInstance()Ltas/internal/camera/client/ServerConnection$Holder;

    move-result-object v0

    return-object v0
.end method

.method public newInstance()Ltas/internal/camera/client/ServerConnection$Holder;
    .locals 2

    .prologue
    .line 470
    new-instance v0, Ltas/internal/camera/client/ServerConnection$Holder;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Ltas/internal/camera/client/ServerConnection$Holder;-><init>(Ltas/internal/camera/client/ServerConnection$Holder;)V

    return-object v0
.end method

.method public bridge synthetic setNext(Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 0
    .param p1, "h"    # Ljava/lang/Object;
    .param p2, "next"    # Ljava/lang/Object;

    .prologue
    .line 477
    check-cast p1, Ltas/internal/camera/client/ServerConnection$Holder;

    .end local p1    # "h":Ljava/lang/Object;
    check-cast p2, Ltas/internal/camera/client/ServerConnection$Holder;

    .end local p2    # "next":Ljava/lang/Object;
    invoke-virtual {p0, p1, p2}, Ltas/internal/camera/client/ServerConnection$Holder$1;->setNext(Ltas/internal/camera/client/ServerConnection$Holder;Ltas/internal/camera/client/ServerConnection$Holder;)V

    return-void
.end method

.method public setNext(Ltas/internal/camera/client/ServerConnection$Holder;Ltas/internal/camera/client/ServerConnection$Holder;)V
    .locals 0
    .param p1, "h"    # Ltas/internal/camera/client/ServerConnection$Holder;
    .param p2, "next"    # Ltas/internal/camera/client/ServerConnection$Holder;

    .prologue
    .line 478
    invoke-static {p1, p2}, Ltas/internal/camera/client/ServerConnection$Holder;->-set0(Ltas/internal/camera/client/ServerConnection$Holder;Ltas/internal/camera/client/ServerConnection$Holder;)Ltas/internal/camera/client/ServerConnection$Holder;

    .line 477
    return-void
.end method
