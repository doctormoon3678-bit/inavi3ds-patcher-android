.class public Ltas/camera/CameraMessage;
.super Ljava/lang/Object;
.source "CameraMessage.java"


# instance fields
.field public arg1:I

.field public arg2:I

.field public args:[I

.field public bytes:[B

.field public extra:Landroid/os/Bundle;

.field public str1:Ljava/lang/String;

.field public str2:Ljava/lang/String;

.field public what:I


# direct methods
.method public constructor <init>()V
    .locals 0

    .prologue
    .line 24
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(I)V
    .locals 0
    .param p1, "_what"    # I

    .prologue
    .line 27
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 28
    iput p1, p0, Ltas/camera/CameraMessage;->what:I

    .line 27
    return-void
.end method


# virtual methods
.method public clear()V
    .locals 2

    .prologue
    const/4 v1, 0x0

    const/4 v0, 0x0

    .line 43
    iput v1, p0, Ltas/camera/CameraMessage;->what:I

    .line 44
    iput v1, p0, Ltas/camera/CameraMessage;->arg1:I

    .line 45
    iput v1, p0, Ltas/camera/CameraMessage;->arg2:I

    .line 46
    iput-object v0, p0, Ltas/camera/CameraMessage;->args:[I

    .line 47
    iput-object v0, p0, Ltas/camera/CameraMessage;->str1:Ljava/lang/String;

    .line 48
    iput-object v0, p0, Ltas/camera/CameraMessage;->str2:Ljava/lang/String;

    .line 49
    iput-object v0, p0, Ltas/camera/CameraMessage;->bytes:[B

    .line 50
    iput-object v0, p0, Ltas/camera/CameraMessage;->extra:Landroid/os/Bundle;

    .line 42
    return-void
.end method

.method public copy(Ltas/camera/CameraMessage;)V
    .locals 1
    .param p1, "that"    # Ltas/camera/CameraMessage;

    .prologue
    .line 32
    iget v0, p1, Ltas/camera/CameraMessage;->what:I

    iput v0, p0, Ltas/camera/CameraMessage;->what:I

    .line 33
    iget v0, p1, Ltas/camera/CameraMessage;->arg1:I

    iput v0, p0, Ltas/camera/CameraMessage;->arg1:I

    .line 34
    iget v0, p1, Ltas/camera/CameraMessage;->arg2:I

    iput v0, p0, Ltas/camera/CameraMessage;->arg2:I

    .line 35
    iget-object v0, p1, Ltas/camera/CameraMessage;->args:[I

    iput-object v0, p0, Ltas/camera/CameraMessage;->args:[I

    .line 36
    iget-object v0, p1, Ltas/camera/CameraMessage;->str1:Ljava/lang/String;

    iput-object v0, p0, Ltas/camera/CameraMessage;->str1:Ljava/lang/String;

    .line 37
    iget-object v0, p1, Ltas/camera/CameraMessage;->str2:Ljava/lang/String;

    iput-object v0, p0, Ltas/camera/CameraMessage;->str2:Ljava/lang/String;

    .line 38
    iget-object v0, p1, Ltas/camera/CameraMessage;->bytes:[B

    iput-object v0, p0, Ltas/camera/CameraMessage;->bytes:[B

    .line 39
    iget-object v0, p1, Ltas/camera/CameraMessage;->extra:Landroid/os/Bundle;

    iput-object v0, p0, Ltas/camera/CameraMessage;->extra:Landroid/os/Bundle;

    .line 31
    return-void
.end method

.method public readFromParcel(Landroid/os/Parcel;)V
    .locals 4
    .param p1, "source"    # Landroid/os/Parcel;

    .prologue
    .line 80
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v2

    iput v2, p0, Ltas/camera/CameraMessage;->what:I

    .line 81
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v2

    iput v2, p0, Ltas/camera/CameraMessage;->arg1:I

    .line 82
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v2

    iput v2, p0, Ltas/camera/CameraMessage;->arg2:I

    .line 83
    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v2

    iput-object v2, p0, Ltas/camera/CameraMessage;->str1:Ljava/lang/String;

    .line 84
    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v2

    iput-object v2, p0, Ltas/camera/CameraMessage;->str2:Ljava/lang/String;

    .line 88
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 89
    .local v1, "length":I
    if-lez v1, :cond_0

    .line 90
    new-array v2, v1, [I

    iput-object v2, p0, Ltas/camera/CameraMessage;->args:[I

    .line 92
    :try_start_0
    iget-object v2, p0, Ltas/camera/CameraMessage;->args:[I

    invoke-virtual {p1, v2}, Landroid/os/Parcel;->readIntArray([I)V
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    .line 97
    :cond_0
    :goto_0
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 98
    if-lez v1, :cond_1

    .line 99
    new-array v2, v1, [B

    iput-object v2, p0, Ltas/camera/CameraMessage;->bytes:[B

    .line 101
    :try_start_1
    iget-object v2, p0, Ltas/camera/CameraMessage;->bytes:[B

    invoke-virtual {p1, v2}, Landroid/os/Parcel;->readByteArray([B)V
    :try_end_1
    .catch Ljava/lang/RuntimeException; {:try_start_1 .. :try_end_1} :catch_1

    .line 106
    :cond_1
    :goto_1
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v2

    const/4 v3, 0x1

    if-ne v2, v3, :cond_2

    .line 107
    invoke-virtual {p1}, Landroid/os/Parcel;->readBundle()Landroid/os/Bundle;

    move-result-object v2

    iput-object v2, p0, Ltas/camera/CameraMessage;->extra:Landroid/os/Bundle;

    .line 79
    :cond_2
    return-void

    .line 93
    :catch_0
    move-exception v0

    .line 94
    .local v0, "e":Ljava/lang/RuntimeException;
    invoke-virtual {v0}, Ljava/lang/RuntimeException;->printStackTrace()V

    goto :goto_0

    .line 102
    .end local v0    # "e":Ljava/lang/RuntimeException;
    :catch_1
    move-exception v0

    .line 103
    .restart local v0    # "e":Ljava/lang/RuntimeException;
    invoke-virtual {v0}, Ljava/lang/RuntimeException;->printStackTrace()V

    goto :goto_1
.end method

.method public toString()Ljava/lang/String;
    .locals 3

    .prologue
    .line 113
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 114
    .local v0, "sb":Ljava/lang/StringBuilder;
    const-string/jumbo v1, "what="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget v2, p0, Ltas/camera/CameraMessage;->what:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 115
    const-string/jumbo v1, " arg1="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget v2, p0, Ltas/camera/CameraMessage;->arg1:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 116
    const-string/jumbo v1, " arg2="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget v2, p0, Ltas/camera/CameraMessage;->arg2:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 117
    const-string/jumbo v1, " str1="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Ltas/camera/CameraMessage;->str1:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 118
    const-string/jumbo v1, " str2="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Ltas/camera/CameraMessage;->str2:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 119
    const-string/jumbo v1, " extra="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Ltas/camera/CameraMessage;->extra:Landroid/os/Bundle;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 120
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    return-object v1
.end method

.method public writeToParcel(Landroid/os/Parcel;)V
    .locals 2
    .param p1, "dest"    # Landroid/os/Parcel;

    .prologue
    const/4 v1, 0x0

    .line 54
    iget v0, p0, Ltas/camera/CameraMessage;->what:I

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->writeInt(I)V

    .line 55
    iget v0, p0, Ltas/camera/CameraMessage;->arg1:I

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->writeInt(I)V

    .line 56
    iget v0, p0, Ltas/camera/CameraMessage;->arg2:I

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->writeInt(I)V

    .line 57
    iget-object v0, p0, Ltas/camera/CameraMessage;->str1:Ljava/lang/String;

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    .line 58
    iget-object v0, p0, Ltas/camera/CameraMessage;->str2:Ljava/lang/String;

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    .line 59
    iget-object v0, p0, Ltas/camera/CameraMessage;->args:[I

    if-eqz v0, :cond_0

    .line 60
    iget-object v0, p0, Ltas/camera/CameraMessage;->args:[I

    array-length v0, v0

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->writeInt(I)V

    .line 61
    iget-object v0, p0, Ltas/camera/CameraMessage;->args:[I

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->writeIntArray([I)V

    .line 65
    :goto_0
    iget-object v0, p0, Ltas/camera/CameraMessage;->bytes:[B

    if-eqz v0, :cond_1

    .line 66
    iget-object v0, p0, Ltas/camera/CameraMessage;->bytes:[B

    array-length v0, v0

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->writeInt(I)V

    .line 67
    iget-object v0, p0, Ltas/camera/CameraMessage;->bytes:[B

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->writeByteArray([B)V

    .line 71
    :goto_1
    iget-object v0, p0, Ltas/camera/CameraMessage;->extra:Landroid/os/Bundle;

    if-eqz v0, :cond_2

    .line 72
    const/4 v0, 0x1

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->writeInt(I)V

    .line 73
    iget-object v0, p0, Ltas/camera/CameraMessage;->extra:Landroid/os/Bundle;

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->writeBundle(Landroid/os/Bundle;)V

    .line 53
    :goto_2
    return-void

    .line 63
    :cond_0
    invoke-virtual {p1, v1}, Landroid/os/Parcel;->writeInt(I)V

    goto :goto_0

    .line 69
    :cond_1
    invoke-virtual {p1, v1}, Landroid/os/Parcel;->writeInt(I)V

    goto :goto_1

    .line 75
    :cond_2
    invoke-virtual {p1, v1}, Landroid/os/Parcel;->writeInt(I)V

    goto :goto_2
.end method
