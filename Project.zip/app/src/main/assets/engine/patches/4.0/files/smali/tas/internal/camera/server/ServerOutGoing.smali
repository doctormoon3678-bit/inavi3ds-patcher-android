.class public Ltas/internal/camera/server/ServerOutGoing;
.super Ljava/lang/Object;
.source "ServerOutGoing.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ltas/internal/camera/server/ServerOutGoing$Client;
    }
.end annotation


# static fields
.field private static final DBG:Z = true

.field private static final TAG:Ljava/lang/String; = "TasCAM<Server>"


# instance fields
.field private final mClients:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List",
            "<",
            "Ltas/internal/camera/server/ServerOutGoing$Client;",
            ">;"
        }
    .end annotation
.end field

.field private mContext:Landroid/content/Context;

.field private final mLock:Ljava/lang/Object;


# direct methods
.method static synthetic -wrap0(Ltas/internal/camera/server/ServerOutGoing;Ltas/internal/camera/server/ServerOutGoing$Client;)V
    .locals 0
    .param p1, "client"    # Ltas/internal/camera/server/ServerOutGoing$Client;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/camera/server/ServerOutGoing;->removeClient(Ltas/internal/camera/server/ServerOutGoing$Client;)V

    return-void
.end method

.method constructor <init>(Landroid/content/Context;)V
    .locals 1
    .param p1, "context"    # Landroid/content/Context;

    .prologue
    .line 29
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 25
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Ltas/internal/camera/server/ServerOutGoing;->mClients:Ljava/util/List;

    .line 26
    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, Ltas/internal/camera/server/ServerOutGoing;->mLock:Ljava/lang/Object;

    .line 30
    iput-object p1, p0, Ltas/internal/camera/server/ServerOutGoing;->mContext:Landroid/content/Context;

    .line 29
    return-void
.end method

.method private addClient(Ltas/internal/camera/server/ServerOutGoing$Client;)V
    .locals 4
    .param p1, "client"    # Ltas/internal/camera/server/ServerOutGoing$Client;

    .prologue
    .line 216
    iget-object v1, p0, Ltas/internal/camera/server/ServerOutGoing;->mLock:Ljava/lang/Object;

    monitor-enter v1

    .line 217
    :try_start_0
    iget-object v0, p0, Ltas/internal/camera/server/ServerOutGoing;->mClients:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_0

    .line 218
    invoke-static {p1}, Ltas/internal/camera/server/ServerOutGoing$Client;->-wrap5(Ltas/internal/camera/server/ServerOutGoing$Client;)V

    .line 219
    iget-object v0, p0, Ltas/internal/camera/server/ServerOutGoing;->mClients:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 220
    const-string/jumbo v0, "TasCAM<Server>"

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "add "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v2}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_0
    monitor-exit v1

    .line 215
    return-void

    .line 216
    :catchall_0
    move-exception v0

    monitor-exit v1

    throw v0
.end method

.method private getClient(I)Ltas/internal/camera/server/ServerOutGoing$Client;
    .locals 4
    .param p1, "pid"    # I

    .prologue
    .line 194
    iget-object v3, p0, Ltas/internal/camera/server/ServerOutGoing;->mLock:Ljava/lang/Object;

    monitor-enter v3

    .line 195
    :try_start_0
    iget-object v2, p0, Ltas/internal/camera/server/ServerOutGoing;->mClients:Ljava/util/List;

    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    .local v1, "c$iterator":Ljava/util/Iterator;
    :cond_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/camera/server/ServerOutGoing$Client;

    .line 196
    .local v0, "c":Ltas/internal/camera/server/ServerOutGoing$Client;
    invoke-static {v0}, Ltas/internal/camera/server/ServerOutGoing$Client;->-wrap3(Ltas/internal/camera/server/ServerOutGoing$Client;)I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    move-result v2

    if-ne v2, p1, :cond_0

    monitor-exit v3

    .line 197
    return-object v0

    .line 200
    .end local v0    # "c":Ltas/internal/camera/server/ServerOutGoing$Client;
    :cond_1
    const/4 v2, 0x0

    monitor-exit v3

    return-object v2

    .line 194
    .end local v1    # "c$iterator":Ljava/util/Iterator;
    :catchall_0
    move-exception v2

    monitor-exit v3

    throw v2
.end method

.method private getClient(Ljava/lang/String;)Ltas/internal/camera/server/ServerOutGoing$Client;
    .locals 4
    .param p1, "procName"    # Ljava/lang/String;

    .prologue
    .line 205
    iget-object v3, p0, Ltas/internal/camera/server/ServerOutGoing;->mLock:Ljava/lang/Object;

    monitor-enter v3

    .line 206
    :try_start_0
    iget-object v2, p0, Ltas/internal/camera/server/ServerOutGoing;->mClients:Ljava/util/List;

    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    .local v1, "c$iterator":Ljava/util/Iterator;
    :cond_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/camera/server/ServerOutGoing$Client;

    .line 207
    .local v0, "c":Ltas/internal/camera/server/ServerOutGoing$Client;
    invoke-static {v0, p1}, Ltas/internal/camera/server/ServerOutGoing$Client;->-wrap2(Ltas/internal/camera/server/ServerOutGoing$Client;Ljava/lang/String;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    move-result v2

    if-eqz v2, :cond_0

    monitor-exit v3

    .line 208
    return-object v0

    .line 211
    .end local v0    # "c":Ltas/internal/camera/server/ServerOutGoing$Client;
    :cond_1
    const/4 v2, 0x0

    monitor-exit v3

    return-object v2

    .line 205
    .end local v1    # "c$iterator":Ljava/util/Iterator;
    :catchall_0
    move-exception v2

    monitor-exit v3

    throw v2
.end method

.method private removeClient(Ltas/internal/camera/server/ServerOutGoing$Client;)V
    .locals 4
    .param p1, "client"    # Ltas/internal/camera/server/ServerOutGoing$Client;

    .prologue
    .line 226
    iget-object v1, p0, Ltas/internal/camera/server/ServerOutGoing;->mLock:Ljava/lang/Object;

    monitor-enter v1

    .line 227
    :try_start_0
    iget-object v0, p0, Ltas/internal/camera/server/ServerOutGoing;->mClients:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 228
    invoke-static {p1}, Ltas/internal/camera/server/ServerOutGoing$Client;->-wrap14(Ltas/internal/camera/server/ServerOutGoing$Client;)V

    .line 229
    invoke-static {p1}, Ltas/internal/camera/server/ServerOutGoing$Client;->-wrap12(Ltas/internal/camera/server/ServerOutGoing$Client;)V

    .line 230
    iget-object v0, p0, Ltas/internal/camera/server/ServerOutGoing;->mClients:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->remove(Ljava/lang/Object;)Z

    .line 231
    const-string/jumbo v0, "TasCAM<Server>"

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "remove "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v2}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_0
    monitor-exit v1

    .line 225
    return-void

    .line 226
    :catchall_0
    move-exception v0

    monitor-exit v1

    throw v0
.end method


# virtual methods
.method public addClientCallback(ILtas/internal/camera/server/IServerCallback;)V
    .locals 6
    .param p1, "pid"    # I
    .param p2, "cb"    # Ltas/internal/camera/server/IServerCallback;

    .prologue
    const/4 v5, 0x0

    .line 59
    iget-object v2, p0, Ltas/internal/camera/server/ServerOutGoing;->mContext:Landroid/content/Context;

    invoke-static {v2, p1}, Ltas/internal/camera/util/SystemUtil;->getRunningAppProcesses(Landroid/content/Context;I)Landroid/app/ActivityManager$RunningAppProcessInfo;

    move-result-object v1

    .line 60
    .local v1, "proc":Landroid/app/ActivityManager$RunningAppProcessInfo;
    if-nez v1, :cond_0

    .line 61
    const-string/jumbo v2, "TasCAM<Server>"

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v4, "getRunningAppProcessInfo failed (pid="

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 62
    return-void

    .line 65
    :cond_0
    invoke-direct {p0, p1}, Ltas/internal/camera/server/ServerOutGoing;->getClient(I)Ltas/internal/camera/server/ServerOutGoing$Client;

    move-result-object v0

    .line 66
    .local v0, "client":Ltas/internal/camera/server/ServerOutGoing$Client;
    if-eqz v0, :cond_3

    .line 67
    iget-object v2, v1, Landroid/app/ActivityManager$RunningAppProcessInfo;->processName:Ljava/lang/String;

    invoke-static {v0, v2}, Ltas/internal/camera/server/ServerOutGoing$Client;->-wrap2(Ltas/internal/camera/server/ServerOutGoing$Client;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1

    .line 68
    const-string/jumbo v2, "TasCAM<Server>"

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v4, "pid="

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string/jumbo v4, " already setup its callback."

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 76
    :cond_1
    :goto_0
    if-eqz v0, :cond_2

    .line 77
    invoke-direct {p0, v0}, Ltas/internal/camera/server/ServerOutGoing;->removeClient(Ltas/internal/camera/server/ServerOutGoing$Client;)V

    .line 79
    :cond_2
    new-instance v2, Ltas/internal/camera/server/ServerOutGoing$Client;

    invoke-direct {v2, p0, v1, p2, v5}, Ltas/internal/camera/server/ServerOutGoing$Client;-><init>(Ltas/internal/camera/server/ServerOutGoing;Landroid/app/ActivityManager$RunningAppProcessInfo;Ltas/internal/camera/server/IServerCallback;Ltas/internal/camera/server/ServerOutGoing$Client;)V

    invoke-direct {p0, v2}, Ltas/internal/camera/server/ServerOutGoing;->addClient(Ltas/internal/camera/server/ServerOutGoing$Client;)V

    .line 57
    return-void

    .line 73
    :cond_3
    iget-object v2, v1, Landroid/app/ActivityManager$RunningAppProcessInfo;->processName:Ljava/lang/String;

    invoke-direct {p0, v2}, Ltas/internal/camera/server/ServerOutGoing;->getClient(Ljava/lang/String;)Ltas/internal/camera/server/ServerOutGoing$Client;

    move-result-object v0

    goto :goto_0
.end method

.method public addClientConcern(ILjava/lang/String;)V
    .locals 4
    .param p1, "pid"    # I
    .param p2, "cam"    # Ljava/lang/String;

    .prologue
    .line 83
    invoke-direct {p0, p1}, Ltas/internal/camera/server/ServerOutGoing;->getClient(I)Ltas/internal/camera/server/ServerOutGoing$Client;

    move-result-object v0

    .line 84
    .local v0, "client":Ltas/internal/camera/server/ServerOutGoing$Client;
    if-nez v0, :cond_0

    .line 85
    const-string/jumbo v1, "TasCAM<Server>"

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "unknown pid="

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 86
    return-void

    .line 89
    :cond_0
    invoke-static {v0, p2}, Ltas/internal/camera/server/ServerOutGoing$Client;->-wrap15(Ltas/internal/camera/server/ServerOutGoing$Client;Ljava/lang/String;)V

    .line 82
    return-void
.end method

.method getClientName(I)Ljava/lang/String;
    .locals 2
    .param p1, "pid"    # I

    .prologue
    const/4 v1, 0x0

    .line 189
    invoke-direct {p0, p1}, Ltas/internal/camera/server/ServerOutGoing;->getClient(I)Ltas/internal/camera/server/ServerOutGoing$Client;

    move-result-object v0

    .line 190
    .local v0, "client":Ltas/internal/camera/server/ServerOutGoing$Client;
    if-eqz v0, :cond_0

    invoke-static {v0}, Ltas/internal/camera/server/ServerOutGoing$Client;->-wrap4(Ltas/internal/camera/server/ServerOutGoing$Client;)Ljava/lang/String;

    move-result-object v1

    :cond_0
    return-object v1
.end method

.method public getContext()Landroid/content/Context;
    .locals 1

    .prologue
    .line 34
    iget-object v0, p0, Ltas/internal/camera/server/ServerOutGoing;->mContext:Landroid/content/Context;

    return-object v0
.end method

.method public isClientConcern(ILjava/lang/String;)Z
    .locals 4
    .param p1, "pid"    # I
    .param p2, "cam"    # Ljava/lang/String;

    .prologue
    .line 103
    invoke-direct {p0, p1}, Ltas/internal/camera/server/ServerOutGoing;->getClient(I)Ltas/internal/camera/server/ServerOutGoing$Client;

    move-result-object v0

    .line 104
    .local v0, "client":Ltas/internal/camera/server/ServerOutGoing$Client;
    if-nez v0, :cond_0

    .line 105
    const-string/jumbo v1, "TasCAM<Server>"

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "unknown pid="

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 106
    const/4 v1, 0x0

    return v1

    .line 109
    :cond_0
    invoke-static {v0, p2}, Ltas/internal/camera/server/ServerOutGoing$Client;->-wrap1(Ltas/internal/camera/server/ServerOutGoing$Client;Ljava/lang/String;)Z

    move-result v1

    return v1
.end method

.method public isClientConcern(Ljava/lang/String;Ljava/lang/String;)Z
    .locals 4
    .param p1, "proc"    # Ljava/lang/String;
    .param p2, "cam"    # Ljava/lang/String;

    .prologue
    .line 113
    invoke-direct {p0, p1}, Ltas/internal/camera/server/ServerOutGoing;->getClient(Ljava/lang/String;)Ltas/internal/camera/server/ServerOutGoing$Client;

    move-result-object v0

    .line 114
    .local v0, "client":Ltas/internal/camera/server/ServerOutGoing$Client;
    if-nez v0, :cond_0

    .line 115
    const-string/jumbo v1, "TasCAM<Server>"

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "unknown proc="

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 116
    const/4 v1, 0x0

    return v1

    .line 119
    :cond_0
    invoke-static {v0, p2}, Ltas/internal/camera/server/ServerOutGoing$Client;->-wrap1(Ltas/internal/camera/server/ServerOutGoing$Client;Ljava/lang/String;)Z

    move-result v1

    return v1
.end method

.method public isClientRunning(I)Z
    .locals 4
    .param p1, "pid"    # I

    .prologue
    .line 38
    invoke-direct {p0, p1}, Ltas/internal/camera/server/ServerOutGoing;->getClient(I)Ltas/internal/camera/server/ServerOutGoing$Client;

    move-result-object v0

    .line 39
    .local v0, "client":Ltas/internal/camera/server/ServerOutGoing$Client;
    if-nez v0, :cond_0

    .line 40
    const-string/jumbo v1, "TasCAM<Server>"

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "unknown pid="

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 41
    const/4 v1, 0x0

    return v1

    .line 44
    :cond_0
    invoke-static {v0}, Ltas/internal/camera/server/ServerOutGoing$Client;->-wrap0(Ltas/internal/camera/server/ServerOutGoing$Client;)Z

    move-result v1

    return v1
.end method

.method public isClientRunning(Ljava/lang/String;)Z
    .locals 4
    .param p1, "pkg"    # Ljava/lang/String;

    .prologue
    .line 48
    invoke-direct {p0, p1}, Ltas/internal/camera/server/ServerOutGoing;->getClient(Ljava/lang/String;)Ltas/internal/camera/server/ServerOutGoing$Client;

    move-result-object v0

    .line 49
    .local v0, "client":Ltas/internal/camera/server/ServerOutGoing$Client;
    if-nez v0, :cond_0

    .line 50
    const-string/jumbo v1, "TasCAM<Server>"

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "unknown pkg="

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 51
    const/4 v1, 0x0

    return v1

    .line 54
    :cond_0
    invoke-static {v0}, Ltas/internal/camera/server/ServerOutGoing$Client;->-wrap0(Ltas/internal/camera/server/ServerOutGoing$Client;)Z

    move-result v1

    return v1
.end method

.method notifyInitialState(ILjava/lang/String;Ltas/internal/camera/InputSource;)V
    .locals 9
    .param p1, "pid"    # I
    .param p2, "cam"    # Ljava/lang/String;
    .param p3, "input"    # Ltas/internal/camera/InputSource;

    .prologue
    const/4 v5, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x0

    .line 164
    invoke-static {}, Ltas/internal/camera/server/RemoteMessage;->obtain()Ltas/internal/camera/server/RemoteMessage;

    move-result-object v2

    .line 165
    .local v2, "ev":Ltas/internal/camera/server/RemoteMessage;
    iget-object v3, v2, Ltas/internal/camera/server/RemoteMessage;->params:Ltas/internal/camera/InputParams;

    .line 166
    .local v3, "params":Ltas/internal/camera/InputParams;
    iput-object p2, v3, Ltas/internal/camera/InputParams;->cam:Ljava/lang/String;

    .line 167
    iput p1, v3, Ltas/internal/camera/InputParams;->pid:I

    .line 168
    iput v6, v3, Ltas/internal/camera/InputParams;->what:I

    .line 169
    iget-object v8, v3, Ltas/internal/camera/InputParams;->msg:Ltas/camera/CameraMessage;

    if-eqz p3, :cond_0

    invoke-virtual {p3}, Ltas/internal/camera/InputSource;->isPlugged()Z

    move-result v4

    if-eqz v4, :cond_0

    move v4, v5

    :goto_0
    iput v4, v8, Ltas/camera/CameraMessage;->arg1:I

    .line 170
    iget-object v4, v3, Ltas/internal/camera/InputParams;->msg:Ltas/camera/CameraMessage;

    if-eqz p3, :cond_1

    invoke-virtual {p3}, Ltas/internal/camera/InputSource;->isOpened()Z

    move-result v8

    if-eqz v8, :cond_1

    :goto_1
    iput v5, v4, Ltas/camera/CameraMessage;->arg2:I

    .line 171
    iget-object v5, v3, Ltas/internal/camera/InputParams;->msg:Ltas/camera/CameraMessage;

    if-eqz p3, :cond_2

    invoke-virtual {p3}, Ltas/internal/camera/InputSource;->camid()Ljava/lang/String;

    move-result-object v4

    :goto_2
    iput-object v4, v5, Ltas/camera/CameraMessage;->str1:Ljava/lang/String;

    .line 173
    iget-object v5, p0, Ltas/internal/camera/server/ServerOutGoing;->mLock:Ljava/lang/Object;

    monitor-enter v5

    .line 174
    if-nez p1, :cond_3

    .line 175
    :try_start_0
    iget-object v4, p0, Ltas/internal/camera/server/ServerOutGoing;->mClients:Ljava/util/List;

    invoke-interface {v4}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    .local v1, "client$iterator":Ljava/util/Iterator;
    :goto_3
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_4

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/camera/server/ServerOutGoing$Client;

    .line 176
    .local v0, "client":Ltas/internal/camera/server/ServerOutGoing$Client;
    invoke-static {v0, v2}, Ltas/internal/camera/server/ServerOutGoing$Client;->-wrap10(Ltas/internal/camera/server/ServerOutGoing$Client;Ltas/internal/camera/server/RemoteMessage;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_3

    .line 173
    .end local v0    # "client":Ltas/internal/camera/server/ServerOutGoing$Client;
    .end local v1    # "client$iterator":Ljava/util/Iterator;
    :catchall_0
    move-exception v4

    monitor-exit v5

    throw v4

    :cond_0
    move v4, v6

    .line 169
    goto :goto_0

    :cond_1
    move v5, v6

    .line 170
    goto :goto_1

    :cond_2
    move-object v4, v7

    .line 171
    goto :goto_2

    .line 179
    :cond_3
    :try_start_1
    invoke-direct {p0, p1}, Ltas/internal/camera/server/ServerOutGoing;->getClient(I)Ltas/internal/camera/server/ServerOutGoing$Client;

    move-result-object v0

    .line 180
    .restart local v0    # "client":Ltas/internal/camera/server/ServerOutGoing$Client;
    if-eqz v0, :cond_4

    .line 181
    invoke-static {v0, v2}, Ltas/internal/camera/server/ServerOutGoing$Client;->-wrap10(Ltas/internal/camera/server/ServerOutGoing$Client;Ltas/internal/camera/server/RemoteMessage;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .end local v0    # "client":Ltas/internal/camera/server/ServerOutGoing$Client;
    :cond_4
    monitor-exit v5

    .line 185
    invoke-virtual {v2}, Ltas/internal/camera/server/RemoteMessage;->recycle()V

    .line 163
    return-void
.end method

.method public post(Ltas/internal/camera/server/RemoteMessage;)V
    .locals 6
    .param p1, "msg"    # Ltas/internal/camera/server/RemoteMessage;

    .prologue
    .line 123
    iget-object v3, p0, Ltas/internal/camera/server/ServerOutGoing;->mLock:Ljava/lang/Object;

    monitor-enter v3

    .line 124
    :try_start_0
    iget-object v2, p1, Ltas/internal/camera/server/RemoteMessage;->params:Ltas/internal/camera/InputParams;

    iget v2, v2, Ltas/internal/camera/InputParams;->what:I

    packed-switch v2, :pswitch_data_0

    .line 156
    const-string/jumbo v2, "TasCAM<Server>"

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v5, "invalid notifyid="

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    iget-object v5, p1, Ltas/internal/camera/server/RemoteMessage;->params:Ltas/internal/camera/InputParams;

    iget v5, v5, Ltas/internal/camera/InputParams;->what:I

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v2, v4}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_0
    monitor-exit v3

    .line 122
    return-void

    .line 126
    :pswitch_0
    :try_start_1
    iget-object v2, p0, Ltas/internal/camera/server/ServerOutGoing;->mClients:Ljava/util/List;

    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    .local v1, "client$iterator":Ljava/util/Iterator;
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_0

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/camera/server/ServerOutGoing$Client;

    .line 127
    .local v0, "client":Ltas/internal/camera/server/ServerOutGoing$Client;
    invoke-static {v0, p1}, Ltas/internal/camera/server/ServerOutGoing$Client;->-wrap6(Ltas/internal/camera/server/ServerOutGoing$Client;Ltas/internal/camera/server/RemoteMessage;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_0

    .line 123
    .end local v0    # "client":Ltas/internal/camera/server/ServerOutGoing$Client;
    .end local v1    # "client$iterator":Ljava/util/Iterator;
    :catchall_0
    move-exception v2

    monitor-exit v3

    throw v2

    .line 132
    :pswitch_1
    :try_start_2
    iget-object v2, p0, Ltas/internal/camera/server/ServerOutGoing;->mClients:Ljava/util/List;

    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    .restart local v1    # "client$iterator":Ljava/util/Iterator;
    :goto_1
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_0

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/camera/server/ServerOutGoing$Client;

    .line 133
    .restart local v0    # "client":Ltas/internal/camera/server/ServerOutGoing$Client;
    invoke-static {v0, p1}, Ltas/internal/camera/server/ServerOutGoing$Client;->-wrap8(Ltas/internal/camera/server/ServerOutGoing$Client;Ltas/internal/camera/server/RemoteMessage;)V

    goto :goto_1

    .line 138
    .end local v0    # "client":Ltas/internal/camera/server/ServerOutGoing$Client;
    .end local v1    # "client$iterator":Ljava/util/Iterator;
    :pswitch_2
    iget-object v2, p0, Ltas/internal/camera/server/ServerOutGoing;->mClients:Ljava/util/List;

    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    .restart local v1    # "client$iterator":Ljava/util/Iterator;
    :goto_2
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_0

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/camera/server/ServerOutGoing$Client;

    .line 139
    .restart local v0    # "client":Ltas/internal/camera/server/ServerOutGoing$Client;
    invoke-static {v0, p1}, Ltas/internal/camera/server/ServerOutGoing$Client;->-wrap7(Ltas/internal/camera/server/ServerOutGoing$Client;Ltas/internal/camera/server/RemoteMessage;)V

    goto :goto_2

    .line 144
    .end local v0    # "client":Ltas/internal/camera/server/ServerOutGoing$Client;
    .end local v1    # "client$iterator":Ljava/util/Iterator;
    :pswitch_3
    iget-object v2, p0, Ltas/internal/camera/server/ServerOutGoing;->mClients:Ljava/util/List;

    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    .restart local v1    # "client$iterator":Ljava/util/Iterator;
    :goto_3
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_0

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/camera/server/ServerOutGoing$Client;

    .line 145
    .restart local v0    # "client":Ltas/internal/camera/server/ServerOutGoing$Client;
    invoke-static {v0, p1}, Ltas/internal/camera/server/ServerOutGoing$Client;->-wrap9(Ltas/internal/camera/server/ServerOutGoing$Client;Ltas/internal/camera/server/RemoteMessage;)V

    goto :goto_3

    .line 150
    .end local v0    # "client":Ltas/internal/camera/server/ServerOutGoing$Client;
    .end local v1    # "client$iterator":Ljava/util/Iterator;
    :pswitch_4
    iget-object v2, p0, Ltas/internal/camera/server/ServerOutGoing;->mClients:Ljava/util/List;

    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    .restart local v1    # "client$iterator":Ljava/util/Iterator;
    :goto_4
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_0

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/camera/server/ServerOutGoing$Client;

    .line 151
    .restart local v0    # "client":Ltas/internal/camera/server/ServerOutGoing$Client;
    invoke-static {v0, p1}, Ltas/internal/camera/server/ServerOutGoing$Client;->-wrap11(Ltas/internal/camera/server/ServerOutGoing$Client;Ltas/internal/camera/server/RemoteMessage;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    goto :goto_4

    .line 124
    nop

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_0
        :pswitch_1
        :pswitch_2
        :pswitch_3
        :pswitch_4
    .end packed-switch
.end method

.method public removeClientConcern(ILjava/lang/String;)V
    .locals 4
    .param p1, "pid"    # I
    .param p2, "cam"    # Ljava/lang/String;

    .prologue
    .line 93
    invoke-direct {p0, p1}, Ltas/internal/camera/server/ServerOutGoing;->getClient(I)Ltas/internal/camera/server/ServerOutGoing$Client;

    move-result-object v0

    .line 94
    .local v0, "client":Ltas/internal/camera/server/ServerOutGoing$Client;
    if-nez v0, :cond_0

    .line 95
    const-string/jumbo v1, "TasCAM<Server>"

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "unknown pid="

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 96
    return-void

    .line 99
    :cond_0
    invoke-static {v0, p2}, Ltas/internal/camera/server/ServerOutGoing$Client;->-wrap13(Ltas/internal/camera/server/ServerOutGoing$Client;Ljava/lang/String;)V

    .line 92
    return-void
.end method
