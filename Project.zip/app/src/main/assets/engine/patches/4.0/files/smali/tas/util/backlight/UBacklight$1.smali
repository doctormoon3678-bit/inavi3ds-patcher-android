.class Ltas/util/backlight/UBacklight$1;
.super Landroid/database/ContentObserver;
.source "UBacklight.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ltas/util/backlight/UBacklight;->registerObserverLocked(Landroid/content/Context;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Ltas/util/backlight/UBacklight;

.field final synthetic val$c:Landroid/content/Context;


# direct methods
.method constructor <init>(Ltas/util/backlight/UBacklight;Landroid/os/Handler;Landroid/content/Context;)V
    .locals 0
    .param p1, "this$0"    # Ltas/util/backlight/UBacklight;
    .param p2, "$anonymous0"    # Landroid/os/Handler;
    .param p3, "val$c"    # Landroid/content/Context;

    .prologue
    .line 134
    iput-object p1, p0, Ltas/util/backlight/UBacklight$1;->this$0:Ltas/util/backlight/UBacklight;

    iput-object p3, p0, Ltas/util/backlight/UBacklight$1;->val$c:Landroid/content/Context;

    invoke-direct {p0, p2}, Landroid/database/ContentObserver;-><init>(Landroid/os/Handler;)V

    return-void
.end method


# virtual methods
.method public onChange(ZLandroid/net/Uri;)V
    .locals 6
    .param p1, "selfChange"    # Z
    .param p2, "uri"    # Landroid/net/Uri;

    .prologue
    .line 137
    const-class v4, Ltas/util/backlight/UBacklight;

    monitor-enter v4

    .line 138
    if-eqz p1, :cond_0

    monitor-exit v4

    return-void

    .line 139
    :cond_0
    :try_start_0
    iget-object v3, p0, Ltas/util/backlight/UBacklight$1;->val$c:Landroid/content/Context;

    const/4 v5, -0x1

    invoke-static {v3, v5}, Ltas/util/backlight/UBacklight;->getBrightness(Landroid/content/Context;I)I

    move-result v0

    .line 140
    .local v0, "br":I
    iget-object v3, p0, Ltas/util/backlight/UBacklight$1;->this$0:Ltas/util/backlight/UBacklight;

    invoke-static {v3}, Ltas/util/backlight/UBacklight;->-get0(Ltas/util/backlight/UBacklight;)Ljava/util/List;

    move-result-object v3

    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v2

    .local v2, "o$iterator":Ljava/util/Iterator;
    :cond_1
    :goto_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_2

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ltas/util/backlight/UBacklight$BrightnessObserver;

    .line 141
    .local v1, "o":Ltas/util/backlight/UBacklight$BrightnessObserver;
    if-eqz v1, :cond_1

    invoke-interface {v1, v0}, Ltas/util/backlight/UBacklight$BrightnessObserver;->onUBrightnessRequested(I)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    .line 137
    .end local v0    # "br":I
    .end local v1    # "o":Ltas/util/backlight/UBacklight$BrightnessObserver;
    .end local v2    # "o$iterator":Ljava/util/Iterator;
    :catchall_0
    move-exception v3

    monitor-exit v4

    throw v3

    .restart local v0    # "br":I
    .restart local v2    # "o$iterator":Ljava/util/Iterator;
    :cond_2
    monitor-exit v4

    .line 136
    return-void
.end method
