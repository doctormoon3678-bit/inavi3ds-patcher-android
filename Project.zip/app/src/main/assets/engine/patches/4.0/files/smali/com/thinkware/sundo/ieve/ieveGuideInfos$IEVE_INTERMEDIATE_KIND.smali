.class public final enum Lcom/thinkware/sundo/ieve/ieveGuideInfos$IEVE_INTERMEDIATE_KIND;
.super Ljava/lang/Enum;
.source "ieveGuideInfos.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/thinkware/sundo/ieve/ieveGuideInfos;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "IEVE_INTERMEDIATE_KIND"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum",
        "<",
        "Lcom/thinkware/sundo/ieve/ieveGuideInfos$IEVE_INTERMEDIATE_KIND;",
        ">;"
    }
.end annotation


# static fields
.field public static final enum IEVE_INTERMEDIATE_LOCATION:Lcom/thinkware/sundo/ieve/ieveGuideInfos$IEVE_INTERMEDIATE_KIND;

.field public static final enum NONE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$IEVE_INTERMEDIATE_KIND;

.field private static final synthetic b:[Lcom/thinkware/sundo/ieve/ieveGuideInfos$IEVE_INTERMEDIATE_KIND;


# instance fields
.field private final a:I


# direct methods
.method static constructor <clinit>()V
    .locals 5

    .prologue
    const/4 v4, 0x1

    const/4 v3, 0x0

    .line 107
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$IEVE_INTERMEDIATE_KIND;

    const-string v1, "NONE"

    invoke-direct {v0, v1, v3, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$IEVE_INTERMEDIATE_KIND;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$IEVE_INTERMEDIATE_KIND;->NONE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$IEVE_INTERMEDIATE_KIND;

    .line 108
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$IEVE_INTERMEDIATE_KIND;

    const-string v1, "IEVE_INTERMEDIATE_LOCATION"

    const/16 v2, 0x3e7

    invoke-direct {v0, v1, v4, v2}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$IEVE_INTERMEDIATE_KIND;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$IEVE_INTERMEDIATE_KIND;->IEVE_INTERMEDIATE_LOCATION:Lcom/thinkware/sundo/ieve/ieveGuideInfos$IEVE_INTERMEDIATE_KIND;

    .line 106
    const/4 v0, 0x2

    new-array v0, v0, [Lcom/thinkware/sundo/ieve/ieveGuideInfos$IEVE_INTERMEDIATE_KIND;

    sget-object v1, Lcom/thinkware/sundo/ieve/ieveGuideInfos$IEVE_INTERMEDIATE_KIND;->NONE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$IEVE_INTERMEDIATE_KIND;

    aput-object v1, v0, v3

    sget-object v1, Lcom/thinkware/sundo/ieve/ieveGuideInfos$IEVE_INTERMEDIATE_KIND;->IEVE_INTERMEDIATE_LOCATION:Lcom/thinkware/sundo/ieve/ieveGuideInfos$IEVE_INTERMEDIATE_KIND;

    aput-object v1, v0, v4

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$IEVE_INTERMEDIATE_KIND;->b:[Lcom/thinkware/sundo/ieve/ieveGuideInfos$IEVE_INTERMEDIATE_KIND;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .locals 0
    .param p3, "value"    # I

    .prologue
    .line 110
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    iput p3, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$IEVE_INTERMEDIATE_KIND;->a:I

    return-void
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/thinkware/sundo/ieve/ieveGuideInfos$IEVE_INTERMEDIATE_KIND;
    .locals 1

    .prologue
    .line 1
    const-class v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$IEVE_INTERMEDIATE_KIND;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object v0

    check-cast v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$IEVE_INTERMEDIATE_KIND;

    return-object v0
.end method

.method public static values()[Lcom/thinkware/sundo/ieve/ieveGuideInfos$IEVE_INTERMEDIATE_KIND;
    .locals 4

    .prologue
    const/4 v3, 0x0

    .line 1
    sget-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$IEVE_INTERMEDIATE_KIND;->b:[Lcom/thinkware/sundo/ieve/ieveGuideInfos$IEVE_INTERMEDIATE_KIND;

    array-length v1, v0

    new-array v2, v1, [Lcom/thinkware/sundo/ieve/ieveGuideInfos$IEVE_INTERMEDIATE_KIND;

    invoke-static {v0, v3, v2, v3, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    return-object v2
.end method


# virtual methods
.method public getValue()I
    .locals 1

    .prologue
    .line 112
    iget v0, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$IEVE_INTERMEDIATE_KIND;->a:I

    return v0
.end method
