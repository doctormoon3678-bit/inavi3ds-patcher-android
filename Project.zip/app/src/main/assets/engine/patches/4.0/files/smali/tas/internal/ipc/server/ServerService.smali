.class public Ltas/internal/ipc/server/ServerService;
.super Landroid/app/Service;
.source "ServerService.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ltas/internal/ipc/server/ServerService$RemoteProxy;
    }
.end annotation


# static fields
.field private static final DBG:Z = true

.field private static final TAG:Ljava/lang/String; = "TasIPC<ServerService>"


# instance fields
.field private mBinder:Landroid/os/IBinder;

.field private mMgr:Ltas/internal/ipc/server/ServerManager;


# direct methods
.method static synthetic -get0(Ltas/internal/ipc/server/ServerService;)Ltas/internal/ipc/server/ServerManager;
    .locals 1

    iget-object v0, p0, Ltas/internal/ipc/server/ServerService;->mMgr:Ltas/internal/ipc/server/ServerManager;

    return-object v0
.end method

.method public constructor <init>()V
    .locals 0

    .prologue
    .line 19
    invoke-direct {p0}, Landroid/app/Service;-><init>()V

    return-void
.end method


# virtual methods
.method public onBind(Landroid/content/Intent;)Landroid/os/IBinder;
    .locals 2
    .param p1, "intent"    # Landroid/content/Intent;

    .prologue
    .line 47
    const-string/jumbo v0, "TasIPC<ServerService>"

    const-string/jumbo v1, "bind"

    invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 48
    iget-object v0, p0, Ltas/internal/ipc/server/ServerService;->mBinder:Landroid/os/IBinder;

    return-object v0
.end method

.method public onCreate()V
    .locals 1

    .prologue
    .line 29
    invoke-static {}, Ltas/internal/ipc/BuildConfig;->printVersion()V

    .line 31
    new-instance v0, Ltas/internal/ipc/server/ServerManager;

    invoke-direct {v0}, Ltas/internal/ipc/server/ServerManager;-><init>()V

    iput-object v0, p0, Ltas/internal/ipc/server/ServerService;->mMgr:Ltas/internal/ipc/server/ServerManager;

    .line 32
    new-instance v0, Ltas/internal/ipc/server/ServerService$RemoteProxy;

    invoke-direct {v0, p0}, Ltas/internal/ipc/server/ServerService$RemoteProxy;-><init>(Ltas/internal/ipc/server/ServerService;)V

    iput-object v0, p0, Ltas/internal/ipc/server/ServerService;->mBinder:Landroid/os/IBinder;

    .line 28
    return-void
.end method

.method public onDestroy()V
    .locals 2

    .prologue
    .line 42
    const-string/jumbo v0, "TasIPC<ServerService>"

    const-string/jumbo v1, "server is stopped."

    invoke-static {v0, v1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 41
    return-void
.end method

.method public onRebind(Landroid/content/Intent;)V
    .locals 2
    .param p1, "intent"    # Landroid/content/Intent;

    .prologue
    .line 53
    const-string/jumbo v0, "TasIPC<ServerService>"

    const-string/jumbo v1, "rebind"

    invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 52
    return-void
.end method

.method public onStartCommand(Landroid/content/Intent;II)I
    .locals 1
    .param p1, "intent"    # Landroid/content/Intent;
    .param p2, "flags"    # I
    .param p3, "startId"    # I

    .prologue
    .line 37
    const/4 v0, 0x1

    return v0
.end method

.method public onUnbind(Landroid/content/Intent;)Z
    .locals 2
    .param p1, "intent"    # Landroid/content/Intent;

    .prologue
    .line 58
    const-string/jumbo v0, "TasIPC<ServerService>"

    const-string/jumbo v1, "unbind"

    invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 59
    const/4 v0, 0x1

    return v0
.end method
