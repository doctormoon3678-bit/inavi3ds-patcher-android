.class Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;
.super Ltas/internal/ipc/server/RemoteReceiver;
.source "ReceiverManager.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltas/internal/ipc/ReceiverManager;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = "ReceiverWrapper"
.end annotation


# instance fields
.field private mExtra:Landroid/os/Bundle;

.field private final mListeners:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List",
            "<",
            "Ltas/internal/ipc/Receiver;",
            ">;"
        }
    .end annotation
.end field

.field private mRepliers:Landroid/util/ArrayMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/util/ArrayMap",
            "<",
            "Ljava/lang/Long;",
            "Ltas/internal/ipc/ReceiverManager$Replier;",
            ">;"
        }
    .end annotation
.end field

.field private final mSenders:Landroid/util/ArrayMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/util/ArrayMap",
            "<",
            "Ljava/lang/Long;",
            "Ltas/internal/ipc/server/RemoteSender;",
            ">;"
        }
    .end annotation
.end field

.field private mWatchAnonymous:Z

.field private mWatchAnonymousRef:I

.field private final mWatchRef:Landroid/util/ArrayMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/util/ArrayMap",
            "<",
            "Ljava/lang/String;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic this$0:Ltas/internal/ipc/ReceiverManager;


# direct methods
.method static synthetic -get0(Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;)Landroid/os/Bundle;
    .locals 1

    iget-object v0, p0, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->mExtra:Landroid/os/Bundle;

    return-object v0
.end method

.method static synthetic -get1(Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;)Ljava/util/List;
    .locals 1

    iget-object v0, p0, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->mListeners:Ljava/util/List;

    return-object v0
.end method

.method static synthetic -get2(Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;)Landroid/util/ArrayMap;
    .locals 1

    iget-object v0, p0, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->mSenders:Landroid/util/ArrayMap;

    return-object v0
.end method

.method static synthetic -get3(Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;)Z
    .locals 1

    iget-boolean v0, p0, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->mWatchAnonymous:Z

    return v0
.end method

.method static synthetic -get4(Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;)I
    .locals 1

    iget v0, p0, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->mWatchAnonymousRef:I

    return v0
.end method

.method static synthetic -get5(Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;)Landroid/util/ArrayMap;
    .locals 1

    iget-object v0, p0, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->mWatchRef:Landroid/util/ArrayMap;

    return-object v0
.end method

.method static synthetic -set0(Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;Landroid/os/Bundle;)Landroid/os/Bundle;
    .locals 0

    iput-object p1, p0, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->mExtra:Landroid/os/Bundle;

    return-object p1
.end method

.method static synthetic -set1(Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;Z)Z
    .locals 0

    iput-boolean p1, p0, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->mWatchAnonymous:Z

    return p1
.end method

.method static synthetic -set2(Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;I)I
    .locals 0

    iput p1, p0, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->mWatchAnonymousRef:I

    return p1
.end method

.method static synthetic -wrap0(Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;)V
    .locals 0

    invoke-direct {p0}, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->clearSenders()V

    return-void
.end method

.method static synthetic -wrap1(Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;Ltas/internal/ipc/server/RemoteMessage;)V
    .locals 0
    .param p1, "rmsg"    # Ltas/internal/ipc/server/RemoteMessage;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->onReceive(Ltas/internal/ipc/server/RemoteMessage;)V

    return-void
.end method

.method static synthetic -wrap2(Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;Ltas/internal/ipc/server/RemoteSender;)V
    .locals 0
    .param p1, "sender"    # Ltas/internal/ipc/server/RemoteSender;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->onSenderOffline(Ltas/internal/ipc/server/RemoteSender;)V

    return-void
.end method

.method static synthetic -wrap3(Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;Ltas/internal/ipc/server/RemoteSender;)V
    .locals 0
    .param p1, "sender"    # Ltas/internal/ipc/server/RemoteSender;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->onSenderOnline(Ltas/internal/ipc/server/RemoteSender;)V

    return-void
.end method

.method static synthetic -wrap4(Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;Ltas/internal/ipc/server/RemoteSender;)V
    .locals 0
    .param p1, "sender"    # Ltas/internal/ipc/server/RemoteSender;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->onSenderUpdate(Ltas/internal/ipc/server/RemoteSender;)V

    return-void
.end method

.method private constructor <init>(Ltas/internal/ipc/ReceiverManager;Ltas/internal/ipc/Receiver;)V
    .locals 3
    .param p1, "this$0"    # Ltas/internal/ipc/ReceiverManager;
    .param p2, "receiver"    # Ltas/internal/ipc/Receiver;

    .prologue
    const/4 v0, 0x0

    .line 407
    iput-object p1, p0, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->this$0:Ltas/internal/ipc/ReceiverManager;

    .line 408
    iget-object v1, p2, Ltas/internal/ipc/Receiver;->pkg:Ljava/lang/String;

    iget-object v2, p2, Ltas/internal/ipc/Receiver;->name:Ljava/lang/String;

    invoke-direct {p0, v1, v2}, Ltas/internal/ipc/server/RemoteReceiver;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 393
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 392
    iput-object v1, p0, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->mListeners:Ljava/util/List;

    .line 396
    new-instance v1, Landroid/util/ArrayMap;

    invoke-direct {v1}, Landroid/util/ArrayMap;-><init>()V

    .line 395
    iput-object v1, p0, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->mSenders:Landroid/util/ArrayMap;

    .line 399
    new-instance v1, Landroid/util/ArrayMap;

    invoke-direct {v1}, Landroid/util/ArrayMap;-><init>()V

    .line 398
    iput-object v1, p0, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->mWatchRef:Landroid/util/ArrayMap;

    .line 402
    iput v0, p0, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->mWatchAnonymousRef:I

    .line 409
    iget-object v1, p2, Ltas/internal/ipc/Receiver;->srvcls:Ljava/lang/Class;

    if-eqz v1, :cond_0

    const/4 v0, 0x1

    :cond_0
    iput-boolean v0, p0, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->p2pMode:Z

    .line 407
    return-void
.end method

.method synthetic constructor <init>(Ltas/internal/ipc/ReceiverManager;Ltas/internal/ipc/Receiver;Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;)V
    .locals 0
    .param p1, "this$0"    # Ltas/internal/ipc/ReceiverManager;
    .param p2, "receiver"    # Ltas/internal/ipc/Receiver;

    .prologue
    invoke-direct {p0, p1, p2}, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;-><init>(Ltas/internal/ipc/ReceiverManager;Ltas/internal/ipc/Receiver;)V

    return-void
.end method

.method private addReplier(JLtas/internal/ipc/ReceiverManager$Replier;)V
    .locals 3
    .param p1, "id"    # J
    .param p3, "replier"    # Ltas/internal/ipc/ReceiverManager$Replier;

    .prologue
    .line 455
    iget-object v0, p0, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->mRepliers:Landroid/util/ArrayMap;

    if-nez v0, :cond_0

    .line 456
    new-instance v0, Landroid/util/ArrayMap;

    invoke-direct {v0}, Landroid/util/ArrayMap;-><init>()V

    iput-object v0, p0, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->mRepliers:Landroid/util/ArrayMap;

    .line 458
    :cond_0
    iget-object v0, p0, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->mRepliers:Landroid/util/ArrayMap;

    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    invoke-virtual {v0, v1, p3}, Landroid/util/ArrayMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 454
    return-void
.end method

.method private clearSenders()V
    .locals 6

    .prologue
    .line 536
    iget-object v5, p0, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->mSenders:Landroid/util/ArrayMap;

    invoke-virtual {v5}, Landroid/util/ArrayMap;->isEmpty()Z

    move-result v5

    if-eqz v5, :cond_0

    .line 537
    return-void

    .line 539
    :cond_0
    iget-object v5, p0, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->mSenders:Landroid/util/ArrayMap;

    invoke-virtual {v5}, Landroid/util/ArrayMap;->values()Ljava/util/Collection;

    move-result-object v4

    .line 540
    .local v4, "senders":Ljava/util/Collection;, "Ljava/util/Collection<Ltas/internal/ipc/server/RemoteSender;>;"
    invoke-interface {v4}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v3

    .local v3, "s$iterator":Ljava/util/Iterator;
    :cond_1
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_4

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ltas/internal/ipc/server/RemoteSender;

    .line 541
    .local v2, "s":Ltas/internal/ipc/server/RemoteSender;
    iget-object v5, p0, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->mListeners:Ljava/util/List;

    invoke-interface {v5}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    .local v1, "r$iterator":Ljava/util/Iterator;
    :cond_2
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_1

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/ipc/Receiver;

    .line 542
    .local v0, "r":Ltas/internal/ipc/Receiver;
    if-eqz v0, :cond_2

    if-eqz v2, :cond_2

    .line 543
    iget-object v5, v2, Ltas/internal/ipc/server/RemoteSender;->name:Ljava/lang/String;

    invoke-virtual {v0, v5}, Ltas/internal/ipc/Receiver;->isWatchingSender(Ljava/lang/String;)Z

    move-result v5

    if-nez v5, :cond_3

    .line 544
    invoke-virtual {v0}, Ltas/internal/ipc/Receiver;->hasAnonymousSession()Z

    move-result v5

    .line 542
    if-eqz v5, :cond_2

    .line 545
    :cond_3
    iget-object v5, p0, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->this$0:Ltas/internal/ipc/ReceiverManager;

    invoke-static {v5, v0, v2}, Ltas/internal/ipc/ReceiverManager;->-wrap0(Ltas/internal/ipc/ReceiverManager;Ltas/internal/ipc/Receiver;Ltas/internal/ipc/server/RemoteSender;)V

    goto :goto_0

    .line 535
    .end local v0    # "r":Ltas/internal/ipc/Receiver;
    .end local v1    # "r$iterator":Ljava/util/Iterator;
    .end local v2    # "s":Ltas/internal/ipc/server/RemoteSender;
    :cond_4
    return-void
.end method

.method private getReplier(J)Ltas/internal/ipc/ReceiverManager$Replier;
    .locals 3
    .param p1, "id"    # J

    .prologue
    const/4 v0, 0x0

    .line 450
    iget-object v1, p0, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->mRepliers:Landroid/util/ArrayMap;

    if-eqz v1, :cond_0

    .line 451
    iget-object v0, p0, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->mRepliers:Landroid/util/ArrayMap;

    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/util/ArrayMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/ipc/ReceiverManager$Replier;

    .line 450
    :cond_0
    return-object v0
.end method

.method private getReplier(Ltas/ipc/ReceiverSession;)Ltas/internal/ipc/ReceiverManager$Replier;
    .locals 2
    .param p1, "session"    # Ltas/ipc/ReceiverSession;

    .prologue
    .line 446
    iget-wide v0, p1, Ltas/ipc/ReceiverSession;->id:J

    invoke-direct {p0, v0, v1}, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->getReplier(J)Ltas/internal/ipc/ReceiverManager$Replier;

    move-result-object v0

    return-object v0
.end method

.method private onReceive(Ltas/internal/ipc/server/RemoteMessage;)V
    .locals 5
    .param p1, "rmsg"    # Ltas/internal/ipc/server/RemoteMessage;

    .prologue
    .line 524
    iget-object v3, p1, Ltas/internal/ipc/server/RemoteMessage;->sender:Ltas/internal/ipc/server/RemoteSender;

    .line 525
    .local v3, "sender":Ltas/internal/ipc/server/RemoteSender;
    iget-object v2, p1, Ltas/internal/ipc/server/RemoteMessage;->receiver:Ltas/internal/ipc/server/RemoteReceiver;

    .line 527
    .local v2, "receiver":Ltas/internal/ipc/server/RemoteReceiver;
    iget-object v4, p0, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->mListeners:Ljava/util/List;

    invoke-interface {v4}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    .local v1, "r$iterator":Ljava/util/Iterator;
    :cond_0
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_2

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/ipc/Receiver;

    .line 528
    .local v0, "r":Ltas/internal/ipc/Receiver;
    if-eqz v0, :cond_0

    iget-object v4, v3, Ltas/internal/ipc/server/RemoteSender;->name:Ljava/lang/String;

    invoke-virtual {v0, v4}, Ltas/internal/ipc/Receiver;->isWatchingSender(Ljava/lang/String;)Z

    move-result v4

    if-nez v4, :cond_1

    .line 529
    invoke-virtual {v0}, Ltas/internal/ipc/Receiver;->hasAnonymousSession()Z

    move-result v4

    .line 528
    if-eqz v4, :cond_0

    .line 530
    :cond_1
    iget-object v4, p0, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->this$0:Ltas/internal/ipc/ReceiverManager;

    invoke-static {v4, v0, p1}, Ltas/internal/ipc/ReceiverManager;->-wrap2(Ltas/internal/ipc/ReceiverManager;Ltas/internal/ipc/Receiver;Ltas/internal/ipc/server/RemoteMessage;)V

    goto :goto_0

    .line 523
    .end local v0    # "r":Ltas/internal/ipc/Receiver;
    :cond_2
    return-void
.end method

.method private onSenderOffline(Ltas/internal/ipc/server/RemoteSender;)V
    .locals 6
    .param p1, "sender"    # Ltas/internal/ipc/server/RemoteSender;

    .prologue
    .line 503
    iget-object v2, p0, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->mSenders:Landroid/util/ArrayMap;

    invoke-virtual {p1}, Ltas/internal/ipc/server/RemoteSender;->getid()J

    move-result-wide v4

    invoke-static {v4, v5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/util/ArrayMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 504
    invoke-direct {p0, p1}, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->unsetReplier(Ltas/internal/ipc/server/RemoteSender;)V

    .line 506
    iget-object v2, p0, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->mListeners:Ljava/util/List;

    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    .local v1, "r$iterator":Ljava/util/Iterator;
    :cond_0
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_2

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/ipc/Receiver;

    .line 507
    .local v0, "r":Ltas/internal/ipc/Receiver;
    if-eqz v0, :cond_0

    iget-object v2, p1, Ltas/internal/ipc/server/RemoteSender;->name:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ltas/internal/ipc/Receiver;->isWatchingSender(Ljava/lang/String;)Z

    move-result v2

    if-nez v2, :cond_1

    .line 508
    invoke-virtual {v0}, Ltas/internal/ipc/Receiver;->hasAnonymousSession()Z

    move-result v2

    .line 507
    if-eqz v2, :cond_0

    .line 509
    :cond_1
    iget-object v2, p0, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->this$0:Ltas/internal/ipc/ReceiverManager;

    invoke-static {v2, v0, p1}, Ltas/internal/ipc/ReceiverManager;->-wrap0(Ltas/internal/ipc/ReceiverManager;Ltas/internal/ipc/Receiver;Ltas/internal/ipc/server/RemoteSender;)V

    goto :goto_0

    .line 502
    .end local v0    # "r":Ltas/internal/ipc/Receiver;
    :cond_2
    return-void
.end method

.method private onSenderOnline(Ltas/internal/ipc/server/RemoteSender;)V
    .locals 6
    .param p1, "sender"    # Ltas/internal/ipc/server/RemoteSender;

    .prologue
    .line 491
    iget-object v2, p0, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->mSenders:Landroid/util/ArrayMap;

    invoke-virtual {p1}, Ltas/internal/ipc/server/RemoteSender;->getid()J

    move-result-wide v4

    invoke-static {v4, v5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v3

    invoke-virtual {v2, v3, p1}, Landroid/util/ArrayMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 492
    invoke-direct {p0, p1}, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->setReplier(Ltas/internal/ipc/server/RemoteSender;)V

    .line 494
    iget-object v2, p0, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->mListeners:Ljava/util/List;

    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    .local v1, "r$iterator":Ljava/util/Iterator;
    :cond_0
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_2

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/ipc/Receiver;

    .line 495
    .local v0, "r":Ltas/internal/ipc/Receiver;
    if-eqz v0, :cond_0

    iget-object v2, p1, Ltas/internal/ipc/server/RemoteSender;->name:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ltas/internal/ipc/Receiver;->isWatchingSender(Ljava/lang/String;)Z

    move-result v2

    if-nez v2, :cond_1

    .line 496
    invoke-virtual {v0}, Ltas/internal/ipc/Receiver;->hasAnonymousSession()Z

    move-result v2

    .line 495
    if-eqz v2, :cond_0

    .line 497
    :cond_1
    iget-object v2, p0, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->this$0:Ltas/internal/ipc/ReceiverManager;

    invoke-static {v2, v0, p1}, Ltas/internal/ipc/ReceiverManager;->-wrap1(Ltas/internal/ipc/ReceiverManager;Ltas/internal/ipc/Receiver;Ltas/internal/ipc/server/RemoteSender;)V

    goto :goto_0

    .line 490
    .end local v0    # "r":Ltas/internal/ipc/Receiver;
    :cond_2
    return-void
.end method

.method private onSenderUpdate(Ltas/internal/ipc/server/RemoteSender;)V
    .locals 3
    .param p1, "sender"    # Ltas/internal/ipc/server/RemoteSender;

    .prologue
    .line 515
    iget-object v2, p0, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->mListeners:Ljava/util/List;

    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    .local v1, "r$iterator":Ljava/util/Iterator;
    :cond_0
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_2

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/ipc/Receiver;

    .line 516
    .local v0, "r":Ltas/internal/ipc/Receiver;
    if-eqz v0, :cond_0

    iget-object v2, p1, Ltas/internal/ipc/server/RemoteSender;->name:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ltas/internal/ipc/Receiver;->isWatchingSender(Ljava/lang/String;)Z

    move-result v2

    if-nez v2, :cond_1

    .line 517
    invoke-virtual {v0}, Ltas/internal/ipc/Receiver;->hasAnonymousSession()Z

    move-result v2

    .line 516
    if-eqz v2, :cond_0

    .line 518
    :cond_1
    iget-object v2, p0, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->this$0:Ltas/internal/ipc/ReceiverManager;

    invoke-static {v2, v0, p1}, Ltas/internal/ipc/ReceiverManager;->-wrap3(Ltas/internal/ipc/ReceiverManager;Ltas/internal/ipc/Receiver;Ltas/internal/ipc/server/RemoteSender;)V

    goto :goto_0

    .line 514
    .end local v0    # "r":Ltas/internal/ipc/Receiver;
    :cond_2
    return-void
.end method

.method private removeReplier(J)Z
    .locals 3
    .param p1, "id"    # J

    .prologue
    const/4 v0, 0x0

    .line 462
    iget-object v1, p0, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->mRepliers:Landroid/util/ArrayMap;

    if-eqz v1, :cond_0

    .line 463
    iget-object v1, p0, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->mRepliers:Landroid/util/ArrayMap;

    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/util/ArrayMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    if-eqz v1, :cond_0

    const/4 v0, 0x1

    .line 462
    :cond_0
    return v0
.end method

.method private setReplier(Ltas/internal/ipc/server/RemoteSender;)V
    .locals 4
    .param p1, "sender"    # Ltas/internal/ipc/server/RemoteSender;

    .prologue
    .line 467
    iget-object v1, p1, Ltas/internal/ipc/server/RemoteSender;->replier:Landroid/os/IBinder;

    if-nez v1, :cond_0

    .line 468
    return-void

    .line 470
    :cond_0
    invoke-virtual {p1}, Ltas/internal/ipc/server/RemoteSender;->getid()J

    move-result-wide v2

    invoke-direct {p0, v2, v3}, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->getReplier(J)Ltas/internal/ipc/ReceiverManager$Replier;

    move-result-object v0

    .line 471
    .local v0, "replier":Ltas/internal/ipc/ReceiverManager$Replier;
    if-nez v0, :cond_1

    .line 473
    const-string/jumbo v1, "TasIPC<ReceiverManager>"

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "["

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, p1, Ltas/internal/ipc/server/RemoteSender;->name:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string/jumbo v3, "] replier setup."

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 476
    new-instance v0, Ltas/internal/ipc/ReceiverManager$Replier;

    .end local v0    # "replier":Ltas/internal/ipc/ReceiverManager$Replier;
    iget-object v1, p0, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->this$0:Ltas/internal/ipc/ReceiverManager;

    new-instance v2, Ltas/internal/ipc/server/RemoteSender;

    invoke-direct {v2, p1}, Ltas/internal/ipc/server/RemoteSender;-><init>(Ltas/internal/ipc/server/RemoteSender;)V

    invoke-direct {v0, v1, v2, p0}, Ltas/internal/ipc/ReceiverManager$Replier;-><init>(Ltas/internal/ipc/ReceiverManager;Ltas/internal/ipc/server/RemoteSender;Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;)V

    .line 477
    .restart local v0    # "replier":Ltas/internal/ipc/ReceiverManager$Replier;
    invoke-virtual {p1}, Ltas/internal/ipc/server/RemoteSender;->getid()J

    move-result-wide v2

    invoke-direct {p0, v2, v3, v0}, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->addReplier(JLtas/internal/ipc/ReceiverManager$Replier;)V

    .line 466
    :cond_1
    return-void
.end method

.method private unsetReplier(Ltas/internal/ipc/server/RemoteSender;)V
    .locals 3
    .param p1, "sender"    # Ltas/internal/ipc/server/RemoteSender;

    .prologue
    .line 483
    invoke-virtual {p1}, Ltas/internal/ipc/server/RemoteSender;->getid()J

    move-result-wide v0

    invoke-direct {p0, v0, v1}, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->removeReplier(J)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 485
    const-string/jumbo v0, "TasIPC<ReceiverManager>"

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "["

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p1, Ltas/internal/ipc/server/RemoteSender;->name:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string/jumbo v2, "] replier unset."

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 482
    :cond_0
    return-void
.end method


# virtual methods
.method declared-synchronized reply(Ltas/internal/ipc/Receiver;Ltas/ipc/ReceiverSession;Ltas/ipc/MsgData;)V
    .locals 3
    .param p1, "receiver"    # Ltas/internal/ipc/Receiver;
    .param p2, "session"    # Ltas/ipc/ReceiverSession;
    .param p3, "msg"    # Ltas/ipc/MsgData;

    .prologue
    monitor-enter p0

    .line 429
    :try_start_0
    iget-boolean v1, p1, Ltas/internal/ipc/Receiver;->mOnline:Z

    if-nez v1, :cond_0

    .line 430
    const-string/jumbo v1, "TasIPC<ReceiverManager>"

    const-string/jumbo v2, "receiver is offline"

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 431
    invoke-virtual {p3}, Ltas/ipc/MsgData;->recycle()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit p0

    .line 432
    return-void

    .line 435
    :cond_0
    :try_start_1
    invoke-direct {p0, p2}, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->getReplier(Ltas/ipc/ReceiverSession;)Ltas/internal/ipc/ReceiverManager$Replier;

    move-result-object v0

    .line 436
    .local v0, "replier":Ltas/internal/ipc/ReceiverManager$Replier;
    if-nez v0, :cond_1

    .line 437
    const-string/jumbo v1, "TasIPC<ReceiverManager>"

    const-string/jumbo v2, "replier not found."

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 438
    invoke-virtual {p3}, Ltas/ipc/MsgData;->recycle()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    monitor-exit p0

    .line 439
    return-void

    .line 442
    :cond_1
    :try_start_2
    invoke-virtual {v0, p3}, Ltas/internal/ipc/ReceiverManager$Replier;->reply(Ltas/ipc/MsgData;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    monitor-exit p0

    .line 428
    return-void

    .end local v0    # "replier":Ltas/internal/ipc/ReceiverManager$Replier;
    :catchall_0
    move-exception v1

    monitor-exit p0

    throw v1
.end method

.method declared-synchronized update(Ltas/internal/ipc/Receiver;)V
    .locals 3
    .param p1, "receiver"    # Ltas/internal/ipc/Receiver;

    .prologue
    monitor-enter p0

    .line 413
    :try_start_0
    iget-boolean v2, p1, Ltas/internal/ipc/Receiver;->mOnline:Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-nez v2, :cond_0

    monitor-exit p0

    .line 414
    return-void

    .line 417
    :cond_0
    :try_start_1
    iget-object v2, p1, Ltas/internal/ipc/Receiver;->mExtra:Landroid/os/Bundle;

    iput-object v2, p0, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->mExtra:Landroid/os/Bundle;

    iput-object v2, p0, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->extra:Landroid/os/Bundle;

    .line 418
    iget-object v2, p0, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->mListeners:Ljava/util/List;

    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    .local v1, "r$iterator":Ljava/util/Iterator;
    :cond_1
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_2

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/ipc/Receiver;

    .line 419
    .local v0, "r":Ltas/internal/ipc/Receiver;
    if-eqz v0, :cond_1

    if-eq v0, p1, :cond_1

    .line 420
    iget-object v2, p0, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->mExtra:Landroid/os/Bundle;

    iput-object v2, v0, Ltas/internal/ipc/Receiver;->mExtra:Landroid/os/Bundle;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_0

    .end local v0    # "r":Ltas/internal/ipc/Receiver;
    .end local v1    # "r$iterator":Ljava/util/Iterator;
    :catchall_0
    move-exception v2

    monitor-exit p0

    throw v2

    .line 424
    .restart local v1    # "r$iterator":Ljava/util/Iterator;
    :cond_2
    :try_start_2
    iget-object v2, p0, Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;->this$0:Ltas/internal/ipc/ReceiverManager;

    invoke-static {v2, p0}, Ltas/internal/ipc/ReceiverManager;->-wrap5(Ltas/internal/ipc/ReceiverManager;Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    monitor-exit p0

    .line 412
    return-void
.end method
