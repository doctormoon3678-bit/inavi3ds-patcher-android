.class public Ltas/ipc/TransceiverSession;
.super Ljava/lang/Object;
.source "TransceiverSession.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ltas/ipc/TransceiverSession$Callback;,
        Ltas/ipc/TransceiverSession$SimpleCallback;
    }
.end annotation


# instance fields
.field public cb:Ltas/ipc/TransceiverSession$Callback;

.field public name:Ljava/lang/String;

.field public pkg:Ljava/lang/String;

.field public r:Ltas/ipc/ReceiverSession;

.field public s:Ltas/ipc/SenderSession;


# direct methods
.method public constructor <init>(Ltas/ipc/TransceiverSession$Callback;)V
    .locals 0
    .param p1, "_cb"    # Ltas/ipc/TransceiverSession$Callback;

    .prologue
    .line 21
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 22
    iput-object p1, p0, Ltas/ipc/TransceiverSession;->cb:Ltas/ipc/TransceiverSession$Callback;

    .line 21
    return-void
.end method


# virtual methods
.method public destroy()V
    .locals 1

    .prologue
    .line 34
    iget-object v0, p0, Ltas/ipc/TransceiverSession;->s:Ltas/ipc/SenderSession;

    if-eqz v0, :cond_0

    iget-object v0, p0, Ltas/ipc/TransceiverSession;->s:Ltas/ipc/SenderSession;

    invoke-virtual {v0}, Ltas/ipc/SenderSession;->destroy()V

    .line 35
    :cond_0
    iget-object v0, p0, Ltas/ipc/TransceiverSession;->r:Ltas/ipc/ReceiverSession;

    if-eqz v0, :cond_1

    iget-object v0, p0, Ltas/ipc/TransceiverSession;->r:Ltas/ipc/ReceiverSession;

    invoke-virtual {v0}, Ltas/ipc/ReceiverSession;->destroy()V

    .line 33
    :cond_1
    return-void
.end method

.method public getReplier(I)Ltas/ipc/ReplierSession;
    .locals 2
    .param p1, "what"    # I

    .prologue
    const/4 v0, 0x0

    .line 118
    iget-object v1, p0, Ltas/ipc/TransceiverSession;->r:Ltas/ipc/ReceiverSession;

    if-eqz v1, :cond_0

    iget-object v0, p0, Ltas/ipc/TransceiverSession;->r:Ltas/ipc/ReceiverSession;

    invoke-virtual {v0, p1}, Ltas/ipc/ReceiverSession;->getReplier(I)Ltas/ipc/ReplierSession;

    move-result-object v0

    :cond_0
    return-object v0
.end method

.method public isReceiverOnline()Z
    .locals 1

    .prologue
    .line 30
    iget-object v0, p0, Ltas/ipc/TransceiverSession;->r:Ltas/ipc/ReceiverSession;

    if-eqz v0, :cond_0

    iget-object v0, p0, Ltas/ipc/TransceiverSession;->r:Ltas/ipc/ReceiverSession;

    iget-boolean v0, v0, Ltas/ipc/ReceiverSession;->online:Z

    :goto_0
    return v0

    :cond_0
    const/4 v0, 0x0

    goto :goto_0
.end method

.method public isSenderOnline()Z
    .locals 1

    .prologue
    .line 26
    iget-object v0, p0, Ltas/ipc/TransceiverSession;->s:Ltas/ipc/SenderSession;

    if-eqz v0, :cond_0

    iget-object v0, p0, Ltas/ipc/TransceiverSession;->s:Ltas/ipc/SenderSession;

    iget-boolean v0, v0, Ltas/ipc/SenderSession;->online:Z

    :goto_0
    return v0

    :cond_0
    const/4 v0, 0x0

    goto :goto_0
.end method

.method public send(I)V
    .locals 1
    .param p1, "what"    # I

    .prologue
    .line 44
    iget-object v0, p0, Ltas/ipc/TransceiverSession;->s:Ltas/ipc/SenderSession;

    if-eqz v0, :cond_0

    iget-object v0, p0, Ltas/ipc/TransceiverSession;->s:Ltas/ipc/SenderSession;

    invoke-virtual {v0, p1}, Ltas/ipc/SenderSession;->send(I)V

    .line 43
    :cond_0
    return-void
.end method

.method public send(III)V
    .locals 1
    .param p1, "what"    # I
    .param p2, "arg1"    # I
    .param p3, "arg2"    # I

    .prologue
    .line 51
    iget-object v0, p0, Ltas/ipc/TransceiverSession;->s:Ltas/ipc/SenderSession;

    if-eqz v0, :cond_0

    iget-object v0, p0, Ltas/ipc/TransceiverSession;->s:Ltas/ipc/SenderSession;

    invoke-virtual {v0, p1, p2, p3}, Ltas/ipc/SenderSession;->send(III)V

    .line 50
    :cond_0
    return-void
.end method

.method public varargs send(III[I)V
    .locals 1
    .param p1, "what"    # I
    .param p2, "arg1"    # I
    .param p3, "arg2"    # I
    .param p4, "args"    # [I

    .prologue
    .line 58
    iget-object v0, p0, Ltas/ipc/TransceiverSession;->s:Ltas/ipc/SenderSession;

    if-eqz v0, :cond_0

    iget-object v0, p0, Ltas/ipc/TransceiverSession;->s:Ltas/ipc/SenderSession;

    invoke-virtual {v0, p1, p2, p3, p4}, Ltas/ipc/SenderSession;->send(III[I)V

    .line 57
    :cond_0
    return-void
.end method

.method public send(III[ILjava/lang/String;Ljava/lang/String;[BLandroid/os/Bundle;)V
    .locals 9
    .param p1, "what"    # I
    .param p2, "arg1"    # I
    .param p3, "arg2"    # I
    .param p4, "args"    # [I
    .param p5, "str1"    # Ljava/lang/String;
    .param p6, "str2"    # Ljava/lang/String;
    .param p7, "bytes"    # [B
    .param p8, "bundle"    # Landroid/os/Bundle;

    .prologue
    .line 102
    iget-object v0, p0, Ltas/ipc/TransceiverSession;->s:Ltas/ipc/SenderSession;

    if-eqz v0, :cond_0

    iget-object v0, p0, Ltas/ipc/TransceiverSession;->s:Ltas/ipc/SenderSession;

    move v1, p1

    move v2, p2

    move v3, p3

    move-object v4, p4

    move-object v5, p5

    move-object v6, p6

    move-object/from16 v7, p7

    move-object/from16 v8, p8

    invoke-virtual/range {v0 .. v8}, Ltas/ipc/SenderSession;->send(III[ILjava/lang/String;Ljava/lang/String;[BLandroid/os/Bundle;)V

    .line 101
    :cond_0
    return-void
.end method

.method public send(ILandroid/os/Bundle;)V
    .locals 1
    .param p1, "what"    # I
    .param p2, "bundle"    # Landroid/os/Bundle;

    .prologue
    .line 93
    iget-object v0, p0, Ltas/ipc/TransceiverSession;->s:Ltas/ipc/SenderSession;

    if-eqz v0, :cond_0

    iget-object v0, p0, Ltas/ipc/TransceiverSession;->s:Ltas/ipc/SenderSession;

    invoke-virtual {v0, p1, p2}, Ltas/ipc/SenderSession;->send(ILandroid/os/Bundle;)V

    .line 92
    :cond_0
    return-void
.end method

.method public send(ILjava/lang/String;)V
    .locals 1
    .param p1, "what"    # I
    .param p2, "str1"    # Ljava/lang/String;

    .prologue
    .line 65
    iget-object v0, p0, Ltas/ipc/TransceiverSession;->s:Ltas/ipc/SenderSession;

    if-eqz v0, :cond_0

    iget-object v0, p0, Ltas/ipc/TransceiverSession;->s:Ltas/ipc/SenderSession;

    invoke-virtual {v0, p1, p2}, Ltas/ipc/SenderSession;->send(ILjava/lang/String;)V

    .line 64
    :cond_0
    return-void
.end method

.method public send(ILjava/lang/String;Ljava/lang/String;)V
    .locals 1
    .param p1, "what"    # I
    .param p2, "str1"    # Ljava/lang/String;
    .param p3, "str2"    # Ljava/lang/String;

    .prologue
    .line 72
    iget-object v0, p0, Ltas/ipc/TransceiverSession;->s:Ltas/ipc/SenderSession;

    if-eqz v0, :cond_0

    iget-object v0, p0, Ltas/ipc/TransceiverSession;->s:Ltas/ipc/SenderSession;

    invoke-virtual {v0, p1, p2, p3}, Ltas/ipc/SenderSession;->send(ILjava/lang/String;Ljava/lang/String;)V

    .line 71
    :cond_0
    return-void
.end method

.method public send(I[B)V
    .locals 1
    .param p1, "what"    # I
    .param p2, "bytes"    # [B

    .prologue
    .line 86
    iget-object v0, p0, Ltas/ipc/TransceiverSession;->s:Ltas/ipc/SenderSession;

    if-eqz v0, :cond_0

    iget-object v0, p0, Ltas/ipc/TransceiverSession;->s:Ltas/ipc/SenderSession;

    invoke-virtual {v0, p1, p2}, Ltas/ipc/SenderSession;->send(I[B)V

    .line 85
    :cond_0
    return-void
.end method

.method public send(I[I)V
    .locals 1
    .param p1, "what"    # I
    .param p2, "args"    # [I

    .prologue
    .line 79
    iget-object v0, p0, Ltas/ipc/TransceiverSession;->s:Ltas/ipc/SenderSession;

    if-eqz v0, :cond_0

    iget-object v0, p0, Ltas/ipc/TransceiverSession;->s:Ltas/ipc/SenderSession;

    invoke-virtual {v0, p1, p2}, Ltas/ipc/SenderSession;->send(I[I)V

    .line 78
    :cond_0
    return-void
.end method

.method public send(Ltas/ipc/MsgData;)V
    .locals 1
    .param p1, "msg"    # Ltas/ipc/MsgData;

    .prologue
    .line 109
    iget-object v0, p0, Ltas/ipc/TransceiverSession;->s:Ltas/ipc/SenderSession;

    if-eqz v0, :cond_0

    iget-object v0, p0, Ltas/ipc/TransceiverSession;->s:Ltas/ipc/SenderSession;

    invoke-virtual {v0, p1}, Ltas/ipc/SenderSession;->send(Ltas/ipc/MsgData;)V

    .line 108
    :cond_0
    return-void
.end method

.method public toString()Ljava/lang/String;
    .locals 2

    .prologue
    .line 259
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 260
    .local v0, "sb":Ljava/lang/StringBuilder;
    iget-object v1, p0, Ltas/ipc/TransceiverSession;->s:Ltas/ipc/SenderSession;

    invoke-virtual {v1, v0}, Ltas/ipc/SenderSession;->dumpToString(Ljava/lang/StringBuilder;)Ljava/lang/StringBuilder;

    .line 261
    const-string/jumbo v1, " "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 262
    iget-object v1, p0, Ltas/ipc/TransceiverSession;->r:Ltas/ipc/ReceiverSession;

    invoke-virtual {v1, v0}, Ltas/ipc/ReceiverSession;->dumpToString(Ljava/lang/StringBuilder;)Ljava/lang/StringBuilder;

    .line 263
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    return-object v1
.end method
