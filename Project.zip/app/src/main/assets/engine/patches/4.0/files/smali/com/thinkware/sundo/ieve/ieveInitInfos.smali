.class public Lcom/thinkware/sundo/ieve/ieveInitInfos;
.super Ljava/lang/Object;
.source "ieveInitInfos.java"


# instance fields
.field public cameramodel:I

.field public captureimageheight:I

.field public captureimagewidth:I

.field public devicemodel:I

.field public encryptfolder:Ljava/lang/String;

.field public language:I

.field public pixelformat:I

.field public respath:Ljava/lang/String;

.field public sizescreenheight:I

.field public sizescreenwidth:I

.field public sizeviewheight:I

.field public sizeviewwidth:I

.field public sizeviewx:I

.field public sizeviewy:I

.field public uid:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .locals 2

    .prologue
    const/4 v1, 0x0

    .line 25
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    const-string v0, ""

    iput-object v0, p0, Lcom/thinkware/sundo/ieve/ieveInitInfos;->uid:Ljava/lang/String;

    .line 5
    const-string v0, ""

    iput-object v0, p0, Lcom/thinkware/sundo/ieve/ieveInitInfos;->respath:Ljava/lang/String;

    .line 6
    const-string v0, ""

    iput-object v0, p0, Lcom/thinkware/sundo/ieve/ieveInitInfos;->encryptfolder:Ljava/lang/String;

    .line 8
    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveInitInfos;->language:I

    .line 9
    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveInitInfos;->devicemodel:I

    .line 10
    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveInitInfos;->cameramodel:I

    .line 11
    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveInitInfos;->pixelformat:I

    .line 13
    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveInitInfos;->captureimagewidth:I

    .line 14
    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveInitInfos;->captureimageheight:I

    .line 16
    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveInitInfos;->sizescreenwidth:I

    .line 17
    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveInitInfos;->sizescreenheight:I

    .line 19
    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveInitInfos;->sizeviewx:I

    .line 20
    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveInitInfos;->sizeviewy:I

    .line 21
    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveInitInfos;->sizeviewwidth:I

    .line 22
    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveInitInfos;->sizeviewheight:I

    .line 26
    invoke-virtual {p0}, Lcom/thinkware/sundo/ieve/ieveInitInfos;->clear()V

    .line 27
    return-void
.end method


# virtual methods
.method public clear()V
    .locals 2

    .prologue
    const/4 v1, 0x0

    .line 30
    const-string v0, ""

    iput-object v0, p0, Lcom/thinkware/sundo/ieve/ieveInitInfos;->uid:Ljava/lang/String;

    .line 31
    const-string v0, ""

    iput-object v0, p0, Lcom/thinkware/sundo/ieve/ieveInitInfos;->respath:Ljava/lang/String;

    .line 32
    const-string v0, ""

    iput-object v0, p0, Lcom/thinkware/sundo/ieve/ieveInitInfos;->encryptfolder:Ljava/lang/String;

    .line 34
    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveInitInfos;->language:I

    .line 35
    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveInitInfos;->cameramodel:I

    .line 36
    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveInitInfos;->pixelformat:I

    .line 38
    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveInitInfos;->captureimagewidth:I

    .line 39
    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveInitInfos;->captureimageheight:I

    .line 41
    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveInitInfos;->sizescreenwidth:I

    .line 42
    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveInitInfos;->sizescreenheight:I

    .line 44
    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveInitInfos;->sizeviewx:I

    .line 45
    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveInitInfos;->sizeviewy:I

    .line 46
    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveInitInfos;->sizeviewwidth:I

    .line 47
    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveInitInfos;->sizeviewheight:I

    .line 48
    return-void
.end method
