.class public Ltas/ipc/ReceiverSession$SimpleCallback;
.super Ljava/lang/Object;
.source "ReceiverSession.java"

# interfaces
.implements Ltas/ipc/ReceiverSession$Callback;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltas/ipc/ReceiverSession;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "SimpleCallback"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    .prologue
    .line 113
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onReceive(Ltas/ipc/ReceiverSession;ILtas/ipc/MsgData;)V
    .locals 0
    .param p1, "session"    # Ltas/ipc/ReceiverSession;
    .param p2, "what"    # I
    .param p3, "msg"    # Ltas/ipc/MsgData;

    .prologue
    .line 126
    return-void
.end method

.method public onSenderOffline(Ltas/ipc/ReceiverSession;)V
    .locals 0
    .param p1, "session"    # Ltas/ipc/ReceiverSession;

    .prologue
    .line 118
    return-void
.end method

.method public onSenderOnline(Ltas/ipc/ReceiverSession;)V
    .locals 0
    .param p1, "session"    # Ltas/ipc/ReceiverSession;

    .prologue
    .line 115
    return-void
.end method

.method public onSenderUpdate(Ltas/ipc/ReceiverSession;Landroid/os/Bundle;)V
    .locals 0
    .param p1, "session"    # Ltas/ipc/ReceiverSession;
    .param p2, "extra"    # Landroid/os/Bundle;

    .prologue
    .line 122
    return-void
.end method
