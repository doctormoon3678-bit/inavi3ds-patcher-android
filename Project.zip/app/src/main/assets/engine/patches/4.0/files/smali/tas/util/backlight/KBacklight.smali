.class public final Ltas/util/backlight/KBacklight;
.super Ljava/lang/Object;
.source "KBacklight.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ltas/util/backlight/KBacklight$PowerObserver;,
        Ltas/util/backlight/KBacklight$BrightnessObserver;
    }
.end annotation


# static fields
.field private static final DEVPATH:Ljava/lang/String;

.field public static final INVALID:I = -0x1

.field public static final MAX:I

.field public static final MIN:I

.field private static final SYSFS_ACTUAL_BR:Ljava/lang/String;

.field private static final SYSFS_BR:Ljava/lang/String;

.field private static final SYSFS_POWER:Ljava/lang/String;

.field private static sSelf:Ltas/util/backlight/KBacklight;


# instance fields
.field private final BRIGHTNESS:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List",
            "<",
            "Ltas/util/backlight/KBacklight$BrightnessObserver;",
            ">;"
        }
    .end annotation
.end field

.field private COUNT:I

.field private final OBSERVER:Landroid/os/UEventObserver;

.field private final POWER:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List",
            "<",
            "Ltas/util/backlight/KBacklight$PowerObserver;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static synthetic -wrap0(Ltas/util/backlight/KBacklight;Landroid/os/UEventObserver$UEvent;)Z
    .locals 1
    .param p1, "event"    # Landroid/os/UEventObserver$UEvent;

    .prologue
    invoke-direct {p0, p1}, Ltas/util/backlight/KBacklight;->onBrightnessUEvent(Landroid/os/UEventObserver$UEvent;)Z

    move-result v0

    return v0
.end method

.method static synthetic -wrap1(Ltas/util/backlight/KBacklight;Landroid/os/UEventObserver$UEvent;)Z
    .locals 1
    .param p1, "event"    # Landroid/os/UEventObserver$UEvent;

    .prologue
    invoke-direct {p0, p1}, Ltas/util/backlight/KBacklight;->onPowerKeyUEvent(Landroid/os/UEventObserver$UEvent;)Z

    move-result v0

    return v0
.end method

.method static constructor <clinit>()V
    .locals 2

    .prologue
    .line 34
    const-string/jumbo v0, "serpiero"

    sget-object v1, Landroid/os/Build;->DEVICE:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 35
    const/16 v0, 0xd2

    sput v0, Ltas/util/backlight/KBacklight;->MAX:I

    .line 40
    :goto_0
    const/4 v0, 0x0

    sput v0, Ltas/util/backlight/KBacklight;->MIN:I

    .line 42
    const-string/jumbo v0, "/sys/class/backlight/0.backlight/bl_power"

    sput-object v0, Ltas/util/backlight/KBacklight;->SYSFS_POWER:Ljava/lang/String;

    .line 43
    const-string/jumbo v0, "/sys/class/backlight/0.backlight/brightness"

    sput-object v0, Ltas/util/backlight/KBacklight;->SYSFS_BR:Ljava/lang/String;

    .line 44
    const-string/jumbo v0, "/sys/class/backlight/0.backlight/actual_brightness"

    sput-object v0, Ltas/util/backlight/KBacklight;->SYSFS_ACTUAL_BR:Ljava/lang/String;

    .line 45
    const-string/jumbo v0, "DEVPATH=/devices/0.backlight/backlight/0.backlight"

    sput-object v0, Ltas/util/backlight/KBacklight;->DEVPATH:Ljava/lang/String;

    .line 19
    return-void

    .line 37
    :cond_0
    const/16 v0, 0xff

    sput v0, Ltas/util/backlight/KBacklight;->MAX:I

    goto :goto_0
.end method

.method private constructor <init>()V
    .locals 1

    .prologue
    .line 163
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 164
    const/4 v0, 0x0

    iput v0, p0, Ltas/util/backlight/KBacklight;->COUNT:I

    .line 165
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Ltas/util/backlight/KBacklight;->BRIGHTNESS:Ljava/util/List;

    .line 166
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Ltas/util/backlight/KBacklight;->POWER:Ljava/util/List;

    .line 167
    new-instance v0, Ltas/util/backlight/KBacklight$1;

    invoke-direct {v0, p0}, Ltas/util/backlight/KBacklight$1;-><init>(Ltas/util/backlight/KBacklight;)V

    iput-object v0, p0, Ltas/util/backlight/KBacklight;->OBSERVER:Landroid/os/UEventObserver;

    .line 163
    return-void
.end method

.method private addObserver(Ljava/lang/Object;Ljava/util/List;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(TT;",
            "Ljava/util/List",
            "<TT;>;)V"
        }
    .end annotation

    .prologue
    .line 181
    .local p1, "t":Ljava/lang/Object;, "TT;"
    .local p2, "l":Ljava/util/List;, "Ljava/util/List<TT;>;"
    const-class v1, Ltas/util/backlight/KBacklight;

    monitor-enter v1

    .line 182
    if-eqz p1, :cond_0

    :try_start_0
    invoke-interface {p2, p1}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2

    .line 186
    :cond_0
    :goto_0
    iget v0, p0, Ltas/util/backlight/KBacklight;->COUNT:I

    const/4 v2, 0x1

    if-ne v0, v2, :cond_1

    .line 187
    invoke-direct {p0}, Ltas/util/backlight/KBacklight;->startLocked()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_1
    monitor-exit v1

    .line 180
    return-void

    .line 183
    :cond_2
    :try_start_1
    invoke-interface {p2, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 184
    iget v0, p0, Ltas/util/backlight/KBacklight;->COUNT:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Ltas/util/backlight/KBacklight;->COUNT:I
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_0

    .line 181
    :catchall_0
    move-exception v0

    monitor-exit v1

    throw v0
.end method

.method public static addObserver(Ltas/util/backlight/KBacklight$BrightnessObserver;)V
    .locals 2
    .param p0, "o"    # Ltas/util/backlight/KBacklight$BrightnessObserver;

    .prologue
    .line 73
    invoke-static {}, Ltas/util/backlight/KBacklight;->get()Ltas/util/backlight/KBacklight;

    move-result-object v0

    .local v0, "bl":Ltas/util/backlight/KBacklight;
    iget-object v1, v0, Ltas/util/backlight/KBacklight;->BRIGHTNESS:Ljava/util/List;

    invoke-direct {v0, p0, v1}, Ltas/util/backlight/KBacklight;->addObserver(Ljava/lang/Object;Ljava/util/List;)V

    .line 72
    return-void
.end method

.method public static addObserver(Ltas/util/backlight/KBacklight$PowerObserver;)V
    .locals 2
    .param p0, "o"    # Ltas/util/backlight/KBacklight$PowerObserver;

    .prologue
    .line 80
    invoke-static {}, Ltas/util/backlight/KBacklight;->get()Ltas/util/backlight/KBacklight;

    move-result-object v0

    .local v0, "bl":Ltas/util/backlight/KBacklight;
    iget-object v1, v0, Ltas/util/backlight/KBacklight;->POWER:Ljava/util/List;

    invoke-direct {v0, p0, v1}, Ltas/util/backlight/KBacklight;->addObserver(Ljava/lang/Object;Ljava/util/List;)V

    .line 79
    return-void
.end method

.method private static get()Ltas/util/backlight/KBacklight;
    .locals 2

    .prologue
    .line 157
    const-class v1, Ltas/util/backlight/KBacklight;

    monitor-enter v1

    .line 158
    :try_start_0
    sget-object v0, Ltas/util/backlight/KBacklight;->sSelf:Ltas/util/backlight/KBacklight;

    if-nez v0, :cond_0

    new-instance v0, Ltas/util/backlight/KBacklight;

    invoke-direct {v0}, Ltas/util/backlight/KBacklight;-><init>()V

    sput-object v0, Ltas/util/backlight/KBacklight;->sSelf:Ltas/util/backlight/KBacklight;

    .line 159
    :cond_0
    sget-object v0, Ltas/util/backlight/KBacklight;->sSelf:Ltas/util/backlight/KBacklight;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit v1

    return-object v0

    .line 157
    :catchall_0
    move-exception v0

    monitor-exit v1

    throw v0
.end method

.method public static getActualBrightness()I
    .locals 2

    .prologue
    .line 143
    sget-object v0, Ltas/util/backlight/KBacklight;->SYSFS_ACTUAL_BR:Ljava/lang/String;

    const/4 v1, -0x1

    invoke-static {v0, v1}, Ltas/util/io/FileOp;->readSimpleInt(Ljava/lang/String;I)I

    move-result v0

    return v0
.end method

.method public static getBrightness()I
    .locals 2

    .prologue
    .line 136
    sget-object v0, Ltas/util/backlight/KBacklight;->SYSFS_BR:Ljava/lang/String;

    const/4 v1, -0x1

    invoke-static {v0, v1}, Ltas/util/io/FileOp;->readSimpleInt(Ljava/lang/String;I)I

    move-result v0

    return v0
.end method

.method public static isPoweredUp()Z
    .locals 2

    .prologue
    const/4 v0, 0x0

    .line 103
    sget-object v1, Ltas/util/backlight/KBacklight;->SYSFS_POWER:Ljava/lang/String;

    invoke-static {v1, v0}, Ltas/util/io/FileOp;->readSimpleInt(Ljava/lang/String;I)I

    move-result v1

    if-nez v1, :cond_0

    const/4 v0, 0x1

    :cond_0
    return v0
.end method

.method private onBrightnessUEvent(Landroid/os/UEventObserver$UEvent;)Z
    .locals 8
    .param p1, "event"    # Landroid/os/UEventObserver$UEvent;

    .prologue
    const/4 v7, 0x1

    .line 259
    const-string/jumbo v5, "BRIGHTNESS"

    invoke-virtual {p1, v5}, Landroid/os/UEventObserver$UEvent;->get(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 260
    .local v4, "str":Ljava/lang/String;
    if-nez v4, :cond_0

    const/4 v5, 0x0

    return v5

    .line 261
    :cond_0
    iget-object v5, p0, Ltas/util/backlight/KBacklight;->BRIGHTNESS:Ljava/util/List;

    if-eqz v5, :cond_1

    iget-object v5, p0, Ltas/util/backlight/KBacklight;->BRIGHTNESS:Ljava/util/List;

    invoke-interface {v5}, Ljava/util/List;->isEmpty()Z

    move-result v5

    if-eqz v5, :cond_2

    :cond_1
    return v7

    .line 266
    :cond_2
    :try_start_0
    invoke-static {v4}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I
    :try_end_0
    .catch Ljava/lang/NumberFormatException; {:try_start_0 .. :try_end_0} :catch_0

    move-result v0

    .line 272
    .local v0, "br":I
    :goto_0
    const-class v6, Ltas/util/backlight/KBacklight;

    monitor-enter v6

    .line 273
    :try_start_1
    iget-object v5, p0, Ltas/util/backlight/KBacklight;->BRIGHTNESS:Ljava/util/List;

    invoke-interface {v5}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v3

    .local v3, "o$iterator":Ljava/util/Iterator;
    :cond_3
    :goto_1
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_4

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ltas/util/backlight/KBacklight$BrightnessObserver;

    .line 274
    .local v2, "o":Ltas/util/backlight/KBacklight$BrightnessObserver;
    if-eqz v2, :cond_3

    invoke-interface {v2, v0}, Ltas/util/backlight/KBacklight$BrightnessObserver;->onKBrightnessChanged(I)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_1

    .line 272
    .end local v2    # "o":Ltas/util/backlight/KBacklight$BrightnessObserver;
    .end local v3    # "o$iterator":Ljava/util/Iterator;
    :catchall_0
    move-exception v5

    monitor-exit v6

    throw v5

    .line 267
    .end local v0    # "br":I
    :catch_0
    move-exception v1

    .line 268
    .local v1, "e":Ljava/lang/NumberFormatException;
    invoke-virtual {v1}, Ljava/lang/NumberFormatException;->printStackTrace()V

    .line 269
    const/4 v0, -0x1

    .restart local v0    # "br":I
    goto :goto_0

    .end local v1    # "e":Ljava/lang/NumberFormatException;
    .restart local v3    # "o$iterator":Ljava/util/Iterator;
    :cond_4
    monitor-exit v6

    .line 278
    return v7
.end method

.method private onPowerKeyUEvent(Landroid/os/UEventObserver$UEvent;)Z
    .locals 10
    .param p1, "event"    # Landroid/os/UEventObserver$UEvent;

    .prologue
    const/4 v9, 0x1

    .line 219
    const-string/jumbo v7, "POWER_KEY"

    invoke-virtual {p1, v7}, Landroid/os/UEventObserver$UEvent;->get(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    if-nez v7, :cond_0

    const/4 v7, 0x0

    return v7

    .line 221
    :cond_0
    const-string/jumbo v7, "BRIGHTNESS"

    invoke-virtual {p1, v7}, Landroid/os/UEventObserver$UEvent;->get(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 222
    .local v6, "str":Ljava/lang/String;
    if-eqz v6, :cond_1

    iget-object v7, p0, Ltas/util/backlight/KBacklight;->POWER:Ljava/util/List;

    if-nez v7, :cond_2

    :cond_1
    return v9

    :cond_2
    iget-object v7, p0, Ltas/util/backlight/KBacklight;->POWER:Ljava/util/List;

    invoke-interface {v7}, Ljava/util/List;->isEmpty()Z

    move-result v7

    if-nez v7, :cond_1

    .line 227
    :try_start_0
    invoke-static {v6}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I
    :try_end_0
    .catch Ljava/lang/NumberFormatException; {:try_start_0 .. :try_end_0} :catch_0

    move-result v2

    .line 233
    .local v2, "br":I
    :goto_0
    const-string/jumbo v7, "ACTUAL_BRIGHTNESS"

    invoke-virtual {p1, v7}, Landroid/os/UEventObserver$UEvent;->get(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 234
    .local v1, "actual_str":Ljava/lang/String;
    const/4 v0, -0x1

    .line 236
    .local v0, "actual_br":I
    if-eqz v1, :cond_3

    .line 238
    :try_start_1
    invoke-static {v1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I
    :try_end_1
    .catch Ljava/lang/NumberFormatException; {:try_start_1 .. :try_end_1} :catch_1

    move-result v0

    .line 244
    :cond_3
    :goto_1
    const-class v8, Ltas/util/backlight/KBacklight;

    monitor-enter v8

    .line 245
    :try_start_2
    iget-object v7, p0, Ltas/util/backlight/KBacklight;->POWER:Ljava/util/List;

    invoke-interface {v7}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v5

    .local v5, "o$iterator":Ljava/util/Iterator;
    :cond_4
    :goto_2
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_5

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ltas/util/backlight/KBacklight$PowerObserver;

    .line 246
    .local v4, "o":Ltas/util/backlight/KBacklight$PowerObserver;
    if-eqz v4, :cond_4

    invoke-interface {v4, v2, v0}, Ltas/util/backlight/KBacklight$PowerObserver;->onKBacklightPowerKeyPressed(II)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    goto :goto_2

    .line 244
    .end local v4    # "o":Ltas/util/backlight/KBacklight$PowerObserver;
    .end local v5    # "o$iterator":Ljava/util/Iterator;
    :catchall_0
    move-exception v7

    monitor-exit v8

    throw v7

    .line 228
    .end local v0    # "actual_br":I
    .end local v1    # "actual_str":Ljava/lang/String;
    .end local v2    # "br":I
    :catch_0
    move-exception v3

    .line 229
    .local v3, "e":Ljava/lang/NumberFormatException;
    invoke-virtual {v3}, Ljava/lang/NumberFormatException;->printStackTrace()V

    .line 230
    const/4 v2, -0x1

    .restart local v2    # "br":I
    goto :goto_0

    .line 239
    .end local v3    # "e":Ljava/lang/NumberFormatException;
    .restart local v0    # "actual_br":I
    .restart local v1    # "actual_str":Ljava/lang/String;
    :catch_1
    move-exception v3

    .line 240
    .restart local v3    # "e":Ljava/lang/NumberFormatException;
    invoke-virtual {v3}, Ljava/lang/NumberFormatException;->printStackTrace()V

    goto :goto_1

    .end local v3    # "e":Ljava/lang/NumberFormatException;
    .restart local v5    # "o$iterator":Ljava/util/Iterator;
    :cond_5
    monitor-exit v8

    .line 250
    return v9
.end method

.method private removeObserver(Ljava/lang/Object;Ljava/util/List;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(TT;",
            "Ljava/util/List",
            "<TT;>;)V"
        }
    .end annotation

    .prologue
    .line 193
    .local p1, "t":Ljava/lang/Object;, "TT;"
    .local p2, "l":Ljava/util/List;, "Ljava/util/List<TT;>;"
    const-class v1, Ltas/util/backlight/KBacklight;

    monitor-enter v1

    .line 194
    if-eqz p1, :cond_0

    :try_start_0
    invoke-interface {p2, p1}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 195
    invoke-interface {p2, p1}, Ljava/util/List;->remove(Ljava/lang/Object;)Z

    .line 196
    iget v0, p0, Ltas/util/backlight/KBacklight;->COUNT:I

    add-int/lit8 v0, v0, -0x1

    iput v0, p0, Ltas/util/backlight/KBacklight;->COUNT:I

    .line 198
    :cond_0
    iget v0, p0, Ltas/util/backlight/KBacklight;->COUNT:I

    if-nez v0, :cond_1

    .line 199
    invoke-direct {p0}, Ltas/util/backlight/KBacklight;->stopLocked()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_1
    monitor-exit v1

    .line 192
    return-void

    .line 193
    :catchall_0
    move-exception v0

    monitor-exit v1

    throw v0
.end method

.method public static removeObserver(Ltas/util/backlight/KBacklight$BrightnessObserver;)V
    .locals 2
    .param p0, "o"    # Ltas/util/backlight/KBacklight$BrightnessObserver;

    .prologue
    .line 87
    invoke-static {}, Ltas/util/backlight/KBacklight;->get()Ltas/util/backlight/KBacklight;

    move-result-object v0

    .local v0, "bl":Ltas/util/backlight/KBacklight;
    iget-object v1, v0, Ltas/util/backlight/KBacklight;->BRIGHTNESS:Ljava/util/List;

    invoke-direct {v0, p0, v1}, Ltas/util/backlight/KBacklight;->removeObserver(Ljava/lang/Object;Ljava/util/List;)V

    .line 86
    return-void
.end method

.method public static removeObserver(Ltas/util/backlight/KBacklight$PowerObserver;)V
    .locals 2
    .param p0, "o"    # Ltas/util/backlight/KBacklight$PowerObserver;

    .prologue
    .line 94
    invoke-static {}, Ltas/util/backlight/KBacklight;->get()Ltas/util/backlight/KBacklight;

    move-result-object v0

    .local v0, "bl":Ltas/util/backlight/KBacklight;
    iget-object v1, v0, Ltas/util/backlight/KBacklight;->POWER:Ljava/util/List;

    invoke-direct {v0, p0, v1}, Ltas/util/backlight/KBacklight;->removeObserver(Ljava/lang/Object;Ljava/util/List;)V

    .line 93
    return-void
.end method

.method public static setBrightness(I)Z
    .locals 2
    .param p0, "brightness"    # I

    .prologue
    .line 129
    sget-object v0, Ltas/util/backlight/KBacklight;->SYSFS_BR:Ljava/lang/String;

    invoke-static {p0}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Ltas/util/io/FileOp;->write(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    return v0
.end method

.method public static setPowerDown()Z
    .locals 2

    .prologue
    .line 121
    sget-object v0, Ltas/util/backlight/KBacklight;->SYSFS_POWER:Ljava/lang/String;

    const-string/jumbo v1, "1"

    invoke-static {v0, v1}, Ltas/util/io/FileOp;->write(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    return v0
.end method

.method public static setPowerUp()Z
    .locals 2

    .prologue
    .line 112
    sget-object v0, Ltas/util/backlight/KBacklight;->SYSFS_POWER:Ljava/lang/String;

    const-string/jumbo v1, "0"

    invoke-static {v0, v1}, Ltas/util/io/FileOp;->write(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    return v0
.end method

.method private startLocked()V
    .locals 2

    .prologue
    .line 205
    iget-object v0, p0, Ltas/util/backlight/KBacklight;->OBSERVER:Landroid/os/UEventObserver;

    sget-object v1, Ltas/util/backlight/KBacklight;->DEVPATH:Ljava/lang/String;

    invoke-virtual {v0, v1}, Landroid/os/UEventObserver;->startObserving(Ljava/lang/String;)V

    .line 204
    return-void
.end method

.method private stopLocked()V
    .locals 1

    .prologue
    .line 209
    iget-object v0, p0, Ltas/util/backlight/KBacklight;->OBSERVER:Landroid/os/UEventObserver;

    invoke-virtual {v0}, Landroid/os/UEventObserver;->stopObserving()V

    .line 208
    return-void
.end method
