.class Ltas/internal/ipc/Sender$AnonymousSession;
.super Ltas/ipc/SenderSession;
.source "Sender.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltas/internal/ipc/Sender;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "AnonymousSession"
.end annotation


# instance fields
.field private final mSessions:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List",
            "<",
            "Ltas/ipc/SenderSession;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static synthetic -wrap0(Ltas/internal/ipc/Sender$AnonymousSession;Ltas/ipc/SenderSession;)V
    .locals 0
    .param p1, "session"    # Ltas/ipc/SenderSession;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/ipc/Sender$AnonymousSession;->addSession(Ltas/ipc/SenderSession;)V

    return-void
.end method

.method static synthetic -wrap1(Ltas/internal/ipc/Sender$AnonymousSession;Ltas/ipc/SenderSession;)V
    .locals 0
    .param p1, "session"    # Ltas/ipc/SenderSession;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/ipc/Sender$AnonymousSession;->removeSession(Ltas/ipc/SenderSession;)V

    return-void
.end method

.method private constructor <init>(Ltas/internal/ipc/Sender;)V
    .locals 8
    .param p1, "sender"    # Ltas/internal/ipc/Sender;

    .prologue
    const/4 v4, 0x0

    .line 316
    const-wide/16 v2, -0x1

    const/4 v6, 0x0

    move-object v0, p0

    move-object v1, p1

    move-object v5, v4

    move-object v7, v4

    invoke-direct/range {v0 .. v7}, Ltas/ipc/SenderSession;-><init>(Ltas/internal/ipc/Sender;JLjava/lang/String;Ljava/lang/String;ZLandroid/os/Bundle;)V

    .line 314
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 313
    iput-object v0, p0, Ltas/internal/ipc/Sender$AnonymousSession;->mSessions:Ljava/util/List;

    .line 315
    return-void
.end method

.method synthetic constructor <init>(Ltas/internal/ipc/Sender;Ltas/internal/ipc/Sender$AnonymousSession;)V
    .locals 0
    .param p1, "sender"    # Ltas/internal/ipc/Sender;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/ipc/Sender$AnonymousSession;-><init>(Ltas/internal/ipc/Sender;)V

    return-void
.end method

.method private addSession(Ltas/ipc/SenderSession;)V
    .locals 1
    .param p1, "session"    # Ltas/ipc/SenderSession;

    .prologue
    .line 320
    monitor-enter p0

    .line 321
    :try_start_0
    iget-object v0, p0, Ltas/internal/ipc/Sender$AnonymousSession;->mSessions:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit p0

    .line 319
    return-void

    .line 320
    :catchall_0
    move-exception v0

    monitor-exit p0

    throw v0
.end method

.method private removeSession(Ltas/ipc/SenderSession;)V
    .locals 1
    .param p1, "session"    # Ltas/ipc/SenderSession;

    .prologue
    .line 326
    monitor-enter p0

    .line 327
    :try_start_0
    iget-object v0, p0, Ltas/internal/ipc/Sender$AnonymousSession;->mSessions:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->remove(Ljava/lang/Object;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit p0

    .line 325
    return-void

    .line 326
    :catchall_0
    move-exception v0

    monitor-exit p0

    throw v0
.end method


# virtual methods
.method public destroy()V
    .locals 3

    .prologue
    .line 341
    monitor-enter p0

    .line 342
    :try_start_0
    iget-object v2, p0, Ltas/internal/ipc/Sender$AnonymousSession;->mSessions:Ljava/util/List;

    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    .local v1, "s$iterator":Ljava/util/Iterator;
    :cond_0
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/ipc/SenderSession;

    .line 343
    .local v0, "s":Ltas/ipc/SenderSession;
    if-eqz v0, :cond_0

    invoke-virtual {v0}, Ltas/ipc/SenderSession;->destroy()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    .line 341
    .end local v0    # "s":Ltas/ipc/SenderSession;
    .end local v1    # "s$iterator":Ljava/util/Iterator;
    :catchall_0
    move-exception v2

    monitor-exit p0

    throw v2

    .restart local v1    # "s$iterator":Ljava/util/Iterator;
    :cond_1
    monitor-exit p0

    .line 340
    return-void
.end method

.method public send(Ltas/ipc/MsgData;)V
    .locals 3
    .param p1, "msg"    # Ltas/ipc/MsgData;

    .prologue
    .line 332
    monitor-enter p0

    .line 333
    :try_start_0
    iget-object v2, p0, Ltas/internal/ipc/Sender$AnonymousSession;->mSessions:Ljava/util/List;

    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    .local v1, "s$iterator":Ljava/util/Iterator;
    :cond_0
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/ipc/SenderSession;

    .line 334
    .local v0, "s":Ltas/ipc/SenderSession;
    if-eqz v0, :cond_0

    invoke-static {p1}, Ltas/ipc/MsgData;->obtain(Ltas/ipc/MsgData;)Ltas/ipc/MsgData;

    move-result-object v2

    invoke-virtual {v0, v2}, Ltas/ipc/SenderSession;->send(Ltas/ipc/MsgData;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    .line 332
    .end local v0    # "s":Ltas/ipc/SenderSession;
    .end local v1    # "s$iterator":Ljava/util/Iterator;
    :catchall_0
    move-exception v2

    monitor-exit p0

    throw v2

    .restart local v1    # "s$iterator":Ljava/util/Iterator;
    :cond_1
    monitor-exit p0

    .line 337
    invoke-virtual {p1}, Ltas/ipc/MsgData;->recycle()V

    .line 331
    return-void
.end method
