.class public Ltas/internal/camera/util/SystemUtil;
.super Ljava/lang/Object;
.source "SystemUtil.java"


# static fields
.field private static DBG:Z = false

.field private static final TAG:Ljava/lang/String; = "TasCAM<SystemUtil>"

.field private static sSelf:Ltas/internal/camera/util/SystemUtil;


# instance fields
.field private mCtx:Landroid/content/Context;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .prologue
    .line 32
    const/4 v0, 0x1

    sput-boolean v0, Ltas/internal/camera/util/SystemUtil;->DBG:Z

    .line 29
    return-void
.end method

.method private constructor <init>()V
    .locals 0

    .prologue
    .line 236
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static closeBufferedReader(Ljava/io/BufferedReader;)V
    .locals 1
    .param p0, "br"    # Ljava/io/BufferedReader;

    .prologue
    .line 116
    if-nez p0, :cond_0

    return-void

    .line 118
    :cond_0
    :try_start_0
    invoke-virtual {p0}, Ljava/io/BufferedReader;->close()V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    .line 115
    :goto_0
    return-void

    .line 119
    :catch_0
    move-exception v0

    .line 120
    .local v0, "e":Ljava/io/IOException;
    invoke-virtual {v0}, Ljava/io/IOException;->printStackTrace()V

    goto :goto_0
.end method

.method public static closeBufferedWriter(Ljava/io/BufferedWriter;)V
    .locals 1
    .param p0, "bw"    # Ljava/io/BufferedWriter;

    .prologue
    .line 106
    if-nez p0, :cond_0

    return-void

    .line 108
    :cond_0
    :try_start_0
    invoke-virtual {p0}, Ljava/io/BufferedWriter;->flush()V

    .line 109
    invoke-virtual {p0}, Ljava/io/BufferedWriter;->close()V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    .line 105
    :goto_0
    return-void

    .line 110
    :catch_0
    move-exception v0

    .line 111
    .local v0, "e":Ljava/io/IOException;
    invoke-virtual {v0}, Ljava/io/IOException;->printStackTrace()V

    goto :goto_0
.end method

.method public static get()Ltas/internal/camera/util/SystemUtil;
    .locals 2

    .prologue
    .line 239
    const-class v1, Ltas/internal/camera/util/SystemUtil;

    monitor-enter v1

    .line 240
    :try_start_0
    sget-object v0, Ltas/internal/camera/util/SystemUtil;->sSelf:Ltas/internal/camera/util/SystemUtil;

    if-nez v0, :cond_0

    .line 241
    new-instance v0, Ltas/internal/camera/util/SystemUtil;

    invoke-direct {v0}, Ltas/internal/camera/util/SystemUtil;-><init>()V

    sput-object v0, Ltas/internal/camera/util/SystemUtil;->sSelf:Ltas/internal/camera/util/SystemUtil;

    .line 243
    :cond_0
    sget-object v0, Ltas/internal/camera/util/SystemUtil;->sSelf:Ltas/internal/camera/util/SystemUtil;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit v1

    return-object v0

    .line 239
    :catchall_0
    move-exception v0

    monitor-exit v1

    throw v0
.end method

.method public static getBufferedReader(Ljava/lang/String;)Ljava/io/BufferedReader;
    .locals 3
    .param p0, "path"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/FileNotFoundException;,
            Ljava/io/IOException;
        }
    .end annotation

    .prologue
    .line 102
    new-instance v0, Ljava/io/BufferedReader;

    new-instance v1, Ljava/io/FileReader;

    new-instance v2, Ljava/io/File;

    invoke-direct {v2, p0}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    invoke-direct {v1, v2}, Ljava/io/FileReader;-><init>(Ljava/io/File;)V

    invoke-direct {v0, v1}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V

    return-object v0
.end method

.method public static getBufferedWriter(Ljava/lang/String;)Ljava/io/BufferedWriter;
    .locals 3
    .param p0, "path"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/FileNotFoundException;,
            Ljava/io/IOException;
        }
    .end annotation

    .prologue
    .line 96
    new-instance v0, Ljava/io/BufferedWriter;

    new-instance v1, Ljava/io/FileWriter;

    new-instance v2, Ljava/io/File;

    invoke-direct {v2, p0}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    invoke-direct {v1, v2}, Ljava/io/FileWriter;-><init>(Ljava/io/File;)V

    invoke-direct {v0, v1}, Ljava/io/BufferedWriter;-><init>(Ljava/io/Writer;)V

    return-object v0
.end method

.method public static getRunningAppProcesses(Landroid/content/Context;I)Landroid/app/ActivityManager$RunningAppProcessInfo;
    .locals 7
    .param p0, "ctx"    # Landroid/content/Context;
    .param p1, "pid"    # I

    .prologue
    const/4 v6, 0x0

    .line 147
    const-string/jumbo v4, "activity"

    invoke-virtual {p0, v4}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    .line 146
    check-cast v0, Landroid/app/ActivityManager;

    .line 148
    .local v0, "am":Landroid/app/ActivityManager;
    if-nez v0, :cond_0

    .line 149
    const-string/jumbo v4, "TasCAM<SystemUtil>"

    const-string/jumbo v5, "getSystemService am failed"

    invoke-static {v4, v5}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 150
    return-object v6

    .line 153
    :cond_0
    invoke-virtual {v0}, Landroid/app/ActivityManager;->getRunningAppProcesses()Ljava/util/List;

    move-result-object v3

    .line 154
    .local v3, "rap":Ljava/util/List;, "Ljava/util/List<Landroid/app/ActivityManager$RunningAppProcessInfo;>;"
    if-eqz v3, :cond_1

    invoke-interface {v3}, Ljava/util/List;->isEmpty()Z

    move-result v4

    if-eqz v4, :cond_2

    .line 159
    :cond_1
    return-object v6

    .line 155
    :cond_2
    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v2

    .local v2, "ap$iterator":Ljava/util/Iterator;
    :cond_3
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_1

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/app/ActivityManager$RunningAppProcessInfo;

    .line 156
    .local v1, "ap":Landroid/app/ActivityManager$RunningAppProcessInfo;
    iget v4, v1, Landroid/app/ActivityManager$RunningAppProcessInfo;->pid:I

    if-ne p1, v4, :cond_3

    return-object v1
.end method

.method public static getRunningTasks(Landroid/content/Context;I)Ljava/util/List;
    .locals 6
    .param p0, "ctx"    # Landroid/content/Context;
    .param p1, "maxNum"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "I)",
            "Ljava/util/List",
            "<",
            "Landroid/app/ActivityManager$RunningTaskInfo;",
            ">;"
        }
    .end annotation

    .prologue
    const/4 v5, 0x0

    .line 128
    const-string/jumbo v3, "activity"

    invoke-virtual {p0, v3}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    .line 127
    check-cast v0, Landroid/app/ActivityManager;

    .line 129
    .local v0, "am":Landroid/app/ActivityManager;
    if-nez v0, :cond_0

    .line 130
    const-string/jumbo v3, "TasCAM<SystemUtil>"

    const-string/jumbo v4, "getSystemService am failed"

    invoke-static {v3, v4}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 131
    return-object v5

    .line 134
    :cond_0
    const/4 v2, 0x0

    .line 136
    .local v2, "rt":Ljava/util/List;, "Ljava/util/List<Landroid/app/ActivityManager$RunningTaskInfo;>;"
    :try_start_0
    invoke-virtual {v0, p1}, Landroid/app/ActivityManager;->getRunningTasks(I)Ljava/util/List;
    :try_end_0
    .catch Ljava/lang/SecurityException; {:try_start_0 .. :try_end_0} :catch_0

    move-result-object v2

    .line 140
    .end local v2    # "rt":Ljava/util/List;, "Ljava/util/List<Landroid/app/ActivityManager$RunningTaskInfo;>;"
    :goto_0
    return-object v2

    .line 137
    .restart local v2    # "rt":Ljava/util/List;, "Ljava/util/List<Landroid/app/ActivityManager$RunningTaskInfo;>;"
    :catch_0
    move-exception v1

    .line 138
    .local v1, "e":Ljava/lang/SecurityException;
    invoke-virtual {v1}, Ljava/lang/SecurityException;->printStackTrace()V

    goto :goto_0
.end method

.method public static isActivityRunning(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Z
    .locals 6
    .param p0, "ctx"    # Landroid/content/Context;
    .param p1, "pkg"    # Ljava/lang/String;
    .param p2, "cls"    # Ljava/lang/String;

    .prologue
    const/4 v5, 0x0

    .line 179
    const/4 v4, 0x1

    invoke-static {p0, v4}, Ltas/internal/camera/util/SystemUtil;->getRunningTasks(Landroid/content/Context;I)Ljava/util/List;

    move-result-object v3

    .line 180
    .local v3, "rt":Ljava/util/List;, "Ljava/util/List<Landroid/app/ActivityManager$RunningTaskInfo;>;"
    if-eqz v3, :cond_0

    invoke-interface {v3}, Ljava/util/List;->isEmpty()Z

    move-result v4

    if-eqz v4, :cond_1

    .line 181
    :cond_0
    return v5

    .line 184
    :cond_1
    invoke-interface {v3, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroid/app/ActivityManager$RunningTaskInfo;

    iget-object v1, v4, Landroid/app/ActivityManager$RunningTaskInfo;->topActivity:Landroid/content/ComponentName;

    .line 185
    .local v1, "comp":Landroid/content/ComponentName;
    invoke-virtual {v1}, Landroid/content/ComponentName;->getPackageName()Ljava/lang/String;

    move-result-object v2

    .line 186
    .local v2, "packageName":Ljava/lang/String;
    invoke-virtual {v1}, Landroid/content/ComponentName;->getClassName()Ljava/lang/String;

    move-result-object v0

    .line 188
    .local v0, "className":Ljava/lang/String;
    if-eqz v2, :cond_2

    invoke-virtual {v2, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_2

    .line 189
    if-eqz v0, :cond_2

    invoke-virtual {v0, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    .line 188
    :goto_0
    return v4

    :cond_2
    move v4, v5

    goto :goto_0
.end method

.method public static isApplicationRunning(Landroid/content/Context;Ljava/lang/String;)Z
    .locals 5
    .param p0, "ctx"    # Landroid/content/Context;
    .param p1, "pkg"    # Ljava/lang/String;

    .prologue
    const/4 v4, 0x0

    .line 165
    const/4 v3, 0x1

    invoke-static {p0, v3}, Ltas/internal/camera/util/SystemUtil;->getRunningTasks(Landroid/content/Context;I)Ljava/util/List;

    move-result-object v2

    .line 166
    .local v2, "rt":Ljava/util/List;, "Ljava/util/List<Landroid/app/ActivityManager$RunningTaskInfo;>;"
    if-eqz v2, :cond_0

    invoke-interface {v2}, Ljava/util/List;->isEmpty()Z

    move-result v3

    if-eqz v3, :cond_1

    .line 167
    :cond_0
    return v4

    .line 170
    :cond_1
    invoke-interface {v2, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/app/ActivityManager$RunningTaskInfo;

    iget-object v0, v3, Landroid/app/ActivityManager$RunningTaskInfo;->topActivity:Landroid/content/ComponentName;

    .line 171
    .local v0, "comp":Landroid/content/ComponentName;
    invoke-virtual {v0}, Landroid/content/ComponentName;->getPackageName()Ljava/lang/String;

    move-result-object v1

    .line 172
    .local v1, "packageName":Ljava/lang/String;
    if-eqz v1, :cond_2

    invoke-virtual {v1, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    :goto_0
    return v3

    :cond_2
    move v3, v4

    goto :goto_0
.end method

.method public static read(Ljava/lang/String;)I
    .locals 5
    .param p0, "path"    # Ljava/lang/String;

    .prologue
    .line 76
    const/4 v0, 0x0

    .line 77
    .local v0, "br":Ljava/io/BufferedReader;
    const/4 v1, -0x1

    .line 80
    .local v1, "ch":I
    :try_start_0
    invoke-static {p0}, Ltas/internal/camera/util/SystemUtil;->getBufferedReader(Ljava/lang/String;)Ljava/io/BufferedReader;

    move-result-object v0

    .line 81
    .local v0, "br":Ljava/io/BufferedReader;
    invoke-virtual {v0}, Ljava/io/BufferedReader;->read()I
    :try_end_0
    .catch Ljava/io/FileNotFoundException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    move-result v1

    .line 87
    invoke-static {v0}, Ltas/internal/camera/util/SystemUtil;->closeBufferedReader(Ljava/io/BufferedReader;)V

    .line 90
    .end local v0    # "br":Ljava/io/BufferedReader;
    :goto_0
    invoke-static {v1}, Ljava/lang/Character;->getNumericValue(I)I

    move-result v4

    return v4

    .line 84
    :catch_0
    move-exception v3

    .line 85
    .local v3, "e":Ljava/io/IOException;
    :try_start_1
    invoke-virtual {v3}, Ljava/io/IOException;->printStackTrace()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 87
    invoke-static {v0}, Ltas/internal/camera/util/SystemUtil;->closeBufferedReader(Ljava/io/BufferedReader;)V

    goto :goto_0

    .line 82
    .end local v3    # "e":Ljava/io/IOException;
    :catch_1
    move-exception v2

    .line 83
    .local v2, "e":Ljava/io/FileNotFoundException;
    :try_start_2
    invoke-virtual {v2}, Ljava/io/FileNotFoundException;->printStackTrace()V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 87
    invoke-static {v0}, Ltas/internal/camera/util/SystemUtil;->closeBufferedReader(Ljava/io/BufferedReader;)V

    goto :goto_0

    .line 86
    .end local v2    # "e":Ljava/io/FileNotFoundException;
    :catchall_0
    move-exception v4

    .line 87
    invoke-static {v0}, Ltas/internal/camera/util/SystemUtil;->closeBufferedReader(Ljava/io/BufferedReader;)V

    .line 86
    throw v4
.end method

.method public static read(Ljava/lang/String;[CII)I
    .locals 5
    .param p0, "path"    # Ljava/lang/String;
    .param p1, "buffer"    # [C
    .param p2, "offset"    # I
    .param p3, "length"    # I

    .prologue
    .line 58
    const/4 v0, 0x0

    .line 59
    .local v0, "br":Ljava/io/BufferedReader;
    const/4 v3, -0x1

    .line 62
    .local v3, "len":I
    :try_start_0
    invoke-static {p0}, Ltas/internal/camera/util/SystemUtil;->getBufferedReader(Ljava/lang/String;)Ljava/io/BufferedReader;

    move-result-object v0

    .line 63
    .local v0, "br":Ljava/io/BufferedReader;
    invoke-virtual {v0, p1, p2, p3}, Ljava/io/BufferedReader;->read([CII)I
    :try_end_0
    .catch Ljava/io/FileNotFoundException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    move-result v3

    .line 69
    invoke-static {v0}, Ltas/internal/camera/util/SystemUtil;->closeBufferedReader(Ljava/io/BufferedReader;)V

    .line 72
    .end local v0    # "br":Ljava/io/BufferedReader;
    :goto_0
    return v3

    .line 66
    :catch_0
    move-exception v2

    .line 67
    .local v2, "e":Ljava/io/IOException;
    :try_start_1
    invoke-virtual {v2}, Ljava/io/IOException;->printStackTrace()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 69
    invoke-static {v0}, Ltas/internal/camera/util/SystemUtil;->closeBufferedReader(Ljava/io/BufferedReader;)V

    goto :goto_0

    .line 64
    .end local v2    # "e":Ljava/io/IOException;
    :catch_1
    move-exception v1

    .line 65
    .local v1, "e":Ljava/io/FileNotFoundException;
    :try_start_2
    invoke-virtual {v1}, Ljava/io/FileNotFoundException;->printStackTrace()V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 69
    invoke-static {v0}, Ltas/internal/camera/util/SystemUtil;->closeBufferedReader(Ljava/io/BufferedReader;)V

    goto :goto_0

    .line 68
    .end local v1    # "e":Ljava/io/FileNotFoundException;
    :catchall_0
    move-exception v4

    .line 69
    invoke-static {v0}, Ltas/internal/camera/util/SystemUtil;->closeBufferedReader(Ljava/io/BufferedReader;)V

    .line 68
    throw v4
.end method

.method public static startActivity(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
    .locals 6
    .param p0, "ctx"    # Landroid/content/Context;
    .param p1, "pkg"    # Ljava/lang/String;
    .param p2, "cls"    # Ljava/lang/String;

    .prologue
    .line 196
    invoke-static {p0, p1, p2}, Ltas/internal/camera/util/SystemUtil;->isActivityRunning(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_0

    .line 197
    return-void

    .line 200
    :cond_0
    new-instance v2, Landroid/content/Intent;

    invoke-direct {v2}, Landroid/content/Intent;-><init>()V

    .line 201
    .local v2, "intent":Landroid/content/Intent;
    invoke-virtual {v2, p1, p2}, Landroid/content/Intent;->setClassName(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 202
    const/high16 v3, 0x14000000

    invoke-virtual {v2, v3}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;

    .line 205
    sget-boolean v3, Ltas/internal/camera/util/SystemUtil;->DBG:Z

    if-eqz v3, :cond_1

    .line 206
    const-string/jumbo v3, "TasCAM<SystemUtil>"

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v5, "starting activity - "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    .line 207
    invoke-virtual {v2}, Landroid/content/Intent;->getComponent()Landroid/content/ComponentName;

    move-result-object v5

    invoke-virtual {v5}, Landroid/content/ComponentName;->toString()Ljava/lang/String;

    move-result-object v5

    .line 206
    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v3, v4}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 211
    :cond_1
    :try_start_0
    invoke-virtual {p0, v2}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_0
    .catch Landroid/content/ActivityNotFoundException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 194
    :goto_0
    return-void

    .line 214
    :catch_0
    move-exception v1

    .line 215
    .local v1, "e":Ljava/lang/Exception;
    invoke-virtual {v1}, Ljava/lang/Exception;->printStackTrace()V

    goto :goto_0

    .line 212
    .end local v1    # "e":Ljava/lang/Exception;
    :catch_1
    move-exception v0

    .line 213
    .local v0, "e":Landroid/content/ActivityNotFoundException;
    invoke-virtual {v0}, Landroid/content/ActivityNotFoundException;->printStackTrace()V

    goto :goto_0
.end method

.method public static startService(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
    .locals 4
    .param p0, "ctx"    # Landroid/content/Context;
    .param p1, "pkg"    # Ljava/lang/String;
    .param p2, "cls"    # Ljava/lang/String;

    .prologue
    .line 223
    new-instance v0, Landroid/content/Intent;

    invoke-direct {v0}, Landroid/content/Intent;-><init>()V

    .line 224
    .local v0, "intent":Landroid/content/Intent;
    invoke-virtual {v0, p1, p2}, Landroid/content/Intent;->setClassName(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 226
    sget-boolean v1, Ltas/internal/camera/util/SystemUtil;->DBG:Z

    if-eqz v1, :cond_0

    .line 227
    const-string/jumbo v1, "TasCAM<SystemUtil>"

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "starting service - "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    .line 228
    invoke-virtual {v0}, Landroid/content/Intent;->getComponent()Landroid/content/ComponentName;

    move-result-object v3

    invoke-virtual {v3}, Landroid/content/ComponentName;->toString()Ljava/lang/String;

    move-result-object v3

    .line 227
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 231
    :cond_0
    invoke-virtual {p0, v0}, Landroid/content/Context;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;

    .line 221
    return-void
.end method

.method public static write(Ljava/lang/String;I)V
    .locals 1
    .param p0, "path"    # Ljava/lang/String;
    .param p1, "value"    # I

    .prologue
    .line 35
    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v0

    invoke-static {p0, v0}, Ltas/internal/camera/util/SystemUtil;->write(Ljava/lang/String;Ljava/lang/String;)V

    .line 34
    return-void
.end method

.method public static write(Ljava/lang/String;Ljava/lang/String;)V
    .locals 4
    .param p0, "path"    # Ljava/lang/String;
    .param p1, "value"    # Ljava/lang/String;

    .prologue
    .line 41
    const/4 v0, 0x0

    .line 44
    .local v0, "bw":Ljava/io/BufferedWriter;
    :try_start_0
    invoke-static {p0}, Ltas/internal/camera/util/SystemUtil;->getBufferedWriter(Ljava/lang/String;)Ljava/io/BufferedWriter;

    move-result-object v0

    .line 45
    .local v0, "bw":Ljava/io/BufferedWriter;
    invoke-virtual {v0, p1}, Ljava/io/BufferedWriter;->write(Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/io/FileNotFoundException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 51
    invoke-static {v0}, Ltas/internal/camera/util/SystemUtil;->closeBufferedWriter(Ljava/io/BufferedWriter;)V

    .line 39
    .end local v0    # "bw":Ljava/io/BufferedWriter;
    :goto_0
    return-void

    .line 48
    :catch_0
    move-exception v2

    .line 49
    .local v2, "e":Ljava/io/IOException;
    :try_start_1
    invoke-virtual {v2}, Ljava/io/IOException;->printStackTrace()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 51
    invoke-static {v0}, Ltas/internal/camera/util/SystemUtil;->closeBufferedWriter(Ljava/io/BufferedWriter;)V

    goto :goto_0

    .line 46
    .end local v2    # "e":Ljava/io/IOException;
    :catch_1
    move-exception v1

    .line 47
    .local v1, "e":Ljava/io/FileNotFoundException;
    :try_start_2
    invoke-virtual {v1}, Ljava/io/FileNotFoundException;->printStackTrace()V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 51
    invoke-static {v0}, Ltas/internal/camera/util/SystemUtil;->closeBufferedWriter(Ljava/io/BufferedWriter;)V

    goto :goto_0

    .line 50
    .end local v1    # "e":Ljava/io/FileNotFoundException;
    :catchall_0
    move-exception v3

    .line 51
    invoke-static {v0}, Ltas/internal/camera/util/SystemUtil;->closeBufferedWriter(Ljava/io/BufferedWriter;)V

    .line 50
    throw v3
.end method


# virtual methods
.method public getRunningAppProcesses(I)Landroid/app/ActivityManager$RunningAppProcessInfo;
    .locals 2
    .param p1, "pid"    # I

    .prologue
    const/4 v0, 0x0

    .line 256
    iget-object v1, p0, Ltas/internal/camera/util/SystemUtil;->mCtx:Landroid/content/Context;

    if-eqz v1, :cond_0

    iget-object v0, p0, Ltas/internal/camera/util/SystemUtil;->mCtx:Landroid/content/Context;

    invoke-static {v0, p1}, Ltas/internal/camera/util/SystemUtil;->getRunningAppProcesses(Landroid/content/Context;I)Landroid/app/ActivityManager$RunningAppProcessInfo;

    move-result-object v0

    :cond_0
    return-object v0
.end method

.method public getRunningTasks(I)Ljava/util/List;
    .locals 2
    .param p1, "maxNum"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)",
            "Ljava/util/List",
            "<",
            "Landroid/app/ActivityManager$RunningTaskInfo;",
            ">;"
        }
    .end annotation

    .prologue
    const/4 v0, 0x0

    .line 252
    iget-object v1, p0, Ltas/internal/camera/util/SystemUtil;->mCtx:Landroid/content/Context;

    if-eqz v1, :cond_0

    iget-object v0, p0, Ltas/internal/camera/util/SystemUtil;->mCtx:Landroid/content/Context;

    invoke-static {v0, p1}, Ltas/internal/camera/util/SystemUtil;->getRunningTasks(Landroid/content/Context;I)Ljava/util/List;

    move-result-object v0

    :cond_0
    return-object v0
.end method

.method public isActivityRunning(Ljava/lang/String;Ljava/lang/String;)Z
    .locals 1
    .param p1, "pkg"    # Ljava/lang/String;
    .param p2, "cls"    # Ljava/lang/String;

    .prologue
    .line 265
    iget-object v0, p0, Ltas/internal/camera/util/SystemUtil;->mCtx:Landroid/content/Context;

    if-eqz v0, :cond_0

    iget-object v0, p0, Ltas/internal/camera/util/SystemUtil;->mCtx:Landroid/content/Context;

    invoke-static {v0, p1, p2}, Ltas/internal/camera/util/SystemUtil;->isActivityRunning(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    :goto_0
    return v0

    :cond_0
    const/4 v0, 0x0

    goto :goto_0
.end method

.method public isApplicationRunning(Ljava/lang/String;)Z
    .locals 1
    .param p1, "pkg"    # Ljava/lang/String;

    .prologue
    .line 260
    iget-object v0, p0, Ltas/internal/camera/util/SystemUtil;->mCtx:Landroid/content/Context;

    if-eqz v0, :cond_0

    iget-object v0, p0, Ltas/internal/camera/util/SystemUtil;->mCtx:Landroid/content/Context;

    invoke-static {v0, p1}, Ltas/internal/camera/util/SystemUtil;->isApplicationRunning(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v0

    :goto_0
    return v0

    :cond_0
    const/4 v0, 0x0

    goto :goto_0
.end method

.method public setApplicationContext(Landroid/content/Context;)V
    .locals 0
    .param p1, "ctx"    # Landroid/content/Context;

    .prologue
    .line 248
    iput-object p1, p0, Ltas/internal/camera/util/SystemUtil;->mCtx:Landroid/content/Context;

    .line 247
    return-void
.end method

.method public startActivity(Ljava/lang/String;Ljava/lang/String;)V
    .locals 1
    .param p1, "pkg"    # Ljava/lang/String;
    .param p2, "cls"    # Ljava/lang/String;

    .prologue
    .line 270
    iget-object v0, p0, Ltas/internal/camera/util/SystemUtil;->mCtx:Landroid/content/Context;

    if-eqz v0, :cond_0

    iget-object v0, p0, Ltas/internal/camera/util/SystemUtil;->mCtx:Landroid/content/Context;

    invoke-static {v0, p1, p2}, Ltas/internal/camera/util/SystemUtil;->startActivity(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    .line 269
    :cond_0
    return-void
.end method

.method public startService(Ljava/lang/String;Ljava/lang/String;)V
    .locals 1
    .param p1, "pkg"    # Ljava/lang/String;
    .param p2, "cls"    # Ljava/lang/String;

    .prologue
    .line 275
    iget-object v0, p0, Ltas/internal/camera/util/SystemUtil;->mCtx:Landroid/content/Context;

    if-eqz v0, :cond_0

    iget-object v0, p0, Ltas/internal/camera/util/SystemUtil;->mCtx:Landroid/content/Context;

    invoke-static {v0, p1, p2}, Ltas/internal/camera/util/SystemUtil;->startService(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    .line 274
    :cond_0
    return-void
.end method
