.class public interface abstract Ltas/internal/ipc/server/IRemoteTransmitter;
.super Ljava/lang/Object;
.source "IRemoteTransmitter.java"

# interfaces
.implements Landroid/os/IInterface;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ltas/internal/ipc/server/IRemoteTransmitter$Stub;
    }
.end annotation


# virtual methods
.method public abstract transmit(Ltas/internal/ipc/server/RemoteMessage;)V
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation
.end method
