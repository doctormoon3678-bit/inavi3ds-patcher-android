.class public final Ltas/internal/camera/server/Broadcast;
.super Landroid/content/BroadcastReceiver;
.source "Broadcast.java"


# instance fields
.field private final F:Landroid/content/IntentFilter;

.field private final S:Ltas/internal/camera/server/ServerService;


# direct methods
.method constructor <init>(Ltas/internal/camera/server/ServerService;)V
    .locals 2
    .param p1, "s"    # Ltas/internal/camera/server/ServerService;

    .prologue
    .line 17
    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    .line 14
    new-instance v0, Landroid/content/IntentFilter;

    invoke-direct {v0}, Landroid/content/IntentFilter;-><init>()V

    iput-object v0, p0, Ltas/internal/camera/server/Broadcast;->F:Landroid/content/IntentFilter;

    .line 18
    iput-object p1, p0, Ltas/internal/camera/server/Broadcast;->S:Ltas/internal/camera/server/ServerService;

    .line 19
    iget-object v0, p0, Ltas/internal/camera/server/Broadcast;->F:Landroid/content/IntentFilter;

    const-string/jumbo v1, "android.intent.action.ACTION_SHUTDOWN"

    invoke-virtual {v0, v1}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    .line 20
    iget-object v0, p0, Ltas/internal/camera/server/Broadcast;->F:Landroid/content/IntentFilter;

    const-string/jumbo v1, "android.intent.action.MASTER_CLEAR"

    invoke-virtual {v0, v1}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    .line 21
    invoke-virtual {p0}, Ltas/internal/camera/server/Broadcast;->register()V

    .line 17
    return-void
.end method


# virtual methods
.method public varargs addActions([Ljava/lang/String;)V
    .locals 4
    .param p1, "actions"    # [Ljava/lang/String;

    .prologue
    .line 25
    if-nez p1, :cond_0

    return-void

    .line 27
    :cond_0
    const/4 v1, 0x0

    array-length v2, p1

    :goto_0
    if-ge v1, v2, :cond_2

    aget-object v0, p1, v1

    .line 28
    .local v0, "a":Ljava/lang/String;
    iget-object v3, p0, Ltas/internal/camera/server/Broadcast;->F:Landroid/content/IntentFilter;

    invoke-virtual {v3, v0}, Landroid/content/IntentFilter;->hasAction(Ljava/lang/String;)Z

    move-result v3

    if-nez v3, :cond_1

    .line 29
    iget-object v3, p0, Ltas/internal/camera/server/Broadcast;->F:Landroid/content/IntentFilter;

    invoke-virtual {v3, v0}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    .line 27
    :cond_1
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    .line 33
    .end local v0    # "a":Ljava/lang/String;
    :cond_2
    invoke-virtual {p0}, Ltas/internal/camera/server/Broadcast;->unregister()V

    .line 34
    invoke-virtual {p0}, Ltas/internal/camera/server/Broadcast;->register()V

    .line 24
    return-void
.end method

.method public onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 3
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "intent"    # Landroid/content/Intent;

    .prologue
    .line 46
    invoke-virtual {p2}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v0

    .line 47
    .local v0, "a":Ljava/lang/String;
    const-string/jumbo v1, "android.intent.action.ACTION_SHUTDOWN"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_0

    .line 48
    iget-object v1, p0, Ltas/internal/camera/server/Broadcast;->S:Ltas/internal/camera/server/ServerService;

    invoke-virtual {v1}, Ltas/internal/camera/server/ServerService;->onSystemShutdown()V

    .line 49
    return-void

    .line 52
    :cond_0
    const-string/jumbo v1, "android.intent.action.MASTER_CLEAR"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1

    .line 53
    iget-object v1, p0, Ltas/internal/camera/server/Broadcast;->S:Ltas/internal/camera/server/ServerService;

    const-string/jumbo v2, "android.intent.extra.REASON"

    invoke-virtual {p2, v2}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ltas/internal/camera/server/ServerService;->onSystemMasterClear(Ljava/lang/String;)V

    .line 54
    return-void

    .line 57
    :cond_1
    iget-object v1, p0, Ltas/internal/camera/server/Broadcast;->S:Ltas/internal/camera/server/ServerService;

    invoke-virtual {v1, p2}, Ltas/internal/camera/server/ServerService;->onReceiveBroadcast(Landroid/content/Intent;)V

    .line 45
    return-void
.end method

.method public register()V
    .locals 2

    .prologue
    .line 38
    iget-object v0, p0, Ltas/internal/camera/server/Broadcast;->S:Ltas/internal/camera/server/ServerService;

    iget-object v1, p0, Ltas/internal/camera/server/Broadcast;->F:Landroid/content/IntentFilter;

    invoke-virtual {v0, p0, v1}, Ltas/internal/camera/server/ServerService;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    .line 37
    return-void
.end method

.method public unregister()V
    .locals 1

    .prologue
    .line 42
    iget-object v0, p0, Ltas/internal/camera/server/Broadcast;->S:Ltas/internal/camera/server/ServerService;

    invoke-virtual {v0, p0}, Ltas/internal/camera/server/ServerService;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V

    .line 41
    return-void
.end method
