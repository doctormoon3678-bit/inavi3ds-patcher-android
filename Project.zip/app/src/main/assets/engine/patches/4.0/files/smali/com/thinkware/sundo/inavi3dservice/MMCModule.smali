.class public Lcom/thinkware/sundo/inavi3dservice/MMCModule;
.super Ljava/lang/Object;
.source "MMCModule.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/thinkware/sundo/inavi3dservice/MMCModule$8;,
        Lcom/thinkware/sundo/inavi3dservice/MMCModule$_OBD2Info;,
        Lcom/thinkware/sundo/inavi3dservice/MMCModule$GPSTYPE;,
        Lcom/thinkware/sundo/inavi3dservice/MMCModule$MSGTYPE;,
        Lcom/thinkware/sundo/inavi3dservice/MMCModule$LogMode;
    }
.end annotation


# static fields
.field protected static final MSG_GRAVITY:I = 0x3ea

.field protected static final MSG_MAPMATCH:I = 0x3e9

.field protected static final MSG_NMEA_LOGDRIVE:I = 0x3eb

.field protected static final MSG_SIMULATION:I = 0x3ec

.field private static final STATUS_GPSNOTFIX:I = 0x5

.field private static final STATUS_GPS_SOCKET:I = 0x3

.field private static final STATUS_GRAVITY:I = 0x1

.field private static final STATUS_LOGGER:I = 0x4

.field private static final STATUS_MAPMATCH:I = 0x0

.field private static final STATUS_NMEA_LOGDRIVE:I = 0x2

.field private static final dbgModeMsg:[B

.field public static final dummy_nmea:Ljava/lang/String; = "$GPGGA,000000.024,,,,,0,00,,,M,0.0,M,,0000*50\r\n$GPGSA,A,1,,,,,,,,,,,,,,,*1E\r\n$GPGSV,3,1,12,20,00,000,,10,00,000,35,31,00,000,,27,00,000,*7A\r\n$GPGSV,3,2,12,19,00,000,,07,00,000,,04,00,000,43,24,00,000,*71\r\n$GPGSV,3,3,12,16,00,000,,28,00,000,,26,00,000,,29,00,000,*78\r\n$GPRMC,000000.024,V,,,,,,,010407,,,N*49\r\n"

.field private static mm_mutex:Ljava/lang/Object;

.field static nmea_size:I

.field public static speed:I

.field private static test_nmea:Z

.field private static test_rmm:Z

.field private static test_vmm:Z


# instance fields
.field private final DRGPSMODE:Ljava/lang/String;

.field private final INNERGPSMODE:Ljava/lang/String;

.field private LogThreadProc:Ljava/lang/Runnable;

.field private LogThreadProcInJava:Ljava/lang/Runnable;

.field private MMCThreadProc:Ljava/lang/Runnable;

.field private _gpsInfo:Lcom/tw/mapmatch/dataset/_GPSInfo;

.field private _logmode:Lcom/thinkware/sundo/inavi3dservice/MMCModule$LogMode;

.field private _mmcInfo:Lcom/tw/mapmatch/dataset/_MMCInfo;

.field private _obd2Info:Lcom/tw/mapmatch/dataset/_MMOBD2Data;

.field private _satInfo:Lcom/tw/mapmatch/dataset/_SATInfo;

.field private bIsLogDrive:Z

.field private cmd01:Ljava/lang/String;

.field private cmd02:Ljava/lang/String;

.field private delay_tm:J

.field private delay_tm_for_DR:J

.field private fin:Ljava/io/FileInputStream;

.field private gpsSocketThreadProc:Ljava/lang/Runnable;

.field private gravityModule:Lcom/thinkware/sundo/inavi3dservice/GravityModule;

.field private final locationListener:Landroid/location/LocationListener;

.field private location_timestamp:J

.field private m_LogThread:Ljava/lang/Thread;

.field private m_RealMMTM:J

.field private m_VirtualMMCount:S

.field private m_VirtualMMTM:J

.field private m_bIsCar:Z

.field private m_bIsGPSConfiguration:Z

.field private m_bIsGpsOkay:Z

.field private m_bIsRunning:[Z

.field private m_bIsSimulateStartStop:Z

.field private m_bOBD2DataUpdated:Z

.field private m_bUseOBD2:Z

.field private m_bUsingDRSolution:Z

.field private m_bUsingGPSSocket:Z

.field private m_ctxtParent:Landroid/content/Context;

.field private m_delayTM_Nmea:J

.field private m_endTM_Location:J

.field private m_endTM_Nmea:J

.field private m_gi:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

.field private m_gi_dummy:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

.field private m_gpsSocket:Lcom/thinkware/sundo/inavi3dservice/GPSSocketClient;

.field private m_gpsThread:Ljava/lang/Thread;

.field private m_locManager:Landroid/location/LocationManager;

.field private m_mi:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

.field private m_misenData:Lcom/tw/mapmatch/dataset/_MISENData;

.field private m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

.field private m_mmcThread:Ljava/lang/Thread;

.field private m_nAccuracy:I

.field private m_nAltitude:I

.field private m_nCurrentMode:I

.field private m_nLatitude:I

.field private m_nLongitude:I

.field private m_nSimulatePercent:I

.field private m_nSpeedMode:I

.field private m_nUTC:[I

.field private m_nUTC_old:[I

.field private m_prevTime_getMMCInfo:J

.field private m_provider:Ljava/lang/String;

.field private m_sCourse:S

.field private m_sSpeed:S

.field private m_si:Lcom/tw/mapmatch/remote/mapmatch/SATInfo;

.field private m_si_dummy:Lcom/tw/mapmatch/remote/mapmatch/SATInfo;

.field private mmcHandler:Landroid/os/Handler;

.field private nmea0183Data:Ljava/lang/String;

.field private nmea0183Data_2:Ljava/lang/String;

.field private nmeaLength:I

.field private final nmeaListener:Landroid/location/GpsStatus$NmeaListener;

.field private final nmeaMsgListener:Landroid/location/OnNmeaMessageListener;

.field private nmea_timestamp:J

.field private reader:Ljava/io/BufferedReader;

.field private speed_mps:S


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .prologue
    const/4 v1, 0x0

    .line 95
    sput-boolean v1, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->test_nmea:Z

    .line 96
    sput-boolean v1, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->test_vmm:Z

    .line 97
    sput-boolean v1, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->test_rmm:Z

    .line 125
    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->mm_mutex:Ljava/lang/Object;

    .line 126
    const/16 v0, 0x164

    new-array v0, v0, [B

    fill-array-data v0, :array_0

    sput-object v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->dbgModeMsg:[B

    .line 998
    sput v1, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->speed:I

    .line 1426
    sput v1, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->nmea_size:I

    return-void

    .line 126
    :array_0
    .array-data 1
        -0x4bt
        0x62t
        0x6t
        0x2t
        0x8t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        -0x1t
        -0x1t
        -0x1t
        -0x1t
        0xct
        -0x5ct
        -0x4bt
        0x62t
        0x6t
        0x1t
        0x3t
        0x0t
        0xct
        0x1at
        0x1t
        0x31t
        -0x68t
        -0x4bt
        0x62t
        0x6t
        0x1t
        0x3t
        0x0t
        0xct
        0x31t
        0x1t
        0x48t
        -0x3at
        -0x4bt
        0x62t
        0x6t
        0x1t
        0x3t
        0x0t
        0xct
        0x21t
        0x1t
        0x38t
        -0x5at
        -0x4bt
        0x62t
        0x6t
        0x1t
        0x3t
        0x0t
        0xct
        0x10t
        0x1t
        0x27t
        -0x7ct
        -0x4bt
        0x62t
        0x6t
        0x1t
        0x3t
        0x0t
        0xct
        0x16t
        0x1t
        0x2dt
        -0x70t
        -0x4bt
        0x62t
        0x6t
        0x1t
        0x3t
        0x0t
        0xct
        0x34t
        0x1t
        0x4bt
        -0x34t
        -0x4bt
        0x62t
        0x6t
        0x1t
        0x3t
        0x0t
        0x10t
        0x2t
        0x1t
        0x1dt
        0x74t
        -0x4bt
        0x62t
        0x6t
        0x1t
        0x3t
        0x0t
        0x10t
        0x11t
        0x1t
        0x2ct
        -0x6et
        -0x4bt
        0x62t
        0x6t
        0x1t
        0x3t
        0x0t
        0x10t
        0x10t
        0x1t
        0x2bt
        -0x70t
        -0x4bt
        0x62t
        0x6t
        0x1t
        0x3t
        0x0t
        0x10t
        0x12t
        0x1t
        0x2dt
        -0x6ct
        -0x4bt
        0x62t
        0x6t
        0x1t
        0x3t
        0x0t
        0xat
        0x1ct
        0x1t
        0x31t
        -0x6at
        -0x4bt
        0x62t
        0x6t
        0x1t
        0x3t
        0x0t
        0xat
        0x26t
        0x1t
        0x3bt
        -0x56t
        -0x4bt
        0x62t
        0x6t
        0x1t
        0x3t
        0x0t
        0xat
        0x6t
        0x1t
        0x1bt
        0x6at
        -0x4bt
        0x62t
        0x6t
        0x1t
        0x3t
        0x0t
        0x1t
        0x60t
        0x1t
        0x6ct
        0x3t
        -0x4bt
        0x62t
        0x6t
        0x1t
        0x3t
        0x0t
        0x1t
        0x22t
        0x1t
        0x2et
        -0x79t
        -0x4bt
        0x62t
        0x6t
        0x1t
        0x3t
        0x0t
        0x1t
        0x7t
        0x1t
        0x13t
        0x51t
        -0x4bt
        0x62t
        0x6t
        0x1t
        0x3t
        0x0t
        0x1t
        0x6t
        0x1t
        0x12t
        0x4ft
        -0x4bt
        0x62t
        0x6t
        0x1t
        0x3t
        0x0t
        0x1t
        0x30t
        0x1t
        0x3ct
        -0x5dt
        -0x4bt
        0x62t
        0x6t
        0x1t
        0x3t
        0x0t
        0x2t
        0x20t
        0x1et
        0x4at
        -0x5dt
        -0x4bt
        0x62t
        0x6t
        0x1t
        0x3t
        0x0t
        0x3t
        0x10t
        0x1t
        0x1et
        0x69t
        -0x4bt
        0x62t
        0x6t
        0x1t
        0x3t
        0x0t
        0x3t
        0x2t
        0x1t
        0x10t
        0x4dt
        -0x4bt
        0x62t
        0x6t
        0x1t
        0x3t
        0x0t
        0x3t
        0xft
        0x1t
        0x1dt
        0x67t
        -0x4bt
        0x62t
        0x6t
        0x1t
        0x3t
        0x0t
        0x3t
        0x9t
        0x1t
        0x17t
        0x5bt
        -0x4bt
        0x62t
        0x6t
        0x1t
        0x3t
        0x0t
        0x3t
        0xat
        0x1t
        0x18t
        0x5dt
        -0x4bt
        0x62t
        0xct
        0x35t
        0x0t
        0x0t
        0x41t
        -0x31t
        -0x4bt
        0x62t
        0xat
        0x9t
        0x0t
        0x0t
        0x13t
        0x43t
        -0x4bt
        0x62t
        0xat
        0x5t
        0x0t
        0x0t
        0xft
        0x37t
        -0x4bt
        0x62t
        0xat
        0x4t
        0x0t
        0x0t
        0xet
        0x34t
        -0x4bt
        0x62t
        0x6t
        0x1t
        0x3t
        0x0t
        0x1t
        0x35t
        0x1t
        0x41t
        -0x53t
        -0x4bt
        0x62t
        0x6t
        0x1t
        0x3t
        0x0t
        0x1t
        0x32t
        0x1t
        0x3et
        -0x59t
        -0x4bt
        0x62t
        0x6t
        0x1t
        0x3t
        0x0t
        0x2t
        0x23t
        0x1t
        0x30t
        -0x74t
        -0x4bt
        0x62t
        0x6t
        0x1t
        0x3t
        0x0t
        0xat
        0x9t
        0x1t
        0x1et
        0x70t
    .end array-data
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .locals 8
    .param p1, "ctxt"    # Landroid/content/Context;

    .prologue
    const/4 v5, 0x3

    const-wide/16 v6, -0x1

    const/4 v4, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x0

    .line 370
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 33
    iput-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    .line 34
    iput-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->gravityModule:Lcom/thinkware/sundo/inavi3dservice/GravityModule;

    .line 35
    iput-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_mmcInfo:Lcom/tw/mapmatch/dataset/_MMCInfo;

    .line 36
    iput-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_gpsInfo:Lcom/tw/mapmatch/dataset/_GPSInfo;

    .line 37
    iput-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_satInfo:Lcom/tw/mapmatch/dataset/_SATInfo;

    .line 39
    new-instance v0, Lcom/tw/mapmatch/dataset/_MMOBD2Data;

    invoke-direct {v0}, Lcom/tw/mapmatch/dataset/_MMOBD2Data;-><init>()V

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_obd2Info:Lcom/tw/mapmatch/dataset/_MMOBD2Data;

    .line 40
    new-instance v0, Lcom/tw/mapmatch/dataset/_MISENData;

    invoke-direct {v0}, Lcom/tw/mapmatch/dataset/_MISENData;-><init>()V

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_misenData:Lcom/tw/mapmatch/dataset/_MISENData;

    .line 41
    iput-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_gi:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    .line 42
    iput-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mi:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    .line 43
    iput-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_si:Lcom/tw/mapmatch/remote/mapmatch/SATInfo;

    .line 53
    iput v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->nmeaLength:I

    .line 58
    new-array v0, v5, [I

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nUTC:[I

    .line 59
    new-array v0, v5, [I

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nUTC_old:[I

    .line 60
    iput v4, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nSpeedMode:I

    .line 63
    iput-short v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_VirtualMMCount:S

    .line 70
    const-wide/16 v0, 0x0

    iput-wide v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->delay_tm:J

    .line 71
    const-wide/16 v0, 0x0

    iput-wide v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->delay_tm_for_DR:J

    .line 74
    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v0

    iput-wide v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_VirtualMMTM:J

    .line 75
    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v0

    iput-wide v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_RealMMTM:J

    .line 76
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    iput-wide v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_prevTime_getMMCInfo:J

    .line 78
    iput-wide v6, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_endTM_Location:J

    .line 79
    iput-wide v6, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_endTM_Nmea:J

    .line 80
    const-wide/16 v0, 0x0

    iput-wide v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_delayTM_Nmea:J

    .line 83
    const/4 v0, 0x6

    new-array v0, v0, [Z

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsRunning:[Z

    .line 85
    iput-boolean v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsGpsOkay:Z

    .line 86
    iput-boolean v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsSimulateStartStop:Z

    .line 87
    iput-boolean v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsGPSConfiguration:Z

    .line 89
    iput-boolean v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bUsingGPSSocket:Z

    .line 90
    iput-boolean v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bUsingDRSolution:Z

    .line 92
    iput-boolean v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bUseOBD2:Z

    .line 93
    iput-boolean v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bOBD2DataUpdated:Z

    .line 99
    iput v4, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nCurrentMode:I

    .line 118
    iput-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_locManager:Landroid/location/LocationManager;

    .line 119
    iput-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_gpsSocket:Lcom/thinkware/sundo/inavi3dservice/GPSSocketClient;

    .line 169
    const-string v0, "force_inavi_nmea_on"

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->cmd01:Ljava/lang/String;

    .line 170
    const-string v0, "force_inavi_nmea_off"

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->cmd02:Ljava/lang/String;

    .line 172
    const-string v0, "0"

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->INNERGPSMODE:Ljava/lang/String;

    .line 173
    const-string v0, "1"

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->DRGPSMODE:Ljava/lang/String;

    .line 176
    const/4 v0, -0x1

    iput v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nSimulatePercent:I

    .line 181
    sget-object v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule$LogMode;->LOG_NONE:Lcom/thinkware/sundo/inavi3dservice/MMCModule$LogMode;

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_logmode:Lcom/thinkware/sundo/inavi3dservice/MMCModule$LogMode;

    .line 366
    iput-boolean v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->bIsLogDrive:Z

    .line 999
    iput-short v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->speed_mps:S

    .line 1291
    new-instance v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule$1;

    invoke-direct {v0, p0}, Lcom/thinkware/sundo/inavi3dservice/MMCModule$1;-><init>(Lcom/thinkware/sundo/inavi3dservice/MMCModule;)V

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->gpsSocketThreadProc:Ljava/lang/Runnable;

    .line 1410
    new-instance v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule$2;

    invoke-direct {v0, p0}, Lcom/thinkware/sundo/inavi3dservice/MMCModule$2;-><init>(Lcom/thinkware/sundo/inavi3dservice/MMCModule;)V

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->nmeaListener:Landroid/location/GpsStatus$NmeaListener;

    .line 1410
    new-instance v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule$NmeaMsg;

    invoke-direct {v0, p0}, Lcom/thinkware/sundo/inavi3dservice/MMCModule$NmeaMsg;-><init>(Lcom/thinkware/sundo/inavi3dservice/MMCModule;)V

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->nmeaMsgListener:Landroid/location/OnNmeaMessageListener;

    .line 1484
    new-instance v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule$3;

    invoke-direct {v0, p0}, Lcom/thinkware/sundo/inavi3dservice/MMCModule$3;-><init>(Lcom/thinkware/sundo/inavi3dservice/MMCModule;)V

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->locationListener:Landroid/location/LocationListener;

    .line 1510
    new-instance v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule$4;

    invoke-direct {v0, p0}, Lcom/thinkware/sundo/inavi3dservice/MMCModule$4;-><init>(Lcom/thinkware/sundo/inavi3dservice/MMCModule;)V

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->MMCThreadProc:Ljava/lang/Runnable;

    .line 1570
    new-instance v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule$5;

    invoke-direct {v0, p0}, Lcom/thinkware/sundo/inavi3dservice/MMCModule$5;-><init>(Lcom/thinkware/sundo/inavi3dservice/MMCModule;)V

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->LogThreadProcInJava:Ljava/lang/Runnable;

    .line 1602
    new-instance v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule$6;

    invoke-direct {v0, p0}, Lcom/thinkware/sundo/inavi3dservice/MMCModule$6;-><init>(Lcom/thinkware/sundo/inavi3dservice/MMCModule;)V

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->LogThreadProc:Ljava/lang/Runnable;

    .line 1978
    new-instance v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule$7;

    invoke-direct {v0, p0}, Lcom/thinkware/sundo/inavi3dservice/MMCModule$7;-><init>(Lcom/thinkware/sundo/inavi3dservice/MMCModule;)V

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->mmcHandler:Landroid/os/Handler;

    .line 371
    iput-object p1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_ctxtParent:Landroid/content/Context;

    .line 372
    new-instance v0, Lcom/tw/mapmatch/jni/Natives;

    invoke-direct {v0}, Lcom/tw/mapmatch/jni/Natives;-><init>()V

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    .line 374
    new-instance v0, Lcom/thinkware/sundo/inavi3dservice/GravityModule;

    iget-object v1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->mmcHandler:Landroid/os/Handler;

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    invoke-direct {v0, p1, v1, v2}, Lcom/thinkware/sundo/inavi3dservice/GravityModule;-><init>(Landroid/content/Context;Landroid/os/Handler;Lcom/tw/mapmatch/jni/Natives;)V

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->gravityModule:Lcom/thinkware/sundo/inavi3dservice/GravityModule;

    .line 376
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsRunning:[Z

    aput-boolean v3, v0, v3

    .line 377
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsRunning:[Z

    aput-boolean v3, v0, v4

    .line 378
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsRunning:[Z

    const/4 v1, 0x2

    aput-boolean v3, v0, v1

    .line 379
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsRunning:[Z

    aput-boolean v3, v0, v5

    .line 380
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsRunning:[Z

    const/4 v1, 0x4

    aput-boolean v3, v0, v1

    .line 381
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsRunning:[Z

    const/4 v1, 0x5

    aput-boolean v3, v0, v1

    .line 383
    iput-wide v6, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->nmea_timestamp:J

    .line 384
    iput-wide v6, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->location_timestamp:J

    .line 386
    new-instance v0, Lcom/tw/mapmatch/dataset/_MMCInfo;

    invoke-direct {v0}, Lcom/tw/mapmatch/dataset/_MMCInfo;-><init>()V

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_mmcInfo:Lcom/tw/mapmatch/dataset/_MMCInfo;

    .line 387
    new-instance v0, Lcom/tw/mapmatch/dataset/_GPSInfo;

    invoke-direct {v0}, Lcom/tw/mapmatch/dataset/_GPSInfo;-><init>()V

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_gpsInfo:Lcom/tw/mapmatch/dataset/_GPSInfo;

    .line 388
    new-instance v0, Lcom/tw/mapmatch/dataset/_SATInfo;

    invoke-direct {v0}, Lcom/tw/mapmatch/dataset/_SATInfo;-><init>()V

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_satInfo:Lcom/tw/mapmatch/dataset/_SATInfo;

    .line 390
    new-instance v0, Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    invoke-direct {v0}, Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;-><init>()V

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_gi:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    .line 391
    new-instance v0, Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    invoke-direct {v0}, Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;-><init>()V

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mi:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    .line 392
    new-instance v0, Lcom/tw/mapmatch/remote/mapmatch/SATInfo;

    invoke-direct {v0}, Lcom/tw/mapmatch/remote/mapmatch/SATInfo;-><init>()V

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_si:Lcom/tw/mapmatch/remote/mapmatch/SATInfo;

    .line 394
    new-instance v0, Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    invoke-direct {v0}, Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;-><init>()V

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_gi_dummy:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    .line 396
    new-instance v0, Lcom/tw/mapmatch/remote/mapmatch/SATInfo;

    invoke-direct {v0}, Lcom/tw/mapmatch/remote/mapmatch/SATInfo;-><init>()V

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_si_dummy:Lcom/tw/mapmatch/remote/mapmatch/SATInfo;

    .line 398
    iput-boolean v4, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsCar:Z

    .line 401
    new-instance v0, Ljava/lang/Thread;

    iget-object v1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->gpsSocketThreadProc:Ljava/lang/Runnable;

    const-string v2, "gpsSocketThreadProc"

    invoke-direct {v0, v1, v2}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_gpsThread:Ljava/lang/Thread;

    .line 403
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v0

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->IsThinkwareDevice()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v0

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->IsMoreKitKat()Z

    move-result v0

    if-eqz v0, :cond_0

    .line 405
    invoke-virtual {p0, v4}, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->setUsingVirtualRoute(Z)V

    .line 407
    invoke-virtual {p0, v4}, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->SetUsingGPSSocket(Z)V

    .line 416
    :goto_0
    return-void

    .line 412
    :cond_0
    invoke-virtual {p0, v3}, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->SetUsingGPSSocket(Z)V

    goto :goto_0
.end method

.method private Log(Ljava/lang/String;)V
    .locals 7
    .param p1, "log"    # Ljava/lang/String;

    .prologue
    const/4 v6, 0x1

    .line 190
    sget-object v4, Lcom/thinkware/sundo/inavi3dservice/MMCModule$8;->$SwitchMap$com$thinkware$sundo$inavi3dservice$MMCModule$LogMode:[I

    iget-object v5, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_logmode:Lcom/thinkware/sundo/inavi3dservice/MMCModule$LogMode;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3dservice/MMCModule$LogMode;->ordinal()I

    move-result v5

    aget v4, v4, v5

    packed-switch v4, :pswitch_data_0

    .line 228
    :cond_0
    :goto_0
    return-void

    .line 193
    :pswitch_0
    const-string v4, "MMCModule"

    invoke-static {v4, p1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    .line 199
    :pswitch_1
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    move-result-object v4

    invoke-virtual {v4}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getSuperCapPowerOff()Z

    move-result v4

    if-eq v4, v6, :cond_0

    .line 204
    const/4 v2, 0x0

    .line 206
    .local v2, "fos":Ljava/io/FileOutputStream;
    :try_start_0
    new-instance v3, Ljava/io/FileOutputStream;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    sget-object v5, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->kStorageRoot:Ljava/lang/String;

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string v5, "/gpslog/fileLog.txt"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v5, 0x1

    invoke-direct {v3, v4, v5}, Ljava/io/FileOutputStream;-><init>(Ljava/lang/String;Z)V
    :try_end_0
    .catch Ljava/io/FileNotFoundException; {:try_start_0 .. :try_end_0} :catch_1

    .end local v2    # "fos":Ljava/io/FileOutputStream;
    .local v3, "fos":Ljava/io/FileOutputStream;
    move-object v2, v3

    .line 216
    .end local v3    # "fos":Ljava/io/FileOutputStream;
    .restart local v2    # "fos":Ljava/io/FileOutputStream;
    :goto_1
    if-eqz v2, :cond_0

    .line 218
    :try_start_1
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string v5, "\n"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/String;->getBytes()[B

    move-result-object v4

    invoke-virtual {v2, v4}, Ljava/io/FileOutputStream;->write([B)V
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_0

    goto :goto_0

    .line 219
    :catch_0
    move-exception v0

    .line 221
    .local v0, "e":Ljava/io/IOException;
    const-string v4, "MMMCModule"

    invoke-static {v4, p1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    .line 207
    .end local v0    # "e":Ljava/io/IOException;
    :catch_1
    move-exception v0

    .line 210
    .local v0, "e":Ljava/io/FileNotFoundException;
    :try_start_2
    new-instance v3, Ljava/io/FileOutputStream;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    sget-object v5, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->kStorageRoot:Ljava/lang/String;

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string v5, "/gpslog/fileLog.txt"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v3, v4}, Ljava/io/FileOutputStream;-><init>(Ljava/lang/String;)V
    :try_end_2
    .catch Ljava/io/FileNotFoundException; {:try_start_2 .. :try_end_2} :catch_2

    .end local v2    # "fos":Ljava/io/FileOutputStream;
    .restart local v3    # "fos":Ljava/io/FileOutputStream;
    move-object v2, v3

    .line 214
    .end local v3    # "fos":Ljava/io/FileOutputStream;
    .restart local v2    # "fos":Ljava/io/FileOutputStream;
    goto :goto_1

    .line 211
    :catch_2
    move-exception v1

    .line 213
    .local v1, "e1":Ljava/io/FileNotFoundException;
    const-string v4, "MMMCModule"

    invoke-static {v4, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_1

    .line 190
    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_0
        :pswitch_1
    .end packed-switch
.end method

.method private Log(Ljava/lang/String;Ljava/lang/String;)V
    .locals 2
    .param p1, "tag"    # Ljava/lang/String;
    .param p2, "log"    # Ljava/lang/String;

    .prologue
    .line 186
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ": "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->Log(Ljava/lang/String;)V

    .line 187
    return-void
.end method

.method static synthetic access$000(Lcom/thinkware/sundo/inavi3dservice/MMCModule;)Z
    .locals 1
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3dservice/MMCModule;

    .prologue
    .line 31
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bUsingGPSSocket:Z

    return v0
.end method

.method static synthetic access$002(Lcom/thinkware/sundo/inavi3dservice/MMCModule;Z)Z
    .locals 0
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3dservice/MMCModule;
    .param p1, "x1"    # Z

    .prologue
    .line 31
    iput-boolean p1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bUsingGPSSocket:Z

    return p1
.end method

.method static synthetic access$100(Lcom/thinkware/sundo/inavi3dservice/MMCModule;)Lcom/thinkware/sundo/inavi3dservice/GPSSocketClient;
    .locals 1
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3dservice/MMCModule;

    .prologue
    .line 31
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_gpsSocket:Lcom/thinkware/sundo/inavi3dservice/GPSSocketClient;

    return-object v0
.end method

.method static synthetic access$1000(Lcom/thinkware/sundo/inavi3dservice/MMCModule;)Lcom/thinkware/sundo/inavi3dservice/GravityModule;
    .locals 1
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3dservice/MMCModule;

    .prologue
    .line 31
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->gravityModule:Lcom/thinkware/sundo/inavi3dservice/GravityModule;

    return-object v0
.end method

.method static synthetic access$102(Lcom/thinkware/sundo/inavi3dservice/MMCModule;Lcom/thinkware/sundo/inavi3dservice/GPSSocketClient;)Lcom/thinkware/sundo/inavi3dservice/GPSSocketClient;
    .locals 0
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3dservice/MMCModule;
    .param p1, "x1"    # Lcom/thinkware/sundo/inavi3dservice/GPSSocketClient;

    .prologue
    .line 31
    iput-object p1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_gpsSocket:Lcom/thinkware/sundo/inavi3dservice/GPSSocketClient;

    return-object p1
.end method

.method static synthetic access$1100()Ljava/lang/Object;
    .locals 1

    .prologue
    .line 31
    sget-object v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->mm_mutex:Ljava/lang/Object;

    return-object v0
.end method

.method static synthetic access$1200(Lcom/thinkware/sundo/inavi3dservice/MMCModule;I)V
    .locals 0
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3dservice/MMCModule;
    .param p1, "x1"    # I

    .prologue
    .line 31
    invoke-direct {p0, p1}, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->doRealMapMatch(I)V

    return-void
.end method

.method static synthetic access$1300(Lcom/thinkware/sundo/inavi3dservice/MMCModule;)Lcom/tw/mapmatch/jni/Natives;
    .locals 1
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3dservice/MMCModule;

    .prologue
    .line 31
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    return-object v0
.end method

.method static synthetic access$1400(Lcom/thinkware/sundo/inavi3dservice/MMCModule;SS)V
    .locals 0
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3dservice/MMCModule;
    .param p1, "x1"    # S
    .param p2, "x2"    # S

    .prologue
    .line 31
    invoke-direct {p0, p1, p2}, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->resetGps(SS)V

    return-void
.end method

.method static synthetic access$1500(Lcom/thinkware/sundo/inavi3dservice/MMCModule;)Z
    .locals 1
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3dservice/MMCModule;

    .prologue
    .line 31
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsCar:Z

    return v0
.end method

.method static synthetic access$1600(Lcom/thinkware/sundo/inavi3dservice/MMCModule;)Ljava/lang/Thread;
    .locals 1
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3dservice/MMCModule;

    .prologue
    .line 31
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_LogThread:Ljava/lang/Thread;

    return-object v0
.end method

.method static synthetic access$1602(Lcom/thinkware/sundo/inavi3dservice/MMCModule;Ljava/lang/Thread;)Ljava/lang/Thread;
    .locals 0
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3dservice/MMCModule;
    .param p1, "x1"    # Ljava/lang/Thread;

    .prologue
    .line 31
    iput-object p1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_LogThread:Ljava/lang/Thread;

    return-object p1
.end method

.method static synthetic access$1700(Lcom/thinkware/sundo/inavi3dservice/MMCModule;)Ljava/lang/Runnable;
    .locals 1
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3dservice/MMCModule;

    .prologue
    .line 31
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->LogThreadProc:Ljava/lang/Runnable;

    return-object v0
.end method

.method static synthetic access$200(Lcom/thinkware/sundo/inavi3dservice/MMCModule;)[Z
    .locals 1
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3dservice/MMCModule;

    .prologue
    .line 31
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsRunning:[Z

    return-object v0
.end method

.method static synthetic access$300(Lcom/thinkware/sundo/inavi3dservice/MMCModule;J[BI)V
    .locals 1
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3dservice/MMCModule;
    .param p1, "x1"    # J
    .param p3, "x2"    # [B
    .param p4, "x3"    # I

    .prologue
    .line 31
    invoke-direct {p0, p1, p2, p3, p4}, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->sendNMEAMessage(J[BI)V

    return-void
.end method

.method static synthetic access$400(Lcom/thinkware/sundo/inavi3dservice/MMCModule;)I
    .locals 1
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3dservice/MMCModule;

    .prologue
    .line 31
    iget v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nSpeedMode:I

    return v0
.end method

.method static synthetic access$500(Lcom/thinkware/sundo/inavi3dservice/MMCModule;)J
    .locals 2
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3dservice/MMCModule;

    .prologue
    .line 31
    iget-wide v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_RealMMTM:J

    return-wide v0
.end method

.method static synthetic access$600(Lcom/thinkware/sundo/inavi3dservice/MMCModule;)Z
    .locals 1
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3dservice/MMCModule;

    .prologue
    .line 31
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsSimulateStartStop:Z

    return v0
.end method

.method static synthetic access$602(Lcom/thinkware/sundo/inavi3dservice/MMCModule;Z)Z
    .locals 0
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3dservice/MMCModule;
    .param p1, "x1"    # Z

    .prologue
    .line 31
    iput-boolean p1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsSimulateStartStop:Z

    return p1
.end method

.method static synthetic access$700(Lcom/thinkware/sundo/inavi3dservice/MMCModule;)S
    .locals 1
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3dservice/MMCModule;

    .prologue
    .line 31
    iget-short v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_VirtualMMCount:S

    return v0
.end method

.method static synthetic access$702(Lcom/thinkware/sundo/inavi3dservice/MMCModule;S)S
    .locals 0
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3dservice/MMCModule;
    .param p1, "x1"    # S

    .prologue
    .line 31
    iput-short p1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_VirtualMMCount:S

    return p1
.end method

.method static synthetic access$708(Lcom/thinkware/sundo/inavi3dservice/MMCModule;)S
    .locals 2
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3dservice/MMCModule;

    .prologue
    .line 31
    iget-short v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_VirtualMMCount:S

    add-int/lit8 v1, v0, 0x1

    int-to-short v1, v1

    iput-short v1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_VirtualMMCount:S

    return v0
.end method

.method static synthetic access$800(Lcom/thinkware/sundo/inavi3dservice/MMCModule;)V
    .locals 0
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3dservice/MMCModule;

    .prologue
    .line 31
    invoke-direct {p0}, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->doVirtualMapMatch()V

    return-void
.end method

.method static synthetic access$900(Lcom/thinkware/sundo/inavi3dservice/MMCModule;)J
    .locals 2
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3dservice/MMCModule;

    .prologue
    .line 31
    iget-wide v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_VirtualMMTM:J

    return-wide v0
.end method

.method private createLocationManager()V
    .locals 9

    .prologue
    .line 420
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_locManager:Landroid/location/LocationManager;

    if-nez v0, :cond_2

    .line 421
    const-string v6, "location"

    .line 423
    .local v6, "context":Ljava/lang/String;
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_ctxtParent:Landroid/content/Context;

    invoke-virtual {v0, v6}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/location/LocationManager;

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_locManager:Landroid/location/LocationManager;

    .line 432
    const-string v0, "gps"

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_provider:Ljava/lang/String;

    .line 434
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v0

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->IsThinkwareDevice()Z

    move-result v0

    const/4 v1, 0x1

    if-ne v0, v1, :cond_0

    .line 438
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_locManager:Landroid/location/LocationManager;

    iget-object v1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_provider:Ljava/lang/String;

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->cmd01:Ljava/lang/String;

    const/4 v3, 0x0

    invoke-virtual {v0, v1, v2, v3}, Landroid/location/LocationManager;->sendExtraCommand(Ljava/lang/String;Ljava/lang/String;Landroid/os/Bundle;)Z

    .line 443
    :cond_0
    sget v7, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v8, 0x18

    if-lt v7, v8, :cond_1

    .line 443
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_locManager:Landroid/location/LocationManager;

    iget-object v1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->nmeaMsgListener:Landroid/location/OnNmeaMessageListener;

    const/4 v7, 0x0

    invoke-virtual {v0, v1, v7}, Landroid/location/LocationManager;->addNmeaListener(Landroid/location/OnNmeaMessageListener;Landroid/os/Handler;)Z

    goto :goto_0

    :cond_1
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_locManager:Landroid/location/LocationManager;

    iget-object v1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->nmeaListener:Landroid/location/GpsStatus$NmeaListener;

    invoke-virtual {v0, v1}, Landroid/location/LocationManager;->addNmeaListener(Landroid/location/GpsStatus$NmeaListener;)Z

    .line 444
    :goto_0
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_locManager:Landroid/location/LocationManager;

    iget-object v1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_provider:Ljava/lang/String;

    const-wide/16 v2, 0x3e8

    const/4 v4, 0x0

    iget-object v5, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->locationListener:Landroid/location/LocationListener;

    invoke-virtual/range {v0 .. v5}, Landroid/location/LocationManager;->requestLocationUpdates(Ljava/lang/String;JFLandroid/location/LocationListener;)V

    .line 446
    .end local v6    # "context":Ljava/lang/String;
    :cond_2
    return-void
.end method

.method private doRealMapMatch(I)V
    .locals 10
    .param p1, "nMode"    # I

    .prologue
    const-wide/16 v6, 0x3e8

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v9, 0x1

    const/4 v8, 0x0

    .line 791
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->gravityModule:Lcom/thinkware/sundo/inavi3dservice/GravityModule;

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3dservice/GravityModule;->getGPSInfo()Lcom/tw/mapmatch/dataset/_GPSInfo;

    move-result-object v0

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_gpsInfo:Lcom/tw/mapmatch/dataset/_GPSInfo;

    .line 800
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_gpsInfo:Lcom/tw/mapmatch/dataset/_GPSInfo;

    if-eqz v0, :cond_0

    .line 802
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nUTC:[I

    iget-object v1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_gpsInfo:Lcom/tw/mapmatch/dataset/_GPSInfo;

    iget-object v1, v1, Lcom/tw/mapmatch/dataset/_GPSInfo;->UTC:[B

    aget-byte v1, v1, v8

    aput v1, v0, v8

    .line 803
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nUTC:[I

    iget-object v1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_gpsInfo:Lcom/tw/mapmatch/dataset/_GPSInfo;

    iget-object v1, v1, Lcom/tw/mapmatch/dataset/_GPSInfo;->UTC:[B

    aget-byte v1, v1, v9

    aput v1, v0, v9

    .line 804
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nUTC:[I

    iget-object v1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_gpsInfo:Lcom/tw/mapmatch/dataset/_GPSInfo;

    iget-object v1, v1, Lcom/tw/mapmatch/dataset/_GPSInfo;->UTC:[B

    aget-byte v1, v1, v2

    aput v1, v0, v2

    .line 806
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_gpsInfo:Lcom/tw/mapmatch/dataset/_GPSInfo;

    iget-object v0, v0, Lcom/tw/mapmatch/dataset/_GPSInfo;->UTC:[B

    aget-byte v0, v0, v8

    if-nez v0, :cond_1

    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_gpsInfo:Lcom/tw/mapmatch/dataset/_GPSInfo;

    iget-object v0, v0, Lcom/tw/mapmatch/dataset/_GPSInfo;->UTC:[B

    aget-byte v0, v0, v9

    if-nez v0, :cond_1

    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_gpsInfo:Lcom/tw/mapmatch/dataset/_GPSInfo;

    iget-object v0, v0, Lcom/tw/mapmatch/dataset/_GPSInfo;->UTC:[B

    aget-byte v0, v0, v2

    if-nez v0, :cond_1

    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_gpsInfo:Lcom/tw/mapmatch/dataset/_GPSInfo;

    iget v0, v0, Lcom/tw/mapmatch/dataset/_GPSInfo;->Lon:I

    if-nez v0, :cond_1

    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_gpsInfo:Lcom/tw/mapmatch/dataset/_GPSInfo;

    iget v0, v0, Lcom/tw/mapmatch/dataset/_GPSInfo;->Lat:I

    if-nez v0, :cond_1

    .line 809
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsRunning:[Z

    aput-boolean v9, v0, v3

    .line 891
    :cond_0
    :goto_0
    return-void

    .line 811
    :cond_1
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nUTC:[I

    aget v0, v0, v8

    iget-object v1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nUTC_old:[I

    aget v1, v1, v8

    if-ne v0, v1, :cond_2

    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nUTC:[I

    aget v0, v0, v9

    iget-object v1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nUTC_old:[I

    aget v1, v1, v9

    if-ne v0, v1, :cond_2

    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nUTC:[I

    aget v0, v0, v2

    iget-object v1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nUTC_old:[I

    aget v1, v1, v2

    if-eq v0, v1, :cond_0

    .line 813
    :cond_2
    const-wide/16 v0, 0x0

    iput-wide v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->delay_tm_for_DR:J

    .line 814
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsRunning:[Z

    aput-boolean v8, v0, v3

    .line 816
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nUTC_old:[I

    iget-object v1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nUTC:[I

    aget v1, v1, v8

    aput v1, v0, v8

    .line 817
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nUTC_old:[I

    iget-object v1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nUTC:[I

    aget v1, v1, v9

    aput v1, v0, v9

    .line 818
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nUTC_old:[I

    iget-object v1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nUTC:[I

    aget v1, v1, v2

    aput v1, v0, v2

    .line 824
    sput-boolean v9, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->test_rmm:Z

    .line 826
    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v0

    iput-wide v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_RealMMTM:J

    .line 827
    iput-short v8, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_VirtualMMCount:S

    .line 829
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bUseOBD2:Z

    if-eqz v0, :cond_3

    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bOBD2DataUpdated:Z

    if-eqz v0, :cond_3

    .line 833
    invoke-direct {p0}, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->setOBD2nmea()V

    .line 839
    :cond_3
    iput p1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nCurrentMode:I

    .line 841
    const-string v0, "MMCModule"

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "UTC: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_gpsInfo:Lcom/tw/mapmatch/dataset/_GPSInfo;

    iget-short v2, v2, Lcom/tw/mapmatch/dataset/_GPSInfo;->UTC_hh:S

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ":"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_gpsInfo:Lcom/tw/mapmatch/dataset/_GPSInfo;

    iget-short v2, v2, Lcom/tw/mapmatch/dataset/_GPSInfo;->UTC_mm:S

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ":"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_gpsInfo:Lcom/tw/mapmatch/dataset/_GPSInfo;

    iget-short v2, v2, Lcom/tw/mapmatch/dataset/_GPSInfo;->UTC_ss:S

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ", GPS_SPEED:"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_gpsInfo:Lcom/tw/mapmatch/dataset/_GPSInfo;

    iget-short v2, v2, Lcom/tw/mapmatch/dataset/_GPSInfo;->SpeedK:S

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ",  MMC_SPEED:"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_mmcInfo:Lcom/tw/mapmatch/dataset/_MMCInfo;

    iget v2, v2, Lcom/tw/mapmatch/dataset/_MMCInfo;->speed_kmh:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ", lat:"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_mmcInfo:Lcom/tw/mapmatch/dataset/_MMCInfo;

    iget v2, v2, Lcom/tw/mapmatch/dataset/_MMCInfo;->lat:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ", lon:"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_mmcInfo:Lcom/tw/mapmatch/dataset/_MMCInfo;

    iget v2, v2, Lcom/tw/mapmatch/dataset/_MMCInfo;->lon:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ", status:"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_mmcInfo:Lcom/tw/mapmatch/dataset/_MMCInfo;

    iget-short v2, v2, Lcom/tw/mapmatch/dataset/_MMCInfo;->status:S

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 843
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    iget v1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nCurrentMode:I

    invoke-virtual {v0, v8, v1}, Lcom/tw/mapmatch/jni/Natives;->nativeMapMatch(ZI)I

    .line 846
    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v0

    iget-wide v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_RealMMTM:J

    sub-long/2addr v0, v2

    iput-wide v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->delay_tm:J

    .line 847
    const-string v0, "MMC"

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Real MM(Nmea) Time : "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-wide v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->delay_tm:J

    div-long/2addr v2, v6

    invoke-virtual {v1, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "us : "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-wide v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->delay_tm:J

    const-wide/32 v4, 0xf4240

    div-long/2addr v2, v4

    invoke-virtual {v1, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "ms"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {p0, v0, v1}, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->Log(Ljava/lang/String;Ljava/lang/String;)V

    .line 848
    const-string v0, "MMCModule"

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Real MM(Nmea) Time : "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-wide v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->delay_tm:J

    div-long/2addr v2, v6

    invoke-virtual {v1, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "us : "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-wide v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->delay_tm:J

    const-wide/32 v4, 0xf4240

    div-long/2addr v2, v4

    invoke-virtual {v1, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "ms"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 850
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->gravityModule:Lcom/thinkware/sundo/inavi3dservice/GravityModule;

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3dservice/GravityModule;->getGPSInfo()Lcom/tw/mapmatch/dataset/_GPSInfo;

    move-result-object v0

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_gpsInfo:Lcom/tw/mapmatch/dataset/_GPSInfo;

    .line 853
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    invoke-virtual {v0}, Lcom/tw/mapmatch/jni/Natives;->nativeGetMMCInfo()Lcom/tw/mapmatch/dataset/_MMCInfo;

    move-result-object v0

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_mmcInfo:Lcom/tw/mapmatch/dataset/_MMCInfo;

    .line 854
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_mmcInfo:Lcom/tw/mapmatch/dataset/_MMCInfo;

    invoke-direct {p0, v0}, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->setMMCInfo(Lcom/tw/mapmatch/dataset/_MMCInfo;)V

    .line 855
    const-string v0, "MMC"

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "UTC: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_gpsInfo:Lcom/tw/mapmatch/dataset/_GPSInfo;

    iget-short v2, v2, Lcom/tw/mapmatch/dataset/_GPSInfo;->UTC_hh:S

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ":"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_gpsInfo:Lcom/tw/mapmatch/dataset/_GPSInfo;

    iget-short v2, v2, Lcom/tw/mapmatch/dataset/_GPSInfo;->UTC_mm:S

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ":"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_gpsInfo:Lcom/tw/mapmatch/dataset/_GPSInfo;

    iget-short v2, v2, Lcom/tw/mapmatch/dataset/_GPSInfo;->UTC_ss:S

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ", GPS_SPEED:"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_gpsInfo:Lcom/tw/mapmatch/dataset/_GPSInfo;

    iget-short v2, v2, Lcom/tw/mapmatch/dataset/_GPSInfo;->SpeedK:S

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ",  MMC_SPEED:"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_mmcInfo:Lcom/tw/mapmatch/dataset/_MMCInfo;

    iget v2, v2, Lcom/tw/mapmatch/dataset/_MMCInfo;->speed_kmh:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ", lat:"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_mmcInfo:Lcom/tw/mapmatch/dataset/_MMCInfo;

    iget v2, v2, Lcom/tw/mapmatch/dataset/_MMCInfo;->lat:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ", lon:"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_mmcInfo:Lcom/tw/mapmatch/dataset/_MMCInfo;

    iget v2, v2, Lcom/tw/mapmatch/dataset/_MMCInfo;->lon:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ", status:"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_mmcInfo:Lcom/tw/mapmatch/dataset/_MMCInfo;

    iget-short v2, v2, Lcom/tw/mapmatch/dataset/_MMCInfo;->status:S

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {p0, v0, v1}, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->Log(Ljava/lang/String;Ljava/lang/String;)V

    .line 858
    const-string v0, "VMM"

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "R:mapid:"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_mmcInfo:Lcom/tw/mapmatch/dataset/_MMCInfo;

    iget-short v2, v2, Lcom/tw/mapmatch/dataset/_MMCInfo;->mapid:S

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ",linkid:"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_mmcInfo:Lcom/tw/mapmatch/dataset/_MMCInfo;

    iget-short v2, v2, Lcom/tw/mapmatch/dataset/_MMCInfo;->linkid:S

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ",reversed:"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_mmcInfo:Lcom/tw/mapmatch/dataset/_MMCInfo;

    iget-short v2, v2, Lcom/tw/mapmatch/dataset/_MMCInfo;->reversed:S

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ",lon:"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "%.3f"

    new-array v3, v9, [Ljava/lang/Object;

    iget-object v4, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_mmcInfo:Lcom/tw/mapmatch/dataset/_MMCInfo;

    iget v4, v4, Lcom/tw/mapmatch/dataset/_MMCInfo;->lon:I

    int-to-double v4, v4

    iget-object v6, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_mmcInfo:Lcom/tw/mapmatch/dataset/_MMCInfo;

    iget-wide v6, v6, Lcom/tw/mapmatch/dataset/_MMCInfo;->restlon:D

    add-double/2addr v4, v6

    invoke-static {v4, v5}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v4

    aput-object v4, v3, v8

    invoke-static {v2, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ",lat:"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "%.3f"

    new-array v3, v9, [Ljava/lang/Object;

    iget-object v4, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_mmcInfo:Lcom/tw/mapmatch/dataset/_MMCInfo;

    iget v4, v4, Lcom/tw/mapmatch/dataset/_MMCInfo;->lat:I

    int-to-double v4, v4

    iget-object v6, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_mmcInfo:Lcom/tw/mapmatch/dataset/_MMCInfo;

    iget-wide v6, v6, Lcom/tw/mapmatch/dataset/_MMCInfo;->restlat:D

    add-double/2addr v4, v6

    invoke-static {v4, v5}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v4

    aput-object v4, v3, v8

    invoke-static {v2, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ",heading:"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_mmcInfo:Lcom/tw/mapmatch/dataset/_MMCInfo;

    iget-short v2, v2, Lcom/tw/mapmatch/dataset/_MMCInfo;->heading:S

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {p0, v0, v1}, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->Log(Ljava/lang/String;Ljava/lang/String;)V

    .line 872
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_gpsInfo:Lcom/tw/mapmatch/dataset/_GPSInfo;

    invoke-direct {p0, v0}, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->setGPSInfo(Lcom/tw/mapmatch/dataset/_GPSInfo;)V

    .line 874
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    invoke-virtual {v0}, Lcom/tw/mapmatch/jni/Natives;->nativeGetSATInfo()Lcom/tw/mapmatch/dataset/_SATInfo;

    move-result-object v0

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_satInfo:Lcom/tw/mapmatch/dataset/_SATInfo;

    .line 875
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_satInfo:Lcom/tw/mapmatch/dataset/_SATInfo;

    invoke-direct {p0, v0}, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->setSATInfo(Lcom/tw/mapmatch/dataset/_SATInfo;)V

    .line 880
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_gpsInfo:Lcom/tw/mapmatch/dataset/_GPSInfo;

    iget-object v1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_mmcInfo:Lcom/tw/mapmatch/dataset/_MMCInfo;

    iget v1, v1, Lcom/tw/mapmatch/dataset/_MMCInfo;->speed_kmh:I

    mul-int/lit8 v1, v1, 0xa

    int-to-short v1, v1

    iput-short v1, v0, Lcom/tw/mapmatch/dataset/_GPSInfo;->SpeedK:S

    .line 881
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_mmcInfo:Lcom/tw/mapmatch/dataset/_MMCInfo;

    iget v0, v0, Lcom/tw/mapmatch/dataset/_MMCInfo;->speed_kmh:I

    sput v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->speed:I

    .line 882
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_mmcInfo:Lcom/tw/mapmatch/dataset/_MMCInfo;

    iget-short v0, v0, Lcom/tw/mapmatch/dataset/_MMCInfo;->speed:S

    iput-short v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->speed_mps:S

    .line 884
    sput-boolean v8, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->test_rmm:Z

    .line 885
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    invoke-virtual {v0}, Lcom/tw/mapmatch/jni/Natives;->nativeGetMISENData()Lcom/tw/mapmatch/dataset/_MISENData;

    move-result-object v0

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_misenData:Lcom/tw/mapmatch/dataset/_MISENData;

    goto/16 :goto_0
.end method

.method private doVirtualMapMatch()V
    .locals 13

    .prologue
    const/4 v12, 0x0

    const/4 v6, 0x1

    .line 916
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_ctxtParent:Landroid/content/Context;

    invoke-virtual {v3}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v3

    const-string v4, "gps"

    invoke-direct {p0, v3, v4}, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->isLocationProviderEnabled(Landroid/content/ContentResolver;Ljava/lang/String;)Z

    move-result v3

    iput-boolean v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsGPSConfiguration:Z

    .line 919
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    if-eqz v3, :cond_1

    .line 921
    const/4 v2, 0x0

    .line 923
    .local v2, "nRet":I
    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v0

    .line 925
    .local v0, "curTime":J
    sget-object v4, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->mm_mutex:Ljava/lang/Object;

    monitor-enter v4

    .line 927
    const/4 v3, 0x1

    :try_start_0
    sput-boolean v3, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->test_vmm:Z

    .line 928
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsRunning:[Z

    const/4 v5, 0x5

    aget-boolean v3, v3, v5

    if-ne v3, v6, :cond_3

    .line 930
    iget-wide v6, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_VirtualMMTM:J

    sub-long v6, v0, v6

    iput-wide v6, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->delay_tm:J

    .line 931
    iget-wide v6, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->delay_tm_for_DR:J

    iget-wide v8, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->delay_tm:J

    const-wide/32 v10, 0xf4240

    div-long/2addr v8, v10

    add-long/2addr v6, v8

    iput-wide v6, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->delay_tm_for_DR:J

    .line 933
    iget-wide v6, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->delay_tm_for_DR:J

    const-wide/16 v8, 0x384

    cmp-long v3, v6, v8

    if-lez v3, :cond_2

    .line 934
    const-wide/16 v6, 0x0

    iput-wide v6, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->delay_tm_for_DR:J

    .line 935
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    const/4 v5, 0x0

    iget v6, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nCurrentMode:I

    invoke-virtual {v3, v5, v6}, Lcom/tw/mapmatch/jni/Natives;->nativeMapMatch(ZI)I

    .line 938
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    invoke-virtual {v3}, Lcom/tw/mapmatch/jni/Natives;->nativeGetSATInfo()Lcom/tw/mapmatch/dataset/_SATInfo;

    move-result-object v3

    iput-object v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_satInfo:Lcom/tw/mapmatch/dataset/_SATInfo;

    .line 939
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_satInfo:Lcom/tw/mapmatch/dataset/_SATInfo;

    invoke-direct {p0, v3}, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->setSATInfo(Lcom/tw/mapmatch/dataset/_SATInfo;)V

    .line 950
    :cond_0
    :goto_0
    invoke-direct {p0}, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->getGpsStatus()I

    move-result v2

    .line 951
    if-nez v2, :cond_4

    .line 952
    const/4 v3, 0x0

    iput-boolean v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsGpsOkay:Z

    .line 958
    :goto_1
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    invoke-virtual {v3}, Lcom/tw/mapmatch/jni/Natives;->nativeGetMMCInfo()Lcom/tw/mapmatch/dataset/_MMCInfo;

    move-result-object v3

    iput-object v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_mmcInfo:Lcom/tw/mapmatch/dataset/_MMCInfo;

    .line 959
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_mmcInfo:Lcom/tw/mapmatch/dataset/_MMCInfo;

    sget v5, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->speed:I

    iput v5, v3, Lcom/tw/mapmatch/dataset/_MMCInfo;->speed_kmh:I

    .line 960
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_mmcInfo:Lcom/tw/mapmatch/dataset/_MMCInfo;

    iget-short v5, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->speed_mps:S

    iput-short v5, v3, Lcom/tw/mapmatch/dataset/_MMCInfo;->speed:S

    .line 961
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_mmcInfo:Lcom/tw/mapmatch/dataset/_MMCInfo;

    invoke-direct {p0, v3}, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->setMMCInfo(Lcom/tw/mapmatch/dataset/_MMCInfo;)V

    .line 968
    monitor-exit v4
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 971
    iput-wide v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_VirtualMMTM:J

    .line 973
    sput-boolean v12, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->test_vmm:Z

    .line 975
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    invoke-virtual {v3}, Lcom/tw/mapmatch/jni/Natives;->nativeGetSimulatePos()I

    move-result v3

    iput v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nSimulatePercent:I

    .line 977
    .end local v0    # "curTime":J
    .end local v2    # "nRet":I
    :cond_1
    return-void

    .line 942
    .restart local v0    # "curTime":J
    .restart local v2    # "nRet":I
    :cond_2
    :try_start_1
    iget-boolean v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsSimulateStartStop:Z

    if-eqz v3, :cond_0

    .line 943
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    const/4 v5, 0x1

    iget v6, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nCurrentMode:I

    invoke-virtual {v3, v5, v6}, Lcom/tw/mapmatch/jni/Natives;->nativeMapMatch(ZI)I

    goto :goto_0

    .line 968
    :catchall_0
    move-exception v3

    monitor-exit v4
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw v3

    .line 947
    :cond_3
    :try_start_2
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    const/4 v5, 0x1

    iget v6, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nCurrentMode:I

    invoke-virtual {v3, v5, v6}, Lcom/tw/mapmatch/jni/Natives;->nativeMapMatch(ZI)I

    goto :goto_0

    .line 954
    :cond_4
    const/4 v3, 0x1

    iput-boolean v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsGpsOkay:Z
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    goto :goto_1
.end method

.method private getGpsMode()Ljava/lang/String;
    .locals 5

    .prologue
    .line 523
    const-string v2, ""

    .line 525
    .local v2, "line":Ljava/lang/String;
    :try_start_0
    invoke-static {}, Ljava/lang/Runtime;->getRuntime()Ljava/lang/Runtime;

    move-result-object v3

    const-string v4, "getprop persist.sys.drgps"

    invoke-virtual {v3, v4}, Ljava/lang/Runtime;->exec(Ljava/lang/String;)Ljava/lang/Process;

    move-result-object v1

    .line 526
    .local v1, "ifc":Ljava/lang/Process;
    new-instance v0, Ljava/io/BufferedReader;

    new-instance v3, Ljava/io/InputStreamReader;

    invoke-virtual {v1}, Ljava/lang/Process;->getInputStream()Ljava/io/InputStream;

    move-result-object v4

    invoke-direct {v3, v4}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;)V

    invoke-direct {v0, v3}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V

    .line 527
    .local v0, "bis":Ljava/io/BufferedReader;
    invoke-virtual {v0}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    move-result-object v2

    .line 528
    invoke-virtual {v1}, Ljava/lang/Process;->destroy()V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    .line 532
    .end local v0    # "bis":Ljava/io/BufferedReader;
    .end local v1    # "ifc":Ljava/lang/Process;
    :goto_0
    const-string v3, ""

    invoke-virtual {v2, v3}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_0

    const-string v2, "0"

    .line 533
    :cond_0
    return-object v2

    .line 529
    :catch_0
    move-exception v3

    goto :goto_0
.end method

.method private getGpsStatus()I
    .locals 10

    .prologue
    .line 1636
    const/4 v0, 0x0

    .line 1637
    .local v0, "bIsLocation":Z
    const/4 v1, 0x0

    .line 1639
    .local v1, "bIsNmea":Z
    const/4 v4, 0x0

    .line 1642
    .local v4, "nRet":I
    iget-wide v6, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_endTM_Location:J

    const-wide/16 v8, 0x0

    cmp-long v5, v6, v8

    if-gez v5, :cond_2

    .line 1644
    const/4 v0, 0x0

    .line 1658
    :goto_0
    iget-wide v6, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_endTM_Nmea:J

    const-wide/16 v8, 0x0

    cmp-long v5, v6, v8

    if-gez v5, :cond_4

    .line 1660
    const/4 v1, 0x0

    .line 1673
    :goto_1
    const/4 v5, 0x1

    if-ne v1, v5, :cond_6

    .line 1674
    const/4 v4, 0x2

    .line 1679
    :cond_0
    :goto_2
    iget-object v5, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_gi:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    iget-short v5, v5, Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;->UTC_hh:S

    if-nez v5, :cond_1

    iget-object v5, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_gi:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    iget-short v5, v5, Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;->UTC_mm:S

    if-nez v5, :cond_1

    iget-object v5, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_gi:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    iget-short v5, v5, Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;->UTC_ss:S

    if-nez v5, :cond_1

    .line 1680
    const/4 v4, 0x0

    .line 1682
    :cond_1
    return v4

    .line 1646
    :cond_2
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v6

    iget-wide v8, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_endTM_Location:J

    sub-long v2, v6, v8

    .line 1648
    .local v2, "delay_location":J
    const-wide/16 v6, 0xbb8

    cmp-long v5, v2, v6

    if-lez v5, :cond_3

    .line 1650
    const/4 v0, 0x0

    goto :goto_0

    .line 1653
    :cond_3
    const/4 v0, 0x1

    goto :goto_0

    .line 1662
    .end local v2    # "delay_location":J
    :cond_4
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v6

    iget-wide v8, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_endTM_Nmea:J

    sub-long v2, v6, v8

    .line 1664
    .restart local v2    # "delay_location":J
    const-wide/16 v6, 0xbb8

    cmp-long v5, v2, v6

    if-lez v5, :cond_5

    .line 1666
    const/4 v1, 0x0

    goto :goto_1

    .line 1669
    :cond_5
    const/4 v1, 0x1

    goto :goto_1

    .line 1675
    .end local v2    # "delay_location":J
    :cond_6
    const/4 v5, 0x1

    if-ne v0, v5, :cond_0

    .line 1676
    const/4 v4, 0x1

    goto :goto_2
.end method

.method private isLocationProviderEnabled(Landroid/content/ContentResolver;Ljava/lang/String;)Z
    .locals 3
    .param p1, "cr"    # Landroid/content/ContentResolver;
    .param p2, "provider"    # Ljava/lang/String;

    .prologue
    .line 1691
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_locManager:Landroid/location/LocationManager;

    if-nez v0, :cond_0

    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_ctxtParent:Landroid/content/Context;

    const-string v1, "location"

    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/location/LocationManager;

    .line 1693
    :cond_0
    if-eqz v0, :cond_1

    :try_start_0
    invoke-virtual {v0, p2}, Landroid/location/LocationManager;->isProviderEnabled(Ljava/lang/String;)Z

    move-result v2

    return v2
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_0

    .line 1699
    :catch_0
    move-exception v1

    :cond_1
    const/4 v2, 0x0

    return v2
.end method

.method public static normalizeGnssNmea(Ljava/lang/String;)Ljava/lang/String;
    .locals 9

    .prologue
    if-eqz p0, :cond_4

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v1, 0x5

    if-lt v0, v1, :cond_4

    const/4 v0, 0x0

    const/4 v1, 0x3

    invoke-virtual {p0, v0, v1}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v0

    const-string v1, "$GN"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_0

    const-string v1, "$GL"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_0

    const-string v1, "$GA"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_0

    const-string v1, "$GB"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_0

    const-string v1, "$BD"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_4

    :cond_0
    const/4 v1, 0x3

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v2

    invoke-virtual {p0, v1, v2}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v2

    new-instance v3, Ljava/lang/StringBuilder;

    const-string v1, "$GP"

    invoke-direct {v3, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v3, "*"

    invoke-virtual {v1, v3}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result v3

    const/4 v4, -0x1

    if-eq v3, v4, :cond_3

    const/4 v4, 0x0

    const/4 v5, 0x1

    :goto_0
    if-ge v5, v3, :cond_1

    invoke-virtual {v1, v5}, Ljava/lang/String;->charAt(I)C

    move-result v6

    xor-int/2addr v4, v6

    add-int/lit8 v5, v5, 0x1

    goto :goto_0

    :cond_1
    add-int/lit8 v5, v3, 0x1

    const/4 v6, 0x0

    invoke-virtual {v1, v6, v5}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v6

    const/16 v7, 0x10

    invoke-static {v4, v7}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/String;->toUpperCase()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/String;->length()I

    move-result v8

    const/4 v5, 0x2

    if-ge v8, v5, :cond_2

    new-instance v5, Ljava/lang/StringBuilder;

    const-string v8, "0"

    invoke-direct {v5, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    :cond_2
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_3
    return-object v1

    :cond_4
    return-object p0
.end method

.method private resetGps(SS)V
    .locals 8
    .param p1, "gpsType"    # S
    .param p2, "msgType"    # S

    .prologue
    const/4 v7, 0x0

    const/4 v6, 0x1

    .line 1881
    iget-object v5, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_locManager:Landroid/location/LocationManager;

    if-nez v5, :cond_1

    .line 1977
    :cond_0
    :goto_0
    return-void

    .line 1882
    :cond_1
    sget-object v5, Lcom/thinkware/sundo/inavi3dservice/MMCModule$GPSTYPE;->ANDROID_DEFAULT:Lcom/thinkware/sundo/inavi3dservice/MMCModule$GPSTYPE;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3dservice/MMCModule$GPSTYPE;->value()S

    move-result v5

    if-ne p1, v5, :cond_5

    .line 1883
    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    .line 1885
    .local v0, "extras":Landroid/os/Bundle;
    sget-object v5, Lcom/thinkware/sundo/inavi3dservice/MMCModule$MSGTYPE;->FACTORYRESET:Lcom/thinkware/sundo/inavi3dservice/MMCModule$MSGTYPE;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3dservice/MMCModule$MSGTYPE;->value()S

    move-result v5

    if-ne p2, v5, :cond_2

    .line 1886
    const-string v5, "all"

    invoke-virtual {v0, v5, v6}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 1887
    iget-object v5, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_locManager:Landroid/location/LocationManager;

    const-string v6, "gps"

    const-string v7, "delete_aiding_data"

    invoke-virtual {v5, v6, v7, v0}, Landroid/location/LocationManager;->sendExtraCommand(Ljava/lang/String;Ljava/lang/String;Landroid/os/Bundle;)Z

    .line 1888
    const-string v5, "socket_test"

    const-string v6, "factory reset"

    invoke-static {v5, v6}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    .line 1891
    :cond_2
    sget-object v5, Lcom/thinkware/sundo/inavi3dservice/MMCModule$MSGTYPE;->COLDSTART:Lcom/thinkware/sundo/inavi3dservice/MMCModule$MSGTYPE;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3dservice/MMCModule$MSGTYPE;->value()S

    move-result v5

    if-ne p2, v5, :cond_3

    .line 1892
    const-string v5, "almanac"

    invoke-virtual {v0, v5, v6}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 1893
    const-string v5, "ephemeris"

    invoke-virtual {v0, v5, v6}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 1894
    const-string v5, "position"

    invoke-virtual {v0, v5, v6}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 1895
    const-string v5, "time"

    invoke-virtual {v0, v5, v6}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 1897
    iget-object v5, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_locManager:Landroid/location/LocationManager;

    const-string v6, "gps"

    const-string v7, "delete_aiding_data"

    invoke-virtual {v5, v6, v7, v0}, Landroid/location/LocationManager;->sendExtraCommand(Ljava/lang/String;Ljava/lang/String;Landroid/os/Bundle;)Z

    .line 1898
    const-string v5, "socket_test"

    const-string v6, "cold start"

    invoke-static {v5, v6}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    .line 1900
    :cond_3
    sget-object v5, Lcom/thinkware/sundo/inavi3dservice/MMCModule$MSGTYPE;->WARMSTART:Lcom/thinkware/sundo/inavi3dservice/MMCModule$MSGTYPE;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3dservice/MMCModule$MSGTYPE;->value()S

    move-result v5

    if-ne p2, v5, :cond_4

    .line 1902
    const-string v5, "ephemeris"

    invoke-virtual {v0, v5, v6}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 1903
    const-string v5, "position"

    invoke-virtual {v0, v5, v6}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 1904
    const-string v5, "time"

    invoke-virtual {v0, v5, v6}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 1906
    iget-object v5, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_locManager:Landroid/location/LocationManager;

    const-string v6, "gps"

    const-string v7, "delete_aiding_data"

    invoke-virtual {v5, v6, v7, v0}, Landroid/location/LocationManager;->sendExtraCommand(Ljava/lang/String;Ljava/lang/String;Landroid/os/Bundle;)Z

    .line 1907
    const-string v5, "socket_test"

    const-string v6, "warm start"

    invoke-static {v5, v6}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    .line 1910
    :cond_4
    sget-object v5, Lcom/thinkware/sundo/inavi3dservice/MMCModule$MSGTYPE;->HOTSTART:Lcom/thinkware/sundo/inavi3dservice/MMCModule$MSGTYPE;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3dservice/MMCModule$MSGTYPE;->value()S

    move-result v5

    if-ne p2, v5, :cond_0

    .line 1913
    const-string v5, "position"

    invoke-virtual {v0, v5, v6}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 1914
    const-string v5, "time"

    invoke-virtual {v0, v5, v6}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 1916
    iget-object v5, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_locManager:Landroid/location/LocationManager;

    const-string v6, "gps"

    const-string v7, "delete_aiding_data"

    invoke-virtual {v5, v6, v7, v0}, Landroid/location/LocationManager;->sendExtraCommand(Ljava/lang/String;Ljava/lang/String;Landroid/os/Bundle;)Z

    .line 1917
    const-string v5, "socket_test"

    const-string v6, "hot start"

    invoke-static {v5, v6}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    goto/16 :goto_0

    .line 1921
    .end local v0    # "extras":Landroid/os/Bundle;
    :cond_5
    sget-object v5, Lcom/thinkware/sundo/inavi3dservice/MMCModule$GPSTYPE;->OLD_ATHEROS:Lcom/thinkware/sundo/inavi3dservice/MMCModule$GPSTYPE;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3dservice/MMCModule$GPSTYPE;->value()S

    move-result v5

    if-ne p1, v5, :cond_9

    .line 1922
    sget-object v5, Lcom/thinkware/sundo/inavi3dservice/MMCModule$MSGTYPE;->FACTORYRESET:Lcom/thinkware/sundo/inavi3dservice/MMCModule$MSGTYPE;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3dservice/MMCModule$MSGTYPE;->value()S

    move-result v5

    if-ne p2, v5, :cond_6

    .line 1923
    const-string v2, "$PUNV,START,FACTORY*cc\r\n"

    .line 1924
    .local v2, "sMsgFactory":Ljava/lang/String;
    iget-object v5, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_locManager:Landroid/location/LocationManager;

    const-string v6, "gps"

    invoke-virtual {v5, v6, v2, v7}, Landroid/location/LocationManager;->sendExtraCommand(Ljava/lang/String;Ljava/lang/String;Landroid/os/Bundle;)Z

    goto/16 :goto_0

    .line 1926
    .end local v2    # "sMsgFactory":Ljava/lang/String;
    :cond_6
    sget-object v5, Lcom/thinkware/sundo/inavi3dservice/MMCModule$MSGTYPE;->COLDSTART:Lcom/thinkware/sundo/inavi3dservice/MMCModule$MSGTYPE;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3dservice/MMCModule$MSGTYPE;->value()S

    move-result v5

    if-ne p2, v5, :cond_7

    .line 1927
    const-string v1, "$PUNV,START,COLD*59\r\n"

    .line 1928
    .local v1, "sMsgCold":Ljava/lang/String;
    iget-object v5, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_locManager:Landroid/location/LocationManager;

    const-string v6, "gps"

    invoke-virtual {v5, v6, v1, v7}, Landroid/location/LocationManager;->sendExtraCommand(Ljava/lang/String;Ljava/lang/String;Landroid/os/Bundle;)Z

    goto/16 :goto_0

    .line 1930
    .end local v1    # "sMsgCold":Ljava/lang/String;
    :cond_7
    sget-object v5, Lcom/thinkware/sundo/inavi3dservice/MMCModule$MSGTYPE;->WARMSTART:Lcom/thinkware/sundo/inavi3dservice/MMCModule$MSGTYPE;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3dservice/MMCModule$MSGTYPE;->value()S

    move-result v5

    if-ne p2, v5, :cond_8

    .line 1931
    const-string v4, "$PUNV,START,WARM*54\r\n"

    .line 1932
    .local v4, "sMsgWarm":Ljava/lang/String;
    iget-object v5, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_locManager:Landroid/location/LocationManager;

    const-string v6, "gps"

    invoke-virtual {v5, v6, v4, v7}, Landroid/location/LocationManager;->sendExtraCommand(Ljava/lang/String;Ljava/lang/String;Landroid/os/Bundle;)Z

    goto/16 :goto_0

    .line 1934
    .end local v4    # "sMsgWarm":Ljava/lang/String;
    :cond_8
    sget-object v5, Lcom/thinkware/sundo/inavi3dservice/MMCModule$MSGTYPE;->HOTSTART:Lcom/thinkware/sundo/inavi3dservice/MMCModule$MSGTYPE;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3dservice/MMCModule$MSGTYPE;->value()S

    move-result v5

    if-ne p2, v5, :cond_0

    .line 1935
    const-string v3, "$PUNV,START,HOT*0E\r\n"

    .line 1936
    .local v3, "sMsgHot":Ljava/lang/String;
    iget-object v5, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_locManager:Landroid/location/LocationManager;

    const-string v6, "gps"

    invoke-virtual {v5, v6, v3, v7}, Landroid/location/LocationManager;->sendExtraCommand(Ljava/lang/String;Ljava/lang/String;Landroid/os/Bundle;)Z

    goto/16 :goto_0

    .line 1940
    .end local v3    # "sMsgHot":Ljava/lang/String;
    :cond_9
    sget-object v5, Lcom/thinkware/sundo/inavi3dservice/MMCModule$GPSTYPE;->OLD_UBLOX:Lcom/thinkware/sundo/inavi3dservice/MMCModule$GPSTYPE;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3dservice/MMCModule$GPSTYPE;->value()S

    move-result v5

    if-ne p1, v5, :cond_0

    .line 1941
    sget-object v5, Lcom/thinkware/sundo/inavi3dservice/MMCModule$MSGTYPE;->FACTORYRESET:Lcom/thinkware/sundo/inavi3dservice/MMCModule$MSGTYPE;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3dservice/MMCModule$MSGTYPE;->value()S

    move-result v5

    if-eq p2, v5, :cond_0

    .line 1943
    sget-object v5, Lcom/thinkware/sundo/inavi3dservice/MMCModule$MSGTYPE;->COLDSTART:Lcom/thinkware/sundo/inavi3dservice/MMCModule$MSGTYPE;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3dservice/MMCModule$MSGTYPE;->value()S

    move-result v5

    if-ne p2, v5, :cond_a

    .line 1944
    sget-boolean v5, Lcom/tw/mapmatch/HelperFunctions;->OLD_K9_COMPATIBILITY:Z

    if-eqz v5, :cond_0

    goto/16 :goto_0

    .line 1956
    :cond_a
    sget-object v5, Lcom/thinkware/sundo/inavi3dservice/MMCModule$MSGTYPE;->WARMSTART:Lcom/thinkware/sundo/inavi3dservice/MMCModule$MSGTYPE;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3dservice/MMCModule$MSGTYPE;->value()S

    move-result v5

    if-eq p2, v5, :cond_0

    .line 1966
    sget-object v5, Lcom/thinkware/sundo/inavi3dservice/MMCModule$MSGTYPE;->HOTSTART:Lcom/thinkware/sundo/inavi3dservice/MMCModule$MSGTYPE;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3dservice/MMCModule$MSGTYPE;->value()S

    move-result v5

    if-ne p2, v5, :cond_0

    goto/16 :goto_0
.end method

.method private sendNMEAMessage(J[BI)V
    .locals 15
    .param p1, "timestamp"    # J
    .param p3, "nmea"    # [B
    .param p4, "size"    # I

    .prologue
    .line 1429
    const/4 v2, 0x0

    .line 1431
    .local v2, "nRet":I
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsRunning:[Z

    const/4 v8, 0x2

    aget-boolean v3, v3, v8

    const/4 v8, 0x1

    if-ne v3, v8, :cond_0

    .line 1481
    :goto_0
    return-void

    .line 1437
    :cond_0
    move-wide/from16 v0, p1

    iput-wide v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->nmea_timestamp:J

    .line 1441
    iget-wide v8, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_delayTM_Nmea:J

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v10

    iget-wide v12, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_endTM_Nmea:J

    sub-long/2addr v10, v12

    add-long/2addr v8, v10

    iput-wide v8, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_delayTM_Nmea:J

    .line 1444
    iget-wide v8, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_delayTM_Nmea:J

    const-wide/16 v10, 0x5dc

    cmp-long v3, v8, v10

    if-ltz v3, :cond_1

    .line 1447
    const-wide/16 v8, 0x0

    iput-wide v8, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_delayTM_Nmea:J

    .line 1452
    :cond_1
    sget-object v8, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->mm_mutex:Ljava/lang/Object;

    monitor-enter v8

    .line 1454
    const/4 v3, 0x1

    :try_start_0
    sput-boolean v3, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->test_nmea:Z

    .line 1455
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->gravityModule:Lcom/thinkware/sundo/inavi3dservice/GravityModule;

    move-object/from16 v0, p3

    move/from16 v1, p4

    invoke-virtual {v3, v0, v1}, Lcom/thinkware/sundo/inavi3dservice/GravityModule;->setNMEABytes([BI)I

    move-result v2

    .line 1456
    sget v3, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->nmea_size:I

    add-int v3, v3, p4

    sput v3, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->nmea_size:I

    .line 1461
    const/4 v3, 0x1

    if-ne v2, v3, :cond_2

    .line 1463
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v4

    .line 1464
    .local v4, "tick":J
    const/4 v3, 0x1

    invoke-direct {p0, v3}, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->doRealMapMatch(I)V

    .line 1465
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v10

    sub-long v6, v10, v4

    .line 1466
    .local v6, "timegap":J
    const-string v3, "MMC"

    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    const-string v10, "RealMapMatch timeGap: "

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9, v6, v7}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v9

    const-string v10, " , m_delayTM_Nmea: "

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    iget-wide v10, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_delayTM_Nmea:J

    invoke-virtual {v9, v10, v11}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-direct {p0, v3, v9}, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->Log(Ljava/lang/String;Ljava/lang/String;)V

    .line 1468
    const/4 v3, 0x0

    sput v3, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->nmea_size:I

    .line 1471
    const-wide/16 v10, 0x0

    iput-wide v10, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_delayTM_Nmea:J

    .line 1475
    .end local v4    # "tick":J
    .end local v6    # "timegap":J
    :cond_2
    const/4 v3, 0x0

    sput-boolean v3, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->test_nmea:Z

    .line 1476
    monitor-exit v8
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 1479
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v8

    iput-wide v8, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_endTM_Nmea:J

    goto :goto_0

    .line 1476
    :catchall_0
    move-exception v3

    :try_start_1
    monitor-exit v8
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw v3
.end method

.method private setGPSInfo(Lcom/tw/mapmatch/dataset/_GPSInfo;)V
    .locals 6
    .param p1, "_gpsInfo"    # Lcom/tw/mapmatch/dataset/_GPSInfo;

    .prologue
    const/4 v5, 0x0

    const/4 v4, 0x1

    .line 1704
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_gi:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    iget-short v1, p1, Lcom/tw/mapmatch/dataset/_GPSInfo;->UsedSatNo:S

    iput-short v1, v0, Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;->UsedSatNo:S

    .line 1705
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_gi:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    iget-short v1, p1, Lcom/tw/mapmatch/dataset/_GPSInfo;->Date_yy:S

    iput-short v1, v0, Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;->Date_yy:S

    .line 1706
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_gi:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    iget-short v1, p1, Lcom/tw/mapmatch/dataset/_GPSInfo;->Date_mm:S

    iput-short v1, v0, Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;->Date_mm:S

    .line 1707
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_gi:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    iget-short v1, p1, Lcom/tw/mapmatch/dataset/_GPSInfo;->Date_dd:S

    iput-short v1, v0, Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;->Date_dd:S

    .line 1708
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_gi:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    iget-short v1, p1, Lcom/tw/mapmatch/dataset/_GPSInfo;->UTC_hh:S

    iput-short v1, v0, Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;->UTC_hh:S

    .line 1709
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_gi:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    iget-short v1, p1, Lcom/tw/mapmatch/dataset/_GPSInfo;->UTC_mm:S

    iput-short v1, v0, Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;->UTC_mm:S

    .line 1710
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_gi:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    iget-short v1, p1, Lcom/tw/mapmatch/dataset/_GPSInfo;->UTC_ss:S

    iput-short v1, v0, Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;->UTC_ss:S

    .line 1711
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_gi:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    iget-short v1, p1, Lcom/tw/mapmatch/dataset/_GPSInfo;->Course:S

    iput-short v1, v0, Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;->Course:S

    .line 1712
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_gi:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    iget-short v1, p1, Lcom/tw/mapmatch/dataset/_GPSInfo;->SpeedK:S

    iput-short v1, v0, Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;->SpeedK:S

    .line 1713
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_gi:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    iget-char v1, p1, Lcom/tw/mapmatch/dataset/_GPSInfo;->Status:C

    iput-char v1, v0, Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;->Status:C

    .line 1714
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_gi:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    iget-char v1, p1, Lcom/tw/mapmatch/dataset/_GPSInfo;->Dimension:C

    int-to-byte v1, v1

    iput-byte v1, v0, Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;->Dimension:B

    .line 1716
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_gi:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    iget-object v1, p1, Lcom/tw/mapmatch/dataset/_GPSInfo;->Date:[B

    iput-object v1, v0, Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;->Date:[B

    .line 1717
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_gi:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    iget-object v1, p1, Lcom/tw/mapmatch/dataset/_GPSInfo;->UTC:[B

    iput-object v1, v0, Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;->UTC:[B

    .line 1720
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_gi:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    iget v1, p1, Lcom/tw/mapmatch/dataset/_GPSInfo;->Lon:I

    iput v1, v0, Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;->Lon:I

    .line 1721
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_gi:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    iget v1, p1, Lcom/tw/mapmatch/dataset/_GPSInfo;->Lat:I

    iput v1, v0, Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;->Lat:I

    .line 1722
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_gi:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    iget v1, p1, Lcom/tw/mapmatch/dataset/_GPSInfo;->Height:I

    iput v1, v0, Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;->Height:I

    .line 1723
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_gi:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    iget v1, p1, Lcom/tw/mapmatch/dataset/_GPSInfo;->nGpsQlty:I

    iput v1, v0, Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;->nGpsQlty:I

    .line 1724
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_gi:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    iget-wide v2, p1, Lcom/tw/mapmatch/dataset/_GPSInfo;->HDOP:D

    iput-wide v2, v0, Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;->HDOP:D

    .line 1727
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_gi:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    iget-boolean v1, p1, Lcom/tw/mapmatch/dataset/_GPSInfo;->bIsDR:Z

    iput-boolean v1, v0, Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;->bIsDR:Z

    .line 1728
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_gi:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    iget-boolean v1, p1, Lcom/tw/mapmatch/dataset/_GPSInfo;->bIsJump:Z

    iput-boolean v1, v0, Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;->bIsJump:Z

    .line 1730
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_gi:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    iget v1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nAccuracy:I

    iput v1, v0, Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;->nAccuracy:I

    .line 1731
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_gi:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    iget v1, p1, Lcom/tw/mapmatch/dataset/_GPSInfo;->pressure:F

    iput v1, v0, Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;->pressure:F

    .line 1734
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mi:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    iget v0, v0, Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;->gpsStatus:I

    if-nez v0, :cond_0

    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsGpsOkay:Z

    if-ne v0, v4, :cond_0

    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsGPSConfiguration:Z

    if-ne v0, v4, :cond_0

    .line 1735
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_gi:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    iput v4, v0, Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;->gpsStatus:I

    .line 1740
    :goto_0
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsGPSConfiguration:Z

    if-ne v0, v4, :cond_1

    .line 1741
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_gi:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    iput v4, v0, Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;->nSerial:I

    .line 1746
    :goto_1
    return-void

    .line 1737
    :cond_0
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_gi:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    iput v5, v0, Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;->gpsStatus:I

    goto :goto_0

    .line 1743
    :cond_1
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_gi:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    iput v5, v0, Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;->nSerial:I

    goto :goto_1
.end method

.method private setMMCInfo(Lcom/tw/mapmatch/dataset/_MMCInfo;)V
    .locals 4
    .param p1, "_mmcInfo"    # Lcom/tw/mapmatch/dataset/_MMCInfo;

    .prologue
    .line 1772
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mi:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    iget-short v1, p1, Lcom/tw/mapmatch/dataset/_MMCInfo;->reversed:S

    iput-short v1, v0, Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;->reversed:S

    .line 1773
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mi:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    iget-short v1, p1, Lcom/tw/mapmatch/dataset/_MMCInfo;->mapid:S

    iput-short v1, v0, Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;->mapid:S

    .line 1774
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mi:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    iget-short v1, p1, Lcom/tw/mapmatch/dataset/_MMCInfo;->linkid:S

    iput-short v1, v0, Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;->linkid:S

    .line 1775
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mi:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    iget-short v1, p1, Lcom/tw/mapmatch/dataset/_MMCInfo;->heading:S

    iput-short v1, v0, Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;->heading:S

    .line 1776
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mi:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    iget-short v1, p1, Lcom/tw/mapmatch/dataset/_MMCInfo;->segment:S

    iput-short v1, v0, Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;->segment:S

    .line 1777
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mi:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    iget-short v1, p1, Lcom/tw/mapmatch/dataset/_MMCInfo;->speed:S

    iput-short v1, v0, Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;->speed:S

    .line 1778
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mi:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    iget-short v1, p1, Lcom/tw/mapmatch/dataset/_MMCInfo;->status:S

    iput-short v1, v0, Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;->status:S

    .line 1781
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mi:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    iget v1, p1, Lcom/tw/mapmatch/dataset/_MMCInfo;->speed_kmh:I

    iput v1, v0, Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;->speed_kmh:I

    .line 1782
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mi:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    iget v1, p1, Lcom/tw/mapmatch/dataset/_MMCInfo;->lon:I

    iput v1, v0, Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;->lon:I

    .line 1783
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mi:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    iget v1, p1, Lcom/tw/mapmatch/dataset/_MMCInfo;->lat:I

    iput v1, v0, Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;->lat:I

    .line 1784
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mi:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    iget v1, p1, Lcom/tw/mapmatch/dataset/_MMCInfo;->distance:I

    iput v1, v0, Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;->distance:I

    .line 1785
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mi:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    iget v1, p1, Lcom/tw/mapmatch/dataset/_MMCInfo;->linkratio:I

    iput v1, v0, Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;->linkratio:I

    .line 1786
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mi:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    iget v1, p1, Lcom/tw/mapmatch/dataset/_MMCInfo;->nMMCStatus:I

    iput v1, v0, Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;->nMMCStatus:I

    .line 1787
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mi:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    iget v1, p1, Lcom/tw/mapmatch/dataset/_MMCInfo;->nRoadPassWay:I

    iput v1, v0, Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;->nRoadPassWay:I

    .line 1788
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mi:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    iget v1, p1, Lcom/tw/mapmatch/dataset/_MMCInfo;->nCurRoadMMState:I

    iput v1, v0, Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;->nCurRoadMMState:I

    .line 1790
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mi:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    iget v1, p1, Lcom/tw/mapmatch/dataset/_MMCInfo;->gpsscore:I

    iput v1, v0, Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;->gpsscore:I

    .line 1791
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mi:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    iget v1, p1, Lcom/tw/mapmatch/dataset/_MMCInfo;->gpsStatus:I

    iput v1, v0, Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;->gpsStatus:I

    .line 1792
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mi:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    iget v1, p1, Lcom/tw/mapmatch/dataset/_MMCInfo;->DRMValue:I

    iput v1, v0, Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;->DRMValue:I

    .line 1796
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mi:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    iget v1, p1, Lcom/tw/mapmatch/dataset/_MMCInfo;->ir:F

    iput v1, v0, Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;->ir:F

    .line 1797
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mi:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    iget v1, p1, Lcom/tw/mapmatch/dataset/_MMCInfo;->displacement:F

    iput v1, v0, Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;->displacement:F

    .line 1800
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mi:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    iget-wide v2, p1, Lcom/tw/mapmatch/dataset/_MMCInfo;->restlat:D

    iput-wide v2, v0, Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;->restlat:D

    .line 1801
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mi:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    iget-wide v2, p1, Lcom/tw/mapmatch/dataset/_MMCInfo;->restlon:D

    iput-wide v2, v0, Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;->restlon:D

    .line 1804
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mi:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    iget-char v1, p1, Lcom/tw/mapmatch/dataset/_MMCInfo;->sDirectEscape:C

    int-to-byte v1, v1

    iput-byte v1, v0, Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;->sDirectEscape:B

    .line 1805
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mi:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    iget-char v1, p1, Lcom/tw/mapmatch/dataset/_MMCInfo;->cHotStart:C

    int-to-byte v1, v1

    iput-byte v1, v0, Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;->cHotStart:B

    .line 1806
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mi:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    iget-char v1, p1, Lcom/tw/mapmatch/dataset/_MMCInfo;->nIsInBound:C

    int-to-byte v1, v1

    iput-byte v1, v0, Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;->nIsInBound:B

    .line 1807
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mi:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    iget-char v1, p1, Lcom/tw/mapmatch/dataset/_MMCInfo;->cPSaveInZone:C

    int-to-byte v1, v1

    iput-byte v1, v0, Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;->cPSaveInZone:B

    .line 1808
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mi:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    iget-char v1, p1, Lcom/tw/mapmatch/dataset/_MMCInfo;->cLinkInfo:C

    int-to-byte v1, v1

    iput-byte v1, v0, Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;->cLinkInfo:B

    .line 1809
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mi:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    iget-char v1, p1, Lcom/tw/mapmatch/dataset/_MMCInfo;->cReserved:C

    int-to-byte v1, v1

    iput-byte v1, v0, Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;->cReserved:B

    .line 1810
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mi:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    iget-byte v1, p1, Lcom/tw/mapmatch/dataset/_MMCInfo;->cFastEscapeReady:B

    iput-byte v1, v0, Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;->cFastEscapeReady:B

    .line 1822
    return-void
.end method

.method private setOBD2nmea()V
    .locals 13

    .prologue
    .line 2171
    const/4 v7, 0x0

    .line 2176
    .local v7, "used":I
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v2

    .line 2177
    .local v2, "timeStamp":J
    new-instance v0, Ljava/text/SimpleDateFormat;

    const-string v8, "hhmmss.SS"

    invoke-direct {v0, v8}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;)V

    .line 2178
    .local v0, "dayTime":Ljava/text/SimpleDateFormat;
    new-instance v8, Ljava/util/Date;

    invoke-direct {v8, v2, v3}, Ljava/util/Date;-><init>(J)V

    invoke-virtual {v0, v8}, Ljava/text/SimpleDateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v6

    .line 2179
    .local v6, "time_str":Ljava/lang/String;
    iget-wide v8, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->nmea_timestamp:J

    sub-long v4, v2, v8

    .line 2181
    .local v4, "time_gap":J
    iget-boolean v8, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bUseOBD2:Z

    if-eqz v8, :cond_0

    iget-boolean v8, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bOBD2DataUpdated:Z

    if-eqz v8, :cond_0

    .line 2182
    const/4 v7, 0x1

    .line 2186
    :goto_0
    const-string v8, "$PTWNO,%02d%02d%02d,%d,%d,%.3f,%.3f,%d,%d,%d,%d,%d,%d,%d,%d,%d\r\n"

    const/16 v9, 0x10

    new-array v9, v9, [Ljava/lang/Object;

    const/4 v10, 0x0

    iget-object v11, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nUTC:[I

    const/4 v12, 0x0

    aget v11, v11, v12

    invoke-static {v11}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v11

    aput-object v11, v9, v10

    const/4 v10, 0x1

    iget-object v11, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nUTC:[I

    const/4 v12, 0x1

    aget v11, v11, v12

    invoke-static {v11}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v11

    aput-object v11, v9, v10

    const/4 v10, 0x2

    iget-object v11, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nUTC:[I

    const/4 v12, 0x2

    aget v11, v11, v12

    invoke-static {v11}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v11

    aput-object v11, v9, v10

    const/4 v10, 0x3

    invoke-static {v4, v5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v11

    aput-object v11, v9, v10

    const/4 v10, 0x4

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v11

    aput-object v11, v9, v10

    const/4 v10, 0x5

    iget-object v11, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_obd2Info:Lcom/tw/mapmatch/dataset/_MMOBD2Data;

    iget v11, v11, Lcom/tw/mapmatch/dataset/_MMOBD2Data;->CurrentSpeed:F

    invoke-static {v11}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v11

    aput-object v11, v9, v10

    const/4 v10, 0x6

    iget-object v11, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_obd2Info:Lcom/tw/mapmatch/dataset/_MMOBD2Data;

    iget v11, v11, Lcom/tw/mapmatch/dataset/_MMOBD2Data;->SteeringDegree:F

    invoke-static {v11}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v11

    aput-object v11, v9, v10

    const/4 v10, 0x7

    iget-object v11, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_obd2Info:Lcom/tw/mapmatch/dataset/_MMOBD2Data;

    iget-object v11, v11, Lcom/tw/mapmatch/dataset/_MMOBD2Data;->WheelPulse:[I

    const/4 v12, 0x0

    aget v11, v11, v12

    invoke-static {v11}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v11

    aput-object v11, v9, v10

    const/16 v10, 0x8

    iget-object v11, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_obd2Info:Lcom/tw/mapmatch/dataset/_MMOBD2Data;

    iget-object v11, v11, Lcom/tw/mapmatch/dataset/_MMOBD2Data;->WheelPulse:[I

    const/4 v12, 0x1

    aget v11, v11, v12

    invoke-static {v11}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v11

    aput-object v11, v9, v10

    const/16 v10, 0x9

    iget-object v11, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_obd2Info:Lcom/tw/mapmatch/dataset/_MMOBD2Data;

    iget-object v11, v11, Lcom/tw/mapmatch/dataset/_MMOBD2Data;->WheelPulse:[I

    const/4 v12, 0x2

    aget v11, v11, v12

    invoke-static {v11}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v11

    aput-object v11, v9, v10

    const/16 v10, 0xa

    iget-object v11, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_obd2Info:Lcom/tw/mapmatch/dataset/_MMOBD2Data;

    iget-object v11, v11, Lcom/tw/mapmatch/dataset/_MMOBD2Data;->WheelPulse:[I

    const/4 v12, 0x3

    aget v11, v11, v12

    invoke-static {v11}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v11

    aput-object v11, v9, v10

    const/16 v10, 0xb

    iget-object v11, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_obd2Info:Lcom/tw/mapmatch/dataset/_MMOBD2Data;

    iget-object v11, v11, Lcom/tw/mapmatch/dataset/_MMOBD2Data;->GearLevel:[I

    const/4 v12, 0x0

    aget v11, v11, v12

    invoke-static {v11}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v11

    aput-object v11, v9, v10

    const/16 v10, 0xc

    iget-object v11, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_obd2Info:Lcom/tw/mapmatch/dataset/_MMOBD2Data;

    iget-object v11, v11, Lcom/tw/mapmatch/dataset/_MMOBD2Data;->GearLevel:[I

    const/4 v12, 0x1

    aget v11, v11, v12

    invoke-static {v11}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v11

    aput-object v11, v9, v10

    const/16 v10, 0xd

    iget-object v11, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_obd2Info:Lcom/tw/mapmatch/dataset/_MMOBD2Data;

    iget-object v11, v11, Lcom/tw/mapmatch/dataset/_MMOBD2Data;->LeftRightLamp:[I

    const/4 v12, 0x0

    aget v11, v11, v12

    invoke-static {v11}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v11

    aput-object v11, v9, v10

    const/16 v10, 0xe

    iget-object v11, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_obd2Info:Lcom/tw/mapmatch/dataset/_MMOBD2Data;

    iget-object v11, v11, Lcom/tw/mapmatch/dataset/_MMOBD2Data;->LeftRightLamp:[I

    const/4 v12, 0x1

    aget v11, v11, v12

    invoke-static {v11}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v11

    aput-object v11, v9, v10

    const/16 v10, 0xf

    iget-object v11, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_obd2Info:Lcom/tw/mapmatch/dataset/_MMOBD2Data;

    iget v11, v11, Lcom/tw/mapmatch/dataset/_MMOBD2Data;->BrakeSwitch:I

    invoke-static {v11}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v11

    aput-object v11, v9, v10

    invoke-static {v8, v9}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    .line 2192
    .local v1, "nmea":Ljava/lang/String;
    invoke-virtual {v1}, Ljava/lang/String;->getBytes()[B

    move-result-object v8

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v9

    invoke-direct {p0, v2, v3, v8, v9}, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->sendNMEAMessage(J[BI)V

    .line 2193
    const/4 v8, 0x0

    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bOBD2DataUpdated:Z

    .line 2194
    return-void

    .line 2183
    .end local v1    # "nmea":Ljava/lang/String;
    :cond_0
    const/4 v7, 0x0

    goto/16 :goto_0
.end method

.method private setSATInfo(Lcom/tw/mapmatch/dataset/_SATInfo;)V
    .locals 6
    .param p1, "satInfo"    # Lcom/tw/mapmatch/dataset/_SATInfo;

    .prologue
    .line 1749
    new-instance v1, Lcom/tw/mapmatch/remote/mapmatch/SATInfo;

    invoke-direct {v1}, Lcom/tw/mapmatch/remote/mapmatch/SATInfo;-><init>()V

    .line 1751
    .local v1, "tmpSat":Lcom/tw/mapmatch/remote/mapmatch/SATInfo;
    iget-short v2, p1, Lcom/tw/mapmatch/dataset/_SATInfo;->ViewSatNo:S

    iput-short v2, v1, Lcom/tw/mapmatch/remote/mapmatch/SATInfo;->ViewSatNo:S

    .line 1752
    iget-char v2, p1, Lcom/tw/mapmatch/dataset/_SATInfo;->Dimension:C

    int-to-byte v2, v2

    iput-byte v2, v1, Lcom/tw/mapmatch/remote/mapmatch/SATInfo;->Dimension:B

    .line 1759
    const/4 v0, 0x0

    .local v0, "i":I
    :goto_0
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_si:Lcom/tw/mapmatch/remote/mapmatch/SATInfo;

    iget-short v2, v2, Lcom/tw/mapmatch/remote/mapmatch/SATInfo;->ViewSatNo:S

    if-ge v0, v2, :cond_0

    .line 1761
    iget-object v2, v1, Lcom/tw/mapmatch/remote/mapmatch/SATInfo;->EAngle:[B

    iget-object v3, p1, Lcom/tw/mapmatch/dataset/_SATInfo;->EAngle:[B

    aget-byte v3, v3, v0

    aput-byte v3, v2, v0

    .line 1762
    iget-object v2, v1, Lcom/tw/mapmatch/remote/mapmatch/SATInfo;->IsUsed:[B

    iget-object v3, p1, Lcom/tw/mapmatch/dataset/_SATInfo;->IsUsed:[B

    aget-byte v3, v3, v0

    aput-byte v3, v2, v0

    .line 1763
    iget-object v2, v1, Lcom/tw/mapmatch/remote/mapmatch/SATInfo;->BAngle:[J

    iget-object v3, p1, Lcom/tw/mapmatch/dataset/_SATInfo;->BAngle:[S

    aget-short v3, v3, v0

    int-to-long v4, v3

    aput-wide v4, v2, v0

    .line 1764
    iget-object v2, v1, Lcom/tw/mapmatch/remote/mapmatch/SATInfo;->PRN:[B

    iget-object v3, p1, Lcom/tw/mapmatch/dataset/_SATInfo;->PRN:[B

    aget-byte v3, v3, v0

    aput-byte v3, v2, v0

    .line 1759
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    .line 1767
    :cond_0
    iput-object v1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_si:Lcom/tw/mapmatch/remote/mapmatch/SATInfo;

    .line 1768
    return-void
.end method

.method private updateWithNewLocation(Landroid/location/Location;)V
    .locals 37
    .param p1, "location"    # Landroid/location/Location;

    .prologue
    .line 645
    move-object/from16 v0, p0

    iget-object v6, v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsRunning:[Z

    const/4 v7, 0x2

    aget-boolean v6, v6, v7

    const/4 v7, 0x1

    if-ne v6, v7, :cond_0

    .line 784
    :goto_0
    return-void

    .line 649
    :cond_0
    if-eqz p1, :cond_7

    move-object/from16 v0, p0

    iget-wide v6, v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->nmea_timestamp:J

    const-wide/16 v8, 0x0

    cmp-long v6, v6, v8

    if-gez v6, :cond_7

    .line 652
    const/4 v6, 0x3

    new-array v0, v6, [I

    move-object/from16 v30, v0

    fill-array-data v30, :array_0

    .line 654
    .local v30, "nDate":[I
    invoke-virtual/range {p1 .. p1}, Landroid/location/Location;->getTime()J

    move-result-wide v6

    move-object/from16 v0, p0

    iput-wide v6, v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->location_timestamp:J

    .line 657
    const-string v6, "UTC"

    invoke-static {v6}, Ljava/util/TimeZone;->getTimeZone(Ljava/lang/String;)Ljava/util/TimeZone;

    move-result-object v6

    invoke-static {v6}, Ljava/util/TimeZone;->setDefault(Ljava/util/TimeZone;)V

    .line 659
    new-instance v32, Ljava/text/SimpleDateFormat;

    const-string v6, "dd:MM:yy:HH:mm:ss"

    move-object/from16 v0, v32

    invoke-direct {v0, v6}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;)V

    .line 660
    .local v32, "sdf":Ljava/text/SimpleDateFormat;
    new-instance v6, Ljava/util/Date;

    move-object/from16 v0, p0

    iget-wide v8, v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->location_timestamp:J

    invoke-direct {v6, v8, v9}, Ljava/util/Date;-><init>(J)V

    move-object/from16 v0, v32

    invoke-virtual {v0, v6}, Ljava/text/SimpleDateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v31

    .line 662
    .local v31, "prt":Ljava/lang/String;
    new-instance v36, Ljava/util/StringTokenizer;

    const-string v6, ":"

    move-object/from16 v0, v36

    move-object/from16 v1, v31

    invoke-direct {v0, v1, v6}, Ljava/util/StringTokenizer;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 664
    .local v36, "tok":Ljava/util/StringTokenizer;
    const/16 v21, 0x0

    .line 666
    .local v21, "i":I
    :goto_1
    invoke-virtual/range {v36 .. v36}, Ljava/util/StringTokenizer;->hasMoreElements()Z

    move-result v6

    if-eqz v6, :cond_2

    .line 668
    const/4 v6, 0x3

    move/from16 v0, v21

    if-ge v0, v6, :cond_1

    .line 669
    invoke-virtual/range {v36 .. v36}, Ljava/util/StringTokenizer;->nextToken()Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v6

    aput v6, v30, v21

    .line 673
    :goto_2
    add-int/lit8 v21, v21, 0x1

    goto :goto_1

    .line 671
    :cond_1
    move-object/from16 v0, p0

    iget-object v6, v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nUTC:[I

    add-int/lit8 v7, v21, -0x3

    invoke-virtual/range {v36 .. v36}, Ljava/util/StringTokenizer;->nextToken()Ljava/lang/String;

    move-result-object v8

    invoke-static {v8}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v8

    aput v8, v6, v7

    goto :goto_2

    .line 676
    :cond_2
    move-object/from16 v0, p0

    iget-object v6, v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nUTC:[I

    const/4 v7, 0x0

    aget v6, v6, v7

    move-object/from16 v0, p0

    iget-object v7, v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nUTC_old:[I

    const/4 v8, 0x0

    aget v7, v7, v8

    if-ne v6, v7, :cond_3

    move-object/from16 v0, p0

    iget-object v6, v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nUTC:[I

    const/4 v7, 0x1

    aget v6, v6, v7

    move-object/from16 v0, p0

    iget-object v7, v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nUTC_old:[I

    const/4 v8, 0x1

    aget v7, v7, v8

    if-ne v6, v7, :cond_3

    move-object/from16 v0, p0

    iget-object v6, v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nUTC:[I

    const/4 v7, 0x2

    aget v6, v6, v7

    move-object/from16 v0, p0

    iget-object v7, v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nUTC_old:[I

    const/4 v8, 0x2

    aget v7, v7, v8

    if-eq v6, v7, :cond_4

    .line 678
    :cond_3
    move-object/from16 v0, p0

    iget-object v6, v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nUTC_old:[I

    const/4 v7, 0x0

    move-object/from16 v0, p0

    iget-object v8, v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nUTC:[I

    const/4 v9, 0x0

    aget v8, v8, v9

    aput v8, v6, v7

    .line 679
    move-object/from16 v0, p0

    iget-object v6, v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nUTC_old:[I

    const/4 v7, 0x1

    move-object/from16 v0, p0

    iget-object v8, v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nUTC:[I

    const/4 v9, 0x1

    aget v8, v8, v9

    aput v8, v6, v7

    .line 680
    move-object/from16 v0, p0

    iget-object v6, v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nUTC_old:[I

    const/4 v7, 0x2

    move-object/from16 v0, p0

    iget-object v8, v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nUTC:[I

    const/4 v9, 0x2

    aget v8, v8, v9

    aput v8, v6, v7

    .line 683
    :cond_4
    invoke-virtual/range {p1 .. p1}, Landroid/location/Location;->getLatitude()D

    move-result-wide v26

    .line 684
    .local v26, "lat":D
    invoke-virtual/range {p1 .. p1}, Landroid/location/Location;->getLongitude()D

    move-result-wide v28

    .line 687
    .local v28, "lon":D
    invoke-static/range {v26 .. v27}, Ljava/lang/Math;->floor(D)D

    move-result-wide v6

    double-to-int v14, v6

    .line 688
    .local v14, "LatDD":I
    invoke-static/range {v28 .. v29}, Ljava/lang/Math;->floor(D)D

    move-result-wide v6

    double-to-int v15, v6

    .line 689
    .local v15, "LonDD":I
    const-string v34, ""

    .local v34, "strTmpLat":Ljava/lang/String;
    const-string v35, ""

    .line 691
    .local v35, "strTmpLon":Ljava/lang/String;
    int-to-double v6, v14

    sub-double v16, v26, v6

    .line 692
    .local v16, "LatMM":D
    int-to-double v6, v15

    sub-double v18, v28, v6

    .line 694
    .local v18, "LonMM":D
    const-wide/high16 v6, 0x404e000000000000L    # 60.0

    mul-double v16, v16, v6

    .line 695
    const-wide/high16 v6, 0x404e000000000000L    # 60.0

    mul-double v18, v18, v6

    .line 698
    const-wide/high16 v6, 0x4024000000000000L    # 10.0

    cmpg-double v6, v16, v6

    if-gez v6, :cond_5

    .line 699
    const-string v6, "0%.5f"

    const/4 v7, 0x1

    new-array v7, v7, [Ljava/lang/Object;

    const/4 v8, 0x0

    invoke-static/range {v16 .. v17}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v9

    aput-object v9, v7, v8

    invoke-static {v6, v7}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v34

    .line 704
    :goto_3
    const-wide/high16 v6, 0x4024000000000000L    # 10.0

    cmpg-double v6, v18, v6

    if-gez v6, :cond_6

    .line 705
    const-string v6, "0%.5f"

    const/4 v7, 0x1

    new-array v7, v7, [Ljava/lang/Object;

    const/4 v8, 0x0

    invoke-static/range {v18 .. v19}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v9

    aput-object v9, v7, v8

    invoke-static {v6, v7}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v35

    .line 710
    :goto_4
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "%d"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    move-object/from16 v0, v34

    invoke-virtual {v6, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    const/4 v7, 0x1

    new-array v7, v7, [Ljava/lang/Object;

    const/4 v8, 0x0

    invoke-static {v14}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    aput-object v9, v7, v8

    invoke-static {v6, v7}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/String;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    move-result-wide v16

    .line 711
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "%d"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    move-object/from16 v0, v35

    invoke-virtual {v6, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    const/4 v7, 0x1

    new-array v7, v7, [Ljava/lang/Object;

    const/4 v8, 0x0

    invoke-static {v15}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    aput-object v9, v7, v8

    invoke-static {v6, v7}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/String;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    move-result-wide v18

    .line 714
    const-wide/16 v24, 0x0

    .line 715
    .local v24, "bessel_lon":D
    const-wide/16 v22, 0x0

    .line 716
    .local v22, "bessel_lat":D
    const/16 v20, 0x0

    .line 718
    .local v20, "bessel_altitude":I
    invoke-static/range {v16 .. v17}, Lcom/tw/mapmatch/HelperFunctions;->TWSEC(D)D

    move-result-wide v22

    .line 719
    invoke-static/range {v18 .. v19}, Lcom/tw/mapmatch/HelperFunctions;->TWSEC(D)D

    move-result-wide v24

    .line 721
    invoke-virtual/range {p1 .. p1}, Landroid/location/Location;->getAltitude()D

    move-result-wide v6

    double-to-int v0, v6

    move/from16 v20, v0

    .line 724
    mul-int/lit8 v20, v20, 0xa

    .line 726
    move-wide/from16 v0, v24

    move-wide/from16 v2, v22

    move/from16 v4, v20

    invoke-static {v0, v1, v2, v3, v4}, Lcom/tw/mapmatch/HelperFunctions;->Moledensky(DDI)V

    .line 728
    sget-wide v24, Lcom/tw/mapmatch/HelperFunctions;->bessel_lon:D

    .line 729
    sget-wide v22, Lcom/tw/mapmatch/HelperFunctions;->bessel_lat:D

    .line 730
    sget v20, Lcom/tw/mapmatch/HelperFunctions;->bessel_altitude:I

    .line 732
    const-wide/high16 v6, 0x4024000000000000L    # 10.0

    div-double v6, v22, v6

    double-to-int v6, v6

    move-object/from16 v0, p0

    iput v6, v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nLatitude:I

    .line 733
    const-wide/high16 v6, 0x4024000000000000L    # 10.0

    div-double v6, v24, v6

    double-to-int v6, v6

    move-object/from16 v0, p0

    iput v6, v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nLongitude:I

    .line 734
    move/from16 v0, v20

    move-object/from16 v1, p0

    iput v0, v1, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nAltitude:I

    .line 735
    invoke-virtual/range {p1 .. p1}, Landroid/location/Location;->getBearing()F

    move-result v6

    float-to-int v6, v6

    int-to-short v6, v6

    move-object/from16 v0, p0

    iput-short v6, v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_sCourse:S

    .line 739
    invoke-virtual/range {p1 .. p1}, Landroid/location/Location;->getSpeed()F

    move-result v6

    const v7, 0x40666666    # 3.6f

    mul-float v33, v6, v7

    .line 740
    .local v33, "speed":F
    const/high16 v6, 0x41200000    # 10.0f

    mul-float v6, v6, v33

    float-to-int v6, v6

    int-to-short v6, v6

    move-object/from16 v0, p0

    iput-short v6, v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_sSpeed:S

    .line 743
    const/4 v6, 0x6

    new-array v13, v6, [B

    fill-array-data v13, :array_1

    .line 744
    .local v13, "bUTC":[B
    const/4 v6, 0x0

    move-object/from16 v0, p0

    iget-object v7, v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nUTC:[I

    const/4 v8, 0x0

    aget v7, v7, v8

    int-to-byte v7, v7

    aput-byte v7, v13, v6

    .line 745
    const/4 v6, 0x1

    move-object/from16 v0, p0

    iget-object v7, v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nUTC:[I

    const/4 v8, 0x1

    aget v7, v7, v8

    int-to-byte v7, v7

    aput-byte v7, v13, v6

    .line 746
    const/4 v6, 0x2

    move-object/from16 v0, p0

    iget-object v7, v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nUTC:[I

    const/4 v8, 0x2

    aget v7, v7, v8

    int-to-byte v7, v7

    aput-byte v7, v13, v6

    .line 747
    const/4 v6, 0x3

    const/4 v7, 0x0

    aget v7, v30, v7

    int-to-byte v7, v7

    aput-byte v7, v13, v6

    .line 748
    const/4 v6, 0x4

    const/4 v7, 0x1

    aget v7, v30, v7

    int-to-byte v7, v7

    aput-byte v7, v13, v6

    .line 749
    const/4 v6, 0x5

    const/4 v7, 0x2

    aget v7, v30, v7

    int-to-byte v7, v7

    aput-byte v7, v13, v6

    .line 752
    invoke-virtual/range {p1 .. p1}, Landroid/location/Location;->getAccuracy()F

    move-result v6

    const/high16 v7, 0x41200000    # 10.0f

    mul-float/2addr v6, v7

    float-to-int v6, v6

    move-object/from16 v0, p0

    iput v6, v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nAccuracy:I

    .line 754
    move-object/from16 v0, p0

    iget-object v6, v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    move-object/from16 v0, p0

    iget v7, v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nLatitude:I

    move-object/from16 v0, p0

    iget v8, v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nLongitude:I

    move-object/from16 v0, p0

    iget v9, v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nAltitude:I

    move-object/from16 v0, p0

    iget v10, v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nAccuracy:I

    move-object/from16 v0, p0

    iget-short v11, v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_sCourse:S

    move-object/from16 v0, p0

    iget-short v12, v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_sSpeed:S

    invoke-virtual/range {v6 .. v13}, Lcom/tw/mapmatch/jni/Natives;->nativeSetLocationData(IIIISS[B)I

    .line 756
    sget-object v7, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->mm_mutex:Ljava/lang/Object;

    monitor-enter v7

    .line 762
    const/4 v6, 0x2

    :try_start_0
    move-object/from16 v0, p0

    iput v6, v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nCurrentMode:I

    .line 763
    move-object/from16 v0, p0

    iget-object v6, v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    const/4 v8, 0x0

    move-object/from16 v0, p0

    iget v9, v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nCurrentMode:I

    invoke-virtual {v6, v8, v9}, Lcom/tw/mapmatch/jni/Natives;->nativeMapMatch(ZI)I

    .line 766
    move-object/from16 v0, p0

    iget-object v6, v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    invoke-virtual {v6}, Lcom/tw/mapmatch/jni/Natives;->nativeGetMMCInfo()Lcom/tw/mapmatch/dataset/_MMCInfo;

    move-result-object v6

    move-object/from16 v0, p0

    iput-object v6, v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_mmcInfo:Lcom/tw/mapmatch/dataset/_MMCInfo;

    .line 769
    monitor-exit v7
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 771
    move-object/from16 v0, p0

    iget-object v6, v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_mmcInfo:Lcom/tw/mapmatch/dataset/_MMCInfo;

    move-object/from16 v0, p0

    invoke-direct {v0, v6}, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->setMMCInfo(Lcom/tw/mapmatch/dataset/_MMCInfo;)V

    .line 774
    move-object/from16 v0, p0

    iget-object v6, v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->gravityModule:Lcom/thinkware/sundo/inavi3dservice/GravityModule;

    invoke-virtual {v6}, Lcom/thinkware/sundo/inavi3dservice/GravityModule;->getGPSInfo()Lcom/tw/mapmatch/dataset/_GPSInfo;

    move-result-object v6

    move-object/from16 v0, p0

    iput-object v6, v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_gpsInfo:Lcom/tw/mapmatch/dataset/_GPSInfo;

    .line 776
    move-object/from16 v0, p0

    iget-object v6, v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_gpsInfo:Lcom/tw/mapmatch/dataset/_GPSInfo;

    move-object/from16 v0, p0

    invoke-direct {v0, v6}, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->setGPSInfo(Lcom/tw/mapmatch/dataset/_GPSInfo;)V

    .line 777
    const-string v6, "Asia/Seoul"

    invoke-static {v6}, Ljava/util/TimeZone;->getTimeZone(Ljava/lang/String;)Ljava/util/TimeZone;

    move-result-object v6

    invoke-static {v6}, Ljava/util/TimeZone;->setDefault(Ljava/util/TimeZone;)V

    goto/16 :goto_0

    .line 701
    .end local v13    # "bUTC":[B
    .end local v20    # "bessel_altitude":I
    .end local v22    # "bessel_lat":D
    .end local v24    # "bessel_lon":D
    .end local v33    # "speed":F
    :cond_5
    const-string v6, "%.5f"

    const/4 v7, 0x1

    new-array v7, v7, [Ljava/lang/Object;

    const/4 v8, 0x0

    invoke-static/range {v16 .. v17}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v9

    aput-object v9, v7, v8

    invoke-static {v6, v7}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v34

    goto/16 :goto_3

    .line 707
    :cond_6
    const-string v6, "%.5f"

    const/4 v7, 0x1

    new-array v7, v7, [Ljava/lang/Object;

    const/4 v8, 0x0

    invoke-static/range {v18 .. v19}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v9

    aput-object v9, v7, v8

    invoke-static {v6, v7}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v35

    goto/16 :goto_4

    .line 769
    .restart local v13    # "bUTC":[B
    .restart local v20    # "bessel_altitude":I
    .restart local v22    # "bessel_lat":D
    .restart local v24    # "bessel_lon":D
    .restart local v33    # "speed":F
    :catchall_0
    move-exception v6

    :try_start_1
    monitor-exit v7
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw v6

    .line 781
    .end local v13    # "bUTC":[B
    .end local v14    # "LatDD":I
    .end local v15    # "LonDD":I
    .end local v16    # "LatMM":D
    .end local v18    # "LonMM":D
    .end local v20    # "bessel_altitude":I
    .end local v21    # "i":I
    .end local v22    # "bessel_lat":D
    .end local v24    # "bessel_lon":D
    .end local v26    # "lat":D
    .end local v28    # "lon":D
    .end local v30    # "nDate":[I
    .end local v31    # "prt":Ljava/lang/String;
    .end local v32    # "sdf":Ljava/text/SimpleDateFormat;
    .end local v33    # "speed":F
    .end local v34    # "strTmpLat":Ljava/lang/String;
    .end local v35    # "strTmpLon":Ljava/lang/String;
    .end local v36    # "tok":Ljava/util/StringTokenizer;
    :cond_7
    invoke-virtual/range {p1 .. p1}, Landroid/location/Location;->getAccuracy()F

    move-result v6

    const/high16 v7, 0x41200000    # 10.0f

    mul-float/2addr v6, v7

    float-to-int v6, v6

    move-object/from16 v0, p0

    iput v6, v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nAccuracy:I

    goto/16 :goto_0

    .line 652
    nop

    :array_0
    .array-data 4
        0x0
        0x0
        0x0
    .end array-data

    .line 743
    :array_1
    .array-data 1
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
    .end array-data
.end method


# virtual methods
.method public ChangeLink()V
    .locals 4

    .prologue
    .line 1051
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->mmcHandler:Landroid/os/Handler;

    const/16 v3, 0x3e9

    invoke-virtual {v2, v3}, Landroid/os/Handler;->obtainMessage(I)Landroid/os/Message;

    move-result-object v1

    .line 1052
    .local v1, "msg":Landroid/os/Message;
    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    .line 1053
    .local v0, "data":Landroid/os/Bundle;
    const-string v2, "MsgType"

    sget-object v3, Lcom/thinkware/sundo/inavi3dservice/MMCModule$MSGTYPE;->CHANGELINK:Lcom/thinkware/sundo/inavi3dservice/MMCModule$MSGTYPE;

    invoke-virtual {v3}, Lcom/thinkware/sundo/inavi3dservice/MMCModule$MSGTYPE;->value()S

    move-result v3

    invoke-virtual {v0, v2, v3}, Landroid/os/Bundle;->putShort(Ljava/lang/String;S)V

    .line 1055
    invoke-virtual {v1, v0}, Landroid/os/Message;->setData(Landroid/os/Bundle;)V

    .line 1056
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->mmcHandler:Landroid/os/Handler;

    invoke-virtual {v2, v1}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    .line 1057
    return-void
.end method

.method public ClearRouteTbl()V
    .locals 1

    .prologue
    .line 1100
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    invoke-virtual {v0}, Lcom/tw/mapmatch/jni/Natives;->nativeClearRouteTbl()V

    .line 1101
    return-void
.end method

.method public GetGPSInfo()Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;
    .locals 3

    .prologue
    const/4 v2, 0x1

    .line 984
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsGPSConfiguration:Z

    if-ne v0, v2, :cond_0

    .line 985
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_gi:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    .line 996
    :goto_0
    return-object v0

    .line 986
    :cond_0
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsRunning:[Z

    const/4 v1, 0x2

    aget-boolean v0, v0, v1

    if-ne v0, v2, :cond_1

    .line 987
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_gi:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    goto :goto_0

    .line 990
    :cond_1
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_gi_dummy:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    const/4 v1, 0x0

    iput v1, v0, Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;->nSerial:I

    .line 996
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_gi_dummy:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    goto :goto_0
.end method

.method public GetMMCInfo()Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;
    .locals 3

    .prologue
    const/4 v2, 0x1

    .line 1016
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsGPSConfiguration:Z

    if-eq v0, v2, :cond_0

    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsRunning:[Z

    const/4 v1, 0x2

    aget-boolean v0, v0, v1

    if-ne v0, v2, :cond_1

    .line 1023
    :cond_0
    :goto_0
    const-string v0, "MMC"

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "UTC: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_gpsInfo:Lcom/tw/mapmatch/dataset/_GPSInfo;

    iget-short v2, v2, Lcom/tw/mapmatch/dataset/_GPSInfo;->UTC_hh:S

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ":"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_gpsInfo:Lcom/tw/mapmatch/dataset/_GPSInfo;

    iget-short v2, v2, Lcom/tw/mapmatch/dataset/_GPSInfo;->UTC_mm:S

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ":"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_gpsInfo:Lcom/tw/mapmatch/dataset/_GPSInfo;

    iget-short v2, v2, Lcom/tw/mapmatch/dataset/_GPSInfo;->UTC_ss:S

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ", SPEED_mps:"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-short v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->speed_mps:S

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ", SPEED:"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    sget v2, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->speed:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ", MMC_SPEED:"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mi:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    iget v2, v2, Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;->speed_kmh:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ", GPS_SPEED:"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_gpsInfo:Lcom/tw/mapmatch/dataset/_GPSInfo;

    iget-short v2, v2, Lcom/tw/mapmatch/dataset/_GPSInfo;->SpeedK:S

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ",  speed :"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    sget v2, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->speed:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ", lat:"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mi:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    iget v2, v2, Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;->lat:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ", lon:"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mi:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    iget v2, v2, Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;->lon:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ", status:"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mi:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    iget-short v2, v2, Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;->status:S

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {p0, v0, v1}, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->Log(Ljava/lang/String;Ljava/lang/String;)V

    .line 1025
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mi:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    return-object v0

    .line 1019
    :cond_1
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mi:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    const/4 v1, 0x0

    iput v1, v0, Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;->gpsscore:I

    .line 1020
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mi:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    const/4 v1, -0x2

    iput v1, v0, Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;->gpsStatus:I

    goto/16 :goto_0
.end method

.method public GetSATInfo()Lcom/tw/mapmatch/remote/mapmatch/SATInfo;
    .locals 3

    .prologue
    const/4 v2, 0x1

    .line 1030
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsGPSConfiguration:Z

    if-ne v0, v2, :cond_0

    .line 1031
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_si:Lcom/tw/mapmatch/remote/mapmatch/SATInfo;

    .line 1036
    :goto_0
    return-object v0

    .line 1032
    :cond_0
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsRunning:[Z

    const/4 v1, 0x2

    aget-boolean v0, v0, v1

    if-ne v0, v2, :cond_1

    .line 1033
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_si:Lcom/tw/mapmatch/remote/mapmatch/SATInfo;

    goto :goto_0

    .line 1036
    :cond_1
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_si_dummy:Lcom/tw/mapmatch/remote/mapmatch/SATInfo;

    goto :goto_0
.end method

.method public GetStringNmea()Ljava/lang/String;
    .locals 1

    .prologue
    .line 1045
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->nmea0183Data_2:Ljava/lang/String;

    return-object v0
.end method

.method public InitGPS()V
    .locals 4

    .prologue
    .line 1059
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->mmcHandler:Landroid/os/Handler;

    const/16 v3, 0x3e9

    invoke-virtual {v2, v3}, Landroid/os/Handler;->obtainMessage(I)Landroid/os/Message;

    move-result-object v1

    .line 1060
    .local v1, "msg":Landroid/os/Message;
    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    .line 1063
    .local v0, "data":Landroid/os/Bundle;
    const-string v2, "MsgType"

    sget-object v3, Lcom/thinkware/sundo/inavi3dservice/MMCModule$MSGTYPE;->FACTORYRESET:Lcom/thinkware/sundo/inavi3dservice/MMCModule$MSGTYPE;

    invoke-virtual {v3}, Lcom/thinkware/sundo/inavi3dservice/MMCModule$MSGTYPE;->value()S

    move-result v3

    invoke-virtual {v0, v2, v3}, Landroid/os/Bundle;->putShort(Ljava/lang/String;S)V

    .line 1071
    const-string v2, "GpsType"

    sget-object v3, Lcom/thinkware/sundo/inavi3dservice/MMCModule$GPSTYPE;->ANDROID_DEFAULT:Lcom/thinkware/sundo/inavi3dservice/MMCModule$GPSTYPE;

    invoke-virtual {v3}, Lcom/thinkware/sundo/inavi3dservice/MMCModule$GPSTYPE;->value()S

    move-result v3

    invoke-virtual {v0, v2, v3}, Landroid/os/Bundle;->putShort(Ljava/lang/String;S)V

    .line 1094
    invoke-virtual {v1, v0}, Landroid/os/Message;->setData(Landroid/os/Bundle;)V

    .line 1095
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->mmcHandler:Landroid/os/Handler;

    invoke-virtual {v2, v1}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    .line 1096
    return-void
.end method

.method public SetLastDpCoordinate(III)V
    .locals 1
    .param p1, "nX"    # I
    .param p2, "nY"    # I
    .param p3, "nCarAngle"    # I

    .prologue
    .line 1130
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    invoke-virtual {v0, p1, p2, p3}, Lcom/tw/mapmatch/jni/Natives;->nativeSetLastDpCoordinate(III)V

    .line 1131
    return-void
.end method

.method public SetSpeedMode(I)V
    .locals 0
    .param p1, "nSpeedMode"    # I

    .prologue
    .line 1686
    iput p1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nSpeedMode:I

    .line 1687
    return-void
.end method

.method public SetUsingGPSSocket(Z)V
    .locals 4
    .param p1, "bUsing"    # Z

    .prologue
    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v1, 0x0

    .line 1280
    if-eqz p1, :cond_0

    .line 1281
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsRunning:[Z

    aput-boolean v2, v0, v3

    .line 1282
    iput-boolean v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bUsingGPSSocket:Z

    .line 1283
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_gpsThread:Ljava/lang/Thread;

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    .line 1289
    :goto_0
    return-void

    .line 1286
    :cond_0
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsRunning:[Z

    aput-boolean v1, v0, v3

    .line 1287
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bUsingGPSSocket:Z

    goto :goto_0
.end method

.method public StartMapMatch()V
    .locals 6

    .prologue
    const/4 v5, 0x0

    const/4 v4, 0x1

    .line 451
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_ctxtParent:Landroid/content/Context;

    invoke-virtual {v1}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v1

    const-string v2, "gps"

    invoke-direct {p0, v1, v2}, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->isLocationProviderEnabled(Landroid/content/ContentResolver;Ljava/lang/String;)Z

    move-result v1

    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsGPSConfiguration:Z

    .line 453
    invoke-direct {p0}, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->createLocationManager()V

    .line 455
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->doAssistGPS()V

    .line 459
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    sget-object v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->kStorageRoot:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "/mapdata/"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/tw/mapmatch/jni/Natives;->nativeInitMap(Ljava/lang/String;)I

    .line 462
    invoke-direct {p0}, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->getGpsMode()Ljava/lang/String;

    move-result-object v0

    .line 464
    .local v0, "gpsMode":Ljava/lang/String;
    const-string v1, "1"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_0

    .line 465
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    invoke-virtual {v1, v4}, Lcom/tw/mapmatch/jni/Natives;->nativeSetUseDRSolution(Z)V

    .line 466
    iput-boolean v4, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bUsingDRSolution:Z

    .line 472
    :goto_0
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    invoke-virtual {v1, v4}, Lcom/tw/mapmatch/jni/Natives;->nativeSetUseCNModule(Z)V

    .line 474
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    const/4 v2, 0x2

    invoke-virtual {v1, v2}, Lcom/tw/mapmatch/jni/Natives;->nativeSetUseVDrive(I)V

    .line 477
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsRunning:[Z

    aput-boolean v4, v1, v5

    .line 478
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsRunning:[Z

    aput-boolean v4, v1, v4

    .line 481
    new-instance v1, Ljava/lang/Thread;

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->MMCThreadProc:Ljava/lang/Runnable;

    const-string v3, "MMCThreadProc"

    invoke-direct {v1, v2, v3}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    iput-object v1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmcThread:Ljava/lang/Thread;

    .line 482
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmcThread:Ljava/lang/Thread;

    invoke-virtual {v1}, Ljava/lang/Thread;->start()V

    .line 485
    return-void

    .line 468
    :cond_0
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    invoke-virtual {v1, v5}, Lcom/tw/mapmatch/jni/Natives;->nativeSetUseDRSolution(Z)V

    .line 469
    iput-boolean v5, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bUsingDRSolution:Z

    goto :goto_0
.end method

.method public StopMapMatch()V
    .locals 9

    .prologue
    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v5, 0x0

    .line 547
    const-string v2, "MMC"

    const-string v3, "StopMapMatch"

    invoke-direct {p0, v2, v3}, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->Log(Ljava/lang/String;Ljava/lang/String;)V

    .line 548
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->gravityModule:Lcom/thinkware/sundo/inavi3dservice/GravityModule;

    if-eqz v2, :cond_0

    .line 550
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->gravityModule:Lcom/thinkware/sundo/inavi3dservice/GravityModule;

    invoke-virtual {v2}, Lcom/thinkware/sundo/inavi3dservice/GravityModule;->endGravity()V

    .line 552
    :cond_0
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_locManager:Landroid/location/LocationManager;

    if-eqz v2, :cond_3

    .line 554
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v2

    invoke-virtual {v2}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->IsThinkwareDevice()Z

    move-result v2

    if-ne v2, v7, :cond_1

    .line 555
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_locManager:Landroid/location/LocationManager;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_provider:Ljava/lang/String;

    iget-object v4, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->cmd02:Ljava/lang/String;

    invoke-virtual {v2, v3, v4, v5}, Landroid/location/LocationManager;->sendExtraCommand(Ljava/lang/String;Ljava/lang/String;Landroid/os/Bundle;)Z

    .line 557
    :cond_1
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_locManager:Landroid/location/LocationManager;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->locationListener:Landroid/location/LocationListener;

    invoke-virtual {v2, v3}, Landroid/location/LocationManager;->removeUpdates(Landroid/location/LocationListener;)V

    .line 558
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x18

    if-lt v0, v1, :cond_2

    .line 558
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_locManager:Landroid/location/LocationManager;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->nmeaMsgListener:Landroid/location/OnNmeaMessageListener;

    invoke-virtual {v2, v3}, Landroid/location/LocationManager;->removeNmeaListener(Landroid/location/OnNmeaMessageListener;)V

    goto :goto_0

    :cond_2
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_locManager:Landroid/location/LocationManager;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->nmeaListener:Landroid/location/GpsStatus$NmeaListener;

    invoke-virtual {v2, v3}, Landroid/location/LocationManager;->removeNmeaListener(Landroid/location/GpsStatus$NmeaListener;)V

    .line 561
    :goto_0
    iput-object v5, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_locManager:Landroid/location/LocationManager;

    .line 564
    :cond_3
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsRunning:[Z

    aget-boolean v2, v2, v8

    if-ne v2, v7, :cond_4

    .line 565
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsRunning:[Z

    aput-boolean v6, v2, v8

    .line 568
    const-wide/16 v2, 0x96

    :try_start_0
    invoke-static {v2, v3}, Ljava/lang/Thread;->sleep(J)V

    .line 569
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_LogThread:Ljava/lang/Thread;

    invoke-virtual {v2}, Ljava/lang/Thread;->interrupt()V

    .line 570
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_LogThread:Ljava/lang/Thread;

    invoke-virtual {v2}, Ljava/lang/Thread;->join()V
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0

    .line 575
    :goto_1
    iput-object v5, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_LogThread:Ljava/lang/Thread;

    .line 579
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->gravityModule:Lcom/thinkware/sundo/inavi3dservice/GravityModule;

    const-string v3, "GPS ONLY"

    const-string v4, "dummy"

    invoke-virtual {v2, v3, v4}, Lcom/thinkware/sundo/inavi3dservice/GravityModule;->initializeGravity(Ljava/lang/String;Ljava/lang/String;)I

    .line 583
    :cond_4
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsRunning:[Z

    aput-boolean v6, v2, v6

    .line 584
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsRunning:[Z

    aput-boolean v6, v2, v7

    .line 586
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmcThread:Ljava/lang/Thread;

    if-eqz v2, :cond_5

    .line 588
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsRunning:[Z

    aput-boolean v6, v2, v6

    .line 590
    const-wide/16 v2, 0x96

    :try_start_1
    invoke-static {v2, v3}, Ljava/lang/Thread;->sleep(J)V

    .line 591
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmcThread:Ljava/lang/Thread;

    invoke-virtual {v2}, Ljava/lang/Thread;->interrupt()V

    .line 592
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmcThread:Ljava/lang/Thread;

    invoke-virtual {v2}, Ljava/lang/Thread;->join()V
    :try_end_1
    .catch Ljava/lang/InterruptedException; {:try_start_1 .. :try_end_1} :catch_1

    .line 598
    :goto_2
    iput-object v5, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmcThread:Ljava/lang/Thread;

    .line 601
    :cond_5
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsRunning:[Z

    const/4 v3, 0x3

    aput-boolean v6, v2, v3

    .line 602
    iput-boolean v6, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bUsingGPSSocket:Z

    .line 603
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_gpsThread:Ljava/lang/Thread;

    if-eqz v2, :cond_6

    .line 605
    const-wide/16 v2, 0x96

    :try_start_2
    invoke-static {v2, v3}, Ljava/lang/Thread;->sleep(J)V

    .line 606
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_gpsThread:Ljava/lang/Thread;

    invoke-virtual {v2}, Ljava/lang/Thread;->interrupt()V

    .line 607
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_gpsThread:Ljava/lang/Thread;

    invoke-virtual {v2}, Ljava/lang/Thread;->join()V
    :try_end_2
    .catch Ljava/lang/InterruptedException; {:try_start_2 .. :try_end_2} :catch_2

    .line 612
    :goto_3
    iput-object v5, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_gpsThread:Ljava/lang/Thread;

    .line 617
    :cond_6
    :try_start_3
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->reader:Ljava/io/BufferedReader;

    if-eqz v2, :cond_7

    .line 618
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->reader:Ljava/io/BufferedReader;

    invoke-virtual {v2}, Ljava/io/BufferedReader;->close()V

    .line 619
    :cond_7
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->fin:Ljava/io/FileInputStream;

    if-eqz v2, :cond_8

    .line 620
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->fin:Ljava/io/FileInputStream;

    invoke-virtual {v2}, Ljava/io/FileInputStream;->close()V

    .line 622
    :cond_8
    const/4 v2, 0x0

    iput-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->reader:Ljava/io/BufferedReader;

    .line 623
    const/4 v2, 0x0

    iput-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->fin:Ljava/io/FileInputStream;
    :try_end_3
    .catch Ljava/io/IOException; {:try_start_3 .. :try_end_3} :catch_3

    .line 634
    :goto_4
    return-void

    .line 572
    :catch_0
    move-exception v1

    .line 573
    .local v1, "ie":Ljava/lang/InterruptedException;
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_ctxtParent:Landroid/content/Context;

    const-string v3, "InterruptedException m_LogThread"

    invoke-static {v2, v3, v7}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v2

    invoke-virtual {v2}, Landroid/widget/Toast;->show()V

    goto :goto_1

    .line 593
    .end local v1    # "ie":Ljava/lang/InterruptedException;
    :catch_1
    move-exception v1

    .line 594
    .restart local v1    # "ie":Ljava/lang/InterruptedException;
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_ctxtParent:Landroid/content/Context;

    const-string v3, "InterruptedException m_mmcThread"

    const/16 v4, 0x7d0

    invoke-static {v2, v3, v4}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v2

    invoke-virtual {v2}, Landroid/widget/Toast;->show()V

    goto :goto_2

    .line 609
    .end local v1    # "ie":Ljava/lang/InterruptedException;
    :catch_2
    move-exception v1

    .line 610
    .restart local v1    # "ie":Ljava/lang/InterruptedException;
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_ctxtParent:Landroid/content/Context;

    const-string v3, "InterruptedException m_mmcThread"

    const/16 v4, 0x7d0

    invoke-static {v2, v3, v4}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v2

    invoke-virtual {v2}, Landroid/widget/Toast;->show()V

    goto :goto_3

    .line 626
    .end local v1    # "ie":Ljava/lang/InterruptedException;
    :catch_3
    move-exception v0

    .line 628
    .local v0, "ex":Ljava/io/IOException;
    iput-object v5, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->reader:Ljava/io/BufferedReader;

    .line 629
    iput-object v5, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->fin:Ljava/io/FileInputStream;

    goto :goto_4
.end method

.method protected doAssistGPS()V
    .locals 4

    .prologue
    .line 493
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_locManager:Landroid/location/LocationManager;

    if-nez v1, :cond_0

    .line 519
    :goto_0
    return-void

    .line 495
    :cond_0
    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    .line 502
    .local v0, "extra":Landroid/os/Bundle;
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_locManager:Landroid/location/LocationManager;

    const-string v2, "gps"

    const-string v3, "force_xtra_injection"

    invoke-virtual {v1, v2, v3, v0}, Landroid/location/LocationManager;->sendExtraCommand(Ljava/lang/String;Ljava/lang/String;Landroid/os/Bundle;)Z

    .line 510
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_locManager:Landroid/location/LocationManager;

    const-string v2, "gps"

    const-string v3, "force_time_injection"

    invoke-virtual {v1, v2, v3, v0}, Landroid/location/LocationManager;->sendExtraCommand(Ljava/lang/String;Ljava/lang/String;Landroid/os/Bundle;)Z

    .line 518
    const/4 v0, 0x0

    .line 519
    goto :goto_0
.end method

.method public getGPSUpdateTime()I
    .locals 2

    .prologue
    .line 1243
    const/4 v0, 0x0

    .line 1244
    .local v0, "nRet":I
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    if-eqz v1, :cond_0

    .line 1245
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    invoke-virtual {v1}, Lcom/tw/mapmatch/jni/Natives;->nativeGetGPSUpdateTime()I

    move-result v0

    .line 1247
    :cond_0
    return v0
.end method

.method public getIsEscapeLinkNowFlag()Z
    .locals 2

    .prologue
    .line 1234
    const/4 v0, 0x0

    .line 1235
    .local v0, "bRet":Z
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    if-eqz v1, :cond_0

    .line 1236
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    invoke-virtual {v1}, Lcom/tw/mapmatch/jni/Natives;->nativeGetIsEscapeLinkNowFlag()Z

    move-result v0

    .line 1238
    :cond_0
    return v0
.end method

.method public getLogCountDown()I
    .locals 1

    .prologue
    .line 2217
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    invoke-virtual {v0}, Lcom/tw/mapmatch/jni/Natives;->getLogCountDown()I

    move-result v0

    return v0
.end method

.method public getMISENData()Lcom/tw/mapmatch/dataset/_MISENData;
    .locals 1

    .prologue
    .line 1041
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_misenData:Lcom/tw/mapmatch/dataset/_MISENData;

    return-object v0
.end method

.method public getSensorActionStatus()I
    .locals 1

    .prologue
    .line 1252
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->gravityModule:Lcom/thinkware/sundo/inavi3dservice/GravityModule;

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3dservice/GravityModule;->getSensorActionStatus()I

    move-result v0

    return v0
.end method

.method public getSensorErrorStatus()I
    .locals 1

    .prologue
    .line 1256
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->gravityModule:Lcom/thinkware/sundo/inavi3dservice/GravityModule;

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3dservice/GravityModule;->getSensorErrorStatus()I

    move-result v0

    return v0
.end method

.method public getSensorSensiblityStatus()I
    .locals 1

    .prologue
    .line 1264
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->gravityModule:Lcom/thinkware/sundo/inavi3dservice/GravityModule;

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3dservice/GravityModule;->getSensorSensiblityStatus()I

    move-result v0

    return v0
.end method

.method public getSensorUseStatus()I
    .locals 1

    .prologue
    .line 1260
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->gravityModule:Lcom/thinkware/sundo/inavi3dservice/GravityModule;

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3dservice/GravityModule;->getSensorUseStatus()I

    move-result v0

    return v0
.end method

.method public getSimulateDriveState()Z
    .locals 1

    .prologue
    .line 1207
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsSimulateStartStop:Z

    return v0
.end method

.method public getSimulatePause()Z
    .locals 2

    .prologue
    .line 1146
    const/4 v0, 0x0

    .line 1148
    .local v0, "bRet":Z
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    if-eqz v1, :cond_0

    .line 1149
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    invoke-virtual {v1}, Lcom/tw/mapmatch/jni/Natives;->nativeGetSimulatePause()Z

    move-result v0

    .line 1152
    :cond_0
    return v0
.end method

.method public getSimulatePos()I
    .locals 1

    .prologue
    .line 1142
    iget v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nSimulatePercent:I

    return v0
.end method

.method public getVirtualRoutePosition(IIIII)Lcom/tw/mapmatch/dataset/MMPosition;
    .locals 8
    .param p1, "x"    # I
    .param p2, "y"    # I
    .param p3, "nMapID"    # I
    .param p4, "nLinkID"    # I
    .param p5, "direction"    # I

    .prologue
    .line 1270
    sget-object v7, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->mm_mutex:Ljava/lang/Object;

    monitor-enter v7

    .line 1272
    :try_start_0
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    move v1, p1

    move v2, p2

    move v3, p3

    move v4, p4

    move v5, p5

    invoke-virtual/range {v0 .. v5}, Lcom/tw/mapmatch/jni/Natives;->nativeGetVirtualRoutePosition(IIIII)Lcom/tw/mapmatch/dataset/MMPosition;

    move-result-object v6

    .line 1273
    .local v6, "ret":Lcom/tw/mapmatch/dataset/MMPosition;
    monitor-exit v7

    .line 1275
    return-object v6

    .line 1273
    .end local v6    # "ret":Lcom/tw/mapmatch/dataset/MMPosition;
    :catchall_0
    move-exception v0

    monitor-exit v7
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw v0
.end method

.method public isLogDrive()Z
    .locals 1

    .prologue
    .line 364
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->bIsLogDrive:Z

    return v0
.end method

.method public setCRoadSkipMode(Z)V
    .locals 4
    .param p1, "bCRSkipMode"    # Z

    .prologue
    .line 1196
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->mmcHandler:Landroid/os/Handler;

    const/16 v3, 0x3ec

    invoke-virtual {v2, v3}, Landroid/os/Handler;->obtainMessage(I)Landroid/os/Message;

    move-result-object v1

    .line 1197
    .local v1, "msg":Landroid/os/Message;
    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    .line 1198
    .local v0, "data":Landroid/os/Bundle;
    const-string v2, "setCRoadSkipMode"

    const/4 v3, 0x1

    invoke-virtual {v0, v2, v3}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 1199
    const-string v2, "bCRSkipMode"

    invoke-virtual {v0, v2, p1}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 1200
    invoke-virtual {v1, v0}, Landroid/os/Message;->setData(Landroid/os/Bundle;)V

    .line 1201
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->mmcHandler:Landroid/os/Handler;

    invoke-virtual {v2, v1}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    .line 1202
    return-void
.end method

.method public setDRMString(Ljava/lang/String;)Z
    .locals 2
    .param p1, "SDRM4MMC"    # Ljava/lang/String;

    .prologue
    .line 539
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    invoke-virtual {v1, p1}, Lcom/tw/mapmatch/jni/Natives;->nativeSetDRMString(Ljava/lang/String;)Z

    move-result v0

    .line 542
    .local v0, "bRet":Z
    return v0
.end method

.method public setDoingReRoute()V
    .locals 1

    .prologue
    .line 2207
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    invoke-virtual {v0}, Lcom/tw/mapmatch/jni/Natives;->setDoingReRoute()V

    .line 2209
    return-void
.end method

.method public setDoingRoute()V
    .locals 1

    .prologue
    .line 2212
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    invoke-virtual {v0}, Lcom/tw/mapmatch/jni/Natives;->setDoingRoute()V

    .line 2214
    return-void
.end method

.method public setGuideCode(II)V
    .locals 1
    .param p1, "nGuideCode"    # I
    .param p2, "nDistTurnPnt"    # I

    .prologue
    .line 2228
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    invoke-virtual {v0, p1, p2}, Lcom/tw/mapmatch/jni/Natives;->nativeSetGuideCode(II)V

    .line 2229
    return-void
.end method

.method public setIsEscapeLinkNowFlag(Z)V
    .locals 1
    .param p1, "bEscape"    # Z

    .prologue
    .line 1227
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    if-eqz v0, :cond_0

    .line 1228
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    invoke-virtual {v0, p1}, Lcom/tw/mapmatch/jni/Natives;->nativeSetIsEscapeLinkNowFlag(Z)V

    .line 1230
    :cond_0
    return-void
.end method

.method public setLastPosSavedInZone(Z)V
    .locals 1
    .param p1, "bSaved"    # Z

    .prologue
    .line 1220
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    if-eqz v0, :cond_0

    .line 1221
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    invoke-virtual {v0, p1}, Lcom/tw/mapmatch/jni/Natives;->nativeSetLastPosSavedInZone(Z)V

    .line 1223
    :cond_0
    return-void
.end method

.method public setLogCountDown()V
    .locals 1

    .prologue
    .line 2221
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    invoke-virtual {v0}, Lcom/tw/mapmatch/jni/Natives;->setLogCountDown()V

    .line 2222
    return-void
.end method

.method public setLogDrive(ZLjava/lang/String;)V
    .locals 9
    .param p1, "val"    # Z
    .param p2, "strPath"    # Ljava/lang/String;

    .prologue
    const/16 v8, 0x3eb

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v5, 0x1

    .line 286
    if-ne p1, v5, :cond_2

    .line 287
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsRunning:[Z

    aget-boolean v3, v3, v6

    if-ne v3, v5, :cond_1

    .line 360
    :cond_0
    :goto_0
    return-void

    .line 290
    :cond_1
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsRunning:[Z

    const/4 v4, 0x3

    aput-boolean v7, v3, v4

    .line 292
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsRunning:[Z

    aput-boolean v5, v3, v6

    .line 307
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->mmcHandler:Landroid/os/Handler;

    invoke-virtual {v3, v8}, Landroid/os/Handler;->obtainMessage(I)Landroid/os/Message;

    move-result-object v2

    .line 308
    .local v2, "msg":Landroid/os/Message;
    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    .line 309
    .local v0, "data":Landroid/os/Bundle;
    const-string v3, "startGravity"

    invoke-virtual {v0, v3, v5}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 310
    const-string v3, "strPath"

    invoke-virtual {v0, v3, p2}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 311
    invoke-virtual {v2, v0}, Landroid/os/Message;->setData(Landroid/os/Bundle;)V

    .line 312
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->mmcHandler:Landroid/os/Handler;

    invoke-virtual {v3, v2}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    .line 359
    :goto_1
    iput-boolean p1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->bIsLogDrive:Z

    goto :goto_0

    .line 315
    .end local v0    # "data":Landroid/os/Bundle;
    .end local v2    # "msg":Landroid/os/Message;
    :cond_2
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsRunning:[Z

    aget-boolean v3, v3, v6

    if-eqz v3, :cond_0

    .line 331
    const-wide/16 v4, 0x96

    :try_start_0
    invoke-static {v4, v5}, Ljava/lang/Thread;->sleep(J)V

    .line 332
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_LogThread:Ljava/lang/Thread;

    invoke-virtual {v3}, Ljava/lang/Thread;->interrupt()V

    .line 333
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_LogThread:Ljava/lang/Thread;

    invoke-virtual {v3}, Ljava/lang/Thread;->join()V
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0

    .line 337
    :goto_2
    const/4 v3, 0x0

    iput-object v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_LogThread:Ljava/lang/Thread;

    .line 343
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->mmcHandler:Landroid/os/Handler;

    invoke-virtual {v3, v8}, Landroid/os/Handler;->obtainMessage(I)Landroid/os/Message;

    move-result-object v2

    .line 344
    .restart local v2    # "msg":Landroid/os/Message;
    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    .line 345
    .restart local v0    # "data":Landroid/os/Bundle;
    const-string v3, "startGravity"

    invoke-virtual {v0, v3, v7}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 346
    invoke-virtual {v2, v0}, Landroid/os/Message;->setData(Landroid/os/Bundle;)V

    .line 347
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->mmcHandler:Landroid/os/Handler;

    invoke-virtual {v3, v2}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto :goto_1

    .line 334
    .end local v0    # "data":Landroid/os/Bundle;
    .end local v2    # "msg":Landroid/os/Message;
    :catch_0
    move-exception v1

    .line 335
    .local v1, "ie":Ljava/lang/InterruptedException;
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_ctxtParent:Landroid/content/Context;

    const-string v4, "InterruptedException m_LogThread"

    const/16 v5, 0x7d0

    invoke-static {v3, v4, v5}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v3

    invoke-virtual {v3}, Landroid/widget/Toast;->show()V

    goto :goto_2
.end method

.method public setMapMatchWalk(Z)V
    .locals 6
    .param p1, "val"    # Z

    .prologue
    const/4 v5, 0x0

    const/4 v4, 0x1

    .line 259
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->mmcHandler:Landroid/os/Handler;

    const/16 v3, 0x3ea

    invoke-virtual {v2, v3}, Landroid/os/Handler;->obtainMessage(I)Landroid/os/Message;

    move-result-object v1

    .line 260
    .local v1, "msg":Landroid/os/Message;
    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    .line 261
    .local v0, "data":Landroid/os/Bundle;
    const-string v2, "bIsSensor"

    invoke-virtual {v0, v2, v4}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 262
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->getSensorUseStatus()I

    move-result v2

    if-nez v2, :cond_0

    .line 263
    const-string v2, "bIsSensor"

    invoke-virtual {v0, v2, v5}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 266
    :cond_0
    if-ne p1, v4, :cond_1

    .line 267
    iput-boolean v5, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsCar:Z

    .line 272
    :goto_0
    invoke-virtual {v1, v0}, Landroid/os/Message;->setData(Landroid/os/Bundle;)V

    .line 273
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->mmcHandler:Landroid/os/Handler;

    invoke-virtual {v2, v1}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    .line 282
    return-void

    .line 269
    :cond_1
    iput-boolean v4, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsCar:Z

    goto :goto_0
.end method

.method public setOBD2Data(Lcom/tw/mapmatch/dataset/_MMOBD2Data;)V
    .locals 3
    .param p1, "obd2Data"    # Lcom/tw/mapmatch/dataset/_MMOBD2Data;

    .prologue
    .line 2128
    invoke-virtual {p1}, Lcom/tw/mapmatch/dataset/_MMOBD2Data;->clone()Lcom/tw/mapmatch/dataset/_MMOBD2Data;

    move-result-object v0

    .line 2129
    .local v0, "obd2":Lcom/tw/mapmatch/dataset/_MMOBD2Data;
    if-eqz v0, :cond_0

    .line 2130
    iput-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_obd2Info:Lcom/tw/mapmatch/dataset/_MMOBD2Data;

    .line 2131
    const/4 v2, 0x1

    iput-boolean v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bOBD2DataUpdated:Z

    .line 2135
    const/4 v1, 0x0

    .line 2136
    .local v1, "used":I
    iget-boolean v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bUseOBD2:Z

    if-eqz v2, :cond_0

    .line 2152
    .end local v1    # "used":I
    :cond_0
    return-void
.end method

.method public setRouteTable([BI)I
    .locals 6
    .param p1, "buffer"    # [B
    .param p2, "nLength"    # I

    .prologue
    .line 1106
    sget-object v3, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->mm_mutex:Ljava/lang/Object;

    monitor-enter v3

    .line 1109
    :try_start_0
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    array-length v4, p1

    invoke-virtual {v2, p1, v4}, Lcom/tw/mapmatch/jni/Natives;->nativeSetRouteTable([BI)I

    move-result v1

    .line 1110
    .local v1, "nResult":I
    const-string v2, "MMCModule"

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "rt ret ["

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string v5, "]"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v2, v4}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 1111
    :try_start_1
    monitor-exit v3

    .line 1118
    .end local v1    # "nResult":I
    :goto_0
    return v1

    .line 1113
    :catch_0
    move-exception v0

    .line 1115
    .local v0, "ex":Ljava/lang/Exception;
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_ctxtParent:Landroid/content/Context;

    const-string v4, "IOException route table"

    const/16 v5, 0x7d0

    invoke-static {v2, v4, v5}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v2

    invoke-virtual {v2}, Landroid/widget/Toast;->show()V

    .line 1117
    monitor-exit v3

    .line 1118
    const/4 v1, 0x0

    goto :goto_0

    .line 1117
    .end local v0    # "ex":Ljava/lang/Exception;
    :catchall_0
    move-exception v2

    monitor-exit v3
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw v2
.end method

.method public setRouteTableInDirect(Ljava/lang/String;)I
    .locals 4
    .param p1, "fileName"    # Ljava/lang/String;

    .prologue
    .line 1122
    const-string v1, "MMCModule"

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "rt name ["

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "]"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 1123
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    invoke-virtual {v1, p1}, Lcom/tw/mapmatch/jni/Natives;->nativeSetRouteTableInDirect(Ljava/lang/String;)I

    move-result v0

    .line 1124
    .local v0, "nResult":I
    const-string v1, "MMCModule"

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "rt ret ["

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "]"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 1125
    return v0
.end method

.method public setSimulatePause(Z)V
    .locals 4
    .param p1, "bPause"    # Z

    .prologue
    .line 1164
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->mmcHandler:Landroid/os/Handler;

    const/16 v3, 0x3ec

    invoke-virtual {v2, v3}, Landroid/os/Handler;->obtainMessage(I)Landroid/os/Message;

    move-result-object v1

    .line 1165
    .local v1, "msg":Landroid/os/Message;
    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    .line 1166
    .local v0, "data":Landroid/os/Bundle;
    const-string v2, "setSimulatePause"

    const/4 v3, 0x1

    invoke-virtual {v0, v2, v3}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 1167
    const-string v2, "bPause"

    invoke-virtual {v0, v2, p1}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 1168
    invoke-virtual {v1, v0}, Landroid/os/Message;->setData(Landroid/os/Bundle;)V

    .line 1169
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->mmcHandler:Landroid/os/Handler;

    invoke-virtual {v2, v1}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    .line 1170
    return-void
.end method

.method public setSimulatePercentage(I)V
    .locals 4
    .param p1, "nPercentage"    # I

    .prologue
    .line 1188
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->mmcHandler:Landroid/os/Handler;

    const/16 v3, 0x3ec

    invoke-virtual {v2, v3}, Landroid/os/Handler;->obtainMessage(I)Landroid/os/Message;

    move-result-object v1

    .line 1189
    .local v1, "msg":Landroid/os/Message;
    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    .line 1190
    .local v0, "data":Landroid/os/Bundle;
    const-string v2, "setSimulatePercentage"

    const/4 v3, 0x1

    invoke-virtual {v0, v2, v3}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 1191
    const-string v2, "nPercentage"

    invoke-virtual {v0, v2, p1}, Landroid/os/Bundle;->putInt(Ljava/lang/String;I)V

    .line 1192
    invoke-virtual {v1, v0}, Landroid/os/Message;->setData(Landroid/os/Bundle;)V

    .line 1193
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->mmcHandler:Landroid/os/Handler;

    invoke-virtual {v2, v1}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    .line 1194
    return-void
.end method

.method public setSimulatePos(I)V
    .locals 4
    .param p1, "nPos"    # I

    .prologue
    .line 1156
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->mmcHandler:Landroid/os/Handler;

    const/16 v3, 0x3ec

    invoke-virtual {v2, v3}, Landroid/os/Handler;->obtainMessage(I)Landroid/os/Message;

    move-result-object v1

    .line 1157
    .local v1, "msg":Landroid/os/Message;
    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    .line 1158
    .local v0, "data":Landroid/os/Bundle;
    const-string v2, "setSimulatePos"

    const/4 v3, 0x1

    invoke-virtual {v0, v2, v3}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 1159
    const-string v2, "nPos"

    invoke-virtual {v0, v2, p1}, Landroid/os/Bundle;->putInt(Ljava/lang/String;I)V

    .line 1160
    invoke-virtual {v1, v0}, Landroid/os/Message;->setData(Landroid/os/Bundle;)V

    .line 1161
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->mmcHandler:Landroid/os/Handler;

    invoke-virtual {v2, v1}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    .line 1162
    return-void
.end method

.method public setSimulateSpeed(I)V
    .locals 4
    .param p1, "nSpeed"    # I

    .prologue
    .line 1180
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->mmcHandler:Landroid/os/Handler;

    const/16 v3, 0x3ec

    invoke-virtual {v2, v3}, Landroid/os/Handler;->obtainMessage(I)Landroid/os/Message;

    move-result-object v1

    .line 1181
    .local v1, "msg":Landroid/os/Message;
    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    .line 1182
    .local v0, "data":Landroid/os/Bundle;
    const-string v2, "setSimulateSpeed"

    const/4 v3, 0x1

    invoke-virtual {v0, v2, v3}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 1183
    const-string v2, "nSpeed"

    invoke-virtual {v0, v2, p1}, Landroid/os/Bundle;->putInt(Ljava/lang/String;I)V

    .line 1184
    invoke-virtual {v1, v0}, Landroid/os/Message;->setData(Landroid/os/Bundle;)V

    .line 1185
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->mmcHandler:Landroid/os/Handler;

    invoke-virtual {v2, v1}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    .line 1186
    return-void
.end method

.method public setSimulateStartStop(Z)V
    .locals 4
    .param p1, "bStart"    # Z

    .prologue
    .line 1172
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->mmcHandler:Landroid/os/Handler;

    const/16 v3, 0x3ec

    invoke-virtual {v2, v3}, Landroid/os/Handler;->obtainMessage(I)Landroid/os/Message;

    move-result-object v1

    .line 1173
    .local v1, "msg":Landroid/os/Message;
    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    .line 1174
    .local v0, "data":Landroid/os/Bundle;
    const-string v2, "setSimulateStartStop"

    const/4 v3, 0x1

    invoke-virtual {v0, v2, v3}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 1175
    const-string v2, "bStart"

    invoke-virtual {v0, v2, p1}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 1176
    invoke-virtual {v1, v0}, Landroid/os/Message;->setData(Landroid/os/Bundle;)V

    .line 1177
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->mmcHandler:Landroid/os/Handler;

    invoke-virtual {v2, v1}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    .line 1178
    return-void
.end method

.method public setUseOBD2(Z)V
    .locals 0
    .param p1, "bUseOBD2"    # Z

    .prologue
    .line 2156
    iput-boolean p1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bUseOBD2:Z

    .line 2157
    return-void
.end method

.method public setUseOBD2Data(Z)V
    .locals 1
    .param p1, "use"    # Z

    .prologue
    .line 2115
    iput-boolean p1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bUseOBD2:Z

    .line 2116
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    invoke-virtual {v0, p1}, Lcom/tw/mapmatch/jni/Natives;->nativeSetUseOBD2Data(Z)V

    .line 2122
    return-void
.end method

.method public setUsingVirtualRoute(Z)V
    .locals 1
    .param p1, "use"    # Z

    .prologue
    .line 1212
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    if-eqz v0, :cond_0

    .line 1213
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    invoke-virtual {v0, p1}, Lcom/tw/mapmatch/jni/Natives;->nativeSetUseVirtualRoute(Z)V

    .line 1215
    :cond_0
    return-void
.end method

.method public startLiveLogging(Ljava/lang/String;)I
    .locals 1
    .param p1, "pathName"    # Ljava/lang/String;

    .prologue
    .line 2199
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    invoke-virtual {v0, p1}, Lcom/tw/mapmatch/jni/Natives;->startLiveLogging(Ljava/lang/String;)I

    move-result v0

    return v0
.end method

.method public startLogging(Ljava/lang/String;)I
    .locals 1
    .param p1, "fileName"    # Ljava/lang/String;

    .prologue
    .line 1826
    const/4 v0, 0x0

    invoke-virtual {p0, p1, v0}, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->startLogging(Ljava/lang/String;Z)I

    move-result v0

    return v0
.end method

.method public declared-synchronized startLogging(Ljava/lang/String;Z)I
    .locals 10
    .param p1, "fileName"    # Ljava/lang/String;
    .param p2, "debugmode"    # Z

    .prologue
    .line 1830
    monitor-enter p0

    :try_start_0
    iget-object v5, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_gpsSocket:Lcom/thinkware/sundo/inavi3dservice/GPSSocketClient;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-nez v5, :cond_0

    const/4 v5, -0x1

    .line 1872
    :goto_0
    monitor-exit p0

    return v5

    .line 1832
    :cond_0
    const-wide/16 v6, 0x0

    .line 1834
    .local v6, "timestamp":J
    :try_start_1
    invoke-direct {p0}, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->getGpsMode()Ljava/lang/String;

    move-result-object v1

    .line 1835
    .local v1, "gpsMode":Ljava/lang/String;
    const-string v5, "0"

    invoke-virtual {v5, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    move-result v5

    if-eqz v5, :cond_1

    .line 1839
    :try_start_2
    iget-object v5, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_gpsSocket:Lcom/thinkware/sundo/inavi3dservice/GPSSocketClient;

    sget-object v8, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->dbgModeMsg:[B

    invoke-virtual {v5, v8}, Lcom/thinkware/sundo/inavi3dservice/GPSSocketClient;->Send([B)I

    .line 1840
    const-wide/16 v8, 0x32

    invoke-static {v8, v9}, Ljava/lang/Thread;->sleep(J)V
    :try_end_2
    .catch Ljava/lang/InterruptedException; {:try_start_2 .. :try_end_2} :catch_0
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 1857
    :cond_1
    :goto_1
    :try_start_3
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v6

    .line 1859
    const-string v5, "Asia/Seoul"

    invoke-static {v5}, Ljava/util/TimeZone;->getTimeZone(Ljava/lang/String;)Ljava/util/TimeZone;

    move-result-object v5

    invoke-static {v5}, Ljava/util/TimeZone;->setDefault(Ljava/util/TimeZone;)V

    .line 1860
    new-instance v4, Ljava/text/SimpleDateFormat;

    const-string v5, "yyyyMMdd-HHmmss"

    invoke-direct {v4, v5}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;)V

    .line 1862
    .local v4, "sdf":Ljava/text/SimpleDateFormat;
    new-instance v3, Ljava/util/Date;

    invoke-direct {v3, v6, v7}, Ljava/util/Date;-><init>(J)V

    .line 1866
    .local v3, "now":Ljava/util/Date;
    if-eqz p1, :cond_2

    .line 1867
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v8, "/SENSORLOG-"

    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v4, v3}, Ljava/text/SimpleDateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v8, ".txt"

    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    .line 1872
    .local v2, "logFileName":Ljava/lang/String;
    :goto_2
    iget-object v5, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    invoke-virtual {v5, v2}, Lcom/tw/mapmatch/jni/Natives;->nativeSetLogFileName(Ljava/lang/String;)I

    move-result v5

    goto :goto_0

    .line 1841
    .end local v2    # "logFileName":Ljava/lang/String;
    .end local v3    # "now":Ljava/util/Date;
    .end local v4    # "sdf":Ljava/text/SimpleDateFormat;
    :catch_0
    move-exception v0

    .line 1842
    .local v0, "e":Ljava/lang/InterruptedException;
    const-string v5, "GPSMessage"

    const-string v8, "Error on sleep()."

    invoke-static {v5, v8}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    goto :goto_1

    .line 1830
    .end local v0    # "e":Ljava/lang/InterruptedException;
    .end local v1    # "gpsMode":Ljava/lang/String;
    .end local v6    # "timestamp":J
    :catchall_0
    move-exception v5

    monitor-exit p0

    throw v5

    .line 1843
    .restart local v1    # "gpsMode":Ljava/lang/String;
    .restart local v6    # "timestamp":J
    :catch_1
    move-exception v0

    .line 1844
    .local v0, "e":Ljava/lang/Exception;
    :try_start_4
    const-string v5, "GPSMessage"

    const-string v8, "Failed sending debug mode messages."

    invoke-static {v5, v8}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_1

    .line 1869
    .end local v0    # "e":Ljava/lang/Exception;
    .restart local v3    # "now":Ljava/util/Date;
    .restart local v4    # "sdf":Ljava/text/SimpleDateFormat;
    :cond_2
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    sget-object v8, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->kStorageRoot:Ljava/lang/String;

    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v8, "/gpslog/SENSORLOG-"

    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v4, v3}, Ljava/text/SimpleDateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v8, ".txt"

    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    move-result-object v2

    .restart local v2    # "logFileName":Ljava/lang/String;
    goto :goto_2
.end method

.method public stopLiveLogging()V
    .locals 1

    .prologue
    .line 2203
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    invoke-virtual {v0}, Lcom/tw/mapmatch/jni/Natives;->stopLiveLogging()V

    .line 2204
    return-void
.end method

.method public stopLogging()I
    .locals 1

    .prologue
    .line 1877
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    invoke-virtual {v0}, Lcom/tw/mapmatch/jni/Natives;->nativeStopLogging()I

    move-result v0

    return v0
.end method
