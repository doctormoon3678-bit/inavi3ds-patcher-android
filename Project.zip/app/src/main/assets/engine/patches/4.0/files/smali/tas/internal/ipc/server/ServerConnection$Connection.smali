.class Ltas/internal/ipc/server/ServerConnection$Connection;
.super Ltas/internal/ipc/util/ServiceConnectionAbstract;
.source "ServerConnection.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltas/internal/ipc/server/ServerConnection;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "Connection"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ltas/internal/ipc/util/ServiceConnectionAbstract",
        "<",
        "Ltas/internal/ipc/server/IServerService;",
        ">;"
    }
.end annotation


# static fields
.field private static final NAME:Ljava/lang/String; = "IPC SERVER"

.field private static final REGISTER_RECEIVER:I = 0x65

.field private static final REGISTER_SENDER:I = 0x68

.field private static final SET_CALLBACK:I = 0x73

.field private static final TRANSMIT:I = 0x74

.field private static final UNREGISTER_RECEIVER:I = 0x66

.field private static final UNREGISTER_SENDER:I = 0x69

.field private static final UNWATCH_ANONYMOUS_RECEIVER:I = 0x6e

.field private static final UNWATCH_ANONYMOUS_SENDER:I = 0x72

.field private static final UNWATCH_RECEIVER:I = 0x6c

.field private static final UNWATCH_SENDER:I = 0x70

.field private static final UPDATE_RECEIVER:I = 0x67

.field private static final UPDATE_SENDER:I = 0x6a

.field private static final WATCH_ANONYMOUS_RECEIVER:I = 0x6d

.field private static final WATCH_ANONYMOUS_SENDER:I = 0x71

.field private static final WATCH_RECEIVER:I = 0x6b

.field private static final WATCH_SENDER:I = 0x6f


# instance fields
.field private final mCallback:Ltas/internal/ipc/server/ServerConnection$ServerCallback;


# direct methods
.method static synthetic -wrap0(Ltas/internal/ipc/server/ServerConnection$Connection;Landroid/content/Context;)V
    .locals 0
    .param p1, "context"    # Landroid/content/Context;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/ipc/server/ServerConnection$Connection;->connect(Landroid/content/Context;)V

    return-void
.end method

.method static synthetic -wrap1(Ltas/internal/ipc/server/ServerConnection$Connection;Ltas/internal/ipc/server/RemoteReceiver;)V
    .locals 0
    .param p1, "receiver"    # Ltas/internal/ipc/server/RemoteReceiver;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/ipc/server/ServerConnection$Connection;->registerReceiver(Ltas/internal/ipc/server/RemoteReceiver;)V

    return-void
.end method

.method static synthetic -wrap10(Ltas/internal/ipc/server/ServerConnection$Connection;Ltas/internal/ipc/server/RemoteReceiver;)V
    .locals 0
    .param p1, "receiver"    # Ltas/internal/ipc/server/RemoteReceiver;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/ipc/server/ServerConnection$Connection;->stopWatchingAnonymousSender(Ltas/internal/ipc/server/RemoteReceiver;)V

    return-void
.end method

.method static synthetic -wrap11(Ltas/internal/ipc/server/ServerConnection$Connection;Ltas/internal/ipc/server/RemoteSender;)V
    .locals 0
    .param p1, "sender"    # Ltas/internal/ipc/server/RemoteSender;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/ipc/server/ServerConnection$Connection;->stopWatchingReceiver(Ltas/internal/ipc/server/RemoteSender;)V

    return-void
.end method

.method static synthetic -wrap12(Ltas/internal/ipc/server/ServerConnection$Connection;Ltas/internal/ipc/server/RemoteReceiver;)V
    .locals 0
    .param p1, "receiver"    # Ltas/internal/ipc/server/RemoteReceiver;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/ipc/server/ServerConnection$Connection;->stopWatchingSender(Ltas/internal/ipc/server/RemoteReceiver;)V

    return-void
.end method

.method static synthetic -wrap13(Ltas/internal/ipc/server/ServerConnection$Connection;Ltas/internal/ipc/server/RemoteMessage;)V
    .locals 0
    .param p1, "msg"    # Ltas/internal/ipc/server/RemoteMessage;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/ipc/server/ServerConnection$Connection;->transmit(Ltas/internal/ipc/server/RemoteMessage;)V

    return-void
.end method

.method static synthetic -wrap14(Ltas/internal/ipc/server/ServerConnection$Connection;Ltas/internal/ipc/server/RemoteReceiver;)V
    .locals 0
    .param p1, "receiver"    # Ltas/internal/ipc/server/RemoteReceiver;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/ipc/server/ServerConnection$Connection;->unregisterReceiver(Ltas/internal/ipc/server/RemoteReceiver;)V

    return-void
.end method

.method static synthetic -wrap15(Ltas/internal/ipc/server/ServerConnection$Connection;Ltas/internal/ipc/server/RemoteSender;)V
    .locals 0
    .param p1, "sender"    # Ltas/internal/ipc/server/RemoteSender;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/ipc/server/ServerConnection$Connection;->unregisterSender(Ltas/internal/ipc/server/RemoteSender;)V

    return-void
.end method

.method static synthetic -wrap16(Ltas/internal/ipc/server/ServerConnection$Connection;Ltas/internal/ipc/server/RemoteReceiver;)V
    .locals 0
    .param p1, "receiver"    # Ltas/internal/ipc/server/RemoteReceiver;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/ipc/server/ServerConnection$Connection;->updateReceiver(Ltas/internal/ipc/server/RemoteReceiver;)V

    return-void
.end method

.method static synthetic -wrap17(Ltas/internal/ipc/server/ServerConnection$Connection;Ltas/internal/ipc/server/RemoteSender;)V
    .locals 0
    .param p1, "sender"    # Ltas/internal/ipc/server/RemoteSender;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/ipc/server/ServerConnection$Connection;->updateSender(Ltas/internal/ipc/server/RemoteSender;)V

    return-void
.end method

.method static synthetic -wrap2(Ltas/internal/ipc/server/ServerConnection$Connection;Ltas/internal/ipc/server/RemoteSender;)V
    .locals 0
    .param p1, "sender"    # Ltas/internal/ipc/server/RemoteSender;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/ipc/server/ServerConnection$Connection;->registerSender(Ltas/internal/ipc/server/RemoteSender;)V

    return-void
.end method

.method static synthetic -wrap3(Ltas/internal/ipc/server/ServerConnection$Connection;Ltas/internal/ipc/server/ServerConnection$ReceiverCallback;)V
    .locals 0
    .param p1, "cb"    # Ltas/internal/ipc/server/ServerConnection$ReceiverCallback;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/ipc/server/ServerConnection$Connection;->setReceiverCallback(Ltas/internal/ipc/server/ServerConnection$ReceiverCallback;)V

    return-void
.end method

.method static synthetic -wrap4(Ltas/internal/ipc/server/ServerConnection$Connection;Ltas/internal/ipc/server/ServerConnection$SenderCallback;)V
    .locals 0
    .param p1, "cb"    # Ltas/internal/ipc/server/ServerConnection$SenderCallback;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/ipc/server/ServerConnection$Connection;->setSenderCallback(Ltas/internal/ipc/server/ServerConnection$SenderCallback;)V

    return-void
.end method

.method static synthetic -wrap5(Ltas/internal/ipc/server/ServerConnection$Connection;Ltas/internal/ipc/server/RemoteSender;)V
    .locals 0
    .param p1, "sender"    # Ltas/internal/ipc/server/RemoteSender;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/ipc/server/ServerConnection$Connection;->startWatchingAnonymousReceiver(Ltas/internal/ipc/server/RemoteSender;)V

    return-void
.end method

.method static synthetic -wrap6(Ltas/internal/ipc/server/ServerConnection$Connection;Ltas/internal/ipc/server/RemoteReceiver;)V
    .locals 0
    .param p1, "receiver"    # Ltas/internal/ipc/server/RemoteReceiver;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/ipc/server/ServerConnection$Connection;->startWatchingAnonymousSender(Ltas/internal/ipc/server/RemoteReceiver;)V

    return-void
.end method

.method static synthetic -wrap7(Ltas/internal/ipc/server/ServerConnection$Connection;Ltas/internal/ipc/server/RemoteSender;)V
    .locals 0
    .param p1, "sender"    # Ltas/internal/ipc/server/RemoteSender;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/ipc/server/ServerConnection$Connection;->startWatchingReceiver(Ltas/internal/ipc/server/RemoteSender;)V

    return-void
.end method

.method static synthetic -wrap8(Ltas/internal/ipc/server/ServerConnection$Connection;Ltas/internal/ipc/server/RemoteReceiver;)V
    .locals 0
    .param p1, "receiver"    # Ltas/internal/ipc/server/RemoteReceiver;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/ipc/server/ServerConnection$Connection;->startWatchingSender(Ltas/internal/ipc/server/RemoteReceiver;)V

    return-void
.end method

.method static synthetic -wrap9(Ltas/internal/ipc/server/ServerConnection$Connection;Ltas/internal/ipc/server/RemoteSender;)V
    .locals 0
    .param p1, "sender"    # Ltas/internal/ipc/server/RemoteSender;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/ipc/server/ServerConnection$Connection;->stopWatchingAnonymousReceiver(Ltas/internal/ipc/server/RemoteSender;)V

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    .prologue
    .line 192
    const-string/jumbo v0, "IPC SERVER"

    invoke-direct {p0, v0}, Ltas/internal/ipc/util/ServiceConnectionAbstract;-><init>(Ljava/lang/String;)V

    .line 190
    new-instance v0, Ltas/internal/ipc/server/ServerConnection$ServerCallback;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Ltas/internal/ipc/server/ServerConnection$ServerCallback;-><init>(Ltas/internal/ipc/server/ServerConnection$ServerCallback;)V

    iput-object v0, p0, Ltas/internal/ipc/server/ServerConnection$Connection;->mCallback:Ltas/internal/ipc/server/ServerConnection$ServerCallback;

    .line 192
    return-void
.end method

.method synthetic constructor <init>(Ltas/internal/ipc/server/ServerConnection$Connection;)V
    .locals 0

    .prologue
    invoke-direct {p0}, Ltas/internal/ipc/server/ServerConnection$Connection;-><init>()V

    return-void
.end method

.method private connect(Landroid/content/Context;)V
    .locals 3
    .param p1, "context"    # Landroid/content/Context;

    .prologue
    .line 256
    const-string/jumbo v0, "tas.service.common"

    .line 257
    const-string/jumbo v1, "tas.service.ipc.IpcServer"

    .line 258
    const/16 v2, 0x49

    .line 255
    invoke-virtual {p0, p1, v0, v1, v2}, Ltas/internal/ipc/server/ServerConnection$Connection;->connect(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;I)V

    .line 254
    return-void
.end method

.method private registerReceiver(Ltas/internal/ipc/server/RemoteReceiver;)V
    .locals 1
    .param p1, "receiver"    # Ltas/internal/ipc/server/RemoteReceiver;

    .prologue
    .line 195
    const/16 v0, 0x65

    invoke-virtual {p0, v0, p1}, Ltas/internal/ipc/server/ServerConnection$Connection;->schedule(ILjava/lang/Object;)V

    .line 194
    return-void
.end method

.method private registerSender(Ltas/internal/ipc/server/RemoteSender;)V
    .locals 1
    .param p1, "sender"    # Ltas/internal/ipc/server/RemoteSender;

    .prologue
    .line 207
    const/16 v0, 0x68

    invoke-virtual {p0, v0, p1}, Ltas/internal/ipc/server/ServerConnection$Connection;->schedule(ILjava/lang/Object;)V

    .line 206
    return-void
.end method

.method private setReceiverCallback(Ltas/internal/ipc/server/ServerConnection$ReceiverCallback;)V
    .locals 1
    .param p1, "cb"    # Ltas/internal/ipc/server/ServerConnection$ReceiverCallback;

    .prologue
    .line 268
    iget-object v0, p0, Ltas/internal/ipc/server/ServerConnection$Connection;->mCallback:Ltas/internal/ipc/server/ServerConnection$ServerCallback;

    invoke-virtual {v0, p1}, Ltas/internal/ipc/server/ServerConnection$ServerCallback;->setReceiverCallback(Ltas/internal/ipc/server/ServerConnection$ReceiverCallback;)V

    .line 267
    return-void
.end method

.method private setSenderCallback(Ltas/internal/ipc/server/ServerConnection$SenderCallback;)V
    .locals 1
    .param p1, "cb"    # Ltas/internal/ipc/server/ServerConnection$SenderCallback;

    .prologue
    .line 264
    iget-object v0, p0, Ltas/internal/ipc/server/ServerConnection$Connection;->mCallback:Ltas/internal/ipc/server/ServerConnection$ServerCallback;

    invoke-virtual {v0, p1}, Ltas/internal/ipc/server/ServerConnection$ServerCallback;->setSenderCallback(Ltas/internal/ipc/server/ServerConnection$SenderCallback;)V

    .line 263
    return-void
.end method

.method private startWatchingAnonymousReceiver(Ltas/internal/ipc/server/RemoteSender;)V
    .locals 1
    .param p1, "sender"    # Ltas/internal/ipc/server/RemoteSender;

    .prologue
    .line 227
    const/16 v0, 0x6d

    invoke-virtual {p0, v0, p1}, Ltas/internal/ipc/server/ServerConnection$Connection;->schedule(ILjava/lang/Object;)V

    .line 226
    return-void
.end method

.method private startWatchingAnonymousSender(Ltas/internal/ipc/server/RemoteReceiver;)V
    .locals 1
    .param p1, "receiver"    # Ltas/internal/ipc/server/RemoteReceiver;

    .prologue
    .line 243
    const/16 v0, 0x71

    invoke-virtual {p0, v0, p1}, Ltas/internal/ipc/server/ServerConnection$Connection;->schedule(ILjava/lang/Object;)V

    .line 242
    return-void
.end method

.method private startWatchingReceiver(Ltas/internal/ipc/server/RemoteSender;)V
    .locals 1
    .param p1, "sender"    # Ltas/internal/ipc/server/RemoteSender;

    .prologue
    .line 219
    const/16 v0, 0x6b

    invoke-virtual {p0, v0, p1}, Ltas/internal/ipc/server/ServerConnection$Connection;->schedule(ILjava/lang/Object;)V

    .line 218
    return-void
.end method

.method private startWatchingSender(Ltas/internal/ipc/server/RemoteReceiver;)V
    .locals 1
    .param p1, "receiver"    # Ltas/internal/ipc/server/RemoteReceiver;

    .prologue
    .line 235
    const/16 v0, 0x6f

    invoke-virtual {p0, v0, p1}, Ltas/internal/ipc/server/ServerConnection$Connection;->schedule(ILjava/lang/Object;)V

    .line 234
    return-void
.end method

.method private stopWatchingAnonymousReceiver(Ltas/internal/ipc/server/RemoteSender;)V
    .locals 1
    .param p1, "sender"    # Ltas/internal/ipc/server/RemoteSender;

    .prologue
    .line 231
    const/16 v0, 0x6e

    invoke-virtual {p0, v0, p1}, Ltas/internal/ipc/server/ServerConnection$Connection;->schedule(ILjava/lang/Object;)V

    .line 230
    return-void
.end method

.method private stopWatchingAnonymousSender(Ltas/internal/ipc/server/RemoteReceiver;)V
    .locals 1
    .param p1, "receiver"    # Ltas/internal/ipc/server/RemoteReceiver;

    .prologue
    .line 247
    const/16 v0, 0x72

    invoke-virtual {p0, v0, p1}, Ltas/internal/ipc/server/ServerConnection$Connection;->schedule(ILjava/lang/Object;)V

    .line 246
    return-void
.end method

.method private stopWatchingReceiver(Ltas/internal/ipc/server/RemoteSender;)V
    .locals 1
    .param p1, "sender"    # Ltas/internal/ipc/server/RemoteSender;

    .prologue
    .line 223
    const/16 v0, 0x6c

    invoke-virtual {p0, v0, p1}, Ltas/internal/ipc/server/ServerConnection$Connection;->schedule(ILjava/lang/Object;)V

    .line 222
    return-void
.end method

.method private stopWatchingSender(Ltas/internal/ipc/server/RemoteReceiver;)V
    .locals 1
    .param p1, "receiver"    # Ltas/internal/ipc/server/RemoteReceiver;

    .prologue
    .line 239
    const/16 v0, 0x70

    invoke-virtual {p0, v0, p1}, Ltas/internal/ipc/server/ServerConnection$Connection;->schedule(ILjava/lang/Object;)V

    .line 238
    return-void
.end method

.method private transmit(Ltas/internal/ipc/server/RemoteMessage;)V
    .locals 1
    .param p1, "msg"    # Ltas/internal/ipc/server/RemoteMessage;

    .prologue
    .line 251
    const/16 v0, 0x74

    invoke-virtual {p0, v0, p1}, Ltas/internal/ipc/server/ServerConnection$Connection;->schedule(ILjava/lang/Object;)V

    .line 250
    return-void
.end method

.method private unregisterReceiver(Ltas/internal/ipc/server/RemoteReceiver;)V
    .locals 1
    .param p1, "receiver"    # Ltas/internal/ipc/server/RemoteReceiver;

    .prologue
    .line 199
    const/16 v0, 0x66

    invoke-virtual {p0, v0, p1}, Ltas/internal/ipc/server/ServerConnection$Connection;->schedule(ILjava/lang/Object;)V

    .line 198
    return-void
.end method

.method private unregisterSender(Ltas/internal/ipc/server/RemoteSender;)V
    .locals 1
    .param p1, "sender"    # Ltas/internal/ipc/server/RemoteSender;

    .prologue
    .line 211
    const/16 v0, 0x69

    invoke-virtual {p0, v0, p1}, Ltas/internal/ipc/server/ServerConnection$Connection;->schedule(ILjava/lang/Object;)V

    .line 210
    return-void
.end method

.method private updateReceiver(Ltas/internal/ipc/server/RemoteReceiver;)V
    .locals 1
    .param p1, "receiver"    # Ltas/internal/ipc/server/RemoteReceiver;

    .prologue
    .line 203
    const/16 v0, 0x67

    invoke-virtual {p0, v0, p1}, Ltas/internal/ipc/server/ServerConnection$Connection;->schedule(ILjava/lang/Object;)V

    .line 202
    return-void
.end method

.method private updateSender(Ltas/internal/ipc/server/RemoteSender;)V
    .locals 1
    .param p1, "sender"    # Ltas/internal/ipc/server/RemoteSender;

    .prologue
    .line 215
    const/16 v0, 0x6a

    invoke-virtual {p0, v0, p1}, Ltas/internal/ipc/server/ServerConnection$Connection;->schedule(ILjava/lang/Object;)V

    .line 214
    return-void
.end method


# virtual methods
.method dumpPendingMsg()V
    .locals 2

    .prologue
    .line 462
    const/16 v0, 0x65

    invoke-virtual {p0, v0}, Ltas/internal/ipc/server/ServerConnection$Connection;->hasMsg(I)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 463
    const-string/jumbo v0, "TasIPC<ServerConnection>"

    const-string/jumbo v1, "pending msg --> 101"

    invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 465
    :cond_0
    const/16 v0, 0x66

    invoke-virtual {p0, v0}, Ltas/internal/ipc/server/ServerConnection$Connection;->hasMsg(I)Z

    move-result v0

    if-eqz v0, :cond_1

    .line 466
    const-string/jumbo v0, "TasIPC<ServerConnection>"

    const-string/jumbo v1, "pending msg --> 102"

    invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 468
    :cond_1
    const/16 v0, 0x67

    invoke-virtual {p0, v0}, Ltas/internal/ipc/server/ServerConnection$Connection;->hasMsg(I)Z

    move-result v0

    if-eqz v0, :cond_2

    .line 469
    const-string/jumbo v0, "TasIPC<ServerConnection>"

    const-string/jumbo v1, "pending msg --> 103"

    invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 471
    :cond_2
    const/16 v0, 0x68

    invoke-virtual {p0, v0}, Ltas/internal/ipc/server/ServerConnection$Connection;->hasMsg(I)Z

    move-result v0

    if-eqz v0, :cond_3

    .line 472
    const-string/jumbo v0, "TasIPC<ServerConnection>"

    const-string/jumbo v1, "pending msg --> 104"

    invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 474
    :cond_3
    const/16 v0, 0x69

    invoke-virtual {p0, v0}, Ltas/internal/ipc/server/ServerConnection$Connection;->hasMsg(I)Z

    move-result v0

    if-eqz v0, :cond_4

    .line 475
    const-string/jumbo v0, "TasIPC<ServerConnection>"

    const-string/jumbo v1, "pending msg --> 105"

    invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 477
    :cond_4
    const/16 v0, 0x6a

    invoke-virtual {p0, v0}, Ltas/internal/ipc/server/ServerConnection$Connection;->hasMsg(I)Z

    move-result v0

    if-eqz v0, :cond_5

    .line 478
    const-string/jumbo v0, "TasIPC<ServerConnection>"

    const-string/jumbo v1, "pending msg --> 106"

    invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 480
    :cond_5
    const/16 v0, 0x6b

    invoke-virtual {p0, v0}, Ltas/internal/ipc/server/ServerConnection$Connection;->hasMsg(I)Z

    move-result v0

    if-eqz v0, :cond_6

    .line 481
    const-string/jumbo v0, "TasIPC<ServerConnection>"

    const-string/jumbo v1, "pending msg --> 107"

    invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 483
    :cond_6
    const/16 v0, 0x6c

    invoke-virtual {p0, v0}, Ltas/internal/ipc/server/ServerConnection$Connection;->hasMsg(I)Z

    move-result v0

    if-eqz v0, :cond_7

    .line 484
    const-string/jumbo v0, "TasIPC<ServerConnection>"

    const-string/jumbo v1, "pending msg --> 108"

    invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 486
    :cond_7
    const/16 v0, 0x6d

    invoke-virtual {p0, v0}, Ltas/internal/ipc/server/ServerConnection$Connection;->hasMsg(I)Z

    move-result v0

    if-eqz v0, :cond_8

    .line 487
    const-string/jumbo v0, "TasIPC<ServerConnection>"

    const-string/jumbo v1, "pending msg --> 109"

    invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 489
    :cond_8
    const/16 v0, 0x6e

    invoke-virtual {p0, v0}, Ltas/internal/ipc/server/ServerConnection$Connection;->hasMsg(I)Z

    move-result v0

    if-eqz v0, :cond_9

    .line 490
    const-string/jumbo v0, "TasIPC<ServerConnection>"

    const-string/jumbo v1, "pending msg --> 110"

    invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 492
    :cond_9
    const/16 v0, 0x6f

    invoke-virtual {p0, v0}, Ltas/internal/ipc/server/ServerConnection$Connection;->hasMsg(I)Z

    move-result v0

    if-eqz v0, :cond_a

    .line 493
    const-string/jumbo v0, "TasIPC<ServerConnection>"

    const-string/jumbo v1, "pending msg --> 111"

    invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 495
    :cond_a
    const/16 v0, 0x70

    invoke-virtual {p0, v0}, Ltas/internal/ipc/server/ServerConnection$Connection;->hasMsg(I)Z

    move-result v0

    if-eqz v0, :cond_b

    .line 496
    const-string/jumbo v0, "TasIPC<ServerConnection>"

    const-string/jumbo v1, "pending msg --> 112"

    invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 498
    :cond_b
    const/16 v0, 0x71

    invoke-virtual {p0, v0}, Ltas/internal/ipc/server/ServerConnection$Connection;->hasMsg(I)Z

    move-result v0

    if-eqz v0, :cond_c

    .line 499
    const-string/jumbo v0, "TasIPC<ServerConnection>"

    const-string/jumbo v1, "pending msg --> 113"

    invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 501
    :cond_c
    const/16 v0, 0x72

    invoke-virtual {p0, v0}, Ltas/internal/ipc/server/ServerConnection$Connection;->hasMsg(I)Z

    move-result v0

    if-eqz v0, :cond_d

    .line 502
    const-string/jumbo v0, "TasIPC<ServerConnection>"

    const-string/jumbo v1, "pending msg --> 114"

    invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 504
    :cond_d
    const/16 v0, 0x74

    invoke-virtual {p0, v0}, Ltas/internal/ipc/server/ServerConnection$Connection;->hasMsg(I)Z

    move-result v0

    if-eqz v0, :cond_e

    .line 505
    const-string/jumbo v0, "TasIPC<ServerConnection>"

    const-string/jumbo v1, "pending msg --> 116"

    invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 461
    :cond_e
    return-void
.end method

.method public bridge synthetic handleMessage(Landroid/os/IInterface;Landroid/os/Message;)V
    .locals 0
    .param p1, "remote"    # Landroid/os/IInterface;
    .param p2, "msg"    # Landroid/os/Message;

    .prologue
    .line 285
    check-cast p1, Ltas/internal/ipc/server/IServerService;

    .end local p1    # "remote":Landroid/os/IInterface;
    invoke-virtual {p0, p1, p2}, Ltas/internal/ipc/server/ServerConnection$Connection;->handleMessage(Ltas/internal/ipc/server/IServerService;Landroid/os/Message;)V

    return-void
.end method

.method public handleMessage(Ltas/internal/ipc/server/IServerService;Landroid/os/Message;)V
    .locals 8
    .param p1, "remote"    # Ltas/internal/ipc/server/IServerService;
    .param p2, "msg"    # Landroid/os/Message;

    .prologue
    const/4 v7, 0x0

    .line 286
    iget v4, p2, Landroid/os/Message;->what:I

    const/16 v5, 0x74

    if-eq v4, v5, :cond_0

    .line 287
    const-string/jumbo v4, "TasIPC<ServerConnection>"

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v6, "msg --> "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    iget v6, p2, Landroid/os/Message;->what:I

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-static {v4, v5}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 289
    :cond_0
    iget v4, p2, Landroid/os/Message;->what:I

    packed-switch v4, :pswitch_data_0

    .line 285
    :goto_0
    :pswitch_0
    return-void

    .line 291
    :pswitch_1
    iget-object v1, p2, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v1, Ltas/internal/ipc/server/RemoteReceiver;

    .line 293
    .local v1, "r":Ltas/internal/ipc/server/RemoteReceiver;
    :try_start_0
    invoke-interface {p1, v1}, Ltas/internal/ipc/server/IServerService;->registerReceiver(Ltas/internal/ipc/server/RemoteReceiver;)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 297
    iput-object v7, v1, Ltas/internal/ipc/server/RemoteReceiver;->extra:Landroid/os/Bundle;

    .line 298
    invoke-virtual {v1}, Ltas/internal/ipc/server/RemoteReceiver;->recycle()V

    goto :goto_0

    .line 294
    :catch_0
    move-exception v0

    .line 295
    .local v0, "e":Landroid/os/RemoteException;
    :try_start_1
    const-string/jumbo v4, "TasIPC<ServerConnection>"

    const-string/jumbo v5, "failed to registerReceiver."

    invoke-static {v4, v5, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 297
    iput-object v7, v1, Ltas/internal/ipc/server/RemoteReceiver;->extra:Landroid/os/Bundle;

    .line 298
    invoke-virtual {v1}, Ltas/internal/ipc/server/RemoteReceiver;->recycle()V

    goto :goto_0

    .line 296
    .end local v0    # "e":Landroid/os/RemoteException;
    :catchall_0
    move-exception v4

    .line 297
    iput-object v7, v1, Ltas/internal/ipc/server/RemoteReceiver;->extra:Landroid/os/Bundle;

    .line 298
    invoke-virtual {v1}, Ltas/internal/ipc/server/RemoteReceiver;->recycle()V

    .line 296
    throw v4

    .line 303
    .end local v1    # "r":Ltas/internal/ipc/server/RemoteReceiver;
    :pswitch_2
    iget-object v1, p2, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v1, Ltas/internal/ipc/server/RemoteReceiver;

    .line 305
    .restart local v1    # "r":Ltas/internal/ipc/server/RemoteReceiver;
    :try_start_2
    invoke-interface {p1, v1}, Ltas/internal/ipc/server/IServerService;->unregisterReceiver(Ltas/internal/ipc/server/RemoteReceiver;)V
    :try_end_2
    .catch Landroid/os/RemoteException; {:try_start_2 .. :try_end_2} :catch_1
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .line 309
    invoke-virtual {v1}, Ltas/internal/ipc/server/RemoteReceiver;->recycle()V

    goto :goto_0

    .line 306
    :catch_1
    move-exception v0

    .line 307
    .restart local v0    # "e":Landroid/os/RemoteException;
    :try_start_3
    const-string/jumbo v4, "TasIPC<ServerConnection>"

    const-string/jumbo v5, "failed to unregisterReceiver."

    invoke-static {v4, v5, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    .line 309
    invoke-virtual {v1}, Ltas/internal/ipc/server/RemoteReceiver;->recycle()V

    goto :goto_0

    .line 308
    .end local v0    # "e":Landroid/os/RemoteException;
    :catchall_1
    move-exception v4

    .line 309
    invoke-virtual {v1}, Ltas/internal/ipc/server/RemoteReceiver;->recycle()V

    .line 308
    throw v4

    .line 314
    .end local v1    # "r":Ltas/internal/ipc/server/RemoteReceiver;
    :pswitch_3
    iget-object v1, p2, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v1, Ltas/internal/ipc/server/RemoteReceiver;

    .line 316
    .restart local v1    # "r":Ltas/internal/ipc/server/RemoteReceiver;
    :try_start_4
    invoke-interface {p1, v1}, Ltas/internal/ipc/server/IServerService;->updateReceiver(Ltas/internal/ipc/server/RemoteReceiver;)V
    :try_end_4
    .catch Landroid/os/RemoteException; {:try_start_4 .. :try_end_4} :catch_2
    .catchall {:try_start_4 .. :try_end_4} :catchall_2

    .line 320
    iput-object v7, v1, Ltas/internal/ipc/server/RemoteReceiver;->extra:Landroid/os/Bundle;

    .line 321
    invoke-virtual {v1}, Ltas/internal/ipc/server/RemoteReceiver;->recycle()V

    goto :goto_0

    .line 317
    :catch_2
    move-exception v0

    .line 318
    .restart local v0    # "e":Landroid/os/RemoteException;
    :try_start_5
    const-string/jumbo v4, "TasIPC<ServerConnection>"

    const-string/jumbo v5, "failed to updateReceiver."

    invoke-static {v4, v5, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_2

    .line 320
    iput-object v7, v1, Ltas/internal/ipc/server/RemoteReceiver;->extra:Landroid/os/Bundle;

    .line 321
    invoke-virtual {v1}, Ltas/internal/ipc/server/RemoteReceiver;->recycle()V

    goto :goto_0

    .line 319
    .end local v0    # "e":Landroid/os/RemoteException;
    :catchall_2
    move-exception v4

    .line 320
    iput-object v7, v1, Ltas/internal/ipc/server/RemoteReceiver;->extra:Landroid/os/Bundle;

    .line 321
    invoke-virtual {v1}, Ltas/internal/ipc/server/RemoteReceiver;->recycle()V

    .line 319
    throw v4

    .line 326
    .end local v1    # "r":Ltas/internal/ipc/server/RemoteReceiver;
    :pswitch_4
    iget-object v3, p2, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v3, Ltas/internal/ipc/server/RemoteSender;

    .line 328
    .local v3, "s":Ltas/internal/ipc/server/RemoteSender;
    :try_start_6
    invoke-interface {p1, v3}, Ltas/internal/ipc/server/IServerService;->registerSender(Ltas/internal/ipc/server/RemoteSender;)V
    :try_end_6
    .catch Landroid/os/RemoteException; {:try_start_6 .. :try_end_6} :catch_3
    .catchall {:try_start_6 .. :try_end_6} :catchall_3

    .line 332
    iput-object v7, v3, Ltas/internal/ipc/server/RemoteSender;->extra:Landroid/os/Bundle;

    .line 333
    invoke-virtual {v3}, Ltas/internal/ipc/server/RemoteSender;->recycle()V

    goto :goto_0

    .line 329
    :catch_3
    move-exception v0

    .line 330
    .restart local v0    # "e":Landroid/os/RemoteException;
    :try_start_7
    const-string/jumbo v4, "TasIPC<ServerConnection>"

    const-string/jumbo v5, "failed to registerSender."

    invoke-static {v4, v5, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_3

    .line 332
    iput-object v7, v3, Ltas/internal/ipc/server/RemoteSender;->extra:Landroid/os/Bundle;

    .line 333
    invoke-virtual {v3}, Ltas/internal/ipc/server/RemoteSender;->recycle()V

    goto/16 :goto_0

    .line 331
    .end local v0    # "e":Landroid/os/RemoteException;
    :catchall_3
    move-exception v4

    .line 332
    iput-object v7, v3, Ltas/internal/ipc/server/RemoteSender;->extra:Landroid/os/Bundle;

    .line 333
    invoke-virtual {v3}, Ltas/internal/ipc/server/RemoteSender;->recycle()V

    .line 331
    throw v4

    .line 338
    .end local v3    # "s":Ltas/internal/ipc/server/RemoteSender;
    :pswitch_5
    iget-object v3, p2, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v3, Ltas/internal/ipc/server/RemoteSender;

    .line 340
    .restart local v3    # "s":Ltas/internal/ipc/server/RemoteSender;
    :try_start_8
    invoke-interface {p1, v3}, Ltas/internal/ipc/server/IServerService;->unregisterSender(Ltas/internal/ipc/server/RemoteSender;)V
    :try_end_8
    .catch Landroid/os/RemoteException; {:try_start_8 .. :try_end_8} :catch_4
    .catchall {:try_start_8 .. :try_end_8} :catchall_4

    .line 344
    invoke-virtual {v3}, Ltas/internal/ipc/server/RemoteSender;->recycle()V

    goto/16 :goto_0

    .line 341
    :catch_4
    move-exception v0

    .line 342
    .restart local v0    # "e":Landroid/os/RemoteException;
    :try_start_9
    const-string/jumbo v4, "TasIPC<ServerConnection>"

    const-string/jumbo v5, "failed to unregisterSender."

    invoke-static {v4, v5, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_4

    .line 344
    invoke-virtual {v3}, Ltas/internal/ipc/server/RemoteSender;->recycle()V

    goto/16 :goto_0

    .line 343
    .end local v0    # "e":Landroid/os/RemoteException;
    :catchall_4
    move-exception v4

    .line 344
    invoke-virtual {v3}, Ltas/internal/ipc/server/RemoteSender;->recycle()V

    .line 343
    throw v4

    .line 349
    .end local v3    # "s":Ltas/internal/ipc/server/RemoteSender;
    :pswitch_6
    iget-object v3, p2, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v3, Ltas/internal/ipc/server/RemoteSender;

    .line 351
    .restart local v3    # "s":Ltas/internal/ipc/server/RemoteSender;
    :try_start_a
    invoke-interface {p1, v3}, Ltas/internal/ipc/server/IServerService;->updateSender(Ltas/internal/ipc/server/RemoteSender;)V
    :try_end_a
    .catch Landroid/os/RemoteException; {:try_start_a .. :try_end_a} :catch_5
    .catchall {:try_start_a .. :try_end_a} :catchall_5

    .line 355
    iput-object v7, v3, Ltas/internal/ipc/server/RemoteSender;->extra:Landroid/os/Bundle;

    .line 356
    invoke-virtual {v3}, Ltas/internal/ipc/server/RemoteSender;->recycle()V

    goto/16 :goto_0

    .line 352
    :catch_5
    move-exception v0

    .line 353
    .restart local v0    # "e":Landroid/os/RemoteException;
    :try_start_b
    const-string/jumbo v4, "TasIPC<ServerConnection>"

    const-string/jumbo v5, "failed to updateSender."

    invoke-static {v4, v5, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    :try_end_b
    .catchall {:try_start_b .. :try_end_b} :catchall_5

    .line 355
    iput-object v7, v3, Ltas/internal/ipc/server/RemoteSender;->extra:Landroid/os/Bundle;

    .line 356
    invoke-virtual {v3}, Ltas/internal/ipc/server/RemoteSender;->recycle()V

    goto/16 :goto_0

    .line 354
    .end local v0    # "e":Landroid/os/RemoteException;
    :catchall_5
    move-exception v4

    .line 355
    iput-object v7, v3, Ltas/internal/ipc/server/RemoteSender;->extra:Landroid/os/Bundle;

    .line 356
    invoke-virtual {v3}, Ltas/internal/ipc/server/RemoteSender;->recycle()V

    .line 354
    throw v4

    .line 361
    .end local v3    # "s":Ltas/internal/ipc/server/RemoteSender;
    :pswitch_7
    iget-object v3, p2, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v3, Ltas/internal/ipc/server/RemoteSender;

    .line 363
    .restart local v3    # "s":Ltas/internal/ipc/server/RemoteSender;
    :try_start_c
    invoke-interface {p1, v3}, Ltas/internal/ipc/server/IServerService;->watchReceiver(Ltas/internal/ipc/server/RemoteSender;)V
    :try_end_c
    .catch Landroid/os/RemoteException; {:try_start_c .. :try_end_c} :catch_6
    .catchall {:try_start_c .. :try_end_c} :catchall_6

    .line 367
    invoke-virtual {v3}, Ltas/internal/ipc/server/RemoteSender;->recycle()V

    goto/16 :goto_0

    .line 364
    :catch_6
    move-exception v0

    .line 365
    .restart local v0    # "e":Landroid/os/RemoteException;
    :try_start_d
    const-string/jumbo v4, "TasIPC<ServerConnection>"

    const-string/jumbo v5, "failed to watchReceiver."

    invoke-static {v4, v5, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    :try_end_d
    .catchall {:try_start_d .. :try_end_d} :catchall_6

    .line 367
    invoke-virtual {v3}, Ltas/internal/ipc/server/RemoteSender;->recycle()V

    goto/16 :goto_0

    .line 366
    .end local v0    # "e":Landroid/os/RemoteException;
    :catchall_6
    move-exception v4

    .line 367
    invoke-virtual {v3}, Ltas/internal/ipc/server/RemoteSender;->recycle()V

    .line 366
    throw v4

    .line 372
    .end local v3    # "s":Ltas/internal/ipc/server/RemoteSender;
    :pswitch_8
    iget-object v3, p2, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v3, Ltas/internal/ipc/server/RemoteSender;

    .line 374
    .restart local v3    # "s":Ltas/internal/ipc/server/RemoteSender;
    :try_start_e
    invoke-interface {p1, v3}, Ltas/internal/ipc/server/IServerService;->unwatchReceiver(Ltas/internal/ipc/server/RemoteSender;)V
    :try_end_e
    .catch Landroid/os/RemoteException; {:try_start_e .. :try_end_e} :catch_7
    .catchall {:try_start_e .. :try_end_e} :catchall_7

    .line 378
    invoke-virtual {v3}, Ltas/internal/ipc/server/RemoteSender;->recycle()V

    goto/16 :goto_0

    .line 375
    :catch_7
    move-exception v0

    .line 376
    .restart local v0    # "e":Landroid/os/RemoteException;
    :try_start_f
    const-string/jumbo v4, "TasIPC<ServerConnection>"

    const-string/jumbo v5, "failed to unwatchReceiver."

    invoke-static {v4, v5, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    :try_end_f
    .catchall {:try_start_f .. :try_end_f} :catchall_7

    .line 378
    invoke-virtual {v3}, Ltas/internal/ipc/server/RemoteSender;->recycle()V

    goto/16 :goto_0

    .line 377
    .end local v0    # "e":Landroid/os/RemoteException;
    :catchall_7
    move-exception v4

    .line 378
    invoke-virtual {v3}, Ltas/internal/ipc/server/RemoteSender;->recycle()V

    .line 377
    throw v4

    .line 383
    .end local v3    # "s":Ltas/internal/ipc/server/RemoteSender;
    :pswitch_9
    iget-object v3, p2, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v3, Ltas/internal/ipc/server/RemoteSender;

    .line 385
    .restart local v3    # "s":Ltas/internal/ipc/server/RemoteSender;
    :try_start_10
    invoke-interface {p1, v3}, Ltas/internal/ipc/server/IServerService;->watchAnonymousReceiver(Ltas/internal/ipc/server/RemoteSender;)V
    :try_end_10
    .catch Landroid/os/RemoteException; {:try_start_10 .. :try_end_10} :catch_8
    .catchall {:try_start_10 .. :try_end_10} :catchall_8

    .line 389
    invoke-virtual {v3}, Ltas/internal/ipc/server/RemoteSender;->recycle()V

    goto/16 :goto_0

    .line 386
    :catch_8
    move-exception v0

    .line 387
    .restart local v0    # "e":Landroid/os/RemoteException;
    :try_start_11
    const-string/jumbo v4, "TasIPC<ServerConnection>"

    const-string/jumbo v5, "failed to watchAnonymousReceiver."

    invoke-static {v4, v5, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    :try_end_11
    .catchall {:try_start_11 .. :try_end_11} :catchall_8

    .line 389
    invoke-virtual {v3}, Ltas/internal/ipc/server/RemoteSender;->recycle()V

    goto/16 :goto_0

    .line 388
    .end local v0    # "e":Landroid/os/RemoteException;
    :catchall_8
    move-exception v4

    .line 389
    invoke-virtual {v3}, Ltas/internal/ipc/server/RemoteSender;->recycle()V

    .line 388
    throw v4

    .line 394
    .end local v3    # "s":Ltas/internal/ipc/server/RemoteSender;
    :pswitch_a
    iget-object v3, p2, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v3, Ltas/internal/ipc/server/RemoteSender;

    .line 396
    .restart local v3    # "s":Ltas/internal/ipc/server/RemoteSender;
    :try_start_12
    invoke-interface {p1, v3}, Ltas/internal/ipc/server/IServerService;->unwatchAnonymousReceiver(Ltas/internal/ipc/server/RemoteSender;)V
    :try_end_12
    .catch Landroid/os/RemoteException; {:try_start_12 .. :try_end_12} :catch_9
    .catchall {:try_start_12 .. :try_end_12} :catchall_9

    .line 400
    invoke-virtual {v3}, Ltas/internal/ipc/server/RemoteSender;->recycle()V

    goto/16 :goto_0

    .line 397
    :catch_9
    move-exception v0

    .line 398
    .restart local v0    # "e":Landroid/os/RemoteException;
    :try_start_13
    const-string/jumbo v4, "TasIPC<ServerConnection>"

    const-string/jumbo v5, "failed to unwatchAnonymousReceiver."

    invoke-static {v4, v5, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    :try_end_13
    .catchall {:try_start_13 .. :try_end_13} :catchall_9

    .line 400
    invoke-virtual {v3}, Ltas/internal/ipc/server/RemoteSender;->recycle()V

    goto/16 :goto_0

    .line 399
    .end local v0    # "e":Landroid/os/RemoteException;
    :catchall_9
    move-exception v4

    .line 400
    invoke-virtual {v3}, Ltas/internal/ipc/server/RemoteSender;->recycle()V

    .line 399
    throw v4

    .line 405
    .end local v3    # "s":Ltas/internal/ipc/server/RemoteSender;
    :pswitch_b
    iget-object v1, p2, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v1, Ltas/internal/ipc/server/RemoteReceiver;

    .line 407
    .restart local v1    # "r":Ltas/internal/ipc/server/RemoteReceiver;
    :try_start_14
    invoke-interface {p1, v1}, Ltas/internal/ipc/server/IServerService;->watchSender(Ltas/internal/ipc/server/RemoteReceiver;)V
    :try_end_14
    .catch Landroid/os/RemoteException; {:try_start_14 .. :try_end_14} :catch_a
    .catchall {:try_start_14 .. :try_end_14} :catchall_a

    .line 411
    invoke-virtual {v1}, Ltas/internal/ipc/server/RemoteReceiver;->recycle()V

    goto/16 :goto_0

    .line 408
    :catch_a
    move-exception v0

    .line 409
    .restart local v0    # "e":Landroid/os/RemoteException;
    :try_start_15
    const-string/jumbo v4, "TasIPC<ServerConnection>"

    const-string/jumbo v5, "failed to watchSender."

    invoke-static {v4, v5, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    :try_end_15
    .catchall {:try_start_15 .. :try_end_15} :catchall_a

    .line 411
    invoke-virtual {v1}, Ltas/internal/ipc/server/RemoteReceiver;->recycle()V

    goto/16 :goto_0

    .line 410
    .end local v0    # "e":Landroid/os/RemoteException;
    :catchall_a
    move-exception v4

    .line 411
    invoke-virtual {v1}, Ltas/internal/ipc/server/RemoteReceiver;->recycle()V

    .line 410
    throw v4

    .line 416
    .end local v1    # "r":Ltas/internal/ipc/server/RemoteReceiver;
    :pswitch_c
    iget-object v1, p2, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v1, Ltas/internal/ipc/server/RemoteReceiver;

    .line 418
    .restart local v1    # "r":Ltas/internal/ipc/server/RemoteReceiver;
    :try_start_16
    invoke-interface {p1, v1}, Ltas/internal/ipc/server/IServerService;->unwatchSender(Ltas/internal/ipc/server/RemoteReceiver;)V
    :try_end_16
    .catch Landroid/os/RemoteException; {:try_start_16 .. :try_end_16} :catch_b
    .catchall {:try_start_16 .. :try_end_16} :catchall_b

    .line 422
    invoke-virtual {v1}, Ltas/internal/ipc/server/RemoteReceiver;->recycle()V

    goto/16 :goto_0

    .line 419
    :catch_b
    move-exception v0

    .line 420
    .restart local v0    # "e":Landroid/os/RemoteException;
    :try_start_17
    const-string/jumbo v4, "TasIPC<ServerConnection>"

    const-string/jumbo v5, "failed to unwatchSender."

    invoke-static {v4, v5, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    :try_end_17
    .catchall {:try_start_17 .. :try_end_17} :catchall_b

    .line 422
    invoke-virtual {v1}, Ltas/internal/ipc/server/RemoteReceiver;->recycle()V

    goto/16 :goto_0

    .line 421
    .end local v0    # "e":Landroid/os/RemoteException;
    :catchall_b
    move-exception v4

    .line 422
    invoke-virtual {v1}, Ltas/internal/ipc/server/RemoteReceiver;->recycle()V

    .line 421
    throw v4

    .line 427
    .end local v1    # "r":Ltas/internal/ipc/server/RemoteReceiver;
    :pswitch_d
    iget-object v1, p2, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v1, Ltas/internal/ipc/server/RemoteReceiver;

    .line 429
    .restart local v1    # "r":Ltas/internal/ipc/server/RemoteReceiver;
    :try_start_18
    invoke-interface {p1, v1}, Ltas/internal/ipc/server/IServerService;->watchAnonymousSender(Ltas/internal/ipc/server/RemoteReceiver;)V
    :try_end_18
    .catch Landroid/os/RemoteException; {:try_start_18 .. :try_end_18} :catch_c
    .catchall {:try_start_18 .. :try_end_18} :catchall_c

    .line 433
    invoke-virtual {v1}, Ltas/internal/ipc/server/RemoteReceiver;->recycle()V

    goto/16 :goto_0

    .line 430
    :catch_c
    move-exception v0

    .line 431
    .restart local v0    # "e":Landroid/os/RemoteException;
    :try_start_19
    const-string/jumbo v4, "TasIPC<ServerConnection>"

    const-string/jumbo v5, "failed to watchAnonymousSender."

    invoke-static {v4, v5, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    :try_end_19
    .catchall {:try_start_19 .. :try_end_19} :catchall_c

    .line 433
    invoke-virtual {v1}, Ltas/internal/ipc/server/RemoteReceiver;->recycle()V

    goto/16 :goto_0

    .line 432
    .end local v0    # "e":Landroid/os/RemoteException;
    :catchall_c
    move-exception v4

    .line 433
    invoke-virtual {v1}, Ltas/internal/ipc/server/RemoteReceiver;->recycle()V

    .line 432
    throw v4

    .line 438
    .end local v1    # "r":Ltas/internal/ipc/server/RemoteReceiver;
    :pswitch_e
    iget-object v1, p2, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v1, Ltas/internal/ipc/server/RemoteReceiver;

    .line 440
    .restart local v1    # "r":Ltas/internal/ipc/server/RemoteReceiver;
    :try_start_1a
    invoke-interface {p1, v1}, Ltas/internal/ipc/server/IServerService;->unwatchAnonymousSender(Ltas/internal/ipc/server/RemoteReceiver;)V
    :try_end_1a
    .catch Landroid/os/RemoteException; {:try_start_1a .. :try_end_1a} :catch_d
    .catchall {:try_start_1a .. :try_end_1a} :catchall_d

    .line 444
    invoke-virtual {v1}, Ltas/internal/ipc/server/RemoteReceiver;->recycle()V

    goto/16 :goto_0

    .line 441
    :catch_d
    move-exception v0

    .line 442
    .restart local v0    # "e":Landroid/os/RemoteException;
    :try_start_1b
    const-string/jumbo v4, "TasIPC<ServerConnection>"

    const-string/jumbo v5, "failed to unwatchAnonymousSender."

    invoke-static {v4, v5, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    :try_end_1b
    .catchall {:try_start_1b .. :try_end_1b} :catchall_d

    .line 444
    invoke-virtual {v1}, Ltas/internal/ipc/server/RemoteReceiver;->recycle()V

    goto/16 :goto_0

    .line 443
    .end local v0    # "e":Landroid/os/RemoteException;
    :catchall_d
    move-exception v4

    .line 444
    invoke-virtual {v1}, Ltas/internal/ipc/server/RemoteReceiver;->recycle()V

    .line 443
    throw v4

    .line 449
    .end local v1    # "r":Ltas/internal/ipc/server/RemoteReceiver;
    :pswitch_f
    iget-object v2, p2, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v2, Ltas/internal/ipc/server/RemoteMessage;

    .line 451
    .local v2, "remoteMessage":Ltas/internal/ipc/server/RemoteMessage;
    :try_start_1c
    invoke-interface {p1, v2}, Ltas/internal/ipc/server/IServerService;->transmit(Ltas/internal/ipc/server/RemoteMessage;)V
    :try_end_1c
    .catch Landroid/os/RemoteException; {:try_start_1c .. :try_end_1c} :catch_e
    .catchall {:try_start_1c .. :try_end_1c} :catchall_e

    .line 455
    invoke-virtual {v2}, Ltas/internal/ipc/server/RemoteMessage;->recycle()V

    goto/16 :goto_0

    .line 452
    :catch_e
    move-exception v0

    .line 453
    .restart local v0    # "e":Landroid/os/RemoteException;
    :try_start_1d
    const-string/jumbo v4, "TasIPC<ServerConnection>"

    const-string/jumbo v5, "failed to transmit."

    invoke-static {v4, v5, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    :try_end_1d
    .catchall {:try_start_1d .. :try_end_1d} :catchall_e

    .line 455
    invoke-virtual {v2}, Ltas/internal/ipc/server/RemoteMessage;->recycle()V

    goto/16 :goto_0

    .line 454
    .end local v0    # "e":Landroid/os/RemoteException;
    :catchall_e
    move-exception v4

    .line 455
    invoke-virtual {v2}, Ltas/internal/ipc/server/RemoteMessage;->recycle()V

    .line 454
    throw v4

    .line 289
    :pswitch_data_0
    .packed-switch 0x65
        :pswitch_1
        :pswitch_2
        :pswitch_3
        :pswitch_4
        :pswitch_5
        :pswitch_6
        :pswitch_7
        :pswitch_8
        :pswitch_9
        :pswitch_a
        :pswitch_b
        :pswitch_c
        :pswitch_d
        :pswitch_e
        :pswitch_0
        :pswitch_f
    .end packed-switch
.end method

.method public bridge synthetic onConnected(Landroid/os/IBinder;)Landroid/os/IInterface;
    .locals 1
    .param p1, "binder"    # Landroid/os/IBinder;

    .prologue
    .line 272
    invoke-virtual {p0, p1}, Ltas/internal/ipc/server/ServerConnection$Connection;->onConnected(Landroid/os/IBinder;)Ltas/internal/ipc/server/IServerService;

    move-result-object v0

    return-object v0
.end method

.method public onConnected(Landroid/os/IBinder;)Ltas/internal/ipc/server/IServerService;
    .locals 4
    .param p1, "binder"    # Landroid/os/IBinder;

    .prologue
    .line 273
    invoke-static {p1}, Ltas/internal/ipc/server/IServerService$Stub;->asInterface(Landroid/os/IBinder;)Ltas/internal/ipc/server/IServerService;

    move-result-object v1

    .line 275
    .local v1, "server":Ltas/internal/ipc/server/IServerService;
    :try_start_0
    iget-object v2, p0, Ltas/internal/ipc/server/ServerConnection$Connection;->mCallback:Ltas/internal/ipc/server/ServerConnection$ServerCallback;

    invoke-interface {v1, v2}, Ltas/internal/ipc/server/IServerService;->setCallback(Ltas/internal/ipc/server/IServerCallback;)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    .line 280
    invoke-virtual {p0}, Ltas/internal/ipc/server/ServerConnection$Connection;->dumpPendingMsg()V

    .line 281
    return-object v1

    .line 276
    :catch_0
    move-exception v0

    .line 277
    .local v0, "e":Landroid/os/RemoteException;
    const-string/jumbo v2, "TasIPC<ServerConnection>"

    const-string/jumbo v3, "failed to setCallback."

    invoke-static {v2, v3, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 278
    const/4 v2, 0x0

    return-object v2
.end method
