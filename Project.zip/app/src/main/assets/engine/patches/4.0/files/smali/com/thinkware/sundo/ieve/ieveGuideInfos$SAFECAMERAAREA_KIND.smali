.class public final enum Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERAAREA_KIND;
.super Ljava/lang/Enum;
.source "ieveGuideInfos.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/thinkware/sundo/ieve/ieveGuideInfos;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "SAFECAMERAAREA_KIND"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum",
        "<",
        "Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERAAREA_KIND;",
        ">;"
    }
.end annotation


# static fields
.field public static final enum NONE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERAAREA_KIND;

.field public static final enum SAFEAREA_END_CAMERA:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERAAREA_KIND;

.field public static final enum SAFEAREA_START_CAMERA:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERAAREA_KIND;

.field private static final synthetic b:[Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERAAREA_KIND;


# instance fields
.field private final a:I


# direct methods
.method static constructor <clinit>()V
    .locals 6

    .prologue
    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v3, 0x0

    .line 141
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERAAREA_KIND;

    const-string v1, "NONE"

    invoke-direct {v0, v1, v3, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERAAREA_KIND;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERAAREA_KIND;->NONE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERAAREA_KIND;

    .line 142
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERAAREA_KIND;

    const-string v1, "SAFEAREA_START_CAMERA"

    const/16 v2, 0xb

    invoke-direct {v0, v1, v4, v2}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERAAREA_KIND;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERAAREA_KIND;->SAFEAREA_START_CAMERA:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERAAREA_KIND;

    .line 143
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERAAREA_KIND;

    const-string v1, "SAFEAREA_END_CAMERA"

    const/16 v2, 0xc

    invoke-direct {v0, v1, v5, v2}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERAAREA_KIND;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERAAREA_KIND;->SAFEAREA_END_CAMERA:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERAAREA_KIND;

    .line 140
    const/4 v0, 0x3

    new-array v0, v0, [Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERAAREA_KIND;

    sget-object v1, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERAAREA_KIND;->NONE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERAAREA_KIND;

    aput-object v1, v0, v3

    sget-object v1, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERAAREA_KIND;->SAFEAREA_START_CAMERA:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERAAREA_KIND;

    aput-object v1, v0, v4

    sget-object v1, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERAAREA_KIND;->SAFEAREA_END_CAMERA:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERAAREA_KIND;

    aput-object v1, v0, v5

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERAAREA_KIND;->b:[Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERAAREA_KIND;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .locals 0
    .param p3, "value"    # I

    .prologue
    .line 145
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    iput p3, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERAAREA_KIND;->a:I

    return-void
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERAAREA_KIND;
    .locals 1

    .prologue
    .line 1
    const-class v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERAAREA_KIND;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object v0

    check-cast v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERAAREA_KIND;

    return-object v0
.end method

.method public static values()[Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERAAREA_KIND;
    .locals 4

    .prologue
    const/4 v3, 0x0

    .line 1
    sget-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERAAREA_KIND;->b:[Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERAAREA_KIND;

    array-length v1, v0

    new-array v2, v1, [Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERAAREA_KIND;

    invoke-static {v0, v3, v2, v3, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    return-object v2
.end method


# virtual methods
.method public getValue()I
    .locals 1

    .prologue
    .line 147
    iget v0, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFECAMERAAREA_KIND;->a:I

    return v0
.end method
