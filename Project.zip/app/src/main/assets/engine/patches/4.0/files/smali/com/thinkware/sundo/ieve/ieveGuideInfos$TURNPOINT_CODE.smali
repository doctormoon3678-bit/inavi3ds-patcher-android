.class public final enum Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;
.super Ljava/lang/Enum;
.source "ieveGuideInfos.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/thinkware/sundo/ieve/ieveGuideInfos;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "TURNPOINT_CODE"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum",
        "<",
        "Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;",
        ">;"
    }
.end annotation


# static fields
.field public static final enum GCODE_END_ST1:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

.field public static final enum GCODE_END_ST2:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

.field public static final enum GCODE_END_ST3:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

.field public static final enum GCODE_END_ST4:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

.field public static final enum GCODE_LEFTWAY:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

.field public static final enum GCODE_LEFTWAY_HIGHWAY_ENT:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

.field public static final enum GCODE_LEFTWAY_HIGHWAY_EXIT:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

.field public static final enum GCODE_LEFTWAY_OVERROAD:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

.field public static final enum GCODE_LEFTWAY_OVERROAD_SIDE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

.field public static final enum GCODE_LEFTWAY_UNDERROAD:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

.field public static final enum GCODE_LEFTWAY_UNDERROAD_SIDE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

.field public static final enum GCODE_LEFT_TURN:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

.field public static final enum GCODE_NONE_0:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

.field public static final enum GCODE_NONE_1:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

.field public static final enum GCODE_NONE_3:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

.field public static final enum GCODE_NONE_4:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

.field public static final enum GCODE_NONE_5:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

.field public static final enum GCODE_NONE_6:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

.field public static final enum GCODE_NONE_7:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

.field public static final enum GCODE_NONE_8:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

.field public static final enum GCODE_PTURN:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

.field public static final enum GCODE_REST:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

.field public static final enum GCODE_RETURN_ROUTE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

.field public static final enum GCODE_RIGHTWAY:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

.field public static final enum GCODE_RIGHTWAY_HIGHWAY_ENT:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

.field public static final enum GCODE_RIGHTWAY_HIGHWAY_EXIT:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

.field public static final enum GCODE_RIGHTWAY_OVERROAD:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

.field public static final enum GCODE_RIGHTWAY_OVERROAD_SIDE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

.field public static final enum GCODE_RIGHTWAY_UNDERROAD:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

.field public static final enum GCODE_RIGHTWAY_UNDERROAD_SIDE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

.field public static final enum GCODE_RIGHT_TURN:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

.field public static final enum GCODE_ROTARY_1:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

.field public static final enum GCODE_ROTARY_10:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

.field public static final enum GCODE_ROTARY_11:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

.field public static final enum GCODE_ROTARY_12:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

.field public static final enum GCODE_ROTARY_2:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

.field public static final enum GCODE_ROTARY_3:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

.field public static final enum GCODE_ROTARY_4:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

.field public static final enum GCODE_ROTARY_5:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

.field public static final enum GCODE_ROTARY_6:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

.field public static final enum GCODE_ROTARY_7:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

.field public static final enum GCODE_ROTARY_8:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

.field public static final enum GCODE_ROTARY_9:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

.field public static final enum GCODE_STRAGHTWAY:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

.field public static final enum GCODE_STRAGHTWAY_HIGHWAY_ENT:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

.field public static final enum GCODE_STRAGHTWAY_OVERROAD_SIDE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

.field public static final enum GCODE_STRAIGHTWAY_HIGHWAY_EXIT:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

.field public static final enum GCODE_STRAIGHTWAY_NEXTGUIDE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

.field public static final enum GCODE_STRAIGHTWAY_OVERROAD:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

.field public static final enum GCODE_STRAIGHTWAY_UNDERROAD:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

.field public static final enum GCODE_STRAIGHTWAY_UNDERROAD_SIDE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

.field public static final enum GCODE_TIME10WAY:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

.field public static final enum GCODE_TIME11WAY:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

.field public static final enum GCODE_TIME12WAY:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

.field public static final enum GCODE_TIME1WAY:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

.field public static final enum GCODE_TIME2WAY:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

.field public static final enum GCODE_TIME3WAY:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

.field public static final enum GCODE_TIME4WAY:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

.field public static final enum GCODE_TIME5WAY:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

.field public static final enum GCODE_TIME6WAY:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

.field public static final enum GCODE_TIME7WAY:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

.field public static final enum GCODE_TIME8WAY:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

.field public static final enum GCODE_TIME9WAY:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

.field public static final enum GCODE_TOLLGATE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

.field public static final enum GCODE_TUNNEL:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

.field public static final enum GCODE_UTURN:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

.field public static final enum GCODE_VIA:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

.field private static final synthetic b:[Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;


# instance fields
.field private final a:I


# direct methods
.method static constructor <clinit>()V
    .locals 9

    .prologue
    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v4, 0x0

    .line 33
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    const-string v1, "GCODE_NONE_0"

    invoke-direct {v0, v1, v4, v4}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_NONE_0:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    .line 34
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    const-string v1, "GCODE_NONE_1"

    invoke-direct {v0, v1, v5, v5}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_NONE_1:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    .line 35
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    const-string v1, "GCODE_RETURN_ROUTE"

    invoke-direct {v0, v1, v6, v6}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_RETURN_ROUTE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    .line 36
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    const-string v1, "GCODE_STRAIGHTWAY_HIGHWAY_EXIT"

    invoke-direct {v0, v1, v7, v7}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_STRAIGHTWAY_HIGHWAY_EXIT:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    .line 37
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    const-string v1, "GCODE_LEFTWAY_HIGHWAY_EXIT"

    invoke-direct {v0, v1, v8, v8}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_LEFTWAY_HIGHWAY_EXIT:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    .line 38
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    const-string v1, "GCODE_RIGHTWAY_HIGHWAY_EXIT"

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_RIGHTWAY_HIGHWAY_EXIT:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    .line 39
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    const-string v1, "GCODE_REST"

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_REST:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    .line 40
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    const-string v1, "GCODE_LEFTWAY"

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_LEFTWAY:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    .line 41
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    const-string v1, "GCODE_RIGHTWAY"

    const/16 v2, 0x8

    const/16 v3, 0x8

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_RIGHTWAY:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    .line 42
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    const-string v1, "GCODE_STRAGHTWAY_HIGHWAY_ENT"

    const/16 v2, 0x9

    const/16 v3, 0x9

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_STRAGHTWAY_HIGHWAY_ENT:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    .line 43
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    const-string v1, "GCODE_LEFTWAY_HIGHWAY_ENT"

    const/16 v2, 0xa

    const/16 v3, 0xa

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_LEFTWAY_HIGHWAY_ENT:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    .line 44
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    const-string v1, "GCODE_RIGHTWAY_HIGHWAY_ENT"

    const/16 v2, 0xb

    const/16 v3, 0xb

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_RIGHTWAY_HIGHWAY_ENT:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    .line 45
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    const-string v1, "GCODE_LEFT_TURN"

    const/16 v2, 0xc

    const/16 v3, 0xc

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_LEFT_TURN:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    .line 46
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    const-string v1, "GCODE_RIGHT_TURN"

    const/16 v2, 0xd

    const/16 v3, 0xd

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_RIGHT_TURN:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    .line 47
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    const-string v1, "GCODE_UTURN"

    const/16 v2, 0xe

    const/16 v3, 0xe

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_UTURN:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    .line 48
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    const-string v1, "GCODE_STRAGHTWAY"

    const/16 v2, 0xf

    const/16 v3, 0xf

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_STRAGHTWAY:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    .line 49
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    const-string v1, "GCODE_TIME12WAY"

    const/16 v2, 0x10

    const/16 v3, 0x10

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_TIME12WAY:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    .line 50
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    const-string v1, "GCODE_TIME1WAY"

    const/16 v2, 0x11

    const/16 v3, 0x11

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_TIME1WAY:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    .line 51
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    const-string v1, "GCODE_TIME2WAY"

    const/16 v2, 0x12

    const/16 v3, 0x12

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_TIME2WAY:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    .line 52
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    const-string v1, "GCODE_TIME3WAY"

    const/16 v2, 0x13

    const/16 v3, 0x13

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_TIME3WAY:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    .line 53
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    const-string v1, "GCODE_TIME4WAY"

    const/16 v2, 0x14

    const/16 v3, 0x14

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_TIME4WAY:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    .line 54
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    const-string v1, "GCODE_TIME5WAY"

    const/16 v2, 0x15

    const/16 v3, 0x15

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_TIME5WAY:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    .line 55
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    const-string v1, "GCODE_TIME6WAY"

    const/16 v2, 0x16

    const/16 v3, 0x16

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_TIME6WAY:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    .line 56
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    const-string v1, "GCODE_TIME7WAY"

    const/16 v2, 0x17

    const/16 v3, 0x17

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_TIME7WAY:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    .line 57
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    const-string v1, "GCODE_TIME8WAY"

    const/16 v2, 0x18

    const/16 v3, 0x18

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_TIME8WAY:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    .line 58
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    const-string v1, "GCODE_TIME9WAY"

    const/16 v2, 0x19

    const/16 v3, 0x19

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_TIME9WAY:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    .line 59
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    const-string v1, "GCODE_TIME10WAY"

    const/16 v2, 0x1a

    const/16 v3, 0x1a

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_TIME10WAY:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    .line 60
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    const-string v1, "GCODE_TIME11WAY"

    const/16 v2, 0x1b

    const/16 v3, 0x1b

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_TIME11WAY:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    .line 61
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    const-string v1, "GCODE_STRAIGHTWAY_OVERROAD"

    const/16 v2, 0x1c

    const/16 v3, 0x1c

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_STRAIGHTWAY_OVERROAD:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    .line 62
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    const-string v1, "GCODE_LEFTWAY_OVERROAD"

    const/16 v2, 0x1d

    const/16 v3, 0x1d

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_LEFTWAY_OVERROAD:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    .line 63
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    const-string v1, "GCODE_RIGHTWAY_OVERROAD"

    const/16 v2, 0x1e

    const/16 v3, 0x1e

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_RIGHTWAY_OVERROAD:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    .line 64
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    const-string v1, "GCODE_STRAGHTWAY_OVERROAD_SIDE"

    const/16 v2, 0x1f

    const/16 v3, 0x1f

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_STRAGHTWAY_OVERROAD_SIDE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    .line 65
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    const-string v1, "GCODE_LEFTWAY_OVERROAD_SIDE"

    const/16 v2, 0x20

    const/16 v3, 0x20

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_LEFTWAY_OVERROAD_SIDE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    .line 66
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    const-string v1, "GCODE_RIGHTWAY_OVERROAD_SIDE"

    const/16 v2, 0x21

    const/16 v3, 0x21

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_RIGHTWAY_OVERROAD_SIDE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    .line 67
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    const-string v1, "GCODE_STRAIGHTWAY_UNDERROAD"

    const/16 v2, 0x22

    const/16 v3, 0x22

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_STRAIGHTWAY_UNDERROAD:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    .line 68
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    const-string v1, "GCODE_LEFTWAY_UNDERROAD"

    const/16 v2, 0x23

    const/16 v3, 0x23

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_LEFTWAY_UNDERROAD:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    .line 69
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    const-string v1, "GCODE_RIGHTWAY_UNDERROAD"

    const/16 v2, 0x24

    const/16 v3, 0x24

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_RIGHTWAY_UNDERROAD:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    .line 70
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    const-string v1, "GCODE_STRAIGHTWAY_UNDERROAD_SIDE"

    const/16 v2, 0x25

    const/16 v3, 0x25

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_STRAIGHTWAY_UNDERROAD_SIDE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    .line 71
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    const-string v1, "GCODE_LEFTWAY_UNDERROAD_SIDE"

    const/16 v2, 0x26

    const/16 v3, 0x26

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_LEFTWAY_UNDERROAD_SIDE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    .line 72
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    const-string v1, "GCODE_RIGHTWAY_UNDERROAD_SIDE"

    const/16 v2, 0x27

    const/16 v3, 0x27

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_RIGHTWAY_UNDERROAD_SIDE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    .line 73
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    const-string v1, "GCODE_PTURN"

    const/16 v2, 0x28

    const/16 v3, 0x28

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_PTURN:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    .line 74
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    const-string v1, "GCODE_NONE_3"

    const/16 v2, 0x29

    const/16 v3, 0x29

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_NONE_3:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    .line 75
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    const-string v1, "GCODE_TUNNEL"

    const/16 v2, 0x2a

    const/16 v3, 0x2a

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_TUNNEL:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    .line 76
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    const-string v1, "GCODE_TOLLGATE"

    const/16 v2, 0x2b

    const/16 v3, 0x2b

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_TOLLGATE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    .line 77
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    const-string v1, "GCODE_NONE_4"

    const/16 v2, 0x2c

    const/16 v3, 0x2c

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_NONE_4:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    .line 78
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    const-string v1, "GCODE_NONE_5"

    const/16 v2, 0x2d

    const/16 v3, 0x2d

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_NONE_5:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    .line 79
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    const-string v1, "GCODE_ROTARY_1"

    const/16 v2, 0x2e

    const/16 v3, 0x2e

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_ROTARY_1:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    .line 80
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    const-string v1, "GCODE_ROTARY_2"

    const/16 v2, 0x2f

    const/16 v3, 0x2f

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_ROTARY_2:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    .line 81
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    const-string v1, "GCODE_ROTARY_3"

    const/16 v2, 0x30

    const/16 v3, 0x30

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_ROTARY_3:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    .line 82
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    const-string v1, "GCODE_ROTARY_4"

    const/16 v2, 0x31

    const/16 v3, 0x31

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_ROTARY_4:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    .line 83
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    const-string v1, "GCODE_ROTARY_5"

    const/16 v2, 0x32

    const/16 v3, 0x32

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_ROTARY_5:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    .line 84
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    const-string v1, "GCODE_ROTARY_6"

    const/16 v2, 0x33

    const/16 v3, 0x33

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_ROTARY_6:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    .line 85
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    const-string v1, "GCODE_ROTARY_7"

    const/16 v2, 0x34

    const/16 v3, 0x34

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_ROTARY_7:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    .line 86
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    const-string v1, "GCODE_ROTARY_8"

    const/16 v2, 0x35

    const/16 v3, 0x35

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_ROTARY_8:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    .line 87
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    const-string v1, "GCODE_ROTARY_9"

    const/16 v2, 0x36

    const/16 v3, 0x36

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_ROTARY_9:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    .line 88
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    const-string v1, "GCODE_ROTARY_10"

    const/16 v2, 0x37

    const/16 v3, 0x37

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_ROTARY_10:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    .line 89
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    const-string v1, "GCODE_ROTARY_11"

    const/16 v2, 0x38

    const/16 v3, 0x38

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_ROTARY_11:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    .line 90
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    const-string v1, "GCODE_ROTARY_12"

    const/16 v2, 0x39

    const/16 v3, 0x39

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_ROTARY_12:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    .line 91
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    const-string v1, "GCODE_STRAIGHTWAY_NEXTGUIDE"

    const/16 v2, 0x3a

    const/16 v3, 0x3a

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_STRAIGHTWAY_NEXTGUIDE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    .line 92
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    const-string v1, "GCODE_VIA"

    const/16 v2, 0x3b

    const/16 v3, 0x3b

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_VIA:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    .line 93
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    const-string v1, "GCODE_END_ST1"

    const/16 v2, 0x3c

    const/16 v3, 0x3c

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_END_ST1:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    .line 94
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    const-string v1, "GCODE_END_ST2"

    const/16 v2, 0x3d

    const/16 v3, 0x3d

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_END_ST2:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    .line 95
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    const-string v1, "GCODE_END_ST3"

    const/16 v2, 0x3e

    const/16 v3, 0x3e

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_END_ST3:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    .line 96
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    const-string v1, "GCODE_END_ST4"

    const/16 v2, 0x3f

    const/16 v3, 0x3f

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_END_ST4:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    .line 97
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    const-string v1, "GCODE_NONE_6"

    const/16 v2, 0x40

    const/16 v3, 0x40

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_NONE_6:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    .line 98
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    const-string v1, "GCODE_NONE_7"

    const/16 v2, 0x41

    const/16 v3, 0x41

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_NONE_7:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    .line 99
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    const-string v1, "GCODE_NONE_8"

    const/16 v2, 0x42

    const/16 v3, 0x42

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_NONE_8:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    .line 32
    const/16 v0, 0x43

    new-array v0, v0, [Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    sget-object v1, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_NONE_0:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    aput-object v1, v0, v4

    sget-object v1, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_NONE_1:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    aput-object v1, v0, v5

    sget-object v1, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_RETURN_ROUTE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    aput-object v1, v0, v6

    sget-object v1, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_STRAIGHTWAY_HIGHWAY_EXIT:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    aput-object v1, v0, v7

    sget-object v1, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_LEFTWAY_HIGHWAY_EXIT:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    aput-object v1, v0, v8

    const/4 v1, 0x5

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_RIGHTWAY_HIGHWAY_EXIT:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    aput-object v2, v0, v1

    const/4 v1, 0x6

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_REST:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    aput-object v2, v0, v1

    const/4 v1, 0x7

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_LEFTWAY:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    aput-object v2, v0, v1

    const/16 v1, 0x8

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_RIGHTWAY:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    aput-object v2, v0, v1

    const/16 v1, 0x9

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_STRAGHTWAY_HIGHWAY_ENT:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    aput-object v2, v0, v1

    const/16 v1, 0xa

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_LEFTWAY_HIGHWAY_ENT:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    aput-object v2, v0, v1

    const/16 v1, 0xb

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_RIGHTWAY_HIGHWAY_ENT:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    aput-object v2, v0, v1

    const/16 v1, 0xc

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_LEFT_TURN:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    aput-object v2, v0, v1

    const/16 v1, 0xd

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_RIGHT_TURN:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    aput-object v2, v0, v1

    const/16 v1, 0xe

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_UTURN:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    aput-object v2, v0, v1

    const/16 v1, 0xf

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_STRAGHTWAY:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    aput-object v2, v0, v1

    const/16 v1, 0x10

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_TIME12WAY:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    aput-object v2, v0, v1

    const/16 v1, 0x11

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_TIME1WAY:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    aput-object v2, v0, v1

    const/16 v1, 0x12

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_TIME2WAY:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    aput-object v2, v0, v1

    const/16 v1, 0x13

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_TIME3WAY:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    aput-object v2, v0, v1

    const/16 v1, 0x14

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_TIME4WAY:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    aput-object v2, v0, v1

    const/16 v1, 0x15

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_TIME5WAY:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    aput-object v2, v0, v1

    const/16 v1, 0x16

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_TIME6WAY:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    aput-object v2, v0, v1

    const/16 v1, 0x17

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_TIME7WAY:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    aput-object v2, v0, v1

    const/16 v1, 0x18

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_TIME8WAY:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    aput-object v2, v0, v1

    const/16 v1, 0x19

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_TIME9WAY:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    aput-object v2, v0, v1

    const/16 v1, 0x1a

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_TIME10WAY:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    aput-object v2, v0, v1

    const/16 v1, 0x1b

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_TIME11WAY:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    aput-object v2, v0, v1

    const/16 v1, 0x1c

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_STRAIGHTWAY_OVERROAD:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    aput-object v2, v0, v1

    const/16 v1, 0x1d

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_LEFTWAY_OVERROAD:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    aput-object v2, v0, v1

    const/16 v1, 0x1e

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_RIGHTWAY_OVERROAD:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    aput-object v2, v0, v1

    const/16 v1, 0x1f

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_STRAGHTWAY_OVERROAD_SIDE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    aput-object v2, v0, v1

    const/16 v1, 0x20

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_LEFTWAY_OVERROAD_SIDE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    aput-object v2, v0, v1

    const/16 v1, 0x21

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_RIGHTWAY_OVERROAD_SIDE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    aput-object v2, v0, v1

    const/16 v1, 0x22

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_STRAIGHTWAY_UNDERROAD:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    aput-object v2, v0, v1

    const/16 v1, 0x23

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_LEFTWAY_UNDERROAD:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    aput-object v2, v0, v1

    const/16 v1, 0x24

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_RIGHTWAY_UNDERROAD:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    aput-object v2, v0, v1

    const/16 v1, 0x25

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_STRAIGHTWAY_UNDERROAD_SIDE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    aput-object v2, v0, v1

    const/16 v1, 0x26

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_LEFTWAY_UNDERROAD_SIDE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    aput-object v2, v0, v1

    const/16 v1, 0x27

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_RIGHTWAY_UNDERROAD_SIDE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    aput-object v2, v0, v1

    const/16 v1, 0x28

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_PTURN:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    aput-object v2, v0, v1

    const/16 v1, 0x29

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_NONE_3:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    aput-object v2, v0, v1

    const/16 v1, 0x2a

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_TUNNEL:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    aput-object v2, v0, v1

    const/16 v1, 0x2b

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_TOLLGATE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    aput-object v2, v0, v1

    const/16 v1, 0x2c

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_NONE_4:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    aput-object v2, v0, v1

    const/16 v1, 0x2d

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_NONE_5:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    aput-object v2, v0, v1

    const/16 v1, 0x2e

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_ROTARY_1:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    aput-object v2, v0, v1

    const/16 v1, 0x2f

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_ROTARY_2:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    aput-object v2, v0, v1

    const/16 v1, 0x30

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_ROTARY_3:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    aput-object v2, v0, v1

    const/16 v1, 0x31

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_ROTARY_4:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    aput-object v2, v0, v1

    const/16 v1, 0x32

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_ROTARY_5:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    aput-object v2, v0, v1

    const/16 v1, 0x33

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_ROTARY_6:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    aput-object v2, v0, v1

    const/16 v1, 0x34

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_ROTARY_7:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    aput-object v2, v0, v1

    const/16 v1, 0x35

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_ROTARY_8:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    aput-object v2, v0, v1

    const/16 v1, 0x36

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_ROTARY_9:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    aput-object v2, v0, v1

    const/16 v1, 0x37

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_ROTARY_10:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    aput-object v2, v0, v1

    const/16 v1, 0x38

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_ROTARY_11:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    aput-object v2, v0, v1

    const/16 v1, 0x39

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_ROTARY_12:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    aput-object v2, v0, v1

    const/16 v1, 0x3a

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_STRAIGHTWAY_NEXTGUIDE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    aput-object v2, v0, v1

    const/16 v1, 0x3b

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_VIA:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    aput-object v2, v0, v1

    const/16 v1, 0x3c

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_END_ST1:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    aput-object v2, v0, v1

    const/16 v1, 0x3d

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_END_ST2:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    aput-object v2, v0, v1

    const/16 v1, 0x3e

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_END_ST3:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    aput-object v2, v0, v1

    const/16 v1, 0x3f

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_END_ST4:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    aput-object v2, v0, v1

    const/16 v1, 0x40

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_NONE_6:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    aput-object v2, v0, v1

    const/16 v1, 0x41

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_NONE_7:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    aput-object v2, v0, v1

    const/16 v1, 0x42

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->GCODE_NONE_8:Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    aput-object v2, v0, v1

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->b:[Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .locals 0
    .param p3, "value"    # I

    .prologue
    .line 101
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    iput p3, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->a:I

    return-void
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;
    .locals 1

    .prologue
    .line 1
    const-class v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object v0

    check-cast v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    return-object v0
.end method

.method public static values()[Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;
    .locals 4

    .prologue
    const/4 v3, 0x0

    .line 1
    sget-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->b:[Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    array-length v1, v0

    new-array v2, v1, [Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;

    invoke-static {v0, v3, v2, v3, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    return-object v2
.end method


# virtual methods
.method public getValue()I
    .locals 1

    .prologue
    .line 103
    iget v0, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$TURNPOINT_CODE;->a:I

    return v0
.end method
