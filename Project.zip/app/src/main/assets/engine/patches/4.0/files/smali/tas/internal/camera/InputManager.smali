.class public Ltas/internal/camera/InputManager;
.super Ljava/lang/Object;
.source "InputManager.java"

# interfaces
.implements Ltas/internal/camera/util/CameraMonitor$Callback;


# static fields
.field private static final DBG:Z = true

.field private static final TAG:Ljava/lang/String; = "TasCAM<InputManager>"


# instance fields
.field private final mChs:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List",
            "<",
            "Ltas/internal/camera/InputChannel;",
            ">;"
        }
    .end annotation
.end field

.field private mContext:Landroid/content/Context;

.field private mMonitor:Ltas/internal/camera/util/CameraMonitor;

.field private mServer:Ltas/internal/camera/server/ServerOutGoing;


# direct methods
.method public constructor <init>(Ltas/internal/camera/server/ServerOutGoing;)V
    .locals 2
    .param p1, "_server"    # Ltas/internal/camera/server/ServerOutGoing;

    .prologue
    .line 27
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 25
    new-instance v0, Ljava/util/ArrayList;

    const/4 v1, 0x2

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    iput-object v0, p0, Ltas/internal/camera/InputManager;->mChs:Ljava/util/List;

    .line 28
    iput-object p1, p0, Ltas/internal/camera/InputManager;->mServer:Ltas/internal/camera/server/ServerOutGoing;

    .line 29
    invoke-virtual {p1}, Ltas/internal/camera/server/ServerOutGoing;->getContext()Landroid/content/Context;

    move-result-object v0

    iput-object v0, p0, Ltas/internal/camera/InputManager;->mContext:Landroid/content/Context;

    .line 30
    new-instance v0, Ltas/internal/camera/util/CameraMonitor;

    iget-object v1, p0, Ltas/internal/camera/InputManager;->mContext:Landroid/content/Context;

    invoke-direct {v0, v1, p0}, Ltas/internal/camera/util/CameraMonitor;-><init>(Landroid/content/Context;Ltas/internal/camera/util/CameraMonitor$Callback;)V

    iput-object v0, p0, Ltas/internal/camera/InputManager;->mMonitor:Ltas/internal/camera/util/CameraMonitor;

    .line 31
    iget-object v0, p0, Ltas/internal/camera/InputManager;->mMonitor:Ltas/internal/camera/util/CameraMonitor;

    invoke-virtual {v0}, Ltas/internal/camera/util/CameraMonitor;->connect()V

    .line 27
    return-void
.end method


# virtual methods
.method public addInput(Ltas/internal/camera/InputSource;)V
    .locals 5
    .param p1, "input"    # Ltas/internal/camera/InputSource;

    .prologue
    .line 35
    invoke-virtual {p0, p1}, Ltas/internal/camera/InputManager;->hasInput(Ltas/internal/camera/InputSource;)Z

    move-result v1

    if-eqz v1, :cond_0

    .line 36
    return-void

    .line 38
    :cond_0
    new-instance v0, Ltas/internal/camera/Dispatcher;

    iget-object v1, p0, Ltas/internal/camera/InputManager;->mServer:Ltas/internal/camera/server/ServerOutGoing;

    invoke-direct {v0, v1}, Ltas/internal/camera/Dispatcher;-><init>(Ltas/internal/camera/server/ServerOutGoing;)V

    .line 39
    .local v0, "dispatcher":Ltas/internal/camera/Dispatcher;
    iget-object v1, p0, Ltas/internal/camera/InputManager;->mChs:Ljava/util/List;

    new-instance v2, Ltas/internal/camera/InputChannel;

    iget-object v3, p0, Ltas/internal/camera/InputManager;->mChs:Ljava/util/List;

    invoke-interface {v3}, Ljava/util/List;->size()I

    move-result v3

    iget-object v4, p0, Ltas/internal/camera/InputManager;->mMonitor:Ltas/internal/camera/util/CameraMonitor;

    invoke-direct {v2, v3, p1, v0, v4}, Ltas/internal/camera/InputChannel;-><init>(ILtas/internal/camera/InputSource;Ltas/internal/camera/Dispatcher;Ltas/internal/camera/util/CameraMonitor;)V

    invoke-interface {v1, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 34
    return-void
.end method

.method public cancel(Ljava/lang/String;Ltas/internal/camera/InputParams;)V
    .locals 4
    .param p1, "proc"    # Ljava/lang/String;
    .param p2, "params"    # Ltas/internal/camera/InputParams;

    .prologue
    .line 160
    const/4 v2, -0x1

    .line 161
    .local v2, "result":I
    iget-object v3, p0, Ltas/internal/camera/InputManager;->mChs:Ljava/util/List;

    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    .local v1, "ch$iterator":Ljava/util/Iterator;
    :cond_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_1

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/camera/InputChannel;

    .line 162
    .local v0, "ch":Ltas/internal/camera/InputChannel;
    invoke-virtual {v0, p1, p2}, Ltas/internal/camera/InputChannel;->cancel(Ljava/lang/String;Ltas/internal/camera/InputParams;)I

    move-result v2

    .line 163
    if-eqz v2, :cond_1

    .line 164
    const/4 v3, -0x8

    if-ne v2, v3, :cond_2

    .line 159
    .end local v0    # "ch":Ltas/internal/camera/InputChannel;
    :cond_1
    :goto_0
    return-void

    .line 165
    .restart local v0    # "ch":Ltas/internal/camera/InputChannel;
    :cond_2
    const/16 v3, -0xd

    if-eq v2, v3, :cond_1

    .line 166
    const/16 v3, -0xe

    if-ne v2, v3, :cond_0

    goto :goto_0
.end method

.method public command(Ljava/lang/String;Ltas/internal/camera/InputParams;)I
    .locals 4
    .param p1, "proc"    # Ljava/lang/String;
    .param p2, "params"    # Ltas/internal/camera/InputParams;

    .prologue
    .line 173
    const/4 v2, -0x1

    .line 174
    .local v2, "result":I
    iget-object v3, p0, Ltas/internal/camera/InputManager;->mChs:Ljava/util/List;

    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    .local v1, "ch$iterator":Ljava/util/Iterator;
    :cond_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_1

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/camera/InputChannel;

    .line 175
    .local v0, "ch":Ltas/internal/camera/InputChannel;
    invoke-virtual {v0, p1, p2}, Ltas/internal/camera/InputChannel;->command(Ljava/lang/String;Ltas/internal/camera/InputParams;)I

    move-result v2

    .line 176
    const/4 v3, -0x5

    if-eq v2, v3, :cond_0

    .line 180
    .end local v0    # "ch":Ltas/internal/camera/InputChannel;
    :cond_1
    return v2
.end method

.method public findInput(Ljava/lang/String;)Ltas/internal/camera/InputSource;
    .locals 5
    .param p1, "camcls"    # Ljava/lang/String;

    .prologue
    const/4 v4, 0x0

    .line 134
    const/4 v2, 0x0

    .line 135
    .local v2, "input":Ltas/internal/camera/InputSourceInner;
    iget-object v3, p0, Ltas/internal/camera/InputManager;->mChs:Ljava/util/List;

    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    .end local v2    # "input":Ltas/internal/camera/InputSourceInner;
    .local v1, "ch$iterator":Ljava/util/Iterator;
    :cond_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_1

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/camera/InputChannel;

    .line 136
    .local v0, "ch":Ltas/internal/camera/InputChannel;
    invoke-virtual {v0, p1}, Ltas/internal/camera/InputChannel;->findInput(Ljava/lang/String;)Ltas/internal/camera/InputSourceInner;

    move-result-object v2

    .line 137
    .local v2, "input":Ltas/internal/camera/InputSourceInner;
    if-eqz v2, :cond_0

    .line 138
    iget-object v3, v2, Ltas/internal/camera/InputSourceInner;->hook:Ltas/internal/camera/InputSource$Hook;

    iget-object v3, v3, Ltas/internal/camera/InputSource$Hook;->input:Ltas/internal/camera/InputSource;

    return-object v3

    .line 141
    .end local v0    # "ch":Ltas/internal/camera/InputChannel;
    .end local v2    # "input":Ltas/internal/camera/InputSourceInner;
    :cond_1
    return-object v4
.end method

.method public hasInput(Ltas/internal/camera/InputSource;)Z
    .locals 4
    .param p1, "input"    # Ltas/internal/camera/InputSource;

    .prologue
    .line 43
    iget-object v2, p0, Ltas/internal/camera/InputManager;->mChs:Ljava/util/List;

    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    .local v1, "ch$iterator":Ljava/util/Iterator;
    :cond_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/camera/InputChannel;

    .line 44
    .local v0, "ch":Ltas/internal/camera/InputChannel;
    invoke-virtual {v0}, Ltas/internal/camera/InputChannel;->getRootInput()Ltas/internal/camera/InputSourceInner;

    move-result-object v2

    iget-object v3, p1, Ltas/internal/camera/InputSource;->hook:Ltas/internal/camera/InputSource$Hook;

    iget-object v3, v3, Ltas/internal/camera/InputSource$Hook;->impl:Ltas/internal/camera/InputSourceInner;

    if-ne v2, v3, :cond_0

    .line 45
    const/4 v2, 0x1

    return v2

    .line 48
    .end local v0    # "ch":Ltas/internal/camera/InputChannel;
    :cond_1
    const/4 v2, 0x0

    return v2
.end method

.method public onCameraOpen(Ltas/internal/camera/util/CameraMonitor;I)V
    .locals 6
    .param p1, "monitor"    # Ltas/internal/camera/util/CameraMonitor;
    .param p2, "camid"    # I

    .prologue
    .line 97
    const-string/jumbo v3, "TasCAM<InputManager>"

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v5, "camera open: camid="

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v3, v4}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 98
    iget-object v3, p0, Ltas/internal/camera/InputManager;->mChs:Ljava/util/List;

    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    .local v1, "ch$iterator":Ljava/util/Iterator;
    :cond_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_1

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/camera/InputChannel;

    .line 99
    .local v0, "ch":Ltas/internal/camera/InputChannel;
    invoke-virtual {v0}, Ltas/internal/camera/InputChannel;->getCurrInput()Ltas/internal/camera/InputSourceInner;

    move-result-object v2

    .line 100
    .local v2, "input":Ltas/internal/camera/InputSourceInner;
    if-eqz v2, :cond_0

    invoke-virtual {v2, p2}, Ltas/internal/camera/InputSourceInner;->isCamid(I)Z

    move-result v3

    if-eqz v3, :cond_0

    .line 101
    invoke-virtual {v0}, Ltas/internal/camera/InputChannel;->onCameraOpen()V

    .line 102
    return-void

    .line 105
    .end local v0    # "ch":Ltas/internal/camera/InputChannel;
    .end local v2    # "input":Ltas/internal/camera/InputSourceInner;
    :cond_1
    const-string/jumbo v3, "TasCAM<InputManager>"

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v5, "a unknown user is making use of the camera("

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v4

    .line 106
    const-string/jumbo v5, "). "

    .line 105
    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v3, v4}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 107
    invoke-static {p2}, Ltas/internal/camera/InputChannel;->addUnknownOpenedCamid(I)V

    .line 109
    iget-object v3, p0, Ltas/internal/camera/InputManager;->mChs:Ljava/util/List;

    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_2

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/camera/InputChannel;

    .line 110
    .restart local v0    # "ch":Ltas/internal/camera/InputChannel;
    invoke-virtual {v0, p2}, Ltas/internal/camera/InputChannel;->reportUnknownCameraOpened(I)V

    goto :goto_0

    .line 96
    .end local v0    # "ch":Ltas/internal/camera/InputChannel;
    :cond_2
    return-void
.end method

.method public onCameraRelease(Ltas/internal/camera/util/CameraMonitor;I)V
    .locals 6
    .param p1, "monitor"    # Ltas/internal/camera/util/CameraMonitor;
    .param p2, "camid"    # I

    .prologue
    .line 116
    const-string/jumbo v3, "TasCAM<InputManager>"

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v5, "camera release: camid="

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v3, v4}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 117
    iget-object v3, p0, Ltas/internal/camera/InputManager;->mChs:Ljava/util/List;

    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    .local v1, "ch$iterator":Ljava/util/Iterator;
    :cond_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_1

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/camera/InputChannel;

    .line 118
    .local v0, "ch":Ltas/internal/camera/InputChannel;
    invoke-virtual {v0}, Ltas/internal/camera/InputChannel;->getCurrInput()Ltas/internal/camera/InputSourceInner;

    move-result-object v2

    .line 119
    .local v2, "input":Ltas/internal/camera/InputSourceInner;
    if-eqz v2, :cond_0

    invoke-virtual {v2, p2}, Ltas/internal/camera/InputSourceInner;->isCamid(I)Z

    move-result v3

    if-eqz v3, :cond_0

    .line 120
    invoke-virtual {v0}, Ltas/internal/camera/InputChannel;->onCameraRelease()V

    .line 121
    return-void

    .line 124
    .end local v0    # "ch":Ltas/internal/camera/InputChannel;
    .end local v2    # "input":Ltas/internal/camera/InputSourceInner;
    :cond_1
    const-string/jumbo v3, "TasCAM<InputManager>"

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v5, "a unknown user has released the camera("

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v4

    .line 125
    const-string/jumbo v5, "). "

    .line 124
    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v3, v4}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 126
    invoke-static {p2}, Ltas/internal/camera/InputChannel;->removeUnknownOpenedCamid(I)V

    .line 128
    iget-object v3, p0, Ltas/internal/camera/InputManager;->mChs:Ljava/util/List;

    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_2

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/camera/InputChannel;

    .line 129
    .restart local v0    # "ch":Ltas/internal/camera/InputChannel;
    invoke-virtual {v0, p2}, Ltas/internal/camera/InputChannel;->reportUnknownCameraReleased(I)V

    goto :goto_0

    .line 115
    .end local v0    # "ch":Ltas/internal/camera/InputChannel;
    :cond_2
    return-void
.end method

.method public onMonitorBinderDied(Ltas/internal/camera/util/CameraMonitor;)V
    .locals 4
    .param p1, "monitor"    # Ltas/internal/camera/util/CameraMonitor;

    .prologue
    .line 83
    const-string/jumbo v2, "TasCAM<InputManager>"

    const-string/jumbo v3, "monitor binderdied"

    invoke-static {v2, v3}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 84
    iget-object v2, p0, Ltas/internal/camera/InputManager;->mChs:Ljava/util/List;

    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    .local v1, "ch$iterator":Ljava/util/Iterator;
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_0

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/camera/InputChannel;

    .line 85
    .local v0, "ch":Ltas/internal/camera/InputChannel;
    invoke-virtual {v0}, Ltas/internal/camera/InputChannel;->onMediaServerDied()V

    goto :goto_0

    .line 87
    .end local v0    # "ch":Ltas/internal/camera/InputChannel;
    :cond_0
    const/4 v2, 0x1

    const/16 v3, 0x5dc

    invoke-virtual {p1, v2, v3}, Ltas/internal/camera/util/CameraMonitor;->reconnect(ZI)V

    .line 82
    return-void
.end method

.method public onMonitorConnected(Ltas/internal/camera/util/CameraMonitor;)V
    .locals 2
    .param p1, "monitor"    # Ltas/internal/camera/util/CameraMonitor;

    .prologue
    .line 65
    const-string/jumbo v0, "TasCAM<InputManager>"

    const-string/jumbo v1, "monitor connected"

    invoke-static {v0, v1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 64
    return-void
.end method

.method public onMonitorDisconnected(Ltas/internal/camera/util/CameraMonitor;)V
    .locals 2
    .param p1, "monitor"    # Ltas/internal/camera/util/CameraMonitor;

    .prologue
    .line 70
    const-string/jumbo v0, "TasCAM<InputManager>"

    const-string/jumbo v1, "monitor disconnected"

    invoke-static {v0, v1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 69
    return-void
.end method

.method public onMonitorError(Ltas/internal/camera/util/CameraMonitor;II)V
    .locals 3
    .param p1, "monitor"    # Ltas/internal/camera/util/CameraMonitor;
    .param p2, "what"    # I
    .param p3, "err"    # I

    .prologue
    .line 92
    const-string/jumbo v0, "TasCAM<InputManager>"

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "monitor error. what="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string/jumbo v2, ", err="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 91
    return-void
.end method

.method public onMonitorReconnected(Ltas/internal/camera/util/CameraMonitor;)V
    .locals 4
    .param p1, "monitor"    # Ltas/internal/camera/util/CameraMonitor;

    .prologue
    .line 75
    const-string/jumbo v2, "TasCAM<InputManager>"

    const-string/jumbo v3, "monitor reconnected"

    invoke-static {v2, v3}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 76
    iget-object v2, p0, Ltas/internal/camera/InputManager;->mChs:Ljava/util/List;

    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    .local v1, "ch$iterator":Ljava/util/Iterator;
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_0

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/camera/InputChannel;

    .line 77
    .local v0, "ch":Ltas/internal/camera/InputChannel;
    invoke-virtual {v0}, Ltas/internal/camera/InputChannel;->onMediaServerRevived()V

    goto :goto_0

    .line 74
    .end local v0    # "ch":Ltas/internal/camera/InputChannel;
    :cond_0
    return-void
.end method

.method public onSystemMasterClear(Ljava/lang/String;)V
    .locals 3
    .param p1, "reason"    # Ljava/lang/String;

    .prologue
    .line 58
    iget-object v2, p0, Ltas/internal/camera/InputManager;->mChs:Ljava/util/List;

    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    .local v1, "ch$iterator":Ljava/util/Iterator;
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_0

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/camera/InputChannel;

    .line 59
    .local v0, "ch":Ltas/internal/camera/InputChannel;
    invoke-virtual {v0, p1}, Ltas/internal/camera/InputChannel;->onSystemMasterClear(Ljava/lang/String;)V

    goto :goto_0

    .line 57
    .end local v0    # "ch":Ltas/internal/camera/InputChannel;
    :cond_0
    return-void
.end method

.method public onSystemShutdown()V
    .locals 3

    .prologue
    .line 52
    iget-object v2, p0, Ltas/internal/camera/InputManager;->mChs:Ljava/util/List;

    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    .local v1, "ch$iterator":Ljava/util/Iterator;
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_0

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/camera/InputChannel;

    .line 53
    .local v0, "ch":Ltas/internal/camera/InputChannel;
    invoke-virtual {v0}, Ltas/internal/camera/InputChannel;->onSystemShutdown()V

    goto :goto_0

    .line 51
    .end local v0    # "ch":Ltas/internal/camera/InputChannel;
    :cond_0
    return-void
.end method

.method public request(Ljava/lang/String;Ltas/internal/camera/InputParams;)I
    .locals 4
    .param p1, "proc"    # Ljava/lang/String;
    .param p2, "params"    # Ltas/internal/camera/InputParams;

    .prologue
    .line 145
    const/4 v2, -0x1

    .line 146
    .local v2, "result":I
    iget-object v3, p0, Ltas/internal/camera/InputManager;->mChs:Ljava/util/List;

    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    .local v1, "ch$iterator":Ljava/util/Iterator;
    :cond_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_1

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/camera/InputChannel;

    .line 147
    .local v0, "ch":Ltas/internal/camera/InputChannel;
    invoke-virtual {v0, p1, p2}, Ltas/internal/camera/InputChannel;->request(Ljava/lang/String;Ltas/internal/camera/InputParams;)I

    move-result v2

    .line 148
    if-eqz v2, :cond_1

    .line 149
    const/4 v3, -0x4

    if-ne v2, v3, :cond_2

    .line 156
    .end local v0    # "ch":Ltas/internal/camera/InputChannel;
    :cond_1
    :goto_0
    return v2

    .line 150
    .restart local v0    # "ch":Ltas/internal/camera/InputChannel;
    :cond_2
    const/4 v3, -0x3

    if-eq v2, v3, :cond_1

    .line 151
    const/4 v3, -0x7

    if-eq v2, v3, :cond_1

    .line 152
    const/4 v3, -0x6

    if-ne v2, v3, :cond_0

    goto :goto_0
.end method
