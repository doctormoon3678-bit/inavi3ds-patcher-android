.class public Ltas/internal/ipc/server/RemoteReceiver;
.super Ltas/internal/ipc/server/RemoteClient;
.source "RemoteReceiver.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ltas/internal/ipc/server/RemoteReceiver$1;,
        Ltas/internal/ipc/server/RemoteReceiver$2;
    }
.end annotation


# static fields
.field private static final CALLBACK:Ltas/internal/ipc/util/SyncdPool$Callback;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ltas/internal/ipc/util/SyncdPool$Callback",
            "<",
            "Ltas/internal/ipc/server/RemoteReceiver;",
            ">;"
        }
    .end annotation
.end field

.field public static final CREATOR:Landroid/os/Parcelable$Creator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/os/Parcelable$Creator",
            "<",
            "Ltas/internal/ipc/server/RemoteReceiver;",
            ">;"
        }
    .end annotation
.end field

.field private static final sPool:Ltas/internal/ipc/util/SyncdPool;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ltas/internal/ipc/util/SyncdPool",
            "<",
            "Ltas/internal/ipc/server/RemoteReceiver;",
            ">;"
        }
    .end annotation
.end field

.field private static sPoolId:I


# instance fields
.field private mAllocated:Z

.field private mPooled:Z

.field private next:Ltas/internal/ipc/server/RemoteReceiver;

.field public p2pMode:Z

.field private pool:I


# direct methods
.method static synthetic -get0(Ltas/internal/ipc/server/RemoteReceiver;)Ltas/internal/ipc/server/RemoteReceiver;
    .locals 1

    iget-object v0, p0, Ltas/internal/ipc/server/RemoteReceiver;->next:Ltas/internal/ipc/server/RemoteReceiver;

    return-object v0
.end method

.method static synthetic -get1()I
    .locals 1

    sget v0, Ltas/internal/ipc/server/RemoteReceiver;->sPoolId:I

    return v0
.end method

.method static synthetic -set0(Ltas/internal/ipc/server/RemoteReceiver;Z)Z
    .locals 0

    iput-boolean p1, p0, Ltas/internal/ipc/server/RemoteReceiver;->mPooled:Z

    return p1
.end method

.method static synthetic -set1(Ltas/internal/ipc/server/RemoteReceiver;Ltas/internal/ipc/server/RemoteReceiver;)Ltas/internal/ipc/server/RemoteReceiver;
    .locals 0

    iput-object p1, p0, Ltas/internal/ipc/server/RemoteReceiver;->next:Ltas/internal/ipc/server/RemoteReceiver;

    return-object p1
.end method

.method static synthetic -set2(Ltas/internal/ipc/server/RemoteReceiver;I)I
    .locals 0

    iput p1, p0, Ltas/internal/ipc/server/RemoteReceiver;->pool:I

    return p1
.end method

.method static synthetic -set3(I)I
    .locals 0

    sput p0, Ltas/internal/ipc/server/RemoteReceiver;->sPoolId:I

    return p0
.end method

.method static constructor <clinit>()V
    .locals 2

    .prologue
    .line 35
    new-instance v0, Ltas/internal/ipc/server/RemoteReceiver$1;

    invoke-direct {v0}, Ltas/internal/ipc/server/RemoteReceiver$1;-><init>()V

    .line 34
    sput-object v0, Ltas/internal/ipc/server/RemoteReceiver;->CREATOR:Landroid/os/Parcelable$Creator;

    .line 69
    new-instance v0, Ltas/internal/ipc/server/RemoteReceiver$2;

    invoke-direct {v0}, Ltas/internal/ipc/server/RemoteReceiver$2;-><init>()V

    .line 68
    sput-object v0, Ltas/internal/ipc/server/RemoteReceiver;->CALLBACK:Ltas/internal/ipc/util/SyncdPool$Callback;

    .line 87
    new-instance v0, Ltas/internal/ipc/util/SyncdPool;

    sget-object v1, Ltas/internal/ipc/server/RemoteReceiver;->CALLBACK:Ltas/internal/ipc/util/SyncdPool$Callback;

    invoke-direct {v0, v1}, Ltas/internal/ipc/util/SyncdPool;-><init>(Ltas/internal/ipc/util/SyncdPool$Callback;)V

    .line 86
    sput-object v0, Ltas/internal/ipc/server/RemoteReceiver;->sPool:Ltas/internal/ipc/util/SyncdPool;

    .line 88
    const/4 v0, 0x0

    sput v0, Ltas/internal/ipc/server/RemoteReceiver;->sPoolId:I

    .line 15
    return-void
.end method

.method private constructor <init>()V
    .locals 0

    .prologue
    .line 18
    invoke-direct {p0}, Ltas/internal/ipc/server/RemoteClient;-><init>()V

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;)V
    .locals 0
    .param p1, "pkg"    # Ljava/lang/String;
    .param p2, "name"    # Ljava/lang/String;

    .prologue
    .line 16
    invoke-direct {p0, p1, p2}, Ltas/internal/ipc/server/RemoteClient;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method public constructor <init>(Ltas/internal/ipc/server/RemoteReceiver;)V
    .locals 0
    .param p1, "receiver"    # Ltas/internal/ipc/server/RemoteReceiver;

    .prologue
    .line 17
    invoke-direct {p0, p1}, Ltas/internal/ipc/server/RemoteClient;-><init>(Ltas/internal/ipc/server/RemoteClient;)V

    return-void
.end method

.method synthetic constructor <init>(Ltas/internal/ipc/server/RemoteReceiver;Ltas/internal/ipc/server/RemoteReceiver;)V
    .locals 0

    .prologue
    invoke-direct {p0}, Ltas/internal/ipc/server/RemoteReceiver;-><init>()V

    return-void
.end method

.method public static createFromParcel(Landroid/os/Parcel;)Ltas/internal/ipc/server/RemoteReceiver;
    .locals 1
    .param p0, "source"    # Landroid/os/Parcel;

    .prologue
    .line 63
    invoke-static {}, Ltas/internal/ipc/server/RemoteReceiver;->obtain()Ltas/internal/ipc/server/RemoteReceiver;

    move-result-object v0

    .line 64
    .local v0, "r":Ltas/internal/ipc/server/RemoteReceiver;
    invoke-virtual {v0, p0}, Ltas/internal/ipc/server/RemoteReceiver;->readFromParcel(Landroid/os/Parcel;)V

    .line 65
    return-object v0
.end method

.method public static obtain()Ltas/internal/ipc/server/RemoteReceiver;
    .locals 2

    .prologue
    .line 49
    sget-object v1, Ltas/internal/ipc/server/RemoteReceiver;->sPool:Ltas/internal/ipc/util/SyncdPool;

    invoke-virtual {v1}, Ltas/internal/ipc/util/SyncdPool;->allocate()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/ipc/server/RemoteReceiver;

    .line 50
    .local v0, "r":Ltas/internal/ipc/server/RemoteReceiver;
    const/4 v1, 0x1

    iput-boolean v1, v0, Ltas/internal/ipc/server/RemoteReceiver;->mAllocated:Z

    .line 51
    return-object v0
.end method

.method public static obtain(Ltas/internal/ipc/server/RemoteReceiver;)Ltas/internal/ipc/server/RemoteReceiver;
    .locals 1
    .param p0, "that"    # Ltas/internal/ipc/server/RemoteReceiver;

    .prologue
    .line 55
    invoke-static {}, Ltas/internal/ipc/server/RemoteReceiver;->obtain()Ltas/internal/ipc/server/RemoteReceiver;

    move-result-object v0

    .line 56
    .local v0, "r":Ltas/internal/ipc/server/RemoteReceiver;
    invoke-virtual {v0, p0}, Ltas/internal/ipc/server/RemoteReceiver;->copyFrom(Ltas/internal/ipc/server/RemoteClient;)V

    .line 57
    return-object v0
.end method


# virtual methods
.method public copyFrom(Ltas/internal/ipc/server/RemoteClient;)V
    .locals 4
    .param p1, "c"    # Ltas/internal/ipc/server/RemoteClient;

    .prologue
    .line 24
    instance-of v1, p1, Ltas/internal/ipc/server/RemoteReceiver;

    if-nez v1, :cond_0

    .line 25
    new-instance v1, Ljava/lang/IllegalArgumentException;

    .line 26
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "copyFrom: "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {p1}, Ltas/internal/ipc/server/RemoteClient;->getClass()Ljava/lang/Class;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    .line 25
    invoke-direct {v1, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v1

    .line 28
    :cond_0
    invoke-super {p0, p1}, Ltas/internal/ipc/server/RemoteClient;->copyFrom(Ltas/internal/ipc/server/RemoteClient;)V

    move-object v0, p1

    .line 30
    check-cast v0, Ltas/internal/ipc/server/RemoteReceiver;

    .line 31
    .local v0, "r":Ltas/internal/ipc/server/RemoteReceiver;
    iget-boolean v1, v0, Ltas/internal/ipc/server/RemoteReceiver;->p2pMode:Z

    iput-boolean v1, p0, Ltas/internal/ipc/server/RemoteReceiver;->p2pMode:Z

    .line 23
    return-void
.end method

.method public readFromParcel(Landroid/os/Parcel;)V
    .locals 2
    .param p1, "source"    # Landroid/os/Parcel;

    .prologue
    const/4 v0, 0x1

    .line 115
    invoke-super {p0, p1}, Ltas/internal/ipc/server/RemoteClient;->readFromParcel(Landroid/os/Parcel;)V

    .line 116
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v1

    if-ne v1, v0, :cond_0

    :goto_0
    iput-boolean v0, p0, Ltas/internal/ipc/server/RemoteReceiver;->p2pMode:Z

    .line 114
    return-void

    .line 116
    :cond_0
    const/4 v0, 0x0

    goto :goto_0
.end method

.method public recycle()V
    .locals 3

    .prologue
    const/4 v2, 0x0

    const/4 v1, 0x0

    .line 97
    iget-boolean v0, p0, Ltas/internal/ipc/server/RemoteReceiver;->mPooled:Z

    if-eqz v0, :cond_0

    iget-boolean v0, p0, Ltas/internal/ipc/server/RemoteReceiver;->mAllocated:Z

    if-eqz v0, :cond_0

    .line 98
    iput-boolean v2, p0, Ltas/internal/ipc/server/RemoteReceiver;->mAllocated:Z

    .line 99
    iput-object v1, p0, Ltas/internal/ipc/server/RemoteReceiver;->pkg:Ljava/lang/String;

    .line 100
    iput-object v1, p0, Ltas/internal/ipc/server/RemoteReceiver;->name:Ljava/lang/String;

    .line 101
    iput-object v1, p0, Ltas/internal/ipc/server/RemoteReceiver;->extra:Landroid/os/Bundle;

    .line 102
    iput-boolean v2, p0, Ltas/internal/ipc/server/RemoteReceiver;->p2pMode:Z

    .line 103
    sget-object v0, Ltas/internal/ipc/server/RemoteReceiver;->sPool:Ltas/internal/ipc/util/SyncdPool;

    invoke-virtual {v0, p0}, Ltas/internal/ipc/util/SyncdPool;->recycle(Ljava/lang/Object;)V

    .line 94
    :cond_0
    return-void
.end method

.method public toString()Ljava/lang/String;
    .locals 2

    .prologue
    .line 121
    iget-boolean v0, p0, Ltas/internal/ipc/server/RemoteReceiver;->mPooled:Z

    if-eqz v0, :cond_0

    .line 122
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0, v0}, Ltas/internal/ipc/server/RemoteReceiver;->buildString(Ljava/lang/StringBuilder;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 123
    const-string/jumbo v1, " "

    .line 122
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 123
    iget v1, p0, Ltas/internal/ipc/server/RemoteReceiver;->pool:I

    .line 122
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0

    .line 126
    :cond_0
    invoke-super {p0}, Ltas/internal/ipc/server/RemoteClient;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public writeToParcel(Landroid/os/Parcel;I)V
    .locals 1
    .param p1, "dest"    # Landroid/os/Parcel;
    .param p2, "flags"    # I

    .prologue
    .line 109
    invoke-super {p0, p1, p2}, Ltas/internal/ipc/server/RemoteClient;->writeToParcel(Landroid/os/Parcel;I)V

    .line 110
    iget-boolean v0, p0, Ltas/internal/ipc/server/RemoteReceiver;->p2pMode:Z

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    :goto_0
    invoke-virtual {p1, v0}, Landroid/os/Parcel;->writeInt(I)V

    .line 108
    return-void

    .line 110
    :cond_0
    const/4 v0, 0x0

    goto :goto_0
.end method
