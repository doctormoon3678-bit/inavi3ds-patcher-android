.class public Ltas/internal/avm/PGSPoints;
.super Ljava/lang/Object;
.source "PGSPoints.java"


# static fields
.field private static final CVBS_TO_WSVGA_RATIO_X:F = 1.42f

.field private static final CVBS_TO_WSVGA_RATIO_Y:F = 1.25f

.field public static final FLOAT_BYTE_SIZE:I = 0x4

.field private static final TAG:Ljava/lang/String; = "TAS.INTERNAL.AVM.PGS"


# instance fields
.field private mNumPoint:I

.field private x:[F

.field private xy:[[B

.field private y:[F


# direct methods
.method public constructor <init>(I)V
    .locals 1
    .param p1, "numPoint"    # I

    .prologue
    .line 23
    const/4 v0, 0x0

    check-cast v0, [B

    invoke-direct {p0, p1, v0}, Ltas/internal/avm/PGSPoints;-><init>(I[B)V

    .line 22
    return-void
.end method

.method public constructor <init>(I[B)V
    .locals 10
    .param p1, "numPoint"    # I
    .param p2, "points"    # [B

    .prologue
    const/4 v9, 0x4

    const/4 v8, 0x0

    .line 26
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 27
    const/16 v4, 0x14

    if-le p1, v4, :cond_0

    .line 28
    const-string/jumbo v4, "TAS.INTERNAL.AVM.PGS"

    const-string/jumbo v5, "you cannot allocate more than 20 points at a time. change numPoint to 20 forcibely."

    invoke-static {v4, v5}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 31
    const/16 p1, 0x14

    .line 34
    :cond_0
    iput p1, p0, Ltas/internal/avm/PGSPoints;->mNumPoint:I

    .line 35
    new-array v4, p1, [F

    iput-object v4, p0, Ltas/internal/avm/PGSPoints;->x:[F

    .line 36
    new-array v4, p1, [F

    iput-object v4, p0, Ltas/internal/avm/PGSPoints;->y:[F

    .line 37
    sget-object v4, Ljava/lang/Byte;->TYPE:Ljava/lang/Class;

    const/4 v5, 0x2

    new-array v5, v5, [I

    aput p1, v5, v8

    const/16 v6, 0x8

    const/4 v7, 0x1

    aput v6, v5, v7

    invoke-static {v4, v5}, Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class;[I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, [[B

    iput-object v4, p0, Ltas/internal/avm/PGSPoints;->xy:[[B

    .line 39
    if-eqz p2, :cond_2

    .line 41
    array-length v4, p2

    mul-int/lit8 v5, p1, 0x4

    mul-int/lit8 v5, v5, 0x2

    if-eq v4, v5, :cond_1

    .line 42
    const-string/jumbo v4, "TAS.INTERNAL.AVM.PGS"

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v6, "wrong size points or numPoint. numPoint = "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v5

    .line 43
    const-string/jumbo v6, "points length = "

    .line 42
    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    .line 44
    array-length v6, p2

    .line 42
    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-static {v4, v5}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 46
    iput v8, p0, Ltas/internal/avm/PGSPoints;->mNumPoint:I

    .line 47
    return-void

    .line 50
    :cond_1
    mul-int/lit8 v4, p1, 0x4

    mul-int/lit8 v4, v4, 0x2

    invoke-static {v4}, Ljava/nio/ByteBuffer;->allocate(I)Ljava/nio/ByteBuffer;

    move-result-object v0

    .line 51
    .local v0, "bb":Ljava/nio/ByteBuffer;
    invoke-virtual {v0, p2}, Ljava/nio/ByteBuffer;->put([B)Ljava/nio/ByteBuffer;

    .line 53
    const/4 v3, 0x0

    .local v3, "i":I
    :goto_0
    iget v4, p0, Ltas/internal/avm/PGSPoints;->mNumPoint:I

    if-ge v3, v4, :cond_2

    .line 54
    invoke-static {v9}, Ljava/nio/ByteBuffer;->allocate(I)Ljava/nio/ByteBuffer;

    move-result-object v1

    .line 55
    .local v1, "fx":Ljava/nio/ByteBuffer;
    invoke-static {v9}, Ljava/nio/ByteBuffer;->allocate(I)Ljava/nio/ByteBuffer;

    move-result-object v2

    .line 57
    .local v2, "fy":Ljava/nio/ByteBuffer;
    mul-int/lit8 v4, v3, 0x4

    mul-int/lit8 v4, v4, 0x2

    invoke-virtual {v1, p2, v4, v9}, Ljava/nio/ByteBuffer;->put([BII)Ljava/nio/ByteBuffer;

    .line 58
    mul-int/lit8 v4, v3, 0x4

    mul-int/lit8 v4, v4, 0x2

    add-int/lit8 v4, v4, 0x4

    invoke-virtual {v2, p2, v4, v9}, Ljava/nio/ByteBuffer;->put([BII)Ljava/nio/ByteBuffer;

    .line 60
    invoke-virtual {v1, v8}, Ljava/nio/ByteBuffer;->position(I)Ljava/nio/Buffer;

    .line 61
    invoke-virtual {v2, v8}, Ljava/nio/ByteBuffer;->position(I)Ljava/nio/Buffer;

    .line 63
    iget-object v4, p0, Ltas/internal/avm/PGSPoints;->x:[F

    invoke-virtual {v1}, Ljava/nio/ByteBuffer;->getFloat()F

    move-result v5

    aput v5, v4, v3

    .line 64
    iget-object v4, p0, Ltas/internal/avm/PGSPoints;->y:[F

    invoke-virtual {v2}, Ljava/nio/ByteBuffer;->getFloat()F

    move-result v5

    aput v5, v4, v3

    .line 66
    iget-object v4, p0, Ltas/internal/avm/PGSPoints;->x:[F

    aget v4, v4, v3

    iget-object v5, p0, Ltas/internal/avm/PGSPoints;->y:[F

    aget v5, v5, v3

    invoke-virtual {p0, v3, v4, v5}, Ltas/internal/avm/PGSPoints;->setXY(IFF)V

    .line 53
    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    .line 26
    .end local v0    # "bb":Ljava/nio/ByteBuffer;
    .end local v1    # "fx":Ljava/nio/ByteBuffer;
    .end local v2    # "fy":Ljava/nio/ByteBuffer;
    .end local v3    # "i":I
    :cond_2
    return-void
.end method

.method private isIndexOutOfBound(I)Z
    .locals 2
    .param p1, "index"    # I

    .prologue
    .line 144
    iget v0, p0, Ltas/internal/avm/PGSPoints;->mNumPoint:I

    if-le p1, v0, :cond_0

    .line 145
    const-string/jumbo v0, "TAS.INTERNAL.AVM.PGS"

    const-string/jumbo v1, "index should be less then getPointCount()"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 146
    const/4 v0, 0x1

    return v0

    .line 149
    :cond_0
    const/4 v0, 0x0

    return v0
.end method


# virtual methods
.method public convertCVBStoWSVGA()V
    .locals 5

    .prologue
    .line 129
    const/4 v0, 0x0

    .local v0, "i":I
    :goto_0
    iget v3, p0, Ltas/internal/avm/PGSPoints;->mNumPoint:I

    if-ge v0, v3, :cond_0

    .line 130
    iget-object v3, p0, Ltas/internal/avm/PGSPoints;->x:[F

    aget v3, v3, v0

    const v4, 0x3fb5c28f    # 1.42f

    mul-float v1, v3, v4

    .line 131
    .local v1, "wsvgaX":F
    iget-object v3, p0, Ltas/internal/avm/PGSPoints;->y:[F

    aget v3, v3, v0

    const/high16 v4, 0x3fa00000    # 1.25f

    mul-float v2, v3, v4

    .line 133
    .local v2, "wsvgaY":F
    invoke-virtual {p0, v0, v1, v2}, Ltas/internal/avm/PGSPoints;->setXY(IFF)V

    .line 129
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    .line 128
    .end local v1    # "wsvgaX":F
    .end local v2    # "wsvgaY":F
    :cond_0
    return-void
.end method

.method public dump()V
    .locals 4

    .prologue
    .line 138
    const/4 v0, 0x0

    .local v0, "i":I
    :goto_0
    iget v1, p0, Ltas/internal/avm/PGSPoints;->mNumPoint:I

    if-ge v0, v1, :cond_0

    .line 139
    const-string/jumbo v1, "TAS.INTERNAL.AVM.PGS"

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "PGSPoints ("

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {p0, v0}, Ltas/internal/avm/PGSPoints;->getX(I)I

    move-result v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string/jumbo v3, ", "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {p0, v0}, Ltas/internal/avm/PGSPoints;->getY(I)I

    move-result v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string/jumbo v3, ")"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 138
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    .line 137
    :cond_0
    return-void
.end method

.method public fillRandom(II)V
    .locals 8
    .param p1, "maxX"    # I
    .param p2, "maxY"    # I

    .prologue
    const/4 v7, 0x1

    .line 72
    invoke-static {}, Ljava/util/concurrent/ThreadLocalRandom;->current()Ljava/util/concurrent/ThreadLocalRandom;

    move-result-object v3

    .line 73
    .local v3, "random":Ljava/util/concurrent/ThreadLocalRandom;
    const/4 v0, 0x0

    .local v0, "i":I
    :goto_0
    iget v4, p0, Ltas/internal/avm/PGSPoints;->mNumPoint:I

    if-ge v0, v4, :cond_0

    .line 74
    invoke-virtual {v3, v7, p1}, Ljava/util/concurrent/ThreadLocalRandom;->nextInt(II)I

    move-result v4

    int-to-float v1, v4

    .line 75
    .local v1, "randX":F
    invoke-virtual {v3, v7, p2}, Ljava/util/concurrent/ThreadLocalRandom;->nextInt(II)I

    move-result v4

    int-to-float v2, v4

    .line 76
    .local v2, "randY":F
    const-string/jumbo v4, "TAS.INTERNAL.AVM.PGS"

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v6, "point ("

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string/jumbo v6, ") allocated with random point ("

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string/jumbo v6, ", "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string/jumbo v6, ")"

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-static {v4, v5}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 78
    invoke-virtual {p0, v0, v1, v2}, Ltas/internal/avm/PGSPoints;->setXY(IFF)V

    .line 73
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    .line 71
    .end local v1    # "randX":F
    .end local v2    # "randY":F
    :cond_0
    return-void
.end method

.method public getPointCount()I
    .locals 1

    .prologue
    .line 153
    iget v0, p0, Ltas/internal/avm/PGSPoints;->mNumPoint:I

    return v0
.end method

.method public getX(I)I
    .locals 1
    .param p1, "index"    # I

    .prologue
    .line 157
    iget-object v0, p0, Ltas/internal/avm/PGSPoints;->x:[F

    aget v0, v0, p1

    invoke-static {v0}, Ljava/lang/Math;->round(F)I

    move-result v0

    return v0
.end method

.method public getY(I)I
    .locals 1
    .param p1, "index"    # I

    .prologue
    .line 161
    iget-object v0, p0, Ltas/internal/avm/PGSPoints;->y:[F

    aget v0, v0, p1

    invoke-static {v0}, Ljava/lang/Math;->round(F)I

    move-result v0

    return v0
.end method

.method public setXY(IFF)V
    .locals 9
    .param p1, "index"    # I
    .param p2, "x"    # F
    .param p3, "y"    # F

    .prologue
    const/4 v8, 0x4

    .line 106
    invoke-direct {p0, p1}, Ltas/internal/avm/PGSPoints;->isIndexOutOfBound(I)Z

    move-result v5

    if-eqz v5, :cond_0

    .line 107
    const-string/jumbo v5, "TAS.INTERNAL.AVM.PGS"

    const-string/jumbo v6, "index out of boud"

    invoke-static {v5, v6}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 108
    return-void

    .line 111
    :cond_0
    new-array v3, v8, [B

    .line 112
    .local v3, "tmp_x":[B
    new-array v4, v8, [B

    .line 114
    .local v4, "tmp_y":[B
    invoke-static {v8}, Ljava/nio/ByteBuffer;->allocate(I)Ljava/nio/ByteBuffer;

    move-result-object v0

    .line 115
    .local v0, "bbx":Ljava/nio/ByteBuffer;
    invoke-static {v8}, Ljava/nio/ByteBuffer;->allocate(I)Ljava/nio/ByteBuffer;

    move-result-object v1

    .line 117
    .local v1, "bby":Ljava/nio/ByteBuffer;
    invoke-virtual {v0, p2}, Ljava/nio/ByteBuffer;->putFloat(F)Ljava/nio/ByteBuffer;

    move-result-object v5

    invoke-virtual {v5}, Ljava/nio/ByteBuffer;->array()[B

    move-result-object v3

    .line 118
    invoke-virtual {v1, p3}, Ljava/nio/ByteBuffer;->putFloat(F)Ljava/nio/ByteBuffer;

    move-result-object v5

    invoke-virtual {v5}, Ljava/nio/ByteBuffer;->array()[B

    move-result-object v4

    .line 120
    const/4 v2, 0x0

    .local v2, "i":I
    :goto_0
    if-ge v2, v8, :cond_1

    .line 121
    iget-object v5, p0, Ltas/internal/avm/PGSPoints;->x:[F

    aput p2, v5, p1

    .line 122
    iget-object v5, p0, Ltas/internal/avm/PGSPoints;->y:[F

    aput p3, v5, p1

    .line 123
    iget-object v5, p0, Ltas/internal/avm/PGSPoints;->xy:[[B

    aget-object v5, v5, p1

    aget-byte v6, v3, v2

    aput-byte v6, v5, v2

    .line 124
    iget-object v5, p0, Ltas/internal/avm/PGSPoints;->xy:[[B

    aget-object v5, v5, p1

    add-int/lit8 v6, v2, 0x4

    aget-byte v7, v4, v2

    aput-byte v7, v5, v6

    .line 120
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    .line 104
    :cond_1
    return-void
.end method

.method public toByteArray()[B
    .locals 5

    .prologue
    .line 83
    iget v3, p0, Ltas/internal/avm/PGSPoints;->mNumPoint:I

    mul-int/lit8 v3, v3, 0x4

    mul-int/lit8 v3, v3, 0x2

    new-array v0, v3, [B

    .line 84
    .local v0, "flattened":[B
    const/4 v1, 0x0

    .local v1, "i":I
    :goto_0
    iget v3, p0, Ltas/internal/avm/PGSPoints;->mNumPoint:I

    if-ge v1, v3, :cond_1

    .line 85
    const/4 v2, 0x0

    .local v2, "j":I
    :goto_1
    const/16 v3, 0x8

    if-ge v2, v3, :cond_0

    .line 87
    mul-int/lit8 v3, v1, 0x4

    mul-int/lit8 v3, v3, 0x2

    add-int/2addr v3, v2

    iget-object v4, p0, Ltas/internal/avm/PGSPoints;->xy:[[B

    aget-object v4, v4, v1

    aget-byte v4, v4, v2

    aput-byte v4, v0, v3

    .line 85
    add-int/lit8 v2, v2, 0x1

    goto :goto_1

    .line 84
    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    .line 91
    .end local v2    # "j":I
    :cond_1
    return-object v0
.end method

.method public toString()Ljava/lang/String;
    .locals 4

    .prologue
    .line 95
    const-string/jumbo v1, ""

    .line 96
    .local v1, "ret":Ljava/lang/String;
    const/4 v0, 0x0

    .local v0, "i":I
    :goto_0
    iget v2, p0, Ltas/internal/avm/PGSPoints;->mNumPoint:I

    if-ge v0, v2, :cond_0

    .line 97
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string/jumbo v3, "["

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string/jumbo v3, "]"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string/jumbo v3, " x = "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, p0, Ltas/internal/avm/PGSPoints;->x:[F

    aget v3, v3, v0

    invoke-static {v3}, Ljava/lang/Float;->toString(F)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    .line 98
    const-string/jumbo v3, " y = "

    .line 97
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    .line 98
    iget-object v3, p0, Ltas/internal/avm/PGSPoints;->y:[F

    aget v3, v3, v0

    invoke-static {v3}, Ljava/lang/Float;->toString(F)Ljava/lang/String;

    move-result-object v3

    .line 97
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    .line 98
    const-string/jumbo v3, "\n"

    .line 97
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .line 96
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    .line 101
    :cond_0
    return-object v1
.end method
