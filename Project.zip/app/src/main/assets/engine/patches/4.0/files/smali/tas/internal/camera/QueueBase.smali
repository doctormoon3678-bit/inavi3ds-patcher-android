.class public Ltas/internal/camera/QueueBase;
.super Ljava/lang/Object;
.source "QueueBase.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ltas/internal/camera/QueueBase$OnAvailableListener;,
        Ltas/internal/camera/QueueBase$H;,
        Ltas/internal/camera/QueueBase$1;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation


# static fields
.field private static final DBG:Z = true


# instance fields
.field private final DEQ_RUNNABLE:Ljava/lang/Runnable;

.field protected TAG:Ljava/lang/String;

.field private mDequeued:Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TT;"
        }
    .end annotation
.end field

.field private mH:Ltas/internal/camera/QueueBase$H;

.field private mHT:Landroid/os/HandlerThread;

.field private mL:Ltas/internal/camera/QueueBase$OnAvailableListener;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ltas/internal/camera/QueueBase$OnAvailableListener",
            "<TT;>;"
        }
    .end annotation
.end field

.field private mPausedCount:I

.field private mQueue:Ljava/util/Deque;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Deque",
            "<TT;>;"
        }
    .end annotation
.end field

.field private final mSp:Ljava/util/concurrent/Semaphore;


# direct methods
.method static synthetic -get0(Ltas/internal/camera/QueueBase;)Ltas/internal/camera/QueueBase$OnAvailableListener;
    .locals 1

    iget-object v0, p0, Ltas/internal/camera/QueueBase;->mL:Ltas/internal/camera/QueueBase$OnAvailableListener;

    return-object v0
.end method

.method static synthetic -get1(Ltas/internal/camera/QueueBase;)Ljava/util/Deque;
    .locals 1

    iget-object v0, p0, Ltas/internal/camera/QueueBase;->mQueue:Ljava/util/Deque;

    return-object v0
.end method

.method static synthetic -set0(Ltas/internal/camera/QueueBase;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    iput-object p1, p0, Ltas/internal/camera/QueueBase;->mDequeued:Ljava/lang/Object;

    return-object p1
.end method

.method static synthetic -wrap0(Ltas/internal/camera/QueueBase;)V
    .locals 0

    invoke-direct {p0}, Ltas/internal/camera/QueueBase;->dequeue()V

    return-void
.end method

.method static synthetic -wrap1(Ltas/internal/camera/QueueBase;)V
    .locals 0

    invoke-direct {p0}, Ltas/internal/camera/QueueBase;->lockdequeue()V

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    .prologue
    .line 33
    .local p0, "this":Ltas/internal/camera/QueueBase;, "Ltas/internal/camera/QueueBase<TT;>;"
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 21
    const-string/jumbo v0, "TasCAM"

    iput-object v0, p0, Ltas/internal/camera/QueueBase;->TAG:Ljava/lang/String;

    .line 126
    new-instance v0, Ltas/internal/camera/QueueBase$1;

    invoke-direct {v0, p0}, Ltas/internal/camera/QueueBase$1;-><init>(Ltas/internal/camera/QueueBase;)V

    iput-object v0, p0, Ltas/internal/camera/QueueBase;->DEQ_RUNNABLE:Ljava/lang/Runnable;

    .line 200
    new-instance v0, Ljava/util/concurrent/Semaphore;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Ljava/util/concurrent/Semaphore;-><init>(I)V

    iput-object v0, p0, Ltas/internal/camera/QueueBase;->mSp:Ljava/util/concurrent/Semaphore;

    .line 34
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v1, p0, Ltas/internal/camera/QueueBase;->TAG:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string/jumbo v1, "<"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {p0}, Ltas/internal/camera/QueueBase;->getClass()Ljava/lang/Class;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string/jumbo v1, ">"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Ltas/internal/camera/QueueBase;->TAG:Ljava/lang/String;

    .line 35
    new-instance v0, Ljava/util/concurrent/ConcurrentLinkedDeque;

    invoke-direct {v0}, Ljava/util/concurrent/ConcurrentLinkedDeque;-><init>()V

    iput-object v0, p0, Ltas/internal/camera/QueueBase;->mQueue:Ljava/util/Deque;

    .line 36
    invoke-direct {p0}, Ltas/internal/camera/QueueBase;->startBackgroundThread()V

    .line 37
    invoke-direct {p0}, Ltas/internal/camera/QueueBase;->dequeue()V

    .line 33
    return-void
.end method

.method private dequeue()V
    .locals 2

    .prologue
    .line 192
    .local p0, "this":Ltas/internal/camera/QueueBase;, "Ltas/internal/camera/QueueBase<TT;>;"
    iget-object v0, p0, Ltas/internal/camera/QueueBase;->mH:Ltas/internal/camera/QueueBase$H;

    iget-object v1, p0, Ltas/internal/camera/QueueBase;->DEQ_RUNNABLE:Ljava/lang/Runnable;

    invoke-virtual {v0, v1}, Ltas/internal/camera/QueueBase$H;->post(Ljava/lang/Runnable;)Z

    .line 191
    return-void
.end method

.method private enqueue(Ljava/lang/Object;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    .prologue
    .line 185
    .local p0, "this":Ltas/internal/camera/QueueBase;, "Ltas/internal/camera/QueueBase<TT;>;"
    .local p1, "t":Ljava/lang/Object;, "TT;"
    iget-object v0, p0, Ltas/internal/camera/QueueBase;->mQueue:Ljava/util/Deque;

    invoke-interface {v0, p1}, Ljava/util/Deque;->offer(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 186
    invoke-virtual {p0, p1}, Ltas/internal/camera/QueueBase;->onEnqueue(Ljava/lang/Object;)V

    .line 187
    invoke-direct {p0}, Ltas/internal/camera/QueueBase;->unlock()V

    .line 184
    :cond_0
    return-void
.end method

.method private lock()V
    .locals 2

    .prologue
    .line 173
    .local p0, "this":Ltas/internal/camera/QueueBase;, "Ltas/internal/camera/QueueBase<TT;>;"
    :try_start_0
    iget-object v1, p0, Ltas/internal/camera/QueueBase;->mSp:Ljava/util/concurrent/Semaphore;

    invoke-virtual {v1}, Ljava/util/concurrent/Semaphore;->acquire()V
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0

    .line 170
    :goto_0
    return-void

    .line 174
    :catch_0
    move-exception v0

    .line 175
    .local v0, "e":Ljava/lang/InterruptedException;
    invoke-virtual {v0}, Ljava/lang/InterruptedException;->printStackTrace()V

    goto :goto_0
.end method

.method private lockdequeue()V
    .locals 0

    .prologue
    .line 196
    .local p0, "this":Ltas/internal/camera/QueueBase;, "Ltas/internal/camera/QueueBase<TT;>;"
    invoke-direct {p0}, Ltas/internal/camera/QueueBase;->lock()V

    .line 197
    invoke-direct {p0}, Ltas/internal/camera/QueueBase;->dequeue()V

    .line 195
    return-void
.end method

.method private startBackgroundThread()V
    .locals 3

    .prologue
    .line 154
    .local p0, "this":Ltas/internal/camera/QueueBase;, "Ltas/internal/camera/QueueBase<TT;>;"
    new-instance v0, Landroid/os/HandlerThread;

    invoke-virtual {p0}, Ltas/internal/camera/QueueBase;->getClass()Ljava/lang/Class;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/HandlerThread;-><init>(Ljava/lang/String;)V

    iput-object v0, p0, Ltas/internal/camera/QueueBase;->mHT:Landroid/os/HandlerThread;

    .line 155
    iget-object v0, p0, Ltas/internal/camera/QueueBase;->mHT:Landroid/os/HandlerThread;

    invoke-virtual {v0}, Landroid/os/HandlerThread;->start()V

    .line 156
    new-instance v0, Ltas/internal/camera/QueueBase$H;

    iget-object v1, p0, Ltas/internal/camera/QueueBase;->mHT:Landroid/os/HandlerThread;

    invoke-virtual {v1}, Landroid/os/HandlerThread;->getLooper()Landroid/os/Looper;

    move-result-object v1

    const/4 v2, 0x0

    invoke-direct {v0, p0, v1, v2}, Ltas/internal/camera/QueueBase$H;-><init>(Ltas/internal/camera/QueueBase;Landroid/os/Looper;Ltas/internal/camera/QueueBase$H;)V

    iput-object v0, p0, Ltas/internal/camera/QueueBase;->mH:Ltas/internal/camera/QueueBase$H;

    .line 153
    return-void
.end method

.method private stopBackgroundThread()V
    .locals 2

    .prologue
    .line 160
    .local p0, "this":Ltas/internal/camera/QueueBase;, "Ltas/internal/camera/QueueBase<TT;>;"
    iget-object v1, p0, Ltas/internal/camera/QueueBase;->mHT:Landroid/os/HandlerThread;

    invoke-virtual {v1}, Landroid/os/HandlerThread;->quitSafely()Z

    .line 162
    :try_start_0
    iget-object v1, p0, Ltas/internal/camera/QueueBase;->mHT:Landroid/os/HandlerThread;

    invoke-virtual {v1}, Landroid/os/HandlerThread;->join()V

    .line 163
    const/4 v1, 0x0

    iput-object v1, p0, Ltas/internal/camera/QueueBase;->mHT:Landroid/os/HandlerThread;

    .line 164
    const/4 v1, 0x0

    iput-object v1, p0, Ltas/internal/camera/QueueBase;->mH:Ltas/internal/camera/QueueBase$H;
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0

    .line 159
    :goto_0
    return-void

    .line 165
    :catch_0
    move-exception v0

    .line 166
    .local v0, "e":Ljava/lang/InterruptedException;
    invoke-virtual {v0}, Ljava/lang/InterruptedException;->printStackTrace()V

    goto :goto_0
.end method

.method private unlock()V
    .locals 1

    .prologue
    .line 181
    .local p0, "this":Ltas/internal/camera/QueueBase;, "Ltas/internal/camera/QueueBase<TT;>;"
    iget-object v0, p0, Ltas/internal/camera/QueueBase;->mSp:Ljava/util/concurrent/Semaphore;

    invoke-virtual {v0}, Ljava/util/concurrent/Semaphore;->release()V

    .line 180
    return-void
.end method


# virtual methods
.method public clear()V
    .locals 1

    .prologue
    .line 87
    .local p0, "this":Ltas/internal/camera/QueueBase;, "Ltas/internal/camera/QueueBase<TT;>;"
    iget-object v0, p0, Ltas/internal/camera/QueueBase;->mQueue:Ljava/util/Deque;

    invoke-interface {v0}, Ljava/util/Deque;->clear()V

    .line 86
    return-void
.end method

.method public getLastDequeued()Ljava/lang/Object;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TT;"
        }
    .end annotation

    .prologue
    .line 83
    .local p0, "this":Ltas/internal/camera/QueueBase;, "Ltas/internal/camera/QueueBase<TT;>;"
    iget-object v0, p0, Ltas/internal/camera/QueueBase;->mDequeued:Ljava/lang/Object;

    return-object v0
.end method

.method public handleMessage(Landroid/os/Message;)V
    .locals 0
    .param p1, "msg"    # Landroid/os/Message;

    .prologue
    .line 47
    .local p0, "this":Ltas/internal/camera/QueueBase;, "Ltas/internal/camera/QueueBase<TT;>;"
    return-void
.end method

.method public isEmpty()Z
    .locals 1

    .prologue
    .line 95
    .local p0, "this":Ltas/internal/camera/QueueBase;, "Ltas/internal/camera/QueueBase<TT;>;"
    iget-object v0, p0, Ltas/internal/camera/QueueBase;->mQueue:Ljava/util/Deque;

    invoke-interface {v0}, Ljava/util/Deque;->isEmpty()Z

    move-result v0

    return v0
.end method

.method public isPaused()Z
    .locals 3

    .prologue
    .local p0, "this":Ltas/internal/camera/QueueBase;, "Ltas/internal/camera/QueueBase<TT;>;"
    const/4 v0, 0x0

    .line 73
    const-class v1, Ltas/internal/camera/QueueBase;

    monitor-enter v1

    .line 74
    :try_start_0
    iget v2, p0, Ltas/internal/camera/QueueBase;->mPausedCount:I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-lez v2, :cond_0

    const/4 v0, 0x1

    :cond_0
    monitor-exit v1

    return v0

    .line 73
    :catchall_0
    move-exception v0

    monitor-exit v1

    throw v0
.end method

.method public iterator()Ljava/util/Iterator;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Iterator",
            "<TT;>;"
        }
    .end annotation

    .prologue
    .line 99
    .local p0, "this":Ltas/internal/camera/QueueBase;, "Ltas/internal/camera/QueueBase<TT;>;"
    iget-object v0, p0, Ltas/internal/camera/QueueBase;->mQueue:Ljava/util/Deque;

    invoke-interface {v0}, Ljava/util/Deque;->iterator()Ljava/util/Iterator;

    move-result-object v0

    return-object v0
.end method

.method public offer(Ljava/lang/Object;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    .prologue
    .line 79
    .local p0, "this":Ltas/internal/camera/QueueBase;, "Ltas/internal/camera/QueueBase<TT;>;"
    .local p1, "t":Ljava/lang/Object;, "TT;"
    invoke-direct {p0, p1}, Ltas/internal/camera/QueueBase;->enqueue(Ljava/lang/Object;)V

    .line 78
    return-void
.end method

.method public onAvailable(Ljava/lang/Object;)Z
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)Z"
        }
    .end annotation

    .prologue
    .line 46
    .local p0, "this":Ltas/internal/camera/QueueBase;, "Ltas/internal/camera/QueueBase<TT;>;"
    .local p1, "t":Ljava/lang/Object;, "TT;"
    const/4 v0, 0x0

    return v0
.end method

.method public onDequeue()Ljava/lang/Object;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TT;"
        }
    .end annotation

    .prologue
    .line 45
    .local p0, "this":Ltas/internal/camera/QueueBase;, "Ltas/internal/camera/QueueBase<TT;>;"
    const/4 v0, 0x0

    return-object v0
.end method

.method public onEnqueue(Ljava/lang/Object;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    .prologue
    .line 44
    .local p0, "this":Ltas/internal/camera/QueueBase;, "Ltas/internal/camera/QueueBase<TT;>;"
    .local p1, "t":Ljava/lang/Object;, "TT;"
    return-void
.end method

.method public pause()I
    .locals 2

    .prologue
    .line 66
    .local p0, "this":Ltas/internal/camera/QueueBase;, "Ltas/internal/camera/QueueBase<TT;>;"
    const-class v1, Ltas/internal/camera/QueueBase;

    monitor-enter v1

    .line 67
    :try_start_0
    iget v0, p0, Ltas/internal/camera/QueueBase;->mPausedCount:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Ltas/internal/camera/QueueBase;->mPausedCount:I

    .line 68
    iget v0, p0, Ltas/internal/camera/QueueBase;->mPausedCount:I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit v1

    return v0

    .line 66
    :catchall_0
    move-exception v0

    monitor-exit v1

    throw v0
.end method

.method public peekHead()Ljava/lang/Object;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TT;"
        }
    .end annotation

    .prologue
    .line 103
    .local p0, "this":Ltas/internal/camera/QueueBase;, "Ltas/internal/camera/QueueBase<TT;>;"
    iget-object v0, p0, Ltas/internal/camera/QueueBase;->mQueue:Ljava/util/Deque;

    invoke-interface {v0}, Ljava/util/Deque;->peek()Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method

.method public peekTail()Ljava/lang/Object;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TT;"
        }
    .end annotation

    .prologue
    .line 115
    .local p0, "this":Ltas/internal/camera/QueueBase;, "Ltas/internal/camera/QueueBase<TT;>;"
    iget-object v0, p0, Ltas/internal/camera/QueueBase;->mQueue:Ljava/util/Deque;

    invoke-interface {v0}, Ljava/util/Deque;->peekLast()Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method

.method public pollHead()Ljava/lang/Object;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TT;"
        }
    .end annotation

    .prologue
    .line 111
    .local p0, "this":Ltas/internal/camera/QueueBase;, "Ltas/internal/camera/QueueBase<TT;>;"
    iget-object v0, p0, Ltas/internal/camera/QueueBase;->mQueue:Ljava/util/Deque;

    invoke-interface {v0}, Ljava/util/Deque;->poll()Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method

.method public pollTail()Ljava/lang/Object;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TT;"
        }
    .end annotation

    .prologue
    .line 123
    .local p0, "this":Ltas/internal/camera/QueueBase;, "Ltas/internal/camera/QueueBase<TT;>;"
    iget-object v0, p0, Ltas/internal/camera/QueueBase;->mQueue:Ljava/util/Deque;

    invoke-interface {v0}, Ljava/util/Deque;->pollLast()Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method

.method public removeHead()Ljava/lang/Object;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TT;"
        }
    .end annotation

    .prologue
    .line 107
    .local p0, "this":Ltas/internal/camera/QueueBase;, "Ltas/internal/camera/QueueBase<TT;>;"
    iget-object v0, p0, Ltas/internal/camera/QueueBase;->mQueue:Ljava/util/Deque;

    invoke-interface {v0}, Ljava/util/Deque;->remove()Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method

.method public removeTail()Ljava/lang/Object;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TT;"
        }
    .end annotation

    .prologue
    .line 119
    .local p0, "this":Ltas/internal/camera/QueueBase;, "Ltas/internal/camera/QueueBase<TT;>;"
    iget-object v0, p0, Ltas/internal/camera/QueueBase;->mQueue:Ljava/util/Deque;

    invoke-interface {v0}, Ljava/util/Deque;->removeLast()Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method

.method public resume()I
    .locals 2

    .prologue
    .line 54
    .local p0, "this":Ltas/internal/camera/QueueBase;, "Ltas/internal/camera/QueueBase<TT;>;"
    const-class v1, Ltas/internal/camera/QueueBase;

    monitor-enter v1

    .line 55
    :try_start_0
    iget v0, p0, Ltas/internal/camera/QueueBase;->mPausedCount:I

    if-eqz v0, :cond_0

    .line 56
    iget v0, p0, Ltas/internal/camera/QueueBase;->mPausedCount:I

    add-int/lit8 v0, v0, -0x1

    iput v0, p0, Ltas/internal/camera/QueueBase;->mPausedCount:I

    .line 57
    iget v0, p0, Ltas/internal/camera/QueueBase;->mPausedCount:I

    if-nez v0, :cond_0

    .line 58
    invoke-direct {p0}, Ltas/internal/camera/QueueBase;->unlock()V

    .line 61
    :cond_0
    iget v0, p0, Ltas/internal/camera/QueueBase;->mPausedCount:I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit v1

    return v0

    .line 54
    :catchall_0
    move-exception v0

    monitor-exit v1

    throw v0
.end method

.method public setOnAvailableListener(Ltas/internal/camera/QueueBase$OnAvailableListener;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ltas/internal/camera/QueueBase$OnAvailableListener",
            "<TT;>;)V"
        }
    .end annotation

    .prologue
    .line 50
    .local p0, "this":Ltas/internal/camera/QueueBase;, "Ltas/internal/camera/QueueBase<TT;>;"
    .local p1, "l":Ltas/internal/camera/QueueBase$OnAvailableListener;, "Ltas/internal/camera/QueueBase$OnAvailableListener<TT;>;"
    iput-object p1, p0, Ltas/internal/camera/QueueBase;->mL:Ltas/internal/camera/QueueBase$OnAvailableListener;

    .line 49
    return-void
.end method

.method public size()I
    .locals 1

    .prologue
    .line 91
    .local p0, "this":Ltas/internal/camera/QueueBase;, "Ltas/internal/camera/QueueBase<TT;>;"
    iget-object v0, p0, Ltas/internal/camera/QueueBase;->mQueue:Ljava/util/Deque;

    invoke-interface {v0}, Ljava/util/Deque;->size()I

    move-result v0

    return v0
.end method
