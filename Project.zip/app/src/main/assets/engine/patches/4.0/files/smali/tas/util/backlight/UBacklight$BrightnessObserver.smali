.class public interface abstract Ltas/util/backlight/UBacklight$BrightnessObserver;
.super Ljava/lang/Object;
.source "UBacklight.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltas/util/backlight/UBacklight;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "BrightnessObserver"
.end annotation


# virtual methods
.method public abstract onUBrightnessRequested(I)V
.end method
