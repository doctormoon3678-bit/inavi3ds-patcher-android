.class public Ltas/ipc/MsgReceiverService;
.super Landroid/app/Service;
.source "MsgReceiverService.java"


# static fields
.field private static final DBG:Z = true

.field private static final TAG:Ljava/lang/String; = "TasIPC<ReceiverService>"


# instance fields
.field private mBinder:Landroid/os/IBinder;


# direct methods
.method public constructor <init>()V
    .locals 0

    .prologue
    .line 17
    invoke-direct {p0}, Landroid/app/Service;-><init>()V

    return-void
.end method


# virtual methods
.method public onBind(Landroid/content/Intent;)Landroid/os/IBinder;
    .locals 2
    .param p1, "intent"    # Landroid/content/Intent;

    .prologue
    .line 42
    const-string/jumbo v0, "TasIPC<ReceiverService>"

    const-string/jumbo v1, "bind"

    invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 43
    iget-object v0, p0, Ltas/ipc/MsgReceiverService;->mBinder:Landroid/os/IBinder;

    return-object v0
.end method

.method public onCreate()V
    .locals 2

    .prologue
    .line 26
    const-string/jumbo v0, "TasIPC<ReceiverService>"

    const-string/jumbo v1, "receiver is running."

    invoke-static {v0, v1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 27
    invoke-static {}, Ltas/internal/ipc/Receiver;->createServiceBinder()Landroid/os/IBinder;

    move-result-object v0

    iput-object v0, p0, Ltas/ipc/MsgReceiverService;->mBinder:Landroid/os/IBinder;

    .line 25
    return-void
.end method

.method public onDestroy()V
    .locals 2

    .prologue
    .line 37
    const-string/jumbo v0, "TasIPC<ReceiverService>"

    const-string/jumbo v1, "receiver is stopped."

    invoke-static {v0, v1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 36
    return-void
.end method

.method public onRebind(Landroid/content/Intent;)V
    .locals 2
    .param p1, "intent"    # Landroid/content/Intent;

    .prologue
    .line 48
    const-string/jumbo v0, "TasIPC<ReceiverService>"

    const-string/jumbo v1, "rebind"

    invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 47
    return-void
.end method

.method public onStartCommand(Landroid/content/Intent;II)I
    .locals 1
    .param p1, "intent"    # Landroid/content/Intent;
    .param p2, "flags"    # I
    .param p3, "startId"    # I

    .prologue
    .line 32
    const/4 v0, 0x1

    return v0
.end method

.method public onUnbind(Landroid/content/Intent;)Z
    .locals 2
    .param p1, "intent"    # Landroid/content/Intent;

    .prologue
    .line 53
    const-string/jumbo v0, "TasIPC<ReceiverService>"

    const-string/jumbo v1, "unbind"

    invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 54
    const/4 v0, 0x1

    return v0
.end method
