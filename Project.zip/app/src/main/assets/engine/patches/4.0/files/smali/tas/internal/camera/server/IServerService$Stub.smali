.class public abstract Ltas/internal/camera/server/IServerService$Stub;
.super Landroid/os/Binder;
.source "IServerService.java"

# interfaces
.implements Ltas/internal/camera/server/IServerService;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltas/internal/camera/server/IServerService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "Stub"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ltas/internal/camera/server/IServerService$Stub$Proxy;
    }
.end annotation


# static fields
.field private static final DESCRIPTOR:Ljava/lang/String; = "tas.internal.camera.server.IServerService"

.field static final TRANSACTION_cancel:I = 0x5

.field static final TRANSACTION_command:I = 0x6

.field static final TRANSACTION_request:I = 0x4

.field static final TRANSACTION_setcallback:I = 0x1

.field static final TRANSACTION_unwatch:I = 0x3

.field static final TRANSACTION_watch:I = 0x2


# direct methods
.method public constructor <init>()V
    .locals 1

    .prologue
    .line 13
    invoke-direct {p0}, Landroid/os/Binder;-><init>()V

    .line 15
    const-string/jumbo v0, "tas.internal.camera.server.IServerService"

    invoke-virtual {p0, p0, v0}, Ltas/internal/camera/server/IServerService$Stub;->attachInterface(Landroid/os/IInterface;Ljava/lang/String;)V

    .line 13
    return-void
.end method

.method public static asInterface(Landroid/os/IBinder;)Ltas/internal/camera/server/IServerService;
    .locals 2
    .param p0, "obj"    # Landroid/os/IBinder;

    .prologue
    const/4 v1, 0x0

    .line 23
    if-nez p0, :cond_0

    .line 24
    return-object v1

    .line 26
    :cond_0
    const-string/jumbo v1, "tas.internal.camera.server.IServerService"

    invoke-interface {p0, v1}, Landroid/os/IBinder;->queryLocalInterface(Ljava/lang/String;)Landroid/os/IInterface;

    move-result-object v0

    .line 27
    .local v0, "iin":Landroid/os/IInterface;
    if-eqz v0, :cond_1

    instance-of v1, v0, Ltas/internal/camera/server/IServerService;

    if-eqz v1, :cond_1

    .line 28
    check-cast v0, Ltas/internal/camera/server/IServerService;

    .end local v0    # "iin":Landroid/os/IInterface;
    return-object v0

    .line 30
    .restart local v0    # "iin":Landroid/os/IInterface;
    :cond_1
    new-instance v1, Ltas/internal/camera/server/IServerService$Stub$Proxy;

    invoke-direct {v1, p0}, Ltas/internal/camera/server/IServerService$Stub$Proxy;-><init>(Landroid/os/IBinder;)V

    return-object v1
.end method


# virtual methods
.method public asBinder()Landroid/os/IBinder;
    .locals 0

    .prologue
    .line 34
    return-object p0
.end method

.method public onTransact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    .locals 5
    .param p1, "code"    # I
    .param p2, "data"    # Landroid/os/Parcel;
    .param p3, "reply"    # Landroid/os/Parcel;
    .param p4, "flags"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .prologue
    const/4 v4, 0x1

    .line 38
    sparse-switch p1, :sswitch_data_0

    .line 127
    invoke-super {p0, p1, p2, p3, p4}, Landroid/os/Binder;->onTransact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z

    move-result v3

    return v3

    .line 42
    :sswitch_0
    const-string/jumbo v3, "tas.internal.camera.server.IServerService"

    invoke-virtual {p3, v3}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    .line 43
    return v4

    .line 47
    :sswitch_1
    const-string/jumbo v3, "tas.internal.camera.server.IServerService"

    invoke-virtual {p2, v3}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 49
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v3

    invoke-static {v3}, Ltas/internal/camera/server/IServerCallback$Stub;->asInterface(Landroid/os/IBinder;)Ltas/internal/camera/server/IServerCallback;

    move-result-object v0

    .line 50
    .local v0, "_arg0":Ltas/internal/camera/server/IServerCallback;
    invoke-virtual {p0, v0}, Ltas/internal/camera/server/IServerService$Stub;->setcallback(Ltas/internal/camera/server/IServerCallback;)V

    .line 51
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 52
    return v4

    .line 56
    .end local v0    # "_arg0":Ltas/internal/camera/server/IServerCallback;
    :sswitch_2
    const-string/jumbo v3, "tas.internal.camera.server.IServerService"

    invoke-virtual {p2, v3}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 58
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v3

    if-eqz v3, :cond_0

    .line 59
    sget-object v3, Ltas/internal/camera/server/RemoteMessage;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-interface {v3, p2}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ltas/internal/camera/server/RemoteMessage;

    .line 64
    :goto_0
    invoke-virtual {p0, v1}, Ltas/internal/camera/server/IServerService$Stub;->watch(Ltas/internal/camera/server/RemoteMessage;)V

    .line 65
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 66
    return v4

    .line 62
    :cond_0
    const/4 v1, 0x0

    .local v1, "_arg0":Ltas/internal/camera/server/RemoteMessage;
    goto :goto_0

    .line 70
    .end local v1    # "_arg0":Ltas/internal/camera/server/RemoteMessage;
    :sswitch_3
    const-string/jumbo v3, "tas.internal.camera.server.IServerService"

    invoke-virtual {p2, v3}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 72
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v3

    if-eqz v3, :cond_1

    .line 73
    sget-object v3, Ltas/internal/camera/server/RemoteMessage;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-interface {v3, p2}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ltas/internal/camera/server/RemoteMessage;

    .line 78
    :goto_1
    invoke-virtual {p0, v1}, Ltas/internal/camera/server/IServerService$Stub;->unwatch(Ltas/internal/camera/server/RemoteMessage;)V

    .line 79
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 80
    return v4

    .line 76
    :cond_1
    const/4 v1, 0x0

    .restart local v1    # "_arg0":Ltas/internal/camera/server/RemoteMessage;
    goto :goto_1

    .line 84
    .end local v1    # "_arg0":Ltas/internal/camera/server/RemoteMessage;
    :sswitch_4
    const-string/jumbo v3, "tas.internal.camera.server.IServerService"

    invoke-virtual {p2, v3}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 86
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v3

    if-eqz v3, :cond_2

    .line 87
    sget-object v3, Ltas/internal/camera/server/RemoteMessage;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-interface {v3, p2}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ltas/internal/camera/server/RemoteMessage;

    .line 92
    :goto_2
    invoke-virtual {p0, v1}, Ltas/internal/camera/server/IServerService$Stub;->request(Ltas/internal/camera/server/RemoteMessage;)I

    move-result v2

    .line 93
    .local v2, "_result":I
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 94
    invoke-virtual {p3, v2}, Landroid/os/Parcel;->writeInt(I)V

    .line 95
    return v4

    .line 90
    .end local v2    # "_result":I
    :cond_2
    const/4 v1, 0x0

    .restart local v1    # "_arg0":Ltas/internal/camera/server/RemoteMessage;
    goto :goto_2

    .line 99
    .end local v1    # "_arg0":Ltas/internal/camera/server/RemoteMessage;
    :sswitch_5
    const-string/jumbo v3, "tas.internal.camera.server.IServerService"

    invoke-virtual {p2, v3}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 101
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v3

    if-eqz v3, :cond_3

    .line 102
    sget-object v3, Ltas/internal/camera/server/RemoteMessage;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-interface {v3, p2}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ltas/internal/camera/server/RemoteMessage;

    .line 107
    :goto_3
    invoke-virtual {p0, v1}, Ltas/internal/camera/server/IServerService$Stub;->cancel(Ltas/internal/camera/server/RemoteMessage;)V

    .line 108
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 109
    return v4

    .line 105
    :cond_3
    const/4 v1, 0x0

    .restart local v1    # "_arg0":Ltas/internal/camera/server/RemoteMessage;
    goto :goto_3

    .line 113
    .end local v1    # "_arg0":Ltas/internal/camera/server/RemoteMessage;
    :sswitch_6
    const-string/jumbo v3, "tas.internal.camera.server.IServerService"

    invoke-virtual {p2, v3}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 115
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v3

    if-eqz v3, :cond_4

    .line 116
    sget-object v3, Ltas/internal/camera/server/RemoteMessage;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-interface {v3, p2}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ltas/internal/camera/server/RemoteMessage;

    .line 121
    :goto_4
    invoke-virtual {p0, v1}, Ltas/internal/camera/server/IServerService$Stub;->command(Ltas/internal/camera/server/RemoteMessage;)I

    move-result v2

    .line 122
    .restart local v2    # "_result":I
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 123
    invoke-virtual {p3, v2}, Landroid/os/Parcel;->writeInt(I)V

    .line 124
    return v4

    .line 119
    .end local v2    # "_result":I
    :cond_4
    const/4 v1, 0x0

    .restart local v1    # "_arg0":Ltas/internal/camera/server/RemoteMessage;
    goto :goto_4

    .line 38
    :sswitch_data_0
    .sparse-switch
        0x1 -> :sswitch_1
        0x2 -> :sswitch_2
        0x3 -> :sswitch_3
        0x4 -> :sswitch_4
        0x5 -> :sswitch_5
        0x6 -> :sswitch_6
        0x5f4e5446 -> :sswitch_0
    .end sparse-switch
.end method
