.class public interface abstract Ltas/camera/BaseListener;
.super Ljava/lang/Object;
.source "BaseListener.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ltas/camera/CameraId;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation
