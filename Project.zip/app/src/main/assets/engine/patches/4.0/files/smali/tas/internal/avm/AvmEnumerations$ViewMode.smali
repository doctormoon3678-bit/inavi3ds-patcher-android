.class public final enum Ltas/internal/avm/AvmEnumerations$ViewMode;
.super Ljava/lang/Enum;
.source "AvmEnumerations.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltas/internal/avm/AvmEnumerations;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "ViewMode"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum",
        "<",
        "Ltas/internal/avm/AvmEnumerations$ViewMode;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Ltas/internal/avm/AvmEnumerations$ViewMode;

.field public static final enum FULL_FRONT:Ltas/internal/avm/AvmEnumerations$ViewMode;

.field public static final enum FULL_LEFT:Ltas/internal/avm/AvmEnumerations$ViewMode;

.field public static final enum FULL_REAR:Ltas/internal/avm/AvmEnumerations$ViewMode;

.field public static final enum FULL_RIGHT:Ltas/internal/avm/AvmEnumerations$ViewMode;

.field public static final enum PIP_LEFT_REAR:Ltas/internal/avm/AvmEnumerations$ViewMode;

.field public static final enum PIP_RIGHT_REAR:Ltas/internal/avm/AvmEnumerations$ViewMode;

.field public static final enum PIP_TOP:Ltas/internal/avm/AvmEnumerations$ViewMode;

.field public static final enum TOP_FRONT:Ltas/internal/avm/AvmEnumerations$ViewMode;

.field public static final enum TOP_LEFT:Ltas/internal/avm/AvmEnumerations$ViewMode;

.field public static final enum TOP_REAR:Ltas/internal/avm/AvmEnumerations$ViewMode;

.field public static final enum TOP_RIGHT:Ltas/internal/avm/AvmEnumerations$ViewMode;

.field public static final enum TOP_SIDE:Ltas/internal/avm/AvmEnumerations$ViewMode;

.field public static final enum VIEW_UNKNOWN:Ltas/internal/avm/AvmEnumerations$ViewMode;


# instance fields
.field private mode:I


# direct methods
.method static constructor <clinit>()V
    .locals 9

    .prologue
    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v4, 0x1

    .line 96
    new-instance v0, Ltas/internal/avm/AvmEnumerations$ViewMode;

    const-string/jumbo v1, "TOP_REAR"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2, v4}, Ltas/internal/avm/AvmEnumerations$ViewMode;-><init>(Ljava/lang/String;II)V

    sput-object v0, Ltas/internal/avm/AvmEnumerations$ViewMode;->TOP_REAR:Ltas/internal/avm/AvmEnumerations$ViewMode;

    .line 97
    new-instance v0, Ltas/internal/avm/AvmEnumerations$ViewMode;

    const-string/jumbo v1, "TOP_FRONT"

    invoke-direct {v0, v1, v4, v5}, Ltas/internal/avm/AvmEnumerations$ViewMode;-><init>(Ljava/lang/String;II)V

    sput-object v0, Ltas/internal/avm/AvmEnumerations$ViewMode;->TOP_FRONT:Ltas/internal/avm/AvmEnumerations$ViewMode;

    .line 98
    new-instance v0, Ltas/internal/avm/AvmEnumerations$ViewMode;

    const-string/jumbo v1, "TOP_SIDE"

    invoke-direct {v0, v1, v5, v6}, Ltas/internal/avm/AvmEnumerations$ViewMode;-><init>(Ljava/lang/String;II)V

    sput-object v0, Ltas/internal/avm/AvmEnumerations$ViewMode;->TOP_SIDE:Ltas/internal/avm/AvmEnumerations$ViewMode;

    .line 99
    new-instance v0, Ltas/internal/avm/AvmEnumerations$ViewMode;

    const-string/jumbo v1, "FULL_FRONT"

    invoke-direct {v0, v1, v6, v7}, Ltas/internal/avm/AvmEnumerations$ViewMode;-><init>(Ljava/lang/String;II)V

    sput-object v0, Ltas/internal/avm/AvmEnumerations$ViewMode;->FULL_FRONT:Ltas/internal/avm/AvmEnumerations$ViewMode;

    .line 100
    new-instance v0, Ltas/internal/avm/AvmEnumerations$ViewMode;

    const-string/jumbo v1, "FULL_REAR"

    invoke-direct {v0, v1, v7, v8}, Ltas/internal/avm/AvmEnumerations$ViewMode;-><init>(Ljava/lang/String;II)V

    sput-object v0, Ltas/internal/avm/AvmEnumerations$ViewMode;->FULL_REAR:Ltas/internal/avm/AvmEnumerations$ViewMode;

    .line 101
    new-instance v0, Ltas/internal/avm/AvmEnumerations$ViewMode;

    const-string/jumbo v1, "TOP_LEFT"

    const/4 v2, 0x6

    invoke-direct {v0, v1, v8, v2}, Ltas/internal/avm/AvmEnumerations$ViewMode;-><init>(Ljava/lang/String;II)V

    sput-object v0, Ltas/internal/avm/AvmEnumerations$ViewMode;->TOP_LEFT:Ltas/internal/avm/AvmEnumerations$ViewMode;

    .line 102
    new-instance v0, Ltas/internal/avm/AvmEnumerations$ViewMode;

    const-string/jumbo v1, "TOP_RIGHT"

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-direct {v0, v1, v2, v3}, Ltas/internal/avm/AvmEnumerations$ViewMode;-><init>(Ljava/lang/String;II)V

    sput-object v0, Ltas/internal/avm/AvmEnumerations$ViewMode;->TOP_RIGHT:Ltas/internal/avm/AvmEnumerations$ViewMode;

    .line 103
    new-instance v0, Ltas/internal/avm/AvmEnumerations$ViewMode;

    const-string/jumbo v1, "FULL_LEFT"

    const/4 v2, 0x7

    const/16 v3, 0x8

    invoke-direct {v0, v1, v2, v3}, Ltas/internal/avm/AvmEnumerations$ViewMode;-><init>(Ljava/lang/String;II)V

    sput-object v0, Ltas/internal/avm/AvmEnumerations$ViewMode;->FULL_LEFT:Ltas/internal/avm/AvmEnumerations$ViewMode;

    .line 104
    new-instance v0, Ltas/internal/avm/AvmEnumerations$ViewMode;

    const-string/jumbo v1, "FULL_RIGHT"

    const/16 v2, 0x8

    const/16 v3, 0x9

    invoke-direct {v0, v1, v2, v3}, Ltas/internal/avm/AvmEnumerations$ViewMode;-><init>(Ljava/lang/String;II)V

    sput-object v0, Ltas/internal/avm/AvmEnumerations$ViewMode;->FULL_RIGHT:Ltas/internal/avm/AvmEnumerations$ViewMode;

    .line 105
    new-instance v0, Ltas/internal/avm/AvmEnumerations$ViewMode;

    const-string/jumbo v1, "PIP_RIGHT_REAR"

    const/16 v2, 0x9

    const/16 v3, 0xa

    invoke-direct {v0, v1, v2, v3}, Ltas/internal/avm/AvmEnumerations$ViewMode;-><init>(Ljava/lang/String;II)V

    sput-object v0, Ltas/internal/avm/AvmEnumerations$ViewMode;->PIP_RIGHT_REAR:Ltas/internal/avm/AvmEnumerations$ViewMode;

    .line 106
    new-instance v0, Ltas/internal/avm/AvmEnumerations$ViewMode;

    const-string/jumbo v1, "PIP_LEFT_REAR"

    const/16 v2, 0xa

    const/16 v3, 0xb

    invoke-direct {v0, v1, v2, v3}, Ltas/internal/avm/AvmEnumerations$ViewMode;-><init>(Ljava/lang/String;II)V

    sput-object v0, Ltas/internal/avm/AvmEnumerations$ViewMode;->PIP_LEFT_REAR:Ltas/internal/avm/AvmEnumerations$ViewMode;

    .line 107
    new-instance v0, Ltas/internal/avm/AvmEnumerations$ViewMode;

    const-string/jumbo v1, "PIP_TOP"

    const/16 v2, 0xb

    const/16 v3, 0xc

    invoke-direct {v0, v1, v2, v3}, Ltas/internal/avm/AvmEnumerations$ViewMode;-><init>(Ljava/lang/String;II)V

    sput-object v0, Ltas/internal/avm/AvmEnumerations$ViewMode;->PIP_TOP:Ltas/internal/avm/AvmEnumerations$ViewMode;

    .line 108
    new-instance v0, Ltas/internal/avm/AvmEnumerations$ViewMode;

    const-string/jumbo v1, "VIEW_UNKNOWN"

    const/16 v2, 0xc

    const/4 v3, -0x1

    invoke-direct {v0, v1, v2, v3}, Ltas/internal/avm/AvmEnumerations$ViewMode;-><init>(Ljava/lang/String;II)V

    sput-object v0, Ltas/internal/avm/AvmEnumerations$ViewMode;->VIEW_UNKNOWN:Ltas/internal/avm/AvmEnumerations$ViewMode;

    .line 95
    const/16 v0, 0xd

    new-array v0, v0, [Ltas/internal/avm/AvmEnumerations$ViewMode;

    sget-object v1, Ltas/internal/avm/AvmEnumerations$ViewMode;->TOP_REAR:Ltas/internal/avm/AvmEnumerations$ViewMode;

    const/4 v2, 0x0

    aput-object v1, v0, v2

    sget-object v1, Ltas/internal/avm/AvmEnumerations$ViewMode;->TOP_FRONT:Ltas/internal/avm/AvmEnumerations$ViewMode;

    aput-object v1, v0, v4

    sget-object v1, Ltas/internal/avm/AvmEnumerations$ViewMode;->TOP_SIDE:Ltas/internal/avm/AvmEnumerations$ViewMode;

    aput-object v1, v0, v5

    sget-object v1, Ltas/internal/avm/AvmEnumerations$ViewMode;->FULL_FRONT:Ltas/internal/avm/AvmEnumerations$ViewMode;

    aput-object v1, v0, v6

    sget-object v1, Ltas/internal/avm/AvmEnumerations$ViewMode;->FULL_REAR:Ltas/internal/avm/AvmEnumerations$ViewMode;

    aput-object v1, v0, v7

    sget-object v1, Ltas/internal/avm/AvmEnumerations$ViewMode;->TOP_LEFT:Ltas/internal/avm/AvmEnumerations$ViewMode;

    aput-object v1, v0, v8

    sget-object v1, Ltas/internal/avm/AvmEnumerations$ViewMode;->TOP_RIGHT:Ltas/internal/avm/AvmEnumerations$ViewMode;

    const/4 v2, 0x6

    aput-object v1, v0, v2

    sget-object v1, Ltas/internal/avm/AvmEnumerations$ViewMode;->FULL_LEFT:Ltas/internal/avm/AvmEnumerations$ViewMode;

    const/4 v2, 0x7

    aput-object v1, v0, v2

    sget-object v1, Ltas/internal/avm/AvmEnumerations$ViewMode;->FULL_RIGHT:Ltas/internal/avm/AvmEnumerations$ViewMode;

    const/16 v2, 0x8

    aput-object v1, v0, v2

    sget-object v1, Ltas/internal/avm/AvmEnumerations$ViewMode;->PIP_RIGHT_REAR:Ltas/internal/avm/AvmEnumerations$ViewMode;

    const/16 v2, 0x9

    aput-object v1, v0, v2

    sget-object v1, Ltas/internal/avm/AvmEnumerations$ViewMode;->PIP_LEFT_REAR:Ltas/internal/avm/AvmEnumerations$ViewMode;

    const/16 v2, 0xa

    aput-object v1, v0, v2

    sget-object v1, Ltas/internal/avm/AvmEnumerations$ViewMode;->PIP_TOP:Ltas/internal/avm/AvmEnumerations$ViewMode;

    const/16 v2, 0xb

    aput-object v1, v0, v2

    sget-object v1, Ltas/internal/avm/AvmEnumerations$ViewMode;->VIEW_UNKNOWN:Ltas/internal/avm/AvmEnumerations$ViewMode;

    const/16 v2, 0xc

    aput-object v1, v0, v2

    sput-object v0, Ltas/internal/avm/AvmEnumerations$ViewMode;->$VALUES:[Ltas/internal/avm/AvmEnumerations$ViewMode;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .locals 0
    .param p3, "mode"    # I

    .prologue
    .line 111
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 112
    iput p3, p0, Ltas/internal/avm/AvmEnumerations$ViewMode;->mode:I

    .line 111
    return-void
.end method

.method public static createFromValue(I)Ltas/internal/avm/AvmEnumerations$ViewMode;
    .locals 5
    .param p0, "mode"    # I

    .prologue
    .line 126
    invoke-static {}, Ltas/internal/avm/AvmEnumerations$ViewMode;->values()[Ltas/internal/avm/AvmEnumerations$ViewMode;

    move-result-object v2

    const/4 v1, 0x0

    array-length v3, v2

    :goto_0
    if-ge v1, v3, :cond_1

    aget-object v0, v2, v1

    .line 127
    .local v0, "i":Ltas/internal/avm/AvmEnumerations$ViewMode;
    invoke-virtual {v0}, Ltas/internal/avm/AvmEnumerations$ViewMode;->toInteger()I

    move-result v4

    if-ne v4, p0, :cond_0

    .line 128
    return-object v0

    .line 126
    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    .line 131
    .end local v0    # "i":Ltas/internal/avm/AvmEnumerations$ViewMode;
    :cond_1
    sget-object v1, Ltas/internal/avm/AvmEnumerations$ViewMode;->VIEW_UNKNOWN:Ltas/internal/avm/AvmEnumerations$ViewMode;

    return-object v1
.end method

.method public static getRandomForTest()Ltas/internal/avm/AvmEnumerations$ViewMode;
    .locals 4

    .prologue
    .line 120
    invoke-static {}, Ljava/util/concurrent/ThreadLocalRandom;->current()Ljava/util/concurrent/ThreadLocalRandom;

    move-result-object v1

    .line 121
    .local v1, "random":Ljava/util/concurrent/ThreadLocalRandom;
    const/4 v2, 0x1

    const/16 v3, 0xc

    invoke-virtual {v1, v2, v3}, Ljava/util/concurrent/ThreadLocalRandom;->nextInt(II)I

    move-result v0

    .line 122
    .local v0, "rand":I
    invoke-static {v0}, Ltas/internal/avm/AvmEnumerations$ViewMode;->createFromValue(I)Ltas/internal/avm/AvmEnumerations$ViewMode;

    move-result-object v2

    return-object v2
.end method

.method public static valueOf(Ljava/lang/String;)Ltas/internal/avm/AvmEnumerations$ViewMode;
    .locals 1
    .param p0, "name"    # Ljava/lang/String;

    .prologue
    .line 95
    const-class v0, Ltas/internal/avm/AvmEnumerations$ViewMode;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object v0

    check-cast v0, Ltas/internal/avm/AvmEnumerations$ViewMode;

    return-object v0
.end method

.method public static values()[Ltas/internal/avm/AvmEnumerations$ViewMode;
    .locals 1

    .prologue
    .line 95
    sget-object v0, Ltas/internal/avm/AvmEnumerations$ViewMode;->$VALUES:[Ltas/internal/avm/AvmEnumerations$ViewMode;

    return-object v0
.end method


# virtual methods
.method public toInteger()I
    .locals 1

    .prologue
    .line 116
    iget v0, p0, Ltas/internal/avm/AvmEnumerations$ViewMode;->mode:I

    return v0
.end method
