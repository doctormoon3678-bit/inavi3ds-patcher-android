.class public Ltas/camera/id/AR;
.super Ltas/camera/CameraId;
.source "AR.java"


# static fields
.field public static final DUMP_REGISTERS:I = 0x7d2

.field public static final RESET:I = 0x7d1


# instance fields
.field private final proxy:Ltas/internal/camera/client/CameraProxy;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ltas/internal/camera/client/CameraProxy",
            "<",
            "Ltas/camera/id/AR;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 1
    .param p1, "context"    # Landroid/content/Context;

    .prologue
    .line 25
    invoke-direct {p0}, Ltas/camera/CameraId;-><init>()V

    .line 26
    new-instance v0, Ltas/internal/camera/client/CameraProxy;

    invoke-direct {v0, p1, p0}, Ltas/internal/camera/client/CameraProxy;-><init>(Landroid/content/Context;Ltas/camera/CameraId;)V

    iput-object v0, p0, Ltas/camera/id/AR;->proxy:Ltas/internal/camera/client/CameraProxy;

    .line 25
    return-void
.end method


# virtual methods
.method protected proxy()Ltas/internal/camera/client/CameraProxy;
    .locals 1

    .prologue
    .line 30
    iget-object v0, p0, Ltas/camera/id/AR;->proxy:Ltas/internal/camera/client/CameraProxy;

    return-object v0
.end method

.method public setListener(Ltas/camera/BaseListener;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ltas/camera/BaseListener",
            "<",
            "Ltas/camera/id/AR;",
            ">;)V"
        }
    .end annotation

    .prologue
    .line 34
    .local p1, "l":Ltas/camera/BaseListener;, "Ltas/camera/BaseListener<Ltas/camera/id/AR;>;"
    iget-object v0, p0, Ltas/camera/id/AR;->proxy:Ltas/internal/camera/client/CameraProxy;

    invoke-virtual {v0, p1}, Ltas/internal/camera/client/CameraProxy;->setListener(Ltas/camera/BaseListener;)V

    .line 33
    return-void
.end method
