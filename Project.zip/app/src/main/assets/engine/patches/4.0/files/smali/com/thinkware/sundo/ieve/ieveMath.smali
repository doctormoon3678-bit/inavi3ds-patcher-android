.class public Lcom/thinkware/sundo/ieve/ieveMath;
.super Ljava/lang/Object;
.source "ieveMath.java"


# direct methods
.method public constructor <init>()V
    .locals 0

    .prologue
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static ROUND_DOWN(F)I
    .locals 2
    .param p0, "v"    # F

    .prologue
    const/4 v0, 0x0

    .line 5
    cmpg-float v1, p0, v0

    if-gez v1, :cond_0

    const/high16 v0, 0x3f800000    # 1.0f

    :cond_0
    sub-float v0, p0, v0

    float-to-int v0, v0

    return v0
.end method

.method public static ROUND_DOWN(D)J
    .locals 4
    .param p0, "v"    # D

    .prologue
    const-wide/16 v0, 0x0

    .line 9
    cmpg-double v2, p0, v0

    if-gez v2, :cond_0

    const-wide/high16 v0, 0x3ff0000000000000L    # 1.0

    :cond_0
    sub-double v0, p0, v0

    double-to-long v0, v0

    return-wide v0
.end method

.method public static ROUND_OFF(F)I
    .locals 1
    .param p0, "v"    # F

    .prologue
    .line 13
    invoke-static {p0}, Ljava/lang/Math;->round(F)I

    move-result v0

    return v0
.end method

.method public static ROUND_OFF(D)J
    .locals 2
    .param p0, "v"    # D

    .prologue
    .line 17
    invoke-static {p0, p1}, Ljava/lang/Math;->round(D)J

    move-result-wide v0

    return-wide v0
.end method

.method public static ROUND_UP(F)I
    .locals 2
    .param p0, "v"    # F

    .prologue
    const/4 v0, 0x0

    .line 21
    cmpl-float v1, p0, v0

    if-lez v1, :cond_0

    const/high16 v0, 0x3f800000    # 1.0f

    :cond_0
    add-float/2addr v0, p0

    float-to-int v0, v0

    return v0
.end method

.method public static ROUND_UP(D)J
    .locals 4
    .param p0, "v"    # D

    .prologue
    const-wide/16 v0, 0x0

    .line 25
    cmpl-double v2, p0, v0

    if-lez v2, :cond_0

    const-wide/high16 v0, 0x3ff0000000000000L    # 1.0

    :cond_0
    add-double/2addr v0, p0

    double-to-long v0, v0

    return-wide v0
.end method

.method public static WIDTH4(I)I
    .locals 1
    .param p0, "width"    # I

    .prologue
    .line 29
    add-int/lit8 v0, p0, 0x3

    and-int/lit8 v0, v0, -0x4

    return v0
.end method

.method public static WIDTH4CH(II)I
    .locals 1
    .param p0, "width"    # I
    .param p1, "channel"    # I

    .prologue
    .line 33
    mul-int v0, p0, p1

    add-int/lit8 v0, v0, 0x3

    and-int/lit8 v0, v0, -0x4

    return v0
.end method
