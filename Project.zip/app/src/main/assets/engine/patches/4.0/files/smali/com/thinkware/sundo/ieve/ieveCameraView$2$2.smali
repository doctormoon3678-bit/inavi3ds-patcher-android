.class Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;
.super Landroid/os/AsyncTask;
.source "ieveCameraView.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Landroid/os/AsyncTask",
        "<",
        "Ljava/lang/Void;",
        "Ljava/lang/Void;",
        "Ljava/lang/Boolean;",
        ">;"
    }
.end annotation


# instance fields
.field protected a:Landroid/media/MediaCodec$BufferInfo;

.field final synthetic b:Lcom/thinkware/sundo/ieve/ieveCameraView$2;

.field private c:Z

.field private d:I

.field private e:I

.field private f:Landroid/media/MediaMuxer;

.field private g:Ljava/lang/String;

.field private h:Landroid/media/MediaCodec;

.field private i:Landroid/media/MediaFormat;

.field private j:Ljava/io/FileOutputStream;


# direct methods
.method constructor <init>(Lcom/thinkware/sundo/ieve/ieveCameraView$2;)V
    .locals 2

    .prologue
    const/4 v1, 0x0

    .line 1
    iput-object p1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->b:Lcom/thinkware/sundo/ieve/ieveCameraView$2;

    .line 675
    invoke-direct {p0}, Landroid/os/AsyncTask;-><init>()V

    .line 676
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->c:Z

    .line 677
    const/4 v0, 0x0

    iput v0, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->d:I

    .line 678
    const/4 v0, -0x1

    iput v0, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->e:I

    .line 679
    iput-object v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->f:Landroid/media/MediaMuxer;

    .line 681
    iput-object v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->g:Ljava/lang/String;

    .line 682
    iput-object v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->h:Landroid/media/MediaCodec;

    .line 683
    iput-object v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->i:Landroid/media/MediaFormat;

    .line 685
    iput-object v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->a:Landroid/media/MediaCodec$BufferInfo;

    .line 686
    iput-object v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->j:Ljava/io/FileOutputStream;

    return-void
.end method

.method private a(ID)J
    .locals 4
    .param p1, "frameIndex"    # I
    .param p2, "fps"    # D

    .prologue
    .line 786
    iget-boolean v0, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->c:Z

    if-eqz v0, :cond_1

    .line 787
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->b:Lcom/thinkware/sundo/ieve/ieveCameraView$2;

    invoke-static {v0}, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a(Lcom/thinkware/sundo/ieve/ieveCameraView$2;)Lcom/thinkware/sundo/ieve/ieveCameraView;

    move-result-object v0

    invoke-static {v0}, Lcom/thinkware/sundo/ieve/ieveCameraView;->x(Lcom/thinkware/sundo/ieve/ieveCameraView;)Landroid/content/Context;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v0

    const-string v1, "com.thinkware.inavi3ds"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 788
    int-to-double v0, p1

    const-wide v2, 0x411e910000000000L    # 500800.0

    mul-double/2addr v0, v2

    div-double/2addr v0, p2

    double-to-long v0, v0

    .line 796
    :goto_0
    return-wide v0

    .line 791
    :cond_0
    int-to-double v0, p1

    const-wide v2, 0x4120c8e000000000L    # 550000.0

    mul-double/2addr v0, v2

    div-double/2addr v0, p2

    double-to-long v0, v0

    goto :goto_0

    .line 796
    :cond_1
    const-wide v0, 0x4060800000000000L    # 132.0

    const v2, 0xf4240

    mul-int/2addr v2, p1

    int-to-double v2, v2

    div-double/2addr v2, p2

    add-double/2addr v0, v2

    double-to-long v0, v0

    goto :goto_0
.end method

.method private a(Ljava/lang/String;)Landroid/media/MediaCodecInfo;
    .locals 9
    .param p1, "mimeType"    # Ljava/lang/String;

    .prologue
    const/4 v5, 0x0

    .line 894
    invoke-static {}, Landroid/media/MediaCodecList;->getCodecCount()I

    move-result v2

    .line 895
    .local v2, "numCodecs":I
    const/4 v1, 0x0

    .local v1, "i":I
    :goto_0
    if-lt v1, v2, :cond_0

    .line 905
    const/4 v0, 0x0

    :goto_1
    return-object v0

    .line 896
    :cond_0
    invoke-static {v1}, Landroid/media/MediaCodecList;->getCodecInfoAt(I)Landroid/media/MediaCodecInfo;

    move-result-object v0

    .line 897
    .local v0, "codecInfo":Landroid/media/MediaCodecInfo;
    invoke-virtual {v0}, Landroid/media/MediaCodecInfo;->isEncoder()Z

    move-result v4

    if-nez v4, :cond_2

    .line 895
    :cond_1
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    .line 898
    :cond_2
    invoke-virtual {v0}, Landroid/media/MediaCodecInfo;->getSupportedTypes()[Ljava/lang/String;

    move-result-object v6

    array-length v7, v6

    move v4, v5

    :goto_2
    if-ge v4, v7, :cond_1

    aget-object v3, v6, v4

    .line 899
    .local v3, "types":Ljava/lang/String;
    invoke-virtual {v3, p1}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v8

    if-eqz v8, :cond_3

    .line 900
    invoke-static {}, Lcom/thinkware/sundo/ieve/ieveCameraView;->a()Ljava/lang/String;

    move-result-object v4

    const-string v6, "saveStream:selectCodec[%s]"

    const/4 v7, 0x1

    new-array v7, v7, [Ljava/lang/Object;

    invoke-virtual {v0}, Landroid/media/MediaCodecInfo;->getName()Ljava/lang/String;

    move-result-object v8

    aput-object v8, v7, v5

    invoke-static {v6, v7}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v5

    invoke-static {v4, v5}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_1

    .line 898
    :cond_3
    add-int/lit8 v4, v4, 0x1

    goto :goto_2
.end method


# virtual methods
.method protected varargs a([Ljava/lang/Void;)Ljava/lang/Boolean;
    .locals 13
    .param p1, "params"    # [Ljava/lang/Void;

    .prologue
    const/4 v12, 0x0

    const/4 v11, 0x1

    const/4 v10, 0x0

    .line 941
    invoke-static {}, Lcom/thinkware/sundo/ieve/ieveCameraView;->a()Ljava/lang/String;

    move-result-object v5

    const-string v6, "saveStream:doInBackground[Run taking stream...]"

    invoke-static {v5, v6}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 942
    const/4 v4, 0x1

    .line 944
    .local v4, "success_encode":Z
    :try_start_0
    invoke-virtual {p0}, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->a()Z

    move-result v5

    if-nez v5, :cond_0

    .line 945
    invoke-static {}, Lcom/thinkware/sundo/ieve/ieveCameraView;->a()Ljava/lang/String;

    move-result-object v5

    const-string v6, "saveStream:doInBackground[createEncoder is false]"

    invoke-static {v5, v6}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 946
    const/4 v5, 0x0

    invoke-static {v5}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    move-result-object v5

    .line 1072
    :goto_0
    return-object v5

    .line 948
    :catch_0
    move-exception v1

    .line 949
    .local v1, "e":Ljava/io/IOException;
    invoke-virtual {v1}, Ljava/io/IOException;->printStackTrace()V

    .line 950
    invoke-static {}, Lcom/thinkware/sundo/ieve/ieveCameraView;->a()Ljava/lang/String;

    move-result-object v5

    const-string v6, "saveStream:doInBackground[IOException:%s]"

    new-array v7, v11, [Ljava/lang/Object;

    invoke-virtual {v1}, Ljava/io/IOException;->getLocalizedMessage()Ljava/lang/String;

    move-result-object v8

    aput-object v8, v7, v10

    invoke-static {v6, v7}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v5, v6}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 951
    invoke-static {v10}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v5

    goto :goto_0

    .line 954
    .end local v1    # "e":Ljava/io/IOException;
    :cond_0
    :try_start_1
    iget-boolean v5, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->c:Z

    if-eqz v5, :cond_9

    .line 955
    invoke-static {}, Lcom/thinkware/sundo/ieve/ieveCameraView;->a()Ljava/lang/String;

    move-result-object v5

    const-string v6, "saveStream:doInBackground[mUseMuxer is true]"

    invoke-static {v5, v6}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_1
    .catch Ljava/io/FileNotFoundException; {:try_start_1 .. :try_end_1} :catch_2
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 957
    :try_start_2
    new-instance v5, Landroid/media/MediaMuxer;

    iget-object v6, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->g:Ljava/lang/String;

    const/4 v7, 0x0

    invoke-direct {v5, v6, v7}, Landroid/media/MediaMuxer;-><init>(Ljava/lang/String;I)V

    iput-object v5, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->f:Landroid/media/MediaMuxer;
    :try_end_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_1
    .catch Ljava/io/FileNotFoundException; {:try_start_2 .. :try_end_2} :catch_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 970
    :goto_1
    :try_start_3
    invoke-static {}, Lcom/thinkware/sundo/ieve/ieveCameraView;->a()Ljava/lang/String;

    move-result-object v5

    const-string v6, "saveStream:doInBackground[mStreamBufferBefore.size(): %d]"

    const/4 v7, 0x1

    new-array v7, v7, [Ljava/lang/Object;

    const/4 v8, 0x0

    iget-object v9, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->b:Lcom/thinkware/sundo/ieve/ieveCameraView$2;

    invoke-static {v9}, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a(Lcom/thinkware/sundo/ieve/ieveCameraView$2;)Lcom/thinkware/sundo/ieve/ieveCameraView;

    move-result-object v9

    invoke-static {v9}, Lcom/thinkware/sundo/ieve/ieveCameraView;->m(Lcom/thinkware/sundo/ieve/ieveCameraView;)Ljava/util/Vector;

    move-result-object v9

    invoke-virtual {v9}, Ljava/util/Vector;->size()I

    move-result v9

    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    aput-object v9, v7, v8

    invoke-static {v6, v7}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v5, v6}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 971
    const/4 v0, 0x0

    .line 972
    .local v0, "data_nv12":[B
    :goto_2
    iget-object v5, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->b:Lcom/thinkware/sundo/ieve/ieveCameraView$2;

    invoke-static {v5}, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a(Lcom/thinkware/sundo/ieve/ieveCameraView$2;)Lcom/thinkware/sundo/ieve/ieveCameraView;

    move-result-object v5

    invoke-static {v5}, Lcom/thinkware/sundo/ieve/ieveCameraView;->m(Lcom/thinkware/sundo/ieve/ieveCameraView;)Ljava/util/Vector;

    move-result-object v5

    if-eqz v5, :cond_1

    iget-object v5, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->b:Lcom/thinkware/sundo/ieve/ieveCameraView$2;

    invoke-static {v5}, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a(Lcom/thinkware/sundo/ieve/ieveCameraView$2;)Lcom/thinkware/sundo/ieve/ieveCameraView;

    move-result-object v5

    invoke-static {v5}, Lcom/thinkware/sundo/ieve/ieveCameraView;->m(Lcom/thinkware/sundo/ieve/ieveCameraView;)Ljava/util/Vector;

    move-result-object v5

    invoke-virtual {v5}, Ljava/util/Vector;->size()I

    move-result v5

    if-gtz v5, :cond_c

    .line 993
    :cond_1
    :goto_3
    iget-object v5, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->b:Lcom/thinkware/sundo/ieve/ieveCameraView$2;

    invoke-static {v5}, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a(Lcom/thinkware/sundo/ieve/ieveCameraView$2;)Lcom/thinkware/sundo/ieve/ieveCameraView;

    move-result-object v5

    invoke-static {v5}, Lcom/thinkware/sundo/ieve/ieveCameraView;->m(Lcom/thinkware/sundo/ieve/ieveCameraView;)Ljava/util/Vector;

    move-result-object v5

    if-eqz v5, :cond_2

    .line 994
    iget-object v5, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->b:Lcom/thinkware/sundo/ieve/ieveCameraView$2;

    invoke-static {v5}, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a(Lcom/thinkware/sundo/ieve/ieveCameraView$2;)Lcom/thinkware/sundo/ieve/ieveCameraView;

    move-result-object v5

    invoke-static {v5}, Lcom/thinkware/sundo/ieve/ieveCameraView;->m(Lcom/thinkware/sundo/ieve/ieveCameraView;)Ljava/util/Vector;

    move-result-object v5

    invoke-virtual {v5}, Ljava/util/Vector;->clear()V

    .line 995
    invoke-static {}, Lcom/thinkware/sundo/ieve/ieveCameraView;->a()Ljava/lang/String;

    move-result-object v5

    const-string v6, "saveStream:doInBackground[mStreamBufferBefore.clear]"

    invoke-static {v5, v6}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 997
    :cond_2
    :goto_4
    iget-object v5, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->b:Lcom/thinkware/sundo/ieve/ieveCameraView$2;

    invoke-static {v5}, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a(Lcom/thinkware/sundo/ieve/ieveCameraView$2;)Lcom/thinkware/sundo/ieve/ieveCameraView;

    move-result-object v5

    invoke-static {v5}, Lcom/thinkware/sundo/ieve/ieveCameraView;->k(Lcom/thinkware/sundo/ieve/ieveCameraView;)Ljava/util/Vector;

    move-result-object v5

    if-eqz v5, :cond_3

    iget-object v5, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->b:Lcom/thinkware/sundo/ieve/ieveCameraView$2;

    invoke-static {v5}, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a(Lcom/thinkware/sundo/ieve/ieveCameraView$2;)Lcom/thinkware/sundo/ieve/ieveCameraView;

    move-result-object v5

    invoke-static {v5}, Lcom/thinkware/sundo/ieve/ieveCameraView;->k(Lcom/thinkware/sundo/ieve/ieveCameraView;)Ljava/util/Vector;

    move-result-object v5

    invoke-virtual {v5}, Ljava/util/Vector;->size()I

    move-result v5

    iget-object v6, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->b:Lcom/thinkware/sundo/ieve/ieveCameraView$2;

    invoke-static {v6}, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a(Lcom/thinkware/sundo/ieve/ieveCameraView$2;)Lcom/thinkware/sundo/ieve/ieveCameraView;

    move-result-object v6

    invoke-static {v6}, Lcom/thinkware/sundo/ieve/ieveCameraView;->l(Lcom/thinkware/sundo/ieve/ieveCameraView;)I

    move-result v6

    if-ne v5, v6, :cond_12

    .line 1007
    :cond_3
    :goto_5
    iget-object v5, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->b:Lcom/thinkware/sundo/ieve/ieveCameraView$2;

    invoke-static {v5}, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a(Lcom/thinkware/sundo/ieve/ieveCameraView$2;)Lcom/thinkware/sundo/ieve/ieveCameraView;

    move-result-object v5

    const/4 v6, 0x1

    invoke-static {v5, v6}, Lcom/thinkware/sundo/ieve/ieveCameraView;->d(Lcom/thinkware/sundo/ieve/ieveCameraView;Z)V

    .line 1010
    iget-object v5, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->b:Lcom/thinkware/sundo/ieve/ieveCameraView$2;

    invoke-static {v5}, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a(Lcom/thinkware/sundo/ieve/ieveCameraView$2;)Lcom/thinkware/sundo/ieve/ieveCameraView;

    move-result-object v5

    invoke-static {v5}, Lcom/thinkware/sundo/ieve/ieveCameraView;->k(Lcom/thinkware/sundo/ieve/ieveCameraView;)Ljava/util/Vector;

    move-result-object v5

    if-eqz v5, :cond_4

    .line 1011
    invoke-static {}, Lcom/thinkware/sundo/ieve/ieveCameraView;->a()Ljava/lang/String;

    move-result-object v5

    const-string v6, "saveStream:doInBackground[mStreamBufferAfter.size() : %d]"

    const/4 v7, 0x1

    new-array v7, v7, [Ljava/lang/Object;

    const/4 v8, 0x0

    iget-object v9, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->b:Lcom/thinkware/sundo/ieve/ieveCameraView$2;

    invoke-static {v9}, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a(Lcom/thinkware/sundo/ieve/ieveCameraView$2;)Lcom/thinkware/sundo/ieve/ieveCameraView;

    move-result-object v9

    invoke-static {v9}, Lcom/thinkware/sundo/ieve/ieveCameraView;->k(Lcom/thinkware/sundo/ieve/ieveCameraView;)Ljava/util/Vector;

    move-result-object v9

    invoke-virtual {v9}, Ljava/util/Vector;->size()I

    move-result v9

    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    aput-object v9, v7, v8

    invoke-static {v6, v7}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v5, v6}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 1013
    :cond_4
    :goto_6
    iget-object v5, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->b:Lcom/thinkware/sundo/ieve/ieveCameraView$2;

    invoke-static {v5}, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a(Lcom/thinkware/sundo/ieve/ieveCameraView$2;)Lcom/thinkware/sundo/ieve/ieveCameraView;

    move-result-object v5

    invoke-static {v5}, Lcom/thinkware/sundo/ieve/ieveCameraView;->k(Lcom/thinkware/sundo/ieve/ieveCameraView;)Ljava/util/Vector;

    move-result-object v5

    if-eqz v5, :cond_5

    iget-object v5, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->b:Lcom/thinkware/sundo/ieve/ieveCameraView$2;

    invoke-static {v5}, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a(Lcom/thinkware/sundo/ieve/ieveCameraView$2;)Lcom/thinkware/sundo/ieve/ieveCameraView;

    move-result-object v5

    invoke-static {v5}, Lcom/thinkware/sundo/ieve/ieveCameraView;->k(Lcom/thinkware/sundo/ieve/ieveCameraView;)Ljava/util/Vector;

    move-result-object v5

    invoke-virtual {v5}, Ljava/util/Vector;->size()I

    move-result v5

    if-gtz v5, :cond_13

    .line 1033
    :cond_5
    :goto_7
    iget-object v5, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->b:Lcom/thinkware/sundo/ieve/ieveCameraView$2;

    invoke-static {v5}, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a(Lcom/thinkware/sundo/ieve/ieveCameraView$2;)Lcom/thinkware/sundo/ieve/ieveCameraView;

    move-result-object v5

    invoke-static {v5}, Lcom/thinkware/sundo/ieve/ieveCameraView;->k(Lcom/thinkware/sundo/ieve/ieveCameraView;)Ljava/util/Vector;

    move-result-object v5

    if-eqz v5, :cond_6

    .line 1034
    iget-object v5, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->b:Lcom/thinkware/sundo/ieve/ieveCameraView$2;

    invoke-static {v5}, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a(Lcom/thinkware/sundo/ieve/ieveCameraView$2;)Lcom/thinkware/sundo/ieve/ieveCameraView;

    move-result-object v5

    invoke-static {v5}, Lcom/thinkware/sundo/ieve/ieveCameraView;->k(Lcom/thinkware/sundo/ieve/ieveCameraView;)Ljava/util/Vector;

    move-result-object v5

    invoke-virtual {v5}, Ljava/util/Vector;->clear()V

    .line 1035
    invoke-static {}, Lcom/thinkware/sundo/ieve/ieveCameraView;->a()Ljava/lang/String;

    move-result-object v5

    const-string v6, "saveStream:doInBackground[mStreamBufferAfter.clear]"

    invoke-static {v5, v6}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_3
    .catch Ljava/io/FileNotFoundException; {:try_start_3 .. :try_end_3} :catch_2
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 1042
    :cond_6
    iget-object v5, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->j:Ljava/io/FileOutputStream;

    if-eqz v5, :cond_8

    .line 1044
    :try_start_4
    iget-object v5, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->j:Ljava/io/FileOutputStream;

    invoke-virtual {v5}, Ljava/io/FileOutputStream;->flush()V

    .line 1045
    iget-object v5, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->j:Ljava/io/FileOutputStream;

    invoke-virtual {v5}, Ljava/io/FileOutputStream;->close()V

    .line 1046
    invoke-static {}, Lcom/thinkware/sundo/ieve/ieveCameraView;->a()Ljava/lang/String;

    move-result-object v5

    const-string v6, "saveStream:doInBackground[mOutputStream.close]"

    invoke-static {v5, v6}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_4
    .catch Ljava/io/IOException; {:try_start_4 .. :try_end_4} :catch_6

    .line 1052
    if-nez v4, :cond_19

    .line 1053
    invoke-static {}, Lcom/thinkware/sundo/ieve/ieveCameraView;->a()Ljava/lang/String;

    move-result-object v5

    const-string v6, "saveStream:doInBackground[Failed saveStream]"

    invoke-static {v5, v6}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 1054
    new-instance v2, Ljava/io/File;

    iget-object v5, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->g:Ljava/lang/String;

    invoke-direct {v2, v5}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 1055
    .local v2, "file":Ljava/io/File;
    if-eqz v2, :cond_7

    invoke-virtual {v2}, Ljava/io/File;->delete()Z

    .line 1060
    .end local v2    # "file":Ljava/io/File;
    :cond_7
    :goto_8
    iput-object v12, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->j:Ljava/io/FileOutputStream;

    .line 1062
    :cond_8
    invoke-virtual {p0}, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->b()V

    .line 1067
    .end local v0    # "data_nv12":[B
    :goto_9
    iget-object v5, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->b:Lcom/thinkware/sundo/ieve/ieveCameraView$2;

    invoke-static {v5}, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a(Lcom/thinkware/sundo/ieve/ieveCameraView$2;)Lcom/thinkware/sundo/ieve/ieveCameraView;

    move-result-object v5

    invoke-static {v5, v12}, Lcom/thinkware/sundo/ieve/ieveCameraView;->b(Lcom/thinkware/sundo/ieve/ieveCameraView;Ljava/lang/String;)V

    .line 1068
    iget-object v5, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->b:Lcom/thinkware/sundo/ieve/ieveCameraView$2;

    invoke-static {v5}, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a(Lcom/thinkware/sundo/ieve/ieveCameraView$2;)Lcom/thinkware/sundo/ieve/ieveCameraView;

    move-result-object v5

    invoke-static {v5, v10}, Lcom/thinkware/sundo/ieve/ieveCameraView;->e(Lcom/thinkware/sundo/ieve/ieveCameraView;Z)V

    .line 1069
    iget-object v5, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->b:Lcom/thinkware/sundo/ieve/ieveCameraView$2;

    invoke-static {v5}, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a(Lcom/thinkware/sundo/ieve/ieveCameraView$2;)Lcom/thinkware/sundo/ieve/ieveCameraView;

    move-result-object v5

    invoke-static {v5, v10}, Lcom/thinkware/sundo/ieve/ieveCameraView;->a(Lcom/thinkware/sundo/ieve/ieveCameraView;Z)V

    .line 1070
    invoke-static {}, Lcom/thinkware/sundo/ieve/ieveCameraView;->a()Ljava/lang/String;

    move-result-object v5

    const-string v6, "saveStream:doInBackground[Done]"

    invoke-static {v5, v6}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 1072
    invoke-static {v4}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v5

    goto/16 :goto_0

    .line 958
    :catch_1
    move-exception v1

    .line 959
    .restart local v1    # "e":Ljava/io/IOException;
    :try_start_5
    invoke-virtual {v1}, Ljava/io/IOException;->printStackTrace()V

    .line 960
    invoke-static {}, Lcom/thinkware/sundo/ieve/ieveCameraView;->a()Ljava/lang/String;

    move-result-object v5

    const-string v6, "saveStream:doInBackground[IOException:%s]"

    const/4 v7, 0x1

    new-array v7, v7, [Ljava/lang/Object;

    const/4 v8, 0x0

    invoke-virtual {v1}, Ljava/io/IOException;->getLocalizedMessage()Ljava/lang/String;

    move-result-object v9

    aput-object v9, v7, v8

    invoke-static {v6, v7}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v5, v6}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 961
    const/4 v4, 0x0

    .line 963
    goto/16 :goto_1

    .line 965
    .end local v1    # "e":Ljava/io/IOException;
    :cond_9
    invoke-static {}, Lcom/thinkware/sundo/ieve/ieveCameraView;->a()Ljava/lang/String;

    move-result-object v5

    const-string v6, "saveStream:doInBackground[mUseMuxer is false]"

    invoke-static {v5, v6}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 966
    new-instance v5, Ljava/io/FileOutputStream;

    iget-object v6, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->g:Ljava/lang/String;

    const/4 v7, 0x1

    invoke-direct {v5, v6, v7}, Ljava/io/FileOutputStream;-><init>(Ljava/lang/String;Z)V

    iput-object v5, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->j:Ljava/io/FileOutputStream;
    :try_end_5
    .catch Ljava/io/FileNotFoundException; {:try_start_5 .. :try_end_5} :catch_2
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    goto/16 :goto_1

    .line 1037
    :catch_2
    move-exception v1

    .line 1038
    .local v1, "e":Ljava/io/FileNotFoundException;
    :try_start_6
    invoke-virtual {v1}, Ljava/io/FileNotFoundException;->printStackTrace()V

    .line 1039
    invoke-static {}, Lcom/thinkware/sundo/ieve/ieveCameraView;->a()Ljava/lang/String;

    move-result-object v5

    const-string v6, "saveStream:doInBackground[FileNotFoundException:%s]"

    const/4 v7, 0x1

    new-array v7, v7, [Ljava/lang/Object;

    const/4 v8, 0x0

    invoke-virtual {v1}, Ljava/io/FileNotFoundException;->getLocalizedMessage()Ljava/lang/String;

    move-result-object v9

    aput-object v9, v7, v8

    invoke-static {v6, v7}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v5, v6}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_0

    .line 1040
    const/4 v4, 0x0

    .line 1042
    iget-object v5, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->j:Ljava/io/FileOutputStream;

    if-eqz v5, :cond_b

    .line 1044
    :try_start_7
    iget-object v5, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->j:Ljava/io/FileOutputStream;

    invoke-virtual {v5}, Ljava/io/FileOutputStream;->flush()V

    .line 1045
    iget-object v5, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->j:Ljava/io/FileOutputStream;

    invoke-virtual {v5}, Ljava/io/FileOutputStream;->close()V

    .line 1046
    invoke-static {}, Lcom/thinkware/sundo/ieve/ieveCameraView;->a()Ljava/lang/String;

    move-result-object v5

    const-string v6, "saveStream:doInBackground[mOutputStream.close]"

    invoke-static {v5, v6}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_7
    .catch Ljava/io/IOException; {:try_start_7 .. :try_end_7} :catch_4

    .line 1052
    if-nez v4, :cond_17

    .line 1053
    invoke-static {}, Lcom/thinkware/sundo/ieve/ieveCameraView;->a()Ljava/lang/String;

    move-result-object v5

    const-string v6, "saveStream:doInBackground[Failed saveStream]"

    invoke-static {v5, v6}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 1054
    new-instance v2, Ljava/io/File;

    iget-object v5, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->g:Ljava/lang/String;

    invoke-direct {v2, v5}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 1055
    .restart local v2    # "file":Ljava/io/File;
    if-eqz v2, :cond_a

    invoke-virtual {v2}, Ljava/io/File;->delete()Z

    .line 1060
    .end local v2    # "file":Ljava/io/File;
    :cond_a
    :goto_a
    iput-object v12, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->j:Ljava/io/FileOutputStream;

    .line 1062
    :cond_b
    invoke-virtual {p0}, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->b()V

    goto/16 :goto_9

    .line 973
    .end local v1    # "e":Ljava/io/FileNotFoundException;
    .restart local v0    # "data_nv12":[B
    :cond_c
    :try_start_8
    iget-object v5, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->b:Lcom/thinkware/sundo/ieve/ieveCameraView$2;

    invoke-static {v5}, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a(Lcom/thinkware/sundo/ieve/ieveCameraView$2;)Lcom/thinkware/sundo/ieve/ieveCameraView;

    move-result-object v5

    invoke-static {v5}, Lcom/thinkware/sundo/ieve/ieveCameraView;->h(Lcom/thinkware/sundo/ieve/ieveCameraView;)Z

    move-result v5

    if-eqz v5, :cond_1

    .line 974
    iget-object v5, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->b:Lcom/thinkware/sundo/ieve/ieveCameraView$2;

    invoke-static {v5}, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a(Lcom/thinkware/sundo/ieve/ieveCameraView$2;)Lcom/thinkware/sundo/ieve/ieveCameraView;

    move-result-object v5

    invoke-static {v5}, Lcom/thinkware/sundo/ieve/ieveCameraView;->m(Lcom/thinkware/sundo/ieve/ieveCameraView;)Ljava/util/Vector;

    move-result-object v5

    const/4 v6, 0x0

    invoke-virtual {v5, v6}, Ljava/util/Vector;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, [B

    .line 975
    .local v3, "pBuffer":[B
    if-nez v3, :cond_d

    .line 976
    invoke-static {}, Lcom/thinkware/sundo/ieve/ieveCameraView;->a()Ljava/lang/String;

    move-result-object v5

    const-string v6, "saveStream:doInBackground[Error mStreamBufferBefore.get(0) is null]"

    invoke-static {v5, v6}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 977
    const/4 v4, 0x0

    .line 978
    goto/16 :goto_3

    .line 980
    :cond_d
    iget-object v5, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->b:Lcom/thinkware/sundo/ieve/ieveCameraView$2;

    invoke-static {v5}, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a(Lcom/thinkware/sundo/ieve/ieveCameraView$2;)Lcom/thinkware/sundo/ieve/ieveCameraView;

    move-result-object v5

    iget-object v6, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->b:Lcom/thinkware/sundo/ieve/ieveCameraView$2;

    invoke-static {v6}, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a(Lcom/thinkware/sundo/ieve/ieveCameraView$2;)Lcom/thinkware/sundo/ieve/ieveCameraView;

    move-result-object v6

    invoke-static {v6}, Lcom/thinkware/sundo/ieve/ieveCameraView;->q(Lcom/thinkware/sundo/ieve/ieveCameraView;)I

    move-result v6

    iget-object v7, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->b:Lcom/thinkware/sundo/ieve/ieveCameraView$2;

    invoke-static {v7}, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a(Lcom/thinkware/sundo/ieve/ieveCameraView$2;)Lcom/thinkware/sundo/ieve/ieveCameraView;

    move-result-object v7

    invoke-static {v7}, Lcom/thinkware/sundo/ieve/ieveCameraView;->r(Lcom/thinkware/sundo/ieve/ieveCameraView;)I

    move-result v7

    invoke-virtual {v5, v3, v6, v7}, Lcom/thinkware/sundo/ieve/ieveCameraView;->cvtColorNV21_NV12([BII)[B

    move-result-object v0

    .line 981
    if-nez v0, :cond_e

    .line 982
    invoke-static {}, Lcom/thinkware/sundo/ieve/ieveCameraView;->a()Ljava/lang/String;

    move-result-object v5

    const-string v6, "saveStream:doInBackground[Error mStreamBufferBefore data_nv12 is null]"

    invoke-static {v5, v6}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 983
    const/4 v4, 0x0

    .line 984
    goto/16 :goto_3

    .line 986
    :cond_e
    invoke-virtual {p0, v0}, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->a([B)Z

    move-result v5

    if-nez v5, :cond_f

    .line 987
    invoke-static {}, Lcom/thinkware/sundo/ieve/ieveCameraView;->a()Ljava/lang/String;

    move-result-object v5

    const-string v6, "saveStream:doInBackground[Error drainEncode mStreamBufferBefore]"

    invoke-static {v5, v6}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 988
    const/4 v4, 0x0

    .line 989
    goto/16 :goto_3

    .line 991
    :cond_f
    iget-object v5, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->b:Lcom/thinkware/sundo/ieve/ieveCameraView$2;

    invoke-static {v5}, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a(Lcom/thinkware/sundo/ieve/ieveCameraView$2;)Lcom/thinkware/sundo/ieve/ieveCameraView;

    move-result-object v5

    invoke-static {v5}, Lcom/thinkware/sundo/ieve/ieveCameraView;->m(Lcom/thinkware/sundo/ieve/ieveCameraView;)Ljava/util/Vector;

    move-result-object v5

    const/4 v6, 0x0

    invoke-virtual {v5, v6}, Ljava/util/Vector;->remove(I)Ljava/lang/Object;
    :try_end_8
    .catch Ljava/io/FileNotFoundException; {:try_start_8 .. :try_end_8} :catch_2
    .catchall {:try_start_8 .. :try_end_8} :catchall_0

    goto/16 :goto_2

    .line 1041
    .end local v0    # "data_nv12":[B
    .end local v3    # "pBuffer":[B
    :catchall_0
    move-exception v5

    .line 1042
    iget-object v6, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->j:Ljava/io/FileOutputStream;

    if-eqz v6, :cond_11

    .line 1044
    :try_start_9
    iget-object v6, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->j:Ljava/io/FileOutputStream;

    invoke-virtual {v6}, Ljava/io/FileOutputStream;->flush()V

    .line 1045
    iget-object v6, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->j:Ljava/io/FileOutputStream;

    invoke-virtual {v6}, Ljava/io/FileOutputStream;->close()V

    .line 1046
    invoke-static {}, Lcom/thinkware/sundo/ieve/ieveCameraView;->a()Ljava/lang/String;

    move-result-object v6

    const-string v7, "saveStream:doInBackground[mOutputStream.close]"

    invoke-static {v6, v7}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_9
    .catch Ljava/io/IOException; {:try_start_9 .. :try_end_9} :catch_5

    .line 1052
    if-nez v4, :cond_18

    .line 1053
    invoke-static {}, Lcom/thinkware/sundo/ieve/ieveCameraView;->a()Ljava/lang/String;

    move-result-object v6

    const-string v7, "saveStream:doInBackground[Failed saveStream]"

    invoke-static {v6, v7}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 1054
    new-instance v2, Ljava/io/File;

    iget-object v6, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->g:Ljava/lang/String;

    invoke-direct {v2, v6}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 1055
    .restart local v2    # "file":Ljava/io/File;
    if-eqz v2, :cond_10

    invoke-virtual {v2}, Ljava/io/File;->delete()Z

    .line 1060
    .end local v2    # "file":Ljava/io/File;
    :cond_10
    :goto_b
    iput-object v12, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->j:Ljava/io/FileOutputStream;

    .line 1062
    :cond_11
    invoke-virtual {p0}, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->b()V

    .line 1063
    throw v5

    .line 998
    .restart local v0    # "data_nv12":[B
    :cond_12
    :try_start_a
    iget-object v5, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->b:Lcom/thinkware/sundo/ieve/ieveCameraView$2;

    invoke-static {v5}, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a(Lcom/thinkware/sundo/ieve/ieveCameraView$2;)Lcom/thinkware/sundo/ieve/ieveCameraView;

    move-result-object v5

    invoke-static {v5}, Lcom/thinkware/sundo/ieve/ieveCameraView;->h(Lcom/thinkware/sundo/ieve/ieveCameraView;)Z
    :try_end_a
    .catch Ljava/io/FileNotFoundException; {:try_start_a .. :try_end_a} :catch_2
    .catchall {:try_start_a .. :try_end_a} :catchall_0

    move-result v5

    if-eqz v5, :cond_3

    .line 1000
    const-wide/16 v6, 0x1

    :try_start_b
    invoke-static {v6, v7}, Ljava/lang/Thread;->sleep(J)V
    :try_end_b
    .catch Ljava/lang/InterruptedException; {:try_start_b .. :try_end_b} :catch_3
    .catch Ljava/io/FileNotFoundException; {:try_start_b .. :try_end_b} :catch_2
    .catchall {:try_start_b .. :try_end_b} :catchall_0

    goto/16 :goto_4

    .line 1001
    :catch_3
    move-exception v1

    .line 1002
    .local v1, "e":Ljava/lang/InterruptedException;
    :try_start_c
    invoke-virtual {v1}, Ljava/lang/InterruptedException;->printStackTrace()V

    .line 1003
    const/4 v4, 0x0

    .line 1004
    goto/16 :goto_5

    .line 1014
    .end local v1    # "e":Ljava/lang/InterruptedException;
    :cond_13
    iget-object v5, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->b:Lcom/thinkware/sundo/ieve/ieveCameraView$2;

    invoke-static {v5}, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a(Lcom/thinkware/sundo/ieve/ieveCameraView$2;)Lcom/thinkware/sundo/ieve/ieveCameraView;

    move-result-object v5

    invoke-static {v5}, Lcom/thinkware/sundo/ieve/ieveCameraView;->k(Lcom/thinkware/sundo/ieve/ieveCameraView;)Ljava/util/Vector;

    move-result-object v5

    const/4 v6, 0x0

    invoke-virtual {v5, v6}, Ljava/util/Vector;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, [B

    .line 1015
    .restart local v3    # "pBuffer":[B
    if-nez v3, :cond_14

    .line 1016
    invoke-static {}, Lcom/thinkware/sundo/ieve/ieveCameraView;->a()Ljava/lang/String;

    move-result-object v5

    const-string v6, "saveStream:doInBackground[Error mStreamBufferAfter.get(0) is null]"

    invoke-static {v5, v6}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 1017
    const/4 v4, 0x0

    .line 1018
    goto/16 :goto_7

    .line 1020
    :cond_14
    iget-object v5, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->b:Lcom/thinkware/sundo/ieve/ieveCameraView$2;

    invoke-static {v5}, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a(Lcom/thinkware/sundo/ieve/ieveCameraView$2;)Lcom/thinkware/sundo/ieve/ieveCameraView;

    move-result-object v5

    iget-object v6, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->b:Lcom/thinkware/sundo/ieve/ieveCameraView$2;

    invoke-static {v6}, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a(Lcom/thinkware/sundo/ieve/ieveCameraView$2;)Lcom/thinkware/sundo/ieve/ieveCameraView;

    move-result-object v6

    invoke-static {v6}, Lcom/thinkware/sundo/ieve/ieveCameraView;->q(Lcom/thinkware/sundo/ieve/ieveCameraView;)I

    move-result v6

    iget-object v7, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->b:Lcom/thinkware/sundo/ieve/ieveCameraView$2;

    invoke-static {v7}, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a(Lcom/thinkware/sundo/ieve/ieveCameraView$2;)Lcom/thinkware/sundo/ieve/ieveCameraView;

    move-result-object v7

    invoke-static {v7}, Lcom/thinkware/sundo/ieve/ieveCameraView;->r(Lcom/thinkware/sundo/ieve/ieveCameraView;)I

    move-result v7

    invoke-virtual {v5, v3, v6, v7}, Lcom/thinkware/sundo/ieve/ieveCameraView;->cvtColorNV21_NV12([BII)[B

    move-result-object v0

    .line 1021
    if-nez v0, :cond_15

    .line 1022
    invoke-static {}, Lcom/thinkware/sundo/ieve/ieveCameraView;->a()Ljava/lang/String;

    move-result-object v5

    const-string v6, "saveStream:doInBackground[Error mStreamBufferAfter data_nv12 is null]"

    invoke-static {v5, v6}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 1023
    const/4 v4, 0x0

    .line 1024
    goto/16 :goto_7

    .line 1026
    :cond_15
    invoke-virtual {p0, v0}, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->a([B)Z

    move-result v5

    if-nez v5, :cond_16

    .line 1027
    invoke-static {}, Lcom/thinkware/sundo/ieve/ieveCameraView;->a()Ljava/lang/String;

    move-result-object v5

    const-string v6, "saveStream:doInBackground[Error drainEncode mStreamBufferAfter]"

    invoke-static {v5, v6}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 1028
    const/4 v4, 0x0

    .line 1029
    goto/16 :goto_7

    .line 1031
    :cond_16
    iget-object v5, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->b:Lcom/thinkware/sundo/ieve/ieveCameraView$2;

    invoke-static {v5}, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a(Lcom/thinkware/sundo/ieve/ieveCameraView$2;)Lcom/thinkware/sundo/ieve/ieveCameraView;

    move-result-object v5

    invoke-static {v5}, Lcom/thinkware/sundo/ieve/ieveCameraView;->k(Lcom/thinkware/sundo/ieve/ieveCameraView;)Ljava/util/Vector;

    move-result-object v5

    const/4 v6, 0x0

    invoke-virtual {v5, v6}, Ljava/util/Vector;->remove(I)Ljava/lang/Object;
    :try_end_c
    .catch Ljava/io/FileNotFoundException; {:try_start_c .. :try_end_c} :catch_2
    .catchall {:try_start_c .. :try_end_c} :catchall_0

    goto/16 :goto_6

    .line 1047
    .end local v0    # "data_nv12":[B
    .end local v3    # "pBuffer":[B
    .local v1, "e":Ljava/io/FileNotFoundException;
    :catch_4
    move-exception v1

    .line 1048
    .local v1, "e":Ljava/io/IOException;
    invoke-virtual {v1}, Ljava/io/IOException;->printStackTrace()V

    .line 1049
    invoke-static {}, Lcom/thinkware/sundo/ieve/ieveCameraView;->a()Ljava/lang/String;

    move-result-object v5

    const-string v6, "saveStream:doInBackground[File closing failed-IOException:%s]"

    new-array v7, v11, [Ljava/lang/Object;

    invoke-virtual {v1}, Ljava/io/IOException;->getLocalizedMessage()Ljava/lang/String;

    move-result-object v8

    aput-object v8, v7, v10

    invoke-static {v6, v7}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v5, v6}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 1050
    new-instance v5, Ljava/lang/RuntimeException;

    invoke-direct {v5, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V

    throw v5

    .line 1058
    .local v1, "e":Ljava/io/FileNotFoundException;
    :cond_17
    invoke-static {}, Lcom/thinkware/sundo/ieve/ieveCameraView;->a()Ljava/lang/String;

    move-result-object v5

    const-string v6, "saveStream:doInBackground[Successed saveStream]"

    invoke-static {v5, v6}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    goto/16 :goto_a

    .line 1047
    .end local v1    # "e":Ljava/io/FileNotFoundException;
    :catch_5
    move-exception v1

    .line 1048
    .local v1, "e":Ljava/io/IOException;
    invoke-virtual {v1}, Ljava/io/IOException;->printStackTrace()V

    .line 1049
    invoke-static {}, Lcom/thinkware/sundo/ieve/ieveCameraView;->a()Ljava/lang/String;

    move-result-object v5

    const-string v6, "saveStream:doInBackground[File closing failed-IOException:%s]"

    new-array v7, v11, [Ljava/lang/Object;

    invoke-virtual {v1}, Ljava/io/IOException;->getLocalizedMessage()Ljava/lang/String;

    move-result-object v8

    aput-object v8, v7, v10

    invoke-static {v6, v7}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v5, v6}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 1050
    new-instance v5, Ljava/lang/RuntimeException;

    invoke-direct {v5, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V

    throw v5

    .line 1058
    .end local v1    # "e":Ljava/io/IOException;
    :cond_18
    invoke-static {}, Lcom/thinkware/sundo/ieve/ieveCameraView;->a()Ljava/lang/String;

    move-result-object v6

    const-string v7, "saveStream:doInBackground[Successed saveStream]"

    invoke-static {v6, v7}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    goto/16 :goto_b

    .line 1047
    .restart local v0    # "data_nv12":[B
    :catch_6
    move-exception v1

    .line 1048
    .restart local v1    # "e":Ljava/io/IOException;
    invoke-virtual {v1}, Ljava/io/IOException;->printStackTrace()V

    .line 1049
    invoke-static {}, Lcom/thinkware/sundo/ieve/ieveCameraView;->a()Ljava/lang/String;

    move-result-object v5

    const-string v6, "saveStream:doInBackground[File closing failed-IOException:%s]"

    new-array v7, v11, [Ljava/lang/Object;

    invoke-virtual {v1}, Ljava/io/IOException;->getLocalizedMessage()Ljava/lang/String;

    move-result-object v8

    aput-object v8, v7, v10

    invoke-static {v6, v7}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v5, v6}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 1050
    new-instance v5, Ljava/lang/RuntimeException;

    invoke-direct {v5, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V

    throw v5

    .line 1058
    .end local v1    # "e":Ljava/io/IOException;
    :cond_19
    invoke-static {}, Lcom/thinkware/sundo/ieve/ieveCameraView;->a()Ljava/lang/String;

    move-result-object v5

    const-string v6, "saveStream:doInBackground[Successed saveStream]"

    invoke-static {v5, v6}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    goto/16 :goto_8
.end method

.method protected a(Ljava/lang/Boolean;)V
    .locals 5
    .param p1, "result"    # Ljava/lang/Boolean;

    .prologue
    .line 929
    invoke-super {p0, p1}, Landroid/os/AsyncTask;->onPostExecute(Ljava/lang/Object;)V

    .line 930
    invoke-static {}, Lcom/thinkware/sundo/ieve/ieveCameraView;->a()Ljava/lang/String;

    move-result-object v1

    const-string v2, "saveStream:onPostExecute[%s]"

    const/4 v0, 0x1

    new-array v3, v0, [Ljava/lang/Object;

    const/4 v4, 0x0

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-eqz v0, :cond_0

    const-string v0, "succeed"

    :goto_0
    aput-object v0, v3, v4

    invoke-static {v2, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 931
    return-void

    .line 930
    :cond_0
    const-string v0, "failed"

    goto :goto_0
.end method

.method protected a()Z
    .locals 11
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .prologue
    const/4 v10, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x0

    .line 699
    invoke-static {}, Lcom/thinkware/sundo/ieve/ieveCameraView;->a()Ljava/lang/String;

    move-result-object v3

    const-string v4, "saveStream:createEncoder"

    invoke-static {v3, v4}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 700
    const-string v3, "video/avc"

    invoke-direct {p0, v3}, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->a(Ljava/lang/String;)Landroid/media/MediaCodecInfo;

    move-result-object v0

    .line 701
    .local v0, "mci":Landroid/media/MediaCodecInfo;
    if-nez v0, :cond_0

    .line 702
    invoke-static {}, Lcom/thinkware/sundo/ieve/ieveCameraView;->a()Ljava/lang/String;

    move-result-object v3

    const-string v4, "saveStream:createEncoder[Not supported MediaCodec:%s]"

    new-array v2, v2, [Ljava/lang/Object;

    const-string v5, "video/avc"

    aput-object v5, v2, v1

    invoke-static {v4, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v3, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 756
    :goto_0
    return v1

    .line 706
    :cond_0
    new-instance v3, Landroid/media/MediaCodec$BufferInfo;

    invoke-direct {v3}, Landroid/media/MediaCodec$BufferInfo;-><init>()V

    iput-object v3, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->a:Landroid/media/MediaCodec$BufferInfo;

    .line 707
    iget-object v3, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->a:Landroid/media/MediaCodec$BufferInfo;

    if-nez v3, :cond_1

    .line 708
    invoke-static {}, Lcom/thinkware/sundo/ieve/ieveCameraView;->a()Ljava/lang/String;

    move-result-object v2

    const-string v3, "saveStream:createEncoder[Failed create MediaCodec.BufferInfo]"

    invoke-static {v2, v3}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 709
    const/4 v0, 0x0

    .line 710
    goto :goto_0

    .line 713
    :cond_1
    const-string v3, "video/avc"

    iget-object v4, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->b:Lcom/thinkware/sundo/ieve/ieveCameraView$2;

    invoke-static {v4}, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a(Lcom/thinkware/sundo/ieve/ieveCameraView$2;)Lcom/thinkware/sundo/ieve/ieveCameraView;

    move-result-object v4

    invoke-static {v4}, Lcom/thinkware/sundo/ieve/ieveCameraView;->q(Lcom/thinkware/sundo/ieve/ieveCameraView;)I

    move-result v4

    iget-object v5, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->b:Lcom/thinkware/sundo/ieve/ieveCameraView$2;

    invoke-static {v5}, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a(Lcom/thinkware/sundo/ieve/ieveCameraView$2;)Lcom/thinkware/sundo/ieve/ieveCameraView;

    move-result-object v5

    invoke-static {v5}, Lcom/thinkware/sundo/ieve/ieveCameraView;->r(Lcom/thinkware/sundo/ieve/ieveCameraView;)I

    move-result v5

    invoke-static {v3, v4, v5}, Landroid/media/MediaFormat;->createVideoFormat(Ljava/lang/String;II)Landroid/media/MediaFormat;

    move-result-object v3

    iput-object v3, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->i:Landroid/media/MediaFormat;

    .line 714
    iget-object v3, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->i:Landroid/media/MediaFormat;

    if-nez v3, :cond_2

    .line 715
    invoke-static {}, Lcom/thinkware/sundo/ieve/ieveCameraView;->a()Ljava/lang/String;

    move-result-object v2

    const-string v3, "saveStream:createEncoder[Failed create MediaFormat]"

    invoke-static {v2, v3}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 716
    const/4 v0, 0x0

    .line 717
    iput-object v10, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->a:Landroid/media/MediaCodec$BufferInfo;

    goto :goto_0

    .line 722
    :cond_2
    iget-object v3, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->i:Landroid/media/MediaFormat;

    const-string v4, "bitrate"

    const v5, 0x2dc6c0

    invoke-virtual {v3, v4, v5}, Landroid/media/MediaFormat;->setInteger(Ljava/lang/String;I)V

    .line 723
    iget-object v3, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->i:Landroid/media/MediaFormat;

    const-string v4, "color-format"

    const/16 v5, 0x15

    invoke-virtual {v3, v4, v5}, Landroid/media/MediaFormat;->setInteger(Ljava/lang/String;I)V

    .line 724
    iget-object v3, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->i:Landroid/media/MediaFormat;

    const-string v4, "i-frame-interval"

    invoke-virtual {v3, v4, v2}, Landroid/media/MediaFormat;->setInteger(Ljava/lang/String;I)V

    .line 725
    iget-object v3, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->i:Landroid/media/MediaFormat;

    const-string v4, "channel-count"

    invoke-virtual {v3, v4, v2}, Landroid/media/MediaFormat;->setInteger(Ljava/lang/String;I)V

    .line 726
    iget-object v3, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->i:Landroid/media/MediaFormat;

    const-string v4, "frame-rate"

    iget-object v5, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->b:Lcom/thinkware/sundo/ieve/ieveCameraView$2;

    invoke-static {v5}, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a(Lcom/thinkware/sundo/ieve/ieveCameraView$2;)Lcom/thinkware/sundo/ieve/ieveCameraView;

    move-result-object v5

    invoke-static {v5}, Lcom/thinkware/sundo/ieve/ieveCameraView;->v(Lcom/thinkware/sundo/ieve/ieveCameraView;)D

    move-result-wide v6

    double-to-float v5, v6

    invoke-virtual {v3, v4, v5}, Landroid/media/MediaFormat;->setFloat(Ljava/lang/String;F)V

    .line 736
    invoke-static {}, Lcom/thinkware/sundo/ieve/ieveCameraView;->a()Ljava/lang/String;

    move-result-object v3

    const-string v4, "saveStream:createEncoder[%s, %dx%d, %.2ffps, I_Frame:%d, codec:%s]"

    const/4 v5, 0x6

    new-array v5, v5, [Ljava/lang/Object;

    .line 737
    const-string v6, "video/avc"

    aput-object v6, v5, v1

    iget-object v6, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->b:Lcom/thinkware/sundo/ieve/ieveCameraView$2;

    invoke-static {v6}, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a(Lcom/thinkware/sundo/ieve/ieveCameraView$2;)Lcom/thinkware/sundo/ieve/ieveCameraView;

    move-result-object v6

    invoke-static {v6}, Lcom/thinkware/sundo/ieve/ieveCameraView;->q(Lcom/thinkware/sundo/ieve/ieveCameraView;)I

    move-result v6

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    aput-object v6, v5, v2

    const/4 v6, 0x2

    iget-object v7, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->b:Lcom/thinkware/sundo/ieve/ieveCameraView$2;

    invoke-static {v7}, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a(Lcom/thinkware/sundo/ieve/ieveCameraView$2;)Lcom/thinkware/sundo/ieve/ieveCameraView;

    move-result-object v7

    invoke-static {v7}, Lcom/thinkware/sundo/ieve/ieveCameraView;->r(Lcom/thinkware/sundo/ieve/ieveCameraView;)I

    move-result v7

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    aput-object v7, v5, v6

    const/4 v6, 0x3

    iget-object v7, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->b:Lcom/thinkware/sundo/ieve/ieveCameraView$2;

    invoke-static {v7}, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a(Lcom/thinkware/sundo/ieve/ieveCameraView$2;)Lcom/thinkware/sundo/ieve/ieveCameraView;

    move-result-object v7

    invoke-static {v7}, Lcom/thinkware/sundo/ieve/ieveCameraView;->v(Lcom/thinkware/sundo/ieve/ieveCameraView;)D

    move-result-wide v8

    invoke-static {v8, v9}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v7

    aput-object v7, v5, v6

    const/4 v6, 0x4

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    aput-object v7, v5, v6

    const/4 v6, 0x5

    invoke-virtual {v0}, Landroid/media/MediaCodecInfo;->getName()Ljava/lang/String;

    move-result-object v7

    aput-object v7, v5, v6

    .line 736
    invoke-static {v4, v5}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v3, v4}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 739
    const-string v3, "video/avc"

    invoke-static {v3}, Landroid/media/MediaCodec;->createEncoderByType(Ljava/lang/String;)Landroid/media/MediaCodec;

    move-result-object v3

    iput-object v3, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->h:Landroid/media/MediaCodec;

    .line 740
    iget-object v3, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->h:Landroid/media/MediaCodec;

    if-nez v3, :cond_3

    .line 741
    invoke-static {}, Lcom/thinkware/sundo/ieve/ieveCameraView;->a()Ljava/lang/String;

    move-result-object v3

    const-string v4, "saveStream:createEncoder[Failed create MediaCodec.createEncoderByType:%s]"

    new-array v2, v2, [Ljava/lang/Object;

    const-string v5, "video/avc"

    aput-object v5, v2, v1

    invoke-static {v4, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v3, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 742
    const/4 v0, 0x0

    .line 743
    iput-object v10, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->a:Landroid/media/MediaCodec$BufferInfo;

    .line 744
    iput-object v10, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->i:Landroid/media/MediaFormat;

    goto/16 :goto_0

    .line 747
    :cond_3
    iget-object v3, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->h:Landroid/media/MediaCodec;

    iget-object v4, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->i:Landroid/media/MediaFormat;

    invoke-virtual {v3, v4, v10, v10, v2}, Landroid/media/MediaCodec;->configure(Landroid/media/MediaFormat;Landroid/view/Surface;Landroid/media/MediaCrypto;I)V

    .line 748
    iget-object v3, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->h:Landroid/media/MediaCodec;

    invoke-virtual {v3}, Landroid/media/MediaCodec;->start()V

    .line 750
    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->d:I

    .line 751
    const/4 v3, -0x1

    iput v3, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->e:I

    .line 753
    const-string v3, "%s.mp4"

    new-array v4, v2, [Ljava/lang/Object;

    iget-object v5, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->b:Lcom/thinkware/sundo/ieve/ieveCameraView$2;

    invoke-static {v5}, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a(Lcom/thinkware/sundo/ieve/ieveCameraView$2;)Lcom/thinkware/sundo/ieve/ieveCameraView;

    move-result-object v5

    invoke-static {v5}, Lcom/thinkware/sundo/ieve/ieveCameraView;->w(Lcom/thinkware/sundo/ieve/ieveCameraView;)Ljava/lang/String;

    move-result-object v5

    aput-object v5, v4, v1

    invoke-static {v3, v4}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    iput-object v3, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->g:Ljava/lang/String;

    .line 754
    invoke-static {}, Lcom/thinkware/sundo/ieve/ieveCameraView;->a()Ljava/lang/String;

    move-result-object v3

    const-string v4, "saveStream:createEncoder[Save name:%s]"

    new-array v5, v2, [Ljava/lang/Object;

    iget-object v6, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->g:Ljava/lang/String;

    aput-object v6, v5, v1

    invoke-static {v4, v5}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v3, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    move v1, v2

    .line 756
    goto/16 :goto_0
.end method

.method protected a([B)Z
    .locals 20
    .param p1, "data"    # [B

    .prologue
    .line 801
    if-nez p1, :cond_0

    const/4 v2, 0x0

    .line 862
    :goto_0
    return v2

    .line 802
    :cond_0
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->h:Landroid/media/MediaCodec;

    invoke-virtual {v2}, Landroid/media/MediaCodec;->getInputBuffers()[Ljava/nio/ByteBuffer;

    move-result-object v11

    .line 803
    .local v11, "inputBuffers":[Ljava/nio/ByteBuffer;
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->h:Landroid/media/MediaCodec;

    invoke-virtual {v2}, Landroid/media/MediaCodec;->getOutputBuffers()[Ljava/nio/ByteBuffer;

    move-result-object v16

    .line 805
    .local v16, "outputBuffers":[Ljava/nio/ByteBuffer;
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->h:Landroid/media/MediaCodec;

    const-wide/16 v4, 0x2710

    invoke-virtual {v2, v4, v5}, Landroid/media/MediaCodec;->dequeueInputBuffer(J)I

    move-result v3

    .line 806
    .local v3, "inputBufIndex":I
    if-ltz v3, :cond_1

    .line 807
    move-object/from16 v0, p0

    iget v2, v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->d:I

    move-object/from16 v0, p0

    iget-object v4, v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->b:Lcom/thinkware/sundo/ieve/ieveCameraView$2;

    invoke-static {v4}, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a(Lcom/thinkware/sundo/ieve/ieveCameraView$2;)Lcom/thinkware/sundo/ieve/ieveCameraView;

    move-result-object v4

    invoke-static {v4}, Lcom/thinkware/sundo/ieve/ieveCameraView;->v(Lcom/thinkware/sundo/ieve/ieveCameraView;)D

    move-result-wide v4

    move-object/from16 v0, p0

    invoke-direct {v0, v2, v4, v5}, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->a(ID)J

    move-result-wide v6

    .line 808
    .local v6, "idxUsec":J
    aget-object v10, v11, v3

    .line 809
    .local v10, "inputBuffer":Ljava/nio/ByteBuffer;
    invoke-virtual {v10}, Ljava/nio/ByteBuffer;->clear()Ljava/nio/Buffer;

    .line 810
    move-object/from16 v0, p1

    invoke-virtual {v10, v0}, Ljava/nio/ByteBuffer;->put([B)Ljava/nio/ByteBuffer;

    .line 811
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->h:Landroid/media/MediaCodec;

    const/4 v4, 0x0

    move-object/from16 v0, p1

    array-length v5, v0

    const/4 v8, 0x0

    invoke-virtual/range {v2 .. v8}, Landroid/media/MediaCodec;->queueInputBuffer(IIIJI)V

    .line 812
    move-object/from16 v0, p0

    iget v2, v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->d:I

    add-int/lit8 v2, v2, 0x1

    move-object/from16 v0, p0

    iput v2, v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->d:I

    .line 815
    .end local v6    # "idxUsec":J
    .end local v10    # "inputBuffer":Ljava/nio/ByteBuffer;
    :cond_1
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->h:Landroid/media/MediaCodec;

    move-object/from16 v0, p0

    iget-object v4, v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->a:Landroid/media/MediaCodec$BufferInfo;

    const-wide/16 v18, 0x2710

    move-wide/from16 v0, v18

    invoke-virtual {v2, v4, v0, v1}, Landroid/media/MediaCodec;->dequeueOutputBuffer(Landroid/media/MediaCodec$BufferInfo;J)I

    move-result v15

    .line 816
    .local v15, "outputBufferIndex":I
    const/4 v2, -0x1

    if-ne v15, v2, :cond_3

    .line 817
    invoke-static {}, Lcom/thinkware/sundo/ieve/ieveCameraView;->a()Ljava/lang/String;

    move-result-object v2

    const-string v4, "saveStream:drainEncode[no output from encoder available]"

    invoke-static {v2, v4}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 862
    :cond_2
    :goto_1
    const/4 v2, 0x1

    goto :goto_0

    .line 818
    :cond_3
    const/4 v2, -0x3

    if-ne v15, v2, :cond_4

    .line 819
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->h:Landroid/media/MediaCodec;

    invoke-virtual {v2}, Landroid/media/MediaCodec;->getOutputBuffers()[Ljava/nio/ByteBuffer;

    move-result-object v16

    .line 820
    invoke-static {}, Lcom/thinkware/sundo/ieve/ieveCameraView;->a()Ljava/lang/String;

    move-result-object v2

    const-string v4, "saveStream:drainEncode[encoder output buffers changed]"

    invoke-static {v2, v4}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_1

    .line 821
    :cond_4
    const/4 v2, -0x2

    if-ne v15, v2, :cond_5

    .line 822
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->h:Landroid/media/MediaCodec;

    invoke-virtual {v2}, Landroid/media/MediaCodec;->getOutputFormat()Landroid/media/MediaFormat;

    move-result-object v12

    .line 823
    .local v12, "newFormat":Landroid/media/MediaFormat;
    invoke-static {}, Lcom/thinkware/sundo/ieve/ieveCameraView;->a()Ljava/lang/String;

    move-result-object v2

    const-string v4, "saveStream:drainEncode[encoder output format changed:%s]"

    const/4 v5, 0x1

    new-array v5, v5, [Ljava/lang/Object;

    const/4 v8, 0x0

    invoke-virtual {v12}, Landroid/media/MediaFormat;->toString()Ljava/lang/String;

    move-result-object v17

    aput-object v17, v5, v8

    invoke-static {v4, v5}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v2, v4}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 824
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->f:Landroid/media/MediaMuxer;

    if-eqz v2, :cond_2

    .line 825
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->f:Landroid/media/MediaMuxer;

    invoke-virtual {v2, v12}, Landroid/media/MediaMuxer;->addTrack(Landroid/media/MediaFormat;)I

    move-result v2

    move-object/from16 v0, p0

    iput v2, v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->e:I

    .line 826
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->f:Landroid/media/MediaMuxer;

    invoke-virtual {v2}, Landroid/media/MediaMuxer;->start()V

    goto :goto_1

    .line 828
    .end local v12    # "newFormat":Landroid/media/MediaFormat;
    :cond_5
    if-gez v15, :cond_6

    .line 829
    invoke-static {}, Lcom/thinkware/sundo/ieve/ieveCameraView;->a()Ljava/lang/String;

    move-result-object v2

    const-string v4, "saveStream:drainEncode[unexpected result from encoder:%d]"

    const/4 v5, 0x1

    new-array v5, v5, [Ljava/lang/Object;

    const/4 v8, 0x0

    invoke-static {v15}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v17

    aput-object v17, v5, v8

    invoke-static {v4, v5}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v2, v4}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 830
    const/4 v2, 0x0

    goto/16 :goto_0

    .line 832
    :cond_6
    aget-object v14, v16, v15

    .line 833
    .local v14, "outputBuffer":Ljava/nio/ByteBuffer;
    if-nez v14, :cond_7

    .line 834
    invoke-static {}, Lcom/thinkware/sundo/ieve/ieveCameraView;->a()Ljava/lang/String;

    move-result-object v2

    const-string v4, "saveStream:drainEncode[outputBuffer is null:%d]"

    const/4 v5, 0x1

    new-array v5, v5, [Ljava/lang/Object;

    const/4 v8, 0x0

    invoke-static {v15}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v17

    aput-object v17, v5, v8

    invoke-static {v4, v5}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v2, v4}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 835
    const/4 v2, 0x0

    goto/16 :goto_0

    .line 837
    :cond_7
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->a:Landroid/media/MediaCodec$BufferInfo;

    iget v2, v2, Landroid/media/MediaCodec$BufferInfo;->flags:I

    and-int/lit8 v2, v2, 0x2

    if-eqz v2, :cond_8

    .line 838
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->a:Landroid/media/MediaCodec$BufferInfo;

    const/4 v4, 0x0

    iput v4, v2, Landroid/media/MediaCodec$BufferInfo;->size:I

    .line 840
    :cond_8
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->a:Landroid/media/MediaCodec$BufferInfo;

    iget v2, v2, Landroid/media/MediaCodec$BufferInfo;->offset:I

    invoke-virtual {v14, v2}, Ljava/nio/ByteBuffer;->position(I)Ljava/nio/Buffer;

    .line 841
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->a:Landroid/media/MediaCodec$BufferInfo;

    iget v2, v2, Landroid/media/MediaCodec$BufferInfo;->offset:I

    move-object/from16 v0, p0

    iget-object v4, v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->a:Landroid/media/MediaCodec$BufferInfo;

    iget v4, v4, Landroid/media/MediaCodec$BufferInfo;->size:I

    add-int/2addr v2, v4

    invoke-virtual {v14, v2}, Ljava/nio/ByteBuffer;->limit(I)Ljava/nio/Buffer;

    .line 842
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->f:Landroid/media/MediaMuxer;

    if-nez v2, :cond_9

    .line 843
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->a:Landroid/media/MediaCodec$BufferInfo;

    iget v2, v2, Landroid/media/MediaCodec$BufferInfo;->size:I

    new-array v13, v2, [B

    .line 844
    .local v13, "outdata":[B
    invoke-virtual {v14, v13}, Ljava/nio/ByteBuffer;->get([B)Ljava/nio/ByteBuffer;

    .line 846
    :try_start_0
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->j:Ljava/io/FileOutputStream;

    invoke-virtual {v2, v13}, Ljava/io/FileOutputStream;->write([B)V

    .line 847
    invoke-static {}, Lcom/thinkware/sundo/ieve/ieveCameraView;->a()Ljava/lang/String;

    move-result-object v2

    const-string v4, "saveStream:drainEncode[mOutputStream size: %d"

    const/4 v5, 0x1

    new-array v5, v5, [Ljava/lang/Object;

    const/4 v8, 0x0

    array-length v0, v13

    move/from16 v17, v0

    invoke-static/range {v17 .. v17}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v17

    aput-object v17, v5, v8

    invoke-static {v4, v5}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v2, v4}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    .line 848
    const/4 v13, 0x0

    .line 859
    .end local v13    # "outdata":[B
    :goto_2
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->h:Landroid/media/MediaCodec;

    const/4 v4, 0x0

    invoke-virtual {v2, v15, v4}, Landroid/media/MediaCodec;->releaseOutputBuffer(IZ)V

    goto/16 :goto_1

    .line 849
    .restart local v13    # "outdata":[B
    :catch_0
    move-exception v9

    .line 850
    .local v9, "e":Ljava/io/IOException;
    invoke-virtual {v9}, Ljava/io/IOException;->printStackTrace()V

    .line 851
    invoke-static {}, Lcom/thinkware/sundo/ieve/ieveCameraView;->a()Ljava/lang/String;

    move-result-object v2

    const-string v4, "saveStream:drainEncode[File write failed-IOException:%s]"

    const/4 v5, 0x1

    new-array v5, v5, [Ljava/lang/Object;

    const/4 v8, 0x0

    invoke-virtual {v9}, Ljava/io/IOException;->getLocalizedMessage()Ljava/lang/String;

    move-result-object v17

    aput-object v17, v5, v8

    invoke-static {v4, v5}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v2, v4}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 852
    new-instance v2, Ljava/lang/RuntimeException;

    invoke-direct {v2, v9}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V

    throw v2

    .line 856
    .end local v9    # "e":Ljava/io/IOException;
    .end local v13    # "outdata":[B
    :cond_9
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->f:Landroid/media/MediaMuxer;

    move-object/from16 v0, p0

    iget v4, v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->e:I

    move-object/from16 v0, p0

    iget-object v5, v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->a:Landroid/media/MediaCodec$BufferInfo;

    invoke-virtual {v2, v4, v14, v5}, Landroid/media/MediaMuxer;->writeSampleData(ILjava/nio/ByteBuffer;Landroid/media/MediaCodec$BufferInfo;)V

    .line 857
    move-object/from16 v0, p0

    iget v2, v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->d:I

    add-int/lit8 v2, v2, 0x1

    move-object/from16 v0, p0

    iput v2, v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->d:I

    goto :goto_2
.end method

.method protected b()V
    .locals 3

    .prologue
    const/4 v2, 0x0

    .line 760
    invoke-static {}, Lcom/thinkware/sundo/ieve/ieveCameraView;->a()Ljava/lang/String;

    move-result-object v0

    const-string v1, "saveStream:releaseEncoder"

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 761
    const/4 v0, 0x0

    iput v0, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->d:I

    .line 762
    const/4 v0, -0x1

    iput v0, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->e:I

    .line 763
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->h:Landroid/media/MediaCodec;

    if-eqz v0, :cond_0

    .line 764
    invoke-static {}, Lcom/thinkware/sundo/ieve/ieveCameraView;->a()Ljava/lang/String;

    move-result-object v0

    const-string v1, "saveStream:releaseEncoder[mEncoder.stop]"

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 765
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->h:Landroid/media/MediaCodec;

    invoke-virtual {v0}, Landroid/media/MediaCodec;->stop()V

    .line 766
    invoke-static {}, Lcom/thinkware/sundo/ieve/ieveCameraView;->a()Ljava/lang/String;

    move-result-object v0

    const-string v1, "saveStream:releaseEncoder[mEncoder.release]"

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 767
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->h:Landroid/media/MediaCodec;

    invoke-virtual {v0}, Landroid/media/MediaCodec;->release()V

    .line 768
    iput-object v2, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->h:Landroid/media/MediaCodec;

    .line 770
    :cond_0
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->i:Landroid/media/MediaFormat;

    if-eqz v0, :cond_1

    .line 771
    iput-object v2, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->i:Landroid/media/MediaFormat;

    .line 773
    :cond_1
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->a:Landroid/media/MediaCodec$BufferInfo;

    if-eqz v0, :cond_2

    .line 774
    iput-object v2, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->a:Landroid/media/MediaCodec$BufferInfo;

    .line 776
    :cond_2
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->f:Landroid/media/MediaMuxer;

    if-eqz v0, :cond_3

    .line 777
    invoke-static {}, Lcom/thinkware/sundo/ieve/ieveCameraView;->a()Ljava/lang/String;

    move-result-object v0

    const-string v1, "saveStream:releaseEncoder[mMuxer.stop]"

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 778
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->f:Landroid/media/MediaMuxer;

    invoke-virtual {v0}, Landroid/media/MediaMuxer;->stop()V

    .line 779
    invoke-static {}, Lcom/thinkware/sundo/ieve/ieveCameraView;->a()Ljava/lang/String;

    move-result-object v0

    const-string v1, "saveStream:releaseEncoder[mMuxer.release]"

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 780
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->f:Landroid/media/MediaMuxer;

    invoke-virtual {v0}, Landroid/media/MediaMuxer;->release()V

    .line 781
    iput-object v2, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->f:Landroid/media/MediaMuxer;

    .line 783
    :cond_3
    return-void
.end method

.method protected varargs synthetic doInBackground([Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .prologue
    .line 1
    check-cast p1, [Ljava/lang/Void;

    invoke-virtual {p0, p1}, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->a([Ljava/lang/Void;)Ljava/lang/Boolean;

    move-result-object v0

    return-object v0
.end method

.method protected onCancelled()V
    .locals 2

    .prologue
    .line 923
    invoke-super {p0}, Landroid/os/AsyncTask;->onCancelled()V

    .line 924
    invoke-static {}, Lcom/thinkware/sundo/ieve/ieveCameraView;->a()Ljava/lang/String;

    move-result-object v0

    const-string v1, "saveStream:onCancelled"

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 925
    return-void
.end method

.method protected synthetic onPostExecute(Ljava/lang/Object;)V
    .locals 0

    .prologue
    .line 1
    check-cast p1, Ljava/lang/Boolean;

    invoke-virtual {p0, p1}, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->a(Ljava/lang/Boolean;)V

    return-void
.end method

.method protected onPreExecute()V
    .locals 2

    .prologue
    .line 935
    invoke-super {p0}, Landroid/os/AsyncTask;->onPreExecute()V

    .line 936
    invoke-static {}, Lcom/thinkware/sundo/ieve/ieveCameraView;->a()Ljava/lang/String;

    move-result-object v0

    const-string v1, "saveStream:onPreExecute"

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 937
    return-void
.end method
