.class public final enum Ltas/internal/avm/AvmEnumerations$BootMode;
.super Ljava/lang/Enum;
.source "AvmEnumerations.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltas/internal/avm/AvmEnumerations;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "BootMode"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum",
        "<",
        "Ltas/internal/avm/AvmEnumerations$BootMode;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Ltas/internal/avm/AvmEnumerations$BootMode;

.field public static final enum BOOT_MODE_UNKNOWN:Ltas/internal/avm/AvmEnumerations$BootMode;

.field public static final enum CALIBRATION_MODE:Ltas/internal/avm/AvmEnumerations$BootMode;

.field public static final enum NORMAL_MODE:Ltas/internal/avm/AvmEnumerations$BootMode;

.field public static final enum UPGRADE_MODE:Ltas/internal/avm/AvmEnumerations$BootMode;

.field public static final enum WAIT_MODE:Ltas/internal/avm/AvmEnumerations$BootMode;


# instance fields
.field private mode:I


# direct methods
.method static constructor <clinit>()V
    .locals 8

    .prologue
    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v3, 0x0

    .line 361
    new-instance v0, Ltas/internal/avm/AvmEnumerations$BootMode;

    const-string/jumbo v1, "WAIT_MODE"

    invoke-direct {v0, v1, v3, v3}, Ltas/internal/avm/AvmEnumerations$BootMode;-><init>(Ljava/lang/String;II)V

    sput-object v0, Ltas/internal/avm/AvmEnumerations$BootMode;->WAIT_MODE:Ltas/internal/avm/AvmEnumerations$BootMode;

    .line 362
    new-instance v0, Ltas/internal/avm/AvmEnumerations$BootMode;

    const-string/jumbo v1, "NORMAL_MODE"

    invoke-direct {v0, v1, v4, v4}, Ltas/internal/avm/AvmEnumerations$BootMode;-><init>(Ljava/lang/String;II)V

    sput-object v0, Ltas/internal/avm/AvmEnumerations$BootMode;->NORMAL_MODE:Ltas/internal/avm/AvmEnumerations$BootMode;

    .line 363
    new-instance v0, Ltas/internal/avm/AvmEnumerations$BootMode;

    const-string/jumbo v1, "UPGRADE_MODE"

    invoke-direct {v0, v1, v5, v5}, Ltas/internal/avm/AvmEnumerations$BootMode;-><init>(Ljava/lang/String;II)V

    sput-object v0, Ltas/internal/avm/AvmEnumerations$BootMode;->UPGRADE_MODE:Ltas/internal/avm/AvmEnumerations$BootMode;

    .line 364
    new-instance v0, Ltas/internal/avm/AvmEnumerations$BootMode;

    const-string/jumbo v1, "CALIBRATION_MODE"

    invoke-direct {v0, v1, v6, v6}, Ltas/internal/avm/AvmEnumerations$BootMode;-><init>(Ljava/lang/String;II)V

    sput-object v0, Ltas/internal/avm/AvmEnumerations$BootMode;->CALIBRATION_MODE:Ltas/internal/avm/AvmEnumerations$BootMode;

    .line 365
    new-instance v0, Ltas/internal/avm/AvmEnumerations$BootMode;

    const-string/jumbo v1, "BOOT_MODE_UNKNOWN"

    const/16 v2, 0xff

    invoke-direct {v0, v1, v7, v2}, Ltas/internal/avm/AvmEnumerations$BootMode;-><init>(Ljava/lang/String;II)V

    sput-object v0, Ltas/internal/avm/AvmEnumerations$BootMode;->BOOT_MODE_UNKNOWN:Ltas/internal/avm/AvmEnumerations$BootMode;

    .line 360
    const/4 v0, 0x5

    new-array v0, v0, [Ltas/internal/avm/AvmEnumerations$BootMode;

    sget-object v1, Ltas/internal/avm/AvmEnumerations$BootMode;->WAIT_MODE:Ltas/internal/avm/AvmEnumerations$BootMode;

    aput-object v1, v0, v3

    sget-object v1, Ltas/internal/avm/AvmEnumerations$BootMode;->NORMAL_MODE:Ltas/internal/avm/AvmEnumerations$BootMode;

    aput-object v1, v0, v4

    sget-object v1, Ltas/internal/avm/AvmEnumerations$BootMode;->UPGRADE_MODE:Ltas/internal/avm/AvmEnumerations$BootMode;

    aput-object v1, v0, v5

    sget-object v1, Ltas/internal/avm/AvmEnumerations$BootMode;->CALIBRATION_MODE:Ltas/internal/avm/AvmEnumerations$BootMode;

    aput-object v1, v0, v6

    sget-object v1, Ltas/internal/avm/AvmEnumerations$BootMode;->BOOT_MODE_UNKNOWN:Ltas/internal/avm/AvmEnumerations$BootMode;

    aput-object v1, v0, v7

    sput-object v0, Ltas/internal/avm/AvmEnumerations$BootMode;->$VALUES:[Ltas/internal/avm/AvmEnumerations$BootMode;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .locals 0
    .param p3, "mode"    # I

    .prologue
    .line 368
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 369
    iput p3, p0, Ltas/internal/avm/AvmEnumerations$BootMode;->mode:I

    .line 368
    return-void
.end method

.method public static createFromOrdinalNumber(I)Ltas/internal/avm/AvmEnumerations$BootMode;
    .locals 5
    .param p0, "number"    # I

    .prologue
    .line 386
    invoke-static {}, Ltas/internal/avm/AvmEnumerations$BootMode;->values()[Ltas/internal/avm/AvmEnumerations$BootMode;

    move-result-object v2

    const/4 v1, 0x0

    array-length v3, v2

    :goto_0
    if-ge v1, v3, :cond_1

    aget-object v0, v2, v1

    .line 387
    .local v0, "i":Ltas/internal/avm/AvmEnumerations$BootMode;
    invoke-virtual {v0}, Ltas/internal/avm/AvmEnumerations$BootMode;->ordinal()I

    move-result v4

    if-ne v4, p0, :cond_0

    .line 388
    return-object v0

    .line 386
    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    .line 391
    .end local v0    # "i":Ltas/internal/avm/AvmEnumerations$BootMode;
    :cond_1
    sget-object v1, Ltas/internal/avm/AvmEnumerations$BootMode;->BOOT_MODE_UNKNOWN:Ltas/internal/avm/AvmEnumerations$BootMode;

    return-object v1
.end method

.method public static createFromValue(I)Ltas/internal/avm/AvmEnumerations$BootMode;
    .locals 5
    .param p0, "mode"    # I

    .prologue
    .line 377
    invoke-static {}, Ltas/internal/avm/AvmEnumerations$BootMode;->values()[Ltas/internal/avm/AvmEnumerations$BootMode;

    move-result-object v2

    const/4 v1, 0x0

    array-length v3, v2

    :goto_0
    if-ge v1, v3, :cond_1

    aget-object v0, v2, v1

    .line 378
    .local v0, "i":Ltas/internal/avm/AvmEnumerations$BootMode;
    invoke-virtual {v0}, Ltas/internal/avm/AvmEnumerations$BootMode;->toInteger()I

    move-result v4

    if-ne v4, p0, :cond_0

    .line 379
    return-object v0

    .line 377
    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    .line 382
    .end local v0    # "i":Ltas/internal/avm/AvmEnumerations$BootMode;
    :cond_1
    sget-object v1, Ltas/internal/avm/AvmEnumerations$BootMode;->BOOT_MODE_UNKNOWN:Ltas/internal/avm/AvmEnumerations$BootMode;

    return-object v1
.end method

.method public static valueOf(Ljava/lang/String;)Ltas/internal/avm/AvmEnumerations$BootMode;
    .locals 1
    .param p0, "name"    # Ljava/lang/String;

    .prologue
    .line 360
    const-class v0, Ltas/internal/avm/AvmEnumerations$BootMode;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object v0

    check-cast v0, Ltas/internal/avm/AvmEnumerations$BootMode;

    return-object v0
.end method

.method public static values()[Ltas/internal/avm/AvmEnumerations$BootMode;
    .locals 1

    .prologue
    .line 360
    sget-object v0, Ltas/internal/avm/AvmEnumerations$BootMode;->$VALUES:[Ltas/internal/avm/AvmEnumerations$BootMode;

    return-object v0
.end method


# virtual methods
.method public toInteger()I
    .locals 1

    .prologue
    .line 373
    iget v0, p0, Ltas/internal/avm/AvmEnumerations$BootMode;->mode:I

    return v0
.end method
