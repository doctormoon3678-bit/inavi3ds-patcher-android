.class public Ltas/ipc/ReplierSession;
.super Ljava/lang/Object;
.source "ReplierSession.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ltas/ipc/ReplierSession$1;
    }
.end annotation


# static fields
.field private static final CALLBACK:Ltas/internal/ipc/util/SyncdPool$Callback;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ltas/internal/ipc/util/SyncdPool$Callback",
            "<",
            "Ltas/ipc/ReplierSession;",
            ">;"
        }
    .end annotation
.end field

.field private static final sPool:Ltas/internal/ipc/util/SyncdPool;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ltas/internal/ipc/util/SyncdPool",
            "<",
            "Ltas/ipc/ReplierSession;",
            ">;"
        }
    .end annotation
.end field

.field private static sPoolId:I

.field private static sStamp:I


# instance fields
.field private allocated:Z

.field private next:Ltas/ipc/ReplierSession;

.field private pool:I

.field private session:Ltas/ipc/ReceiverSession;

.field private stamp:I

.field private what:I


# direct methods
.method static synthetic -get0(Ltas/ipc/ReplierSession;)Ltas/ipc/ReplierSession;
    .locals 1

    iget-object v0, p0, Ltas/ipc/ReplierSession;->next:Ltas/ipc/ReplierSession;

    return-object v0
.end method

.method static synthetic -get1()I
    .locals 1

    sget v0, Ltas/ipc/ReplierSession;->sPoolId:I

    return v0
.end method

.method static synthetic -set0(Ltas/ipc/ReplierSession;Ltas/ipc/ReplierSession;)Ltas/ipc/ReplierSession;
    .locals 0

    iput-object p1, p0, Ltas/ipc/ReplierSession;->next:Ltas/ipc/ReplierSession;

    return-object p1
.end method

.method static synthetic -set1(Ltas/ipc/ReplierSession;I)I
    .locals 0

    iput p1, p0, Ltas/ipc/ReplierSession;->pool:I

    return p1
.end method

.method static synthetic -set2(I)I
    .locals 0

    sput p0, Ltas/ipc/ReplierSession;->sPoolId:I

    return p0
.end method

.method static constructor <clinit>()V
    .locals 3

    .prologue
    const/4 v2, 0x0

    .line 132
    new-instance v0, Ltas/ipc/ReplierSession$1;

    invoke-direct {v0}, Ltas/ipc/ReplierSession$1;-><init>()V

    .line 131
    sput-object v0, Ltas/ipc/ReplierSession;->CALLBACK:Ltas/internal/ipc/util/SyncdPool$Callback;

    .line 149
    new-instance v0, Ltas/internal/ipc/util/SyncdPool;

    sget-object v1, Ltas/ipc/ReplierSession;->CALLBACK:Ltas/internal/ipc/util/SyncdPool$Callback;

    invoke-direct {v0, v1}, Ltas/internal/ipc/util/SyncdPool;-><init>(Ltas/internal/ipc/util/SyncdPool$Callback;)V

    .line 148
    sput-object v0, Ltas/ipc/ReplierSession;->sPool:Ltas/internal/ipc/util/SyncdPool;

    .line 150
    sput v2, Ltas/ipc/ReplierSession;->sStamp:I

    .line 151
    sput v2, Ltas/ipc/ReplierSession;->sPoolId:I

    .line 15
    return-void
.end method

.method private constructor <init>()V
    .locals 0

    .prologue
    .line 157
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method synthetic constructor <init>(Ltas/ipc/ReplierSession;)V
    .locals 0

    .prologue
    invoke-direct {p0}, Ltas/ipc/ReplierSession;-><init>()V

    return-void
.end method

.method private static obtain()Ltas/ipc/ReplierSession;
    .locals 3

    .prologue
    .line 118
    sget-object v1, Ltas/ipc/ReplierSession;->sPool:Ltas/internal/ipc/util/SyncdPool;

    invoke-virtual {v1}, Ltas/internal/ipc/util/SyncdPool;->allocate()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/ipc/ReplierSession;

    .line 119
    .local v0, "replier":Ltas/ipc/ReplierSession;
    sget v1, Ltas/ipc/ReplierSession;->sStamp:I

    add-int/lit8 v2, v1, 0x1

    sput v2, Ltas/ipc/ReplierSession;->sStamp:I

    iput v1, v0, Ltas/ipc/ReplierSession;->stamp:I

    .line 120
    const/4 v1, 0x1

    iput-boolean v1, v0, Ltas/ipc/ReplierSession;->allocated:Z

    .line 121
    return-object v0
.end method

.method static obtain(Ltas/ipc/ReceiverSession;I)Ltas/ipc/ReplierSession;
    .locals 1
    .param p0, "session"    # Ltas/ipc/ReceiverSession;
    .param p1, "what"    # I

    .prologue
    .line 111
    invoke-static {}, Ltas/ipc/ReplierSession;->obtain()Ltas/ipc/ReplierSession;

    move-result-object v0

    .line 112
    .local v0, "replier":Ltas/ipc/ReplierSession;
    iput-object p0, v0, Ltas/ipc/ReplierSession;->session:Ltas/ipc/ReceiverSession;

    .line 113
    iput p1, v0, Ltas/ipc/ReplierSession;->what:I

    .line 114
    return-object v0
.end method

.method private recycle()V
    .locals 1

    .prologue
    .line 125
    iget-boolean v0, p0, Ltas/ipc/ReplierSession;->allocated:Z

    if-eqz v0, :cond_0

    .line 126
    const/4 v0, 0x0

    iput-boolean v0, p0, Ltas/ipc/ReplierSession;->allocated:Z

    .line 127
    sget-object v0, Ltas/ipc/ReplierSession;->sPool:Ltas/internal/ipc/util/SyncdPool;

    invoke-virtual {v0, p0}, Ltas/internal/ipc/util/SyncdPool;->recycle(Ljava/lang/Object;)V

    .line 124
    :cond_0
    return-void
.end method


# virtual methods
.method public reply(II)V
    .locals 1
    .param p1, "arg1"    # I
    .param p2, "arg2"    # I

    .prologue
    .line 33
    iget v0, p0, Ltas/ipc/ReplierSession;->what:I

    invoke-static {v0, p1, p2}, Ltas/ipc/MsgData;->obtain(III)Ltas/ipc/MsgData;

    move-result-object v0

    invoke-virtual {p0, v0}, Ltas/ipc/ReplierSession;->reply(Ltas/ipc/MsgData;)V

    .line 32
    return-void
.end method

.method public varargs reply(II[I)V
    .locals 1
    .param p1, "arg1"    # I
    .param p2, "arg2"    # I
    .param p3, "args"    # [I

    .prologue
    .line 42
    iget v0, p0, Ltas/ipc/ReplierSession;->what:I

    invoke-static {v0, p1, p2, p3}, Ltas/ipc/MsgData;->obtain(III[I)Ltas/ipc/MsgData;

    move-result-object v0

    invoke-virtual {p0, v0}, Ltas/ipc/ReplierSession;->reply(Ltas/ipc/MsgData;)V

    .line 41
    return-void
.end method

.method public reply(II[ILjava/lang/String;Ljava/lang/String;[BLandroid/os/Bundle;)V
    .locals 8
    .param p1, "arg1"    # I
    .param p2, "arg2"    # I
    .param p3, "args"    # [I
    .param p4, "str1"    # Ljava/lang/String;
    .param p5, "str2"    # Ljava/lang/String;
    .param p6, "bytes"    # [B
    .param p7, "bundle"    # Landroid/os/Bundle;

    .prologue
    .line 93
    iget v0, p0, Ltas/ipc/ReplierSession;->what:I

    move v1, p1

    move v2, p2

    move-object v3, p3

    move-object v4, p4

    move-object v5, p5

    move-object v6, p6

    move-object v7, p7

    invoke-static/range {v0 .. v7}, Ltas/ipc/MsgData;->obtain(III[ILjava/lang/String;Ljava/lang/String;[BLandroid/os/Bundle;)Ltas/ipc/MsgData;

    move-result-object v0

    invoke-virtual {p0, v0}, Ltas/ipc/ReplierSession;->reply(Ltas/ipc/MsgData;)V

    .line 92
    return-void
.end method

.method public reply(Landroid/os/Bundle;)V
    .locals 1
    .param p1, "bundle"    # Landroid/os/Bundle;

    .prologue
    .line 78
    iget v0, p0, Ltas/ipc/ReplierSession;->what:I

    invoke-static {v0, p1}, Ltas/ipc/MsgData;->obtain(ILandroid/os/Bundle;)Ltas/ipc/MsgData;

    move-result-object v0

    invoke-virtual {p0, v0}, Ltas/ipc/ReplierSession;->reply(Ltas/ipc/MsgData;)V

    .line 77
    return-void
.end method

.method public reply(Ljava/lang/String;)V
    .locals 1
    .param p1, "str1"    # Ljava/lang/String;

    .prologue
    .line 49
    iget v0, p0, Ltas/ipc/ReplierSession;->what:I

    invoke-static {v0, p1}, Ltas/ipc/MsgData;->obtain(ILjava/lang/String;)Ltas/ipc/MsgData;

    move-result-object v0

    invoke-virtual {p0, v0}, Ltas/ipc/ReplierSession;->reply(Ltas/ipc/MsgData;)V

    .line 48
    return-void
.end method

.method public reply(Ljava/lang/String;Ljava/lang/String;)V
    .locals 1
    .param p1, "str1"    # Ljava/lang/String;
    .param p2, "str2"    # Ljava/lang/String;

    .prologue
    .line 57
    iget v0, p0, Ltas/ipc/ReplierSession;->what:I

    invoke-static {v0, p1, p2}, Ltas/ipc/MsgData;->obtain(ILjava/lang/String;Ljava/lang/String;)Ltas/ipc/MsgData;

    move-result-object v0

    invoke-virtual {p0, v0}, Ltas/ipc/ReplierSession;->reply(Ltas/ipc/MsgData;)V

    .line 56
    return-void
.end method

.method public reply(Ltas/ipc/MsgData;)V
    .locals 2
    .param p1, "msg"    # Ltas/ipc/MsgData;

    .prologue
    .line 100
    iget-boolean v0, p0, Ltas/ipc/ReplierSession;->allocated:Z

    if-eqz v0, :cond_0

    .line 101
    iget-object v0, p0, Ltas/ipc/ReplierSession;->session:Ltas/ipc/ReceiverSession;

    iget-object v0, v0, Ltas/ipc/ReceiverSession;->owner:Ltas/internal/ipc/Receiver;

    iget-object v1, p0, Ltas/ipc/ReplierSession;->session:Ltas/ipc/ReceiverSession;

    invoke-virtual {v0, v1, p1}, Ltas/internal/ipc/Receiver;->reply(Ltas/ipc/ReceiverSession;Ltas/ipc/MsgData;)V

    .line 102
    invoke-direct {p0}, Ltas/ipc/ReplierSession;->recycle()V

    .line 99
    :goto_0
    return-void

    .line 104
    :cond_0
    invoke-virtual {p1}, Ltas/ipc/MsgData;->recycle()V

    goto :goto_0
.end method

.method public reply([B)V
    .locals 1
    .param p1, "bytes"    # [B

    .prologue
    .line 71
    iget v0, p0, Ltas/ipc/ReplierSession;->what:I

    invoke-static {v0, p1}, Ltas/ipc/MsgData;->obtain(I[B)Ltas/ipc/MsgData;

    move-result-object v0

    invoke-virtual {p0, v0}, Ltas/ipc/ReplierSession;->reply(Ltas/ipc/MsgData;)V

    .line 70
    return-void
.end method

.method public reply([I)V
    .locals 1
    .param p1, "args"    # [I

    .prologue
    .line 64
    iget v0, p0, Ltas/ipc/ReplierSession;->what:I

    invoke-static {v0, p1}, Ltas/ipc/MsgData;->obtain(I[I)Ltas/ipc/MsgData;

    move-result-object v0

    invoke-virtual {p0, v0}, Ltas/ipc/ReplierSession;->reply(Ltas/ipc/MsgData;)V

    .line 63
    return-void
.end method

.method public session()Ltas/ipc/ReceiverSession;
    .locals 1

    .prologue
    .line 21
    iget-object v0, p0, Ltas/ipc/ReplierSession;->session:Ltas/ipc/ReceiverSession;

    return-object v0
.end method

.method public what()I
    .locals 1

    .prologue
    .line 25
    iget v0, p0, Ltas/ipc/ReplierSession;->what:I

    return v0
.end method
