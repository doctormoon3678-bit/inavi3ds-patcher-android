.class public final Ltas/internal/iobrigade/connector/IOData;
.super Ljava/lang/Object;
.source "IOData.java"


# static fields
.field public static ID:I


# instance fields
.field public mCharData:Ljava/lang/String;

.field public mErrCode:I

.field public mFlag:I

.field public mState:I


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .prologue
    .line 4
    const/16 v0, 0xff

    sput v0, Ltas/internal/iobrigade/connector/IOData;->ID:I

    .line 3
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .prologue
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
