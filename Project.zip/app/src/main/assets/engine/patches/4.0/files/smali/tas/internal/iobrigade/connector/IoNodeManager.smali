.class public final Ltas/internal/iobrigade/connector/IoNodeManager;
.super Ljava/lang/Object;
.source "IoNodeManager.java"


# static fields
.field private static final DEBUG:Z

.field private static final TAG:Ljava/lang/String;

.field private static mSelf:Ltas/internal/iobrigade/connector/IoNodeManager;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .prologue
    .line 13
    const-class v0, Ltas/internal/iobrigade/connector/IoNodeManager;

    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Ltas/internal/iobrigade/connector/IoNodeManager;->TAG:Ljava/lang/String;

    .line 17
    invoke-static {}, Ltas/internal/iobrigade/connector/util/JNIUtil;->loadNativeLibrary()V

    .line 10
    return-void
.end method

.method private constructor <init>()V
    .locals 0

    .prologue
    .line 23
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static initialize()V
    .locals 1

    .prologue
    .line 21
    new-instance v0, Ltas/internal/iobrigade/connector/IoNodeManager;

    invoke-direct {v0}, Ltas/internal/iobrigade/connector/IoNodeManager;-><init>()V

    sput-object v0, Ltas/internal/iobrigade/connector/IoNodeManager;->mSelf:Ltas/internal/iobrigade/connector/IoNodeManager;

    .line 20
    return-void
.end method

.method public static instance()Ltas/internal/iobrigade/connector/IoNodeManager;
    .locals 1

    .prologue
    .line 25
    sget-object v0, Ltas/internal/iobrigade/connector/IoNodeManager;->mSelf:Ltas/internal/iobrigade/connector/IoNodeManager;

    return-object v0
.end method

.method public static terminate()V
    .locals 0

    .prologue
    .line 27
    return-void
.end method


# virtual methods
.method public newEventNode(Ljava/lang/Class;)Ltas/internal/iobrigade/connector/EventNode;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/lang/Class",
            "<TT;>;)",
            "Ltas/internal/iobrigade/connector/EventNode;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/InstantiationException;,
            Ljava/lang/IllegalAccessException;
        }
    .end annotation

    .prologue
    .line 32
    .local p1, "cname":Ljava/lang/Class;, "Ljava/lang/Class<TT;>;"
    invoke-static {p1}, Ltas/internal/iobrigade/connector/EventNodeHelper;->newNode(Ljava/lang/Class;)Ltas/internal/iobrigade/connector/EventNode;

    move-result-object v0

    return-object v0
.end method

.method public notifyConsumerReady(Ltas/internal/iobrigade/connector/EventNode;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Ltas/internal/iobrigade/connector/EventNode",
            "<TT;>;)V"
        }
    .end annotation

    .prologue
    .line 45
    .local p1, "node":Ltas/internal/iobrigade/connector/EventNode;, "Ltas/internal/iobrigade/connector/EventNode<TT;>;"
    invoke-virtual {p1}, Ltas/internal/iobrigade/connector/EventNode;->notifyConsumerReady()V

    .line 44
    return-void
.end method

.method public sendMessageTo(Ltas/internal/iobrigade/connector/EventNode;Ljava/lang/String;)V
    .locals 0
    .param p2, "msgString"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Ltas/internal/iobrigade/connector/EventNode",
            "<TT;>;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .prologue
    .line 50
    .local p1, "node":Ltas/internal/iobrigade/connector/EventNode;, "Ltas/internal/iobrigade/connector/EventNode<TT;>;"
    invoke-virtual {p1, p2}, Ltas/internal/iobrigade/connector/EventNode;->sendMessageWith(Ljava/lang/String;)V

    .line 49
    return-void
.end method

.method public setAttributes(Ltas/internal/iobrigade/connector/EventNode;I)V
    .locals 0
    .param p2, "attribute"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Ltas/internal/iobrigade/connector/EventNode",
            "<TT;>;I)V"
        }
    .end annotation

    .prologue
    .line 41
    .local p1, "node":Ltas/internal/iobrigade/connector/EventNode;, "Ltas/internal/iobrigade/connector/EventNode<TT;>;"
    invoke-virtual {p1, p2}, Ltas/internal/iobrigade/connector/EventNode;->setAttributes(I)V

    .line 40
    return-void
.end method

.method public setEventConsumer(Ltas/internal/iobrigade/connector/EventNode;Ltas/internal/iobrigade/connector/IRemoteIOEvent;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Ltas/internal/iobrigade/connector/EventNode",
            "<TT;>;",
            "Ltas/internal/iobrigade/connector/IRemoteIOEvent",
            "<TT;>;)V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/NullPointerException;
        }
    .end annotation

    .prologue
    .line 37
    .local p1, "node":Ltas/internal/iobrigade/connector/EventNode;, "Ltas/internal/iobrigade/connector/EventNode<TT;>;"
    .local p2, "e":Ltas/internal/iobrigade/connector/IRemoteIOEvent;, "Ltas/internal/iobrigade/connector/IRemoteIOEvent<TT;>;"
    invoke-virtual {p1, p2}, Ltas/internal/iobrigade/connector/EventNode;->setConsumer(Ltas/internal/iobrigade/connector/IRemoteIOEvent;)V

    .line 36
    return-void
.end method
