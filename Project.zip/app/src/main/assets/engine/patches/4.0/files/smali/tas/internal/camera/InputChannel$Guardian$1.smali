.class Ltas/internal/camera/InputChannel$Guardian$1;
.super Ltas/internal/camera/util/CameraMonitor$SimpleCallback;
.source "InputChannel.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ltas/internal/camera/InputChannel$Guardian;->check(ILtas/internal/camera/InputSourceInner;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$1:Ltas/internal/camera/InputChannel$Guardian;

.field final synthetic val$input:Ltas/internal/camera/InputSourceInner;

.field final synthetic val$what:I


# direct methods
.method constructor <init>(Ltas/internal/camera/InputChannel$Guardian;ILtas/internal/camera/InputSourceInner;)V
    .locals 0
    .param p1, "this$1"    # Ltas/internal/camera/InputChannel$Guardian;
    .param p2, "val$what"    # I
    .param p3, "val$input"    # Ltas/internal/camera/InputSourceInner;

    .prologue
    .line 477
    iput-object p1, p0, Ltas/internal/camera/InputChannel$Guardian$1;->this$1:Ltas/internal/camera/InputChannel$Guardian;

    iput p2, p0, Ltas/internal/camera/InputChannel$Guardian$1;->val$what:I

    iput-object p3, p0, Ltas/internal/camera/InputChannel$Guardian$1;->val$input:Ltas/internal/camera/InputSourceInner;

    invoke-direct {p0}, Ltas/internal/camera/util/CameraMonitor$SimpleCallback;-><init>()V

    return-void
.end method


# virtual methods
.method public onCameraOpen(Ltas/internal/camera/util/CameraMonitor;I)V
    .locals 3
    .param p1, "m"    # Ltas/internal/camera/util/CameraMonitor;
    .param p2, "id"    # I

    .prologue
    .line 480
    iget v0, p0, Ltas/internal/camera/InputChannel$Guardian$1;->val$what:I

    if-nez v0, :cond_0

    .line 481
    iget-object v0, p0, Ltas/internal/camera/InputChannel$Guardian$1;->this$1:Ltas/internal/camera/InputChannel$Guardian;

    iget v1, p0, Ltas/internal/camera/InputChannel$Guardian$1;->val$what:I

    iget-object v2, p0, Ltas/internal/camera/InputChannel$Guardian$1;->val$input:Ltas/internal/camera/InputSourceInner;

    invoke-static {v0, v1, v2}, Ltas/internal/camera/InputChannel$Guardian;->-wrap4(Ltas/internal/camera/InputChannel$Guardian;ILtas/internal/camera/InputSourceInner;)V

    .line 479
    :goto_0
    return-void

    .line 483
    :cond_0
    iget-object v0, p0, Ltas/internal/camera/InputChannel$Guardian$1;->this$1:Ltas/internal/camera/InputChannel$Guardian;

    iget v1, p0, Ltas/internal/camera/InputChannel$Guardian$1;->val$what:I

    iget-object v2, p0, Ltas/internal/camera/InputChannel$Guardian$1;->val$input:Ltas/internal/camera/InputSourceInner;

    invoke-static {v0, v1, v2}, Ltas/internal/camera/InputChannel$Guardian;->-wrap3(Ltas/internal/camera/InputChannel$Guardian;ILtas/internal/camera/InputSourceInner;)V

    goto :goto_0
.end method

.method public onCameraRelease(Ltas/internal/camera/util/CameraMonitor;I)V
    .locals 3
    .param p1, "m"    # Ltas/internal/camera/util/CameraMonitor;
    .param p2, "id"    # I

    .prologue
    .line 489
    iget v0, p0, Ltas/internal/camera/InputChannel$Guardian$1;->val$what:I

    const/4 v1, 0x1

    if-ne v0, v1, :cond_0

    .line 490
    iget-object v0, p0, Ltas/internal/camera/InputChannel$Guardian$1;->this$1:Ltas/internal/camera/InputChannel$Guardian;

    iget v1, p0, Ltas/internal/camera/InputChannel$Guardian$1;->val$what:I

    iget-object v2, p0, Ltas/internal/camera/InputChannel$Guardian$1;->val$input:Ltas/internal/camera/InputSourceInner;

    invoke-static {v0, v1, v2}, Ltas/internal/camera/InputChannel$Guardian;->-wrap4(Ltas/internal/camera/InputChannel$Guardian;ILtas/internal/camera/InputSourceInner;)V

    .line 488
    :goto_0
    return-void

    .line 492
    :cond_0
    iget-object v0, p0, Ltas/internal/camera/InputChannel$Guardian$1;->this$1:Ltas/internal/camera/InputChannel$Guardian;

    iget v1, p0, Ltas/internal/camera/InputChannel$Guardian$1;->val$what:I

    iget-object v2, p0, Ltas/internal/camera/InputChannel$Guardian$1;->val$input:Ltas/internal/camera/InputSourceInner;

    invoke-static {v0, v1, v2}, Ltas/internal/camera/InputChannel$Guardian;->-wrap3(Ltas/internal/camera/InputChannel$Guardian;ILtas/internal/camera/InputSourceInner;)V

    goto :goto_0
.end method
