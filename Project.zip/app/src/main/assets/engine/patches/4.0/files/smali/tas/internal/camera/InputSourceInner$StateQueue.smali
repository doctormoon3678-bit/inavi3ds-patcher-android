.class Ltas/internal/camera/InputSourceInner$StateQueue;
.super Ltas/internal/camera/QueueBase;
.source "InputSourceInner.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltas/internal/camera/InputSourceInner;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "StateQueue"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ltas/internal/camera/QueueBase",
        "<",
        "Ljava/lang/Integer;",
        ">;"
    }
.end annotation


# instance fields
.field private mOwner:Ltas/internal/camera/InputSourceInner;


# direct methods
.method private constructor <init>(Ltas/internal/camera/InputSourceInner;)V
    .locals 0
    .param p1, "owner"    # Ltas/internal/camera/InputSourceInner;

    .prologue
    .line 464
    invoke-direct {p0}, Ltas/internal/camera/QueueBase;-><init>()V

    .line 465
    iput-object p1, p0, Ltas/internal/camera/InputSourceInner$StateQueue;->mOwner:Ltas/internal/camera/InputSourceInner;

    .line 464
    return-void
.end method

.method synthetic constructor <init>(Ltas/internal/camera/InputSourceInner;Ltas/internal/camera/InputSourceInner$StateQueue;)V
    .locals 0
    .param p1, "owner"    # Ltas/internal/camera/InputSourceInner;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/camera/InputSourceInner$StateQueue;-><init>(Ltas/internal/camera/InputSourceInner;)V

    return-void
.end method


# virtual methods
.method public onAvailable(Ljava/lang/Integer;)Z
    .locals 2
    .param p1, "state"    # Ljava/lang/Integer;

    .prologue
    .line 484
    iget-object v0, p0, Ltas/internal/camera/InputSourceInner$StateQueue;->mOwner:Ltas/internal/camera/InputSourceInner;

    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    invoke-static {v0, v1}, Ltas/internal/camera/InputSourceInner;->-wrap1(Ltas/internal/camera/InputSourceInner;I)Z

    move-result v0

    return v0
.end method

.method public bridge synthetic onAvailable(Ljava/lang/Object;)Z
    .locals 1
    .param p1, "state"    # Ljava/lang/Object;

    .prologue
    .line 483
    check-cast p1, Ljava/lang/Integer;

    .end local p1    # "state":Ljava/lang/Object;
    invoke-virtual {p0, p1}, Ltas/internal/camera/InputSourceInner$StateQueue;->onAvailable(Ljava/lang/Integer;)Z

    move-result v0

    return v0
.end method

.method public onDequeue()Ljava/lang/Integer;
    .locals 1

    .prologue
    .line 480
    invoke-virtual {p0}, Ltas/internal/camera/InputSourceInner$StateQueue;->pollHead()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    return-object v0
.end method

.method public bridge synthetic onDequeue()Ljava/lang/Object;
    .locals 1

    .prologue
    .line 468
    invoke-virtual {p0}, Ltas/internal/camera/InputSourceInner$StateQueue;->onDequeue()Ljava/lang/Integer;

    move-result-object v0

    return-object v0
.end method
