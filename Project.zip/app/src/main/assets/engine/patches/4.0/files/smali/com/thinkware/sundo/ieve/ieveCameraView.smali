.class public Lcom/thinkware/sundo/ieve/ieveCameraView;
.super Landroid/view/SurfaceView;
.source "ieveCameraView.java"

# interfaces
.implements Landroid/view/SurfaceHolder$Callback;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/thinkware/sundo/ieve/ieveCameraView$a;
    }
.end annotation


# static fields
.field private static final A:Ljava/lang/String; = "video/avc"

.field private static final B:I = 0x2dc6c0

.field private static final C:I = 0x1

.field private static final D:I = 0x2710

.field public static final IEVE_HMSG_ERROR_CAMERA:I = 0x3ed

.field public static final IEVE_HMSG_PREVIEW_PERFORM:I = 0x3f2

.field public static final IEVE_HMSG_PREVIEW_SNAPSHOT:I = 0x3fc

.field public static final IEVE_HMSG_PREVIEW_STOP:I = 0x44b

.field private static final a:Ljava/lang/String;

.field private static final e:I = 0x5

.field private static final f:I = 0xa

.field private static g:Z


# instance fields
.field private E:Z

.field private F:Z

.field private G:Z

.field private H:Z

.field private I:Z

.field private J:Z

.field private K:Ljava/lang/String;

.field private L:Ljava/lang/String;

.field private M:Ljava/lang/String;

.field private N:I

.field private O:I

.field private P:I

.field private Q:I

.field private R:Lcom/thinkware/sundo/ieve/ieveExifTag;

.field private S:Landroid/graphics/Bitmap;

.field private T:Ljava/util/Vector;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Vector",
            "<[B>;"
        }
    .end annotation
.end field

.field private U:Ljava/util/Vector;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Vector",
            "<[B>;"
        }
    .end annotation
.end field

.field private b:Landroid/content/Context;

.field private c:Landroid/view/SurfaceHolder;

.field private d:Landroid/os/Handler;

.field private h:Lcom/thinkware/sundo/ieve/ieveCameraView$a;

.field private i:Landroid/hardware/Camera;

.field private j:Z

.field private k:Z

.field private l:Z

.field private m:Z

.field private n:I

.field private o:I

.field private p:I

.field private q:I

.field private r:I

.field private s:I

.field private t:I

.field private u:I

.field private v:D

.field private w:D

.field private x:D

.field private y:D

.field private z:Landroid/hardware/Camera$PreviewCallback;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .prologue
    .line 43
    const-class v0, Lcom/thinkware/sundo/ieve/ieveCameraView;

    invoke-virtual {v0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveCameraView;->a:Ljava/lang/String;

    .line 52
    const/4 v0, 0x1

    sput-boolean v0, Lcom/thinkware/sundo/ieve/ieveCameraView;->g:Z

    .line 190
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;IIILandroid/os/Handler;I)V
    .locals 8
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "width"    # I
    .param p3, "height"    # I
    .param p4, "pixelformat"    # I
    .param p5, "handlerparent"    # Landroid/os/Handler;
    .param p6, "cameraid"    # I

    .prologue
    .line 198
    invoke-direct {p0, p1}, Landroid/view/SurfaceView;-><init>(Landroid/content/Context;)V

    .line 44
    const/4 v1, 0x0

    iput-object v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->b:Landroid/content/Context;

    .line 45
    const/4 v1, 0x0

    iput-object v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->c:Landroid/view/SurfaceHolder;

    .line 46
    const/4 v1, 0x0

    iput-object v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->d:Landroid/os/Handler;

    .line 53
    const/4 v1, 0x0

    iput-object v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->h:Lcom/thinkware/sundo/ieve/ieveCameraView$a;

    .line 144
    const/4 v1, 0x0

    iput-object v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->i:Landroid/hardware/Camera;

    .line 145
    const/4 v1, 0x1

    iput-boolean v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->j:Z

    .line 146
    const/4 v1, 0x0

    iput-boolean v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->k:Z

    .line 147
    const/4 v1, 0x0

    iput-boolean v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->l:Z

    .line 148
    const/4 v1, 0x1

    iput-boolean v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->m:Z

    .line 149
    const/4 v1, 0x0

    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->n:I

    .line 150
    const/4 v1, 0x0

    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->o:I

    .line 151
    const/4 v1, 0x0

    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->p:I

    .line 152
    const/4 v1, 0x0

    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->q:I

    .line 153
    const/16 v1, 0x500

    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->r:I

    .line 154
    const/16 v1, 0x2d0

    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->s:I

    .line 155
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->r:I

    iget v2, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->s:I

    mul-int/2addr v1, v2

    int-to-double v2, v1

    const-wide/high16 v4, 0x3ff8000000000000L    # 1.5

    mul-double/2addr v2, v4

    double-to-int v1, v2

    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->t:I

    .line 156
    const/4 v1, 0x0

    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->u:I

    .line 157
    const-wide v2, 0x403df851eb851eb8L    # 29.97

    iput-wide v2, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->v:D

    .line 158
    const-wide/16 v2, 0x0

    iput-wide v2, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->w:D

    .line 159
    const-wide v2, 0x403df851eb851eb8L    # 29.97

    iput-wide v2, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->x:D

    .line 160
    const-wide v2, 0x408f400000000000L    # 1000.0

    iget-wide v4, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->x:D

    const-wide/high16 v6, 0x4008000000000000L    # 3.0

    add-double/2addr v4, v6

    div-double/2addr v2, v4

    iput-wide v2, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->y:D

    .line 161
    const/4 v1, 0x0

    iput-object v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->z:Landroid/hardware/Camera$PreviewCallback;

    .line 168
    const/4 v1, 0x0

    iput-boolean v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->E:Z

    .line 169
    const/4 v1, 0x0

    iput-boolean v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->F:Z

    .line 170
    const/4 v1, 0x0

    iput-boolean v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->G:Z

    .line 171
    const/4 v1, 0x0

    iput-boolean v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->H:Z

    .line 172
    const/4 v1, 0x1

    iput-boolean v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->I:Z

    .line 173
    const/4 v1, 0x0

    iput-boolean v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->J:Z

    .line 174
    const/4 v1, 0x0

    iput-object v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->K:Ljava/lang/String;

    .line 175
    const/4 v1, 0x0

    iput-object v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->L:Ljava/lang/String;

    .line 176
    const/4 v1, 0x0

    iput-object v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->M:Ljava/lang/String;

    .line 177
    const/4 v1, 0x5

    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->N:I

    .line 178
    const/4 v1, 0x5

    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->O:I

    .line 179
    const/4 v1, -0x1

    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->P:I

    .line 180
    const/4 v1, -0x1

    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->Q:I

    .line 181
    const/4 v1, 0x0

    iput-object v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->R:Lcom/thinkware/sundo/ieve/ieveExifTag;

    .line 182
    const/4 v1, 0x0

    iput-object v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->S:Landroid/graphics/Bitmap;

    .line 183
    const/4 v1, 0x0

    iput-object v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->T:Ljava/util/Vector;

    .line 184
    const/4 v1, 0x0

    iput-object v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->U:Ljava/util/Vector;

    .line 199
    sget-object v1, Lcom/thinkware/sundo/ieve/ieveCameraView;->a:Ljava/lang/String;

    const-string v2, "Constructor"

    invoke-static {v1, v2}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 200
    iput-object p1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->b:Landroid/content/Context;

    .line 201
    iput p2, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->r:I

    .line 202
    iput p3, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->s:I

    .line 203
    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->r:I

    iget v2, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->s:I

    mul-int/2addr v1, v2

    int-to-double v2, v1

    const-wide/high16 v4, 0x3ff8000000000000L    # 1.5

    mul-double/2addr v2, v4

    double-to-int v1, v2

    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->t:I

    .line 204
    iput p4, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->q:I

    .line 205
    iput-object p5, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->d:Landroid/os/Handler;

    .line 206
    iput p6, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->o:I

    .line 207
    invoke-virtual {p0}, Lcom/thinkware/sundo/ieve/ieveCameraView;->getHolder()Landroid/view/SurfaceHolder;

    move-result-object v1

    iput-object v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->c:Landroid/view/SurfaceHolder;

    .line 208
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->c:Landroid/view/SurfaceHolder;

    invoke-interface {v1, p0}, Landroid/view/SurfaceHolder;->addCallback(Landroid/view/SurfaceHolder$Callback;)V

    .line 210
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->b:Landroid/content/Context;

    if-nez v1, :cond_1

    .line 211
    const-string v1, "Context is null!"

    const/4 v2, 0x0

    new-array v2, v2, [Ljava/lang/Object;

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    .line 212
    .local v0, "text":Ljava/lang/String;
    sget-object v1, Lcom/thinkware/sundo/ieve/ieveCameraView;->a:Ljava/lang/String;

    invoke-static {v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 219
    .end local v0    # "text":Ljava/lang/String;
    :cond_0
    :goto_0
    return-void

    .line 215
    :cond_1
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->d:Landroid/os/Handler;

    if-nez v1, :cond_0

    .line 216
    const-string v1, "HandlerParent is null!"

    const/4 v2, 0x0

    new-array v2, v2, [Ljava/lang/Object;

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    .line 217
    .restart local v0    # "text":Ljava/lang/String;
    sget-object v1, Lcom/thinkware/sundo/ieve/ieveCameraView;->a:Ljava/lang/String;

    invoke-static {v1, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0
.end method

.method private static a(II)I
    .locals 2
    .param p0, "x"    # I
    .param p1, "t"    # I

    .prologue
    .line 193
    add-int/lit8 v0, p1, -0x1

    add-int/2addr v0, p0

    add-int/lit8 v1, p1, -0x1

    xor-int/lit8 v1, v1, -0x1

    and-int/2addr v0, v1

    return v0
.end method

.method static synthetic a(Lcom/thinkware/sundo/ieve/ieveCameraView;)Landroid/os/Handler;
    .locals 1

    .prologue
    .line 46
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->d:Landroid/os/Handler;

    return-object v0
.end method

.method static synthetic a()Ljava/lang/String;
    .locals 1

    .prologue
    .line 43
    sget-object v0, Lcom/thinkware/sundo/ieve/ieveCameraView;->a:Ljava/lang/String;

    return-object v0
.end method

.method static synthetic a(Lcom/thinkware/sundo/ieve/ieveCameraView;D)V
    .locals 1

    .prologue
    .line 158
    iput-wide p1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->w:D

    return-void
.end method

.method static synthetic a(Lcom/thinkware/sundo/ieve/ieveCameraView;I)V
    .locals 0

    .prologue
    .line 156
    iput p1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->u:I

    return-void
.end method

.method static synthetic a(Lcom/thinkware/sundo/ieve/ieveCameraView;Landroid/graphics/Bitmap;)V
    .locals 0

    .prologue
    .line 182
    iput-object p1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->S:Landroid/graphics/Bitmap;

    return-void
.end method

.method static synthetic a(Lcom/thinkware/sundo/ieve/ieveCameraView;Lcom/thinkware/sundo/ieve/ieveExifTag;)V
    .locals 0

    .prologue
    .line 181
    iput-object p1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->R:Lcom/thinkware/sundo/ieve/ieveExifTag;

    return-void
.end method

.method static synthetic a(Lcom/thinkware/sundo/ieve/ieveCameraView;Ljava/lang/String;)V
    .locals 0

    .prologue
    .line 174
    iput-object p1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->K:Ljava/lang/String;

    return-void
.end method

.method static synthetic a(Lcom/thinkware/sundo/ieve/ieveCameraView;Z)V
    .locals 0

    .prologue
    .line 171
    iput-boolean p1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->H:Z

    return-void
.end method

.method static synthetic b(Lcom/thinkware/sundo/ieve/ieveCameraView;)I
    .locals 1

    .prologue
    .line 155
    iget v0, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->t:I

    return v0
.end method

.method static synthetic b(Lcom/thinkware/sundo/ieve/ieveCameraView;Ljava/lang/String;)V
    .locals 0

    .prologue
    .line 175
    iput-object p1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->L:Ljava/lang/String;

    return-void
.end method

.method static synthetic b(Lcom/thinkware/sundo/ieve/ieveCameraView;Z)V
    .locals 0

    .prologue
    .line 170
    iput-boolean p1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->G:Z

    return-void
.end method

.method private b()Z
    .locals 13

    .prologue
    const/16 v12, 0x3ed

    const/4 v11, 0x2

    const/4 v6, 0x1

    const/4 v5, 0x0

    .line 222
    iget-object v7, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->i:Landroid/hardware/Camera;

    if-eqz v7, :cond_1

    .line 269
    :cond_0
    :goto_0
    return v5

    .line 225
    :cond_1
    :try_start_0
    sget-boolean v7, Lcom/thinkware/sundo/ieve/ieveCameraView;->g:Z

    if-eqz v7, :cond_2

    new-instance v7, Lcom/thinkware/sundo/ieve/ieveCameraView$a;

    invoke-direct {v7, p0}, Lcom/thinkware/sundo/ieve/ieveCameraView$a;-><init>(Lcom/thinkware/sundo/ieve/ieveCameraView;)V

    iput-object v7, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->h:Lcom/thinkware/sundo/ieve/ieveCameraView$a;

    .line 227
    :cond_2
    iget-object v7, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->b:Landroid/content/Context;

    invoke-virtual {v7}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v7

    const-string v8, "com.thinkware.inavi3ds"

    invoke-virtual {v7, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    if-nez v7, :cond_3

    .line 228
    const-wide/16 v8, 0x64

    invoke-static {v8, v9}, Ljava/lang/Thread;->sleep(J)V

    .line 231
    :cond_3
    const/4 v1, 0x0

    .line 232
    .local v1, "i":I
    const-string v8, "cameraCreate[Thread:%s][Num of cameras:%d]"

    const/4 v7, 0x2

    new-array v9, v7, [Ljava/lang/Object;

    const/4 v10, 0x0

    sget-boolean v7, Lcom/thinkware/sundo/ieve/ieveCameraView;->g:Z

    if-eqz v7, :cond_4

    const-string v7, "Y"

    :goto_1
    aput-object v7, v9, v10

    const/4 v7, 0x1

    invoke-static {}, Landroid/hardware/Camera;->getNumberOfCameras()I

    move-result v10

    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v10

    aput-object v10, v9, v7

    invoke-static {v8, v9}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    .line 233
    .local v4, "text":Ljava/lang/String;
    sget-object v7, Lcom/thinkware/sundo/ieve/ieveCameraView;->a:Ljava/lang/String;

    invoke-static {v7, v4}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    move v2, v1

    .line 234
    .end local v1    # "i":I
    .local v2, "i":I
    :goto_2
    add-int/lit8 v1, v2, 0x1

    .end local v2    # "i":I
    .restart local v1    # "i":I
    const/4 v7, 0x3

    if-lt v2, v7, :cond_5

    .line 245
    :goto_3
    iget-object v7, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->i:Landroid/hardware/Camera;

    if-nez v7, :cond_7

    .line 246
    const/4 v7, 0x0

    iput-boolean v7, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->k:Z

    .line 247
    const-string v7, "Can not open the camera[ID:%d]."

    const/4 v8, 0x1

    new-array v8, v8, [Ljava/lang/Object;

    const/4 v9, 0x0

    iget v10, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->o:I

    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v10

    aput-object v10, v8, v9

    invoke-static {v7, v8}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    .line 248
    sget-object v7, Lcom/thinkware/sundo/ieve/ieveCameraView;->a:Ljava/lang/String;

    invoke-static {v7, v4}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 249
    iget-object v7, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->d:Landroid/os/Handler;

    if-eqz v7, :cond_0

    .line 250
    iget-object v7, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->d:Landroid/os/Handler;

    iget-object v8, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->d:Landroid/os/Handler;

    const/16 v9, 0x3ed

    invoke-static {v8, v9, v4}, Landroid/os/Message;->obtain(Landroid/os/Handler;ILjava/lang/Object;)Landroid/os/Message;

    move-result-object v8

    invoke-virtual {v7, v8}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    .line 259
    .end local v1    # "i":I
    .end local v4    # "text":Ljava/lang/String;
    :catch_0
    move-exception v0

    .line 260
    .local v0, "e":Ljava/lang/InterruptedException;
    invoke-virtual {v0}, Ljava/lang/InterruptedException;->printStackTrace()V

    .line 261
    iget-object v7, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->d:Landroid/os/Handler;

    if-eqz v7, :cond_0

    .line 262
    const-string v7, "Exception open the camera[%d][InterruptedException:%s]."

    new-array v8, v11, [Ljava/lang/Object;

    iget v9, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->o:I

    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    aput-object v9, v8, v5

    invoke-virtual {v0}, Ljava/lang/InterruptedException;->getLocalizedMessage()Ljava/lang/String;

    move-result-object v9

    aput-object v9, v8, v6

    invoke-static {v7, v8}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    .line 263
    .restart local v4    # "text":Ljava/lang/String;
    iget-object v6, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->d:Landroid/os/Handler;

    invoke-static {v6, v12, v4}, Landroid/os/Message;->obtain(Landroid/os/Handler;ILjava/lang/Object;)Landroid/os/Message;

    move-result-object v3

    .line 264
    .local v3, "msg":Landroid/os/Message;
    iget-object v6, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->d:Landroid/os/Handler;

    invoke-virtual {v6, v3}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto/16 :goto_0

    .line 232
    .end local v0    # "e":Ljava/lang/InterruptedException;
    .end local v3    # "msg":Landroid/os/Message;
    .end local v4    # "text":Ljava/lang/String;
    .restart local v1    # "i":I
    :cond_4
    :try_start_1
    const-string v7, "N"
    :try_end_1
    .catch Ljava/lang/InterruptedException; {:try_start_1 .. :try_end_1} :catch_0

    goto :goto_1

    .line 236
    .restart local v4    # "text":Ljava/lang/String;
    :cond_5
    :try_start_2
    sget-boolean v7, Lcom/thinkware/sundo/ieve/ieveCameraView;->g:Z

    if-eqz v7, :cond_6

    iget-object v7, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->h:Lcom/thinkware/sundo/ieve/ieveCameraView$a;

    iget v8, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->o:I

    invoke-virtual {v7, v8}, Lcom/thinkware/sundo/ieve/ieveCameraView$a;->a(I)Landroid/hardware/Camera;

    move-result-object v7

    iput-object v7, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->i:Landroid/hardware/Camera;
    :try_end_2
    .catch Ljava/lang/RuntimeException; {:try_start_2 .. :try_end_2} :catch_1
    .catch Ljava/lang/InterruptedException; {:try_start_2 .. :try_end_2} :catch_0

    goto :goto_3

    .line 239
    :catch_1
    move-exception v0

    .line 240
    .local v0, "e":Ljava/lang/RuntimeException;
    :try_start_3
    new-instance v7, Ljava/lang/StringBuilder;

    const-string v8, "cameraCreate[failed:"

    invoke-direct {v7, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/lang/RuntimeException;->getLocalizedMessage()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    const-string v8, "]"

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    const/4 v8, 0x0

    new-array v8, v8, [Ljava/lang/Object;

    invoke-static {v7, v8}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    .line 241
    sget-object v7, Lcom/thinkware/sundo/ieve/ieveCameraView;->a:Ljava/lang/String;

    invoke-static {v7, v4}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 242
    const-wide/16 v8, 0xa

    invoke-static {v8, v9}, Ljava/lang/Thread;->sleep(J)V
    :try_end_3
    .catch Ljava/lang/InterruptedException; {:try_start_3 .. :try_end_3} :catch_0

    move v2, v1

    .end local v1    # "i":I
    .restart local v2    # "i":I
    goto/16 :goto_2

    .line 237
    .end local v0    # "e":Ljava/lang/RuntimeException;
    .end local v2    # "i":I
    .restart local v1    # "i":I
    :cond_6
    :try_start_4
    iget v7, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->o:I

    invoke-static {v7}, Landroid/hardware/Camera;->open(I)Landroid/hardware/Camera;

    move-result-object v7

    iput-object v7, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->i:Landroid/hardware/Camera;
    :try_end_4
    .catch Ljava/lang/RuntimeException; {:try_start_4 .. :try_end_4} :catch_1
    .catch Ljava/lang/InterruptedException; {:try_start_4 .. :try_end_4} :catch_0

    goto/16 :goto_3

    .line 255
    :cond_7
    :try_start_5
    const-string v7, "cameraCreate[opened:ID:%d]"

    const/4 v8, 0x1

    new-array v8, v8, [Ljava/lang/Object;

    const/4 v9, 0x0

    iget v10, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->o:I

    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v10

    aput-object v10, v8, v9

    invoke-static {v7, v8}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    .line 256
    sget-object v7, Lcom/thinkware/sundo/ieve/ieveCameraView;->a:Ljava/lang/String;

    invoke-static {v7, v4}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 257
    const/4 v7, 0x1

    iput-boolean v7, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->k:Z
    :try_end_5
    .catch Ljava/lang/InterruptedException; {:try_start_5 .. :try_end_5} :catch_0

    move v5, v6

    .line 269
    goto/16 :goto_0
.end method

.method static synthetic c(Lcom/thinkware/sundo/ieve/ieveCameraView;)D
    .locals 2

    .prologue
    .line 160
    iget-wide v0, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->y:D

    return-wide v0
.end method

.method static synthetic c(Lcom/thinkware/sundo/ieve/ieveCameraView;Z)V
    .locals 0

    .prologue
    .line 168
    iput-boolean p1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->E:Z

    return-void
.end method

.method private c()Z
    .locals 14

    .prologue
    .line 302
    iget-object v9, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->i:Landroid/hardware/Camera;

    if-nez v9, :cond_0

    const/4 v9, 0x0

    .line 411
    :goto_0
    return v9

    .line 303
    :cond_0
    iget-boolean v9, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->k:Z

    if-nez v9, :cond_1

    const/4 v9, 0x0

    goto :goto_0

    .line 307
    :cond_1
    :try_start_0
    iget-object v9, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->i:Landroid/hardware/Camera;

    iget-object v10, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->c:Landroid/view/SurfaceHolder;

    invoke-virtual {v9, v10}, Landroid/hardware/Camera;->setPreviewDisplay(Landroid/view/SurfaceHolder;)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    .line 312
    :goto_1
    iget-object v9, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->i:Landroid/hardware/Camera;

    invoke-virtual {v9}, Landroid/hardware/Camera;->getParameters()Landroid/hardware/Camera$Parameters;

    move-result-object v5

    .line 313
    .local v5, "parameters":Landroid/hardware/Camera$Parameters;
    new-instance v9, Ljava/lang/StringBuilder;

    const-string v10, "cameraPreviewSetup[PixelFormat("

    invoke-direct {v9, v10}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget v10, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->q:I

    invoke-static {v10}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    const-string v10, ")]"

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    .line 314
    .local v7, "text":Ljava/lang/String;
    iget v9, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->q:I

    invoke-virtual {p0, v9}, Lcom/thinkware/sundo/ieve/ieveCameraView;->isSupportedPreviewFormat(I)Z

    move-result v9

    if-eqz v9, :cond_4

    .line 315
    iget v9, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->q:I

    invoke-virtual {v5, v9}, Landroid/hardware/Camera$Parameters;->setPreviewFormat(I)V

    .line 316
    sget-object v9, Lcom/thinkware/sundo/ieve/ieveCameraView;->a:Ljava/lang/String;

    invoke-static {v9, v7}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 323
    new-instance v9, Ljava/lang/StringBuilder;

    const-string v10, "cameraPreviewSetup[Resolution(width:"

    invoke-direct {v9, v10}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget v10, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->r:I

    invoke-static {v10}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    const-string v10, ",height:"

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    iget v10, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->s:I

    invoke-static {v10}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    const-string v10, ")]"

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    .line 324
    iget v9, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->r:I

    iget v10, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->s:I

    invoke-virtual {p0, v9, v10}, Lcom/thinkware/sundo/ieve/ieveCameraView;->isSupportedPreviewSize(II)Z

    move-result v9

    if-eqz v9, :cond_5

    .line 325
    iget v9, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->r:I

    iget v10, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->s:I

    invoke-virtual {v5, v9, v10}, Landroid/hardware/Camera$Parameters;->setPreviewSize(II)V

    .line 326
    sget-object v9, Lcom/thinkware/sundo/ieve/ieveCameraView;->a:Ljava/lang/String;

    invoke-static {v9, v7}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 333
    iget-boolean v9, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->j:Z

    if-eqz v9, :cond_6

    .line 334
    iget-wide v10, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->v:D

    const-wide v12, 0x408f400000000000L    # 1000.0

    mul-double/2addr v10, v12

    invoke-static {v10, v11}, Lcom/thinkware/sundo/ieve/ieveMath;->ROUND_OFF(D)J

    move-result-wide v10

    long-to-int v3, v10

    .line 345
    .local v3, "frameratems":I
    invoke-virtual {v5, v3, v3}, Landroid/hardware/Camera$Parameters;->setPreviewFpsRange(II)V

    .line 354
    .end local v3    # "frameratems":I
    :goto_2
    const-string v10, "cameraPreviewSetup[WithBuffers is %s, FrameRate is %.2fps]"

    const/4 v9, 0x2

    new-array v11, v9, [Ljava/lang/Object;

    const/4 v12, 0x0

    iget-boolean v9, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->j:Z

    if-eqz v9, :cond_7

    const-string v9, "true"

    :goto_3
    aput-object v9, v11, v12

    const/4 v9, 0x1

    iget-wide v12, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->v:D

    invoke-static {v12, v13}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v12

    aput-object v12, v11, v9

    invoke-static {v10, v11}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v7

    .line 355
    sget-object v9, Lcom/thinkware/sundo/ieve/ieveCameraView;->a:Ljava/lang/String;

    invoke-static {v9, v7}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 356
    iget-object v9, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->i:Landroid/hardware/Camera;

    invoke-virtual {v9, v5}, Landroid/hardware/Camera;->setParameters(Landroid/hardware/Camera$Parameters;)V

    .line 357
    iget-object v9, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->i:Landroid/hardware/Camera;

    new-instance v10, Lcom/thinkware/sundo/ieve/ieveCameraView$1;

    invoke-direct {v10, p0}, Lcom/thinkware/sundo/ieve/ieveCameraView$1;-><init>(Lcom/thinkware/sundo/ieve/ieveCameraView;)V

    invoke-virtual {v9, v10}, Landroid/hardware/Camera;->setErrorCallback(Landroid/hardware/Camera$ErrorCallback;)V

    .line 367
    const/4 v1, 0x0

    .line 368
    .local v1, "dummysize":I
    iget v9, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->p:I

    if-eqz v9, :cond_2

    iget v9, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->p:I

    const/4 v10, 0x1

    if-ne v9, v10, :cond_3

    .line 369
    :cond_2
    const/16 v1, 0x10

    .line 371
    :cond_3
    iget-object v9, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->i:Landroid/hardware/Camera;

    invoke-virtual {v9}, Landroid/hardware/Camera;->getParameters()Landroid/hardware/Camera$Parameters;

    move-result-object v9

    invoke-virtual {v9}, Landroid/hardware/Camera$Parameters;->getPreviewFormat()I

    move-result v9

    sparse-switch v9, :sswitch_data_0

    .line 382
    iget v9, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->r:I

    iget v10, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->s:I

    mul-int/2addr v9, v10

    iget-object v10, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->i:Landroid/hardware/Camera;

    invoke-virtual {v10}, Landroid/hardware/Camera;->getParameters()Landroid/hardware/Camera$Parameters;

    move-result-object v10

    invoke-virtual {v10}, Landroid/hardware/Camera$Parameters;->getPreviewFormat()I

    move-result v10

    invoke-static {v10}, Landroid/graphics/ImageFormat;->getBitsPerPixel(I)I

    move-result v10

    mul-int/2addr v9, v10

    div-int/lit8 v9, v9, 0x8

    add-int/2addr v9, v1

    iput v9, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->t:I

    .line 385
    :goto_4
    const-string v9, "cameraPreviewSetup[NeedSizeBuffer: %d]"

    const/4 v10, 0x1

    new-array v10, v10, [Ljava/lang/Object;

    const/4 v11, 0x0

    iget v12, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->t:I

    invoke-static {v12}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v12

    aput-object v12, v10, v11

    invoke-static {v9, v10}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v7

    .line 386
    sget-object v9, Lcom/thinkware/sundo/ieve/ieveCameraView;->a:Ljava/lang/String;

    invoke-static {v9, v7}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 388
    iget-boolean v9, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->m:Z

    if-eqz v9, :cond_a

    .line 389
    invoke-direct {p0}, Lcom/thinkware/sundo/ieve/ieveCameraView;->d()V

    .line 390
    iget-boolean v9, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->j:Z

    if-eqz v9, :cond_9

    .line 391
    const/4 v4, 0x0

    .local v4, "i":I
    :goto_5
    const/4 v9, 0x5

    if-lt v4, v9, :cond_8

    .line 394
    iget-object v9, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->i:Landroid/hardware/Camera;

    iget-object v10, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->z:Landroid/hardware/Camera$PreviewCallback;

    invoke-virtual {v9, v10}, Landroid/hardware/Camera;->setPreviewCallbackWithBuffer(Landroid/hardware/Camera$PreviewCallback;)V

    .line 399
    .end local v4    # "i":I
    :goto_6
    sget-object v9, Lcom/thinkware/sundo/ieve/ieveCameraView;->a:Ljava/lang/String;

    const-string v10, "cameraPreviewSetup[Use PreviewCallback]"

    invoke-static {v9, v10}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 411
    :goto_7
    const/4 v9, 0x1

    goto/16 :goto_0

    .line 308
    .end local v1    # "dummysize":I
    .end local v5    # "parameters":Landroid/hardware/Camera$Parameters;
    .end local v7    # "text":Ljava/lang/String;
    :catch_0
    move-exception v2

    .line 309
    .local v2, "e":Ljava/io/IOException;
    invoke-virtual {v2}, Ljava/io/IOException;->printStackTrace()V

    goto/16 :goto_1

    .line 319
    .end local v2    # "e":Ljava/io/IOException;
    .restart local v5    # "parameters":Landroid/hardware/Camera$Parameters;
    .restart local v7    # "text":Ljava/lang/String;
    :cond_4
    new-instance v9, Ljava/lang/StringBuilder;

    invoke-static {v7}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v10

    invoke-direct {v9, v10}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string v10, " is not supported by the camera."

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    .line 320
    sget-object v9, Lcom/thinkware/sundo/ieve/ieveCameraView;->a:Ljava/lang/String;

    invoke-static {v9, v7}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 321
    const/4 v9, 0x0

    goto/16 :goto_0

    .line 329
    :cond_5
    new-instance v9, Ljava/lang/StringBuilder;

    invoke-static {v7}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v10

    invoke-direct {v9, v10}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string v10, " is not supported by the camera."

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    .line 330
    sget-object v9, Lcom/thinkware/sundo/ieve/ieveCameraView;->a:Ljava/lang/String;

    invoke-static {v9, v7}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 331
    const/4 v9, 0x0

    goto/16 :goto_0

    .line 351
    :cond_6
    iget-wide v10, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->v:D

    invoke-static {v10, v11}, Lcom/thinkware/sundo/ieve/ieveMath;->ROUND_OFF(D)J

    move-result-wide v10

    long-to-int v9, v10

    invoke-virtual {v5, v9}, Landroid/hardware/Camera$Parameters;->setPreviewFrameRate(I)V

    goto/16 :goto_2

    .line 354
    :cond_7
    const-string v9, "false"

    goto/16 :goto_3

    .line 373
    .restart local v1    # "dummysize":I
    :sswitch_0
    iget v9, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->r:I

    const/16 v10, 0x10

    invoke-static {v9, v10}, Lcom/thinkware/sundo/ieve/ieveCameraView;->a(II)I

    move-result v6

    .line 374
    .local v6, "stride":I
    iget v9, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->s:I

    mul-int v8, v6, v9

    .line 375
    .local v8, "y_size":I
    div-int/lit8 v9, v6, 0x2

    const/16 v10, 0x10

    invoke-static {v9, v10}, Lcom/thinkware/sundo/ieve/ieveCameraView;->a(II)I

    move-result v9

    iget v10, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->s:I

    mul-int/2addr v9, v10

    div-int/lit8 v0, v9, 0x2

    .line 376
    .local v0, "c_size":I
    mul-int/lit8 v9, v0, 0x2

    add-int/2addr v9, v8

    add-int/2addr v9, v1

    iput v9, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->t:I

    .line 379
    .end local v0    # "c_size":I
    .end local v6    # "stride":I
    .end local v8    # "y_size":I
    :sswitch_1
    iget v9, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->r:I

    iget v10, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->s:I

    mul-int/2addr v9, v10

    int-to-double v10, v9

    const-wide/high16 v12, 0x3ff8000000000000L    # 1.5

    mul-double/2addr v10, v12

    double-to-int v9, v10

    add-int/2addr v9, v1

    iput v9, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->t:I

    goto/16 :goto_4

    .line 392
    .restart local v4    # "i":I
    :cond_8
    iget-object v9, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->i:Landroid/hardware/Camera;

    iget v10, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->t:I

    new-array v10, v10, [B

    invoke-virtual {v9, v10}, Landroid/hardware/Camera;->addCallbackBuffer([B)V

    .line 391
    add-int/lit8 v4, v4, 0x1

    goto/16 :goto_5

    .line 397
    .end local v4    # "i":I
    :cond_9
    iget-object v9, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->i:Landroid/hardware/Camera;

    iget-object v10, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->z:Landroid/hardware/Camera$PreviewCallback;

    invoke-virtual {v9, v10}, Landroid/hardware/Camera;->setPreviewCallback(Landroid/hardware/Camera$PreviewCallback;)V

    goto/16 :goto_6

    .line 402
    :cond_a
    iget-boolean v9, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->j:Z

    if-eqz v9, :cond_b

    .line 403
    iget-object v9, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->i:Landroid/hardware/Camera;

    const/4 v10, 0x0

    invoke-virtual {v9, v10}, Landroid/hardware/Camera;->setPreviewCallbackWithBuffer(Landroid/hardware/Camera$PreviewCallback;)V

    .line 408
    :goto_8
    sget-object v9, Lcom/thinkware/sundo/ieve/ieveCameraView;->a:Ljava/lang/String;

    const-string v10, "cameraPreviewSetup[Not use PreviewCallback]"

    invoke-static {v9, v10}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    goto/16 :goto_7

    .line 406
    :cond_b
    iget-object v9, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->i:Landroid/hardware/Camera;

    const/4 v10, 0x0

    invoke-virtual {v9, v10}, Landroid/hardware/Camera;->setPreviewCallback(Landroid/hardware/Camera$PreviewCallback;)V

    goto :goto_8

    .line 371
    nop

    :sswitch_data_0
    .sparse-switch
        0x11 -> :sswitch_1
        0x32315659 -> :sswitch_0
    .end sparse-switch
.end method

.method static synthetic d(Lcom/thinkware/sundo/ieve/ieveCameraView;)I
    .locals 1

    .prologue
    .line 156
    iget v0, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->u:I

    return v0
.end method

.method private d()V
    .locals 1

    .prologue
    .line 498
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2;

    invoke-direct {v0, p0}, Lcom/thinkware/sundo/ieve/ieveCameraView$2;-><init>(Lcom/thinkware/sundo/ieve/ieveCameraView;)V

    iput-object v0, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->z:Landroid/hardware/Camera$PreviewCallback;

    .line 1077
    return-void
.end method

.method static synthetic d(Lcom/thinkware/sundo/ieve/ieveCameraView;Z)V
    .locals 0

    .prologue
    .line 172
    iput-boolean p1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->I:Z

    return-void
.end method

.method private e()V
    .locals 1

    .prologue
    .line 1080
    const/4 v0, 0x0

    iput-object v0, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->z:Landroid/hardware/Camera$PreviewCallback;

    .line 1081
    return-void
.end method

.method static synthetic e(Lcom/thinkware/sundo/ieve/ieveCameraView;Z)V
    .locals 0

    .prologue
    .line 169
    iput-boolean p1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->F:Z

    return-void
.end method

.method static synthetic e(Lcom/thinkware/sundo/ieve/ieveCameraView;)Z
    .locals 1

    .prologue
    .line 168
    iget-boolean v0, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->E:Z

    return v0
.end method

.method static synthetic f(Lcom/thinkware/sundo/ieve/ieveCameraView;)Z
    .locals 1

    .prologue
    .line 170
    iget-boolean v0, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->G:Z

    return v0
.end method

.method static synthetic g(Lcom/thinkware/sundo/ieve/ieveCameraView;)Z
    .locals 1

    .prologue
    .line 173
    iget-boolean v0, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->J:Z

    return v0
.end method

.method static synthetic h(Lcom/thinkware/sundo/ieve/ieveCameraView;)Z
    .locals 1

    .prologue
    .line 169
    iget-boolean v0, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->F:Z

    return v0
.end method

.method static synthetic i(Lcom/thinkware/sundo/ieve/ieveCameraView;)Z
    .locals 1

    .prologue
    .line 171
    iget-boolean v0, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->H:Z

    return v0
.end method

.method static synthetic j(Lcom/thinkware/sundo/ieve/ieveCameraView;)Z
    .locals 1

    .prologue
    .line 172
    iget-boolean v0, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->I:Z

    return v0
.end method

.method static synthetic k(Lcom/thinkware/sundo/ieve/ieveCameraView;)Ljava/util/Vector;
    .locals 1

    .prologue
    .line 183
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->T:Ljava/util/Vector;

    return-object v0
.end method

.method static synthetic l(Lcom/thinkware/sundo/ieve/ieveCameraView;)I
    .locals 1

    .prologue
    .line 179
    iget v0, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->P:I

    return v0
.end method

.method static synthetic m(Lcom/thinkware/sundo/ieve/ieveCameraView;)Ljava/util/Vector;
    .locals 1

    .prologue
    .line 184
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->U:Ljava/util/Vector;

    return-object v0
.end method

.method static synthetic n(Lcom/thinkware/sundo/ieve/ieveCameraView;)I
    .locals 1

    .prologue
    .line 180
    iget v0, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->Q:I

    return v0
.end method

.method static synthetic o(Lcom/thinkware/sundo/ieve/ieveCameraView;)Z
    .locals 1

    .prologue
    .line 145
    iget-boolean v0, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->j:Z

    return v0
.end method

.method static synthetic p(Lcom/thinkware/sundo/ieve/ieveCameraView;)I
    .locals 1

    .prologue
    .line 152
    iget v0, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->q:I

    return v0
.end method

.method static synthetic q(Lcom/thinkware/sundo/ieve/ieveCameraView;)I
    .locals 1

    .prologue
    .line 153
    iget v0, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->r:I

    return v0
.end method

.method static synthetic r(Lcom/thinkware/sundo/ieve/ieveCameraView;)I
    .locals 1

    .prologue
    .line 154
    iget v0, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->s:I

    return v0
.end method

.method static synthetic s(Lcom/thinkware/sundo/ieve/ieveCameraView;)Landroid/graphics/Bitmap;
    .locals 1

    .prologue
    .line 182
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->S:Landroid/graphics/Bitmap;

    return-object v0
.end method

.method static synthetic t(Lcom/thinkware/sundo/ieve/ieveCameraView;)Ljava/lang/String;
    .locals 1

    .prologue
    .line 174
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->K:Ljava/lang/String;

    return-object v0
.end method

.method static synthetic u(Lcom/thinkware/sundo/ieve/ieveCameraView;)Lcom/thinkware/sundo/ieve/ieveExifTag;
    .locals 1

    .prologue
    .line 181
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->R:Lcom/thinkware/sundo/ieve/ieveExifTag;

    return-object v0
.end method

.method static synthetic v(Lcom/thinkware/sundo/ieve/ieveCameraView;)D
    .locals 2

    .prologue
    .line 157
    iget-wide v0, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->v:D

    return-wide v0
.end method

.method static synthetic w(Lcom/thinkware/sundo/ieve/ieveCameraView;)Ljava/lang/String;
    .locals 1

    .prologue
    .line 175
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->L:Ljava/lang/String;

    return-object v0
.end method

.method static synthetic x(Lcom/thinkware/sundo/ieve/ieveCameraView;)Landroid/content/Context;
    .locals 1

    .prologue
    .line 44
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->b:Landroid/content/Context;

    return-object v0
.end method


# virtual methods
.method public cameraDestroy()V
    .locals 15

    .prologue
    const/4 v14, 0x1

    const-wide v12, 0x412e848000000000L    # 1000000.0

    const/4 v11, 0x0

    const/4 v10, 0x0

    .line 275
    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v0

    .line 276
    .local v0, "_UptimeBase":J
    invoke-virtual {p0}, Lcom/thinkware/sundo/ieve/ieveCameraView;->cameraPreviewStop()Z

    .line 277
    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v4

    sub-long v2, v4, v0

    .line 278
    .local v2, "_UptimePeriod":J
    sget-object v4, Lcom/thinkware/sundo/ieve/ieveCameraView;->a:Ljava/lang/String;

    const-string v5, "cameraDestroy[cameraPreviewStop][Period:%.2fms]"

    new-array v6, v14, [Ljava/lang/Object;

    long-to-double v8, v2

    div-double/2addr v8, v12

    invoke-static {v8, v9}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v7

    aput-object v7, v6, v10

    invoke-static {v5, v6}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v5

    invoke-static {v4, v5}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 280
    iget-object v4, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->i:Landroid/hardware/Camera;

    if-eqz v4, :cond_0

    .line 281
    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v0

    .line 282
    iget-boolean v4, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->j:Z

    if-eqz v4, :cond_1

    .line 283
    iget-object v4, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->i:Landroid/hardware/Camera;

    invoke-virtual {v4, v11}, Landroid/hardware/Camera;->setPreviewCallbackWithBuffer(Landroid/hardware/Camera$PreviewCallback;)V

    .line 286
    :goto_0
    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v4

    sub-long v2, v4, v0

    .line 287
    sget-object v4, Lcom/thinkware/sundo/ieve/ieveCameraView;->a:Ljava/lang/String;

    const-string v5, "cameraDestroy[setPreviewCallbackWithBuffer NULL][Period:%.2fms]"

    new-array v6, v14, [Ljava/lang/Object;

    long-to-double v8, v2

    div-double/2addr v8, v12

    invoke-static {v8, v9}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v7

    aput-object v7, v6, v10

    invoke-static {v5, v6}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v5

    invoke-static {v4, v5}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 289
    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v0

    .line 290
    sget-boolean v4, Lcom/thinkware/sundo/ieve/ieveCameraView;->g:Z

    if-eqz v4, :cond_2

    iget-object v4, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->h:Lcom/thinkware/sundo/ieve/ieveCameraView$a;

    invoke-virtual {v4}, Lcom/thinkware/sundo/ieve/ieveCameraView$a;->b()V

    iput-object v11, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->h:Lcom/thinkware/sundo/ieve/ieveCameraView$a;

    .line 292
    :goto_1
    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v4

    sub-long v2, v4, v0

    .line 293
    sget-object v4, Lcom/thinkware/sundo/ieve/ieveCameraView;->a:Ljava/lang/String;

    const-string v5, "cameraDestroy[mCamera.release][Period:%.2fms]"

    new-array v6, v14, [Ljava/lang/Object;

    long-to-double v8, v2

    div-double/2addr v8, v12

    invoke-static {v8, v9}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v7

    aput-object v7, v6, v10

    invoke-static {v5, v6}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v5

    invoke-static {v4, v5}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 294
    iput-object v11, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->i:Landroid/hardware/Camera;

    .line 295
    iput-boolean v10, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->k:Z

    .line 297
    :cond_0
    invoke-direct {p0}, Lcom/thinkware/sundo/ieve/ieveCameraView;->e()V

    .line 298
    sget-object v4, Lcom/thinkware/sundo/ieve/ieveCameraView;->a:Ljava/lang/String;

    const-string v5, "cameraDestroy"

    invoke-static {v4, v5}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 299
    return-void

    .line 285
    :cond_1
    iget-object v4, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->i:Landroid/hardware/Camera;

    invoke-virtual {v4, v11}, Landroid/hardware/Camera;->setPreviewCallback(Landroid/hardware/Camera$PreviewCallback;)V

    goto :goto_0

    .line 291
    :cond_2
    iget-object v4, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->i:Landroid/hardware/Camera;

    invoke-virtual {v4}, Landroid/hardware/Camera;->release()V

    goto :goto_1
.end method

.method protected cameraPreviewStart()Z
    .locals 8

    .prologue
    const/4 v3, 0x1

    const/4 v2, 0x0

    .line 415
    iget-object v4, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->i:Landroid/hardware/Camera;

    if-nez v4, :cond_1

    .line 429
    :cond_0
    :goto_0
    return v2

    .line 416
    :cond_1
    iget-boolean v4, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->k:Z

    if-eqz v4, :cond_0

    .line 417
    iget-boolean v4, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->l:Z

    if-eqz v4, :cond_2

    move v2, v3

    goto :goto_0

    .line 418
    :cond_2
    iput v2, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->u:I

    .line 419
    iget-object v2, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->i:Landroid/hardware/Camera;

    invoke-virtual {v2}, Landroid/hardware/Camera;->startPreview()V

    .line 420
    iput-boolean v3, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->l:Z

    .line 421
    iget-boolean v2, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->J:Z

    if-eqz v2, :cond_3

    .line 422
    iget v2, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->N:I

    int-to-double v4, v2

    iget-wide v6, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->v:D

    mul-double/2addr v4, v6

    invoke-static {v4, v5}, Ljava/lang/Math;->round(D)J

    move-result-wide v4

    long-to-int v0, v4

    .line 423
    .local v0, "countafter":I
    iget v2, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->O:I

    int-to-double v4, v2

    iget-wide v6, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->v:D

    mul-double/2addr v4, v6

    invoke-static {v4, v5}, Ljava/lang/Math;->round(D)J

    move-result-wide v4

    long-to-int v1, v4

    .line 424
    .local v1, "countbefore":I
    invoke-virtual {p0, v1, v0}, Lcom/thinkware/sundo/ieve/ieveCameraView;->createStreamBuffers(II)V

    .line 427
    .end local v0    # "countafter":I
    .end local v1    # "countbefore":I
    :cond_3
    sget-object v2, Lcom/thinkware/sundo/ieve/ieveCameraView;->a:Ljava/lang/String;

    const-string v4, "cameraPreviewStart"

    invoke-static {v2, v4}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    move v2, v3

    .line 429
    goto :goto_0
.end method

.method protected cameraPreviewStop()Z
    .locals 14

    .prologue
    const-wide v12, 0x412e848000000000L    # 1000000.0

    const/4 v6, 0x1

    const/4 v5, 0x0

    .line 433
    iget-object v7, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->i:Landroid/hardware/Camera;

    if-nez v7, :cond_0

    .line 459
    :goto_0
    return v5

    .line 434
    :cond_0
    iget-boolean v7, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->l:Z

    if-nez v7, :cond_1

    move v5, v6

    goto :goto_0

    .line 437
    :cond_1
    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v0

    .line 438
    .local v0, "_UptimeBase":J
    iget-object v7, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->i:Landroid/hardware/Camera;

    invoke-virtual {v7}, Landroid/hardware/Camera;->stopPreview()V

    .line 439
    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v8

    sub-long v2, v8, v0

    .line 440
    .local v2, "_UptimePeriod":J
    sget-object v7, Lcom/thinkware/sundo/ieve/ieveCameraView;->a:Ljava/lang/String;

    const-string v8, "cameraPreviewStop[mCamera.stopPreview][Period:%.2fms]"

    new-array v9, v6, [Ljava/lang/Object;

    long-to-double v10, v2

    div-double/2addr v10, v12

    invoke-static {v10, v11}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v10

    aput-object v10, v9, v5

    invoke-static {v8, v9}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v8

    invoke-static {v7, v8}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 441
    iput-boolean v5, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->l:Z

    .line 443
    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v0

    .line 444
    invoke-virtual {p0}, Lcom/thinkware/sundo/ieve/ieveCameraView;->clearSnapshot()V

    .line 445
    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v8

    sub-long v2, v8, v0

    .line 446
    sget-object v7, Lcom/thinkware/sundo/ieve/ieveCameraView;->a:Ljava/lang/String;

    const-string v8, "cameraPreviewStop[clearSnapshot][Period:%.2fms]"

    new-array v9, v6, [Ljava/lang/Object;

    long-to-double v10, v2

    div-double/2addr v10, v12

    invoke-static {v10, v11}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v10

    aput-object v10, v9, v5

    invoke-static {v8, v9}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v8

    invoke-static {v7, v8}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 448
    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v0

    .line 449
    invoke-virtual {p0}, Lcom/thinkware/sundo/ieve/ieveCameraView;->clearStream()V

    .line 450
    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v8

    sub-long v2, v8, v0

    .line 451
    sget-object v7, Lcom/thinkware/sundo/ieve/ieveCameraView;->a:Ljava/lang/String;

    const-string v8, "cameraPreviewStop[clearStream][Period:%.2fms]"

    new-array v9, v6, [Ljava/lang/Object;

    long-to-double v10, v2

    div-double/2addr v10, v12

    invoke-static {v10, v11}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v10

    aput-object v10, v9, v5

    invoke-static {v8, v9}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v5

    invoke-static {v7, v5}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 453
    iget-object v5, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->d:Landroid/os/Handler;

    if-eqz v5, :cond_2

    .line 454
    iget-object v5, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->d:Landroid/os/Handler;

    const/16 v7, 0x44b

    invoke-static {v5, v7}, Landroid/os/Message;->obtain(Landroid/os/Handler;I)Landroid/os/Message;

    move-result-object v4

    .line 455
    .local v4, "msg":Landroid/os/Message;
    iget-object v5, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->d:Landroid/os/Handler;

    invoke-virtual {v5, v4}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    .line 457
    .end local v4    # "msg":Landroid/os/Message;
    :cond_2
    sget-object v5, Lcom/thinkware/sundo/ieve/ieveCameraView;->a:Ljava/lang/String;

    const-string v7, "cameraPreviewStop"

    invoke-static {v5, v7}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    move v5, v6

    .line 459
    goto/16 :goto_0
.end method

.method public clearSnapshot()V
    .locals 3

    .prologue
    const/4 v2, 0x0

    .line 463
    sget-object v0, Lcom/thinkware/sundo/ieve/ieveCameraView;->a:Ljava/lang/String;

    const-string v1, "clearSnapshot"

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 464
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->S:Landroid/graphics/Bitmap;

    if-eqz v0, :cond_0

    .line 465
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->S:Landroid/graphics/Bitmap;

    invoke-virtual {v0}, Landroid/graphics/Bitmap;->recycle()V

    .line 466
    sget-object v0, Lcom/thinkware/sundo/ieve/ieveCameraView;->a:Ljava/lang/String;

    const-string v1, "clearSnapshot[bitmap clean]"

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 468
    :cond_0
    iput-object v2, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->S:Landroid/graphics/Bitmap;

    .line 469
    iput-object v2, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->K:Ljava/lang/String;

    .line 470
    iput-object v2, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->R:Lcom/thinkware/sundo/ieve/ieveExifTag;

    .line 471
    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->E:Z

    .line 472
    return-void
.end method

.method protected clearStream()V
    .locals 5

    .prologue
    const/4 v4, 0x0

    .line 475
    iget-boolean v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->F:Z

    if-eqz v1, :cond_0

    .line 476
    const/4 v1, 0x0

    iput-boolean v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->F:Z

    .line 477
    :goto_0
    iget-boolean v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->H:Z

    if-nez v1, :cond_3

    .line 485
    const-wide/16 v2, 0x64

    :try_start_0
    invoke-static {v2, v3}, Ljava/lang/Thread;->sleep(J)V
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_1

    .line 490
    :cond_0
    :goto_1
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->T:Ljava/util/Vector;

    if-eqz v1, :cond_1

    iget-object v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->T:Ljava/util/Vector;

    invoke-virtual {v1}, Ljava/util/Vector;->clear()V

    .line 491
    :cond_1
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->U:Ljava/util/Vector;

    if-eqz v1, :cond_2

    iget-object v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->U:Ljava/util/Vector;

    invoke-virtual {v1}, Ljava/util/Vector;->clear()V

    .line 492
    :cond_2
    iput-object v4, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->T:Ljava/util/Vector;

    .line 493
    iput-object v4, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->U:Ljava/util/Vector;

    .line 494
    sget-object v1, Lcom/thinkware/sundo/ieve/ieveCameraView;->a:Ljava/lang/String;

    const-string v2, "clearStream"

    invoke-static {v1, v2}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 495
    return-void

    .line 479
    :cond_3
    const-wide/16 v2, 0x1

    :try_start_1
    invoke-static {v2, v3}, Ljava/lang/Thread;->sleep(J)V
    :try_end_1
    .catch Ljava/lang/InterruptedException; {:try_start_1 .. :try_end_1} :catch_0

    goto :goto_0

    .line 480
    :catch_0
    move-exception v0

    .line 481
    .local v0, "e":Ljava/lang/InterruptedException;
    invoke-virtual {v0}, Ljava/lang/InterruptedException;->printStackTrace()V

    goto :goto_0

    .line 486
    .end local v0    # "e":Ljava/lang/InterruptedException;
    :catch_1
    move-exception v0

    .line 487
    .restart local v0    # "e":Ljava/lang/InterruptedException;
    invoke-virtual {v0}, Ljava/lang/InterruptedException;->printStackTrace()V

    goto :goto_1
.end method

.method protected createStreamBuffers(II)V
    .locals 5
    .param p1, "beforeframe"    # I
    .param p2, "afterframe"    # I

    .prologue
    .line 1084
    sget-object v0, Lcom/thinkware/sundo/ieve/ieveCameraView;->a:Ljava/lang/String;

    const-string v1, "createStreamBuffers[beforeframe:%d, afterframe:%d]"

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    aput-object v4, v2, v3

    const/4 v3, 0x1

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    aput-object v4, v2, v3

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 1085
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->T:Ljava/util/Vector;

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->U:Ljava/util/Vector;

    if-eqz v0, :cond_0

    iget v0, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->Q:I

    if-ne v0, p1, :cond_0

    iget v0, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->P:I

    if-ne v0, p2, :cond_0

    .line 1090
    :goto_0
    return-void

    .line 1086
    :cond_0
    iput p2, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->P:I

    .line 1087
    iput p1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->Q:I

    .line 1088
    new-instance v0, Ljava/util/Vector;

    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->P:I

    invoke-direct {v0, v1}, Ljava/util/Vector;-><init>(I)V

    iput-object v0, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->T:Ljava/util/Vector;

    .line 1089
    new-instance v0, Ljava/util/Vector;

    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->Q:I

    invoke-direct {v0, v1}, Ljava/util/Vector;-><init>(I)V

    iput-object v0, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->U:Ljava/util/Vector;

    goto :goto_0
.end method

.method protected cvtColorNV21_NV12([BII)[B
    .locals 1
    .param p1, "src"    # [B
    .param p2, "width"    # I
    .param p3, "height"    # I

    .prologue
    .line 1093
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-direct {v0}, Lcom/thinkware/sundo/ieve/ieveNative;-><init>()V

    invoke-virtual {v0, p1, p2, p3}, Lcom/thinkware/sundo/ieve/ieveNative;->ConvertNV21ToNV12([BII)[B

    move-result-object v0

    return-object v0
.end method

.method public getBitmapSnapshot()Landroid/graphics/Bitmap;
    .locals 1

    .prologue
    .line 1132
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->S:Landroid/graphics/Bitmap;

    return-object v0
.end method

.method public getCamera()Landroid/hardware/Camera;
    .locals 1

    .prologue
    .line 1136
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->i:Landroid/hardware/Camera;

    return-object v0
.end method

.method public getFrameRatePreview()D
    .locals 2

    .prologue
    .line 1140
    iget-wide v0, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->v:D

    return-wide v0
.end method

.method public getFrameRateReal()D
    .locals 2

    .prologue
    .line 1144
    iget-wide v0, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->w:D

    return-wide v0
.end method

.method public getNeedSizeBuffer()I
    .locals 1

    .prologue
    .line 1185
    iget v0, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->t:I

    return v0
.end method

.method public getPreviewCallbackMaxFPS()D
    .locals 2

    .prologue
    .line 1189
    iget-wide v0, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->x:D

    return-wide v0
.end method

.method public getPreviewHeight()I
    .locals 1

    .prologue
    .line 1202
    iget v0, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->s:I

    return v0
.end method

.method public getPreviewSize()Landroid/hardware/Camera$Size;
    .locals 1

    .prologue
    .line 1193
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->i:Landroid/hardware/Camera;

    if-nez v0, :cond_0

    const/4 v0, 0x0

    .line 1194
    :goto_0
    return-object v0

    :cond_0
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->i:Landroid/hardware/Camera;

    invoke-virtual {v0}, Landroid/hardware/Camera;->getParameters()Landroid/hardware/Camera$Parameters;

    move-result-object v0

    invoke-virtual {v0}, Landroid/hardware/Camera$Parameters;->getPreviewSize()Landroid/hardware/Camera$Size;

    move-result-object v0

    goto :goto_0
.end method

.method public getPreviewWidth()I
    .locals 1

    .prologue
    .line 1198
    iget v0, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->r:I

    return v0
.end method

.method public getStreamSecondsAfter()I
    .locals 1

    .prologue
    .line 1206
    iget v0, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->N:I

    return v0
.end method

.method public getStreamSecondsBefore()I
    .locals 1

    .prologue
    .line 1210
    iget v0, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->O:I

    return v0
.end method

.method public isCameraOpened()Z
    .locals 1

    .prologue
    .line 1214
    iget-boolean v0, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->k:Z

    return v0
.end method

.method public isPreviewCallback()Z
    .locals 1

    .prologue
    .line 1222
    iget-boolean v0, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->m:Z

    return v0
.end method

.method public isPreviewStart()Z
    .locals 1

    .prologue
    .line 1218
    iget-boolean v0, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->l:Z

    return v0
.end method

.method public isSavingSnapshot()Z
    .locals 1

    .prologue
    .line 1226
    iget-boolean v0, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->G:Z

    return v0
.end method

.method public isSavingStream()Z
    .locals 1

    .prologue
    .line 1230
    iget-boolean v0, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->H:Z

    return v0
.end method

.method public isSupportSaveStream()Z
    .locals 1

    .prologue
    .line 1273
    iget-boolean v0, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->J:Z

    return v0
.end method

.method public isSupportedPreviewFormat(I)Z
    .locals 11
    .param p1, "pixelformat"    # I

    .prologue
    const/4 v6, 0x1

    const/4 v5, 0x0

    .line 1234
    iget-object v7, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->i:Landroid/hardware/Camera;

    if-nez v7, :cond_0

    .line 1249
    :goto_0
    return v5

    .line 1236
    :cond_0
    iget-object v7, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->i:Landroid/hardware/Camera;

    invoke-virtual {v7}, Landroid/hardware/Camera;->getParameters()Landroid/hardware/Camera$Parameters;

    move-result-object v1

    .line 1237
    .local v1, "parameters":Landroid/hardware/Camera$Parameters;
    const/4 v2, 0x0

    .line 1238
    .local v2, "supportedFormat":Ljava/lang/Integer;
    invoke-virtual {v1}, Landroid/hardware/Camera$Parameters;->getSupportedPreviewFormats()Ljava/util/List;

    move-result-object v3

    .line 1239
    .local v3, "supportedFormats":Ljava/util/List;, "Ljava/util/List<Ljava/lang/Integer;>;"
    invoke-interface {v3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    .line 1240
    .local v0, "it":Ljava/util/Iterator;, "Ljava/util/Iterator<Ljava/lang/Integer;>;"
    :cond_1
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-nez v7, :cond_2

    .line 1247
    const-string v7, "isSupportedPreviewFormat[Not support PixelFormat:%d]"

    new-array v6, v6, [Ljava/lang/Object;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    aput-object v8, v6, v5

    invoke-static {v7, v6}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    .line 1248
    .local v4, "text":Ljava/lang/String;
    sget-object v6, Lcom/thinkware/sundo/ieve/ieveCameraView;->a:Ljava/lang/String;

    invoke-static {v6, v4}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    .line 1241
    .end local v4    # "text":Ljava/lang/String;
    :cond_2
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    .end local v2    # "supportedFormat":Ljava/lang/Integer;
    check-cast v2, Ljava/lang/Integer;

    .line 1242
    .restart local v2    # "supportedFormat":Ljava/lang/Integer;
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v7

    if-ne v7, p1, :cond_1

    .line 1243
    sget-object v7, Lcom/thinkware/sundo/ieve/ieveCameraView;->a:Ljava/lang/String;

    const-string v8, "isSupportedPreviewFormat[Support PixelFormat:%d]"

    new-array v9, v6, [Ljava/lang/Object;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v10

    aput-object v10, v9, v5

    invoke-static {v8, v9}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v5

    invoke-static {v7, v5}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    move v5, v6

    .line 1244
    goto :goto_0
.end method

.method public isSupportedPreviewSize(II)Z
    .locals 10
    .param p1, "w"    # I
    .param p2, "h"    # I

    .prologue
    const/4 v8, 0x2

    const/4 v6, 0x1

    const/4 v5, 0x0

    .line 1254
    iget-object v7, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->i:Landroid/hardware/Camera;

    if-nez v7, :cond_0

    .line 1269
    :goto_0
    return v5

    .line 1255
    :cond_0
    iget-object v7, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->i:Landroid/hardware/Camera;

    invoke-virtual {v7}, Landroid/hardware/Camera;->getParameters()Landroid/hardware/Camera$Parameters;

    move-result-object v1

    .line 1256
    .local v1, "parameters":Landroid/hardware/Camera$Parameters;
    const/4 v2, 0x0

    .line 1257
    .local v2, "supportedSize":Landroid/hardware/Camera$Size;
    invoke-virtual {v1}, Landroid/hardware/Camera$Parameters;->getSupportedPreviewSizes()Ljava/util/List;

    move-result-object v3

    .line 1258
    .local v3, "supportedSizes":Ljava/util/List;, "Ljava/util/List<Landroid/hardware/Camera$Size;>;"
    invoke-interface {v3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    .line 1259
    .local v0, "it":Ljava/util/Iterator;, "Ljava/util/Iterator<Landroid/hardware/Camera$Size;>;"
    :cond_1
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-nez v7, :cond_2

    .line 1267
    const-string v7, "isSupportedPreviewSize[Not support size - w:%d,h:%d]"

    new-array v8, v8, [Ljava/lang/Object;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    aput-object v9, v8, v5

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    aput-object v9, v8, v6

    invoke-static {v7, v8}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    .line 1268
    .local v4, "text":Ljava/lang/String;
    sget-object v6, Lcom/thinkware/sundo/ieve/ieveCameraView;->a:Ljava/lang/String;

    invoke-static {v6, v4}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    .line 1260
    .end local v4    # "text":Ljava/lang/String;
    :cond_2
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    .end local v2    # "supportedSize":Landroid/hardware/Camera$Size;
    check-cast v2, Landroid/hardware/Camera$Size;

    .line 1261
    .restart local v2    # "supportedSize":Landroid/hardware/Camera$Size;
    iget v7, v2, Landroid/hardware/Camera$Size;->width:I

    if-ne v7, p1, :cond_1

    iget v7, v2, Landroid/hardware/Camera$Size;->height:I

    if-ne v7, p2, :cond_1

    .line 1262
    const-string v7, "isSupportedPreviewSize[w:%d,h:%d]"

    new-array v8, v8, [Ljava/lang/Object;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    aput-object v9, v8, v5

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    aput-object v5, v8, v6

    invoke-static {v7, v8}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    .line 1263
    .restart local v4    # "text":Ljava/lang/String;
    sget-object v5, Lcom/thinkware/sundo/ieve/ieveCameraView;->a:Ljava/lang/String;

    invoke-static {v5, v4}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    move v5, v6

    .line 1264
    goto :goto_0
.end method

.method public isTakingSnapshot()Z
    .locals 1

    .prologue
    .line 1277
    iget-boolean v0, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->E:Z

    return v0
.end method

.method public isTakingStream()Z
    .locals 1

    .prologue
    .line 1281
    iget-boolean v0, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->F:Z

    return v0
.end method

.method public setCameraID(I)V
    .locals 5
    .param p1, "cameraid"    # I

    .prologue
    .line 1290
    iput p1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->o:I

    .line 1291
    sget-object v0, Lcom/thinkware/sundo/ieve/ieveCameraView;->a:Ljava/lang/String;

    const-string v1, "setCameraID: %d"

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    iget v4, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->o:I

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    aput-object v4, v2, v3

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 1292
    return-void
.end method

.method public setCameraModelType(I)V
    .locals 5
    .param p1, "cameramodeltype"    # I

    .prologue
    .line 1285
    iput p1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->n:I

    .line 1286
    sget-object v0, Lcom/thinkware/sundo/ieve/ieveCameraView;->a:Ljava/lang/String;

    const-string v1, "setCameraModelType: %d"

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    iget v4, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->n:I

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    aput-object v4, v2, v3

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 1287
    return-void
.end method

.method public setDeviceModelType(I)V
    .locals 5
    .param p1, "devicemodeltype"    # I

    .prologue
    .line 1295
    iput p1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->p:I

    .line 1296
    sget-object v0, Lcom/thinkware/sundo/ieve/ieveCameraView;->a:Ljava/lang/String;

    const-string v1, "setDeviceModelType: %d"

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    iget v4, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->p:I

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    aput-object v4, v2, v3

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 1297
    return-void
.end method

.method public setFrameRate(D)V
    .locals 13
    .param p1, "framerate"    # D

    .prologue
    const/4 v11, 0x1

    const/4 v10, 0x0

    .line 1300
    iget-object v4, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->i:Landroid/hardware/Camera;

    if-nez v4, :cond_0

    .line 1320
    :goto_0
    return-void

    .line 1301
    :cond_0
    iget-object v4, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->i:Landroid/hardware/Camera;

    invoke-virtual {v4}, Landroid/hardware/Camera;->getParameters()Landroid/hardware/Camera$Parameters;

    move-result-object v2

    .line 1302
    .local v2, "parameters":Landroid/hardware/Camera$Parameters;
    const-wide/high16 v4, 0x3ff0000000000000L    # 1.0

    cmpg-double v4, p1, v4

    if-gez v4, :cond_3

    const-wide/high16 p1, 0x3ff0000000000000L    # 1.0

    .line 1304
    :cond_1
    :goto_1
    iput-wide p1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->v:D

    .line 1305
    sget-object v4, Lcom/thinkware/sundo/ieve/ieveCameraView;->a:Ljava/lang/String;

    const-string v5, "setFrameRate[%.2f]"

    new-array v6, v11, [Ljava/lang/Object;

    iget-wide v8, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->v:D

    invoke-static {v8, v9}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v7

    aput-object v7, v6, v10

    invoke-static {v5, v6}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v5

    invoke-static {v4, v5}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 1306
    iget-boolean v4, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->j:Z

    if-eqz v4, :cond_5

    .line 1307
    iget-wide v4, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->v:D

    const-wide v6, 0x408f400000000000L    # 1000.0

    mul-double/2addr v4, v6

    invoke-static {v4, v5}, Lcom/thinkware/sundo/ieve/ieveMath;->ROUND_OFF(D)J

    move-result-wide v4

    long-to-int v1, v4

    .line 1308
    .local v1, "frameratems":I
    invoke-virtual {v2}, Landroid/hardware/Camera$Parameters;->getSupportedPreviewFpsRange()Ljava/util/List;

    move-result-object v0

    .line 1309
    .local v0, "Supportedrange":Ljava/util/List;, "Ljava/util/List<[I>;"
    invoke-interface {v0, v10}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, [I

    .line 1310
    .local v3, "range":[I
    aget v4, v3, v10

    if-ge v1, v4, :cond_4

    .line 1311
    aget v1, v3, v10

    .line 1314
    :cond_2
    :goto_2
    invoke-virtual {v2, v1, v1}, Landroid/hardware/Camera$Parameters;->setPreviewFpsRange(II)V

    .line 1319
    .end local v0    # "Supportedrange":Ljava/util/List;, "Ljava/util/List<[I>;"
    .end local v1    # "frameratems":I
    .end local v3    # "range":[I
    :goto_3
    iget-object v4, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->i:Landroid/hardware/Camera;

    invoke-virtual {v4, v2}, Landroid/hardware/Camera;->setParameters(Landroid/hardware/Camera$Parameters;)V

    goto :goto_0

    .line 1303
    :cond_3
    const-wide/high16 v4, 0x403e000000000000L    # 30.0

    cmpl-double v4, p1, v4

    if-lez v4, :cond_1

    const-wide/high16 p1, 0x403e000000000000L    # 30.0

    goto :goto_1

    .line 1312
    .restart local v0    # "Supportedrange":Ljava/util/List;, "Ljava/util/List<[I>;"
    .restart local v1    # "frameratems":I
    .restart local v3    # "range":[I
    :cond_4
    aget v4, v3, v11

    if-le v1, v4, :cond_2

    .line 1313
    aget v1, v3, v11

    goto :goto_2

    .line 1317
    .end local v0    # "Supportedrange":Ljava/util/List;, "Ljava/util/List<[I>;"
    .end local v1    # "frameratems":I
    .end local v3    # "range":[I
    :cond_5
    iget-wide v4, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->v:D

    invoke-static {v4, v5}, Lcom/thinkware/sundo/ieve/ieveMath;->ROUND_OFF(D)J

    move-result-wide v4

    long-to-int v4, v4

    invoke-virtual {v2, v4}, Landroid/hardware/Camera$Parameters;->setPreviewFrameRate(I)V

    goto :goto_3
.end method

.method public setPreviewCallback(Z)V
    .locals 0
    .param p1, "enable"    # Z

    .prologue
    .line 1323
    iput-boolean p1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->m:Z

    .line 1324
    return-void
.end method

.method public setPreviewCallbackMaxFPS(D)V
    .locals 7
    .param p1, "fps"    # D

    .prologue
    .line 1327
    const-wide/high16 v0, 0x3ff0000000000000L    # 1.0

    cmpg-double v0, p1, v0

    if-gez v0, :cond_1

    const-wide/high16 p1, 0x3ff0000000000000L    # 1.0

    .line 1329
    :cond_0
    :goto_0
    iput-wide p1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->x:D

    .line 1330
    const-wide v0, 0x408f400000000000L    # 1000.0

    iget-wide v2, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->x:D

    const-wide/high16 v4, 0x4008000000000000L    # 3.0

    add-double/2addr v2, v4

    div-double/2addr v0, v2

    iput-wide v0, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->y:D

    .line 1331
    return-void

    .line 1328
    :cond_1
    const-wide/high16 v0, 0x403e000000000000L    # 30.0

    cmpl-double v0, p1, v0

    if-lez v0, :cond_0

    const-wide/high16 p1, 0x403e000000000000L    # 30.0

    goto :goto_0
.end method

.method public setSupportSaveStream(ZII)V
    .locals 8
    .param p1, "enable"    # Z
    .param p2, "beforeseconds"    # I
    .param p3, "afterseconds"    # I

    .prologue
    const/4 v7, 0x1

    .line 1334
    sget-object v3, Lcom/thinkware/sundo/ieve/ieveCameraView;->a:Ljava/lang/String;

    const-string v4, "setSupportSaveStream[enable:%s, beforeseconds:%d, afterseconds:%d]"

    const/4 v2, 0x3

    new-array v5, v2, [Ljava/lang/Object;

    const/4 v6, 0x0

    if-eqz p1, :cond_2

    const-string v2, "T"

    :goto_0
    aput-object v2, v5, v6

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    aput-object v2, v5, v7

    const/4 v2, 0x2

    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    aput-object v6, v5, v2

    invoke-static {v4, v5}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v3, v2}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 1335
    iput-boolean p1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->J:Z

    .line 1336
    iget-boolean v2, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->J:Z

    if-eqz v2, :cond_3

    .line 1337
    if-ge p2, v7, :cond_0

    const/4 p2, 0x1

    .line 1338
    :cond_0
    if-ge p3, v7, :cond_1

    const/4 p3, 0x1

    .line 1339
    :cond_1
    iput p3, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->N:I

    .line 1340
    iput p2, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->O:I

    .line 1341
    iget v2, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->N:I

    int-to-double v2, v2

    iget-wide v4, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->v:D

    mul-double/2addr v2, v4

    invoke-static {v2, v3}, Ljava/lang/Math;->round(D)J

    move-result-wide v2

    long-to-int v0, v2

    .line 1342
    .local v0, "countafter":I
    iget v2, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->O:I

    int-to-double v2, v2

    iget-wide v4, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->v:D

    mul-double/2addr v2, v4

    invoke-static {v2, v3}, Ljava/lang/Math;->round(D)J

    move-result-wide v2

    long-to-int v1, v2

    .line 1343
    .local v1, "countbefore":I
    invoke-virtual {p0, v1, v0}, Lcom/thinkware/sundo/ieve/ieveCameraView;->createStreamBuffers(II)V

    .line 1348
    .end local v0    # "countafter":I
    .end local v1    # "countbefore":I
    :goto_1
    return-void

    .line 1334
    :cond_2
    const-string v2, "F"

    goto :goto_0

    .line 1346
    :cond_3
    invoke-virtual {p0}, Lcom/thinkware/sundo/ieve/ieveCameraView;->clearStream()V

    goto :goto_1
.end method

.method public surfaceChanged(Landroid/view/SurfaceHolder;III)V
    .locals 5
    .param p1, "surface"    # Landroid/view/SurfaceHolder;
    .param p2, "format"    # I
    .param p3, "width"    # I
    .param p4, "height"    # I

    .prologue
    .line 1427
    sget-object v0, Lcom/thinkware/sundo/ieve/ieveCameraView;->a:Ljava/lang/String;

    const-string v1, "surfaceChanged[format:%d,w:%d,h:%d]"

    const/4 v2, 0x3

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    aput-object v4, v2, v3

    const/4 v3, 0x1

    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    aput-object v4, v2, v3

    const/4 v3, 0x2

    invoke-static {p4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    aput-object v4, v2, v3

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 1428
    invoke-virtual {p0}, Lcom/thinkware/sundo/ieve/ieveCameraView;->cameraPreviewStart()Z

    .line 1429
    return-void
.end method

.method public surfaceCreated(Landroid/view/SurfaceHolder;)V
    .locals 2
    .param p1, "surface"    # Landroid/view/SurfaceHolder;

    .prologue
    .line 1433
    sget-object v0, Lcom/thinkware/sundo/ieve/ieveCameraView;->a:Ljava/lang/String;

    const-string v1, "surfaceCreated"

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 1434
    invoke-direct {p0}, Lcom/thinkware/sundo/ieve/ieveCameraView;->b()Z

    .line 1435
    invoke-direct {p0}, Lcom/thinkware/sundo/ieve/ieveCameraView;->c()Z

    .line 1436
    return-void
.end method

.method public surfaceDestroyed(Landroid/view/SurfaceHolder;)V
    .locals 2
    .param p1, "surface"    # Landroid/view/SurfaceHolder;

    .prologue
    .line 1440
    sget-object v0, Lcom/thinkware/sundo/ieve/ieveCameraView;->a:Ljava/lang/String;

    const-string v1, "surfaceDestroyed"

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 1441
    invoke-virtual {p0}, Lcom/thinkware/sundo/ieve/ieveCameraView;->cameraDestroy()V

    .line 1442
    return-void
.end method

.method public takeSnapshot(Z)Z
    .locals 1
    .param p1, "showprogessdlg"    # Z

    .prologue
    const/4 v0, 0x0

    .line 1351
    invoke-virtual {p0, p1, v0, v0, v0}, Lcom/thinkware/sundo/ieve/ieveCameraView;->takeSnapshot(ZLjava/lang/String;Ljava/lang/String;Lcom/thinkware/sundo/ieve/ieveExifTag;)Z

    move-result v0

    return v0
.end method

.method public takeSnapshot(ZLjava/lang/String;Ljava/lang/String;Lcom/thinkware/sundo/ieve/ieveExifTag;)Z
    .locals 9
    .param p1, "showprogessdlg"    # Z
    .param p2, "pathname"    # Ljava/lang/String;
    .param p3, "filename"    # Ljava/lang/String;
    .param p4, "exiftag"    # Lcom/thinkware/sundo/ieve/ieveExifTag;

    .prologue
    const/4 v8, 0x2

    const/4 v5, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x0

    .line 1356
    iget-boolean v3, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->m:Z

    if-nez v3, :cond_0

    .line 1357
    const-string v2, "takeSnapshot[PreviewCallback is failed]"

    new-array v3, v1, [Ljava/lang/Object;

    invoke-static {v2, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    .line 1358
    .local v0, "text":Ljava/lang/String;
    sget-object v2, Lcom/thinkware/sundo/ieve/ieveCameraView;->a:Ljava/lang/String;

    invoke-static {v2, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 1388
    .end local v0    # "text":Ljava/lang/String;
    :goto_0
    return v1

    .line 1361
    :cond_0
    iget-boolean v3, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->E:Z

    if-eqz v3, :cond_1

    .line 1362
    const-string v2, "takeSnapshot[Previous Snapshot being taken]"

    new-array v3, v1, [Ljava/lang/Object;

    invoke-static {v2, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    .line 1363
    .restart local v0    # "text":Ljava/lang/String;
    sget-object v2, Lcom/thinkware/sundo/ieve/ieveCameraView;->a:Ljava/lang/String;

    invoke-static {v2, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    .line 1366
    .end local v0    # "text":Ljava/lang/String;
    :cond_1
    invoke-virtual {p0}, Lcom/thinkware/sundo/ieve/ieveCameraView;->clearSnapshot()V

    .line 1367
    if-eqz p2, :cond_2

    if-nez p3, :cond_3

    .line 1368
    :cond_2
    iput-object v5, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->K:Ljava/lang/String;

    .line 1369
    iput-object v5, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->R:Lcom/thinkware/sundo/ieve/ieveExifTag;

    .line 1370
    const-string v3, "takeSnapshot[File name is null]"

    new-array v1, v1, [Ljava/lang/Object;

    invoke-static {v3, v1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    .line 1371
    .restart local v0    # "text":Ljava/lang/String;
    sget-object v1, Lcom/thinkware/sundo/ieve/ieveCameraView;->a:Ljava/lang/String;

    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 1386
    .end local v0    # "text":Ljava/lang/String;
    :goto_1
    iput-boolean v2, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->E:Z

    move v1, v2

    .line 1388
    goto :goto_0

    .line 1374
    :cond_3
    const-string v3, "%s/%s"

    new-array v4, v8, [Ljava/lang/Object;

    aput-object p2, v4, v1

    aput-object p3, v4, v2

    invoke-static {v3, v4}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    iput-object v3, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->K:Ljava/lang/String;

    .line 1375
    if-nez p4, :cond_4

    .line 1376
    iput-object v5, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->R:Lcom/thinkware/sundo/ieve/ieveExifTag;

    .line 1377
    sget-object v3, Lcom/thinkware/sundo/ieve/ieveCameraView;->a:Ljava/lang/String;

    const-string v4, "takeSnapshot[%s, exif:null]"

    new-array v5, v2, [Ljava/lang/Object;

    iget-object v6, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->K:Ljava/lang/String;

    aput-object v6, v5, v1

    invoke-static {v4, v5}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v3, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_1

    .line 1380
    :cond_4
    new-instance v3, Lcom/thinkware/sundo/ieve/ieveExifTag;

    invoke-direct {v3}, Lcom/thinkware/sundo/ieve/ieveExifTag;-><init>()V

    iput-object v3, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->R:Lcom/thinkware/sundo/ieve/ieveExifTag;

    .line 1381
    iget-object v3, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->R:Lcom/thinkware/sundo/ieve/ieveExifTag;

    invoke-virtual {v3, p4}, Lcom/thinkware/sundo/ieve/ieveExifTag;->copy(Lcom/thinkware/sundo/ieve/ieveExifTag;)V

    .line 1382
    sget-object v3, Lcom/thinkware/sundo/ieve/ieveCameraView;->a:Ljava/lang/String;

    const-string v4, "takeSnapshot[%s, lat:%f, lon:%f, speedhmh:%d, angle:%d]"

    const/4 v5, 0x5

    new-array v5, v5, [Ljava/lang/Object;

    iget-object v6, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->K:Ljava/lang/String;

    aput-object v6, v5, v1

    iget-wide v6, p4, Lcom/thinkware/sundo/ieve/ieveExifTag;->latitude:D

    invoke-static {v6, v7}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v1

    aput-object v1, v5, v2

    iget-wide v6, p4, Lcom/thinkware/sundo/ieve/ieveExifTag;->longitude:D

    invoke-static {v6, v7}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v1

    aput-object v1, v5, v8

    const/4 v1, 0x3

    iget v6, p4, Lcom/thinkware/sundo/ieve/ieveExifTag;->carspeedhmh:I

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    aput-object v6, v5, v1

    const/4 v1, 0x4

    iget v6, p4, Lcom/thinkware/sundo/ieve/ieveExifTag;->carangle:I

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    aput-object v6, v5, v1

    invoke-static {v4, v5}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v3, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_1
.end method

.method public takeStream(Ljava/lang/String;Ljava/lang/String;)Z
    .locals 7
    .param p1, "pathname"    # Ljava/lang/String;
    .param p2, "filename"    # Ljava/lang/String;

    .prologue
    const/4 v2, 0x1

    const/4 v1, 0x0

    .line 1393
    iget-boolean v3, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->J:Z

    if-nez v3, :cond_0

    .line 1394
    const-string v2, "takeStream[mIsSupportSaveStream is false]"

    new-array v3, v1, [Ljava/lang/Object;

    invoke-static {v2, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    .line 1395
    .local v0, "text":Ljava/lang/String;
    sget-object v2, Lcom/thinkware/sundo/ieve/ieveCameraView;->a:Ljava/lang/String;

    invoke-static {v2, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 1422
    .end local v0    # "text":Ljava/lang/String;
    :goto_0
    return v1

    .line 1398
    :cond_0
    iget-boolean v3, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->m:Z

    if-nez v3, :cond_1

    .line 1399
    const-string v2, "takeStream[PreviewCallback is failed]"

    new-array v3, v1, [Ljava/lang/Object;

    invoke-static {v2, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    .line 1400
    .restart local v0    # "text":Ljava/lang/String;
    sget-object v2, Lcom/thinkware/sundo/ieve/ieveCameraView;->a:Ljava/lang/String;

    invoke-static {v2, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    .line 1403
    .end local v0    # "text":Ljava/lang/String;
    :cond_1
    iget-boolean v3, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->F:Z

    if-eqz v3, :cond_2

    .line 1404
    const-string v2, "takeStream[Previous stream being taken]"

    new-array v3, v1, [Ljava/lang/Object;

    invoke-static {v2, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    .line 1405
    .restart local v0    # "text":Ljava/lang/String;
    sget-object v2, Lcom/thinkware/sundo/ieve/ieveCameraView;->a:Ljava/lang/String;

    invoke-static {v2, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    .line 1408
    .end local v0    # "text":Ljava/lang/String;
    :cond_2
    if-eqz p1, :cond_3

    if-nez p2, :cond_4

    .line 1409
    :cond_3
    const/4 v2, 0x0

    iput-object v2, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->L:Ljava/lang/String;

    .line 1410
    const-string v2, "takeStream[File name is null]"

    new-array v3, v1, [Ljava/lang/Object;

    invoke-static {v2, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    .line 1411
    .restart local v0    # "text":Ljava/lang/String;
    sget-object v2, Lcom/thinkware/sundo/ieve/ieveCameraView;->a:Ljava/lang/String;

    invoke-static {v2, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    .line 1415
    .end local v0    # "text":Ljava/lang/String;
    :cond_4
    const-string v3, "%s/%s"

    const/4 v4, 0x2

    new-array v4, v4, [Ljava/lang/Object;

    aput-object p1, v4, v1

    aput-object p2, v4, v2

    invoke-static {v3, v4}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    iput-object v3, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->L:Ljava/lang/String;

    .line 1416
    const-string v3, "%s"

    new-array v4, v2, [Ljava/lang/Object;

    aput-object p1, v4, v1

    invoke-static {v3, v4}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    iput-object v3, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->M:Ljava/lang/String;

    .line 1417
    sget-object v3, Lcom/thinkware/sundo/ieve/ieveCameraView;->a:Ljava/lang/String;

    const-string v4, "takeStream[%s]"

    new-array v5, v2, [Ljava/lang/Object;

    iget-object v6, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->M:Ljava/lang/String;

    aput-object v6, v5, v1

    invoke-static {v4, v5}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v3, v4}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 1419
    iput-boolean v2, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->F:Z

    .line 1420
    iput-boolean v1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView;->I:Z

    .line 1421
    sget-object v1, Lcom/thinkware/sundo/ieve/ieveCameraView;->a:Ljava/lang/String;

    const-string v3, "takeStream[mIsTakingStream is true]"

    invoke-static {v1, v3}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    move v1, v2

    .line 1422
    goto :goto_0
.end method
