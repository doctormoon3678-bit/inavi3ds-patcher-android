.class public interface abstract Ltas/ipc/TransceiverSession$Callback;
.super Ljava/lang/Object;
.source "TransceiverSession.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltas/ipc/TransceiverSession;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "Callback"
.end annotation


# virtual methods
.method public abstract onReceive(Ltas/ipc/TransceiverSession;ILtas/ipc/MsgData;)V
.end method

.method public abstract onReceiverOffline(Ltas/ipc/TransceiverSession;)V
.end method

.method public abstract onReceiverOnline(Ltas/ipc/TransceiverSession;)V
.end method

.method public abstract onReceiverUpdate(Ltas/ipc/TransceiverSession;Landroid/os/Bundle;)V
.end method

.method public abstract onReply(Ltas/ipc/TransceiverSession;ILtas/ipc/MsgData;)V
.end method

.method public abstract onSenderOffline(Ltas/ipc/TransceiverSession;)V
.end method

.method public abstract onSenderOnline(Ltas/ipc/TransceiverSession;)V
.end method

.method public abstract onSenderUpdate(Ltas/ipc/TransceiverSession;Landroid/os/Bundle;)V
.end method
