.class final Ltas/internal/camera/server/RemoteMessage$2;
.super Ljava/lang/Object;
.source "RemoteMessage.java"

# interfaces
.implements Ltas/internal/ipc/util/SyncdPool$Callback;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltas/internal/camera/server/RemoteMessage;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ltas/internal/ipc/util/SyncdPool$Callback",
        "<",
        "Ltas/internal/camera/server/RemoteMessage;",
        ">;"
    }
.end annotation


# direct methods
.method constructor <init>()V
    .locals 0

    .prologue
    .line 57
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public bridge synthetic getNext(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1
    .param p1, "r"    # Ljava/lang/Object;

    .prologue
    .line 64
    check-cast p1, Ltas/internal/camera/server/RemoteMessage;

    .end local p1    # "r":Ljava/lang/Object;
    invoke-virtual {p0, p1}, Ltas/internal/camera/server/RemoteMessage$2;->getNext(Ltas/internal/camera/server/RemoteMessage;)Ltas/internal/camera/server/RemoteMessage;

    move-result-object v0

    return-object v0
.end method

.method public getNext(Ltas/internal/camera/server/RemoteMessage;)Ltas/internal/camera/server/RemoteMessage;
    .locals 1
    .param p1, "r"    # Ltas/internal/camera/server/RemoteMessage;

    .prologue
    .line 65
    invoke-static {p1}, Ltas/internal/camera/server/RemoteMessage;->-get0(Ltas/internal/camera/server/RemoteMessage;)Ltas/internal/camera/server/RemoteMessage;

    move-result-object v0

    return-object v0
.end method

.method public bridge synthetic newInstance()Ljava/lang/Object;
    .locals 1

    .prologue
    .line 58
    invoke-virtual {p0}, Ltas/internal/camera/server/RemoteMessage$2;->newInstance()Ltas/internal/camera/server/RemoteMessage;

    move-result-object v0

    return-object v0
.end method

.method public newInstance()Ltas/internal/camera/server/RemoteMessage;
    .locals 3

    .prologue
    .line 59
    new-instance v0, Ltas/internal/camera/server/RemoteMessage;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Ltas/internal/camera/server/RemoteMessage;-><init>(Ltas/internal/camera/server/RemoteMessage;)V

    .line 60
    .local v0, "rmsg":Ltas/internal/camera/server/RemoteMessage;
    invoke-static {}, Ltas/internal/camera/server/RemoteMessage;->-get1()I

    move-result v1

    add-int/lit8 v2, v1, 0x1

    invoke-static {v2}, Ltas/internal/camera/server/RemoteMessage;->-set2(I)I

    invoke-static {v0, v1}, Ltas/internal/camera/server/RemoteMessage;->-set1(Ltas/internal/camera/server/RemoteMessage;I)I

    .line 61
    return-object v0
.end method

.method public bridge synthetic setNext(Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 0
    .param p1, "r"    # Ljava/lang/Object;
    .param p2, "next"    # Ljava/lang/Object;

    .prologue
    .line 68
    check-cast p1, Ltas/internal/camera/server/RemoteMessage;

    .end local p1    # "r":Ljava/lang/Object;
    check-cast p2, Ltas/internal/camera/server/RemoteMessage;

    .end local p2    # "next":Ljava/lang/Object;
    invoke-virtual {p0, p1, p2}, Ltas/internal/camera/server/RemoteMessage$2;->setNext(Ltas/internal/camera/server/RemoteMessage;Ltas/internal/camera/server/RemoteMessage;)V

    return-void
.end method

.method public setNext(Ltas/internal/camera/server/RemoteMessage;Ltas/internal/camera/server/RemoteMessage;)V
    .locals 0
    .param p1, "r"    # Ltas/internal/camera/server/RemoteMessage;
    .param p2, "next"    # Ltas/internal/camera/server/RemoteMessage;

    .prologue
    .line 69
    invoke-static {p1, p2}, Ltas/internal/camera/server/RemoteMessage;->-set0(Ltas/internal/camera/server/RemoteMessage;Ltas/internal/camera/server/RemoteMessage;)Ltas/internal/camera/server/RemoteMessage;

    .line 68
    return-void
.end method
