.class Ltas/internal/camera/client/ServerConnection$ServerCallback;
.super Ltas/internal/camera/server/IServerCallback$Stub;
.source "ServerConnection.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltas/internal/camera/client/ServerConnection;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "ServerCallback"
.end annotation


# instance fields
.field private mM:Ljava/lang/ref/WeakReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference",
            "<",
            "Ltas/internal/camera/client/ServerConnection;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method private constructor <init>(Ltas/internal/camera/client/ServerConnection;)V
    .locals 1
    .param p1, "m"    # Ltas/internal/camera/client/ServerConnection;

    .prologue
    .line 272
    invoke-direct {p0}, Ltas/internal/camera/server/IServerCallback$Stub;-><init>()V

    .line 273
    new-instance v0, Ljava/lang/ref/WeakReference;

    invoke-direct {v0, p1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    iput-object v0, p0, Ltas/internal/camera/client/ServerConnection$ServerCallback;->mM:Ljava/lang/ref/WeakReference;

    .line 272
    return-void
.end method

.method synthetic constructor <init>(Ltas/internal/camera/client/ServerConnection;Ltas/internal/camera/client/ServerConnection$ServerCallback;)V
    .locals 0
    .param p1, "m"    # Ltas/internal/camera/client/ServerConnection;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/camera/client/ServerConnection$ServerCallback;-><init>(Ltas/internal/camera/client/ServerConnection;)V

    return-void
.end method


# virtual methods
.method public onCableState(Ltas/internal/camera/server/RemoteMessage;)V
    .locals 2
    .param p1, "msg"    # Ltas/internal/camera/server/RemoteMessage;

    .prologue
    .line 287
    iget-object v1, p0, Ltas/internal/camera/client/ServerConnection$ServerCallback;->mM:Ljava/lang/ref/WeakReference;

    invoke-virtual {v1}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/camera/client/ServerConnection;

    .line 288
    .local v0, "m":Ltas/internal/camera/client/ServerConnection;
    if-eqz v0, :cond_0

    .line 289
    iget-object v1, p1, Ltas/internal/camera/server/RemoteMessage;->params:Ltas/internal/camera/InputParams;

    invoke-static {v0, v1}, Ltas/internal/camera/client/ServerConnection;->-wrap0(Ltas/internal/camera/client/ServerConnection;Ltas/internal/camera/InputParams;)V

    .line 291
    :cond_0
    invoke-virtual {p1}, Ltas/internal/camera/server/RemoteMessage;->recycle()V

    .line 286
    return-void
.end method

.method public onCameraMessage(Ltas/internal/camera/server/RemoteMessage;)V
    .locals 2
    .param p1, "msg"    # Ltas/internal/camera/server/RemoteMessage;

    .prologue
    .line 305
    iget-object v1, p0, Ltas/internal/camera/client/ServerConnection$ServerCallback;->mM:Ljava/lang/ref/WeakReference;

    invoke-virtual {v1}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/camera/client/ServerConnection;

    .line 306
    .local v0, "m":Ltas/internal/camera/client/ServerConnection;
    if-eqz v0, :cond_0

    .line 307
    iget-object v1, p1, Ltas/internal/camera/server/RemoteMessage;->params:Ltas/internal/camera/InputParams;

    invoke-static {v0, v1}, Ltas/internal/camera/client/ServerConnection;->-wrap1(Ltas/internal/camera/client/ServerConnection;Ltas/internal/camera/InputParams;)V

    .line 309
    :cond_0
    invoke-virtual {p1}, Ltas/internal/camera/server/RemoteMessage;->recycle()V

    .line 304
    return-void
.end method

.method public onCameraState(Ltas/internal/camera/server/RemoteMessage;)V
    .locals 2
    .param p1, "msg"    # Ltas/internal/camera/server/RemoteMessage;

    .prologue
    .line 296
    iget-object v1, p0, Ltas/internal/camera/client/ServerConnection$ServerCallback;->mM:Ljava/lang/ref/WeakReference;

    invoke-virtual {v1}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/camera/client/ServerConnection;

    .line 297
    .local v0, "m":Ltas/internal/camera/client/ServerConnection;
    if-eqz v0, :cond_0

    .line 298
    iget-object v1, p1, Ltas/internal/camera/server/RemoteMessage;->params:Ltas/internal/camera/InputParams;

    invoke-static {v0, v1}, Ltas/internal/camera/client/ServerConnection;->-wrap2(Ltas/internal/camera/client/ServerConnection;Ltas/internal/camera/InputParams;)V

    .line 300
    :cond_0
    invoke-virtual {p1}, Ltas/internal/camera/server/RemoteMessage;->recycle()V

    .line 295
    return-void
.end method

.method public onExtraState(Ltas/internal/camera/server/RemoteMessage;)V
    .locals 2
    .param p1, "msg"    # Ltas/internal/camera/server/RemoteMessage;

    .prologue
    .line 314
    iget-object v1, p0, Ltas/internal/camera/client/ServerConnection$ServerCallback;->mM:Ljava/lang/ref/WeakReference;

    invoke-virtual {v1}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/camera/client/ServerConnection;

    .line 315
    .local v0, "m":Ltas/internal/camera/client/ServerConnection;
    if-eqz v0, :cond_0

    .line 316
    iget-object v1, p1, Ltas/internal/camera/server/RemoteMessage;->params:Ltas/internal/camera/InputParams;

    invoke-static {v0, v1}, Ltas/internal/camera/client/ServerConnection;->-wrap3(Ltas/internal/camera/client/ServerConnection;Ltas/internal/camera/InputParams;)V

    .line 318
    :cond_0
    invoke-virtual {p1}, Ltas/internal/camera/server/RemoteMessage;->recycle()V

    .line 313
    return-void
.end method

.method public onInitialState(Ltas/internal/camera/server/RemoteMessage;)V
    .locals 2
    .param p1, "msg"    # Ltas/internal/camera/server/RemoteMessage;

    .prologue
    .line 278
    iget-object v1, p0, Ltas/internal/camera/client/ServerConnection$ServerCallback;->mM:Ljava/lang/ref/WeakReference;

    invoke-virtual {v1}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/camera/client/ServerConnection;

    .line 279
    .local v0, "m":Ltas/internal/camera/client/ServerConnection;
    if-eqz v0, :cond_0

    .line 280
    iget-object v1, p1, Ltas/internal/camera/server/RemoteMessage;->params:Ltas/internal/camera/InputParams;

    invoke-static {v0, v1}, Ltas/internal/camera/client/ServerConnection;->-wrap4(Ltas/internal/camera/client/ServerConnection;Ltas/internal/camera/InputParams;)V

    .line 282
    :cond_0
    invoke-virtual {p1}, Ltas/internal/camera/server/RemoteMessage;->recycle()V

    .line 277
    return-void
.end method

.method public onMediaServerState(Ltas/internal/camera/server/RemoteMessage;)V
    .locals 2
    .param p1, "msg"    # Ltas/internal/camera/server/RemoteMessage;

    .prologue
    .line 323
    iget-object v1, p0, Ltas/internal/camera/client/ServerConnection$ServerCallback;->mM:Ljava/lang/ref/WeakReference;

    invoke-virtual {v1}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/camera/client/ServerConnection;

    .line 324
    .local v0, "m":Ltas/internal/camera/client/ServerConnection;
    if-eqz v0, :cond_0

    .line 325
    iget-object v1, p1, Ltas/internal/camera/server/RemoteMessage;->params:Ltas/internal/camera/InputParams;

    invoke-static {v0, v1}, Ltas/internal/camera/client/ServerConnection;->-wrap5(Ltas/internal/camera/client/ServerConnection;Ltas/internal/camera/InputParams;)V

    .line 327
    :cond_0
    invoke-virtual {p1}, Ltas/internal/camera/server/RemoteMessage;->recycle()V

    .line 322
    return-void
.end method
