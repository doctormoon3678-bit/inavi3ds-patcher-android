.class public final enum Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;
.super Ljava/lang/Enum;
.source "ieveGuideInfos.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/thinkware/sundo/ieve/ieveGuideInfos;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "SAFEGUIDE_KIND"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum",
        "<",
        "Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;",
        ">;"
    }
.end annotation


# static fields
.field public static final enum NONE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

.field public static final enum SAFETY_GUIDE_CONFLUENCEROAD:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

.field public static final enum SAFETY_GUIDE_CONFLUENCEROAD_AND:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

.field public static final enum SAFETY_GUIDE_CONFLUENCEROAD_CONTINUE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

.field public static final enum SAFETY_GUIDE_FOGAREA:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

.field public static final enum SAFETY_GUIDE_FOGAREA_AND:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

.field public static final enum SAFETY_GUIDE_FOGAREA_CONTINUE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

.field public static final enum SAFETY_GUIDE_HEIGHTLIMIT:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

.field public static final enum SAFETY_GUIDE_HEIGHTLIMIT_AND:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

.field public static final enum SAFETY_GUIDE_HEIGHTLIMIT_CONTINUE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

.field public static final enum SAFETY_GUIDE_LOCAL_GUIDE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

.field public static final enum SAFETY_GUIDE_LOCAL_GUIDE_AND:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

.field public static final enum SAFETY_GUIDE_LOCAL_GUIDE_CONTINUE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

.field public static final enum SAFETY_GUIDE_MANYACCIDENT:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

.field public static final enum SAFETY_GUIDE_MANYACCIDENT_AND:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

.field public static final enum SAFETY_GUIDE_MANYACCIDENT_CONTINUE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

.field public static final enum SAFETY_GUIDE_OTTTERANIMAL:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

.field public static final enum SAFETY_GUIDE_OTTTERANIMAL_AND:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

.field public static final enum SAFETY_GUIDE_OTTTERANIMAL_CONTINUE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

.field public static final enum SAFETY_GUIDE_OVERSPEED:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

.field public static final enum SAFETY_GUIDE_OVERSPEED_AND:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

.field public static final enum SAFETY_GUIDE_OVERSPEED_CONTINUE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

.field public static final enum SAFETY_GUIDE_PLUNGE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

.field public static final enum SAFETY_GUIDE_PLUNGE_AND:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

.field public static final enum SAFETY_GUIDE_PLUNGE_CONTINUE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

.field public static final enum SAFETY_GUIDE_POLICEACCIDENT:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

.field public static final enum SAFETY_GUIDE_POLICEACCIDENT_AND:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

.field public static final enum SAFETY_GUIDE_POLICEACCIDENT_CONTINUE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

.field public static final enum SAFETY_GUIDE_RAILWAYCROSSING:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

.field public static final enum SAFETY_GUIDE_RAILWAYCROSSING_AND:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

.field public static final enum SAFETY_GUIDE_RAILWAYCROSSING_CONTINUE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

.field public static final enum SAFETY_GUIDE_RAINSTONE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

.field public static final enum SAFETY_GUIDE_RAINSTONE_AND:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

.field public static final enum SAFETY_GUIDE_RAINSTONE_CONTINUE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

.field public static final enum SAFETY_GUIDE_ROUNDABOUT:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

.field public static final enum SAFETY_GUIDE_SHARPCURVE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

.field public static final enum SAFETY_GUIDE_SHARPCURVE_AND:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

.field public static final enum SAFETY_GUIDE_SHARPCURVE_CONTINUE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

.field public static final enum SAFETY_GUIDE_SLIP:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

.field public static final enum SAFETY_GUIDE_SLIP_AND:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

.field public static final enum SAFETY_GUIDE_SLIP_CONTINUE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

.field public static final enum SAFETY_GUIDE_WILDANIMAL:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

.field public static final enum SAFETY_GUIDE_WILDANIMAL_AND:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

.field public static final enum SAFETY_GUIDE_WILDANIMAL_CONTINUE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

.field public static final enum USER_CAMERA_CCTV:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

.field private static final synthetic b:[Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;


# instance fields
.field private final a:I


# direct methods
.method static constructor <clinit>()V
    .locals 9

    .prologue
    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v4, 0x0

    .line 151
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    const-string v1, "NONE"

    invoke-direct {v0, v1, v4, v4}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->NONE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    .line 152
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    const-string v1, "SAFETY_GUIDE_FOGAREA"

    const/16 v2, 0x64

    invoke-direct {v0, v1, v5, v2}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->SAFETY_GUIDE_FOGAREA:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    .line 153
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    const-string v1, "SAFETY_GUIDE_FOGAREA_AND"

    const/16 v2, 0x65

    invoke-direct {v0, v1, v6, v2}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->SAFETY_GUIDE_FOGAREA_AND:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    .line 154
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    const-string v1, "SAFETY_GUIDE_MANYACCIDENT"

    const/16 v2, 0x66

    invoke-direct {v0, v1, v7, v2}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->SAFETY_GUIDE_MANYACCIDENT:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    .line 155
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    const-string v1, "SAFETY_GUIDE_MANYACCIDENT_AND"

    const/16 v2, 0x67

    invoke-direct {v0, v1, v8, v2}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->SAFETY_GUIDE_MANYACCIDENT_AND:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    .line 156
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    const-string v1, "SAFETY_GUIDE_OVERSPEED"

    const/4 v2, 0x5

    const/16 v3, 0x68

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->SAFETY_GUIDE_OVERSPEED:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    .line 157
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    const-string v1, "SAFETY_GUIDE_OVERSPEED_AND"

    const/4 v2, 0x6

    const/16 v3, 0x69

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->SAFETY_GUIDE_OVERSPEED_AND:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    .line 158
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    const-string v1, "SAFETY_GUIDE_PLUNGE"

    const/4 v2, 0x7

    const/16 v3, 0x6a

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->SAFETY_GUIDE_PLUNGE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    .line 159
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    const-string v1, "SAFETY_GUIDE_PLUNGE_AND"

    const/16 v2, 0x8

    const/16 v3, 0x6b

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->SAFETY_GUIDE_PLUNGE_AND:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    .line 160
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    const-string v1, "SAFETY_GUIDE_RAILWAYCROSSING"

    const/16 v2, 0x9

    const/16 v3, 0x6c

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->SAFETY_GUIDE_RAILWAYCROSSING:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    .line 161
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    const-string v1, "SAFETY_GUIDE_RAILWAYCROSSING_AND"

    const/16 v2, 0xa

    const/16 v3, 0x6d

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->SAFETY_GUIDE_RAILWAYCROSSING_AND:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    .line 162
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    const-string v1, "SAFETY_GUIDE_RAINSTONE"

    const/16 v2, 0xb

    const/16 v3, 0x6e

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->SAFETY_GUIDE_RAINSTONE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    .line 163
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    const-string v1, "SAFETY_GUIDE_RAINSTONE_AND"

    const/16 v2, 0xc

    const/16 v3, 0x6f

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->SAFETY_GUIDE_RAINSTONE_AND:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    .line 164
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    const-string v1, "SAFETY_GUIDE_SHARPCURVE"

    const/16 v2, 0xd

    const/16 v3, 0x70

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->SAFETY_GUIDE_SHARPCURVE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    .line 165
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    const-string v1, "SAFETY_GUIDE_SHARPCURVE_AND"

    const/16 v2, 0xe

    const/16 v3, 0x71

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->SAFETY_GUIDE_SHARPCURVE_AND:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    .line 166
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    const-string v1, "SAFETY_GUIDE_SLIP"

    const/16 v2, 0xf

    const/16 v3, 0x72

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->SAFETY_GUIDE_SLIP:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    .line 167
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    const-string v1, "SAFETY_GUIDE_SLIP_AND"

    const/16 v2, 0x10

    const/16 v3, 0x73

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->SAFETY_GUIDE_SLIP_AND:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    .line 168
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    const-string v1, "SAFETY_GUIDE_WILDANIMAL"

    const/16 v2, 0x11

    const/16 v3, 0x74

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->SAFETY_GUIDE_WILDANIMAL:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    .line 169
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    const-string v1, "SAFETY_GUIDE_WILDANIMAL_AND"

    const/16 v2, 0x12

    const/16 v3, 0x75

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->SAFETY_GUIDE_WILDANIMAL_AND:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    .line 170
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    const-string v1, "SAFETY_GUIDE_HEIGHTLIMIT"

    const/16 v2, 0x13

    const/16 v3, 0x76

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->SAFETY_GUIDE_HEIGHTLIMIT:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    .line 171
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    const-string v1, "SAFETY_GUIDE_HEIGHTLIMIT_AND"

    const/16 v2, 0x14

    const/16 v3, 0x77

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->SAFETY_GUIDE_HEIGHTLIMIT_AND:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    .line 172
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    const-string v1, "SAFETY_GUIDE_CONFLUENCEROAD"

    const/16 v2, 0x15

    const/16 v3, 0x78

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->SAFETY_GUIDE_CONFLUENCEROAD:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    .line 173
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    const-string v1, "SAFETY_GUIDE_CONFLUENCEROAD_AND"

    const/16 v2, 0x16

    const/16 v3, 0x79

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->SAFETY_GUIDE_CONFLUENCEROAD_AND:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    .line 174
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    const-string v1, "SAFETY_GUIDE_FOGAREA_CONTINUE"

    const/16 v2, 0x17

    const/16 v3, 0x7a

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->SAFETY_GUIDE_FOGAREA_CONTINUE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    .line 175
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    const-string v1, "SAFETY_GUIDE_MANYACCIDENT_CONTINUE"

    const/16 v2, 0x18

    const/16 v3, 0x7b

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->SAFETY_GUIDE_MANYACCIDENT_CONTINUE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    .line 176
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    const-string v1, "SAFETY_GUIDE_OVERSPEED_CONTINUE"

    const/16 v2, 0x19

    const/16 v3, 0x7c

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->SAFETY_GUIDE_OVERSPEED_CONTINUE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    .line 177
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    const-string v1, "SAFETY_GUIDE_PLUNGE_CONTINUE"

    const/16 v2, 0x1a

    const/16 v3, 0x7d

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->SAFETY_GUIDE_PLUNGE_CONTINUE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    .line 178
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    const-string v1, "SAFETY_GUIDE_RAILWAYCROSSING_CONTINUE"

    const/16 v2, 0x1b

    const/16 v3, 0x7e

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->SAFETY_GUIDE_RAILWAYCROSSING_CONTINUE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    .line 179
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    const-string v1, "SAFETY_GUIDE_RAINSTONE_CONTINUE"

    const/16 v2, 0x1c

    const/16 v3, 0x7f

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->SAFETY_GUIDE_RAINSTONE_CONTINUE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    .line 180
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    const-string v1, "SAFETY_GUIDE_SHARPCURVE_CONTINUE"

    const/16 v2, 0x1d

    const/16 v3, 0x80

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->SAFETY_GUIDE_SHARPCURVE_CONTINUE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    .line 181
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    const-string v1, "SAFETY_GUIDE_SLIP_CONTINUE"

    const/16 v2, 0x1e

    const/16 v3, 0x81

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->SAFETY_GUIDE_SLIP_CONTINUE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    .line 182
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    const-string v1, "SAFETY_GUIDE_WILDANIMAL_CONTINUE"

    const/16 v2, 0x1f

    const/16 v3, 0x82

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->SAFETY_GUIDE_WILDANIMAL_CONTINUE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    .line 183
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    const-string v1, "SAFETY_GUIDE_HEIGHTLIMIT_CONTINUE"

    const/16 v2, 0x20

    const/16 v3, 0x83

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->SAFETY_GUIDE_HEIGHTLIMIT_CONTINUE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    .line 184
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    const-string v1, "SAFETY_GUIDE_CONFLUENCEROAD_CONTINUE"

    const/16 v2, 0x21

    const/16 v3, 0x84

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->SAFETY_GUIDE_CONFLUENCEROAD_CONTINUE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    .line 185
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    const-string v1, "SAFETY_GUIDE_POLICEACCIDENT"

    const/16 v2, 0x22

    const/16 v3, 0x85

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->SAFETY_GUIDE_POLICEACCIDENT:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    .line 186
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    const-string v1, "SAFETY_GUIDE_POLICEACCIDENT_AND"

    const/16 v2, 0x23

    const/16 v3, 0x86

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->SAFETY_GUIDE_POLICEACCIDENT_AND:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    .line 187
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    const-string v1, "SAFETY_GUIDE_POLICEACCIDENT_CONTINUE"

    const/16 v2, 0x24

    const/16 v3, 0x87

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->SAFETY_GUIDE_POLICEACCIDENT_CONTINUE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    .line 188
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    const-string v1, "SAFETY_GUIDE_OTTTERANIMAL"

    const/16 v2, 0x25

    const/16 v3, 0x88

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->SAFETY_GUIDE_OTTTERANIMAL:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    .line 189
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    const-string v1, "SAFETY_GUIDE_OTTTERANIMAL_AND"

    const/16 v2, 0x26

    const/16 v3, 0x89

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->SAFETY_GUIDE_OTTTERANIMAL_AND:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    .line 190
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    const-string v1, "SAFETY_GUIDE_OTTTERANIMAL_CONTINUE"

    const/16 v2, 0x27

    const/16 v3, 0x8a

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->SAFETY_GUIDE_OTTTERANIMAL_CONTINUE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    .line 191
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    const-string v1, "SAFETY_GUIDE_LOCAL_GUIDE"

    const/16 v2, 0x28

    const/16 v3, 0x8b

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->SAFETY_GUIDE_LOCAL_GUIDE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    .line 192
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    const-string v1, "SAFETY_GUIDE_LOCAL_GUIDE_AND"

    const/16 v2, 0x29

    const/16 v3, 0x8c

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->SAFETY_GUIDE_LOCAL_GUIDE_AND:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    .line 193
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    const-string v1, "SAFETY_GUIDE_LOCAL_GUIDE_CONTINUE"

    const/16 v2, 0x2a

    const/16 v3, 0x8d

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->SAFETY_GUIDE_LOCAL_GUIDE_CONTINUE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    .line 194
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    const-string v1, "SAFETY_GUIDE_ROUNDABOUT"

    const/16 v2, 0x2b

    const/16 v3, 0x8e

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->SAFETY_GUIDE_ROUNDABOUT:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    .line 195
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    const-string v1, "USER_CAMERA_CCTV"

    const/16 v2, 0x2c

    const/16 v3, 0x8f

    invoke-direct {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->USER_CAMERA_CCTV:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    .line 150
    const/16 v0, 0x2d

    new-array v0, v0, [Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    sget-object v1, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->NONE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    aput-object v1, v0, v4

    sget-object v1, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->SAFETY_GUIDE_FOGAREA:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    aput-object v1, v0, v5

    sget-object v1, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->SAFETY_GUIDE_FOGAREA_AND:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    aput-object v1, v0, v6

    sget-object v1, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->SAFETY_GUIDE_MANYACCIDENT:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    aput-object v1, v0, v7

    sget-object v1, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->SAFETY_GUIDE_MANYACCIDENT_AND:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    aput-object v1, v0, v8

    const/4 v1, 0x5

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->SAFETY_GUIDE_OVERSPEED:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    aput-object v2, v0, v1

    const/4 v1, 0x6

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->SAFETY_GUIDE_OVERSPEED_AND:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    aput-object v2, v0, v1

    const/4 v1, 0x7

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->SAFETY_GUIDE_PLUNGE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    aput-object v2, v0, v1

    const/16 v1, 0x8

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->SAFETY_GUIDE_PLUNGE_AND:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    aput-object v2, v0, v1

    const/16 v1, 0x9

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->SAFETY_GUIDE_RAILWAYCROSSING:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    aput-object v2, v0, v1

    const/16 v1, 0xa

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->SAFETY_GUIDE_RAILWAYCROSSING_AND:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    aput-object v2, v0, v1

    const/16 v1, 0xb

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->SAFETY_GUIDE_RAINSTONE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    aput-object v2, v0, v1

    const/16 v1, 0xc

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->SAFETY_GUIDE_RAINSTONE_AND:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    aput-object v2, v0, v1

    const/16 v1, 0xd

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->SAFETY_GUIDE_SHARPCURVE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    aput-object v2, v0, v1

    const/16 v1, 0xe

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->SAFETY_GUIDE_SHARPCURVE_AND:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    aput-object v2, v0, v1

    const/16 v1, 0xf

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->SAFETY_GUIDE_SLIP:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    aput-object v2, v0, v1

    const/16 v1, 0x10

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->SAFETY_GUIDE_SLIP_AND:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    aput-object v2, v0, v1

    const/16 v1, 0x11

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->SAFETY_GUIDE_WILDANIMAL:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    aput-object v2, v0, v1

    const/16 v1, 0x12

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->SAFETY_GUIDE_WILDANIMAL_AND:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    aput-object v2, v0, v1

    const/16 v1, 0x13

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->SAFETY_GUIDE_HEIGHTLIMIT:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    aput-object v2, v0, v1

    const/16 v1, 0x14

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->SAFETY_GUIDE_HEIGHTLIMIT_AND:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    aput-object v2, v0, v1

    const/16 v1, 0x15

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->SAFETY_GUIDE_CONFLUENCEROAD:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    aput-object v2, v0, v1

    const/16 v1, 0x16

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->SAFETY_GUIDE_CONFLUENCEROAD_AND:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    aput-object v2, v0, v1

    const/16 v1, 0x17

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->SAFETY_GUIDE_FOGAREA_CONTINUE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    aput-object v2, v0, v1

    const/16 v1, 0x18

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->SAFETY_GUIDE_MANYACCIDENT_CONTINUE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    aput-object v2, v0, v1

    const/16 v1, 0x19

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->SAFETY_GUIDE_OVERSPEED_CONTINUE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    aput-object v2, v0, v1

    const/16 v1, 0x1a

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->SAFETY_GUIDE_PLUNGE_CONTINUE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    aput-object v2, v0, v1

    const/16 v1, 0x1b

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->SAFETY_GUIDE_RAILWAYCROSSING_CONTINUE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    aput-object v2, v0, v1

    const/16 v1, 0x1c

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->SAFETY_GUIDE_RAINSTONE_CONTINUE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    aput-object v2, v0, v1

    const/16 v1, 0x1d

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->SAFETY_GUIDE_SHARPCURVE_CONTINUE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    aput-object v2, v0, v1

    const/16 v1, 0x1e

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->SAFETY_GUIDE_SLIP_CONTINUE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    aput-object v2, v0, v1

    const/16 v1, 0x1f

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->SAFETY_GUIDE_WILDANIMAL_CONTINUE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    aput-object v2, v0, v1

    const/16 v1, 0x20

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->SAFETY_GUIDE_HEIGHTLIMIT_CONTINUE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    aput-object v2, v0, v1

    const/16 v1, 0x21

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->SAFETY_GUIDE_CONFLUENCEROAD_CONTINUE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    aput-object v2, v0, v1

    const/16 v1, 0x22

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->SAFETY_GUIDE_POLICEACCIDENT:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    aput-object v2, v0, v1

    const/16 v1, 0x23

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->SAFETY_GUIDE_POLICEACCIDENT_AND:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    aput-object v2, v0, v1

    const/16 v1, 0x24

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->SAFETY_GUIDE_POLICEACCIDENT_CONTINUE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    aput-object v2, v0, v1

    const/16 v1, 0x25

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->SAFETY_GUIDE_OTTTERANIMAL:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    aput-object v2, v0, v1

    const/16 v1, 0x26

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->SAFETY_GUIDE_OTTTERANIMAL_AND:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    aput-object v2, v0, v1

    const/16 v1, 0x27

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->SAFETY_GUIDE_OTTTERANIMAL_CONTINUE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    aput-object v2, v0, v1

    const/16 v1, 0x28

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->SAFETY_GUIDE_LOCAL_GUIDE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    aput-object v2, v0, v1

    const/16 v1, 0x29

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->SAFETY_GUIDE_LOCAL_GUIDE_AND:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    aput-object v2, v0, v1

    const/16 v1, 0x2a

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->SAFETY_GUIDE_LOCAL_GUIDE_CONTINUE:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    aput-object v2, v0, v1

    const/16 v1, 0x2b

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->SAFETY_GUIDE_ROUNDABOUT:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    aput-object v2, v0, v1

    const/16 v1, 0x2c

    sget-object v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->USER_CAMERA_CCTV:Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    aput-object v2, v0, v1

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->b:[Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .locals 0
    .param p3, "value"    # I

    .prologue
    .line 197
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    iput p3, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->a:I

    return-void
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;
    .locals 1

    .prologue
    .line 1
    const-class v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object v0

    check-cast v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    return-object v0
.end method

.method public static values()[Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;
    .locals 4

    .prologue
    const/4 v3, 0x0

    .line 1
    sget-object v0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->b:[Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    array-length v1, v0

    new-array v2, v1, [Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;

    invoke-static {v0, v3, v2, v3, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    return-object v2
.end method


# virtual methods
.method public getValue()I
    .locals 1

    .prologue
    .line 199
    iget v0, p0, Lcom/thinkware/sundo/ieve/ieveGuideInfos$SAFEGUIDE_KIND;->a:I

    return v0
.end method
