.class Ltas/internal/ipc/SenderManager$SenderWrapper;
.super Ltas/internal/ipc/server/RemoteSender;
.source "SenderManager.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltas/internal/ipc/SenderManager;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = "SenderWrapper"
.end annotation


# instance fields
.field private mExtra:Landroid/os/Bundle;

.field private final mListeners:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List",
            "<",
            "Ltas/internal/ipc/Sender;",
            ">;"
        }
    .end annotation
.end field

.field private final mReceivers:Landroid/util/ArrayMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/util/ArrayMap",
            "<",
            "Ljava/lang/Long;",
            "Ltas/internal/ipc/SenderManager$ReceiverWrapper;",
            ">;"
        }
    .end annotation
.end field

.field private final mReplySp:Ljava/util/concurrent/Semaphore;

.field private mWatchAnonymous:Z

.field private mWatchAnonymousRef:I

.field private final mWatchRef:Landroid/util/ArrayMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/util/ArrayMap",
            "<",
            "Ljava/lang/String;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic this$0:Ltas/internal/ipc/SenderManager;


# direct methods
.method static synthetic -get0(Ltas/internal/ipc/SenderManager$SenderWrapper;)Landroid/os/Bundle;
    .locals 1

    iget-object v0, p0, Ltas/internal/ipc/SenderManager$SenderWrapper;->mExtra:Landroid/os/Bundle;

    return-object v0
.end method

.method static synthetic -get1(Ltas/internal/ipc/SenderManager$SenderWrapper;)Ljava/util/List;
    .locals 1

    iget-object v0, p0, Ltas/internal/ipc/SenderManager$SenderWrapper;->mListeners:Ljava/util/List;

    return-object v0
.end method

.method static synthetic -get2(Ltas/internal/ipc/SenderManager$SenderWrapper;)Landroid/util/ArrayMap;
    .locals 1

    iget-object v0, p0, Ltas/internal/ipc/SenderManager$SenderWrapper;->mReceivers:Landroid/util/ArrayMap;

    return-object v0
.end method

.method static synthetic -get3(Ltas/internal/ipc/SenderManager$SenderWrapper;)Z
    .locals 1

    iget-boolean v0, p0, Ltas/internal/ipc/SenderManager$SenderWrapper;->mWatchAnonymous:Z

    return v0
.end method

.method static synthetic -get4(Ltas/internal/ipc/SenderManager$SenderWrapper;)I
    .locals 1

    iget v0, p0, Ltas/internal/ipc/SenderManager$SenderWrapper;->mWatchAnonymousRef:I

    return v0
.end method

.method static synthetic -get5(Ltas/internal/ipc/SenderManager$SenderWrapper;)Landroid/util/ArrayMap;
    .locals 1

    iget-object v0, p0, Ltas/internal/ipc/SenderManager$SenderWrapper;->mWatchRef:Landroid/util/ArrayMap;

    return-object v0
.end method

.method static synthetic -set0(Ltas/internal/ipc/SenderManager$SenderWrapper;Landroid/os/Bundle;)Landroid/os/Bundle;
    .locals 0

    iput-object p1, p0, Ltas/internal/ipc/SenderManager$SenderWrapper;->mExtra:Landroid/os/Bundle;

    return-object p1
.end method

.method static synthetic -set1(Ltas/internal/ipc/SenderManager$SenderWrapper;Z)Z
    .locals 0

    iput-boolean p1, p0, Ltas/internal/ipc/SenderManager$SenderWrapper;->mWatchAnonymous:Z

    return p1
.end method

.method static synthetic -set2(Ltas/internal/ipc/SenderManager$SenderWrapper;I)I
    .locals 0

    iput p1, p0, Ltas/internal/ipc/SenderManager$SenderWrapper;->mWatchAnonymousRef:I

    return p1
.end method

.method static synthetic -wrap0(Ltas/internal/ipc/SenderManager$SenderWrapper;)V
    .locals 0

    invoke-direct {p0}, Ltas/internal/ipc/SenderManager$SenderWrapper;->clearReceivers()V

    return-void
.end method

.method static synthetic -wrap1(Ltas/internal/ipc/SenderManager$SenderWrapper;)V
    .locals 0

    invoke-direct {p0}, Ltas/internal/ipc/SenderManager$SenderWrapper;->disconnectReceivers()V

    return-void
.end method

.method static synthetic -wrap2(Ltas/internal/ipc/SenderManager$SenderWrapper;Ltas/internal/ipc/SenderManager$ReceiverWrapper;)V
    .locals 0
    .param p1, "rw"    # Ltas/internal/ipc/SenderManager$ReceiverWrapper;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/ipc/SenderManager$SenderWrapper;->onReceiverOffline(Ltas/internal/ipc/SenderManager$ReceiverWrapper;)V

    return-void
.end method

.method static synthetic -wrap3(Ltas/internal/ipc/SenderManager$SenderWrapper;Ltas/internal/ipc/SenderManager$ReceiverWrapper;)V
    .locals 0
    .param p1, "rw"    # Ltas/internal/ipc/SenderManager$ReceiverWrapper;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/ipc/SenderManager$SenderWrapper;->onReceiverOnline(Ltas/internal/ipc/SenderManager$ReceiverWrapper;)V

    return-void
.end method

.method static synthetic -wrap4(Ltas/internal/ipc/SenderManager$SenderWrapper;Ltas/internal/ipc/SenderManager$ReceiverWrapper;)V
    .locals 0
    .param p1, "rw"    # Ltas/internal/ipc/SenderManager$ReceiverWrapper;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/ipc/SenderManager$SenderWrapper;->onReceiverUpdate(Ltas/internal/ipc/SenderManager$ReceiverWrapper;)V

    return-void
.end method

.method static synthetic -wrap5(Ltas/internal/ipc/SenderManager$SenderWrapper;Ltas/internal/ipc/server/RemoteMessage;)V
    .locals 0
    .param p1, "rmsg"    # Ltas/internal/ipc/server/RemoteMessage;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/ipc/SenderManager$SenderWrapper;->transmit(Ltas/internal/ipc/server/RemoteMessage;)V

    return-void
.end method

.method private constructor <init>(Ltas/internal/ipc/SenderManager;Ltas/internal/ipc/Sender;)V
    .locals 3
    .param p1, "this$0"    # Ltas/internal/ipc/SenderManager;
    .param p2, "sender"    # Ltas/internal/ipc/Sender;

    .prologue
    const/4 v2, 0x0

    .line 415
    iput-object p1, p0, Ltas/internal/ipc/SenderManager$SenderWrapper;->this$0:Ltas/internal/ipc/SenderManager;

    .line 416
    iget-object v0, p2, Ltas/internal/ipc/Sender;->pkg:Ljava/lang/String;

    iget-object v1, p2, Ltas/internal/ipc/Sender;->name:Ljava/lang/String;

    invoke-direct {p0, v0, v1}, Ltas/internal/ipc/server/RemoteSender;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 402
    new-instance v0, Landroid/util/ArrayMap;

    invoke-direct {v0}, Landroid/util/ArrayMap;-><init>()V

    .line 401
    iput-object v0, p0, Ltas/internal/ipc/SenderManager$SenderWrapper;->mReceivers:Landroid/util/ArrayMap;

    .line 404
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Ltas/internal/ipc/SenderManager$SenderWrapper;->mListeners:Ljava/util/List;

    .line 407
    new-instance v0, Landroid/util/ArrayMap;

    invoke-direct {v0}, Landroid/util/ArrayMap;-><init>()V

    .line 406
    iput-object v0, p0, Ltas/internal/ipc/SenderManager$SenderWrapper;->mWatchRef:Landroid/util/ArrayMap;

    .line 410
    iput v2, p0, Ltas/internal/ipc/SenderManager$SenderWrapper;->mWatchAnonymousRef:I

    .line 412
    new-instance v0, Ljava/util/concurrent/Semaphore;

    invoke-direct {v0, v2}, Ljava/util/concurrent/Semaphore;-><init>(I)V

    iput-object v0, p0, Ltas/internal/ipc/SenderManager$SenderWrapper;->mReplySp:Ljava/util/concurrent/Semaphore;

    .line 417
    new-instance v0, Ltas/internal/ipc/SenderManager$RemoteReplier;

    invoke-direct {v0, p0}, Ltas/internal/ipc/SenderManager$RemoteReplier;-><init>(Ltas/internal/ipc/SenderManager$SenderWrapper;)V

    invoke-virtual {v0}, Ltas/internal/ipc/SenderManager$RemoteReplier;->asBinder()Landroid/os/IBinder;

    move-result-object v0

    iput-object v0, p0, Ltas/internal/ipc/SenderManager$SenderWrapper;->replier:Landroid/os/IBinder;

    .line 415
    return-void
.end method

.method synthetic constructor <init>(Ltas/internal/ipc/SenderManager;Ltas/internal/ipc/Sender;Ltas/internal/ipc/SenderManager$SenderWrapper;)V
    .locals 0
    .param p1, "this$0"    # Ltas/internal/ipc/SenderManager;
    .param p2, "sender"    # Ltas/internal/ipc/Sender;

    .prologue
    invoke-direct {p0, p1, p2}, Ltas/internal/ipc/SenderManager$SenderWrapper;-><init>(Ltas/internal/ipc/SenderManager;Ltas/internal/ipc/Sender;)V

    return-void
.end method

.method private clearReceivers()V
    .locals 4

    .prologue
    .line 504
    iget-object v3, p0, Ltas/internal/ipc/SenderManager$SenderWrapper;->mReceivers:Landroid/util/ArrayMap;

    invoke-virtual {v3}, Landroid/util/ArrayMap;->values()Ljava/util/Collection;

    move-result-object v0

    .line 505
    .local v0, "receivers":Ljava/util/Collection;, "Ljava/util/Collection<Ltas/internal/ipc/SenderManager$ReceiverWrapper;>;"
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v2

    .local v2, "rw$iterator":Ljava/util/Iterator;
    :cond_0
    :goto_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_1

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ltas/internal/ipc/SenderManager$ReceiverWrapper;

    .line 506
    .local v1, "rw":Ltas/internal/ipc/SenderManager$ReceiverWrapper;
    if-eqz v1, :cond_0

    invoke-direct {p0, v1}, Ltas/internal/ipc/SenderManager$SenderWrapper;->onReceiverOffline(Ltas/internal/ipc/SenderManager$ReceiverWrapper;)V

    goto :goto_0

    .line 503
    .end local v1    # "rw":Ltas/internal/ipc/SenderManager$ReceiverWrapper;
    :cond_1
    return-void
.end method

.method private disconnectReceivers()V
    .locals 4

    .prologue
    .line 511
    iget-object v3, p0, Ltas/internal/ipc/SenderManager$SenderWrapper;->mReceivers:Landroid/util/ArrayMap;

    invoke-virtual {v3}, Landroid/util/ArrayMap;->values()Ljava/util/Collection;

    move-result-object v0

    .line 512
    .local v0, "receivers":Ljava/util/Collection;, "Ljava/util/Collection<Ltas/internal/ipc/SenderManager$ReceiverWrapper;>;"
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v2

    .local v2, "rw$iterator":Ljava/util/Iterator;
    :cond_0
    :goto_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_1

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ltas/internal/ipc/SenderManager$ReceiverWrapper;

    .line 513
    .local v1, "rw":Ltas/internal/ipc/SenderManager$ReceiverWrapper;
    if-eqz v1, :cond_0

    invoke-virtual {v1}, Ltas/internal/ipc/SenderManager$ReceiverWrapper;->disconnect()V

    goto :goto_0

    .line 515
    .end local v1    # "rw":Ltas/internal/ipc/SenderManager$ReceiverWrapper;
    :cond_1
    iget-object v3, p0, Ltas/internal/ipc/SenderManager$SenderWrapper;->mReceivers:Landroid/util/ArrayMap;

    invoke-virtual {v3}, Landroid/util/ArrayMap;->clear()V

    .line 510
    return-void
.end method

.method private isWatching(Ljava/lang/String;)Z
    .locals 3
    .param p1, "name"    # Ljava/lang/String;

    .prologue
    .line 444
    iget-object v2, p0, Ltas/internal/ipc/SenderManager$SenderWrapper;->mListeners:Ljava/util/List;

    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    .local v1, "s$iterator":Ljava/util/Iterator;
    :cond_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/ipc/Sender;

    .line 445
    .local v0, "s":Ltas/internal/ipc/Sender;
    if-eqz v0, :cond_0

    invoke-virtual {v0, p1}, Ltas/internal/ipc/Sender;->isWatchingReceiver(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_0

    .line 446
    const/4 v2, 0x1

    return v2

    .line 449
    .end local v0    # "s":Ltas/internal/ipc/Sender;
    :cond_1
    const/4 v2, 0x0

    return v2
.end method

.method private onReceiverOffline(Ltas/internal/ipc/SenderManager$ReceiverWrapper;)V
    .locals 6
    .param p1, "rw"    # Ltas/internal/ipc/SenderManager$ReceiverWrapper;

    .prologue
    .line 483
    invoke-virtual {p1}, Ltas/internal/ipc/SenderManager$ReceiverWrapper;->dec()I

    .line 484
    iget-object v2, p0, Ltas/internal/ipc/SenderManager$SenderWrapper;->mReceivers:Landroid/util/ArrayMap;

    invoke-virtual {p1}, Ltas/internal/ipc/SenderManager$ReceiverWrapper;->getid()J

    move-result-wide v4

    invoke-static {v4, v5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/util/ArrayMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 486
    iget-object v2, p0, Ltas/internal/ipc/SenderManager$SenderWrapper;->mListeners:Ljava/util/List;

    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    .local v1, "s$iterator":Ljava/util/Iterator;
    :cond_0
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_2

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/ipc/Sender;

    .line 487
    .local v0, "s":Ltas/internal/ipc/Sender;
    if-eqz v0, :cond_0

    iget-object v2, p1, Ltas/internal/ipc/SenderManager$ReceiverWrapper;->name:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ltas/internal/ipc/Sender;->isWatchingReceiver(Ljava/lang/String;)Z

    move-result v2

    if-nez v2, :cond_1

    .line 488
    invoke-virtual {v0}, Ltas/internal/ipc/Sender;->hasAnonymousSession()Z

    move-result v2

    .line 487
    if-eqz v2, :cond_0

    .line 489
    :cond_1
    iget-object v2, p0, Ltas/internal/ipc/SenderManager$SenderWrapper;->this$0:Ltas/internal/ipc/SenderManager;

    invoke-static {v2, v0, p1}, Ltas/internal/ipc/SenderManager;->-wrap0(Ltas/internal/ipc/SenderManager;Ltas/internal/ipc/Sender;Ltas/internal/ipc/server/RemoteReceiver;)V

    goto :goto_0

    .line 482
    .end local v0    # "s":Ltas/internal/ipc/Sender;
    :cond_2
    return-void
.end method

.method private onReceiverOnline(Ltas/internal/ipc/SenderManager$ReceiverWrapper;)V
    .locals 6
    .param p1, "rw"    # Ltas/internal/ipc/SenderManager$ReceiverWrapper;

    .prologue
    .line 471
    invoke-virtual {p1}, Ltas/internal/ipc/SenderManager$ReceiverWrapper;->inc()I

    .line 472
    iget-object v2, p0, Ltas/internal/ipc/SenderManager$SenderWrapper;->mReceivers:Landroid/util/ArrayMap;

    invoke-virtual {p1}, Ltas/internal/ipc/SenderManager$ReceiverWrapper;->getid()J

    move-result-wide v4

    invoke-static {v4, v5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v3

    invoke-virtual {v2, v3, p1}, Landroid/util/ArrayMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 474
    iget-object v2, p0, Ltas/internal/ipc/SenderManager$SenderWrapper;->mListeners:Ljava/util/List;

    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    .local v1, "s$iterator":Ljava/util/Iterator;
    :cond_0
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_2

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/ipc/Sender;

    .line 475
    .local v0, "s":Ltas/internal/ipc/Sender;
    if-eqz v0, :cond_0

    iget-object v2, p1, Ltas/internal/ipc/SenderManager$ReceiverWrapper;->name:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ltas/internal/ipc/Sender;->isWatchingReceiver(Ljava/lang/String;)Z

    move-result v2

    if-nez v2, :cond_1

    .line 476
    invoke-virtual {v0}, Ltas/internal/ipc/Sender;->hasAnonymousSession()Z

    move-result v2

    .line 475
    if-eqz v2, :cond_0

    .line 477
    :cond_1
    iget-object v2, p0, Ltas/internal/ipc/SenderManager$SenderWrapper;->this$0:Ltas/internal/ipc/SenderManager;

    invoke-static {v2, v0, p1}, Ltas/internal/ipc/SenderManager;->-wrap1(Ltas/internal/ipc/SenderManager;Ltas/internal/ipc/Sender;Ltas/internal/ipc/server/RemoteReceiver;)V

    goto :goto_0

    .line 470
    .end local v0    # "s":Ltas/internal/ipc/Sender;
    :cond_2
    return-void
.end method

.method private onReceiverUpdate(Ltas/internal/ipc/SenderManager$ReceiverWrapper;)V
    .locals 3
    .param p1, "rw"    # Ltas/internal/ipc/SenderManager$ReceiverWrapper;

    .prologue
    .line 495
    iget-object v2, p0, Ltas/internal/ipc/SenderManager$SenderWrapper;->mListeners:Ljava/util/List;

    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    .local v1, "s$iterator":Ljava/util/Iterator;
    :cond_0
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_2

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/ipc/Sender;

    .line 496
    .local v0, "s":Ltas/internal/ipc/Sender;
    if-eqz v0, :cond_0

    iget-object v2, p1, Ltas/internal/ipc/SenderManager$ReceiverWrapper;->name:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ltas/internal/ipc/Sender;->isWatchingReceiver(Ljava/lang/String;)Z

    move-result v2

    if-nez v2, :cond_1

    .line 497
    invoke-virtual {v0}, Ltas/internal/ipc/Sender;->hasAnonymousSession()Z

    move-result v2

    .line 496
    if-eqz v2, :cond_0

    .line 498
    :cond_1
    iget-object v2, p0, Ltas/internal/ipc/SenderManager$SenderWrapper;->this$0:Ltas/internal/ipc/SenderManager;

    invoke-static {v2, v0, p1}, Ltas/internal/ipc/SenderManager;->-wrap3(Ltas/internal/ipc/SenderManager;Ltas/internal/ipc/Sender;Ltas/internal/ipc/server/RemoteReceiver;)V

    goto :goto_0

    .line 494
    .end local v0    # "s":Ltas/internal/ipc/Sender;
    :cond_2
    return-void
.end method

.method private transmit(Ltas/internal/ipc/server/RemoteMessage;)V
    .locals 7
    .param p1, "rmsg"    # Ltas/internal/ipc/server/RemoteMessage;

    .prologue
    .line 523
    iget-object v5, p1, Ltas/internal/ipc/server/RemoteMessage;->receiver:Ltas/internal/ipc/server/RemoteReceiver;

    invoke-virtual {v5}, Ltas/internal/ipc/server/RemoteReceiver;->getid()J

    move-result-wide v0

    .line 524
    .local v0, "id":J
    iget-object v5, p0, Ltas/internal/ipc/SenderManager$SenderWrapper;->mListeners:Ljava/util/List;

    invoke-interface {v5}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v3

    .local v3, "s$iterator":Ljava/util/Iterator;
    :cond_0
    :goto_0
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_1

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ltas/internal/ipc/Sender;

    .line 525
    .local v2, "s":Ltas/internal/ipc/Sender;
    if-eqz v2, :cond_0

    .line 526
    invoke-virtual {v2, v0, v1}, Ltas/internal/ipc/Sender;->getSession(J)Ltas/ipc/SenderSession;

    move-result-object v4

    .line 527
    .local v4, "session":Ltas/ipc/SenderSession;
    if-eqz v4, :cond_0

    iget-object v5, v4, Ltas/ipc/SenderSession;->q:Ljava/util/Queue;

    if-eqz v5, :cond_0

    .line 528
    iget-object v5, v4, Ltas/ipc/SenderSession;->q:Ljava/util/Queue;

    iget-object v6, p1, Ltas/internal/ipc/server/RemoteMessage;->msg:Ltas/ipc/MsgData;

    invoke-static {v6}, Ltas/ipc/MsgData;->obtain(Ltas/ipc/MsgData;)Ltas/ipc/MsgData;

    move-result-object v6

    invoke-interface {v5, v6}, Ljava/util/Queue;->offer(Ljava/lang/Object;)Z

    .line 529
    iget-object v5, p0, Ltas/internal/ipc/SenderManager$SenderWrapper;->this$0:Ltas/internal/ipc/SenderManager;

    invoke-static {v5, v2, v4}, Ltas/internal/ipc/SenderManager;->-wrap2(Ltas/internal/ipc/SenderManager;Ltas/internal/ipc/Sender;Ltas/ipc/SenderSession;)V

    goto :goto_0

    .line 532
    .end local v2    # "s":Ltas/internal/ipc/Sender;
    .end local v4    # "session":Ltas/ipc/SenderSession;
    :cond_1
    invoke-virtual {p1}, Ltas/internal/ipc/server/RemoteMessage;->recycle()V

    .line 518
    return-void
.end method


# virtual methods
.method findReceiver(Ltas/internal/ipc/server/RemoteReceiver;)Ltas/internal/ipc/SenderManager$ReceiverWrapper;
    .locals 2
    .param p1, "receiver"    # Ltas/internal/ipc/server/RemoteReceiver;

    .prologue
    .line 436
    invoke-virtual {p1}, Ltas/internal/ipc/server/RemoteReceiver;->getid()J

    move-result-wide v0

    invoke-virtual {p0, v0, v1}, Ltas/internal/ipc/SenderManager$SenderWrapper;->getReceiver(J)Ltas/internal/ipc/SenderManager$ReceiverWrapper;

    move-result-object v0

    return-object v0
.end method

.method getReceiver(J)Ltas/internal/ipc/SenderManager$ReceiverWrapper;
    .locals 3
    .param p1, "id"    # J

    .prologue
    .line 440
    iget-object v0, p0, Ltas/internal/ipc/SenderManager$SenderWrapper;->mReceivers:Landroid/util/ArrayMap;

    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/util/ArrayMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/ipc/SenderManager$ReceiverWrapper;

    return-object v0
.end method

.method declared-synchronized send(Ltas/internal/ipc/Sender;Ltas/ipc/SenderSession;Ltas/ipc/MsgData;)V
    .locals 4
    .param p1, "sender"    # Ltas/internal/ipc/Sender;
    .param p2, "session"    # Ltas/ipc/SenderSession;
    .param p3, "msg"    # Ltas/ipc/MsgData;

    .prologue
    monitor-enter p0

    .line 454
    :try_start_0
    iget-boolean v1, p1, Ltas/internal/ipc/Sender;->mOnline:Z

    if-nez v1, :cond_0

    .line 455
    const-string/jumbo v1, "TasIPC<SenderManager>"

    const-string/jumbo v2, "sender is offline"

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 456
    invoke-virtual {p3}, Ltas/ipc/MsgData;->recycle()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit p0

    .line 457
    return-void

    .line 460
    :cond_0
    :try_start_1
    iget-wide v2, p2, Ltas/ipc/SenderSession;->id:J

    invoke-virtual {p0, v2, v3}, Ltas/internal/ipc/SenderManager$SenderWrapper;->getReceiver(J)Ltas/internal/ipc/SenderManager$ReceiverWrapper;

    move-result-object v0

    .line 461
    .local v0, "rw":Ltas/internal/ipc/SenderManager$ReceiverWrapper;
    if-nez v0, :cond_1

    .line 462
    const-string/jumbo v1, "TasIPC<SenderManager>"

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "["

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, p2, Ltas/ipc/SenderSession;->name:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string/jumbo v3, "] not found."

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 463
    invoke-virtual {p3}, Ltas/ipc/MsgData;->recycle()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    monitor-exit p0

    .line 464
    return-void

    .line 467
    :cond_1
    :try_start_2
    invoke-virtual {v0, p3}, Ltas/internal/ipc/SenderManager$ReceiverWrapper;->send(Ltas/ipc/MsgData;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    monitor-exit p0

    .line 453
    return-void

    .end local v0    # "rw":Ltas/internal/ipc/SenderManager$ReceiverWrapper;
    :catchall_0
    move-exception v1

    monitor-exit p0

    throw v1
.end method

.method declared-synchronized update(Ltas/internal/ipc/Sender;)V
    .locals 3
    .param p1, "sender"    # Ltas/internal/ipc/Sender;

    .prologue
    monitor-enter p0

    .line 421
    :try_start_0
    iget-boolean v2, p1, Ltas/internal/ipc/Sender;->mOnline:Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-nez v2, :cond_0

    monitor-exit p0

    .line 422
    return-void

    .line 425
    :cond_0
    :try_start_1
    iget-object v2, p1, Ltas/internal/ipc/Sender;->mExtra:Landroid/os/Bundle;

    iput-object v2, p0, Ltas/internal/ipc/SenderManager$SenderWrapper;->mExtra:Landroid/os/Bundle;

    iput-object v2, p0, Ltas/internal/ipc/SenderManager$SenderWrapper;->extra:Landroid/os/Bundle;

    .line 426
    iget-object v2, p0, Ltas/internal/ipc/SenderManager$SenderWrapper;->mListeners:Ljava/util/List;

    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    .local v1, "s$iterator":Ljava/util/Iterator;
    :cond_1
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_2

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/ipc/Sender;

    .line 427
    .local v0, "s":Ltas/internal/ipc/Sender;
    if-eqz v0, :cond_1

    if-eq v0, p1, :cond_1

    .line 428
    iget-object v2, p0, Ltas/internal/ipc/SenderManager$SenderWrapper;->mExtra:Landroid/os/Bundle;

    iput-object v2, v0, Ltas/internal/ipc/Sender;->mExtra:Landroid/os/Bundle;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_0

    .end local v0    # "s":Ltas/internal/ipc/Sender;
    .end local v1    # "s$iterator":Ljava/util/Iterator;
    :catchall_0
    move-exception v2

    monitor-exit p0

    throw v2

    .line 432
    .restart local v1    # "s$iterator":Ljava/util/Iterator;
    :cond_2
    :try_start_2
    iget-object v2, p0, Ltas/internal/ipc/SenderManager$SenderWrapper;->this$0:Ltas/internal/ipc/SenderManager;

    invoke-static {v2, p0}, Ltas/internal/ipc/SenderManager;->-wrap9(Ltas/internal/ipc/SenderManager;Ltas/internal/ipc/SenderManager$SenderWrapper;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    monitor-exit p0

    .line 420
    return-void
.end method
