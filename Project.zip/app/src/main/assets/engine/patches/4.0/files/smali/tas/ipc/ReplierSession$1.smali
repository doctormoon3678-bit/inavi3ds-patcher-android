.class final Ltas/ipc/ReplierSession$1;
.super Ljava/lang/Object;
.source "ReplierSession.java"

# interfaces
.implements Ltas/internal/ipc/util/SyncdPool$Callback;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltas/ipc/ReplierSession;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ltas/internal/ipc/util/SyncdPool$Callback",
        "<",
        "Ltas/ipc/ReplierSession;",
        ">;"
    }
.end annotation


# direct methods
.method constructor <init>()V
    .locals 0

    .prologue
    .line 132
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public bridge synthetic getNext(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1
    .param p1, "replier"    # Ljava/lang/Object;

    .prologue
    .line 139
    check-cast p1, Ltas/ipc/ReplierSession;

    .end local p1    # "replier":Ljava/lang/Object;
    invoke-virtual {p0, p1}, Ltas/ipc/ReplierSession$1;->getNext(Ltas/ipc/ReplierSession;)Ltas/ipc/ReplierSession;

    move-result-object v0

    return-object v0
.end method

.method public getNext(Ltas/ipc/ReplierSession;)Ltas/ipc/ReplierSession;
    .locals 1
    .param p1, "replier"    # Ltas/ipc/ReplierSession;

    .prologue
    .line 140
    invoke-static {p1}, Ltas/ipc/ReplierSession;->-get0(Ltas/ipc/ReplierSession;)Ltas/ipc/ReplierSession;

    move-result-object v0

    return-object v0
.end method

.method public bridge synthetic newInstance()Ljava/lang/Object;
    .locals 1

    .prologue
    .line 133
    invoke-virtual {p0}, Ltas/ipc/ReplierSession$1;->newInstance()Ltas/ipc/ReplierSession;

    move-result-object v0

    return-object v0
.end method

.method public newInstance()Ltas/ipc/ReplierSession;
    .locals 3

    .prologue
    .line 134
    new-instance v0, Ltas/ipc/ReplierSession;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Ltas/ipc/ReplierSession;-><init>(Ltas/ipc/ReplierSession;)V

    .line 135
    .local v0, "replier":Ltas/ipc/ReplierSession;
    invoke-static {}, Ltas/ipc/ReplierSession;->-get1()I

    move-result v1

    add-int/lit8 v2, v1, 0x1

    invoke-static {v2}, Ltas/ipc/ReplierSession;->-set2(I)I

    invoke-static {v0, v1}, Ltas/ipc/ReplierSession;->-set1(Ltas/ipc/ReplierSession;I)I

    .line 136
    return-object v0
.end method

.method public bridge synthetic setNext(Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 0
    .param p1, "replier"    # Ljava/lang/Object;
    .param p2, "next"    # Ljava/lang/Object;

    .prologue
    .line 143
    check-cast p1, Ltas/ipc/ReplierSession;

    .end local p1    # "replier":Ljava/lang/Object;
    check-cast p2, Ltas/ipc/ReplierSession;

    .end local p2    # "next":Ljava/lang/Object;
    invoke-virtual {p0, p1, p2}, Ltas/ipc/ReplierSession$1;->setNext(Ltas/ipc/ReplierSession;Ltas/ipc/ReplierSession;)V

    return-void
.end method

.method public setNext(Ltas/ipc/ReplierSession;Ltas/ipc/ReplierSession;)V
    .locals 0
    .param p1, "replier"    # Ltas/ipc/ReplierSession;
    .param p2, "next"    # Ltas/ipc/ReplierSession;

    .prologue
    .line 144
    invoke-static {p1, p2}, Ltas/ipc/ReplierSession;->-set0(Ltas/ipc/ReplierSession;Ltas/ipc/ReplierSession;)Ltas/ipc/ReplierSession;

    .line 143
    return-void
.end method
