.class public Ltas/internal/camera/server/RemoteMessage;
.super Ljava/lang/Object;
.source "RemoteMessage.java"

# interfaces
.implements Landroid/os/Parcelable;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ltas/internal/camera/server/RemoteMessage$1;,
        Ltas/internal/camera/server/RemoteMessage$2;
    }
.end annotation


# static fields
.field private static final CALLBACK:Ltas/internal/ipc/util/SyncdPool$Callback;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ltas/internal/ipc/util/SyncdPool$Callback",
            "<",
            "Ltas/internal/camera/server/RemoteMessage;",
            ">;"
        }
    .end annotation
.end field

.field public static final CREATOR:Landroid/os/Parcelable$Creator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/os/Parcelable$Creator",
            "<",
            "Ltas/internal/camera/server/RemoteMessage;",
            ">;"
        }
    .end annotation
.end field

.field private static final sPool:Ltas/internal/ipc/util/SyncdPool;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ltas/internal/ipc/util/SyncdPool",
            "<",
            "Ltas/internal/camera/server/RemoteMessage;",
            ">;"
        }
    .end annotation
.end field

.field private static sPoolId:I

.field private static sStamp:I


# instance fields
.field private mAllocated:Z

.field private next:Ltas/internal/camera/server/RemoteMessage;

.field public final params:Ltas/internal/camera/InputParams;

.field private pool:I

.field private stamp:I


# direct methods
.method static synthetic -get0(Ltas/internal/camera/server/RemoteMessage;)Ltas/internal/camera/server/RemoteMessage;
    .locals 1

    iget-object v0, p0, Ltas/internal/camera/server/RemoteMessage;->next:Ltas/internal/camera/server/RemoteMessage;

    return-object v0
.end method

.method static synthetic -get1()I
    .locals 1

    sget v0, Ltas/internal/camera/server/RemoteMessage;->sPoolId:I

    return v0
.end method

.method static synthetic -set0(Ltas/internal/camera/server/RemoteMessage;Ltas/internal/camera/server/RemoteMessage;)Ltas/internal/camera/server/RemoteMessage;
    .locals 0

    iput-object p1, p0, Ltas/internal/camera/server/RemoteMessage;->next:Ltas/internal/camera/server/RemoteMessage;

    return-object p1
.end method

.method static synthetic -set1(Ltas/internal/camera/server/RemoteMessage;I)I
    .locals 0

    iput p1, p0, Ltas/internal/camera/server/RemoteMessage;->pool:I

    return p1
.end method

.method static synthetic -set2(I)I
    .locals 0

    sput p0, Ltas/internal/camera/server/RemoteMessage;->sPoolId:I

    return p0
.end method

.method static synthetic -wrap0(Ltas/internal/camera/server/RemoteMessage;Landroid/os/Parcel;)V
    .locals 0
    .param p1, "source"    # Landroid/os/Parcel;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/camera/server/RemoteMessage;->readFromParcel(Landroid/os/Parcel;)V

    return-void
.end method

.method static constructor <clinit>()V
    .locals 3

    .prologue
    const/4 v2, 0x0

    .line 29
    new-instance v0, Ltas/internal/camera/server/RemoteMessage$1;

    invoke-direct {v0}, Ltas/internal/camera/server/RemoteMessage$1;-><init>()V

    .line 28
    sput-object v0, Ltas/internal/camera/server/RemoteMessage;->CREATOR:Landroid/os/Parcelable$Creator;

    .line 57
    new-instance v0, Ltas/internal/camera/server/RemoteMessage$2;

    invoke-direct {v0}, Ltas/internal/camera/server/RemoteMessage$2;-><init>()V

    .line 56
    sput-object v0, Ltas/internal/camera/server/RemoteMessage;->CALLBACK:Ltas/internal/ipc/util/SyncdPool$Callback;

    .line 74
    new-instance v0, Ltas/internal/ipc/util/SyncdPool;

    sget-object v1, Ltas/internal/camera/server/RemoteMessage;->CALLBACK:Ltas/internal/ipc/util/SyncdPool$Callback;

    invoke-direct {v0, v1}, Ltas/internal/ipc/util/SyncdPool;-><init>(Ltas/internal/ipc/util/SyncdPool$Callback;)V

    .line 73
    sput-object v0, Ltas/internal/camera/server/RemoteMessage;->sPool:Ltas/internal/ipc/util/SyncdPool;

    .line 109
    sput v2, Ltas/internal/camera/server/RemoteMessage;->sStamp:I

    .line 110
    sput v2, Ltas/internal/camera/server/RemoteMessage;->sPoolId:I

    .line 18
    return-void
.end method

.method private constructor <init>()V
    .locals 2

    .prologue
    const/4 v1, -0x1

    .line 22
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 20
    new-instance v0, Ltas/internal/camera/InputParams;

    invoke-direct {v0}, Ltas/internal/camera/InputParams;-><init>()V

    iput-object v0, p0, Ltas/internal/camera/server/RemoteMessage;->params:Ltas/internal/camera/InputParams;

    .line 111
    iput v1, p0, Ltas/internal/camera/server/RemoteMessage;->stamp:I

    .line 112
    iput v1, p0, Ltas/internal/camera/server/RemoteMessage;->pool:I

    .line 22
    return-void
.end method

.method synthetic constructor <init>(Ltas/internal/camera/server/RemoteMessage;)V
    .locals 0

    .prologue
    invoke-direct {p0}, Ltas/internal/camera/server/RemoteMessage;-><init>()V

    return-void
.end method

.method private clear()V
    .locals 1

    .prologue
    .line 24
    iget-object v0, p0, Ltas/internal/camera/server/RemoteMessage;->params:Ltas/internal/camera/InputParams;

    invoke-virtual {v0}, Ltas/internal/camera/InputParams;->clear()V

    .line 25
    const/4 v0, -0x1

    iput v0, p0, Ltas/internal/camera/server/RemoteMessage;->stamp:I

    .line 23
    return-void
.end method

.method public static obtain()Ltas/internal/camera/server/RemoteMessage;
    .locals 2

    .prologue
    .line 79
    sget-object v1, Ltas/internal/camera/server/RemoteMessage;->sPool:Ltas/internal/ipc/util/SyncdPool;

    invoke-virtual {v1}, Ltas/internal/ipc/util/SyncdPool;->allocate()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/camera/server/RemoteMessage;

    .line 80
    .local v0, "r":Ltas/internal/camera/server/RemoteMessage;
    const/4 v1, 0x1

    iput-boolean v1, v0, Ltas/internal/camera/server/RemoteMessage;->mAllocated:Z

    .line 81
    sget v1, Ltas/internal/camera/server/RemoteMessage;->sStamp:I

    iput v1, v0, Ltas/internal/camera/server/RemoteMessage;->stamp:I

    .line 82
    sget v1, Ltas/internal/camera/server/RemoteMessage;->sStamp:I

    add-int/lit8 v1, v1, 0x1

    sput v1, Ltas/internal/camera/server/RemoteMessage;->sStamp:I

    .line 83
    return-object v0
.end method

.method public static obtain(Ltas/camera/CameraId;)Ltas/internal/camera/server/RemoteMessage;
    .locals 3
    .param p0, "cam"    # Ltas/camera/CameraId;

    .prologue
    .line 87
    invoke-static {}, Ltas/internal/camera/server/RemoteMessage;->obtain()Ltas/internal/camera/server/RemoteMessage;

    move-result-object v0

    .line 88
    .local v0, "r":Ltas/internal/camera/server/RemoteMessage;
    iget-object v1, v0, Ltas/internal/camera/server/RemoteMessage;->params:Ltas/internal/camera/InputParams;

    invoke-virtual {p0}, Ltas/camera/CameraId;->getClass()Ljava/lang/Class;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v2

    iput-object v2, v1, Ltas/internal/camera/InputParams;->cam:Ljava/lang/String;

    .line 89
    return-object v0
.end method

.method public static obtain(Ltas/camera/CameraId;Ltas/camera/CameraMessage;)Ltas/internal/camera/server/RemoteMessage;
    .locals 2
    .param p0, "cam"    # Ltas/camera/CameraId;
    .param p1, "msg"    # Ltas/camera/CameraMessage;

    .prologue
    .line 94
    invoke-static {p0}, Ltas/internal/camera/server/RemoteMessage;->obtain(Ltas/camera/CameraId;)Ltas/internal/camera/server/RemoteMessage;

    move-result-object v0

    .line 95
    .local v0, "r":Ltas/internal/camera/server/RemoteMessage;
    if-eqz p1, :cond_0

    .line 96
    iget-object v1, v0, Ltas/internal/camera/server/RemoteMessage;->params:Ltas/internal/camera/InputParams;

    iget-object v1, v1, Ltas/internal/camera/InputParams;->msg:Ltas/camera/CameraMessage;

    invoke-virtual {v1, p1}, Ltas/camera/CameraMessage;->copy(Ltas/camera/CameraMessage;)V

    .line 98
    :cond_0
    return-object v0
.end method

.method private readFromParcel(Landroid/os/Parcel;)V
    .locals 1
    .param p1, "source"    # Landroid/os/Parcel;

    .prologue
    .line 48
    iget-object v0, p0, Ltas/internal/camera/server/RemoteMessage;->params:Ltas/internal/camera/InputParams;

    invoke-virtual {v0, p1}, Ltas/internal/camera/InputParams;->readFromParcel(Landroid/os/Parcel;)V

    .line 49
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    iput v0, p0, Ltas/internal/camera/server/RemoteMessage;->stamp:I

    .line 47
    return-void
.end method


# virtual methods
.method public describeContents()I
    .locals 1

    .prologue
    .line 53
    const/4 v0, 0x0

    return v0
.end method

.method public recycle()V
    .locals 1

    .prologue
    .line 102
    iget-boolean v0, p0, Ltas/internal/camera/server/RemoteMessage;->mAllocated:Z

    if-eqz v0, :cond_0

    .line 103
    const/4 v0, 0x0

    iput-boolean v0, p0, Ltas/internal/camera/server/RemoteMessage;->mAllocated:Z

    .line 104
    invoke-direct {p0}, Ltas/internal/camera/server/RemoteMessage;->clear()V

    .line 105
    sget-object v0, Ltas/internal/camera/server/RemoteMessage;->sPool:Ltas/internal/ipc/util/SyncdPool;

    invoke-virtual {v0, p0}, Ltas/internal/ipc/util/SyncdPool;->recycle(Ljava/lang/Object;)V

    .line 101
    :cond_0
    return-void
.end method

.method public toString()Ljava/lang/String;
    .locals 2

    .prologue
    .line 115
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 116
    iget v1, p0, Ltas/internal/camera/server/RemoteMessage;->stamp:I

    .line 115
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 116
    const-string/jumbo v1, " {"

    .line 115
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 117
    const-string/jumbo v1, "\n    "

    .line 115
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 117
    iget-object v1, p0, Ltas/internal/camera/server/RemoteMessage;->params:Ltas/internal/camera/InputParams;

    .line 115
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 118
    const-string/jumbo v1, "\n    cmd/msg {"

    .line 115
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 119
    const-string/jumbo v1, "\n        "

    .line 115
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 119
    iget-object v1, p0, Ltas/internal/camera/server/RemoteMessage;->params:Ltas/internal/camera/InputParams;

    iget-object v1, v1, Ltas/internal/camera/InputParams;->cmd:Ltas/camera/CameraCommand;

    .line 115
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 120
    const-string/jumbo v1, "\n    }"

    .line 115
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 121
    const-string/jumbo v1, "\n} "

    .line 115
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 121
    iget v1, p0, Ltas/internal/camera/server/RemoteMessage;->pool:I

    .line 115
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public writeToParcel(Landroid/os/Parcel;I)V
    .locals 1
    .param p1, "dest"    # Landroid/os/Parcel;
    .param p2, "flags"    # I

    .prologue
    .line 43
    iget-object v0, p0, Ltas/internal/camera/server/RemoteMessage;->params:Ltas/internal/camera/InputParams;

    invoke-virtual {v0, p1}, Ltas/internal/camera/InputParams;->writeToParcel(Landroid/os/Parcel;)V

    .line 44
    iget v0, p0, Ltas/internal/camera/server/RemoteMessage;->stamp:I

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->writeInt(I)V

    .line 42
    return-void
.end method
