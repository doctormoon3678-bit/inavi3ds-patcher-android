.class Ltas/internal/camera/InputSourceInner$NoInput;
.super Ltas/internal/camera/InputSource;
.source "InputSourceInner.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltas/internal/camera/InputSourceInner;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "NoInput"
.end annotation


# direct methods
.method private constructor <init>(Ltas/internal/camera/InputSourceInner;)V
    .locals 1
    .param p1, "parent"    # Ltas/internal/camera/InputSourceInner;

    .prologue
    .line 490
    const/4 v0, 0x0

    invoke-direct {p0, v0}, Ltas/internal/camera/InputSource;-><init>(I)V

    .line 491
    iget-object v0, p0, Ltas/internal/camera/InputSourceInner$NoInput;->hook:Ltas/internal/camera/InputSource$Hook;

    iget-object v0, v0, Ltas/internal/camera/InputSource$Hook;->impl:Ltas/internal/camera/InputSourceInner;

    iput-object p1, v0, Ltas/internal/camera/InputSourceInner;->parent:Ltas/internal/camera/InputSourceInner;

    .line 489
    return-void
.end method

.method synthetic constructor <init>(Ltas/internal/camera/InputSourceInner;Ltas/internal/camera/InputSourceInner$NoInput;)V
    .locals 0
    .param p1, "parent"    # Ltas/internal/camera/InputSourceInner;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/camera/InputSourceInner$NoInput;-><init>(Ltas/internal/camera/InputSourceInner;)V

    return-void
.end method
