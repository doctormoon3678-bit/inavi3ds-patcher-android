.class Ltas/internal/camera/util/CameraMonitor$H;
.super Landroid/os/Handler;
.source "CameraMonitor.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltas/internal/camera/util/CameraMonitor;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "H"
.end annotation


# instance fields
.field private mM:Ljava/lang/ref/WeakReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference",
            "<",
            "Ltas/internal/camera/util/CameraMonitor;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Landroid/os/Looper;Ltas/internal/camera/util/CameraMonitor;)V
    .locals 1
    .param p1, "l"    # Landroid/os/Looper;
    .param p2, "m"    # Ltas/internal/camera/util/CameraMonitor;

    .prologue
    .line 459
    invoke-direct {p0, p1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    new-instance v0, Ljava/lang/ref/WeakReference;

    invoke-direct {v0, p2}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    iput-object v0, p0, Ltas/internal/camera/util/CameraMonitor$H;->mM:Ljava/lang/ref/WeakReference;

    .line 458
    return-void
.end method


# virtual methods
.method public handleMessage(Landroid/os/Message;)V
    .locals 4
    .param p1, "msg"    # Landroid/os/Message;

    .prologue
    const/4 v2, 0x0

    const/4 v1, 0x1

    .line 464
    iget-object v3, p0, Ltas/internal/camera/util/CameraMonitor$H;->mM:Ljava/lang/ref/WeakReference;

    invoke-virtual {v3}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/camera/util/CameraMonitor;

    .line 465
    .local v0, "m":Ltas/internal/camera/util/CameraMonitor;
    if-nez v0, :cond_0

    return-void

    .line 467
    :cond_0
    iget v3, p1, Landroid/os/Message;->what:I

    sparse-switch v3, :sswitch_data_0

    .line 463
    :goto_0
    return-void

    .line 469
    :sswitch_0
    invoke-static {v0}, Ltas/internal/camera/util/CameraMonitor;->-get1(Ltas/internal/camera/util/CameraMonitor;)Ltas/internal/camera/util/CameraMonitor$Callback;

    move-result-object v1

    iget v2, p1, Landroid/os/Message;->arg1:I

    invoke-interface {v1, v0, v2}, Ltas/internal/camera/util/CameraMonitor$Callback;->onCameraOpen(Ltas/internal/camera/util/CameraMonitor;I)V

    goto :goto_0

    .line 472
    :sswitch_1
    invoke-static {v0}, Ltas/internal/camera/util/CameraMonitor;->-get1(Ltas/internal/camera/util/CameraMonitor;)Ltas/internal/camera/util/CameraMonitor$Callback;

    move-result-object v1

    iget v2, p1, Landroid/os/Message;->arg1:I

    invoke-interface {v1, v0, v2}, Ltas/internal/camera/util/CameraMonitor$Callback;->onCameraRelease(Ltas/internal/camera/util/CameraMonitor;I)V

    goto :goto_0

    .line 475
    :sswitch_2
    iget v3, p1, Landroid/os/Message;->arg1:I

    if-ne v3, v1, :cond_1

    :goto_1
    invoke-static {v0, v1}, Ltas/internal/camera/util/CameraMonitor;->-wrap0(Ltas/internal/camera/util/CameraMonitor;Z)V

    goto :goto_0

    :cond_1
    move v1, v2

    goto :goto_1

    .line 478
    :sswitch_3
    iget v3, p1, Landroid/os/Message;->arg1:I

    if-ne v3, v1, :cond_2

    :goto_2
    invoke-static {v0, v1}, Ltas/internal/camera/util/CameraMonitor;->-wrap1(Ltas/internal/camera/util/CameraMonitor;Z)V

    goto :goto_0

    :cond_2
    move v1, v2

    goto :goto_2

    .line 467
    nop

    :sswitch_data_0
    .sparse-switch
        0xa -> :sswitch_0
        0xb -> :sswitch_1
        0x64 -> :sswitch_2
        0x66 -> :sswitch_3
    .end sparse-switch
.end method
