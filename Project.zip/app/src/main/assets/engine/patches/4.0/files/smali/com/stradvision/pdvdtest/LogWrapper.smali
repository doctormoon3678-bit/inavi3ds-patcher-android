.class public Lcom/stradvision/pdvdtest/LogWrapper;
.super Ljava/lang/Object;


# static fields
.field public static final D:I = 0x3

.field public static final E:I = 0x1

.field public static final N:I = 0x0

.field public static final V:I = 0x4

.field public static final W:I = 0x2

.field private static a:Z

.field private static b:I


# direct methods
.method static constructor <clinit>()V
    .locals 4

    new-instance v0, Ljava/text/SimpleDateFormat;

    const-string v1, "MM-dd HH:mm:ss.SSS: "

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v2

    invoke-direct {v0, v1, v2}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    new-instance v0, Ljava/util/Date;

    invoke-direct {v0}, Ljava/util/Date;-><init>()V

    const/4 v0, 0x0

    sput-boolean v0, Lcom/stradvision/pdvdtest/LogWrapper;->a:Z

    const/4 v0, 0x3

    sput v0, Lcom/stradvision/pdvdtest/LogWrapper;->b:I

    :try_start_0
    invoke-static {}, Landroid/os/Environment;->getExternalStorageState()Ljava/lang/String;

    move-result-object v0

    const-string v1, "mounted"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const-string v1, "LOGWRAPPER"

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "  bSDCardExist "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    if-eqz v0, :cond_0

    invoke-static {}, Landroid/os/Environment;->getExternalStorageDirectory()Ljava/io/File;

    move-result-object v0

    invoke-virtual {v0}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    :cond_0
    const-string v0, "/storage/emulated/0"

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-static {v0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-direct {v1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string v0, "/SV_ADAS_LOGS/"

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "LOGWRAPPER"

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "  filePath "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :goto_0
    return-void

    :catch_0
    move-exception v0

    const-string v1, "LogWrapper"

    const-string v2, "init failure"

    invoke-static {v1, v2}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    goto :goto_0
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static d(Ljava/lang/String;Ljava/lang/String;)V
    .locals 2

    sget-boolean v0, Lcom/stradvision/pdvdtest/LogWrapper;->a:Z

    if-eqz v0, :cond_0

    sget v0, Lcom/stradvision/pdvdtest/LogWrapper;->b:I

    const/4 v1, 0x3

    if-ge v0, v1, :cond_1

    :cond_0
    :goto_0
    return-void

    :cond_1
    invoke-static {p0, p1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0
.end method

.method public static e(Ljava/lang/String;Ljava/lang/String;)V
    .locals 1

    sget-boolean v0, Lcom/stradvision/pdvdtest/LogWrapper;->a:Z

    if-eqz v0, :cond_0

    sget v0, Lcom/stradvision/pdvdtest/LogWrapper;->b:I

    if-gtz v0, :cond_1

    :cond_0
    :goto_0
    return-void

    :cond_1
    invoke-static {p0, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0
.end method

.method public static getEnable()Z
    .locals 1

    sget-boolean v0, Lcom/stradvision/pdvdtest/LogWrapper;->a:Z

    return v0
.end method

.method public static getLogLevel()I
    .locals 1

    sget v0, Lcom/stradvision/pdvdtest/LogWrapper;->b:I

    return v0
.end method

.method public static setEnable(Z)V
    .locals 0

    sput-boolean p0, Lcom/stradvision/pdvdtest/LogWrapper;->a:Z

    return-void
.end method

.method public static setLogLevel(I)V
    .locals 0

    sput p0, Lcom/stradvision/pdvdtest/LogWrapper;->b:I

    return-void
.end method

.method public static v(Ljava/lang/String;Ljava/lang/String;)V
    .locals 2

    sget-boolean v0, Lcom/stradvision/pdvdtest/LogWrapper;->a:Z

    if-eqz v0, :cond_0

    sget v0, Lcom/stradvision/pdvdtest/LogWrapper;->b:I

    const/4 v1, 0x4

    if-ge v0, v1, :cond_1

    :cond_0
    :goto_0
    return-void

    :cond_1
    invoke-static {p0, p1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0
.end method

.method public static w(Ljava/lang/String;Ljava/lang/String;)V
    .locals 2

    sget-boolean v0, Lcom/stradvision/pdvdtest/LogWrapper;->a:Z

    if-eqz v0, :cond_0

    sget v0, Lcom/stradvision/pdvdtest/LogWrapper;->b:I

    const/4 v1, 0x2

    if-ge v0, v1, :cond_1

    :cond_0
    :goto_0
    return-void

    :cond_1
    invoke-static {p0, p1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0
.end method
