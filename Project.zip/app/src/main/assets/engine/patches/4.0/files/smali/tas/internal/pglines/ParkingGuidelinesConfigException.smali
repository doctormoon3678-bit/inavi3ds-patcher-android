.class public Ltas/internal/pglines/ParkingGuidelinesConfigException;
.super Ljava/lang/Exception;
.source "ParkingGuidelinesConfigException.java"


# direct methods
.method public constructor <init>(Ljava/lang/String;)V
    .locals 0
    .param p1, "s"    # Ljava/lang/String;

    .prologue
    .line 4
    invoke-direct {p0, p1}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    return-void
.end method
