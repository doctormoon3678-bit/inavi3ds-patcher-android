.class public Ltas/internal/ipc/server/RemoteMessage;
.super Ljava/lang/Object;
.source "RemoteMessage.java"

# interfaces
.implements Landroid/os/Parcelable;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ltas/internal/ipc/server/RemoteMessage$1;,
        Ltas/internal/ipc/server/RemoteMessage$2;
    }
.end annotation


# static fields
.field private static final CALLBACK:Ltas/internal/ipc/util/SyncdPool$Callback;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ltas/internal/ipc/util/SyncdPool$Callback",
            "<",
            "Ltas/internal/ipc/server/RemoteMessage;",
            ">;"
        }
    .end annotation
.end field

.field public static final CREATOR:Landroid/os/Parcelable$Creator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/os/Parcelable$Creator",
            "<",
            "Ltas/internal/ipc/server/RemoteMessage;",
            ">;"
        }
    .end annotation
.end field

.field private static final sPool:Ltas/internal/ipc/util/SyncdPool;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ltas/internal/ipc/util/SyncdPool",
            "<",
            "Ltas/internal/ipc/server/RemoteMessage;",
            ">;"
        }
    .end annotation
.end field

.field private static sPoolId:I

.field private static sStamp:I


# instance fields
.field private mAllocated:Z

.field public msg:Ltas/ipc/MsgData;

.field private next:Ltas/internal/ipc/server/RemoteMessage;

.field private pool:I

.field public receiver:Ltas/internal/ipc/server/RemoteReceiver;

.field public sender:Ltas/internal/ipc/server/RemoteSender;

.field private stamp:I


# direct methods
.method static synthetic -get0(Ltas/internal/ipc/server/RemoteMessage;)Ltas/internal/ipc/server/RemoteMessage;
    .locals 1

    iget-object v0, p0, Ltas/internal/ipc/server/RemoteMessage;->next:Ltas/internal/ipc/server/RemoteMessage;

    return-object v0
.end method

.method static synthetic -get1()Ltas/internal/ipc/util/SyncdPool;
    .locals 1

    sget-object v0, Ltas/internal/ipc/server/RemoteMessage;->sPool:Ltas/internal/ipc/util/SyncdPool;

    return-object v0
.end method

.method static synthetic -get2()I
    .locals 1

    sget v0, Ltas/internal/ipc/server/RemoteMessage;->sPoolId:I

    return v0
.end method

.method static synthetic -get3()I
    .locals 1

    sget v0, Ltas/internal/ipc/server/RemoteMessage;->sStamp:I

    return v0
.end method

.method static synthetic -set0(Ltas/internal/ipc/server/RemoteMessage;Z)Z
    .locals 0

    iput-boolean p1, p0, Ltas/internal/ipc/server/RemoteMessage;->mAllocated:Z

    return p1
.end method

.method static synthetic -set1(Ltas/internal/ipc/server/RemoteMessage;Ltas/internal/ipc/server/RemoteMessage;)Ltas/internal/ipc/server/RemoteMessage;
    .locals 0

    iput-object p1, p0, Ltas/internal/ipc/server/RemoteMessage;->next:Ltas/internal/ipc/server/RemoteMessage;

    return-object p1
.end method

.method static synthetic -set2(Ltas/internal/ipc/server/RemoteMessage;I)I
    .locals 0

    iput p1, p0, Ltas/internal/ipc/server/RemoteMessage;->pool:I

    return p1
.end method

.method static synthetic -set3(I)I
    .locals 0

    sput p0, Ltas/internal/ipc/server/RemoteMessage;->sPoolId:I

    return p0
.end method

.method static synthetic -set4(I)I
    .locals 0

    sput p0, Ltas/internal/ipc/server/RemoteMessage;->sStamp:I

    return p0
.end method

.method static synthetic -set5(Ltas/internal/ipc/server/RemoteMessage;I)I
    .locals 0

    iput p1, p0, Ltas/internal/ipc/server/RemoteMessage;->stamp:I

    return p1
.end method

.method static constructor <clinit>()V
    .locals 3

    .prologue
    const/4 v2, 0x0

    .line 37
    new-instance v0, Ltas/internal/ipc/server/RemoteMessage$1;

    invoke-direct {v0}, Ltas/internal/ipc/server/RemoteMessage$1;-><init>()V

    .line 36
    sput-object v0, Ltas/internal/ipc/server/RemoteMessage;->CREATOR:Landroid/os/Parcelable$Creator;

    .line 89
    new-instance v0, Ltas/internal/ipc/server/RemoteMessage$2;

    invoke-direct {v0}, Ltas/internal/ipc/server/RemoteMessage$2;-><init>()V

    .line 88
    sput-object v0, Ltas/internal/ipc/server/RemoteMessage;->CALLBACK:Ltas/internal/ipc/util/SyncdPool$Callback;

    .line 106
    new-instance v0, Ltas/internal/ipc/util/SyncdPool;

    sget-object v1, Ltas/internal/ipc/server/RemoteMessage;->CALLBACK:Ltas/internal/ipc/util/SyncdPool$Callback;

    invoke-direct {v0, v1}, Ltas/internal/ipc/util/SyncdPool;-><init>(Ltas/internal/ipc/util/SyncdPool$Callback;)V

    .line 105
    sput-object v0, Ltas/internal/ipc/server/RemoteMessage;->sPool:Ltas/internal/ipc/util/SyncdPool;

    .line 107
    sput v2, Ltas/internal/ipc/server/RemoteMessage;->sPoolId:I

    .line 108
    sput v2, Ltas/internal/ipc/server/RemoteMessage;->sStamp:I

    .line 18
    return-void
.end method

.method private constructor <init>()V
    .locals 1

    .prologue
    const/4 v0, -0x1

    .line 114
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 111
    iput v0, p0, Ltas/internal/ipc/server/RemoteMessage;->pool:I

    .line 112
    iput v0, p0, Ltas/internal/ipc/server/RemoteMessage;->stamp:I

    .line 114
    return-void
.end method

.method synthetic constructor <init>(Ltas/internal/ipc/server/RemoteMessage;)V
    .locals 0

    .prologue
    invoke-direct {p0}, Ltas/internal/ipc/server/RemoteMessage;-><init>()V

    return-void
.end method

.method public static obtain(Ltas/internal/ipc/server/RemoteSender;Ltas/internal/ipc/server/RemoteReceiver;Ltas/ipc/MsgData;)Ltas/internal/ipc/server/RemoteMessage;
    .locals 3
    .param p0, "sender"    # Ltas/internal/ipc/server/RemoteSender;
    .param p1, "receiver"    # Ltas/internal/ipc/server/RemoteReceiver;
    .param p2, "msg"    # Ltas/ipc/MsgData;

    .prologue
    .line 27
    sget-object v1, Ltas/internal/ipc/server/RemoteMessage;->sPool:Ltas/internal/ipc/util/SyncdPool;

    invoke-virtual {v1}, Ltas/internal/ipc/util/SyncdPool;->allocate()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/ipc/server/RemoteMessage;

    .line 28
    .local v0, "rmsg":Ltas/internal/ipc/server/RemoteMessage;
    sget v1, Ltas/internal/ipc/server/RemoteMessage;->sStamp:I

    add-int/lit8 v2, v1, 0x1

    sput v2, Ltas/internal/ipc/server/RemoteMessage;->sStamp:I

    iput v1, v0, Ltas/internal/ipc/server/RemoteMessage;->stamp:I

    .line 29
    iput-object p0, v0, Ltas/internal/ipc/server/RemoteMessage;->sender:Ltas/internal/ipc/server/RemoteSender;

    .line 30
    iput-object p1, v0, Ltas/internal/ipc/server/RemoteMessage;->receiver:Ltas/internal/ipc/server/RemoteReceiver;

    .line 31
    iput-object p2, v0, Ltas/internal/ipc/server/RemoteMessage;->msg:Ltas/ipc/MsgData;

    .line 32
    const/4 v1, 0x1

    iput-boolean v1, v0, Ltas/internal/ipc/server/RemoteMessage;->mAllocated:Z

    .line 33
    return-object v0
.end method


# virtual methods
.method public describeContents()I
    .locals 1

    .prologue
    .line 139
    const/4 v0, 0x0

    return v0
.end method

.method public readFromParcel(Landroid/os/Parcel;)V
    .locals 3
    .param p1, "source"    # Landroid/os/Parcel;

    .prologue
    const/4 v2, 0x1

    .line 75
    invoke-virtual {p0}, Ltas/internal/ipc/server/RemoteMessage;->getClass()Ljava/lang/Class;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v0

    .line 76
    .local v0, "classLoader":Ljava/lang/ClassLoader;
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v1

    if-ne v1, v2, :cond_0

    .line 77
    invoke-static {p1}, Ltas/internal/ipc/server/RemoteSender;->createFromParcel(Landroid/os/Parcel;)Ltas/internal/ipc/server/RemoteSender;

    move-result-object v1

    iput-object v1, p0, Ltas/internal/ipc/server/RemoteMessage;->sender:Ltas/internal/ipc/server/RemoteSender;

    .line 79
    :cond_0
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v1

    if-ne v1, v2, :cond_1

    .line 80
    invoke-static {p1}, Ltas/internal/ipc/server/RemoteReceiver;->createFromParcel(Landroid/os/Parcel;)Ltas/internal/ipc/server/RemoteReceiver;

    move-result-object v1

    iput-object v1, p0, Ltas/internal/ipc/server/RemoteMessage;->receiver:Ltas/internal/ipc/server/RemoteReceiver;

    .line 82
    :cond_1
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v1

    if-ne v1, v2, :cond_2

    .line 83
    invoke-static {p1}, Ltas/ipc/MsgData;->createFromParcel(Landroid/os/Parcel;)Ltas/ipc/MsgData;

    move-result-object v1

    iput-object v1, p0, Ltas/internal/ipc/server/RemoteMessage;->msg:Ltas/ipc/MsgData;

    .line 85
    :cond_2
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v1

    iput v1, p0, Ltas/internal/ipc/server/RemoteMessage;->stamp:I

    .line 74
    return-void
.end method

.method public recycle()V
    .locals 2

    .prologue
    const/4 v1, 0x0

    .line 118
    const/4 v0, -0x1

    iput v0, p0, Ltas/internal/ipc/server/RemoteMessage;->stamp:I

    .line 119
    iget-object v0, p0, Ltas/internal/ipc/server/RemoteMessage;->sender:Ltas/internal/ipc/server/RemoteSender;

    if-eqz v0, :cond_0

    .line 120
    iget-object v0, p0, Ltas/internal/ipc/server/RemoteMessage;->sender:Ltas/internal/ipc/server/RemoteSender;

    invoke-virtual {v0}, Ltas/internal/ipc/server/RemoteSender;->recycle()V

    .line 121
    iput-object v1, p0, Ltas/internal/ipc/server/RemoteMessage;->sender:Ltas/internal/ipc/server/RemoteSender;

    .line 123
    :cond_0
    iget-object v0, p0, Ltas/internal/ipc/server/RemoteMessage;->receiver:Ltas/internal/ipc/server/RemoteReceiver;

    if-eqz v0, :cond_1

    .line 124
    iget-object v0, p0, Ltas/internal/ipc/server/RemoteMessage;->receiver:Ltas/internal/ipc/server/RemoteReceiver;

    invoke-virtual {v0}, Ltas/internal/ipc/server/RemoteReceiver;->recycle()V

    .line 125
    iput-object v1, p0, Ltas/internal/ipc/server/RemoteMessage;->receiver:Ltas/internal/ipc/server/RemoteReceiver;

    .line 127
    :cond_1
    iget-object v0, p0, Ltas/internal/ipc/server/RemoteMessage;->msg:Ltas/ipc/MsgData;

    if-eqz v0, :cond_2

    .line 128
    iget-object v0, p0, Ltas/internal/ipc/server/RemoteMessage;->msg:Ltas/ipc/MsgData;

    invoke-virtual {v0}, Ltas/ipc/MsgData;->recycle()V

    .line 129
    iput-object v1, p0, Ltas/internal/ipc/server/RemoteMessage;->msg:Ltas/ipc/MsgData;

    .line 131
    :cond_2
    iget-boolean v0, p0, Ltas/internal/ipc/server/RemoteMessage;->mAllocated:Z

    if-eqz v0, :cond_3

    .line 132
    const/4 v0, 0x0

    iput-boolean v0, p0, Ltas/internal/ipc/server/RemoteMessage;->mAllocated:Z

    .line 133
    sget-object v0, Ltas/internal/ipc/server/RemoteMessage;->sPool:Ltas/internal/ipc/util/SyncdPool;

    invoke-virtual {v0, p0}, Ltas/internal/ipc/util/SyncdPool;->recycle(Ljava/lang/Object;)V

    .line 117
    :cond_3
    return-void
.end method

.method public toString()Ljava/lang/String;
    .locals 6

    .prologue
    const-wide/16 v4, -0x1

    const/4 v1, 0x0

    .line 144
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 145
    const-string/jumbo v2, "Sender:"

    .line 144
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    .line 146
    iget-object v0, p0, Ltas/internal/ipc/server/RemoteMessage;->sender:Ltas/internal/ipc/server/RemoteSender;

    if-eqz v0, :cond_2

    iget-object v0, p0, Ltas/internal/ipc/server/RemoteMessage;->sender:Ltas/internal/ipc/server/RemoteSender;

    iget-object v0, v0, Ltas/internal/ipc/server/RemoteSender;->name:Ljava/lang/String;

    .line 144
    :goto_0
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 147
    iget-object v2, p0, Ltas/internal/ipc/server/RemoteMessage;->sender:Ltas/internal/ipc/server/RemoteSender;

    if-eqz v2, :cond_3

    iget-object v2, p0, Ltas/internal/ipc/server/RemoteMessage;->sender:Ltas/internal/ipc/server/RemoteSender;

    invoke-virtual {v2}, Ltas/internal/ipc/server/RemoteSender;->getid()J

    move-result-wide v2

    .line 144
    :goto_1
    invoke-virtual {v0, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 148
    const-string/jumbo v2, " --> "

    .line 144
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 149
    const-string/jumbo v2, "Receiver:"

    .line 144
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 150
    iget-object v2, p0, Ltas/internal/ipc/server/RemoteMessage;->receiver:Ltas/internal/ipc/server/RemoteReceiver;

    if-eqz v2, :cond_0

    iget-object v1, p0, Ltas/internal/ipc/server/RemoteMessage;->receiver:Ltas/internal/ipc/server/RemoteReceiver;

    iget-object v1, v1, Ltas/internal/ipc/server/RemoteReceiver;->name:Ljava/lang/String;

    .line 144
    :cond_0
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 151
    iget-object v1, p0, Ltas/internal/ipc/server/RemoteMessage;->receiver:Ltas/internal/ipc/server/RemoteReceiver;

    if-eqz v1, :cond_1

    iget-object v1, p0, Ltas/internal/ipc/server/RemoteMessage;->receiver:Ltas/internal/ipc/server/RemoteReceiver;

    invoke-virtual {v1}, Ltas/internal/ipc/server/RemoteReceiver;->getid()J

    move-result-wide v4

    .line 144
    :cond_1
    invoke-virtual {v0, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 152
    const-string/jumbo v1, " "

    .line 144
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 152
    iget-object v1, p0, Ltas/internal/ipc/server/RemoteMessage;->msg:Ltas/ipc/MsgData;

    .line 144
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 153
    const-string/jumbo v1, " stamp="

    .line 144
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 153
    iget v1, p0, Ltas/internal/ipc/server/RemoteMessage;->stamp:I

    .line 144
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 154
    const-string/jumbo v1, "."

    .line 144
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 154
    iget v1, p0, Ltas/internal/ipc/server/RemoteMessage;->pool:I

    .line 144
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0

    :cond_2
    move-object v0, v1

    .line 146
    goto :goto_0

    :cond_3
    move-wide v2, v4

    .line 147
    goto :goto_1
.end method

.method public writeToParcel(Landroid/os/Parcel;I)V
    .locals 3
    .param p1, "dest"    # Landroid/os/Parcel;
    .param p2, "flags"    # I

    .prologue
    const/4 v2, 0x1

    const/4 v1, 0x0

    .line 53
    iget-object v0, p0, Ltas/internal/ipc/server/RemoteMessage;->sender:Ltas/internal/ipc/server/RemoteSender;

    if-eqz v0, :cond_0

    .line 54
    invoke-virtual {p1, v2}, Landroid/os/Parcel;->writeInt(I)V

    .line 55
    iget-object v0, p0, Ltas/internal/ipc/server/RemoteMessage;->sender:Ltas/internal/ipc/server/RemoteSender;

    invoke-virtual {v0, p1, p2}, Ltas/internal/ipc/server/RemoteSender;->writeToParcel(Landroid/os/Parcel;I)V

    .line 59
    :goto_0
    iget-object v0, p0, Ltas/internal/ipc/server/RemoteMessage;->receiver:Ltas/internal/ipc/server/RemoteReceiver;

    if-eqz v0, :cond_1

    .line 60
    invoke-virtual {p1, v2}, Landroid/os/Parcel;->writeInt(I)V

    .line 61
    iget-object v0, p0, Ltas/internal/ipc/server/RemoteMessage;->receiver:Ltas/internal/ipc/server/RemoteReceiver;

    invoke-virtual {v0, p1, p2}, Ltas/internal/ipc/server/RemoteReceiver;->writeToParcel(Landroid/os/Parcel;I)V

    .line 65
    :goto_1
    iget-object v0, p0, Ltas/internal/ipc/server/RemoteMessage;->msg:Ltas/ipc/MsgData;

    if-eqz v0, :cond_2

    .line 66
    invoke-virtual {p1, v2}, Landroid/os/Parcel;->writeInt(I)V

    .line 67
    iget-object v0, p0, Ltas/internal/ipc/server/RemoteMessage;->msg:Ltas/ipc/MsgData;

    invoke-virtual {v0, p1, p2}, Ltas/ipc/MsgData;->writeToParcel(Landroid/os/Parcel;I)V

    .line 71
    :goto_2
    iget v0, p0, Ltas/internal/ipc/server/RemoteMessage;->stamp:I

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->writeInt(I)V

    .line 52
    return-void

    .line 57
    :cond_0
    invoke-virtual {p1, v1}, Landroid/os/Parcel;->writeInt(I)V

    goto :goto_0

    .line 63
    :cond_1
    invoke-virtual {p1, v1}, Landroid/os/Parcel;->writeInt(I)V

    goto :goto_1

    .line 69
    :cond_2
    invoke-virtual {p1, v1}, Landroid/os/Parcel;->writeInt(I)V

    goto :goto_2
.end method
