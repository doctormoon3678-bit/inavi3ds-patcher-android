.class public final Ltas/internal/iobrigade/connector/util/JNIUtil;
.super Ljava/lang/Object;
.source "JNIUtil.java"


# static fields
.field private static DEBUG:Z

.field private static SONAME:Ljava/lang/String;

.field private static TAG:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    .prologue
    .line 5
    const-class v1, Ltas/internal/iobrigade/connector/util/JNIUtil;

    invoke-virtual {v1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v1

    sput-object v1, Ltas/internal/iobrigade/connector/util/JNIUtil;->TAG:Ljava/lang/String;

    .line 6
    const/4 v1, 0x1

    sput-boolean v1, Ltas/internal/iobrigade/connector/util/JNIUtil;->DEBUG:Z

    .line 7
    const-string/jumbo v1, "BrigadeJNIPortContext_jni"

    sput-object v1, Ltas/internal/iobrigade/connector/util/JNIUtil;->SONAME:Ljava/lang/String;

    .line 12
    :try_start_0
    sget-boolean v1, Ltas/internal/iobrigade/connector/util/JNIUtil;->DEBUG:Z

    if-eqz v1, :cond_0

    .line 13
    sget-object v1, Ltas/internal/iobrigade/connector/util/JNIUtil;->TAG:Ljava/lang/String;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    sget-object v3, Ltas/internal/iobrigade/connector/util/JNIUtil;->SONAME:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string/jumbo v3, " is tried to be loaded"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 14
    :cond_0
    sget-object v1, Ltas/internal/iobrigade/connector/util/JNIUtil;->SONAME:Ljava/lang/String;

    invoke-static {v1}, Ljava/lang/System;->loadLibrary(Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/UnsatisfiedLinkError; {:try_start_0 .. :try_end_0} :catch_0

    .line 3
    .local v0, "e":Ljava/lang/UnsatisfiedLinkError;
    :goto_0
    return-void

    .line 15
    .end local v0    # "e":Ljava/lang/UnsatisfiedLinkError;
    :catch_0
    move-exception v0

    .line 16
    .restart local v0    # "e":Ljava/lang/UnsatisfiedLinkError;
    invoke-virtual {v0}, Ljava/lang/UnsatisfiedLinkError;->printStackTrace()V

    goto :goto_0
.end method

.method private constructor <init>()V
    .locals 0

    .prologue
    .line 8
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static loadNativeLibrary()V
    .locals 0

    .prologue
    .line 21
    return-void
.end method
