.class public abstract Ltas/internal/ipc/server/IServerCallback$Stub;
.super Landroid/os/Binder;
.source "IServerCallback.java"

# interfaces
.implements Ltas/internal/ipc/server/IServerCallback;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltas/internal/ipc/server/IServerCallback;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "Stub"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ltas/internal/ipc/server/IServerCallback$Stub$Proxy;
    }
.end annotation


# static fields
.field private static final DESCRIPTOR:Ljava/lang/String; = "tas.internal.ipc.server.IServerCallback"

.field static final TRANSACTION_onReceiverOffline:I = 0x2

.field static final TRANSACTION_onReceiverOnline:I = 0x1

.field static final TRANSACTION_onReceiverUpdate:I = 0x3

.field static final TRANSACTION_onSenderOffline:I = 0x5

.field static final TRANSACTION_onSenderOnline:I = 0x4

.field static final TRANSACTION_onSenderUpdate:I = 0x6

.field static final TRANSACTION_transmit:I = 0x7


# direct methods
.method public constructor <init>()V
    .locals 1

    .prologue
    .line 13
    invoke-direct {p0}, Landroid/os/Binder;-><init>()V

    .line 15
    const-string/jumbo v0, "tas.internal.ipc.server.IServerCallback"

    invoke-virtual {p0, p0, v0}, Ltas/internal/ipc/server/IServerCallback$Stub;->attachInterface(Landroid/os/IInterface;Ljava/lang/String;)V

    .line 13
    return-void
.end method

.method public static asInterface(Landroid/os/IBinder;)Ltas/internal/ipc/server/IServerCallback;
    .locals 2
    .param p0, "obj"    # Landroid/os/IBinder;

    .prologue
    const/4 v1, 0x0

    .line 23
    if-nez p0, :cond_0

    .line 24
    return-object v1

    .line 26
    :cond_0
    const-string/jumbo v1, "tas.internal.ipc.server.IServerCallback"

    invoke-interface {p0, v1}, Landroid/os/IBinder;->queryLocalInterface(Ljava/lang/String;)Landroid/os/IInterface;

    move-result-object v0

    .line 27
    .local v0, "iin":Landroid/os/IInterface;
    if-eqz v0, :cond_1

    instance-of v1, v0, Ltas/internal/ipc/server/IServerCallback;

    if-eqz v1, :cond_1

    .line 28
    check-cast v0, Ltas/internal/ipc/server/IServerCallback;

    .end local v0    # "iin":Landroid/os/IInterface;
    return-object v0

    .line 30
    .restart local v0    # "iin":Landroid/os/IInterface;
    :cond_1
    new-instance v1, Ltas/internal/ipc/server/IServerCallback$Stub$Proxy;

    invoke-direct {v1, p0}, Ltas/internal/ipc/server/IServerCallback$Stub$Proxy;-><init>(Landroid/os/IBinder;)V

    return-object v1
.end method


# virtual methods
.method public asBinder()Landroid/os/IBinder;
    .locals 0

    .prologue
    .line 34
    return-object p0
.end method

.method public onTransact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    .locals 7
    .param p1, "code"    # I
    .param p2, "data"    # Landroid/os/Parcel;
    .param p3, "reply"    # Landroid/os/Parcel;
    .param p4, "flags"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .prologue
    const/4 v6, 0x1

    .line 38
    sparse-switch p1, :sswitch_data_0

    .line 186
    invoke-super {p0, p1, p2, p3, p4}, Landroid/os/Binder;->onTransact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z

    move-result v5

    return v5

    .line 42
    :sswitch_0
    const-string/jumbo v5, "tas.internal.ipc.server.IServerCallback"

    invoke-virtual {p3, v5}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    .line 43
    return v6

    .line 47
    :sswitch_1
    const-string/jumbo v5, "tas.internal.ipc.server.IServerCallback"

    invoke-virtual {p2, v5}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 49
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v5

    if-eqz v5, :cond_0

    .line 50
    sget-object v5, Ltas/internal/ipc/server/RemoteSender;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-interface {v5, p2}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ltas/internal/ipc/server/RemoteSender;

    .line 56
    :goto_0
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v5

    if-eqz v5, :cond_1

    .line 57
    sget-object v5, Ltas/internal/ipc/server/RemoteReceiver;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-interface {v5, p2}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ltas/internal/ipc/server/RemoteReceiver;

    .line 62
    :goto_1
    invoke-virtual {p0, v2, v3}, Ltas/internal/ipc/server/IServerCallback$Stub;->onReceiverOnline(Ltas/internal/ipc/server/RemoteSender;Ltas/internal/ipc/server/RemoteReceiver;)V

    .line 63
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 64
    return v6

    .line 53
    :cond_0
    const/4 v2, 0x0

    .local v2, "_arg0":Ltas/internal/ipc/server/RemoteSender;
    goto :goto_0

    .line 60
    .end local v2    # "_arg0":Ltas/internal/ipc/server/RemoteSender;
    :cond_1
    const/4 v3, 0x0

    .local v3, "_arg1":Ltas/internal/ipc/server/RemoteReceiver;
    goto :goto_1

    .line 68
    .end local v3    # "_arg1":Ltas/internal/ipc/server/RemoteReceiver;
    :sswitch_2
    const-string/jumbo v5, "tas.internal.ipc.server.IServerCallback"

    invoke-virtual {p2, v5}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 70
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v5

    if-eqz v5, :cond_2

    .line 71
    sget-object v5, Ltas/internal/ipc/server/RemoteSender;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-interface {v5, p2}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ltas/internal/ipc/server/RemoteSender;

    .line 77
    :goto_2
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v5

    if-eqz v5, :cond_3

    .line 78
    sget-object v5, Ltas/internal/ipc/server/RemoteReceiver;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-interface {v5, p2}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ltas/internal/ipc/server/RemoteReceiver;

    .line 83
    :goto_3
    invoke-virtual {p0, v2, v3}, Ltas/internal/ipc/server/IServerCallback$Stub;->onReceiverOffline(Ltas/internal/ipc/server/RemoteSender;Ltas/internal/ipc/server/RemoteReceiver;)V

    .line 84
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 85
    return v6

    .line 74
    :cond_2
    const/4 v2, 0x0

    .restart local v2    # "_arg0":Ltas/internal/ipc/server/RemoteSender;
    goto :goto_2

    .line 81
    .end local v2    # "_arg0":Ltas/internal/ipc/server/RemoteSender;
    :cond_3
    const/4 v3, 0x0

    .restart local v3    # "_arg1":Ltas/internal/ipc/server/RemoteReceiver;
    goto :goto_3

    .line 89
    .end local v3    # "_arg1":Ltas/internal/ipc/server/RemoteReceiver;
    :sswitch_3
    const-string/jumbo v5, "tas.internal.ipc.server.IServerCallback"

    invoke-virtual {p2, v5}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 91
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v5

    if-eqz v5, :cond_4

    .line 92
    sget-object v5, Ltas/internal/ipc/server/RemoteSender;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-interface {v5, p2}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ltas/internal/ipc/server/RemoteSender;

    .line 98
    :goto_4
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v5

    if-eqz v5, :cond_5

    .line 99
    sget-object v5, Ltas/internal/ipc/server/RemoteReceiver;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-interface {v5, p2}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ltas/internal/ipc/server/RemoteReceiver;

    .line 104
    :goto_5
    invoke-virtual {p0, v2, v3}, Ltas/internal/ipc/server/IServerCallback$Stub;->onReceiverUpdate(Ltas/internal/ipc/server/RemoteSender;Ltas/internal/ipc/server/RemoteReceiver;)V

    .line 105
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 106
    return v6

    .line 95
    :cond_4
    const/4 v2, 0x0

    .restart local v2    # "_arg0":Ltas/internal/ipc/server/RemoteSender;
    goto :goto_4

    .line 102
    .end local v2    # "_arg0":Ltas/internal/ipc/server/RemoteSender;
    :cond_5
    const/4 v3, 0x0

    .restart local v3    # "_arg1":Ltas/internal/ipc/server/RemoteReceiver;
    goto :goto_5

    .line 110
    .end local v3    # "_arg1":Ltas/internal/ipc/server/RemoteReceiver;
    :sswitch_4
    const-string/jumbo v5, "tas.internal.ipc.server.IServerCallback"

    invoke-virtual {p2, v5}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 112
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v5

    if-eqz v5, :cond_6

    .line 113
    sget-object v5, Ltas/internal/ipc/server/RemoteReceiver;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-interface {v5, p2}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ltas/internal/ipc/server/RemoteReceiver;

    .line 119
    :goto_6
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v5

    if-eqz v5, :cond_7

    .line 120
    sget-object v5, Ltas/internal/ipc/server/RemoteSender;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-interface {v5, p2}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ltas/internal/ipc/server/RemoteSender;

    .line 125
    :goto_7
    invoke-virtual {p0, v1, v4}, Ltas/internal/ipc/server/IServerCallback$Stub;->onSenderOnline(Ltas/internal/ipc/server/RemoteReceiver;Ltas/internal/ipc/server/RemoteSender;)V

    .line 126
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 127
    return v6

    .line 116
    :cond_6
    const/4 v1, 0x0

    .local v1, "_arg0":Ltas/internal/ipc/server/RemoteReceiver;
    goto :goto_6

    .line 123
    .end local v1    # "_arg0":Ltas/internal/ipc/server/RemoteReceiver;
    :cond_7
    const/4 v4, 0x0

    .local v4, "_arg1":Ltas/internal/ipc/server/RemoteSender;
    goto :goto_7

    .line 131
    .end local v4    # "_arg1":Ltas/internal/ipc/server/RemoteSender;
    :sswitch_5
    const-string/jumbo v5, "tas.internal.ipc.server.IServerCallback"

    invoke-virtual {p2, v5}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 133
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v5

    if-eqz v5, :cond_8

    .line 134
    sget-object v5, Ltas/internal/ipc/server/RemoteReceiver;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-interface {v5, p2}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ltas/internal/ipc/server/RemoteReceiver;

    .line 140
    :goto_8
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v5

    if-eqz v5, :cond_9

    .line 141
    sget-object v5, Ltas/internal/ipc/server/RemoteSender;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-interface {v5, p2}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ltas/internal/ipc/server/RemoteSender;

    .line 146
    :goto_9
    invoke-virtual {p0, v1, v4}, Ltas/internal/ipc/server/IServerCallback$Stub;->onSenderOffline(Ltas/internal/ipc/server/RemoteReceiver;Ltas/internal/ipc/server/RemoteSender;)V

    .line 147
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 148
    return v6

    .line 137
    :cond_8
    const/4 v1, 0x0

    .restart local v1    # "_arg0":Ltas/internal/ipc/server/RemoteReceiver;
    goto :goto_8

    .line 144
    .end local v1    # "_arg0":Ltas/internal/ipc/server/RemoteReceiver;
    :cond_9
    const/4 v4, 0x0

    .restart local v4    # "_arg1":Ltas/internal/ipc/server/RemoteSender;
    goto :goto_9

    .line 152
    .end local v4    # "_arg1":Ltas/internal/ipc/server/RemoteSender;
    :sswitch_6
    const-string/jumbo v5, "tas.internal.ipc.server.IServerCallback"

    invoke-virtual {p2, v5}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 154
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v5

    if-eqz v5, :cond_a

    .line 155
    sget-object v5, Ltas/internal/ipc/server/RemoteReceiver;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-interface {v5, p2}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ltas/internal/ipc/server/RemoteReceiver;

    .line 161
    :goto_a
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v5

    if-eqz v5, :cond_b

    .line 162
    sget-object v5, Ltas/internal/ipc/server/RemoteSender;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-interface {v5, p2}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ltas/internal/ipc/server/RemoteSender;

    .line 167
    :goto_b
    invoke-virtual {p0, v1, v4}, Ltas/internal/ipc/server/IServerCallback$Stub;->onSenderUpdate(Ltas/internal/ipc/server/RemoteReceiver;Ltas/internal/ipc/server/RemoteSender;)V

    .line 168
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 169
    return v6

    .line 158
    :cond_a
    const/4 v1, 0x0

    .restart local v1    # "_arg0":Ltas/internal/ipc/server/RemoteReceiver;
    goto :goto_a

    .line 165
    .end local v1    # "_arg0":Ltas/internal/ipc/server/RemoteReceiver;
    :cond_b
    const/4 v4, 0x0

    .restart local v4    # "_arg1":Ltas/internal/ipc/server/RemoteSender;
    goto :goto_b

    .line 173
    .end local v4    # "_arg1":Ltas/internal/ipc/server/RemoteSender;
    :sswitch_7
    const-string/jumbo v5, "tas.internal.ipc.server.IServerCallback"

    invoke-virtual {p2, v5}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 175
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v5

    if-eqz v5, :cond_c

    .line 176
    sget-object v5, Ltas/internal/ipc/server/RemoteMessage;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-interface {v5, p2}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/ipc/server/RemoteMessage;

    .line 181
    :goto_c
    invoke-virtual {p0, v0}, Ltas/internal/ipc/server/IServerCallback$Stub;->transmit(Ltas/internal/ipc/server/RemoteMessage;)V

    .line 182
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 183
    return v6

    .line 179
    :cond_c
    const/4 v0, 0x0

    .local v0, "_arg0":Ltas/internal/ipc/server/RemoteMessage;
    goto :goto_c

    .line 38
    nop

    :sswitch_data_0
    .sparse-switch
        0x1 -> :sswitch_1
        0x2 -> :sswitch_2
        0x3 -> :sswitch_3
        0x4 -> :sswitch_4
        0x5 -> :sswitch_5
        0x6 -> :sswitch_6
        0x7 -> :sswitch_7
        0x5f4e5446 -> :sswitch_0
    .end sparse-switch
.end method
