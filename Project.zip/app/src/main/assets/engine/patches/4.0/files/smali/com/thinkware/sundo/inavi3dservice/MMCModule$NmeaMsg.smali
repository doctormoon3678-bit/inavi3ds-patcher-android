.class Lcom/thinkware/sundo/inavi3dservice/MMCModule$NmeaMsg;
.super Ljava/lang/Object;
.source "MMCModule.java"

# interfaces
.implements Landroid/location/OnNmeaMessageListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/thinkware/sundo/inavi3dservice/MMCModule;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = "NmeaMsg"
.end annotation


# instance fields
.field final synthetic this$0:Lcom/thinkware/sundo/inavi3dservice/MMCModule;


# direct methods
.method constructor <init>(Lcom/thinkware/sundo/inavi3dservice/MMCModule;)V
    .locals 0

    .prologue
    iput-object p1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule$NmeaMsg;->this$0:Lcom/thinkware/sundo/inavi3dservice/MMCModule;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onNmeaMessage(Ljava/lang/String;J)V
    .locals 6
    .param p1, "message"    # Ljava/lang/String;
    .param p2, "timestamp"    # J

    .prologue
    if-eqz p1, :cond_0

    invoke-virtual {p1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v5

    invoke-static {v5}, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->normalizeGnssNmea(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    :cond_0
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule$NmeaMsg;->this$0:Lcom/thinkware/sundo/inavi3dservice/MMCModule;

    invoke-static {v3}, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->access$000(Lcom/thinkware/sundo/inavi3dservice/MMCModule;)Z

    move-result v3

    if-eqz v3, :cond_2

    :cond_1
    :goto_0
    return-void

    :cond_2
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule$NmeaMsg;->this$0:Lcom/thinkware/sundo/inavi3dservice/MMCModule;

    invoke-static {v3}, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->access$200(Lcom/thinkware/sundo/inavi3dservice/MMCModule;)[Z

    move-result-object v3

    const/4 v4, 0x2

    aget-boolean v3, v3, v4

    if-nez v3, :cond_1

    if-eqz p1, :cond_1

    const/16 v3, 0x800

    new-array v0, v3, [B

    .local v0, "buffer":[B
    invoke-virtual {p1}, Ljava/lang/String;->toCharArray()[C

    move-result-object v1

    .local v1, "cArray":[C
    const/4 v2, 0x0

    .local v2, "i":I
    :goto_1
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v3

    if-ge v2, v3, :cond_3

    aget-char v3, v1, v2

    int-to-byte v3, v3

    aput-byte v3, v0, v2

    add-int/lit8 v2, v2, 0x1

    goto :goto_1

    :cond_3
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule$NmeaMsg;->this$0:Lcom/thinkware/sundo/inavi3dservice/MMCModule;

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v4

    invoke-static {v3, p2, p3, v0, v4}, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->access$300(Lcom/thinkware/sundo/inavi3dservice/MMCModule;J[BI)V

    goto :goto_0
.end method
