.class public interface abstract Ltas/internal/ipc/server/IServerCallback;
.super Ljava/lang/Object;
.source "IServerCallback.java"

# interfaces
.implements Landroid/os/IInterface;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ltas/internal/ipc/server/IServerCallback$Stub;
    }
.end annotation


# virtual methods
.method public abstract onReceiverOffline(Ltas/internal/ipc/server/RemoteSender;Ltas/internal/ipc/server/RemoteReceiver;)V
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation
.end method

.method public abstract onReceiverOnline(Ltas/internal/ipc/server/RemoteSender;Ltas/internal/ipc/server/RemoteReceiver;)V
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation
.end method

.method public abstract onReceiverUpdate(Ltas/internal/ipc/server/RemoteSender;Ltas/internal/ipc/server/RemoteReceiver;)V
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation
.end method

.method public abstract onSenderOffline(Ltas/internal/ipc/server/RemoteReceiver;Ltas/internal/ipc/server/RemoteSender;)V
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation
.end method

.method public abstract onSenderOnline(Ltas/internal/ipc/server/RemoteReceiver;Ltas/internal/ipc/server/RemoteSender;)V
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation
.end method

.method public abstract onSenderUpdate(Ltas/internal/ipc/server/RemoteReceiver;Ltas/internal/ipc/server/RemoteSender;)V
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation
.end method

.method public abstract transmit(Ltas/internal/ipc/server/RemoteMessage;)V
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation
.end method
