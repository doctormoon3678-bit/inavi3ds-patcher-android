.class public abstract Ltas/camera/CameraId;
.super Ljava/lang/Object;
.source "CameraId.java"


# static fields
.field public static final CLOSED:I = 0x2

.field public static final CUSTOM_CMD:I = 0x7d0

.field public static final CUSTOM_ERR:I = -0x3e8

.field public static final CUSTOM_MSG:I = 0x3e8

.field public static final ERR_ALREADY_OPENED:I = -0xe

.field public static final ERR_DENIED:I = -0x8

.field public static final ERR_GUARDIAN:I = -0x7

.field public static final ERR_HARDWARE:I = -0x4

.field public static final ERR_MEDIA_SERVER:I = -0x6

.field public static final ERR_NOT_PLUGGED:I = -0xc

.field public static final ERR_NOT_REQUESTED:I = -0xd

.field public static final ERR_NOT_SUPPORTED:I = -0x9

.field public static final ERR_NO_SUCH_CAMERA:I = -0x5

.field public static final ERR_OCCUPIED:I = -0x2

.field public static final ERR_SERVER_DIED:I = -0xb

.field public static final ERR_SERVER_DISCONNECTED:I = -0xa

.field public static final ERR_UNKNOWN:I = -0x1

.field public static final ERR_UNKNOWN_OCCUPIED:I = -0x3

.field public static final OKAY:I = 0x0

.field public static final OPENED:I = 0x1

.field public static final READ_REGISTER:I = 0x1f5

.field public static final SET_CABLE_IN:I = 0x1f7

.field public static final SET_CABLE_OUT:I = 0x1f8

.field public static final SET_INPUT:I = 0x1f4

.field public static final WRITE_REGISTER:I = 0x1f6


# instance fields
.field public id:Ljava/lang/String;

.field public idCompat:I

.field public opened:Z

.field public plugged:Z


# direct methods
.method public constructor <init>()V
    .locals 0

    .prologue
    .line 11
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public cancel()V
    .locals 1

    .prologue
    .line 58
    invoke-virtual {p0}, Ltas/camera/CameraId;->proxy()Ltas/internal/camera/client/CameraProxy;

    move-result-object v0

    invoke-virtual {v0}, Ltas/internal/camera/client/CameraProxy;->cancel()V

    .line 57
    return-void
.end method

.method public obtainCommand(I)Ltas/camera/CameraCommand;
    .locals 1
    .param p1, "what"    # I

    .prologue
    .line 117
    new-instance v0, Ltas/camera/CameraCommand;

    invoke-direct {v0, p1}, Ltas/camera/CameraCommand;-><init>(I)V

    return-object v0
.end method

.method protected abstract proxy()Ltas/internal/camera/client/CameraProxy;
.end method

.method public release()V
    .locals 1

    .prologue
    .line 50
    invoke-virtual {p0}, Ltas/camera/CameraId;->proxy()Ltas/internal/camera/client/CameraProxy;

    move-result-object v0

    invoke-virtual {v0}, Ltas/internal/camera/client/CameraProxy;->release()V

    .line 49
    return-void
.end method

.method public request()V
    .locals 1

    .prologue
    .line 54
    invoke-virtual {p0}, Ltas/camera/CameraId;->proxy()Ltas/internal/camera/client/CameraProxy;

    move-result-object v0

    invoke-virtual {v0}, Ltas/internal/camera/client/CameraProxy;->request()V

    .line 53
    return-void
.end method

.method public sendCommand(I)V
    .locals 1
    .param p1, "what"    # I

    .prologue
    .line 62
    invoke-virtual {p0, p1}, Ltas/camera/CameraId;->obtainCommand(I)Ltas/camera/CameraCommand;

    move-result-object v0

    .line 63
    .local v0, "cmd":Ltas/camera/CameraCommand;
    invoke-virtual {p0, v0}, Ltas/camera/CameraId;->sendCommand(Ltas/camera/CameraCommand;)V

    .line 61
    return-void
.end method

.method public sendCommand(II)V
    .locals 1
    .param p1, "what"    # I
    .param p2, "arg1"    # I

    .prologue
    .line 67
    invoke-virtual {p0, p1}, Ltas/camera/CameraId;->obtainCommand(I)Ltas/camera/CameraCommand;

    move-result-object v0

    .line 68
    .local v0, "cmd":Ltas/camera/CameraCommand;
    iput p2, v0, Ltas/camera/CameraCommand;->arg1:I

    .line 69
    invoke-virtual {p0, v0}, Ltas/camera/CameraId;->sendCommand(Ltas/camera/CameraCommand;)V

    .line 66
    return-void
.end method

.method public sendCommand(III)V
    .locals 1
    .param p1, "what"    # I
    .param p2, "arg1"    # I
    .param p3, "arg2"    # I

    .prologue
    .line 73
    invoke-virtual {p0, p1}, Ltas/camera/CameraId;->obtainCommand(I)Ltas/camera/CameraCommand;

    move-result-object v0

    .line 74
    .local v0, "cmd":Ltas/camera/CameraCommand;
    iput p2, v0, Ltas/camera/CameraCommand;->arg1:I

    .line 75
    iput p3, v0, Ltas/camera/CameraCommand;->arg2:I

    .line 76
    invoke-virtual {p0, v0}, Ltas/camera/CameraId;->sendCommand(Ltas/camera/CameraCommand;)V

    .line 72
    return-void
.end method

.method public varargs sendCommand(III[I)V
    .locals 1
    .param p1, "what"    # I
    .param p2, "arg1"    # I
    .param p3, "arg2"    # I
    .param p4, "args"    # [I

    .prologue
    .line 80
    invoke-virtual {p0, p1}, Ltas/camera/CameraId;->obtainCommand(I)Ltas/camera/CameraCommand;

    move-result-object v0

    .line 81
    .local v0, "cmd":Ltas/camera/CameraCommand;
    iput p2, v0, Ltas/camera/CameraCommand;->arg1:I

    .line 82
    iput p3, v0, Ltas/camera/CameraCommand;->arg2:I

    .line 83
    iput-object p4, v0, Ltas/camera/CameraCommand;->args:[I

    .line 84
    invoke-virtual {p0, v0}, Ltas/camera/CameraId;->sendCommand(Ltas/camera/CameraCommand;)V

    .line 79
    return-void
.end method

.method public sendCommand(ILandroid/os/Bundle;)V
    .locals 1
    .param p1, "what"    # I
    .param p2, "extra"    # Landroid/os/Bundle;

    .prologue
    .line 107
    invoke-virtual {p0, p1}, Ltas/camera/CameraId;->obtainCommand(I)Ltas/camera/CameraCommand;

    move-result-object v0

    .line 108
    .local v0, "cmd":Ltas/camera/CameraCommand;
    iput-object p2, v0, Ltas/camera/CameraCommand;->extra:Landroid/os/Bundle;

    .line 109
    invoke-virtual {p0, v0}, Ltas/camera/CameraId;->sendCommand(Ltas/camera/CameraCommand;)V

    .line 106
    return-void
.end method

.method public sendCommand(ILjava/lang/String;)V
    .locals 1
    .param p1, "what"    # I
    .param p2, "str1"    # Ljava/lang/String;

    .prologue
    .line 94
    invoke-virtual {p0, p1}, Ltas/camera/CameraId;->obtainCommand(I)Ltas/camera/CameraCommand;

    move-result-object v0

    .line 95
    .local v0, "cmd":Ltas/camera/CameraCommand;
    iput-object p2, v0, Ltas/camera/CameraCommand;->str1:Ljava/lang/String;

    .line 96
    invoke-virtual {p0, v0}, Ltas/camera/CameraId;->sendCommand(Ltas/camera/CameraCommand;)V

    .line 93
    return-void
.end method

.method public sendCommand(ILjava/lang/String;Ljava/lang/String;)V
    .locals 1
    .param p1, "what"    # I
    .param p2, "str1"    # Ljava/lang/String;
    .param p3, "str2"    # Ljava/lang/String;

    .prologue
    .line 100
    invoke-virtual {p0, p1}, Ltas/camera/CameraId;->obtainCommand(I)Ltas/camera/CameraCommand;

    move-result-object v0

    .line 101
    .local v0, "cmd":Ltas/camera/CameraCommand;
    iput-object p2, v0, Ltas/camera/CameraCommand;->str1:Ljava/lang/String;

    .line 102
    iput-object p3, v0, Ltas/camera/CameraCommand;->str2:Ljava/lang/String;

    .line 103
    invoke-virtual {p0, v0}, Ltas/camera/CameraId;->sendCommand(Ltas/camera/CameraCommand;)V

    .line 99
    return-void
.end method

.method public sendCommand(I[B)V
    .locals 1
    .param p1, "what"    # I
    .param p2, "bytes"    # [B

    .prologue
    .line 88
    invoke-virtual {p0, p1}, Ltas/camera/CameraId;->obtainCommand(I)Ltas/camera/CameraCommand;

    move-result-object v0

    .line 89
    .local v0, "cmd":Ltas/camera/CameraCommand;
    iput-object p2, v0, Ltas/camera/CameraCommand;->bytes:[B

    .line 90
    invoke-virtual {p0, v0}, Ltas/camera/CameraId;->sendCommand(Ltas/camera/CameraCommand;)V

    .line 87
    return-void
.end method

.method public sendCommand(Ltas/camera/CameraCommand;)V
    .locals 1
    .param p1, "cmd"    # Ltas/camera/CameraCommand;

    .prologue
    .line 113
    invoke-virtual {p0}, Ltas/camera/CameraId;->proxy()Ltas/internal/camera/client/CameraProxy;

    move-result-object v0

    invoke-virtual {v0, p1}, Ltas/internal/camera/client/CameraProxy;->command(Ltas/camera/CameraCommand;)V

    .line 112
    return-void
.end method
