.class Ltas/internal/camera/QueueBase$1;
.super Ljava/lang/Object;
.source "QueueBase.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltas/internal/camera/QueueBase;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Ltas/internal/camera/QueueBase;


# direct methods
.method constructor <init>(Ltas/internal/camera/QueueBase;)V
    .locals 0

    .prologue
    .line 126
    .local p1, "this$0":Ltas/internal/camera/QueueBase;, "Ltas/internal/camera/QueueBase<TT;>;"
    iput-object p1, p0, Ltas/internal/camera/QueueBase$1;->this$0:Ltas/internal/camera/QueueBase;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 2

    .prologue
    .line 128
    iget-object v1, p0, Ltas/internal/camera/QueueBase$1;->this$0:Ltas/internal/camera/QueueBase;

    invoke-virtual {v1}, Ltas/internal/camera/QueueBase;->isPaused()Z

    move-result v1

    if-eqz v1, :cond_0

    .line 129
    iget-object v1, p0, Ltas/internal/camera/QueueBase$1;->this$0:Ltas/internal/camera/QueueBase;

    invoke-static {v1}, Ltas/internal/camera/QueueBase;->-wrap1(Ltas/internal/camera/QueueBase;)V

    .line 130
    return-void

    .line 133
    :cond_0
    iget-object v1, p0, Ltas/internal/camera/QueueBase$1;->this$0:Ltas/internal/camera/QueueBase;

    invoke-static {v1}, Ltas/internal/camera/QueueBase;->-get1(Ltas/internal/camera/QueueBase;)Ljava/util/Deque;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/Deque;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_1

    .line 134
    iget-object v1, p0, Ltas/internal/camera/QueueBase$1;->this$0:Ltas/internal/camera/QueueBase;

    invoke-static {v1}, Ltas/internal/camera/QueueBase;->-wrap1(Ltas/internal/camera/QueueBase;)V

    .line 135
    return-void

    .line 138
    :cond_1
    iget-object v1, p0, Ltas/internal/camera/QueueBase$1;->this$0:Ltas/internal/camera/QueueBase;

    invoke-virtual {v1}, Ltas/internal/camera/QueueBase;->onDequeue()Ljava/lang/Object;

    move-result-object v0

    .line 139
    .local v0, "t":Ljava/lang/Object;, "TT;"
    if-nez v0, :cond_2

    .line 140
    iget-object v1, p0, Ltas/internal/camera/QueueBase$1;->this$0:Ltas/internal/camera/QueueBase;

    invoke-static {v1}, Ltas/internal/camera/QueueBase;->-wrap0(Ltas/internal/camera/QueueBase;)V

    .line 141
    return-void

    .line 145
    :cond_2
    iget-object v1, p0, Ltas/internal/camera/QueueBase$1;->this$0:Ltas/internal/camera/QueueBase;

    invoke-virtual {v1, v0}, Ltas/internal/camera/QueueBase;->onAvailable(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_3

    iget-object v1, p0, Ltas/internal/camera/QueueBase$1;->this$0:Ltas/internal/camera/QueueBase;

    invoke-static {v1}, Ltas/internal/camera/QueueBase;->-get0(Ltas/internal/camera/QueueBase;)Ltas/internal/camera/QueueBase$OnAvailableListener;

    move-result-object v1

    if-eqz v1, :cond_4

    iget-object v1, p0, Ltas/internal/camera/QueueBase$1;->this$0:Ltas/internal/camera/QueueBase;

    invoke-static {v1}, Ltas/internal/camera/QueueBase;->-get0(Ltas/internal/camera/QueueBase;)Ltas/internal/camera/QueueBase$OnAvailableListener;

    move-result-object v1

    invoke-interface {v1, v0}, Ltas/internal/camera/QueueBase$OnAvailableListener;->onAvailable(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_4

    .line 146
    :cond_3
    iget-object v1, p0, Ltas/internal/camera/QueueBase$1;->this$0:Ltas/internal/camera/QueueBase;

    invoke-static {v1, v0}, Ltas/internal/camera/QueueBase;->-set0(Ltas/internal/camera/QueueBase;Ljava/lang/Object;)Ljava/lang/Object;

    .line 149
    :cond_4
    iget-object v1, p0, Ltas/internal/camera/QueueBase$1;->this$0:Ltas/internal/camera/QueueBase;

    invoke-static {v1}, Ltas/internal/camera/QueueBase;->-wrap0(Ltas/internal/camera/QueueBase;)V

    .line 127
    return-void
.end method
