.class public Ltas/util/backlight/UBacklight;
.super Ljava/lang/Object;
.source "UBacklight.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ltas/util/backlight/UBacklight$BrightnessObserver;
    }
.end annotation


# static fields
.field public static final INVALID:I = -0x1

.field public static final MAX:I

.field public static final MIN:I

.field private static sSelf:Ltas/util/backlight/UBacklight;


# instance fields
.field private final BRIGHTNESS:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List",
            "<",
            "Ltas/util/backlight/UBacklight$BrightnessObserver;",
            ">;"
        }
    .end annotation
.end field

.field private COUNT:I

.field private OBSERVER:Landroid/database/ContentObserver;


# direct methods
.method static synthetic -get0(Ltas/util/backlight/UBacklight;)Ljava/util/List;
    .locals 1

    iget-object v0, p0, Ltas/util/backlight/UBacklight;->BRIGHTNESS:Ljava/util/List;

    return-object v0
.end method

.method static constructor <clinit>()V
    .locals 1

    .prologue
    .line 32
    const/16 v0, 0xff

    sput v0, Ltas/util/backlight/UBacklight;->MAX:I

    .line 33
    const/16 v0, 0x19

    sput v0, Ltas/util/backlight/UBacklight;->MIN:I

    .line 25
    return-void
.end method

.method private constructor <init>()V
    .locals 1

    .prologue
    .line 101
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 102
    const/4 v0, 0x0

    iput v0, p0, Ltas/util/backlight/UBacklight;->COUNT:I

    .line 103
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Ltas/util/backlight/UBacklight;->BRIGHTNESS:Ljava/util/List;

    .line 101
    return-void
.end method

.method private addObserver(Landroid/content/Context;Ljava/lang/Object;Ljava/util/List;)V
    .locals 3
    .param p1, "c"    # Landroid/content/Context;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Landroid/content/Context;",
            "TT;",
            "Ljava/util/List",
            "<TT;>;)V"
        }
    .end annotation

    .prologue
    .line 108
    .local p2, "t":Ljava/lang/Object;, "TT;"
    .local p3, "l":Ljava/util/List;, "Ljava/util/List<TT;>;"
    const-class v1, Ltas/util/backlight/UBacklight;

    monitor-enter v1

    .line 109
    if-eqz p2, :cond_0

    :try_start_0
    invoke-interface {p3, p2}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2

    .line 113
    :cond_0
    :goto_0
    iget v0, p0, Ltas/util/backlight/UBacklight;->COUNT:I

    const/4 v2, 0x1

    if-ne v0, v2, :cond_1

    .line 114
    invoke-direct {p0, p1}, Ltas/util/backlight/UBacklight;->registerObserverLocked(Landroid/content/Context;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_1
    monitor-exit v1

    .line 107
    return-void

    .line 110
    :cond_2
    :try_start_1
    invoke-interface {p3, p2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 111
    iget v0, p0, Ltas/util/backlight/UBacklight;->COUNT:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Ltas/util/backlight/UBacklight;->COUNT:I
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_0

    .line 108
    :catchall_0
    move-exception v0

    monitor-exit v1

    throw v0
.end method

.method public static addObserver(Landroid/content/Context;Ltas/util/backlight/UBacklight$BrightnessObserver;)V
    .locals 2
    .param p0, "c"    # Landroid/content/Context;
    .param p1, "o"    # Ltas/util/backlight/UBacklight$BrightnessObserver;

    .prologue
    .line 42
    invoke-static {}, Ltas/util/backlight/UBacklight;->get()Ltas/util/backlight/UBacklight;

    move-result-object v0

    .local v0, "bl":Ltas/util/backlight/UBacklight;
    iget-object v1, v0, Ltas/util/backlight/UBacklight;->BRIGHTNESS:Ljava/util/List;

    invoke-direct {v0, p0, p1, v1}, Ltas/util/backlight/UBacklight;->addObserver(Landroid/content/Context;Ljava/lang/Object;Ljava/util/List;)V

    .line 41
    return-void
.end method

.method private static get()Ltas/util/backlight/UBacklight;
    .locals 2

    .prologue
    .line 95
    const-class v1, Ltas/util/backlight/UBacklight;

    monitor-enter v1

    .line 96
    :try_start_0
    sget-object v0, Ltas/util/backlight/UBacklight;->sSelf:Ltas/util/backlight/UBacklight;

    if-nez v0, :cond_0

    new-instance v0, Ltas/util/backlight/UBacklight;

    invoke-direct {v0}, Ltas/util/backlight/UBacklight;-><init>()V

    sput-object v0, Ltas/util/backlight/UBacklight;->sSelf:Ltas/util/backlight/UBacklight;

    .line 97
    :cond_0
    sget-object v0, Ltas/util/backlight/UBacklight;->sSelf:Ltas/util/backlight/UBacklight;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit v1

    return-object v0

    .line 95
    :catchall_0
    move-exception v0

    monitor-exit v1

    throw v0
.end method

.method public static getBrightness(Landroid/content/Context;)I
    .locals 1
    .param p0, "context"    # Landroid/content/Context;

    .prologue
    .line 64
    sget v0, Ltas/util/backlight/UBacklight;->MAX:I

    invoke-static {p0, v0}, Ltas/util/backlight/UBacklight;->getBrightness(Landroid/content/Context;I)I

    move-result v0

    return v0
.end method

.method public static getBrightness(Landroid/content/Context;I)I
    .locals 4
    .param p0, "context"    # Landroid/content/Context;
    .param p1, "dft"    # I

    .prologue
    .line 75
    :try_start_0
    invoke-virtual {p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v2

    .line 76
    const-string/jumbo v3, "screen_brightness"

    .line 75
    invoke-static {v2, v3}, Landroid/provider/Settings$System;->getInt(Landroid/content/ContentResolver;Ljava/lang/String;)I
    :try_end_0
    .catch Landroid/provider/Settings$SettingNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    move-result v0

    .line 82
    .local v0, "brightness":I
    :goto_0
    return v0

    .line 77
    .end local v0    # "brightness":I
    :catch_0
    move-exception v1

    .line 78
    .local v1, "e":Landroid/provider/Settings$SettingNotFoundException;
    invoke-virtual {v1}, Landroid/provider/Settings$SettingNotFoundException;->printStackTrace()V

    .line 79
    move v0, p1

    .restart local v0    # "brightness":I
    goto :goto_0
.end method

.method private registerObserverLocked(Landroid/content/Context;)V
    .locals 4
    .param p1, "c"    # Landroid/content/Context;

    .prologue
    const/4 v2, 0x0

    .line 133
    iget-object v1, p0, Ltas/util/backlight/UBacklight;->OBSERVER:Landroid/database/ContentObserver;

    if-nez v1, :cond_0

    .line 134
    new-instance v1, Ltas/util/backlight/UBacklight$1;

    invoke-direct {v1, p0, v2, p1}, Ltas/util/backlight/UBacklight$1;-><init>(Ltas/util/backlight/UBacklight;Landroid/os/Handler;Landroid/content/Context;)V

    iput-object v1, p0, Ltas/util/backlight/UBacklight;->OBSERVER:Landroid/database/ContentObserver;

    .line 148
    :cond_0
    const-string/jumbo v1, "screen_brightness"

    invoke-static {v1}, Landroid/provider/Settings$System;->getUriFor(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v0

    .line 149
    .local v0, "uri":Landroid/net/Uri;
    invoke-virtual {p1}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v1

    iget-object v2, p0, Ltas/util/backlight/UBacklight;->OBSERVER:Landroid/database/ContentObserver;

    const/4 v3, 0x1

    invoke-virtual {v1, v0, v3, v2}, Landroid/content/ContentResolver;->registerContentObserver(Landroid/net/Uri;ZLandroid/database/ContentObserver;)V

    .line 132
    return-void
.end method

.method private removeObserver(Landroid/content/Context;Ljava/lang/Object;Ljava/util/List;)V
    .locals 2
    .param p1, "c"    # Landroid/content/Context;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Landroid/content/Context;",
            "TT;",
            "Ljava/util/List",
            "<TT;>;)V"
        }
    .end annotation

    .prologue
    .line 121
    .local p2, "t":Ljava/lang/Object;, "TT;"
    .local p3, "l":Ljava/util/List;, "Ljava/util/List<TT;>;"
    const-class v1, Ltas/util/backlight/KBacklight;

    monitor-enter v1

    .line 122
    if-eqz p2, :cond_0

    :try_start_0
    invoke-interface {p3, p2}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 123
    invoke-interface {p3, p2}, Ljava/util/List;->remove(Ljava/lang/Object;)Z

    .line 124
    iget v0, p0, Ltas/util/backlight/UBacklight;->COUNT:I

    add-int/lit8 v0, v0, -0x1

    iput v0, p0, Ltas/util/backlight/UBacklight;->COUNT:I

    .line 126
    :cond_0
    iget v0, p0, Ltas/util/backlight/UBacklight;->COUNT:I

    if-nez v0, :cond_1

    .line 127
    invoke-direct {p0, p1}, Ltas/util/backlight/UBacklight;->unregisterObserverLocked(Landroid/content/Context;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_1
    monitor-exit v1

    .line 120
    return-void

    .line 121
    :catchall_0
    move-exception v0

    monitor-exit v1

    throw v0
.end method

.method public static removeObserver(Landroid/content/Context;Ltas/util/backlight/UBacklight$BrightnessObserver;)V
    .locals 2
    .param p0, "c"    # Landroid/content/Context;
    .param p1, "o"    # Ltas/util/backlight/UBacklight$BrightnessObserver;

    .prologue
    .line 47
    invoke-static {}, Ltas/util/backlight/UBacklight;->get()Ltas/util/backlight/UBacklight;

    move-result-object v0

    .local v0, "bl":Ltas/util/backlight/UBacklight;
    iget-object v1, v0, Ltas/util/backlight/UBacklight;->BRIGHTNESS:Ljava/util/List;

    invoke-direct {v0, p0, p1, v1}, Ltas/util/backlight/UBacklight;->removeObserver(Landroid/content/Context;Ljava/lang/Object;Ljava/util/List;)V

    .line 46
    return-void
.end method

.method public static setBrightness(Landroid/content/Context;I)Z
    .locals 2
    .param p0, "context"    # Landroid/content/Context;
    .param p1, "brightness"    # I

    .prologue
    .line 55
    invoke-virtual {p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v0

    .line 56
    const-string/jumbo v1, "screen_brightness"

    .line 55
    invoke-static {v0, v1, p1}, Landroid/provider/Settings$System;->putInt(Landroid/content/ContentResolver;Ljava/lang/String;I)Z

    move-result v0

    return v0
.end method

.method private unregisterObserverLocked(Landroid/content/Context;)V
    .locals 3
    .param p1, "c"    # Landroid/content/Context;

    .prologue
    const/4 v2, 0x0

    .line 153
    iget-object v0, p0, Ltas/util/backlight/UBacklight;->OBSERVER:Landroid/database/ContentObserver;

    if-eqz v0, :cond_0

    .line 154
    invoke-virtual {p1}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v0

    iget-object v1, p0, Ltas/util/backlight/UBacklight;->OBSERVER:Landroid/database/ContentObserver;

    invoke-virtual {v0, v1}, Landroid/content/ContentResolver;->unregisterContentObserver(Landroid/database/ContentObserver;)V

    .line 155
    iput-object v2, p0, Ltas/util/backlight/UBacklight;->OBSERVER:Landroid/database/ContentObserver;

    .line 152
    :cond_0
    return-void
.end method
