.class Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;
.super Ljava/lang/Object;
.source "INavi3DActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->InitMapButtons()Z
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;


# direct methods
.method constructor <init>(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)V
    .locals 0

    .prologue
    .line 14534
    iput-object p1, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 11

    .prologue
    const v9, 0x7f0a0498

    const v8, 0x7f0a0497

    const/16 v7, 0x8

    const/4 v6, 0x1

    const/4 v5, 0x0

    .line 14537
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    const v4, 0x7f0a05e6

    invoke-virtual {v2, v4}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Lcom/thinkware/sundo/inavi3d/ui/component/QuickMotionView;

    invoke-static {v3, v2}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$20402(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;Lcom/thinkware/sundo/inavi3d/ui/component/QuickMotionView;)Lcom/thinkware/sundo/inavi3d/ui/component/QuickMotionView;

    .line 14539
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    const v4, 0x7f0a05e7

    invoke-virtual {v2, v4}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Lcom/thinkware/sundo/inavi3d/ui/component/QuickMotionView;

    invoke-static {v3, v2}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$20502(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;Lcom/thinkware/sundo/inavi3d/ui/component/QuickMotionView;)Lcom/thinkware/sundo/inavi3d/ui/component/QuickMotionView;

    .line 14541
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    const v4, 0x7f0a05e8

    invoke-virtual {v2, v4}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Lcom/thinkware/sundo/inavi3d/ui/component/QuickMotionView;

    invoke-static {v3, v2}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$20602(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;Lcom/thinkware/sundo/inavi3d/ui/component/QuickMotionView;)Lcom/thinkware/sundo/inavi3d/ui/component/QuickMotionView;

    .line 14543
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    const v4, 0x7f0a05e9

    invoke-virtual {v2, v4}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Lcom/thinkware/sundo/inavi3d/ui/component/QuickMotionView;

    invoke-static {v3, v2}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$20702(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;Lcom/thinkware/sundo/inavi3d/ui/component/QuickMotionView;)Lcom/thinkware/sundo/inavi3d/ui/component/QuickMotionView;

    .line 14545
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    const v4, 0x7f0a05ea

    invoke-virtual {v2, v4}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Lcom/thinkware/sundo/inavi3d/ui/component/QuickMotionView;

    invoke-static {v3, v2}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$20802(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;Lcom/thinkware/sundo/inavi3d/ui/component/QuickMotionView;)Lcom/thinkware/sundo/inavi3d/ui/component/QuickMotionView;

    .line 14547
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    const v4, 0x7f0a05eb

    invoke-virtual {v2, v4}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Lcom/thinkware/sundo/inavi3d/ui/component/QuickMotionView;

    invoke-static {v3, v2}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$20902(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;Lcom/thinkware/sundo/inavi3d/ui/component/QuickMotionView;)Lcom/thinkware/sundo/inavi3d/ui/component/QuickMotionView;

    .line 14549
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    const v4, 0x7f0a05ec

    invoke-virtual {v2, v4}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Lcom/thinkware/sundo/inavi3d/ui/component/QuickMotionView;

    invoke-static {v3, v2}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$21002(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;Lcom/thinkware/sundo/inavi3d/ui/component/QuickMotionView;)Lcom/thinkware/sundo/inavi3d/ui/component/QuickMotionView;

    .line 14551
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    const v4, 0x7f0a05ed

    invoke-virtual {v2, v4}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Lcom/thinkware/sundo/inavi3d/ui/component/QuickMotionView;

    invoke-static {v3, v2}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$21102(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;Lcom/thinkware/sundo/inavi3d/ui/component/QuickMotionView;)Lcom/thinkware/sundo/inavi3d/ui/component/QuickMotionView;

    .line 14553
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    new-instance v3, Ljava/util/Vector;

    invoke-direct {v3}, Ljava/util/Vector;-><init>()V

    invoke-static {v2, v3}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$21202(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;Ljava/util/Vector;)Ljava/util/Vector;

    .line 14554
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    invoke-static {v2}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$21200(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)Ljava/util/Vector;

    move-result-object v2

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    invoke-static {v3}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$20400(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)Lcom/thinkware/sundo/inavi3d/ui/component/QuickMotionView;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/util/Vector;->add(Ljava/lang/Object;)Z

    .line 14555
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    invoke-static {v2}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$21200(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)Ljava/util/Vector;

    move-result-object v2

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    invoke-static {v3}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$20500(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)Lcom/thinkware/sundo/inavi3d/ui/component/QuickMotionView;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/util/Vector;->add(Ljava/lang/Object;)Z

    .line 14556
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    invoke-static {v2}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$21200(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)Ljava/util/Vector;

    move-result-object v2

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    invoke-static {v3}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$20600(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)Lcom/thinkware/sundo/inavi3d/ui/component/QuickMotionView;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/util/Vector;->add(Ljava/lang/Object;)Z

    .line 14557
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    invoke-static {v2}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$21200(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)Ljava/util/Vector;

    move-result-object v2

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    invoke-static {v3}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$20700(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)Lcom/thinkware/sundo/inavi3d/ui/component/QuickMotionView;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/util/Vector;->add(Ljava/lang/Object;)Z

    .line 14558
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    invoke-static {v2}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$21200(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)Ljava/util/Vector;

    move-result-object v2

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    invoke-static {v3}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$20800(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)Lcom/thinkware/sundo/inavi3d/ui/component/QuickMotionView;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/util/Vector;->add(Ljava/lang/Object;)Z

    .line 14559
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    invoke-static {v2}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$21200(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)Ljava/util/Vector;

    move-result-object v2

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    invoke-static {v3}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$20900(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)Lcom/thinkware/sundo/inavi3d/ui/component/QuickMotionView;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/util/Vector;->add(Ljava/lang/Object;)Z

    .line 14560
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    invoke-static {v2}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$21200(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)Ljava/util/Vector;

    move-result-object v2

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    invoke-static {v3}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$21000(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)Lcom/thinkware/sundo/inavi3d/ui/component/QuickMotionView;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/util/Vector;->add(Ljava/lang/Object;)Z

    .line 14561
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    invoke-static {v2}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$21200(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)Ljava/util/Vector;

    move-result-object v2

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    invoke-static {v3}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$21100(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)Lcom/thinkware/sundo/inavi3d/ui/component/QuickMotionView;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/util/Vector;->add(Ljava/lang/Object;)Z

    .line 14563
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    new-instance v3, Landroid/graphics/Point;

    invoke-direct {v3, v5, v5}, Landroid/graphics/Point;-><init>(II)V

    invoke-static {v2, v3}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$21302(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;Landroid/graphics/Point;)Landroid/graphics/Point;

    .line 14564
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v0

    .line 14565
    .local v0, "startTime":J
    const-string v2, "InitStatus"

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "Start : "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v0, v1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Lcom/thinkware/sundo/inavi3d/LOGTW;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 14566
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    const v4, 0x7f0a0493

    invoke-virtual {v3, v4}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->findViewById(I)Landroid/view/View;

    move-result-object v3

    iput-object v3, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar:Landroid/view/View;

    .line 14567
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar:Landroid/view/View;

    new-instance v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54$1;

    invoke-direct {v3, p0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54$1;-><init>(Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;)V

    invoke-virtual {v2, v3}, Landroid/view/View;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    .line 14574
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar:Landroid/view/View;

    const v4, 0x7f0a04a0

    invoke-virtual {v2, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/RelativeLayout;

    iput-object v2, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_weather_layout:Landroid/widget/RelativeLayout;

    .line 14575
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_weather_layout:Landroid/widget/RelativeLayout;

    invoke-virtual {v2, v6}, Landroid/widget/RelativeLayout;->setClickable(Z)V

    .line 14576
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar:Landroid/view/View;

    const v4, 0x7f0a04a2

    invoke-virtual {v3, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v3

    iput-object v3, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_weatherView:Landroid/view/View;

    .line 14577
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_weatherView:Landroid/view/View;

    new-instance v3, Ljava/lang/Integer;

    const/16 v4, 0x3e9

    invoke-direct {v3, v4}, Ljava/lang/Integer;-><init>(I)V

    invoke-virtual {v2, v3}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    .line 14578
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar:Landroid/view/View;

    const v4, 0x7f0a04a1

    invoke-virtual {v3, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v3

    iput-object v3, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_goalText:Landroid/view/View;

    .line 14579
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar:Landroid/view/View;

    const v4, 0x7f0a04a9

    invoke-virtual {v3, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v3

    iput-object v3, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_time1:Landroid/view/View;

    .line 14580
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar:Landroid/view/View;

    const v4, 0x7f0a04aa

    invoke-virtual {v3, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v3

    iput-object v3, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_time2:Landroid/view/View;

    .line 14581
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar:Landroid/view/View;

    const v4, 0x7f0a04ac

    invoke-virtual {v3, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v3

    iput-object v3, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_time3:Landroid/view/View;

    .line 14582
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar:Landroid/view/View;

    const v4, 0x7f0a04ad

    invoke-virtual {v3, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v3

    iput-object v3, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_time4:Landroid/view/View;

    .line 14583
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar:Landroid/view/View;

    const v4, 0x7f0a04a8

    invoke-virtual {v3, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v3

    iput-object v3, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_timeampm:Landroid/view/View;

    .line 14584
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar:Landroid/view/View;

    invoke-virtual {v2, v8}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/Button;

    iput-object v2, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Back:Landroid/widget/Button;

    .line 14585
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar:Landroid/view/View;

    const v4, 0x7f0a0499

    invoke-virtual {v2, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/Button;

    iput-object v2, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Current:Landroid/widget/Button;

    .line 14586
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar:Landroid/view/View;

    const v4, 0x7f0a049a

    invoke-virtual {v2, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/Button;

    iput-object v2, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Fuel:Landroid/widget/Button;

    .line 14587
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar:Landroid/view/View;

    const v4, 0x7f0a04b0

    invoke-virtual {v2, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/Button;

    iput-object v2, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Home:Landroid/widget/Button;

    .line 14588
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar:Landroid/view/View;

    invoke-virtual {v2, v9}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/Button;

    iput-object v2, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Voice:Landroid/widget/Button;

    .line 14589
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar:Landroid/view/View;

    const v4, 0x7f0a04af

    invoke-virtual {v2, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/Button;

    iput-object v2, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_NIP:Landroid/widget/Button;

    .line 14590
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar:Landroid/view/View;

    const v4, 0x7f0a049d

    invoke-virtual {v2, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/RelativeLayout;

    iput-object v2, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_layout_statusBar_DR:Landroid/widget/RelativeLayout;

    .line 14591
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar:Landroid/view/View;

    const v4, 0x7f0a049e

    invoke-virtual {v3, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v3

    iput-object v3, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_DR:Landroid/view/View;

    .line 14592
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_DR:Landroid/view/View;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->MapClickListener:Landroid/view/View$OnClickListener;

    invoke-virtual {v2, v3}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 14593
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar:Landroid/view/View;

    const v4, 0x7f0a04a5

    invoke-virtual {v2, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/Button;

    iput-object v2, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Wifi:Landroid/widget/Button;

    .line 14595
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar:Landroid/view/View;

    const v4, 0x7f0a04a4

    invoke-virtual {v3, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v3

    iput-object v3, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_View_StatusBar_UpdateMap:Landroid/view/View;

    .line 14596
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar:Landroid/view/View;

    const v4, 0x7f0a04a3

    invoke-virtual {v2, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/Button;

    iput-object v2, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_ScreenMirroring:Landroid/widget/Button;

    .line 14598
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v2

    invoke-virtual {v2}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetUseDRConfig()Z

    move-result v2

    if-ne v2, v6, :cond_0

    .line 14603
    :cond_0
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Back:Landroid/widget/Button;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->MapClickListener:Landroid/view/View$OnClickListener;

    invoke-virtual {v2, v3}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 14604
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Current:Landroid/widget/Button;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->MapClickListener:Landroid/view/View$OnClickListener;

    invoke-virtual {v2, v3}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 14606
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Current:Landroid/widget/Button;

    invoke-virtual {v2, v7}, Landroid/widget/Button;->setVisibility(I)V

    .line 14607
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Current:Landroid/widget/Button;

    invoke-virtual {v2, v5}, Landroid/widget/Button;->setEnabled(Z)V

    .line 14609
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Fuel:Landroid/widget/Button;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->MapClickListener:Landroid/view/View$OnClickListener;

    invoke-virtual {v2, v3}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 14610
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Fuel:Landroid/widget/Button;

    invoke-virtual {v2}, Landroid/widget/Button;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object v2

    invoke-virtual {v2}, Landroid/graphics/drawable/Drawable;->getCurrent()Landroid/graphics/drawable/Drawable;

    move-result-object v2

    check-cast v2, Landroid/graphics/drawable/AnimationDrawable;

    iput-object v2, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_aniFuel:Landroid/graphics/drawable/AnimationDrawable;

    .line 14612
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Home:Landroid/widget/Button;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->MapClickListener:Landroid/view/View$OnClickListener;

    invoke-virtual {v2, v3}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 14613
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Home:Landroid/widget/Button;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->MapLongClickListener:Landroid/view/View$OnLongClickListener;

    invoke-virtual {v2, v3}, Landroid/widget/Button;->setOnLongClickListener(Landroid/view/View$OnLongClickListener;)V

    .line 14615
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_NIP:Landroid/widget/Button;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->MapClickListener:Landroid/view/View$OnClickListener;

    invoke-virtual {v2, v3}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 14617
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar:Landroid/view/View;

    const v4, 0x7f0a0494

    invoke-virtual {v3, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v3

    iput-object v3, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_View_StatusBar_Dim:Landroid/view/View;

    .line 14621
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    const v4, 0x7f0a08c2

    invoke-virtual {v2, v4}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/ImageView;

    iput-object v2, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_MenuOnWaterMark_ar:Landroid/widget/ImageView;

    .line 14622
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    const v4, 0x7f0a08c3

    invoke-virtual {v2, v4}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/ImageView;

    iput-object v2, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_MenuOffWaterMark_ar:Landroid/widget/ImageView;

    .line 14623
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_MenuOnWaterMark_ar:Landroid/widget/ImageView;

    invoke-virtual {v2, v5}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 14624
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_MenuOffWaterMark_ar:Landroid/widget/ImageView;

    invoke-virtual {v2, v7}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 14626
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v2

    invoke-virtual {v2}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->isWideDisplay()Z

    move-result v2

    if-eqz v2, :cond_1

    .line 14627
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INaviScaleManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INaviScaleManager;

    move-result-object v2

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_MenuOnWaterMark_ar:Landroid/widget/ImageView;

    const/4 v4, 0x3

    invoke-virtual {v2, v3, v5, v4}, Lcom/thinkware/sundo/inavi3d/INaviScaleManager;->moveEmotion(Landroid/view/View;II)V

    .line 14628
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INaviScaleManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INaviScaleManager;

    move-result-object v2

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_MenuOffWaterMark_ar:Landroid/widget/ImageView;

    invoke-virtual {v2, v3, v5, v6}, Lcom/thinkware/sundo/inavi3d/INaviScaleManager;->moveEmotion(Landroid/view/View;II)V

    .line 14631
    :cond_1
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    const v4, 0x7f0a08d2

    invoke-virtual {v3, v4}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->findViewById(I)Landroid/view/View;

    move-result-object v3

    iput-object v3, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_ar:Landroid/view/View;

    .line 14632
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_ar:Landroid/view/View;

    new-instance v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54$2;

    invoke-direct {v3, p0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54$2;-><init>(Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;)V

    invoke-virtual {v2, v3}, Landroid/view/View;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    .line 14649
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_ar:Landroid/view/View;

    const v4, 0x7f0a04a7

    invoke-virtual {v3, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v3

    iput-object v3, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_time_bg_ar:Landroid/view/View;

    .line 14651
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_ar:Landroid/view/View;

    const v4, 0x7f0a04a9

    invoke-virtual {v3, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v3

    iput-object v3, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_time1_ar:Landroid/view/View;

    .line 14653
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_ar:Landroid/view/View;

    const v4, 0x7f0a04aa

    invoke-virtual {v3, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v3

    iput-object v3, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_time2_ar:Landroid/view/View;

    .line 14655
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_ar:Landroid/view/View;

    const v4, 0x7f0a04ac

    invoke-virtual {v3, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v3

    iput-object v3, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_time3_ar:Landroid/view/View;

    .line 14657
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_ar:Landroid/view/View;

    const v4, 0x7f0a04ad

    invoke-virtual {v3, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v3

    iput-object v3, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_time4_ar:Landroid/view/View;

    .line 14659
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_ar:Landroid/view/View;

    const v4, 0x7f0a04a8

    invoke-virtual {v3, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v3

    iput-object v3, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_timeampm_ar:Landroid/view/View;

    .line 14661
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_ar:Landroid/view/View;

    invoke-virtual {v2, v8}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/Button;

    iput-object v2, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Back_ar:Landroid/widget/Button;

    .line 14663
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_ar:Landroid/view/View;

    const v4, 0x7f0a0499

    invoke-virtual {v2, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/Button;

    iput-object v2, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Current_ar:Landroid/widget/Button;

    .line 14665
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_ar:Landroid/view/View;

    const v4, 0x7f0a049a

    invoke-virtual {v2, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/Button;

    iput-object v2, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Fuel_ar:Landroid/widget/Button;

    .line 14667
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_ar:Landroid/view/View;

    const v4, 0x7f0a04b0

    invoke-virtual {v2, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/Button;

    iput-object v2, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Home_ar:Landroid/widget/Button;

    .line 14669
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_ar:Landroid/view/View;

    invoke-virtual {v2, v9}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/Button;

    iput-object v2, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Voice_ar:Landroid/widget/Button;

    .line 14671
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_ar:Landroid/view/View;

    const v4, 0x7f0a04af

    invoke-virtual {v2, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/Button;

    iput-object v2, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_NIP_ar:Landroid/widget/Button;

    .line 14673
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_ar:Landroid/view/View;

    const v4, 0x7f0a049e

    invoke-virtual {v3, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v3

    iput-object v3, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_DR_ar:Landroid/view/View;

    .line 14675
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_ar:Landroid/view/View;

    const v4, 0x7f0a04a5

    invoke-virtual {v2, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/Button;

    iput-object v2, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Wifi_ar:Landroid/widget/Button;

    .line 14678
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_ar:Landroid/view/View;

    const v4, 0x7f0a04a4

    invoke-virtual {v3, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v3

    iput-object v3, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_View_StatusBar_UpdateMap_AR:Landroid/view/View;

    .line 14679
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_ar:Landroid/view/View;

    const v4, 0x7f0a04a3

    invoke-virtual {v2, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/Button;

    iput-object v2, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_ScreenMirroring_ar:Landroid/widget/Button;

    .line 14681
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v2

    invoke-virtual {v2}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetUseDRConfig()Z

    move-result v2

    if-ne v2, v6, :cond_2

    .line 14682
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_DR_ar:Landroid/view/View;

    invoke-virtual {v2, v5}, Landroid/view/View;->setVisibility(I)V

    .line 14685
    :cond_2
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Back_ar:Landroid/widget/Button;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->MapClickListener:Landroid/view/View$OnClickListener;

    invoke-virtual {v2, v3}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 14686
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Current_ar:Landroid/widget/Button;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->MapClickListener:Landroid/view/View$OnClickListener;

    invoke-virtual {v2, v3}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 14688
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Current_ar:Landroid/widget/Button;

    invoke-virtual {v2, v7}, Landroid/widget/Button;->setVisibility(I)V

    .line 14689
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Current_ar:Landroid/widget/Button;

    invoke-virtual {v2, v5}, Landroid/widget/Button;->setEnabled(Z)V

    .line 14691
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Fuel_ar:Landroid/widget/Button;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->MapClickListener:Landroid/view/View$OnClickListener;

    invoke-virtual {v2, v3}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 14692
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Fuel_ar:Landroid/widget/Button;

    invoke-virtual {v2}, Landroid/widget/Button;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object v2

    invoke-virtual {v2}, Landroid/graphics/drawable/Drawable;->getCurrent()Landroid/graphics/drawable/Drawable;

    move-result-object v2

    check-cast v2, Landroid/graphics/drawable/AnimationDrawable;

    iput-object v2, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_aniFuel_ar:Landroid/graphics/drawable/AnimationDrawable;

    .line 14694
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Home_ar:Landroid/widget/Button;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->MapClickListener:Landroid/view/View$OnClickListener;

    invoke-virtual {v2, v3}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 14695
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Home_ar:Landroid/widget/Button;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->MapLongClickListener:Landroid/view/View$OnLongClickListener;

    invoke-virtual {v2, v3}, Landroid/widget/Button;->setOnLongClickListener(Landroid/view/View$OnLongClickListener;)V

    .line 14706
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_NIP_ar:Landroid/widget/Button;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->MapClickListener:Landroid/view/View$OnClickListener;

    invoke-virtual {v2, v3}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 14707
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Voice_ar:Landroid/widget/Button;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->MapClickListener:Landroid/view/View$OnClickListener;

    invoke-virtual {v2, v3}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 14709
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_ar:Landroid/view/View;

    const v4, 0x7f0a0494

    invoke-virtual {v3, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v3

    iput-object v3, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_View_StatusBar_Dim_ar:Landroid/view/View;

    .line 14717
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    const v4, 0x7f0a0821

    invoke-virtual {v3, v4}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->findViewById(I)Landroid/view/View;

    move-result-object v3

    iput-object v3, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_off:Landroid/view/View;

    .line 14718
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_off:Landroid/view/View;

    new-instance v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54$3;

    invoke-direct {v3, p0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54$3;-><init>(Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;)V

    invoke-virtual {v2, v3}, Landroid/view/View;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    .line 14725
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_off:Landroid/view/View;

    const v4, 0x7f0a04a0

    invoke-virtual {v2, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/RelativeLayout;

    iput-object v2, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_weather_layout_off:Landroid/widget/RelativeLayout;

    .line 14726
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_weather_layout_off:Landroid/widget/RelativeLayout;

    invoke-virtual {v2, v6}, Landroid/widget/RelativeLayout;->setClickable(Z)V

    .line 14727
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_off:Landroid/view/View;

    const v4, 0x7f0a04a2

    invoke-virtual {v3, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v3

    iput-object v3, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_weatherView_off:Landroid/view/View;

    .line 14728
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_weatherView_off:Landroid/view/View;

    new-instance v3, Ljava/lang/Integer;

    const/16 v4, 0x3ea

    invoke-direct {v3, v4}, Ljava/lang/Integer;-><init>(I)V

    invoke-virtual {v2, v3}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    .line 14730
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_off:Landroid/view/View;

    const v4, 0x7f0a04a1

    invoke-virtual {v3, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v3

    iput-object v3, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_goalText_off:Landroid/view/View;

    .line 14731
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_off:Landroid/view/View;

    const v4, 0x7f0a04a9

    invoke-virtual {v3, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v3

    iput-object v3, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_time1_off:Landroid/view/View;

    .line 14732
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_off:Landroid/view/View;

    const v4, 0x7f0a04aa

    invoke-virtual {v3, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v3

    iput-object v3, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_time2_off:Landroid/view/View;

    .line 14733
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_off:Landroid/view/View;

    const v4, 0x7f0a04ac

    invoke-virtual {v3, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v3

    iput-object v3, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_time3_off:Landroid/view/View;

    .line 14734
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_off:Landroid/view/View;

    const v4, 0x7f0a04ad

    invoke-virtual {v3, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v3

    iput-object v3, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_time4_off:Landroid/view/View;

    .line 14735
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_off:Landroid/view/View;

    const v4, 0x7f0a04a8

    invoke-virtual {v3, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v3

    iput-object v3, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_timeampm_off:Landroid/view/View;

    .line 14736
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_off:Landroid/view/View;

    invoke-virtual {v2, v8}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/Button;

    iput-object v2, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Back_off:Landroid/widget/Button;

    .line 14737
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_off:Landroid/view/View;

    const v4, 0x7f0a0499

    invoke-virtual {v2, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/Button;

    iput-object v2, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Current_off:Landroid/widget/Button;

    .line 14738
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_off:Landroid/view/View;

    const v4, 0x7f0a049a

    invoke-virtual {v2, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/Button;

    iput-object v2, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Fuel_off:Landroid/widget/Button;

    .line 14739
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_off:Landroid/view/View;

    const v4, 0x7f0a04b0

    invoke-virtual {v2, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/Button;

    iput-object v2, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Home_off:Landroid/widget/Button;

    .line 14740
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_off:Landroid/view/View;

    invoke-virtual {v2, v9}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/Button;

    iput-object v2, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Voice_off:Landroid/widget/Button;

    .line 14741
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_off:Landroid/view/View;

    const v4, 0x7f0a04af

    invoke-virtual {v2, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/Button;

    iput-object v2, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_NIP_off:Landroid/widget/Button;

    .line 14742
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_off:Landroid/view/View;

    const v4, 0x7f0a049e

    invoke-virtual {v3, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v3

    iput-object v3, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_DR_off:Landroid/view/View;

    .line 14743
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_off:Landroid/view/View;

    const v4, 0x7f0a04a5

    invoke-virtual {v2, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/Button;

    iput-object v2, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Wifi_off:Landroid/widget/Button;

    .line 14745
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_off:Landroid/view/View;

    const v4, 0x7f0a04a4

    invoke-virtual {v3, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v3

    iput-object v3, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_View_StatusBar_UpdateMap_off:Landroid/view/View;

    .line 14746
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_off:Landroid/view/View;

    const v4, 0x7f0a04a3

    invoke-virtual {v2, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/Button;

    iput-object v2, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_ScreenMirroring_off:Landroid/widget/Button;

    .line 14749
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v2

    invoke-virtual {v2}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetUseDRConfig()Z

    move-result v2

    if-ne v2, v6, :cond_3

    .line 14750
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_DR_off:Landroid/view/View;

    invoke-virtual {v2, v5}, Landroid/view/View;->setVisibility(I)V

    .line 14753
    :cond_3
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Back_off:Landroid/widget/Button;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->MapClickListener:Landroid/view/View$OnClickListener;

    invoke-virtual {v2, v3}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 14754
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Current_off:Landroid/widget/Button;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->MapClickListener:Landroid/view/View$OnClickListener;

    invoke-virtual {v2, v3}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 14755
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Fuel_off:Landroid/widget/Button;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->MapClickListener:Landroid/view/View$OnClickListener;

    invoke-virtual {v2, v3}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 14756
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Fuel_off:Landroid/widget/Button;

    invoke-virtual {v2}, Landroid/widget/Button;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object v2

    invoke-virtual {v2}, Landroid/graphics/drawable/Drawable;->getCurrent()Landroid/graphics/drawable/Drawable;

    move-result-object v2

    check-cast v2, Landroid/graphics/drawable/AnimationDrawable;

    iput-object v2, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_aniFuel_off:Landroid/graphics/drawable/AnimationDrawable;

    .line 14757
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Home_off:Landroid/widget/Button;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->MapClickListener:Landroid/view/View$OnClickListener;

    invoke-virtual {v2, v3}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 14758
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Voice_off:Landroid/widget/Button;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->MapClickListener:Landroid/view/View$OnClickListener;

    invoke-virtual {v2, v3}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 14759
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_NIP_off:Landroid/widget/Button;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->MapClickListener:Landroid/view/View$OnClickListener;

    invoke-virtual {v2, v3}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 14761
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    const v4, 0x7f0a07f8

    invoke-virtual {v3, v4}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->findViewById(I)Landroid/view/View;

    move-result-object v3

    iput-object v3, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_routeresult:Landroid/view/View;

    .line 14762
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_routeresult:Landroid/view/View;

    new-instance v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54$4;

    invoke-direct {v3, p0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54$4;-><init>(Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;)V

    invoke-virtual {v2, v3}, Landroid/view/View;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    .line 14769
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_routeresult:Landroid/view/View;

    const v4, 0x7f0a04a0

    invoke-virtual {v2, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/RelativeLayout;

    iput-object v2, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_weather_layout_routeresult:Landroid/widget/RelativeLayout;

    .line 14770
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_weather_layout_routeresult:Landroid/widget/RelativeLayout;

    invoke-virtual {v2, v6}, Landroid/widget/RelativeLayout;->setClickable(Z)V

    .line 14771
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_routeresult:Landroid/view/View;

    const v4, 0x7f0a04a2

    invoke-virtual {v3, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v3

    iput-object v3, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_weatherView_routeresult:Landroid/view/View;

    .line 14772
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_weatherView_routeresult:Landroid/view/View;

    new-instance v3, Ljava/lang/Integer;

    const/16 v4, 0x3eb

    invoke-direct {v3, v4}, Ljava/lang/Integer;-><init>(I)V

    invoke-virtual {v2, v3}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    .line 14773
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_routeresult:Landroid/view/View;

    const v4, 0x7f0a04a1

    invoke-virtual {v3, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v3

    iput-object v3, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_goalText_routeresult:Landroid/view/View;

    .line 14774
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_routeresult:Landroid/view/View;

    const v4, 0x7f0a04a9

    invoke-virtual {v3, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v3

    iput-object v3, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_time1_routeresult:Landroid/view/View;

    .line 14775
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_routeresult:Landroid/view/View;

    const v4, 0x7f0a04aa

    invoke-virtual {v3, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v3

    iput-object v3, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_time2_routeresult:Landroid/view/View;

    .line 14776
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_routeresult:Landroid/view/View;

    const v4, 0x7f0a04ac

    invoke-virtual {v3, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v3

    iput-object v3, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_time3_routeresult:Landroid/view/View;

    .line 14777
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_routeresult:Landroid/view/View;

    const v4, 0x7f0a04ad

    invoke-virtual {v3, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v3

    iput-object v3, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_time4_routeresult:Landroid/view/View;

    .line 14778
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_routeresult:Landroid/view/View;

    const v4, 0x7f0a04a8

    invoke-virtual {v3, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v3

    iput-object v3, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_timeampm_routeresult:Landroid/view/View;

    .line 14779
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_routeresult:Landroid/view/View;

    invoke-virtual {v2, v8}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/Button;

    iput-object v2, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Back_routeresult:Landroid/widget/Button;

    .line 14780
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Back_routeresult:Landroid/widget/Button;

    const/4 v3, 0x0

    invoke-virtual {v2, v3}, Landroid/widget/Button;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 14782
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_routeresult:Landroid/view/View;

    const v4, 0x7f0a0499

    invoke-virtual {v2, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/Button;

    iput-object v2, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Current_routeresult:Landroid/widget/Button;

    .line 14783
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_routeresult:Landroid/view/View;

    const v4, 0x7f0a049a

    invoke-virtual {v2, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/Button;

    iput-object v2, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Fuel_routeresult:Landroid/widget/Button;

    .line 14784
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_routeresult:Landroid/view/View;

    const v4, 0x7f0a04b0

    invoke-virtual {v2, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/Button;

    iput-object v2, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Home_routeresult:Landroid/widget/Button;

    .line 14785
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_routeresult:Landroid/view/View;

    invoke-virtual {v2, v9}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/Button;

    iput-object v2, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Voice_routeresult:Landroid/widget/Button;

    .line 14786
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_routeresult:Landroid/view/View;

    const v4, 0x7f0a04af

    invoke-virtual {v2, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/Button;

    iput-object v2, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_NIP_routeresult:Landroid/widget/Button;

    .line 14787
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_routeresult:Landroid/view/View;

    const v4, 0x7f0a049e

    invoke-virtual {v3, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v3

    iput-object v3, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_DR_routeresult:Landroid/view/View;

    .line 14788
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_routeresult:Landroid/view/View;

    const v4, 0x7f0a04a5

    invoke-virtual {v2, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/Button;

    iput-object v2, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Wifi_routeresult:Landroid/widget/Button;

    .line 14790
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_routeresult:Landroid/view/View;

    const v4, 0x7f0a04a4

    invoke-virtual {v3, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v3

    iput-object v3, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_View_StatusBar_UpdateMap_routeresult:Landroid/view/View;

    .line 14791
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_routeresult:Landroid/view/View;

    const v4, 0x7f0a04a3

    invoke-virtual {v2, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/Button;

    iput-object v2, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_ScreenMirroring_routeresult:Landroid/widget/Button;

    .line 14793
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v2

    invoke-virtual {v2}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetUseDRConfig()Z

    move-result v2

    if-ne v2, v6, :cond_4

    .line 14794
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_DR_routeresult:Landroid/view/View;

    invoke-virtual {v2, v5}, Landroid/view/View;->setVisibility(I)V

    .line 14797
    :cond_4
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Back_routeresult:Landroid/widget/Button;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->MapClickListener:Landroid/view/View$OnClickListener;

    invoke-virtual {v2, v3}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 14798
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Current_routeresult:Landroid/widget/Button;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->MapClickListener:Landroid/view/View$OnClickListener;

    invoke-virtual {v2, v3}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 14799
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Fuel_routeresult:Landroid/widget/Button;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->MapClickListener:Landroid/view/View$OnClickListener;

    invoke-virtual {v2, v3}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 14800
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Fuel_routeresult:Landroid/widget/Button;

    invoke-virtual {v2}, Landroid/widget/Button;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object v2

    invoke-virtual {v2}, Landroid/graphics/drawable/Drawable;->getCurrent()Landroid/graphics/drawable/Drawable;

    move-result-object v2

    check-cast v2, Landroid/graphics/drawable/AnimationDrawable;

    iput-object v2, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_aniFuel_routeresult:Landroid/graphics/drawable/AnimationDrawable;

    .line 14801
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Home_routeresult:Landroid/widget/Button;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->MapClickListener:Landroid/view/View$OnClickListener;

    invoke-virtual {v2, v3}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 14802
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Voice_routeresult:Landroid/widget/Button;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->MapClickListener:Landroid/view/View$OnClickListener;

    invoke-virtual {v2, v3}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 14803
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_NIP_routeresult:Landroid/widget/Button;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->MapClickListener:Landroid/view/View$OnClickListener;

    invoke-virtual {v2, v3}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 14805
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    const v4, 0x7f0a07d8

    invoke-virtual {v3, v4}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->findViewById(I)Landroid/view/View;

    move-result-object v3

    iput-object v3, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_detour:Landroid/view/View;

    .line 14806
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_detour:Landroid/view/View;

    new-instance v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54$5;

    invoke-direct {v3, p0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54$5;-><init>(Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;)V

    invoke-virtual {v2, v3}, Landroid/view/View;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    .line 14813
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_detour:Landroid/view/View;

    const v4, 0x7f0a04a0

    invoke-virtual {v2, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/RelativeLayout;

    iput-object v2, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_weather_layout_detour:Landroid/widget/RelativeLayout;

    .line 14814
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_weather_layout_detour:Landroid/widget/RelativeLayout;

    invoke-virtual {v2, v6}, Landroid/widget/RelativeLayout;->setClickable(Z)V

    .line 14815
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_detour:Landroid/view/View;

    const v4, 0x7f0a04a2

    invoke-virtual {v3, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v3

    iput-object v3, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_weatherView_detour:Landroid/view/View;

    .line 14816
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_weatherView_detour:Landroid/view/View;

    new-instance v3, Ljava/lang/Integer;

    const/16 v4, 0x3ec

    invoke-direct {v3, v4}, Ljava/lang/Integer;-><init>(I)V

    invoke-virtual {v2, v3}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    .line 14817
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_detour:Landroid/view/View;

    const v4, 0x7f0a04a1

    invoke-virtual {v3, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v3

    iput-object v3, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_goalText_detour:Landroid/view/View;

    .line 14818
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_detour:Landroid/view/View;

    const v4, 0x7f0a04a9

    invoke-virtual {v3, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v3

    iput-object v3, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_time1_detour:Landroid/view/View;

    .line 14819
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_detour:Landroid/view/View;

    const v4, 0x7f0a04aa

    invoke-virtual {v3, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v3

    iput-object v3, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_time2_detour:Landroid/view/View;

    .line 14820
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_detour:Landroid/view/View;

    const v4, 0x7f0a04ac

    invoke-virtual {v3, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v3

    iput-object v3, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_time3_detour:Landroid/view/View;

    .line 14821
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_detour:Landroid/view/View;

    const v4, 0x7f0a04ad

    invoke-virtual {v3, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v3

    iput-object v3, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_time4_detour:Landroid/view/View;

    .line 14822
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_detour:Landroid/view/View;

    const v4, 0x7f0a04a8

    invoke-virtual {v3, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v3

    iput-object v3, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_timeampm_detour:Landroid/view/View;

    .line 14823
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_detour:Landroid/view/View;

    invoke-virtual {v2, v8}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/Button;

    iput-object v2, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Back_detour:Landroid/widget/Button;

    .line 14824
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Back_detour:Landroid/widget/Button;

    const/4 v3, 0x0

    invoke-virtual {v2, v3}, Landroid/widget/Button;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 14825
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_detour:Landroid/view/View;

    const v4, 0x7f0a0499

    invoke-virtual {v2, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/Button;

    iput-object v2, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Current_detour:Landroid/widget/Button;

    .line 14826
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_detour:Landroid/view/View;

    const v4, 0x7f0a049a

    invoke-virtual {v2, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/Button;

    iput-object v2, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Fuel_detour:Landroid/widget/Button;

    .line 14827
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_detour:Landroid/view/View;

    const v4, 0x7f0a04b0

    invoke-virtual {v2, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/Button;

    iput-object v2, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Home_detour:Landroid/widget/Button;

    .line 14828
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_detour:Landroid/view/View;

    invoke-virtual {v2, v9}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/Button;

    iput-object v2, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Voice_detour:Landroid/widget/Button;

    .line 14829
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_detour:Landroid/view/View;

    const v4, 0x7f0a04af

    invoke-virtual {v2, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/Button;

    iput-object v2, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_NIP_detour:Landroid/widget/Button;

    .line 14830
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_detour:Landroid/view/View;

    const v4, 0x7f0a049e

    invoke-virtual {v3, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v3

    iput-object v3, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_DR_detour:Landroid/view/View;

    .line 14831
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_detour:Landroid/view/View;

    const v4, 0x7f0a04a5

    invoke-virtual {v2, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/Button;

    iput-object v2, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Wifi_detour:Landroid/widget/Button;

    .line 14833
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_detour:Landroid/view/View;

    const v4, 0x7f0a04a4

    invoke-virtual {v3, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v3

    iput-object v3, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_View_StatusBar_UpdateMap_detour:Landroid/view/View;

    .line 14834
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_detour:Landroid/view/View;

    const v4, 0x7f0a04a3

    invoke-virtual {v2, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/Button;

    iput-object v2, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_ScreenMirroring_detour:Landroid/widget/Button;

    .line 14835
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v2

    invoke-virtual {v2}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetUseDRConfig()Z

    move-result v2

    if-ne v2, v6, :cond_5

    .line 14836
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_DR_detour:Landroid/view/View;

    invoke-virtual {v2, v5}, Landroid/view/View;->setVisibility(I)V

    .line 14839
    :cond_5
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Back_detour:Landroid/widget/Button;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->MapClickListener:Landroid/view/View$OnClickListener;

    invoke-virtual {v2, v3}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 14840
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Current_detour:Landroid/widget/Button;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->MapClickListener:Landroid/view/View$OnClickListener;

    invoke-virtual {v2, v3}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 14841
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Fuel_detour:Landroid/widget/Button;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->MapClickListener:Landroid/view/View$OnClickListener;

    invoke-virtual {v2, v3}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 14842
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Fuel_detour:Landroid/widget/Button;

    invoke-virtual {v2}, Landroid/widget/Button;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object v2

    invoke-virtual {v2}, Landroid/graphics/drawable/Drawable;->getCurrent()Landroid/graphics/drawable/Drawable;

    move-result-object v2

    check-cast v2, Landroid/graphics/drawable/AnimationDrawable;

    iput-object v2, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_aniFuel_detour:Landroid/graphics/drawable/AnimationDrawable;

    .line 14843
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Home_detour:Landroid/widget/Button;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->MapClickListener:Landroid/view/View$OnClickListener;

    invoke-virtual {v2, v3}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 14844
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Voice_detour:Landroid/widget/Button;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->MapClickListener:Landroid/view/View$OnClickListener;

    invoke-virtual {v2, v3}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 14845
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_NIP_detour:Landroid/widget/Button;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->MapClickListener:Landroid/view/View$OnClickListener;

    invoke-virtual {v2, v3}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 14847
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_goalText:Landroid/view/View;

    invoke-virtual {v2, v6}, Landroid/view/View;->setClickable(Z)V

    .line 14848
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_goalText_off:Landroid/view/View;

    invoke-virtual {v2, v6}, Landroid/view/View;->setClickable(Z)V

    .line 14849
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_goalText_routeresult:Landroid/view/View;

    invoke-virtual {v2, v6}, Landroid/view/View;->setClickable(Z)V

    .line 14850
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_goalText_detour:Landroid/view/View;

    invoke-virtual {v2, v6}, Landroid/view/View;->setClickable(Z)V

    .line 14851
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_weather_layout:Landroid/widget/RelativeLayout;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->MapClickListener:Landroid/view/View$OnClickListener;

    invoke-virtual {v2, v3}, Landroid/widget/RelativeLayout;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 14852
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_weather_layout_off:Landroid/widget/RelativeLayout;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->MapClickListener:Landroid/view/View$OnClickListener;

    invoke-virtual {v2, v3}, Landroid/widget/RelativeLayout;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 14853
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_weather_layout_routeresult:Landroid/widget/RelativeLayout;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->MapClickListener:Landroid/view/View$OnClickListener;

    invoke-virtual {v2, v3}, Landroid/widget/RelativeLayout;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 14854
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_weather_layout_detour:Landroid/widget/RelativeLayout;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->MapClickListener:Landroid/view/View$OnClickListener;

    invoke-virtual {v2, v3}, Landroid/widget/RelativeLayout;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 14855
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Voice:Landroid/widget/Button;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->MapClickListener:Landroid/view/View$OnClickListener;

    invoke-virtual {v2, v3}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 14863
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v2

    invoke-virtual {v2}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->supportAINA()Z

    move-result v2

    if-ne v2, v6, :cond_6

    .line 14864
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Voice:Landroid/widget/Button;

    invoke-virtual {v2, v5}, Landroid/widget/Button;->setVisibility(I)V

    .line 14865
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Voice_off:Landroid/widget/Button;

    invoke-virtual {v2, v5}, Landroid/widget/Button;->setVisibility(I)V

    .line 14866
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Voice_detour:Landroid/widget/Button;

    invoke-virtual {v2, v5}, Landroid/widget/Button;->setVisibility(I)V

    .line 14867
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Voice_routeresult:Landroid/widget/Button;

    invoke-virtual {v2, v5}, Landroid/widget/Button;->setVisibility(I)V

    .line 14868
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Voice_ar:Landroid/widget/Button;

    invoke-virtual {v2, v5}, Landroid/widget/Button;->setVisibility(I)V

    .line 14876
    :goto_0
    const-string v2, "InitStatus"

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "End : "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v4

    sub-long/2addr v4, v0

    invoke-virtual {v3, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Lcom/thinkware/sundo/inavi3d/LOGTW;->d(Ljava/lang/String;Ljava/lang/String;)V

    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    invoke-virtual {v10}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->UpdateInAppClock()V

    .line 14888
    return-void

    .line 14870
    :cond_6
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Voice:Landroid/widget/Button;

    invoke-virtual {v2, v7}, Landroid/widget/Button;->setVisibility(I)V

    .line 14871
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Voice_off:Landroid/widget/Button;

    invoke-virtual {v2, v7}, Landroid/widget/Button;->setVisibility(I)V

    .line 14872
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Voice_detour:Landroid/widget/Button;

    invoke-virtual {v2, v7}, Landroid/widget/Button;->setVisibility(I)V

    .line 14873
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Voice_routeresult:Landroid/widget/Button;

    invoke-virtual {v2, v7}, Landroid/widget/Button;->setVisibility(I)V

    .line 14874
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$54;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Voice_ar:Landroid/widget/Button;

    invoke-virtual {v2, v7}, Landroid/widget/Button;->setVisibility(I)V

    goto :goto_0
.end method
