.class Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;
.super Ljava/lang/Object;
.source "ServerManager.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltas/internal/ipc/server/ServerManager$ClientHandler;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "Holder"
.end annotation


# instance fields
.field private rh:Ltas/internal/ipc/server/ServerManager$ReceiverHolder;

.field private sh:Ltas/internal/ipc/server/ServerManager$SenderHolder;


# direct methods
.method static synthetic -get0(Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;)Ltas/internal/ipc/server/ServerManager$ReceiverHolder;
    .locals 1

    iget-object v0, p0, Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;->rh:Ltas/internal/ipc/server/ServerManager$ReceiverHolder;

    return-object v0
.end method

.method static synthetic -get1(Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;)Ltas/internal/ipc/server/ServerManager$SenderHolder;
    .locals 1

    iget-object v0, p0, Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;->sh:Ltas/internal/ipc/server/ServerManager$SenderHolder;

    return-object v0
.end method

.method private constructor <init>(Ltas/internal/ipc/server/ServerManager$SenderHolder;Ltas/internal/ipc/server/ServerManager$ReceiverHolder;)V
    .locals 0
    .param p1, "_s"    # Ltas/internal/ipc/server/ServerManager$SenderHolder;
    .param p2, "_r"    # Ltas/internal/ipc/server/ServerManager$ReceiverHolder;

    .prologue
    .line 189
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 190
    iput-object p1, p0, Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;->sh:Ltas/internal/ipc/server/ServerManager$SenderHolder;

    iput-object p2, p0, Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;->rh:Ltas/internal/ipc/server/ServerManager$ReceiverHolder;

    .line 189
    return-void
.end method

.method synthetic constructor <init>(Ltas/internal/ipc/server/ServerManager$SenderHolder;Ltas/internal/ipc/server/ServerManager$ReceiverHolder;Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;)V
    .locals 0
    .param p1, "_s"    # Ltas/internal/ipc/server/ServerManager$SenderHolder;
    .param p2, "_r"    # Ltas/internal/ipc/server/ServerManager$ReceiverHolder;

    .prologue
    invoke-direct {p0, p1, p2}, Ltas/internal/ipc/server/ServerManager$ClientHandler$Holder;-><init>(Ltas/internal/ipc/server/ServerManager$SenderHolder;Ltas/internal/ipc/server/ServerManager$ReceiverHolder;)V

    return-void
.end method
