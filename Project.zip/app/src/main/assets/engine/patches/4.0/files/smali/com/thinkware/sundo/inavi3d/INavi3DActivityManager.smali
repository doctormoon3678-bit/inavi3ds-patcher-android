.class public Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;
.super Ljava/lang/Object;
.source "INavi3DActivityManager.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$TempHoliDayInfo;,
        Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$HeapLogView;,
        Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$OBD2LogView;,
        Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$MISENLogView;,
        Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$InnerActivityInfo;
    }
.end annotation


# static fields
.field public static final AR_CAMEAR_STATUS_AR:I = 0x0

.field public static final AR_CAMEAR_STATUS_COMPACT_AR:I = 0x1

.field public static final AR_CAMEAR_STATUS_OFF:I = 0x2

.field public static final AUTO_AR_MODE_STATUS_CANCEL:I = 0x2

.field public static final AUTO_AR_MODE_STATUS_RUNNING:I = 0x1

.field public static final AUTO_AR_MODE_STATUS_STOP:I = 0x0

.field public static final EXTRA_NAME_SHOW_WAIT_CRUSOR:Ljava/lang/String; = "ShowWaitCursor"

.field public static final EXT_STATUS_GPS_INFO:I = 0x3eb

.field public static final EXT_STATUS_GPS_MODE:I = 0x3ea

.field public static final EXT_STATUS_OFF:I = 0x3e8

.field public static final EXT_STATUS_ON:I = 0x3f4

.field public static final EXT_STATUS_RECENT:I = 0x3ec

.field public static final EXT_STATUS_TRAFFIC_ACCIDENT:I = 0x3ef

.field public static final EXT_STATUS_TRAFFIC_CCTV:I = 0x3f2

.field public static final EXT_STATUS_TRAFFIC_CONFIG:I = 0x3ed

.field public static final EXT_STATUS_TRAFFIC_MAP:I = 0x3ee

.field public static final EXT_STATUS_TRAFFIC_OIL:I = 0x3f0

.field public static final EXT_STATUS_TRAFFIC_TCON_UPDATE:I = 0x3f3

.field public static final EXT_STATUS_UESRPOINT:I = 0x3f5

.field public static final EXT_STATUS_UNITED_SEARCH:I = 0x3e9

.field private static IntroView:Landroid/view/View; = null

.field public static final KEY_INNER_INTENT:Ljava/lang/String; = "InnerIntent"

.field public static final KEY_INNER_VIEW:Ljava/lang/String; = "InnerView"

.field public static final KEY_PUSH_ACTIVITY:Ljava/lang/String; = "pushActivity"

.field public static final MAIN_ACTIVITY_PACKAGE_NAME:Ljava/lang/String; = "com.thinkware.sundo.inavi3d"

.field public static final ROOT_ACTIVITY_STATUS_CURRENT_ON:I = 0x0

.field public static final ROOT_ACTIVITY_STATUS_DETOUR:I = 0x2

.field public static final ROOT_ACTIVITY_STATUS_END:I = 0x4

.field public static final ROOT_ACTIVITY_STATUS_ROUTE_RESULT:I = 0x1

.field public static final ROOT_ACTIVITY_STATUS_ROUTE_RESULT_FOR_EXT:I = 0x3

.field private static WaitCursorForAsync:Landroid/view/View;

.field private static WaitCursorForAsync1:Landroid/view/View;

.field private static mHeapLogView:Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$HeapLogView;

.field private static mInavi3DActivityManager:Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

.field private static mMISENLogView:Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$MISENLogView;

.field private static mOBD2LogView:Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$OBD2LogView;


# instance fields
.field private final BLOCKING_TIME:I

.field public autoArModeStatus:I

.field private bRunning:Z

.field public camear_nomal_100:I

.field public camear_nomal_300:I

.field public camear_nomal_500:I

.field private mARCameraOn:Z

.field private mARCameraStatus:I

.field private mActivityInfoArray:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList",
            "<",
            "Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$InnerActivityInfo;",
            ">;"
        }
    .end annotation
.end field

.field private mActivityManager:Landroid/app/ActivityManager;

.field private mAdasConnection:Landroid/content/ServiceConnection;

.field private mAdasService:Lcom/thinkware/sundo/inavi3dservice/AdasService;

.field private mAllwaysBarShown:Z

.field private mBSDStatusOn:Z

.field private mBWarningClosed:Z

.field private mBackActivity:Z

.field private mBarShown:Z

.field private mCounter:I

.field private mCurrentOn:Z

.field private mDestroyInnerActivityClassName:Ljava/lang/String;

.field private mEntireRouteMapLevel:I

.field private mEntireRouteViewMode:I

.field private mExtIntent:Landroid/content/Intent;

.field private mExtStart:Z

.field private mExtStatus:I

.field private mFirstCurrentOn:Z

.field private final mHandler:Landroid/os/Handler;

.field private mHeapLogShow:Z

.field private mInitFlag:Z

.field public mIsDoOk:Z

.field private mIsDoingCurrentOn:Z

.field private mIsHideBar:Z

.field private mIsMoveActivity:Z

.field private mIsMoveRootActivity:Z

.field private mIsShowAdas:Z

.field private mIsShowScreenMirroring:Z

.field mLastShowingPid:I

.field mLastShowingPidLive:I

.field private mLowMemory:Z

.field private mMISENDataShow:Z

.field private mMoveRootView:Z

.field private mMsgBlockingkTime:J

.field private mNameSearchMapLevel:I

.field private mNameSearchViewMode:I

.field public mNeedCheckMartWorking:Z

.field private mOBD2Connect:Z

.field private mOBD2LogShow:Z

.field mPOIHasWorkingDayInfo:Lcom/thinkware/sundo/inavi3d/ui/component/CustumDefine$GUISearchPointData;

.field mPOIHasWorkingDayInfoLive:Lcom/thinkware/sundo/inavi3d/livesearch/RSearchPOIResult;

.field private mPackageName:Ljava/lang/String;

.field private mRoadViewShow:Z

.field private mRootActivityClassName:Ljava/lang/String;

.field private mRootActivityStatus:I

.field private mRootContext:Landroid/content/Context;

.field private mRootLayout:Landroid/view/View;

.field private mRoutePointManageViewMode:I

.field mStartTime:J

.field private mTimer:Ljava/util/Timer;

.field private mTimerTask:Ljava/util/TimerTask;

.field private mViewMode:I

.field private m_bSuperCapPowerOff:Z

.field m_nCurrentSecond:I

.field private m_warterMark3D:Landroid/view/View;

.field private m_warterMarkAir:Landroid/view/View;

.field private mbAutoRunInaviByStting:Z

.field private mbEexcuteRenderInNameSrchActvity:Z

.field private mbEnabledTrafficMap:Z

.field private mbExtCurrentMap:Z

.field private mbExtForeGroundCallStatus:Z

.field private mbReadyForDPMap:Z

.field private mbValidateTimeLock:Z

.field public nDinamic:I

.field private statusbarBgColor:I


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .prologue
    const/4 v0, 0x0

    .line 173
    sput-object v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mInavi3DActivityManager:Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    .line 1415
    sput-object v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mMISENLogView:Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$MISENLogView;

    .line 1634
    sput-object v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mOBD2LogView:Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$OBD2LogView;

    .line 1864
    sput-object v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mHeapLogView:Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$HeapLogView;

    .line 1878
    sput-object v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->WaitCursorForAsync:Landroid/view/View;

    .line 1879
    sput-object v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->WaitCursorForAsync1:Landroid/view/View;

    .line 1880
    sput-object v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->IntroView:Landroid/view/View;

    return-void
.end method

.method private constructor <init>()V
    .locals 6

    .prologue
    const/4 v5, -0x1

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v2, 0x0

    .line 282
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 170
    iput v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootActivityStatus:I

    .line 171
    iput-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootActivityClassName:Ljava/lang/String;

    .line 175
    iput-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mActivityInfoArray:Ljava/util/ArrayList;

    .line 176
    iput-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mPackageName:Ljava/lang/String;

    .line 178
    iput-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mDestroyInnerActivityClassName:Ljava/lang/String;

    .line 180
    iput-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    .line 182
    iput-boolean v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mbValidateTimeLock:Z

    .line 185
    iput-boolean v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mbReadyForDPMap:Z

    .line 186
    iput-boolean v4, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mbEexcuteRenderInNameSrchActvity:Z

    .line 187
    iput-boolean v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mbAutoRunInaviByStting:Z

    .line 192
    iput-boolean v4, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mCurrentOn:Z

    .line 193
    iput-boolean v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mIsDoingCurrentOn:Z

    .line 194
    iput-boolean v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mFirstCurrentOn:Z

    .line 195
    iput-boolean v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mInitFlag:Z

    .line 196
    iput-boolean v4, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mBarShown:Z

    .line 198
    iput-boolean v4, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mIsHideBar:Z

    .line 199
    iput v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->statusbarBgColor:I

    .line 201
    iput-boolean v4, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mBWarningClosed:Z

    .line 204
    iput-boolean v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mBackActivity:Z

    .line 207
    iput-boolean v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mHeapLogShow:Z

    .line 211
    iput-boolean v4, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRoadViewShow:Z

    .line 214
    iput-boolean v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mAllwaysBarShown:Z

    .line 215
    iput-boolean v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mOBD2LogShow:Z

    .line 216
    iput-boolean v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mMISENDataShow:Z

    .line 217
    iput v5, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mNameSearchViewMode:I

    .line 218
    iput v5, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mEntireRouteViewMode:I

    .line 219
    iput v5, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRoutePointManageViewMode:I

    .line 220
    iput v5, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mViewMode:I

    .line 221
    iput v5, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mNameSearchMapLevel:I

    .line 222
    iput v5, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mEntireRouteMapLevel:I

    .line 225
    iput-boolean v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mMoveRootView:Z

    .line 227
    iput-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mExtIntent:Landroid/content/Intent;

    .line 229
    iput-boolean v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mExtStart:Z

    .line 230
    iput-boolean v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mbExtCurrentMap:Z

    .line 232
    const/16 v0, 0x3e8

    iput v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mExtStatus:I

    .line 233
    iput-boolean v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mbExtForeGroundCallStatus:Z

    .line 234
    iput-boolean v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mIsMoveRootActivity:Z

    .line 235
    iput-boolean v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mIsMoveActivity:Z

    .line 239
    iput-boolean v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mLowMemory:Z

    .line 241
    iput-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->m_warterMark3D:Landroid/view/View;

    .line 242
    iput-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->m_warterMarkAir:Landroid/view/View;

    .line 250
    iput-boolean v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mIsShowScreenMirroring:Z

    .line 253
    iput-boolean v4, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mARCameraOn:Z

    .line 255
    iput v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mARCameraStatus:I

    .line 257
    iput-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootLayout:Landroid/view/View;

    .line 261
    iput-boolean v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mBSDStatusOn:Z

    .line 266
    iput-boolean v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->m_bSuperCapPowerOff:Z

    .line 270
    iput-boolean v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mIsDoOk:Z

    .line 310
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    iput-wide v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mStartTime:J

    .line 1438
    iput-boolean v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mOBD2Connect:Z

    .line 3114
    const-wide/16 v0, 0x0

    iput-wide v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mMsgBlockingkTime:J

    .line 3115
    const/16 v0, 0xa

    iput v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->BLOCKING_TIME:I

    .line 4009
    iput-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mTimerTask:Ljava/util/TimerTask;

    .line 4010
    new-instance v0, Landroid/os/Handler;

    invoke-direct {v0}, Landroid/os/Handler;-><init>()V

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mHandler:Landroid/os/Handler;

    .line 4011
    new-instance v0, Ljava/util/Timer;

    invoke-direct {v0}, Ljava/util/Timer;-><init>()V

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mTimer:Ljava/util/Timer;

    .line 4013
    iput v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mCounter:I

    .line 4014
    iput-boolean v4, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->bRunning:Z

    .line 4649
    iput v5, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->autoArModeStatus:I

    .line 4650
    iput v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->camear_nomal_500:I

    .line 4651
    iput v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->camear_nomal_300:I

    .line 4652
    iput v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->camear_nomal_100:I

    .line 4653
    iput v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->nDinamic:I

    .line 4818
    iput v5, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->m_nCurrentSecond:I

    .line 5043
    iput-boolean v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mNeedCheckMartWorking:Z

    .line 5044
    iput-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mPOIHasWorkingDayInfo:Lcom/thinkware/sundo/inavi3d/ui/component/CustumDefine$GUISearchPointData;

    .line 5045
    iput-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mPOIHasWorkingDayInfoLive:Lcom/thinkware/sundo/inavi3d/livesearch/RSearchPOIResult;

    .line 5046
    iput v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mLastShowingPid:I

    .line 5047
    iput v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mLastShowingPidLive:I

    .line 5201
    iput-boolean v4, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mIsShowAdas:Z

    .line 5212
    iput-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mAdasService:Lcom/thinkware/sundo/inavi3dservice/AdasService;

    .line 5213
    new-instance v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$13;

    invoke-direct {v0, p0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$13;-><init>(Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;)V

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mAdasConnection:Landroid/content/ServiceConnection;

    .line 283
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mActivityInfoArray:Ljava/util/ArrayList;

    .line 284
    iput v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootActivityStatus:I

    .line 286
    return-void
.end method

.method static synthetic access$100(Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;)Z
    .locals 1
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    .prologue
    .line 115
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mOBD2Connect:Z

    return v0
.end method

.method static synthetic access$1000(Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;)Z
    .locals 1
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    .prologue
    .line 115
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mCurrentOn:Z

    return v0
.end method

.method static synthetic access$1100(Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;)Z
    .locals 1
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    .prologue
    .line 115
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mMoveRootView:Z

    return v0
.end method

.method static synthetic access$1102(Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;Z)Z
    .locals 0
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;
    .param p1, "x1"    # Z

    .prologue
    .line 115
    iput-boolean p1, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mMoveRootView:Z

    return p1
.end method

.method static synthetic access$1200(Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;)V
    .locals 0
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    .prologue
    .line 115
    invoke-direct {p0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->moveToRootActivityFromExt()V

    return-void
.end method

.method static synthetic access$1302(Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;Landroid/content/Intent;)Landroid/content/Intent;
    .locals 0
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;
    .param p1, "x1"    # Landroid/content/Intent;

    .prologue
    .line 115
    iput-object p1, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mExtIntent:Landroid/content/Intent;

    return-object p1
.end method

.method static synthetic access$1400(Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;)Z
    .locals 1
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    .prologue
    .line 115
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mFirstCurrentOn:Z

    return v0
.end method

.method static synthetic access$1500(Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;Landroid/content/Intent;)V
    .locals 0
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;
    .param p1, "x1"    # Landroid/content/Intent;

    .prologue
    .line 115
    invoke-direct {p0, p1}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->onAINAProcessForTAURUS(Landroid/content/Intent;)V

    return-void
.end method

.method static synthetic access$1600(Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;Landroid/content/Intent;)V
    .locals 0
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;
    .param p1, "x1"    # Landroid/content/Intent;

    .prologue
    .line 115
    invoke-direct {p0, p1}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->onAINAProcessForDefault(Landroid/content/Intent;)V

    return-void
.end method

.method static synthetic access$1700(Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;Landroid/content/Intent;Landroid/content/Context;)V
    .locals 0
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;
    .param p1, "x1"    # Landroid/content/Intent;
    .param p2, "x2"    # Landroid/content/Context;

    .prologue
    .line 115
    invoke-direct {p0, p1, p2}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->setExtSolutionRunroute(Landroid/content/Intent;Landroid/content/Context;)V

    return-void
.end method

.method static synthetic access$1800(Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;Landroid/content/Intent;Landroid/content/Context;)V
    .locals 0
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;
    .param p1, "x1"    # Landroid/content/Intent;
    .param p2, "x2"    # Landroid/content/Context;

    .prologue
    .line 115
    invoke-direct {p0, p1, p2}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->setExtSolutionRunroutepassui(Landroid/content/Intent;Landroid/content/Context;)V

    return-void
.end method

.method static synthetic access$1900(Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;Landroid/content/Intent;Landroid/content/Context;)V
    .locals 0
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;
    .param p1, "x1"    # Landroid/content/Intent;
    .param p2, "x2"    # Landroid/content/Context;

    .prologue
    .line 115
    invoke-direct {p0, p1, p2}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->setExtSolutionRunroutenow(Landroid/content/Intent;Landroid/content/Context;)V

    return-void
.end method

.method static synthetic access$200(Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;)Landroid/content/Context;
    .locals 1
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    .prologue
    .line 115
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    return-object v0
.end method

.method static synthetic access$2002(Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;Z)Z
    .locals 0
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;
    .param p1, "x1"    # Z

    .prologue
    .line 115
    iput-boolean p1, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mbExtCurrentMap:Z

    return p1
.end method

.method static synthetic access$2102(Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;Z)Z
    .locals 0
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;
    .param p1, "x1"    # Z

    .prologue
    .line 115
    iput-boolean p1, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mExtStart:Z

    return p1
.end method

.method static synthetic access$2200(Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;)Z
    .locals 1
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    .prologue
    .line 115
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->bRunning:Z

    return v0
.end method

.method static synthetic access$2300(Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;)I
    .locals 1
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    .prologue
    .line 115
    iget v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mCounter:I

    return v0
.end method

.method static synthetic access$2308(Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;)I
    .locals 2
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    .prologue
    .line 115
    iget v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mCounter:I

    add-int/lit8 v1, v0, 0x1

    iput v1, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mCounter:I

    return v0
.end method

.method static synthetic access$2402(Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;Lcom/thinkware/sundo/inavi3dservice/AdasService;)Lcom/thinkware/sundo/inavi3dservice/AdasService;
    .locals 0
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;
    .param p1, "x1"    # Lcom/thinkware/sundo/inavi3dservice/AdasService;

    .prologue
    .line 115
    iput-object p1, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mAdasService:Lcom/thinkware/sundo/inavi3dservice/AdasService;

    return-object p1
.end method

.method static synthetic access$600(Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;)Z
    .locals 1
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    .prologue
    .line 115
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mBarShown:Z

    return v0
.end method

.method static synthetic access$700(Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;)Z
    .locals 1
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    .prologue
    .line 115
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mAllwaysBarShown:Z

    return v0
.end method

.method static synthetic access$800(Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;)I
    .locals 1
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    .prologue
    .line 115
    iget v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->statusbarBgColor:I

    return v0
.end method

.method static synthetic access$802(Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;I)I
    .locals 0
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;
    .param p1, "x1"    # I

    .prologue
    .line 115
    iput p1, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->statusbarBgColor:I

    return p1
.end method

.method static synthetic access$900(Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;)Landroid/os/Handler;
    .locals 1
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    .prologue
    .line 115
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mHandler:Landroid/os/Handler;

    return-object v0
.end method

.method private checkAutoRunInaviWithRouteinfo(Landroid/content/Context;)Z
    .locals 9
    .param p1, "context"    # Landroid/content/Context;

    .prologue
    const/4 v5, 0x0

    const/4 v4, 0x1

    .line 3735
    const/4 v1, 0x0

    .line 3736
    .local v1, "nChecked":I
    invoke-virtual {p1}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v6

    const-string v7, "settings_inavi_auto_excute"

    invoke-static {v6, v7, v4}, Landroid/provider/Settings$System;->getInt(Landroid/content/ContentResolver;Ljava/lang/String;I)I

    move-result v1

    .line 3737
    const-string v6, "inavi3d_wooks_routetbl"

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const-string v8, "nChecked :: "

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-static {v6, v7}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 3738
    if-ne v1, v4, :cond_1

    .line 3739
    const-string v6, "inavi3d_wooks_routetbl"

    const-string v7, "routetbl.bin"

    invoke-static {v6, v7}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 3740
    const-string v3, ""

    .line 3742
    .local v3, "strStorageDir":Ljava/lang/String;
    sget-object v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->SD_EXT_STORAGE_PATH:Ljava/lang/String;

    .line 3743
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, "/inavi3d/iNaviData/routetbl.bin"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    .line 3745
    const-string v6, "inavi3d_wooks_routetbl"

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const-string v8, "routetbl.bin :: path :: "

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-static {v6, v7}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 3747
    new-instance v0, Ljava/io/File;

    invoke-direct {v0, v3}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 3749
    .local v0, "fileCheck":Ljava/io/File;
    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v6

    if-ne v6, v4, :cond_1

    .line 3750
    const-string v6, "inavi3d_wooks_routetbl"

    const-string v7, "routetbl.bin :: exists :: true"

    invoke-static {v6, v7}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 3752
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    sget-object v7, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->SD_EXT_STORAGE_PATH:Ljava/lang/String;

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, "/inavi3d/iNaviData"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    .line 3753
    .local v2, "routeFileDir":Ljava/lang/String;
    invoke-virtual {p0, v2}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->existRouteFile(Ljava/lang/String;)Z

    move-result v6

    if-ne v6, v4, :cond_0

    .line 3761
    .end local v0    # "fileCheck":Ljava/io/File;
    .end local v2    # "routeFileDir":Ljava/lang/String;
    .end local v3    # "strStorageDir":Ljava/lang/String;
    :goto_0
    return v4

    .line 3756
    .restart local v0    # "fileCheck":Ljava/io/File;
    .restart local v2    # "routeFileDir":Ljava/lang/String;
    .restart local v3    # "strStorageDir":Ljava/lang/String;
    :cond_0
    invoke-virtual {v0}, Ljava/io/File;->delete()Z

    move v4, v5

    .line 3757
    goto :goto_0

    .end local v0    # "fileCheck":Ljava/io/File;
    .end local v2    # "routeFileDir":Ljava/lang/String;
    .end local v3    # "strStorageDir":Ljava/lang/String;
    :cond_1
    move v4, v5

    .line 3761
    goto :goto_0
.end method

.method public static checkForeground(Ljava/lang/String;Landroid/content/Context;)Z
    .locals 9
    .param p0, "strPackageName"    # Ljava/lang/String;
    .param p1, "context"    # Landroid/content/Context;

    .prologue
    const/4 v5, 0x1

    const/4 v4, 0x0

    .line 3608
    if-nez p1, :cond_1

    .line 3610
    const-string v5, "inavi3d_java"

    const-string v6, "checkForeground mRootContext is Null"

    invoke-static {v5, v6}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 3640
    :cond_0
    :goto_0
    return v4

    .line 3614
    :cond_1
    sget v6, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v7, 0xb

    if-lt v6, v7, :cond_0

    .line 3616
    const-string v6, "activity"

    invoke-virtual {p1, v6}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/app/ActivityManager;

    .line 3617
    .local v0, "activityManager":Landroid/app/ActivityManager;
    const v6, 0x7fffffff

    const/4 v7, 0x2

    invoke-virtual {v0, v6, v7}, Landroid/app/ActivityManager;->getRecentTasks(II)Ljava/util/List;

    move-result-object v3

    .line 3619
    .local v3, "recentTasks":Ljava/util/List;, "Ljava/util/List<Landroid/app/ActivityManager$RecentTaskInfo;>;"
    const/4 v2, 0x0

    .line 3621
    .local v2, "recentTaskInfo":Landroid/app/ActivityManager$RecentTaskInfo;
    if-nez v3, :cond_2

    invoke-interface {v3}, Ljava/util/List;->size()I

    move-result v6

    if-gtz v6, :cond_2

    .line 3622
    const-string v5, "inavi3d_java"

    const-string v6, "checkForeground recentTasks == null"

    invoke-static {v5, v6}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_0

    .line 3626
    :cond_2
    invoke-interface {v3, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    .end local v2    # "recentTaskInfo":Landroid/app/ActivityManager$RecentTaskInfo;
    check-cast v2, Landroid/app/ActivityManager$RecentTaskInfo;

    .line 3628
    .restart local v2    # "recentTaskInfo":Landroid/app/ActivityManager$RecentTaskInfo;
    if-eqz v2, :cond_0

    iget v6, v2, Landroid/app/ActivityManager$RecentTaskInfo;->id:I

    const/4 v7, -0x1

    if-le v6, v7, :cond_0

    .line 3629
    iget-object v6, v2, Landroid/app/ActivityManager$RecentTaskInfo;->baseIntent:Landroid/content/Intent;

    if-eqz v6, :cond_0

    .line 3630
    iget-object v6, v2, Landroid/app/ActivityManager$RecentTaskInfo;->baseIntent:Landroid/content/Intent;

    invoke-virtual {v6}, Landroid/content/Intent;->getComponent()Landroid/content/ComponentName;

    move-result-object v6

    invoke-virtual {v6}, Landroid/content/ComponentName;->getPackageName()Ljava/lang/String;

    move-result-object v1

    .line 3632
    .local v1, "packageName":Ljava/lang/String;
    const-string v6, "tag_ar"

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const-string v8, "packageName"

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-static {v6, v7}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 3634
    invoke-static {v1}, Lcom/thinkware/sundo/inavi3d/StringHelper;->isValidString(Ljava/lang/String;)Z

    move-result v6

    if-ne v6, v5, :cond_0

    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-ne v6, v5, :cond_0

    move v4, v5

    .line 3635
    goto :goto_0
.end method

.method public static checkForegroundInavi(Landroid/content/Context;)Z
    .locals 14
    .param p0, "context"    # Landroid/content/Context;

    .prologue
    .line 3502
    const-string v10, "com.thinkware.inavi3ds"

    .line 3504
    .local v10, "strPackageName":Ljava/lang/String;
    if-nez p0, :cond_0

    .line 3506
    const-string v11, "inavi3d_java"

    const-string v12, "checkForeground mRootContext is Null"

    invoke-static {v11, v12}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 3507
    const/4 v11, 0x0

    .line 3579
    :goto_0
    return v11

    .line 3510
    :cond_0
    const-string v11, "activity"

    invoke-virtual {p0, v11}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/app/ActivityManager;

    .line 3512
    .local v1, "activityManager":Landroid/app/ActivityManager;
    sget v11, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v12, 0x15

    if-lt v11, v12, :cond_2

    .line 3513
    const/4 v0, 0x2

    .line 3516
    .local v0, "PROCESS_STATE_TOP":I
    :try_start_0
    const-class v11, Landroid/app/ActivityManager$RunningAppProcessInfo;

    const-string v12, "processState"

    invoke-virtual {v11, v12}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v6

    .line 3518
    .local v6, "processStateField":Ljava/lang/reflect/Field;
    invoke-virtual {v1}, Landroid/app/ActivityManager;->getRunningAppProcesses()Ljava/util/List;

    move-result-object v7

    .line 3519
    .local v7, "processes":Ljava/util/List;, "Ljava/util/List<Landroid/app/ActivityManager$RunningAppProcessInfo;>;"
    invoke-interface {v7}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v3

    .local v3, "i$":Ljava/util/Iterator;
    :cond_1
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v11

    if-eqz v11, :cond_4

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Landroid/app/ActivityManager$RunningAppProcessInfo;

    .line 3520
    .local v5, "process":Landroid/app/ActivityManager$RunningAppProcessInfo;
    iget v11, v5, Landroid/app/ActivityManager$RunningAppProcessInfo;->importance:I

    const/16 v12, 0x64

    if-gt v11, v12, :cond_1

    iget v11, v5, Landroid/app/ActivityManager$RunningAppProcessInfo;->importanceReasonCode:I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    if-nez v11, :cond_1

    .line 3534
    const/4 v11, 0x1

    goto :goto_0

    .line 3549
    .end local v3    # "i$":Ljava/util/Iterator;
    .end local v5    # "process":Landroid/app/ActivityManager$RunningAppProcessInfo;
    .end local v6    # "processStateField":Ljava/lang/reflect/Field;
    .end local v7    # "processes":Ljava/util/List;, "Ljava/util/List<Landroid/app/ActivityManager$RunningAppProcessInfo;>;"
    :catch_0
    move-exception v2

    .line 3550
    .local v2, "e":Ljava/lang/Exception;
    invoke-virtual {v2}, Ljava/lang/Exception;->printStackTrace()V

    .line 3551
    const/4 v11, 0x0

    goto :goto_0

    .line 3553
    .end local v0    # "PROCESS_STATE_TOP":I
    .end local v2    # "e":Ljava/lang/Exception;
    :cond_2
    sget v11, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v12, 0xb

    if-lt v11, v12, :cond_4

    .line 3555
    const v11, 0x7fffffff

    const/4 v12, 0x2

    invoke-virtual {v1, v11, v12}, Landroid/app/ActivityManager;->getRecentTasks(II)Ljava/util/List;

    move-result-object v9

    .line 3557
    .local v9, "recentTasks":Ljava/util/List;, "Ljava/util/List<Landroid/app/ActivityManager$RecentTaskInfo;>;"
    const/4 v8, 0x0

    .line 3559
    .local v8, "recentTaskInfo":Landroid/app/ActivityManager$RecentTaskInfo;
    if-nez v9, :cond_3

    invoke-interface {v9}, Ljava/util/List;->size()I

    move-result v11

    if-gtz v11, :cond_3

    .line 3560
    const-string v11, "inavi3d_java"

    const-string v12, "checkForeground recentTasks == null"

    invoke-static {v11, v12}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 3561
    const/4 v11, 0x0

    goto :goto_0

    .line 3564
    :cond_3
    const/4 v11, 0x0

    invoke-interface {v9, v11}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v8

    .end local v8    # "recentTaskInfo":Landroid/app/ActivityManager$RecentTaskInfo;
    check-cast v8, Landroid/app/ActivityManager$RecentTaskInfo;

    .line 3566
    .restart local v8    # "recentTaskInfo":Landroid/app/ActivityManager$RecentTaskInfo;
    if-eqz v8, :cond_4

    iget v11, v8, Landroid/app/ActivityManager$RecentTaskInfo;->id:I

    const/4 v12, -0x1

    if-le v11, v12, :cond_4

    .line 3567
    iget-object v11, v8, Landroid/app/ActivityManager$RecentTaskInfo;->baseIntent:Landroid/content/Intent;

    if-eqz v11, :cond_4

    .line 3568
    iget-object v11, v8, Landroid/app/ActivityManager$RecentTaskInfo;->baseIntent:Landroid/content/Intent;

    invoke-virtual {v11}, Landroid/content/Intent;->getComponent()Landroid/content/ComponentName;

    move-result-object v11

    invoke-virtual {v11}, Landroid/content/ComponentName;->getPackageName()Ljava/lang/String;

    move-result-object v4

    .line 3570
    .local v4, "packageName":Ljava/lang/String;
    const-string v11, "tag_ar"

    new-instance v12, Ljava/lang/StringBuilder;

    invoke-direct {v12}, Ljava/lang/StringBuilder;-><init>()V

    const-string v13, "packageName"

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    invoke-virtual {v12, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    invoke-virtual {v12}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v12

    invoke-static {v11, v12}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 3572
    invoke-static {v4}, Lcom/thinkware/sundo/inavi3d/StringHelper;->isValidString(Ljava/lang/String;)Z

    move-result v11

    const/4 v12, 0x1

    if-ne v11, v12, :cond_4

    invoke-virtual {v4, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v11

    const/4 v12, 0x1

    if-ne v11, v12, :cond_4

    .line 3573
    const/4 v11, 0x1

    goto/16 :goto_0

    .line 3579
    .end local v4    # "packageName":Ljava/lang/String;
    .end local v8    # "recentTaskInfo":Landroid/app/ActivityManager$RecentTaskInfo;
    .end local v9    # "recentTasks":Ljava/util/List;, "Ljava/util/List<Landroid/app/ActivityManager$RecentTaskInfo;>;"
    :cond_4
    const/4 v11, 0x0

    goto/16 :goto_0
.end method

.method public static getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;
    .locals 2

    .prologue
    .line 294
    sget-object v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mInavi3DActivityManager:Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    if-nez v0, :cond_1

    .line 295
    const-class v1, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    monitor-enter v1

    .line 296
    :try_start_0
    sget-object v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mInavi3DActivityManager:Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    if-nez v0, :cond_0

    .line 297
    new-instance v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    invoke-direct {v0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;-><init>()V

    sput-object v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mInavi3DActivityManager:Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    .line 299
    :cond_0
    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 301
    :cond_1
    sget-object v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mInavi3DActivityManager:Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    return-object v0

    .line 299
    :catchall_0
    move-exception v0

    :try_start_1
    monitor-exit v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw v0
.end method

.method private getTopINavi3DActivityIndex()I
    .locals 4

    .prologue
    .line 1079
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getActivityCount()I

    move-result v0

    .line 1080
    .local v0, "listCount":I
    if-lez v0, :cond_0

    .line 1081
    add-int/lit8 v2, v0, -0x1

    invoke-virtual {p0, v2}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getActivityName(I)Ljava/lang/String;

    move-result-object v1

    .line 1082
    .local v1, "tempClassName":Ljava/lang/String;
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getMainClassName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v3, 0x1

    if-ne v2, v3, :cond_0

    .line 1083
    add-int/lit8 v2, v0, -0x1

    .line 1092
    .end local v1    # "tempClassName":Ljava/lang/String;
    :goto_0
    return v2

    :cond_0
    const/4 v2, -0x1

    goto :goto_0
.end method

.method private isOverspeed(Lcom/thinkware/sundo/remoteTBT/TBTGuide;)Z
    .locals 7
    .param p1, "guideData"    # Lcom/thinkware/sundo/remoteTBT/TBTGuide;

    .prologue
    const/4 v6, 0x1

    const/4 v5, 0x5

    .line 4836
    iget v2, p1, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->mCurrentSpeed:I

    .line 4837
    .local v2, "nSpeed":I
    const/4 v1, 0x0

    .line 4839
    .local v1, "bOverspeed":Z
    iget-char v3, p1, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->camerakind:C

    if-eq v3, v6, :cond_0

    iget-char v3, p1, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->camerakind:C

    const/4 v4, 0x2

    if-eq v3, v4, :cond_0

    iget-char v3, p1, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->camerakind:C

    if-eq v3, v5, :cond_0

    iget-char v3, p1, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->camerakind:C

    const/4 v4, 0x6

    if-eq v3, v4, :cond_0

    iget-char v3, p1, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->camerakind:C

    const/16 v4, 0xb

    if-eq v3, v4, :cond_0

    iget-char v3, p1, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->camerakind:C

    const/16 v4, 0xc

    if-eq v3, v4, :cond_0

    iget-char v3, p1, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->camerakind:C

    const/16 v4, 0xd

    if-eq v3, v4, :cond_0

    iget-char v3, p1, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->camerakind:C

    const/16 v4, 0xf

    if-eq v3, v4, :cond_0

    iget-char v3, p1, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->camerakind:C

    const/16 v4, 0x10

    if-ne v3, v4, :cond_4

    .line 4845
    :cond_0
    iget v3, p1, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->speedlimit:I

    sub-int v0, v3, v2

    .line 4847
    .local v0, "Speedlimit1":I
    if-lez v0, :cond_2

    if-gt v0, v5, :cond_2

    .line 4848
    const/4 v1, 0x1

    .line 4871
    .end local v0    # "Speedlimit1":I
    :cond_1
    :goto_0
    return v1

    .line 4849
    .restart local v0    # "Speedlimit1":I
    :cond_2
    iget v3, p1, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->speedlimit:I

    if-gt v3, v2, :cond_3

    .line 4850
    const/4 v1, 0x1

    goto :goto_0

    .line 4852
    :cond_3
    const/4 v1, 0x0

    goto :goto_0

    .line 4854
    .end local v0    # "Speedlimit1":I
    :cond_4
    iget-char v3, p1, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->camerakind:C

    if-ne v3, v6, :cond_7

    .line 4855
    iget v3, p1, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->SpeedLimitZoneGuide_type:I

    if-eqz v3, :cond_1

    .line 4856
    iget v3, p1, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->speedlimit:I

    sub-int v0, v3, v2

    .line 4858
    .restart local v0    # "Speedlimit1":I
    if-lez v0, :cond_5

    if-gt v0, v5, :cond_5

    .line 4859
    const/4 v1, 0x1

    goto :goto_0

    .line 4860
    :cond_5
    iget v3, p1, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->speedlimit:I

    if-gt v3, v2, :cond_6

    .line 4861
    const/4 v1, 0x1

    goto :goto_0

    .line 4863
    :cond_6
    const/4 v1, 0x0

    goto :goto_0

    .line 4867
    .end local v0    # "Speedlimit1":I
    :cond_7
    const/4 v1, 0x0

    goto :goto_0
.end method

.method public static loadMapVer()Ljava/lang/String;
    .locals 9

    .prologue
    .line 2040
    new-instance v1, Ljava/io/File;

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    sget-object v8, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->kMapdataPath:Ljava/lang/String;

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    const-string v8, "/mapver.txt"

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-direct {v1, v7}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 2041
    .local v1, "fileSimsa":Ljava/io/File;
    invoke-virtual {v1}, Ljava/io/File;->isFile()Z

    move-result v7

    if-eqz v7, :cond_3

    .line 2043
    :try_start_0
    new-instance v3, Ljava/io/FileInputStream;

    invoke-direct {v3, v1}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V

    .line 2044
    .local v3, "in":Ljava/io/FileInputStream;
    const/16 v7, 0x1f4

    new-array v5, v7, [B

    .line 2046
    .local v5, "sentence":[B
    invoke-virtual {v3, v5}, Ljava/io/FileInputStream;->read([B)I

    move-result v4

    .line 2047
    .local v4, "readSize":I
    const/4 v7, -0x1

    if-ne v4, v7, :cond_0

    .line 2048
    invoke-virtual {v3}, Ljava/io/FileInputStream;->close()V

    .line 2049
    const-string v6, ""

    .line 2079
    .end local v3    # "in":Ljava/io/FileInputStream;
    .end local v4    # "readSize":I
    .end local v5    # "sentence":[B
    :goto_0
    return-object v6

    .line 2051
    .restart local v3    # "in":Ljava/io/FileInputStream;
    .restart local v4    # "readSize":I
    .restart local v5    # "sentence":[B
    :cond_0
    const/4 v2, 0x0

    .line 2053
    .local v2, "idx":I
    const-string v6, ""

    .line 2054
    .local v6, "strMapVer":Ljava/lang/String;
    new-instance v6, Ljava/lang/String;

    .end local v6    # "strMapVer":Ljava/lang/String;
    const-string v7, "EUC-KR"

    invoke-direct {v6, v5, v2, v4, v7}, Ljava/lang/String;-><init>([BIILjava/lang/String;)V

    .line 2056
    .restart local v6    # "strMapVer":Ljava/lang/String;
    if-eqz v6, :cond_1

    invoke-virtual {v6}, Ljava/lang/String;->length()I

    move-result v7

    const/4 v8, 0x1

    if-ge v7, v8, :cond_2

    .line 2057
    :cond_1
    invoke-virtual {v3}, Ljava/io/FileInputStream;->close()V

    .line 2058
    const-string v6, ""

    goto :goto_0

    .line 2061
    :cond_2
    const-string v7, "\uc544\uc774\ub098\ube44 \uc9c0\ub3c4\ub370\uc774\ud130 \ubc84\uc804 : "

    invoke-virtual {v6, v7}, Ljava/lang/String;->lastIndexOf(Ljava/lang/String;)I

    move-result v7

    invoke-virtual {v6, v7}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v6

    .line 2063
    new-instance v7, Ljava/lang/String;

    const-string v8, "\uc544\uc774\ub098\ube44 \uc9c0\ub3c4\ub370\uc774\ud130 \ubc84\uc804 : "

    invoke-direct {v7, v8}, Ljava/lang/String;-><init>(Ljava/lang/String;)V

    invoke-virtual {v7}, Ljava/lang/String;->length()I

    move-result v7

    invoke-virtual {v6, v7}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v6

    .line 2065
    const-string v7, "."

    const-string v8, ""

    invoke-virtual {v6, v7, v8}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v6

    .line 2067
    invoke-virtual {v3}, Ljava/io/FileInputStream;->close()V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/IndexOutOfBoundsException; {:try_start_0 .. :try_end_0} :catch_1

    goto :goto_0

    .line 2070
    .end local v2    # "idx":I
    .end local v3    # "in":Ljava/io/FileInputStream;
    .end local v4    # "readSize":I
    .end local v5    # "sentence":[B
    .end local v6    # "strMapVer":Ljava/lang/String;
    :catch_0
    move-exception v0

    .line 2071
    .local v0, "e":Ljava/io/IOException;
    invoke-virtual {v0}, Ljava/io/IOException;->printStackTrace()V

    .line 2072
    const-string v6, ""

    goto :goto_0

    .line 2073
    .end local v0    # "e":Ljava/io/IOException;
    :catch_1
    move-exception v0

    .line 2074
    .local v0, "e":Ljava/lang/IndexOutOfBoundsException;
    invoke-virtual {v0}, Ljava/lang/IndexOutOfBoundsException;->printStackTrace()V

    .line 2075
    const-string v6, ""

    goto :goto_0

    .line 2079
    .end local v0    # "e":Ljava/lang/IndexOutOfBoundsException;
    :cond_3
    const-string v6, ""

    goto :goto_0
.end method

.method public static loadSimsa()Ljava/lang/String;
    .locals 8

    .prologue
    .line 2001
    new-instance v0, Ljava/io/File;

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    sget-object v7, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->kMapdataPath:Ljava/lang/String;

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, "/mapver.txt"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-direct {v0, v6}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 2002
    .local v0, "fileSimsa":Ljava/io/File;
    invoke-virtual {v0}, Ljava/io/File;->isFile()Z

    move-result v6

    if-eqz v6, :cond_3

    .line 2004
    :try_start_0
    new-instance v2, Ljava/io/FileInputStream;

    invoke-direct {v2, v0}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V

    .line 2005
    .local v2, "in":Ljava/io/FileInputStream;
    const/16 v6, 0x1f4

    new-array v4, v6, [B

    .line 2007
    .local v4, "sentence":[B
    invoke-virtual {v2, v4}, Ljava/io/FileInputStream;->read([B)I

    move-result v3

    .line 2008
    .local v3, "readSize":I
    const/4 v6, -0x1

    if-ne v3, v6, :cond_0

    .line 2009
    invoke-virtual {v2}, Ljava/io/FileInputStream;->close()V

    .line 2010
    const-string v5, ""

    .line 2035
    .end local v2    # "in":Ljava/io/FileInputStream;
    .end local v3    # "readSize":I
    .end local v4    # "sentence":[B
    :goto_0
    return-object v5

    .line 2012
    .restart local v2    # "in":Ljava/io/FileInputStream;
    .restart local v3    # "readSize":I
    .restart local v4    # "sentence":[B
    :cond_0
    const/4 v1, 0x0

    .line 2013
    .local v1, "idx":I
    const-string v5, ""

    .line 2014
    .local v5, "strSimsa":Ljava/lang/String;
    new-instance v5, Ljava/lang/String;

    .end local v5    # "strSimsa":Ljava/lang/String;
    const-string v6, "EUC-KR"

    invoke-direct {v5, v4, v1, v3, v6}, Ljava/lang/String;-><init>([BIILjava/lang/String;)V

    .line 2015
    .restart local v5    # "strSimsa":Ljava/lang/String;
    const-string v6, "\n"

    const-string v7, " "

    invoke-virtual {v5, v6, v7}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v5

    .line 2016
    const-string v6, " \uc544\uc774\ub098\ube44 \uc9c0\ub3c4\ub370\uc774\ud130 \ubc84\uc804"

    const-string v7, "\n\uc544\uc774\ub098\ube44 \uc9c0\ub3c4\ub370\uc774\ud130 \ubc84\uc804"

    invoke-virtual {v5, v6, v7}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v5

    .line 2017
    if-nez v5, :cond_1

    .line 2018
    invoke-virtual {v2}, Ljava/io/FileInputStream;->close()V

    .line 2019
    const-string v5, ""

    goto :goto_0

    .line 2021
    :cond_1
    const-string v6, "\ub300\ud55c\uce21\ub7c9\ud611\ud68c"

    invoke-virtual {v5, v6}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v6

    if-eqz v6, :cond_2

    .line 2022
    invoke-virtual {v2}, Ljava/io/FileInputStream;->close()V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    .line 2028
    .end local v1    # "idx":I
    .end local v2    # "in":Ljava/io/FileInputStream;
    .end local v3    # "readSize":I
    .end local v4    # "sentence":[B
    .end local v5    # "strSimsa":Ljava/lang/String;
    :catch_0
    move-exception v6

    .line 2035
    const-string v5, ""

    goto :goto_0

    .line 2025
    .restart local v1    # "idx":I
    .restart local v2    # "in":Ljava/io/FileInputStream;
    .restart local v3    # "readSize":I
    .restart local v4    # "sentence":[B
    .restart local v5    # "strSimsa":Ljava/lang/String;
    :cond_2
    :try_start_1
    invoke-virtual {v2}, Ljava/io/FileInputStream;->close()V

    .line 2026
    const-string v5, ""
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_0

    goto :goto_0

    .line 2033
    .end local v1    # "idx":I
    .end local v2    # "in":Ljava/io/FileInputStream;
    .end local v3    # "readSize":I
    .end local v4    # "sentence":[B
    .end local v5    # "strSimsa":Ljava/lang/String;
    :cond_3
    const-string v5, ""

    goto :goto_0
.end method

.method private moveToRootActivity(Landroid/content/Intent;Z)V
    .locals 8
    .param p1, "intent"    # Landroid/content/Intent;
    .param p2, "isCurrent"    # Z

    .prologue
    .line 631
    if-nez p2, :cond_0

    iget-boolean v6, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mCurrentOn:Z

    if-nez v6, :cond_0

    .line 638
    :cond_0
    iget-object v6, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    if-nez v6, :cond_2

    .line 672
    :cond_1
    :goto_0
    return-void

    .line 642
    :cond_2
    iget-object v6, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    invoke-virtual {v6}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v4

    .line 643
    .local v4, "packageName":Ljava/lang/String;
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getActivityCount()I

    move-result v0

    .line 645
    .local v0, "activityCount":I
    if-lez v0, :cond_1

    .line 646
    const/4 v1, 0x0

    .local v1, "activityIndex":I
    :goto_1
    if-ge v1, v0, :cond_5

    .line 647
    iget-object v6, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mActivityInfoArray:Ljava/util/ArrayList;

    invoke-virtual {v6, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$InnerActivityInfo;

    .line 648
    .local v3, "innerActivityInfo":Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$InnerActivityInfo;
    invoke-virtual {v3}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$InnerActivityInfo;->getActivityClassName()Ljava/lang/String;

    move-result-object v2

    .line 650
    .local v2, "className":Ljava/lang/String;
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getMainClassName()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v2, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-nez v6, :cond_4

    .line 651
    new-instance v5, Landroid/content/Intent;

    invoke-direct {v5}, Landroid/content/Intent;-><init>()V

    .line 652
    .local v5, "popIntent":Landroid/content/Intent;
    new-instance v6, Landroid/content/ComponentName;

    invoke-direct {v6, v4, v2}, Landroid/content/ComponentName;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v5, v6}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;

    .line 653
    const/high16 v6, 0x30000

    invoke-virtual {v5, v6}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;

    .line 654
    iget-object v6, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    invoke-virtual {v6, v5}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    .line 646
    .end local v5    # "popIntent":Landroid/content/Intent;
    :cond_3
    add-int/lit8 v1, v1, 0x1

    goto :goto_1

    .line 656
    :cond_4
    const/4 v6, 0x1

    if-ne v0, v6, :cond_3

    .line 657
    iget-object v6, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    invoke-virtual {p0, v6}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->popActivity(Landroid/content/Context;)V

    goto :goto_0

    .line 662
    .end local v2    # "className":Ljava/lang/String;
    .end local v3    # "innerActivityInfo":Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$InnerActivityInfo;
    :cond_5
    if-nez p1, :cond_6

    .line 663
    new-instance p1, Landroid/content/Intent;

    .end local p1    # "intent":Landroid/content/Intent;
    iget-object v6, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    const-class v7, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    invoke-direct {p1, v6, v7}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 665
    .restart local p1    # "intent":Landroid/content/Intent;
    :cond_6
    const/high16 v6, 0x24010000

    invoke-virtual {p1, v6}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;

    .line 668
    iget-object v6, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    invoke-virtual {v6, p1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    .line 670
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->popAllActivity()V

    goto :goto_0
.end method

.method private moveToRootActivityFromExt()V
    .locals 2

    .prologue
    .line 531
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getActivityCount()I

    move-result v0

    .line 532
    .local v0, "activityCount":I
    if-lez v0, :cond_0

    .line 584
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getInnerActivityClassName()Ljava/lang/String;

    move-result-object v1

    if-eqz v1, :cond_1

    .line 585
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v1

    invoke-virtual {v1}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->extCurrentOn()V

    .line 604
    :cond_0
    :goto_0
    return-void

    .line 589
    :cond_1
    const/4 v1, 0x1

    invoke-virtual {p0, v1}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->moveCurrentLocation(Z)V

    goto :goto_0
.end method

.method private onAINAProcessForDefault(Landroid/content/Intent;)V
    .locals 14
    .param p1, "msg"    # Landroid/content/Intent;

    .prologue
    .line 4069
    const-string v9, "VOICE_COMMAND"

    invoke-virtual {p1, v9}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 4070
    .local v6, "strCommand":Ljava/lang/String;
    const-string v9, "\uc9d1\uc73c\ub85c"

    invoke-virtual {v6, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_1

    .line 4075
    sget-object v9, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->inavi_reference:Lcom/thinkware/sundo/inavi3d/Inavi;

    const v10, 0x222e0

    const v11, 0x22329

    const/4 v12, 0x0

    const/4 v13, 0x0

    invoke-virtual {v9, v10, v11, v12, v13}, Lcom/thinkware/sundo/inavi3d/Inavi;->PushMessage(IIII)V

    .line 4219
    :cond_0
    :goto_0
    return-void

    .line 4077
    :cond_1
    const-string v9, "\uc790\uc8fc\uac00\ub294\uacf3"

    invoke-virtual {v6, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_2

    .line 4082
    sget-object v9, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->inavi_reference:Lcom/thinkware/sundo/inavi3d/Inavi;

    const v10, 0x222e0

    const v11, 0x2232a

    const/4 v12, 0x0

    const/4 v13, 0x0

    invoke-virtual {v9, v10, v11, v12, v13}, Lcom/thinkware/sundo/inavi3d/Inavi;->PushMessage(IIII)V

    goto :goto_0

    .line 4084
    :cond_2
    const-string v9, "\uacbd\ub85c\ucde8\uc18c"

    invoke-virtual {v6, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_4

    .line 4086
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/Inavi;->getTbtguide()Lcom/thinkware/sundo/remoteTBT/TBTGuide;

    move-result-object v9

    iget v9, v9, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->viaCount:I

    const/4 v10, 0x1

    if-ne v9, v10, :cond_3

    .line 4087
    sget-object v9, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->inavi_reference:Lcom/thinkware/sundo/inavi3d/Inavi;

    const v10, 0x222e0

    const v11, 0x22315

    const/4 v12, 0x1

    const/4 v13, 0x0

    invoke-virtual {v9, v10, v11, v12, v13}, Lcom/thinkware/sundo/inavi3d/Inavi;->PushMessage(IIII)V

    goto :goto_0

    .line 4091
    :cond_3
    sget-object v9, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->inavi_reference:Lcom/thinkware/sundo/inavi3d/Inavi;

    const v10, 0x22538

    const v11, 0x2253a

    const/4 v12, 0x0

    const/4 v13, 0x0

    invoke-virtual {v9, v10, v11, v12, v13}, Lcom/thinkware/sundo/inavi3d/Inavi;->PushMessage(IIII)V

    goto :goto_0

    .line 4093
    :cond_4
    const-string v9, "\uc548\ub0b4\uc2dc\uc791"

    invoke-virtual {v6, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_5

    .line 4094
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v9

    invoke-virtual {v9}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->onClickStartRouteGuideButton()V

    goto :goto_0

    .line 4096
    :cond_5
    const-string v9, "\ucd5c\uadfc\ubaa9\uc801\uc9c0"

    invoke-virtual {v6, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_7

    .line 4097
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/UserDataMgr;->getInstance()Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/UserDataMgr;

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/UserDataMgr;->GetRecentGoalDBCount()I

    move-result v0

    .line 4098
    .local v0, "goalCount":I
    if-lez v0, :cond_6

    .line 4100
    new-instance v3, Landroid/content/Intent;

    iget-object v9, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    check-cast v9, Landroid/app/Activity;

    invoke-virtual {v9}, Landroid/app/Activity;->getApplication()Landroid/app/Application;

    move-result-object v9

    const-class v10, Lcom/thinkware/sundo/inavi3d/ui/userdata/RecentGoalActivity;

    invoke-direct {v3, v9, v10}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 4101
    .local v3, "intentRecent":Landroid/content/Intent;
    iget-object v9, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    invoke-virtual {v9, v3}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    goto :goto_0

    .line 4105
    .end local v3    # "intentRecent":Landroid/content/Intent;
    :cond_6
    sget-object v9, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->inavi_reference:Lcom/thinkware/sundo/inavi3d/Inavi;

    const v10, 0x22538

    const v11, 0x22543

    const/4 v12, 0x0

    const/4 v13, 0x0

    invoke-virtual {v9, v10, v11, v12, v13}, Lcom/thinkware/sundo/inavi3d/Inavi;->PushMessage(IIII)V

    goto/16 :goto_0

    .line 4107
    .end local v0    # "goalCount":I
    :cond_7
    const-string v9, "\ub4f1\ub85d\uc9c0\uc810"

    invoke-virtual {v6, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_b

    .line 4109
    const/4 v8, 0x0

    .line 4110
    .local v8, "upCnt":I
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/UserDataMgr;->UPGetTotalPointCnt()I

    move-result v8

    .line 4111
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/UserDataMgr;->UPIsHome()Z

    move-result v9

    if-eqz v9, :cond_8

    .line 4112
    add-int/lit8 v8, v8, 0x1

    .line 4113
    :cond_8
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/UserDataMgr;->UPIsFreq()Z

    move-result v9

    if-eqz v9, :cond_9

    .line 4114
    add-int/lit8 v8, v8, 0x1

    .line 4116
    :cond_9
    if-lez v8, :cond_a

    .line 4117
    new-instance v2, Landroid/content/Intent;

    iget-object v9, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    check-cast v9, Landroid/app/Activity;

    invoke-virtual {v9}, Landroid/app/Activity;->getApplication()Landroid/app/Application;

    move-result-object v9

    const-class v10, Lcom/thinkware/sundo/inavi3d/ui/userdata/UserPointActivity;

    invoke-direct {v2, v9, v10}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 4118
    .local v2, "intentPoint":Landroid/content/Intent;
    iget-object v9, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    invoke-virtual {v9, v2}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    goto/16 :goto_0

    .line 4120
    .end local v2    # "intentPoint":Landroid/content/Intent;
    :cond_a
    sget-object v9, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->inavi_reference:Lcom/thinkware/sundo/inavi3d/Inavi;

    const v10, 0x22538

    const v11, 0x22544

    const/4 v12, 0x0

    const/4 v13, 0x0

    invoke-virtual {v9, v10, v11, v12, v13}, Lcom/thinkware/sundo/inavi3d/Inavi;->PushMessage(IIII)V

    goto/16 :goto_0

    .line 4124
    .end local v8    # "upCnt":I
    :cond_b
    const-string v9, "\ub514\uc5e0\ube44"

    invoke-virtual {v6, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_c

    .line 4125
    const-string v9, "inavi3d_nip"

    const-string v10, "showNIP :: 25"

    invoke-static {v9, v10}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 4126
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v9

    const/4 v10, 0x2

    const/4 v11, 0x1

    invoke-virtual {v9, v10, v11}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->showNIP(IZ)Z

    goto/16 :goto_0

    .line 4127
    :cond_c
    const-string v9, "\uc8fc\ubcc0\uc8fc\uc720\uc18c"

    invoke-virtual {v6, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_e

    .line 4128
    sget v9, Lcom/thinkware/sundo/inavi3d/ui/adapterdata/AroundSchListInfo;->AROUND_ALLITEM:I

    const/4 v10, 0x0

    invoke-static {v9, v10}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->SetAroundCategoryList(II)I

    .line 4129
    const/16 v9, 0x66

    invoke-static {v9}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->SetAroundCategoryResultList(I)I

    move-result v5

    .line 4131
    .local v5, "nCount":I
    if-gtz v5, :cond_d

    .line 4132
    const/16 v9, 0x30

    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    const-string v11, "\uc54c\ub9bc"

    const-string v12, "\uac80\uc0c9 \uacb0\uacfc\uac00 \uc5c6\uc2b5\ub2c8\ub2e4"

    const/4 v13, 0x0

    invoke-static {v9, v10, v11, v12, v13}, Lcom/thinkware/sundo/inavi3d/ui/popup/PopupManager;->ShowPopup(ILandroid/content/Context;Ljava/lang/String;Ljava/lang/String;I)Lcom/thinkware/sundo/inavi3d/ui/popup/InaviPopup;

    goto/16 :goto_0

    .line 4134
    :cond_d
    new-instance v1, Landroid/content/Intent;

    iget-object v9, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    check-cast v9, Landroid/app/Activity;

    invoke-virtual {v9}, Landroid/app/Activity;->getApplication()Landroid/app/Application;

    move-result-object v9

    const-class v10, Lcom/thinkware/sundo/inavi3d/ui/AroundSrchResultActivity;

    invoke-direct {v1, v9, v10}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 4135
    .local v1, "intent":Landroid/content/Intent;
    const-string v9, "CategoryID"

    const/16 v10, 0x66

    invoke-virtual {v1, v9, v10}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 4136
    iget-object v9, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    invoke-virtual {v9, v1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    goto/16 :goto_0

    .line 4139
    .end local v1    # "intent":Landroid/content/Intent;
    .end local v5    # "nCount":I
    :cond_e
    const-string v9, "\uc8fc\ubcc0\uc8fc\ucc28\uc7a5"

    invoke-virtual {v6, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_10

    .line 4140
    sget v9, Lcom/thinkware/sundo/inavi3d/ui/adapterdata/AroundSchListInfo;->AROUND_ALLITEM:I

    const/4 v10, 0x0

    invoke-static {v9, v10}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->SetAroundCategoryList(II)I

    .line 4141
    const/4 v9, 0x6

    invoke-static {v9}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->SetAroundCategoryResultList(I)I

    move-result v5

    .line 4143
    .restart local v5    # "nCount":I
    if-gtz v5, :cond_f

    .line 4144
    const/16 v9, 0x30

    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    const-string v11, "\uc54c\ub9bc"

    const-string v12, "\uac80\uc0c9 \uacb0\uacfc\uac00 \uc5c6\uc2b5\ub2c8\ub2e4"

    const/4 v13, 0x0

    invoke-static {v9, v10, v11, v12, v13}, Lcom/thinkware/sundo/inavi3d/ui/popup/PopupManager;->ShowPopup(ILandroid/content/Context;Ljava/lang/String;Ljava/lang/String;I)Lcom/thinkware/sundo/inavi3d/ui/popup/InaviPopup;

    goto/16 :goto_0

    .line 4146
    :cond_f
    new-instance v1, Landroid/content/Intent;

    iget-object v9, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    check-cast v9, Landroid/app/Activity;

    invoke-virtual {v9}, Landroid/app/Activity;->getApplication()Landroid/app/Application;

    move-result-object v9

    const-class v10, Lcom/thinkware/sundo/inavi3d/ui/AroundSrchResultActivity;

    invoke-direct {v1, v9, v10}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 4147
    .restart local v1    # "intent":Landroid/content/Intent;
    const-string v9, "CategoryID"

    const/4 v10, 0x6

    invoke-virtual {v1, v9, v10}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 4148
    iget-object v9, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    invoke-virtual {v9, v1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    goto/16 :goto_0

    .line 4151
    .end local v1    # "intent":Landroid/content/Intent;
    .end local v5    # "nCount":I
    :cond_10
    const-string v9, "\uc8fc\ubcc0\ud3b8\uc758\uc810"

    invoke-virtual {v6, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_12

    .line 4152
    sget v9, Lcom/thinkware/sundo/inavi3d/ui/adapterdata/AroundSchListInfo;->AROUND_ALLITEM:I

    const/4 v10, 0x0

    invoke-static {v9, v10}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->SetAroundCategoryList(II)I

    .line 4153
    const/16 v9, 0x1c

    invoke-static {v9}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->SetAroundCategoryResultList(I)I

    move-result v5

    .line 4155
    .restart local v5    # "nCount":I
    if-gtz v5, :cond_11

    .line 4156
    const/16 v9, 0x30

    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    const-string v11, "\uc54c\ub9bc"

    const-string v12, "\uac80\uc0c9 \uacb0\uacfc\uac00 \uc5c6\uc2b5\ub2c8\ub2e4"

    const/4 v13, 0x0

    invoke-static {v9, v10, v11, v12, v13}, Lcom/thinkware/sundo/inavi3d/ui/popup/PopupManager;->ShowPopup(ILandroid/content/Context;Ljava/lang/String;Ljava/lang/String;I)Lcom/thinkware/sundo/inavi3d/ui/popup/InaviPopup;

    goto/16 :goto_0

    .line 4158
    :cond_11
    new-instance v1, Landroid/content/Intent;

    iget-object v9, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    check-cast v9, Landroid/app/Activity;

    invoke-virtual {v9}, Landroid/app/Activity;->getApplication()Landroid/app/Application;

    move-result-object v9

    const-class v10, Lcom/thinkware/sundo/inavi3d/ui/AroundSrchResultActivity;

    invoke-direct {v1, v9, v10}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 4159
    .restart local v1    # "intent":Landroid/content/Intent;
    const-string v9, "CategoryID"

    const/16 v10, 0x1c

    invoke-virtual {v1, v9, v10}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 4160
    iget-object v9, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    invoke-virtual {v9, v1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    goto/16 :goto_0

    .line 4163
    .end local v1    # "intent":Landroid/content/Intent;
    .end local v5    # "nCount":I
    :cond_12
    const-string v9, "\uc8fc\ubcc0\ud654\uc7a5\uc2e4"

    invoke-virtual {v6, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_14

    .line 4164
    sget v9, Lcom/thinkware/sundo/inavi3d/ui/adapterdata/AroundSchListInfo;->AROUND_ALLITEM:I

    const/4 v10, 0x0

    invoke-static {v9, v10}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->SetAroundCategoryList(II)I

    .line 4165
    const/16 v9, 0xa

    invoke-static {v9}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->SetAroundCategoryResultList(I)I

    move-result v5

    .line 4167
    .restart local v5    # "nCount":I
    if-gtz v5, :cond_13

    .line 4168
    const/16 v9, 0x30

    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    const-string v11, "\uc54c\ub9bc"

    const-string v12, "\uac80\uc0c9 \uacb0\uacfc\uac00 \uc5c6\uc2b5\ub2c8\ub2e4"

    const/4 v13, 0x0

    invoke-static {v9, v10, v11, v12, v13}, Lcom/thinkware/sundo/inavi3d/ui/popup/PopupManager;->ShowPopup(ILandroid/content/Context;Ljava/lang/String;Ljava/lang/String;I)Lcom/thinkware/sundo/inavi3d/ui/popup/InaviPopup;

    goto/16 :goto_0

    .line 4170
    :cond_13
    new-instance v1, Landroid/content/Intent;

    iget-object v9, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    check-cast v9, Landroid/app/Activity;

    invoke-virtual {v9}, Landroid/app/Activity;->getApplication()Landroid/app/Application;

    move-result-object v9

    const-class v10, Lcom/thinkware/sundo/inavi3d/ui/AroundSrchResultActivity;

    invoke-direct {v1, v9, v10}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 4171
    .restart local v1    # "intent":Landroid/content/Intent;
    const-string v9, "CategoryID"

    const/16 v10, 0xa

    invoke-virtual {v1, v9, v10}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 4172
    iget-object v9, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    invoke-virtual {v9, v1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    goto/16 :goto_0

    .line 4175
    .end local v1    # "intent":Landroid/content/Intent;
    .end local v5    # "nCount":I
    :cond_14
    const-string v9, "\uc8fc\ubcc0\ubcd1\uc6d0"

    invoke-virtual {v6, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_16

    .line 4176
    sget v9, Lcom/thinkware/sundo/inavi3d/ui/adapterdata/AroundSchListInfo;->AROUND_ALLITEM:I

    const/4 v10, 0x0

    invoke-static {v9, v10}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->SetAroundCategoryList(II)I

    .line 4177
    const/4 v9, 0x4

    invoke-static {v9}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->SetAroundCategoryResultList(I)I

    move-result v5

    .line 4179
    .restart local v5    # "nCount":I
    if-gtz v5, :cond_15

    .line 4180
    const/16 v9, 0x30

    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    const-string v11, "\uc54c\ub9bc"

    const-string v12, "\uac80\uc0c9 \uacb0\uacfc\uac00 \uc5c6\uc2b5\ub2c8\ub2e4"

    const/4 v13, 0x0

    invoke-static {v9, v10, v11, v12, v13}, Lcom/thinkware/sundo/inavi3d/ui/popup/PopupManager;->ShowPopup(ILandroid/content/Context;Ljava/lang/String;Ljava/lang/String;I)Lcom/thinkware/sundo/inavi3d/ui/popup/InaviPopup;

    goto/16 :goto_0

    .line 4182
    :cond_15
    new-instance v1, Landroid/content/Intent;

    iget-object v9, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    check-cast v9, Landroid/app/Activity;

    invoke-virtual {v9}, Landroid/app/Activity;->getApplication()Landroid/app/Application;

    move-result-object v9

    const-class v10, Lcom/thinkware/sundo/inavi3d/ui/AroundSrchResultActivity;

    invoke-direct {v1, v9, v10}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 4183
    .restart local v1    # "intent":Landroid/content/Intent;
    const-string v9, "CategoryID"

    const/4 v10, 0x4

    invoke-virtual {v1, v9, v10}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 4184
    iget-object v9, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    invoke-virtual {v9, v1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    goto/16 :goto_0

    .line 4187
    .end local v1    # "intent":Landroid/content/Intent;
    .end local v5    # "nCount":I
    :cond_16
    const-string v9, "\uc8fc\ubcc0\ucda9\uc804\uc18c"

    invoke-virtual {v6, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_18

    .line 4188
    sget v9, Lcom/thinkware/sundo/inavi3d/ui/adapterdata/AroundSchListInfo;->AROUND_ALLITEM:I

    const/4 v10, 0x0

    invoke-static {v9, v10}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->SetAroundCategoryList(II)I

    .line 4189
    const/16 v9, 0x66

    invoke-static {v9}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->SetAroundCategoryResultList(I)I

    move-result v5

    .line 4191
    .restart local v5    # "nCount":I
    if-gtz v5, :cond_17

    .line 4192
    const/16 v9, 0x30

    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    const-string v11, "\uc54c\ub9bc"

    const-string v12, "\uac80\uc0c9 \uacb0\uacfc\uac00 \uc5c6\uc2b5\ub2c8\ub2e4"

    const/4 v13, 0x0

    invoke-static {v9, v10, v11, v12, v13}, Lcom/thinkware/sundo/inavi3d/ui/popup/PopupManager;->ShowPopup(ILandroid/content/Context;Ljava/lang/String;Ljava/lang/String;I)Lcom/thinkware/sundo/inavi3d/ui/popup/InaviPopup;

    goto/16 :goto_0

    .line 4194
    :cond_17
    new-instance v1, Landroid/content/Intent;

    iget-object v9, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    check-cast v9, Landroid/app/Activity;

    invoke-virtual {v9}, Landroid/app/Activity;->getApplication()Landroid/app/Application;

    move-result-object v9

    const-class v10, Lcom/thinkware/sundo/inavi3d/ui/AroundSrchResultActivity;

    invoke-direct {v1, v9, v10}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 4195
    .restart local v1    # "intent":Landroid/content/Intent;
    const-string v9, "CategoryID"

    const/16 v10, 0x66

    invoke-virtual {v1, v9, v10}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 4196
    iget-object v9, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    invoke-virtual {v9, v1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    goto/16 :goto_0

    .line 4199
    .end local v1    # "intent":Landroid/content/Intent;
    .end local v5    # "nCount":I
    :cond_18
    const-string v9, "\uc8fc\ubcc0\uc9c0\ud558\ucca0"

    invoke-virtual {v6, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_1a

    .line 4200
    sget v9, Lcom/thinkware/sundo/inavi3d/ui/adapterdata/AroundSchListInfo;->AROUND_ALLITEM:I

    const/4 v10, 0x0

    invoke-static {v9, v10}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->SetAroundCategoryList(II)I

    .line 4201
    const/16 v9, 0x1a

    invoke-static {v9}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->SetAroundCategoryResultList(I)I

    move-result v5

    .line 4203
    .restart local v5    # "nCount":I
    if-gtz v5, :cond_19

    .line 4204
    const/16 v9, 0x30

    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    const-string v11, "\uc54c\ub9bc"

    const-string v12, "\uac80\uc0c9 \uacb0\uacfc\uac00 \uc5c6\uc2b5\ub2c8\ub2e4"

    const/4 v13, 0x0

    invoke-static {v9, v10, v11, v12, v13}, Lcom/thinkware/sundo/inavi3d/ui/popup/PopupManager;->ShowPopup(ILandroid/content/Context;Ljava/lang/String;Ljava/lang/String;I)Lcom/thinkware/sundo/inavi3d/ui/popup/InaviPopup;

    goto/16 :goto_0

    .line 4206
    :cond_19
    new-instance v1, Landroid/content/Intent;

    iget-object v9, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    check-cast v9, Landroid/app/Activity;

    invoke-virtual {v9}, Landroid/app/Activity;->getApplication()Landroid/app/Application;

    move-result-object v9

    const-class v10, Lcom/thinkware/sundo/inavi3d/ui/AroundSrchResultActivity;

    invoke-direct {v1, v9, v10}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 4207
    .restart local v1    # "intent":Landroid/content/Intent;
    const-string v9, "CategoryID"

    const/16 v10, 0x1a

    invoke-virtual {v1, v9, v10}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 4208
    iget-object v9, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    invoke-virtual {v9, v1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    goto/16 :goto_0

    .line 4213
    .end local v1    # "intent":Landroid/content/Intent;
    .end local v5    # "nCount":I
    :cond_1a
    const-string v9, "\uac80\uc0c9"

    invoke-virtual {v6, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_0

    .line 4214
    const-string v9, "SEARCH_WORD"

    invoke-virtual {p1, v9}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    .line 4215
    .local v7, "strQuery":Ljava/lang/String;
    new-instance v4, Landroid/content/Intent;

    iget-object v9, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    check-cast v9, Landroid/app/Activity;

    invoke-virtual {v9}, Landroid/app/Activity;->getApplication()Landroid/app/Application;

    move-result-object v9

    const-class v10, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;

    invoke-direct {v4, v9, v10}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 4216
    .local v4, "intentSearch":Landroid/content/Intent;
    const-string v9, "Query"

    invoke-virtual {v4, v9, v7}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 4217
    iget-object v9, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    invoke-virtual {v9, v4}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    goto/16 :goto_0
.end method

.method private onAINAProcessForTAURUS(Landroid/content/Intent;)V
    .locals 14
    .param p1, "msg"    # Landroid/content/Intent;

    .prologue
    .line 4222
    const-string v9, "VOICE_COMMAND"

    invoke-virtual {p1, v9}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 4223
    .local v6, "strCommand":Ljava/lang/String;
    const-string v9, "\uc9d1\uc73c\ub85c"

    invoke-virtual {v6, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_1

    .line 4228
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v9

    invoke-virtual {v9}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->isSimul()Z

    move-result v9

    if-eqz v9, :cond_0

    .line 4229
    sget-object v9, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->inavi_reference:Lcom/thinkware/sundo/inavi3d/Inavi;

    const v10, 0x249f0

    const v11, 0x249f3

    const/4 v12, 0x0

    const/4 v13, 0x0

    invoke-virtual {v9, v10, v11, v12, v13}, Lcom/thinkware/sundo/inavi3d/Inavi;->PushMessage(IIII)V

    .line 4230
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v9

    const/4 v10, 0x0

    invoke-virtual {v9, v10}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->setSimul(Z)V

    .line 4232
    :cond_0
    sget-object v9, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->inavi_reference:Lcom/thinkware/sundo/inavi3d/Inavi;

    const v10, 0x222e0

    const v11, 0x22329

    const/4 v12, 0x0

    const/4 v13, 0x0

    invoke-virtual {v9, v10, v11, v12, v13}, Lcom/thinkware/sundo/inavi3d/Inavi;->PushMessage(IIII)V

    .line 4395
    :goto_0
    return-void

    .line 4234
    :cond_1
    const-string v9, "\uc790\uc8fc\uac00\ub294\uacf3"

    invoke-virtual {v6, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_3

    .line 4239
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v9

    invoke-virtual {v9}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->isSimul()Z

    move-result v9

    if-eqz v9, :cond_2

    .line 4240
    sget-object v9, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->inavi_reference:Lcom/thinkware/sundo/inavi3d/Inavi;

    const v10, 0x249f0

    const v11, 0x249f3

    const/4 v12, 0x0

    const/4 v13, 0x0

    invoke-virtual {v9, v10, v11, v12, v13}, Lcom/thinkware/sundo/inavi3d/Inavi;->PushMessage(IIII)V

    .line 4241
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v9

    const/4 v10, 0x0

    invoke-virtual {v9, v10}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->setSimul(Z)V

    .line 4243
    :cond_2
    sget-object v9, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->inavi_reference:Lcom/thinkware/sundo/inavi3d/Inavi;

    const v10, 0x222e0

    const v11, 0x2232a

    const/4 v12, 0x0

    const/4 v13, 0x0

    invoke-virtual {v9, v10, v11, v12, v13}, Lcom/thinkware/sundo/inavi3d/Inavi;->PushMessage(IIII)V

    goto :goto_0

    .line 4245
    :cond_3
    const-string v9, "\uacbd\ub85c\ucde8\uc18c"

    invoke-virtual {v6, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_6

    .line 4248
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v9

    invoke-virtual {v9}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->isSimul()Z

    move-result v9

    if-eqz v9, :cond_4

    .line 4249
    sget-object v9, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->inavi_reference:Lcom/thinkware/sundo/inavi3d/Inavi;

    const v10, 0x249f0

    const v11, 0x249f3

    const/4 v12, 0x0

    const/4 v13, 0x0

    invoke-virtual {v9, v10, v11, v12, v13}, Lcom/thinkware/sundo/inavi3d/Inavi;->PushMessage(IIII)V

    .line 4250
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v9

    const/4 v10, 0x0

    invoke-virtual {v9, v10}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->setSimul(Z)V

    .line 4252
    :cond_4
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/Inavi;->getTbtguide()Lcom/thinkware/sundo/remoteTBT/TBTGuide;

    move-result-object v9

    iget v9, v9, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->viaCount:I

    const/4 v10, 0x1

    if-lt v9, v10, :cond_5

    .line 4253
    sget-object v9, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->inavi_reference:Lcom/thinkware/sundo/inavi3d/Inavi;

    const v10, 0x222e0

    const v11, 0x22315

    const/4 v12, 0x1

    const/4 v13, 0x0

    invoke-virtual {v9, v10, v11, v12, v13}, Lcom/thinkware/sundo/inavi3d/Inavi;->PushMessage(IIII)V

    goto :goto_0

    .line 4257
    :cond_5
    sget-object v9, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->inavi_reference:Lcom/thinkware/sundo/inavi3d/Inavi;

    const v10, 0x22538

    const v11, 0x2253a

    const/4 v12, 0x0

    const/4 v13, 0x0

    invoke-virtual {v9, v10, v11, v12, v13}, Lcom/thinkware/sundo/inavi3d/Inavi;->PushMessage(IIII)V

    goto/16 :goto_0

    .line 4259
    :cond_6
    const-string v9, "\uc548\ub0b4\uc2dc\uc791"

    invoke-virtual {v6, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_7

    .line 4260
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v9

    invoke-virtual {v9}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->onClickStartRouteGuideButton()V

    goto/16 :goto_0

    .line 4262
    :cond_7
    const-string v9, "\ucd5c\uadfc\ubaa9\uc801\uc9c0"

    invoke-virtual {v6, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_9

    .line 4263
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/UserDataMgr;->GetRecentGoalDBCount()I

    move-result v0

    .line 4264
    .local v0, "goalCount":I
    if-lez v0, :cond_8

    .line 4266
    new-instance v3, Landroid/content/Intent;

    iget-object v9, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    check-cast v9, Landroid/app/Activity;

    invoke-virtual {v9}, Landroid/app/Activity;->getApplication()Landroid/app/Application;

    move-result-object v9

    const-class v10, Lcom/thinkware/sundo/inavi3d/ui/userdata/RecentGoalActivity;

    invoke-direct {v3, v9, v10}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 4267
    .local v3, "intentRecent":Landroid/content/Intent;
    iget-object v9, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    invoke-virtual {v9, v3}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    goto/16 :goto_0

    .line 4271
    .end local v3    # "intentRecent":Landroid/content/Intent;
    :cond_8
    sget-object v9, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->inavi_reference:Lcom/thinkware/sundo/inavi3d/Inavi;

    const v10, 0x22538

    const v11, 0x22543

    const/4 v12, 0x0

    const/4 v13, 0x0

    invoke-virtual {v9, v10, v11, v12, v13}, Lcom/thinkware/sundo/inavi3d/Inavi;->PushMessage(IIII)V

    goto/16 :goto_0

    .line 4273
    .end local v0    # "goalCount":I
    :cond_9
    const-string v9, "\uc0ac\uc6a9\uc790\uc9c0\uc810"

    invoke-virtual {v6, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_a

    const-string v9, "\ub4f1\ub85d\uc9c0\uc810"

    invoke-virtual {v6, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_e

    .line 4275
    :cond_a
    const/4 v8, 0x0

    .line 4276
    .local v8, "upCnt":I
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/UserDataMgr;->UPGetTotalPointCnt()I

    move-result v8

    .line 4277
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/UserDataMgr;->UPIsHome()Z

    move-result v9

    if-eqz v9, :cond_b

    .line 4278
    add-int/lit8 v8, v8, 0x1

    .line 4279
    :cond_b
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/UserDataMgr;->UPIsFreq()Z

    move-result v9

    if-eqz v9, :cond_c

    .line 4280
    add-int/lit8 v8, v8, 0x1

    .line 4282
    :cond_c
    if-lez v8, :cond_d

    .line 4283
    new-instance v2, Landroid/content/Intent;

    iget-object v9, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    check-cast v9, Landroid/app/Activity;

    invoke-virtual {v9}, Landroid/app/Activity;->getApplication()Landroid/app/Application;

    move-result-object v9

    const-class v10, Lcom/thinkware/sundo/inavi3d/ui/userdata/UserPointActivity;

    invoke-direct {v2, v9, v10}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 4284
    .local v2, "intentPoint":Landroid/content/Intent;
    iget-object v9, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    invoke-virtual {v9, v2}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    goto/16 :goto_0

    .line 4286
    .end local v2    # "intentPoint":Landroid/content/Intent;
    :cond_d
    sget-object v9, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->inavi_reference:Lcom/thinkware/sundo/inavi3d/Inavi;

    const v10, 0x22538

    const v11, 0x22544

    const/4 v12, 0x0

    const/4 v13, 0x0

    invoke-virtual {v9, v10, v11, v12, v13}, Lcom/thinkware/sundo/inavi3d/Inavi;->PushMessage(IIII)V

    goto/16 :goto_0

    .line 4290
    .end local v8    # "upCnt":I
    :cond_e
    const-string v9, "\ub514\uc5e0\ube44"

    invoke-virtual {v6, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_f

    .line 4291
    const-string v9, "inavi3d_nip"

    const-string v10, "showNIP :: 26"

    invoke-static {v9, v10}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 4292
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v9

    const/4 v10, 0x2

    const/4 v11, 0x1

    invoke-virtual {v9, v10, v11}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->showNIP(IZ)Z

    goto/16 :goto_0

    .line 4293
    :cond_f
    const-string v9, "\uac00\uae4c\uc6b4\uc8fc\uc720\uc18c"

    invoke-virtual {v6, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_11

    .line 4294
    sget v9, Lcom/thinkware/sundo/inavi3d/ui/adapterdata/AroundSchListInfo;->AROUND_ALLITEM:I

    const/4 v10, 0x0

    invoke-static {v9, v10}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->SetAroundCategoryList(II)I

    .line 4295
    const/16 v9, 0x66

    invoke-static {v9}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->SetAroundCategoryResultList(I)I

    move-result v5

    .line 4297
    .local v5, "nCount":I
    if-gtz v5, :cond_10

    .line 4298
    const/16 v9, 0x30

    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    const-string v11, "\uc54c\ub9bc"

    const-string v12, "\uac80\uc0c9 \uacb0\uacfc\uac00 \uc5c6\uc2b5\ub2c8\ub2e4"

    const/4 v13, 0x0

    invoke-static {v9, v10, v11, v12, v13}, Lcom/thinkware/sundo/inavi3d/ui/popup/PopupManager;->ShowPopup(ILandroid/content/Context;Ljava/lang/String;Ljava/lang/String;I)Lcom/thinkware/sundo/inavi3d/ui/popup/InaviPopup;

    goto/16 :goto_0

    .line 4300
    :cond_10
    new-instance v1, Landroid/content/Intent;

    iget-object v9, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    check-cast v9, Landroid/app/Activity;

    invoke-virtual {v9}, Landroid/app/Activity;->getApplication()Landroid/app/Application;

    move-result-object v9

    const-class v10, Lcom/thinkware/sundo/inavi3d/ui/AroundSrchResultActivity;

    invoke-direct {v1, v9, v10}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 4301
    .local v1, "intent":Landroid/content/Intent;
    const-string v9, "CategoryID"

    const/16 v10, 0x66

    invoke-virtual {v1, v9, v10}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 4302
    iget-object v9, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    invoke-virtual {v9, v1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    goto/16 :goto_0

    .line 4305
    .end local v1    # "intent":Landroid/content/Intent;
    .end local v5    # "nCount":I
    :cond_11
    const-string v9, "\uac00\uae4c\uc6b4\uc8fc\ucc28\uc7a5"

    invoke-virtual {v6, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_13

    .line 4306
    sget v9, Lcom/thinkware/sundo/inavi3d/ui/adapterdata/AroundSchListInfo;->AROUND_ALLITEM:I

    const/4 v10, 0x0

    invoke-static {v9, v10}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->SetAroundCategoryList(II)I

    .line 4307
    const/4 v9, 0x6

    invoke-static {v9}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->SetAroundCategoryResultList(I)I

    move-result v5

    .line 4309
    .restart local v5    # "nCount":I
    if-gtz v5, :cond_12

    .line 4310
    const/16 v9, 0x30

    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    const-string v11, "\uc54c\ub9bc"

    const-string v12, "\uac80\uc0c9 \uacb0\uacfc\uac00 \uc5c6\uc2b5\ub2c8\ub2e4"

    const/4 v13, 0x0

    invoke-static {v9, v10, v11, v12, v13}, Lcom/thinkware/sundo/inavi3d/ui/popup/PopupManager;->ShowPopup(ILandroid/content/Context;Ljava/lang/String;Ljava/lang/String;I)Lcom/thinkware/sundo/inavi3d/ui/popup/InaviPopup;

    goto/16 :goto_0

    .line 4312
    :cond_12
    new-instance v1, Landroid/content/Intent;

    iget-object v9, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    check-cast v9, Landroid/app/Activity;

    invoke-virtual {v9}, Landroid/app/Activity;->getApplication()Landroid/app/Application;

    move-result-object v9

    const-class v10, Lcom/thinkware/sundo/inavi3d/ui/AroundSrchResultActivity;

    invoke-direct {v1, v9, v10}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 4313
    .restart local v1    # "intent":Landroid/content/Intent;
    const-string v9, "CategoryID"

    const/4 v10, 0x6

    invoke-virtual {v1, v9, v10}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 4314
    iget-object v9, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    invoke-virtual {v9, v1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    goto/16 :goto_0

    .line 4317
    .end local v1    # "intent":Landroid/content/Intent;
    .end local v5    # "nCount":I
    :cond_13
    const-string v9, "\uac00\uae4c\uc6b4\ud3b8\uc758\uc810"

    invoke-virtual {v6, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_15

    .line 4318
    sget v9, Lcom/thinkware/sundo/inavi3d/ui/adapterdata/AroundSchListInfo;->AROUND_ALLITEM:I

    const/4 v10, 0x0

    invoke-static {v9, v10}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->SetAroundCategoryList(II)I

    .line 4319
    const/16 v9, 0x1c

    invoke-static {v9}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->SetAroundCategoryResultList(I)I

    move-result v5

    .line 4321
    .restart local v5    # "nCount":I
    if-gtz v5, :cond_14

    .line 4322
    const/16 v9, 0x30

    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    const-string v11, "\uc54c\ub9bc"

    const-string v12, "\uac80\uc0c9 \uacb0\uacfc\uac00 \uc5c6\uc2b5\ub2c8\ub2e4"

    const/4 v13, 0x0

    invoke-static {v9, v10, v11, v12, v13}, Lcom/thinkware/sundo/inavi3d/ui/popup/PopupManager;->ShowPopup(ILandroid/content/Context;Ljava/lang/String;Ljava/lang/String;I)Lcom/thinkware/sundo/inavi3d/ui/popup/InaviPopup;

    goto/16 :goto_0

    .line 4324
    :cond_14
    new-instance v1, Landroid/content/Intent;

    iget-object v9, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    check-cast v9, Landroid/app/Activity;

    invoke-virtual {v9}, Landroid/app/Activity;->getApplication()Landroid/app/Application;

    move-result-object v9

    const-class v10, Lcom/thinkware/sundo/inavi3d/ui/AroundSrchResultActivity;

    invoke-direct {v1, v9, v10}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 4325
    .restart local v1    # "intent":Landroid/content/Intent;
    const-string v9, "CategoryID"

    const/16 v10, 0x1c

    invoke-virtual {v1, v9, v10}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 4326
    iget-object v9, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    invoke-virtual {v9, v1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    goto/16 :goto_0

    .line 4329
    .end local v1    # "intent":Landroid/content/Intent;
    .end local v5    # "nCount":I
    :cond_15
    const-string v9, "\uac00\uae4c\uc6b4\ud654\uc7a5\uc2e4"

    invoke-virtual {v6, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_17

    .line 4330
    sget v9, Lcom/thinkware/sundo/inavi3d/ui/adapterdata/AroundSchListInfo;->AROUND_ALLITEM:I

    const/4 v10, 0x0

    invoke-static {v9, v10}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->SetAroundCategoryList(II)I

    .line 4331
    const/16 v9, 0xa

    invoke-static {v9}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->SetAroundCategoryResultList(I)I

    move-result v5

    .line 4333
    .restart local v5    # "nCount":I
    if-gtz v5, :cond_16

    .line 4334
    const/16 v9, 0x30

    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    const-string v11, "\uc54c\ub9bc"

    const-string v12, "\uac80\uc0c9 \uacb0\uacfc\uac00 \uc5c6\uc2b5\ub2c8\ub2e4"

    const/4 v13, 0x0

    invoke-static {v9, v10, v11, v12, v13}, Lcom/thinkware/sundo/inavi3d/ui/popup/PopupManager;->ShowPopup(ILandroid/content/Context;Ljava/lang/String;Ljava/lang/String;I)Lcom/thinkware/sundo/inavi3d/ui/popup/InaviPopup;

    goto/16 :goto_0

    .line 4336
    :cond_16
    new-instance v1, Landroid/content/Intent;

    iget-object v9, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    check-cast v9, Landroid/app/Activity;

    invoke-virtual {v9}, Landroid/app/Activity;->getApplication()Landroid/app/Application;

    move-result-object v9

    const-class v10, Lcom/thinkware/sundo/inavi3d/ui/AroundSrchResultActivity;

    invoke-direct {v1, v9, v10}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 4337
    .restart local v1    # "intent":Landroid/content/Intent;
    const-string v9, "CategoryID"

    const/16 v10, 0xa

    invoke-virtual {v1, v9, v10}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 4338
    iget-object v9, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    invoke-virtual {v9, v1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    goto/16 :goto_0

    .line 4341
    .end local v1    # "intent":Landroid/content/Intent;
    .end local v5    # "nCount":I
    :cond_17
    const-string v9, "\uac00\uae4c\uc6b4\ubcd1\uc6d0"

    invoke-virtual {v6, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_19

    .line 4342
    sget v9, Lcom/thinkware/sundo/inavi3d/ui/adapterdata/AroundSchListInfo;->AROUND_ALLITEM:I

    const/4 v10, 0x0

    invoke-static {v9, v10}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->SetAroundCategoryList(II)I

    .line 4343
    const/4 v9, 0x4

    invoke-static {v9}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->SetAroundCategoryResultList(I)I

    move-result v5

    .line 4345
    .restart local v5    # "nCount":I
    if-gtz v5, :cond_18

    .line 4346
    const/16 v9, 0x30

    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    const-string v11, "\uc54c\ub9bc"

    const-string v12, "\uac80\uc0c9 \uacb0\uacfc\uac00 \uc5c6\uc2b5\ub2c8\ub2e4"

    const/4 v13, 0x0

    invoke-static {v9, v10, v11, v12, v13}, Lcom/thinkware/sundo/inavi3d/ui/popup/PopupManager;->ShowPopup(ILandroid/content/Context;Ljava/lang/String;Ljava/lang/String;I)Lcom/thinkware/sundo/inavi3d/ui/popup/InaviPopup;

    goto/16 :goto_0

    .line 4348
    :cond_18
    new-instance v1, Landroid/content/Intent;

    iget-object v9, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    check-cast v9, Landroid/app/Activity;

    invoke-virtual {v9}, Landroid/app/Activity;->getApplication()Landroid/app/Application;

    move-result-object v9

    const-class v10, Lcom/thinkware/sundo/inavi3d/ui/AroundSrchResultActivity;

    invoke-direct {v1, v9, v10}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 4349
    .restart local v1    # "intent":Landroid/content/Intent;
    const-string v9, "CategoryID"

    const/4 v10, 0x4

    invoke-virtual {v1, v9, v10}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 4350
    iget-object v9, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    invoke-virtual {v9, v1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    goto/16 :goto_0

    .line 4353
    .end local v1    # "intent":Landroid/content/Intent;
    .end local v5    # "nCount":I
    :cond_19
    const-string v9, "\uac00\uae4c\uc6b4\ucda9\uc804\uc18c"

    invoke-virtual {v6, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_1b

    .line 4354
    sget v9, Lcom/thinkware/sundo/inavi3d/ui/adapterdata/AroundSchListInfo;->AROUND_ALLITEM:I

    const/4 v10, 0x0

    invoke-static {v9, v10}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->SetAroundCategoryList(II)I

    .line 4355
    const/16 v9, 0x66

    invoke-static {v9}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->SetAroundCategoryResultList(I)I

    move-result v5

    .line 4357
    .restart local v5    # "nCount":I
    if-gtz v5, :cond_1a

    .line 4358
    const/16 v9, 0x30

    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    const-string v11, "\uc54c\ub9bc"

    const-string v12, "\uac80\uc0c9 \uacb0\uacfc\uac00 \uc5c6\uc2b5\ub2c8\ub2e4"

    const/4 v13, 0x0

    invoke-static {v9, v10, v11, v12, v13}, Lcom/thinkware/sundo/inavi3d/ui/popup/PopupManager;->ShowPopup(ILandroid/content/Context;Ljava/lang/String;Ljava/lang/String;I)Lcom/thinkware/sundo/inavi3d/ui/popup/InaviPopup;

    goto/16 :goto_0

    .line 4360
    :cond_1a
    new-instance v1, Landroid/content/Intent;

    iget-object v9, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    check-cast v9, Landroid/app/Activity;

    invoke-virtual {v9}, Landroid/app/Activity;->getApplication()Landroid/app/Application;

    move-result-object v9

    const-class v10, Lcom/thinkware/sundo/inavi3d/ui/AroundSrchResultActivity;

    invoke-direct {v1, v9, v10}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 4361
    .restart local v1    # "intent":Landroid/content/Intent;
    const-string v9, "CategoryID"

    const/16 v10, 0x66

    invoke-virtual {v1, v9, v10}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 4362
    iget-object v9, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    invoke-virtual {v9, v1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    goto/16 :goto_0

    .line 4365
    .end local v1    # "intent":Landroid/content/Intent;
    .end local v5    # "nCount":I
    :cond_1b
    const-string v9, "\uac00\uae4c\uc6b4\uc9c0\ud558\ucca0"

    invoke-virtual {v6, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_1d

    .line 4366
    sget v9, Lcom/thinkware/sundo/inavi3d/ui/adapterdata/AroundSchListInfo;->AROUND_ALLITEM:I

    const/4 v10, 0x0

    invoke-static {v9, v10}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->SetAroundCategoryList(II)I

    .line 4367
    const/16 v9, 0x1a

    invoke-static {v9}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->SetAroundCategoryResultList(I)I

    move-result v5

    .line 4369
    .restart local v5    # "nCount":I
    if-gtz v5, :cond_1c

    .line 4370
    const/16 v9, 0x30

    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    const-string v11, "\uc54c\ub9bc"

    const-string v12, "\uac80\uc0c9 \uacb0\uacfc\uac00 \uc5c6\uc2b5\ub2c8\ub2e4"

    const/4 v13, 0x0

    invoke-static {v9, v10, v11, v12, v13}, Lcom/thinkware/sundo/inavi3d/ui/popup/PopupManager;->ShowPopup(ILandroid/content/Context;Ljava/lang/String;Ljava/lang/String;I)Lcom/thinkware/sundo/inavi3d/ui/popup/InaviPopup;

    goto/16 :goto_0

    .line 4372
    :cond_1c
    new-instance v1, Landroid/content/Intent;

    iget-object v9, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    check-cast v9, Landroid/app/Activity;

    invoke-virtual {v9}, Landroid/app/Activity;->getApplication()Landroid/app/Application;

    move-result-object v9

    const-class v10, Lcom/thinkware/sundo/inavi3d/ui/AroundSrchResultActivity;

    invoke-direct {v1, v9, v10}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 4373
    .restart local v1    # "intent":Landroid/content/Intent;
    const-string v9, "CategoryID"

    const/16 v10, 0x1a

    invoke-virtual {v1, v9, v10}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 4374
    iget-object v9, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    invoke-virtual {v9, v1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    goto/16 :goto_0

    .line 4379
    .end local v1    # "intent":Landroid/content/Intent;
    .end local v5    # "nCount":I
    :cond_1d
    const-string v9, "\uac80\uc0c9"

    invoke-virtual {v6, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_1e

    .line 4380
    const-string v9, "SEARCH_WORD"

    invoke-virtual {p1, v9}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    .line 4382
    .local v7, "strQuery":Ljava/lang/String;
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v9

    iget-object v9, v9, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_iAINASearchListener:Lcom/thinkware/sundo/inavi3d/AINAUnitedSearchManager$onSearchListener;

    invoke-static {v9}, Lcom/thinkware/sundo/inavi3d/AINAUnitedSearchManager;->setOnSearchListener(Lcom/thinkware/sundo/inavi3d/AINAUnitedSearchManager$onSearchListener;)V

    .line 4383
    invoke-static {v7}, Lcom/thinkware/sundo/inavi3d/AINAUnitedSearchManager;->preDoSearch(Ljava/lang/String;)V

    goto/16 :goto_0

    .line 4385
    .end local v7    # "strQuery":Ljava/lang/String;
    :cond_1e
    const-string v9, "\uc8fc\uc18c"

    invoke-virtual {v6, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_1f

    .line 4386
    const-string v9, "SEARCH_WORD"

    invoke-virtual {p1, v9}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    .line 4388
    .restart local v7    # "strQuery":Ljava/lang/String;
    new-instance v4, Landroid/content/Intent;

    iget-object v9, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    check-cast v9, Landroid/app/Activity;

    invoke-virtual {v9}, Landroid/app/Activity;->getApplication()Landroid/app/Application;

    move-result-object v9

    const-class v10, Lcom/thinkware/sundo/inavi3d/ui/AddressSearch;

    invoke-direct {v4, v9, v10}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 4389
    .local v4, "intentSearch":Landroid/content/Intent;
    const-string v9, "ADDR_SEARCH_AINA"

    invoke-virtual {v4, v9, v7}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 4390
    iget-object v9, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    invoke-virtual {v9, v4}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    goto/16 :goto_0

    .line 4393
    .end local v4    # "intentSearch":Landroid/content/Intent;
    .end local v7    # "strQuery":Ljava/lang/String;
    :cond_1f
    invoke-direct {p0, v6, p1}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->onAINAProcessUnitedSearchResult(Ljava/lang/String;Landroid/content/Intent;)V

    goto/16 :goto_0
.end method

.method private onAINAProcessUnitedSearchResult(Ljava/lang/String;Landroid/content/Intent;)V
    .locals 2
    .param p1, "strCommand"    # Ljava/lang/String;
    .param p2, "msg"    # Landroid/content/Intent;

    .prologue
    const/4 v1, 0x1

    .line 4399
    const-string v0, "\uc9c0\uc5ed\uc124\uc815|\ubc18\uacbd\uc124\uc815|\ub2e4\uc2dc\ucc3e\uae30|\uccab\ubc88\uc9f8|\ub450\ubc88\uc9f8|\uc138\ubc88\uc9f8|\ub124\ubc88\uc9f8|\ub2e4\uc12f\ubc88\uc9f8|\uc5ec\uc12f\ubc88\uc9f8|\uc774\uc804\ud398\uc774\uc9c0|\ub2e4\uc74c\ud398\uc774\uc9c0|"

    invoke-virtual {v0, p1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-ne v0, v1, :cond_1

    .line 4400
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v0

    invoke-virtual {v0, p1, p2}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->onAINASearchProcess(Ljava/lang/String;Landroid/content/Intent;)V

    .line 4404
    :cond_0
    :goto_0
    return-void

    .line 4401
    :cond_1
    const-string v0, "\uc804\uad6d|\uacbd\uae30\ub3c4|\uc778\ucc9c|\uc11c\uc6b8|\uac15\uc6d0\ub3c4|\uc138\uc885|\ucda9\uccad\ubd81\ub3c4|\ucda9\uccad\ub0a8\ub3c4|\ub300\uc804|\uacbd\uc0c1\ubd81\ub3c4|\uacbd\uc0c1\ub0a8\ub3c4|\uc804\ub77c\ubd81\ub3c4|\uc804\ub77c\ub0a8\ub3c4|\ub300\uad6c|\uc6b8\uc0b0|\uad11\uc8fc|\ubd80\uc0b0|\uc81c\uc8fc\ub3c4|\ubc18\uacbd\uc77c\ud0a4\ub85c\ubbf8\ud130|\ubc18\uacbd\uc774\ud0a4\ub85c\ubbf8\ud130|\ubc18\uacbd\uc624\ud0a4\ub85c\ubbf8\ud130|\ubc18\uacbd\ud314\ud0a4\ub85c\ubbf8\ud130|\ubc18\uacbd\uc2ed\ud0a4\ub85c\ubbf8\ud130"

    invoke-virtual {v0, p1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-ne v0, v1, :cond_0

    .line 4402
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v0

    invoke-virtual {v0, p1, p2}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->onAINASearchProcess(Ljava/lang/String;Landroid/content/Intent;)V

    goto :goto_0
.end method

.method public static recursiveRecycle(Landroid/view/View;)V
    .locals 5
    .param p0, "root"    # Landroid/view/View;

    .prologue
    const/4 v4, 0x0

    .line 1266
    if-nez p0, :cond_0

    .line 1289
    :goto_0
    return-void

    .line 1270
    :cond_0
    invoke-virtual {p0, v4}, Landroid/view/View;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 1272
    instance-of v3, p0, Landroid/view/ViewGroup;

    if-eqz v3, :cond_2

    move-object v1, p0

    .line 1273
    check-cast v1, Landroid/view/ViewGroup;

    .line 1274
    .local v1, "group":Landroid/view/ViewGroup;
    invoke-virtual {v1}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v0

    .line 1275
    .local v0, "count":I
    const/4 v2, 0x0

    .local v2, "i":I
    :goto_1
    if-ge v2, v0, :cond_1

    .line 1276
    invoke-virtual {v1, v2}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v3

    invoke-static {v3}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->recursiveRecycle(Landroid/view/View;)V

    .line 1275
    add-int/lit8 v2, v2, 0x1

    goto :goto_1

    .line 1278
    :cond_1
    instance-of v3, p0, Landroid/widget/AdapterView;

    if-nez v3, :cond_2

    .line 1279
    invoke-virtual {v1}, Landroid/view/ViewGroup;->removeAllViews()V

    .line 1282
    .end local v0    # "count":I
    .end local v1    # "group":Landroid/view/ViewGroup;
    .end local v2    # "i":I
    :cond_2
    instance-of v3, p0, Landroid/widget/ImageView;

    if-eqz v3, :cond_3

    move-object v3, p0

    .line 1283
    check-cast v3, Landroid/widget/ImageView;

    invoke-virtual {v3, v4}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 1285
    :cond_3
    instance-of v3, p0, Landroid/widget/TextView;

    if-eqz v3, :cond_4

    .line 1286
    check-cast p0, Landroid/widget/TextView;

    .end local p0    # "root":Landroid/view/View;
    const-string v3, ""

    invoke-virtual {p0, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1288
    :cond_4
    const/4 p0, 0x0

    .line 1289
    .restart local p0    # "root":Landroid/view/View;
    goto :goto_0
.end method

.method private sendBroadcastToOBD2(Z)V
    .locals 2
    .param p1, "bIsOverspeed"    # Z

    .prologue
    .line 4830
    new-instance v0, Landroid/content/Intent;

    const-string v1, "com.thinkware.sundo.inavi3d.action.check_overspeed"

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 4831
    .local v0, "intent_overspeed":Landroid/content/Intent;
    const-string v1, "overspeed"

    invoke-virtual {v0, v1, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    .line 4832
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    invoke-virtual {v1, v0}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V

    .line 4833
    return-void
.end method

.method private setExtSolutionRunroute(Landroid/content/Intent;Landroid/content/Context;)V
    .locals 35
    .param p1, "intent"    # Landroid/content/Intent;
    .param p2, "context"    # Landroid/content/Context;

    .prologue
    .line 3120
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v4

    const-wide/16 v6, 0x3e8

    div-long v32, v4, v6

    .line 3123
    .local v32, "tsLong":J
    move-object/from16 v0, p0

    iget-wide v4, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mMsgBlockingkTime:J

    sub-long v10, v32, v4

    .line 3125
    .local v10, "nCap":J
    const-wide/16 v4, 0xa

    cmp-long v4, v10, v4

    if-lez v4, :cond_0

    .line 3127
    move-wide/from16 v0, v32

    move-object/from16 v2, p0

    iput-wide v0, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mMsgBlockingkTime:J

    .line 3135
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v4

    invoke-virtual {v4}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->isRouteResultScene()Z

    move-result v4

    if-eqz v4, :cond_1

    .line 3137
    const-string v4, "solution"

    const-string v5, "\ud0d0\uc0c9\uacb0\uacfc\ud654\uba74\uc785\ub2c8\ub2e4."

    invoke-static {v4, v5}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 3237
    :goto_0
    return-void

    .line 3131
    :cond_0
    const-string v4, "solution"

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "\ud0d0\uc0c9\uc911\uc785\ub2c8\ub2e4. :: "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v10, v11}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-static {v4, v5}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    .line 3149
    :cond_1
    const/4 v4, 0x1

    new-array v0, v4, [I

    move-object/from16 v24, v0

    .line 3150
    .local v24, "nRegX":[I
    const/4 v4, 0x1

    new-array v0, v4, [I

    move-object/from16 v25, v0

    .line 3152
    .local v25, "nRegY":[I
    const/4 v4, 0x1

    new-array v8, v4, [I

    .line 3153
    .local v8, "lon":[I
    const/4 v4, 0x1

    new-array v9, v4, [I

    .line 3155
    .local v9, "lat":[I
    const-string v4, "GOAL1_NAME"

    move-object/from16 v0, p1

    invoke-virtual {v0, v4}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v26

    .line 3157
    .local v26, "strGoalPoint1":Ljava/lang/String;
    const-string v4, "GOAL1_X"

    const-wide/16 v6, 0x0

    move-object/from16 v0, p1

    invoke-virtual {v0, v4, v6, v7}, Landroid/content/Intent;->getDoubleExtra(Ljava/lang/String;D)D

    move-result-wide v4

    double-to-float v0, v4

    move/from16 v18, v0

    .line 3158
    .local v18, "nLon":F
    const-string v4, "GOAL1_Y"

    const-wide/16 v6, 0x0

    move-object/from16 v0, p1

    invoke-virtual {v0, v4, v6, v7}, Landroid/content/Intent;->getDoubleExtra(Ljava/lang/String;D)D

    move-result-wide v4

    double-to-float v12, v4

    .line 3160
    .local v12, "nLat":F
    move/from16 v0, v18

    move-object/from16 v1, v24

    move-object/from16 v2, v25

    invoke-static {v0, v12, v1, v2}, Lcom/tw/mapmatch/HelperFunctions;->WGS84_LongLati2TWNor(FF[I[I)I

    .line 3161
    const/4 v4, 0x0

    aget v4, v24, v4

    int-to-double v4, v4

    const-wide v6, 0x3ff3333333333333L    # 1.2

    mul-double/2addr v4, v6

    const/4 v6, 0x0

    aget v6, v25, v6

    int-to-double v6, v6

    invoke-static/range {v4 .. v9}, Lcom/tw/mapmatch/HelperFunctions;->reg2LonLat(DD[I[I)V

    .line 3163
    const/4 v4, 0x0

    cmpl-float v4, v18, v4

    if-lez v4, :cond_2

    const/4 v4, 0x0

    cmpl-float v4, v12, v4

    if-lez v4, :cond_2

    .line 3165
    const/4 v4, 0x0

    aget v4, v8, v4

    const/4 v5, 0x0

    aget v5, v9, v5

    invoke-static {v4, v5}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetFinishPositionForSolution(II)V

    .line 3168
    :cond_2
    const-string v4, "GOAL2_NAME"

    move-object/from16 v0, p1

    invoke-virtual {v0, v4}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v27

    .line 3170
    .local v27, "strGoalPoint2":Ljava/lang/String;
    const-string v4, "GOAL2_X"

    const-wide/16 v6, 0x0

    move-object/from16 v0, p1

    invoke-virtual {v0, v4, v6, v7}, Landroid/content/Intent;->getDoubleExtra(Ljava/lang/String;D)D

    move-result-wide v4

    double-to-float v0, v4

    move/from16 v19, v0

    .line 3171
    .local v19, "nLon2":F
    const-string v4, "GOAL2_Y"

    const-wide/16 v6, 0x0

    move-object/from16 v0, p1

    invoke-virtual {v0, v4, v6, v7}, Landroid/content/Intent;->getDoubleExtra(Ljava/lang/String;D)D

    move-result-wide v4

    double-to-float v13, v4

    .line 3173
    .local v13, "nLat2":F
    move/from16 v0, v19

    move-object/from16 v1, v24

    move-object/from16 v2, v25

    invoke-static {v0, v13, v1, v2}, Lcom/tw/mapmatch/HelperFunctions;->WGS84_LongLati2TWNor(FF[I[I)I

    .line 3174
    const/4 v4, 0x0

    aget v4, v24, v4

    int-to-double v4, v4

    const-wide v6, 0x3ff3333333333333L    # 1.2

    mul-double/2addr v4, v6

    const/4 v6, 0x0

    aget v6, v25, v6

    int-to-double v6, v6

    invoke-static/range {v4 .. v9}, Lcom/tw/mapmatch/HelperFunctions;->reg2LonLat(DD[I[I)V

    .line 3176
    const/4 v4, 0x0

    cmpl-float v4, v19, v4

    if-lez v4, :cond_3

    const/4 v4, 0x0

    cmpl-float v4, v13, v4

    if-lez v4, :cond_3

    .line 3178
    const/4 v4, 0x0

    aget v4, v8, v4

    const/4 v5, 0x0

    aget v5, v9, v5

    invoke-static {v4, v5}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetFinishPositionForSolution(II)V

    .line 3181
    :cond_3
    const-string v4, "GOAL3_NAME"

    move-object/from16 v0, p1

    invoke-virtual {v0, v4}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v28

    .line 3183
    .local v28, "strGoalPoint3":Ljava/lang/String;
    const-string v4, "GOAL3_X"

    const-wide/16 v6, 0x0

    move-object/from16 v0, p1

    invoke-virtual {v0, v4, v6, v7}, Landroid/content/Intent;->getDoubleExtra(Ljava/lang/String;D)D

    move-result-wide v4

    double-to-float v0, v4

    move/from16 v20, v0

    .line 3184
    .local v20, "nLon3":F
    const-string v4, "GOAL3_Y"

    const-wide/16 v6, 0x0

    move-object/from16 v0, p1

    invoke-virtual {v0, v4, v6, v7}, Landroid/content/Intent;->getDoubleExtra(Ljava/lang/String;D)D

    move-result-wide v4

    double-to-float v14, v4

    .line 3186
    .local v14, "nLat3":F
    move/from16 v0, v20

    move-object/from16 v1, v24

    move-object/from16 v2, v25

    invoke-static {v0, v14, v1, v2}, Lcom/tw/mapmatch/HelperFunctions;->WGS84_LongLati2TWNor(FF[I[I)I

    .line 3187
    const/4 v4, 0x0

    aget v4, v24, v4

    int-to-double v4, v4

    const-wide v6, 0x3ff3333333333333L    # 1.2

    mul-double/2addr v4, v6

    const/4 v6, 0x0

    aget v6, v25, v6

    int-to-double v6, v6

    invoke-static/range {v4 .. v9}, Lcom/tw/mapmatch/HelperFunctions;->reg2LonLat(DD[I[I)V

    .line 3189
    const/4 v4, 0x0

    cmpl-float v4, v20, v4

    if-lez v4, :cond_4

    const/4 v4, 0x0

    cmpl-float v4, v14, v4

    if-lez v4, :cond_4

    .line 3191
    const/4 v4, 0x0

    aget v4, v8, v4

    const/4 v5, 0x0

    aget v5, v9, v5

    invoke-static {v4, v5}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetFinishPositionForSolution(II)V

    .line 3194
    :cond_4
    const-string v4, "GOAL4_NAME"

    move-object/from16 v0, p1

    invoke-virtual {v0, v4}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v29

    .line 3196
    .local v29, "strGoalPoint4":Ljava/lang/String;
    const-string v4, "GOAL4_X"

    const-wide/16 v6, 0x0

    move-object/from16 v0, p1

    invoke-virtual {v0, v4, v6, v7}, Landroid/content/Intent;->getDoubleExtra(Ljava/lang/String;D)D

    move-result-wide v4

    double-to-float v0, v4

    move/from16 v21, v0

    .line 3197
    .local v21, "nLon4":F
    const-string v4, "GOAL4_Y"

    const-wide/16 v6, 0x0

    move-object/from16 v0, p1

    invoke-virtual {v0, v4, v6, v7}, Landroid/content/Intent;->getDoubleExtra(Ljava/lang/String;D)D

    move-result-wide v4

    double-to-float v15, v4

    .line 3199
    .local v15, "nLat4":F
    move/from16 v0, v21

    move-object/from16 v1, v24

    move-object/from16 v2, v25

    invoke-static {v0, v15, v1, v2}, Lcom/tw/mapmatch/HelperFunctions;->WGS84_LongLati2TWNor(FF[I[I)I

    .line 3200
    const/4 v4, 0x0

    aget v4, v24, v4

    int-to-double v4, v4

    const-wide v6, 0x3ff3333333333333L    # 1.2

    mul-double/2addr v4, v6

    const/4 v6, 0x0

    aget v6, v25, v6

    int-to-double v6, v6

    invoke-static/range {v4 .. v9}, Lcom/tw/mapmatch/HelperFunctions;->reg2LonLat(DD[I[I)V

    .line 3202
    const/4 v4, 0x0

    cmpl-float v4, v21, v4

    if-lez v4, :cond_5

    const/4 v4, 0x0

    cmpl-float v4, v15, v4

    if-lez v4, :cond_5

    .line 3204
    const/4 v4, 0x0

    aget v4, v8, v4

    const/4 v5, 0x0

    aget v5, v9, v5

    invoke-static {v4, v5}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetFinishPositionForSolution(II)V

    .line 3207
    :cond_5
    const-string v4, "GOAL5_NAME"

    move-object/from16 v0, p1

    invoke-virtual {v0, v4}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v30

    .line 3209
    .local v30, "strGoalPoint5":Ljava/lang/String;
    const-string v4, "GOAL5_X"

    const-wide/16 v6, 0x0

    move-object/from16 v0, p1

    invoke-virtual {v0, v4, v6, v7}, Landroid/content/Intent;->getDoubleExtra(Ljava/lang/String;D)D

    move-result-wide v4

    double-to-float v0, v4

    move/from16 v22, v0

    .line 3210
    .local v22, "nLon5":F
    const-string v4, "GOAL5_Y"

    const-wide/16 v6, 0x0

    move-object/from16 v0, p1

    invoke-virtual {v0, v4, v6, v7}, Landroid/content/Intent;->getDoubleExtra(Ljava/lang/String;D)D

    move-result-wide v4

    double-to-float v0, v4

    move/from16 v16, v0

    .line 3212
    .local v16, "nLat5":F
    move/from16 v0, v22

    move/from16 v1, v16

    move-object/from16 v2, v24

    move-object/from16 v3, v25

    invoke-static {v0, v1, v2, v3}, Lcom/tw/mapmatch/HelperFunctions;->WGS84_LongLati2TWNor(FF[I[I)I

    .line 3213
    const/4 v4, 0x0

    aget v4, v24, v4

    int-to-double v4, v4

    const-wide v6, 0x3ff3333333333333L    # 1.2

    mul-double/2addr v4, v6

    const/4 v6, 0x0

    aget v6, v25, v6

    int-to-double v6, v6

    invoke-static/range {v4 .. v9}, Lcom/tw/mapmatch/HelperFunctions;->reg2LonLat(DD[I[I)V

    .line 3215
    const/4 v4, 0x0

    cmpl-float v4, v22, v4

    if-lez v4, :cond_6

    const/4 v4, 0x0

    cmpl-float v4, v16, v4

    if-lez v4, :cond_6

    .line 3217
    const/4 v4, 0x0

    aget v4, v8, v4

    const/4 v5, 0x0

    aget v5, v9, v5

    invoke-static {v4, v5}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetFinishPositionForSolution(II)V

    .line 3220
    :cond_6
    const-string v4, "GOAL6_NAME"

    move-object/from16 v0, p1

    invoke-virtual {v0, v4}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v31

    .line 3222
    .local v31, "strGoalPoint6":Ljava/lang/String;
    const-string v4, "GOAL6_X"

    const-wide/16 v6, 0x0

    move-object/from16 v0, p1

    invoke-virtual {v0, v4, v6, v7}, Landroid/content/Intent;->getDoubleExtra(Ljava/lang/String;D)D

    move-result-wide v4

    double-to-float v0, v4

    move/from16 v23, v0

    .line 3223
    .local v23, "nLon6":F
    const-string v4, "GOAL6_Y"

    const-wide/16 v6, 0x0

    move-object/from16 v0, p1

    invoke-virtual {v0, v4, v6, v7}, Landroid/content/Intent;->getDoubleExtra(Ljava/lang/String;D)D

    move-result-wide v4

    double-to-float v0, v4

    move/from16 v17, v0

    .line 3225
    .local v17, "nLat6":F
    move/from16 v0, v23

    move/from16 v1, v17

    move-object/from16 v2, v24

    move-object/from16 v3, v25

    invoke-static {v0, v1, v2, v3}, Lcom/tw/mapmatch/HelperFunctions;->WGS84_LongLati2TWNor(FF[I[I)I

    .line 3226
    const/4 v4, 0x0

    aget v4, v24, v4

    int-to-double v4, v4

    const-wide v6, 0x3ff3333333333333L    # 1.2

    mul-double/2addr v4, v6

    const/4 v6, 0x0

    aget v6, v25, v6

    int-to-double v6, v6

    invoke-static/range {v4 .. v9}, Lcom/tw/mapmatch/HelperFunctions;->reg2LonLat(DD[I[I)V

    .line 3228
    const/4 v4, 0x0

    cmpl-float v4, v23, v4

    if-lez v4, :cond_7

    const/4 v4, 0x0

    cmpl-float v4, v17, v4

    if-lez v4, :cond_7

    .line 3230
    const/4 v4, 0x0

    aget v4, v8, v4

    const/4 v5, 0x0

    aget v5, v9, v5

    invoke-static {v4, v5}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetFinishPositionForSolution(II)V

    .line 3233
    :cond_7
    sget-object v4, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->inavi_reference:Lcom/thinkware/sundo/inavi3d/Inavi;

    const v5, 0x222e0

    const v6, 0x222eb

    const/4 v7, 0x0

    const/16 v34, 0x0

    move/from16 v0, v34

    invoke-virtual {v4, v5, v6, v7, v0}, Lcom/thinkware/sundo/inavi3d/Inavi;->PushMessage(IIII)V

    goto/16 :goto_0
.end method

.method private setExtSolutionRunroutenow(Landroid/content/Intent;Landroid/content/Context;)V
    .locals 38
    .param p1, "intent"    # Landroid/content/Intent;
    .param p2, "context"    # Landroid/content/Context;

    .prologue
    .line 3370
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v4

    const-wide/16 v6, 0x3e8

    div-long v36, v4, v6

    .line 3373
    .local v36, "tsLong":J
    move-object/from16 v0, p0

    iget-wide v4, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mMsgBlockingkTime:J

    sub-long v10, v36, v4

    .line 3375
    .local v10, "nCap":J
    const-wide/16 v4, 0xa

    cmp-long v4, v10, v4

    if-lez v4, :cond_0

    .line 3377
    move-wide/from16 v0, v36

    move-object/from16 v2, p0

    iput-wide v0, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mMsgBlockingkTime:J

    .line 3385
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v4

    invoke-virtual {v4}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->isRouteResultScene()Z

    move-result v4

    if-eqz v4, :cond_1

    .line 3387
    const-string v4, "solution"

    const-string v5, "\ud0d0\uc0c9\uacb0\uacfc\ud654\uba74\uc785\ub2c8\ub2e4."

    invoke-static {v4, v5}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 3494
    :goto_0
    return-void

    .line 3381
    :cond_0
    const-string v4, "solution"

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "\ud0d0\uc0c9\uc911\uc785\ub2c8\ub2e4. :: "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v10, v11}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-static {v4, v5}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    .line 3393
    :cond_1
    const/4 v4, 0x6

    new-array v0, v4, [I

    move-object/from16 v27, v0

    .line 3394
    .local v27, "nX":[I
    const/4 v4, 0x6

    new-array v0, v4, [I

    move-object/from16 v28, v0

    .line 3396
    .local v28, "nY":[I
    const/4 v4, 0x1

    new-array v0, v4, [I

    move-object/from16 v25, v0

    .line 3397
    .local v25, "nRegX":[I
    const/4 v4, 0x1

    new-array v0, v4, [I

    move-object/from16 v26, v0

    .line 3398
    .local v26, "nRegY":[I
    const/4 v4, 0x1

    new-array v8, v4, [I

    .line 3399
    .local v8, "lon":[I
    const/4 v4, 0x1

    new-array v9, v4, [I

    .line 3401
    .local v9, "lat":[I
    const/4 v12, 0x0

    .line 3402
    .local v12, "nCnt":I
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v4

    const/4 v5, 0x1

    iput-boolean v5, v4, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->mbRunRouteNow:Z

    .line 3404
    const-string v4, "GOAL1_NAME"

    move-object/from16 v0, p1

    invoke-virtual {v0, v4}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v29

    .line 3406
    .local v29, "strGoalPoint1":Ljava/lang/String;
    const-string v4, "GOAL1_X"

    const-wide/16 v6, 0x0

    move-object/from16 v0, p1

    invoke-virtual {v0, v4, v6, v7}, Landroid/content/Intent;->getDoubleExtra(Ljava/lang/String;D)D

    move-result-wide v4

    double-to-float v0, v4

    move/from16 v19, v0

    .line 3407
    .local v19, "nLon":F
    const-string v4, "GOAL1_Y"

    const-wide/16 v6, 0x0

    move-object/from16 v0, p1

    invoke-virtual {v0, v4, v6, v7}, Landroid/content/Intent;->getDoubleExtra(Ljava/lang/String;D)D

    move-result-wide v4

    double-to-float v13, v4

    .line 3408
    .local v13, "nLat":F
    move/from16 v0, v19

    move-object/from16 v1, v25

    move-object/from16 v2, v26

    invoke-static {v0, v13, v1, v2}, Lcom/tw/mapmatch/HelperFunctions;->WGS84_LongLati2TWNor(FF[I[I)I

    .line 3409
    const/4 v4, 0x0

    aget v4, v25, v4

    int-to-double v4, v4

    const-wide v6, 0x3ff3333333333333L    # 1.2

    mul-double/2addr v4, v6

    const/4 v6, 0x0

    aget v6, v26, v6

    int-to-double v6, v6

    invoke-static/range {v4 .. v9}, Lcom/tw/mapmatch/HelperFunctions;->reg2LonLat(DD[I[I)V

    .line 3411
    const/4 v4, 0x0

    cmpl-float v4, v19, v4

    if-lez v4, :cond_2

    const/4 v4, 0x0

    cmpl-float v4, v13, v4

    if-lez v4, :cond_2

    .line 3413
    const/4 v4, 0x0

    aget v4, v8, v4

    aput v4, v27, v12

    .line 3414
    const/4 v4, 0x0

    aget v4, v9, v4

    aput v4, v28, v12

    .line 3415
    add-int/lit8 v12, v12, 0x1

    .line 3420
    :cond_2
    const-string v4, "GOAL2_NAME"

    move-object/from16 v0, p1

    invoke-virtual {v0, v4}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v30

    .line 3424
    .local v30, "strGoalPoint2":Ljava/lang/String;
    const-string v4, "GOAL2_X"

    const-wide/16 v6, 0x0

    move-object/from16 v0, p1

    invoke-virtual {v0, v4, v6, v7}, Landroid/content/Intent;->getDoubleExtra(Ljava/lang/String;D)D

    move-result-wide v4

    double-to-float v0, v4

    move/from16 v20, v0

    .line 3425
    .local v20, "nLon2":F
    const-string v4, "GOAL2_Y"

    const-wide/16 v6, 0x0

    move-object/from16 v0, p1

    invoke-virtual {v0, v4, v6, v7}, Landroid/content/Intent;->getDoubleExtra(Ljava/lang/String;D)D

    move-result-wide v4

    double-to-float v14, v4

    .line 3426
    .local v14, "nLat2":F
    move/from16 v0, v20

    move-object/from16 v1, v25

    move-object/from16 v2, v26

    invoke-static {v0, v14, v1, v2}, Lcom/tw/mapmatch/HelperFunctions;->WGS84_LongLati2TWNor(FF[I[I)I

    .line 3427
    const/4 v4, 0x0

    aget v4, v25, v4

    int-to-double v4, v4

    const-wide v6, 0x3ff3333333333333L    # 1.2

    mul-double/2addr v4, v6

    const/4 v6, 0x0

    aget v6, v26, v6

    int-to-double v6, v6

    invoke-static/range {v4 .. v9}, Lcom/tw/mapmatch/HelperFunctions;->reg2LonLat(DD[I[I)V

    .line 3428
    const/4 v4, 0x0

    cmpl-float v4, v20, v4

    if-lez v4, :cond_3

    const/4 v4, 0x0

    cmpl-float v4, v14, v4

    if-lez v4, :cond_3

    .line 3430
    const/4 v4, 0x0

    aget v4, v8, v4

    aput v4, v27, v12

    .line 3431
    const/4 v4, 0x0

    aget v4, v9, v4

    aput v4, v28, v12

    .line 3432
    add-int/lit8 v12, v12, 0x1

    .line 3436
    :cond_3
    const-string v4, "GOAL3_NAME"

    move-object/from16 v0, p1

    invoke-virtual {v0, v4}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v31

    .line 3439
    .local v31, "strGoalPoint3":Ljava/lang/String;
    const-string v4, "GOAL3_X"

    const-wide/16 v6, 0x0

    move-object/from16 v0, p1

    invoke-virtual {v0, v4, v6, v7}, Landroid/content/Intent;->getDoubleExtra(Ljava/lang/String;D)D

    move-result-wide v4

    double-to-float v0, v4

    move/from16 v21, v0

    .line 3440
    .local v21, "nLon3":F
    const-string v4, "GOAL3_Y"

    const-wide/16 v6, 0x0

    move-object/from16 v0, p1

    invoke-virtual {v0, v4, v6, v7}, Landroid/content/Intent;->getDoubleExtra(Ljava/lang/String;D)D

    move-result-wide v4

    double-to-float v15, v4

    .line 3441
    .local v15, "nLat3":F
    move/from16 v0, v21

    move-object/from16 v1, v25

    move-object/from16 v2, v26

    invoke-static {v0, v15, v1, v2}, Lcom/tw/mapmatch/HelperFunctions;->WGS84_LongLati2TWNor(FF[I[I)I

    .line 3442
    const/4 v4, 0x0

    aget v4, v25, v4

    int-to-double v4, v4

    const-wide v6, 0x3ff3333333333333L    # 1.2

    mul-double/2addr v4, v6

    const/4 v6, 0x0

    aget v6, v26, v6

    int-to-double v6, v6

    invoke-static/range {v4 .. v9}, Lcom/tw/mapmatch/HelperFunctions;->reg2LonLat(DD[I[I)V

    .line 3443
    const/4 v4, 0x0

    cmpl-float v4, v21, v4

    if-lez v4, :cond_4

    const/4 v4, 0x0

    cmpl-float v4, v15, v4

    if-lez v4, :cond_4

    .line 3445
    const/4 v4, 0x0

    aget v4, v8, v4

    aput v4, v27, v12

    .line 3446
    const/4 v4, 0x0

    aget v4, v9, v4

    aput v4, v28, v12

    .line 3447
    add-int/lit8 v12, v12, 0x1

    .line 3450
    :cond_4
    const-string v4, "GOAL4_NAME"

    move-object/from16 v0, p1

    invoke-virtual {v0, v4}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v32

    .line 3453
    .local v32, "strGoalPoint4":Ljava/lang/String;
    const-string v4, "GOAL4_X"

    const-wide/16 v6, 0x0

    move-object/from16 v0, p1

    invoke-virtual {v0, v4, v6, v7}, Landroid/content/Intent;->getDoubleExtra(Ljava/lang/String;D)D

    move-result-wide v4

    double-to-float v0, v4

    move/from16 v22, v0

    .line 3454
    .local v22, "nLon4":F
    const-string v4, "GOAL4_Y"

    const-wide/16 v6, 0x0

    move-object/from16 v0, p1

    invoke-virtual {v0, v4, v6, v7}, Landroid/content/Intent;->getDoubleExtra(Ljava/lang/String;D)D

    move-result-wide v4

    double-to-float v0, v4

    move/from16 v16, v0

    .line 3455
    .local v16, "nLat4":F
    move/from16 v0, v22

    move/from16 v1, v16

    move-object/from16 v2, v25

    move-object/from16 v3, v26

    invoke-static {v0, v1, v2, v3}, Lcom/tw/mapmatch/HelperFunctions;->WGS84_LongLati2TWNor(FF[I[I)I

    .line 3456
    const/4 v4, 0x0

    aget v4, v25, v4

    int-to-double v4, v4

    const-wide v6, 0x3ff3333333333333L    # 1.2

    mul-double/2addr v4, v6

    const/4 v6, 0x0

    aget v6, v26, v6

    int-to-double v6, v6

    invoke-static/range {v4 .. v9}, Lcom/tw/mapmatch/HelperFunctions;->reg2LonLat(DD[I[I)V

    .line 3457
    const/4 v4, 0x0

    cmpl-float v4, v22, v4

    if-lez v4, :cond_5

    const/4 v4, 0x0

    cmpl-float v4, v16, v4

    if-lez v4, :cond_5

    .line 3459
    const/4 v4, 0x0

    aget v4, v8, v4

    aput v4, v27, v12

    .line 3460
    const/4 v4, 0x0

    aget v4, v9, v4

    aput v4, v28, v12

    .line 3461
    add-int/lit8 v12, v12, 0x1

    .line 3465
    :cond_5
    const-string v4, "GOAL5_NAME"

    move-object/from16 v0, p1

    invoke-virtual {v0, v4}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v33

    .line 3468
    .local v33, "strGoalPoint5":Ljava/lang/String;
    const-string v4, "GOAL5_X"

    const-wide/16 v6, 0x0

    move-object/from16 v0, p1

    invoke-virtual {v0, v4, v6, v7}, Landroid/content/Intent;->getDoubleExtra(Ljava/lang/String;D)D

    move-result-wide v4

    double-to-float v0, v4

    move/from16 v23, v0

    .line 3469
    .local v23, "nLon5":F
    const-string v4, "GOAL5_Y"

    const-wide/16 v6, 0x0

    move-object/from16 v0, p1

    invoke-virtual {v0, v4, v6, v7}, Landroid/content/Intent;->getDoubleExtra(Ljava/lang/String;D)D

    move-result-wide v4

    double-to-float v0, v4

    move/from16 v17, v0

    .line 3470
    .local v17, "nLat5":F
    move/from16 v0, v23

    move/from16 v1, v17

    move-object/from16 v2, v25

    move-object/from16 v3, v26

    invoke-static {v0, v1, v2, v3}, Lcom/tw/mapmatch/HelperFunctions;->WGS84_LongLati2TWNor(FF[I[I)I

    .line 3471
    const/4 v4, 0x0

    aget v4, v25, v4

    int-to-double v4, v4

    const-wide v6, 0x3ff3333333333333L    # 1.2

    mul-double/2addr v4, v6

    const/4 v6, 0x0

    aget v6, v26, v6

    int-to-double v6, v6

    invoke-static/range {v4 .. v9}, Lcom/tw/mapmatch/HelperFunctions;->reg2LonLat(DD[I[I)V

    .line 3472
    const/4 v4, 0x0

    cmpl-float v4, v23, v4

    if-lez v4, :cond_6

    const/4 v4, 0x0

    cmpl-float v4, v17, v4

    if-lez v4, :cond_6

    .line 3474
    const/4 v4, 0x0

    aget v4, v8, v4

    aput v4, v27, v12

    .line 3475
    const/4 v4, 0x0

    aget v4, v9, v4

    aput v4, v28, v12

    .line 3476
    add-int/lit8 v12, v12, 0x1

    .line 3479
    :cond_6
    const-string v4, "GOAL6_NAME"

    move-object/from16 v0, p1

    invoke-virtual {v0, v4}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v34

    .line 3482
    .local v34, "strGoalPoint6":Ljava/lang/String;
    const-string v4, "GOAL6_X"

    const-wide/16 v6, 0x0

    move-object/from16 v0, p1

    invoke-virtual {v0, v4, v6, v7}, Landroid/content/Intent;->getDoubleExtra(Ljava/lang/String;D)D

    move-result-wide v4

    double-to-float v0, v4

    move/from16 v24, v0

    .line 3483
    .local v24, "nLon6":F
    const-string v4, "GOAL6_Y"

    const-wide/16 v6, 0x0

    move-object/from16 v0, p1

    invoke-virtual {v0, v4, v6, v7}, Landroid/content/Intent;->getDoubleExtra(Ljava/lang/String;D)D

    move-result-wide v4

    double-to-float v0, v4

    move/from16 v18, v0

    .line 3484
    .local v18, "nLat6":F
    move/from16 v0, v24

    move/from16 v1, v18

    move-object/from16 v2, v25

    move-object/from16 v3, v26

    invoke-static {v0, v1, v2, v3}, Lcom/tw/mapmatch/HelperFunctions;->WGS84_LongLati2TWNor(FF[I[I)I

    .line 3485
    const/4 v4, 0x0

    aget v4, v25, v4

    int-to-double v4, v4

    const-wide v6, 0x3ff3333333333333L    # 1.2

    mul-double/2addr v4, v6

    const/4 v6, 0x0

    aget v6, v26, v6

    int-to-double v6, v6

    invoke-static/range {v4 .. v9}, Lcom/tw/mapmatch/HelperFunctions;->reg2LonLat(DD[I[I)V

    .line 3486
    const/4 v4, 0x0

    cmpl-float v4, v24, v4

    if-lez v4, :cond_7

    const/4 v4, 0x0

    cmpl-float v4, v18, v4

    if-lez v4, :cond_7

    .line 3488
    const/4 v4, 0x0

    aget v4, v8, v4

    aput v4, v27, v12

    .line 3489
    const/4 v4, 0x0

    aget v4, v9, v4

    aput v4, v28, v12

    .line 3490
    add-int/lit8 v12, v12, 0x1

    .line 3493
    :cond_7
    const v4, 0x2265b

    move-object/from16 v0, v27

    move-object/from16 v1, v28

    invoke-static {v4, v12, v0, v1}, Lcom/thinkware/sundo/inavi3d/Inavi;->NonePopupRunRouteForSolution(II[I[I)V

    goto/16 :goto_0
.end method

.method private setExtSolutionRunroutepassui(Landroid/content/Intent;Landroid/content/Context;)V
    .locals 38
    .param p1, "intent"    # Landroid/content/Intent;
    .param p2, "context"    # Landroid/content/Context;

    .prologue
    .line 3241
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v4

    const-wide/16 v6, 0x3e8

    div-long v36, v4, v6

    .line 3244
    .local v36, "tsLong":J
    move-object/from16 v0, p0

    iget-wide v4, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mMsgBlockingkTime:J

    sub-long v10, v36, v4

    .line 3246
    .local v10, "nCap":J
    const-wide/16 v4, 0xa

    cmp-long v4, v10, v4

    if-lez v4, :cond_0

    .line 3248
    move-wide/from16 v0, v36

    move-object/from16 v2, p0

    iput-wide v0, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mMsgBlockingkTime:J

    .line 3256
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v4

    invoke-virtual {v4}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->isRouteResultScene()Z

    move-result v4

    if-eqz v4, :cond_1

    .line 3258
    const-string v4, "solution"

    const-string v5, "\ud0d0\uc0c9\uacb0\uacfc\ud654\uba74\uc785\ub2c8\ub2e4."

    invoke-static {v4, v5}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 3366
    :goto_0
    return-void

    .line 3252
    :cond_0
    const-string v4, "solution"

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "\ud0d0\uc0c9\uc911\uc785\ub2c8\ub2e4. :: "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v10, v11}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-static {v4, v5}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    .line 3263
    :cond_1
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v4

    const/4 v5, 0x1

    iput-boolean v5, v4, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->mPassRouteReslutPage:Z

    .line 3265
    const/4 v4, 0x6

    new-array v0, v4, [I

    move-object/from16 v27, v0

    .line 3266
    .local v27, "nX":[I
    const/4 v4, 0x6

    new-array v0, v4, [I

    move-object/from16 v28, v0

    .line 3268
    .local v28, "nY":[I
    const/4 v4, 0x1

    new-array v0, v4, [I

    move-object/from16 v25, v0

    .line 3269
    .local v25, "nRegX":[I
    const/4 v4, 0x1

    new-array v0, v4, [I

    move-object/from16 v26, v0

    .line 3270
    .local v26, "nRegY":[I
    const/4 v4, 0x1

    new-array v8, v4, [I

    .line 3271
    .local v8, "lon":[I
    const/4 v4, 0x1

    new-array v9, v4, [I

    .line 3273
    .local v9, "lat":[I
    const/4 v12, 0x0

    .line 3274
    .local v12, "nCnt":I
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v4

    const/4 v5, 0x1

    iput-boolean v5, v4, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->mbRunRouteNow:Z

    .line 3276
    const-string v4, "GOAL1_NAME"

    move-object/from16 v0, p1

    invoke-virtual {v0, v4}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v29

    .line 3279
    .local v29, "strGoalPoint1":Ljava/lang/String;
    const-string v4, "GOAL1_X"

    const-wide/16 v6, 0x0

    move-object/from16 v0, p1

    invoke-virtual {v0, v4, v6, v7}, Landroid/content/Intent;->getDoubleExtra(Ljava/lang/String;D)D

    move-result-wide v4

    double-to-float v0, v4

    move/from16 v19, v0

    .line 3280
    .local v19, "nLon":F
    const-string v4, "GOAL1_Y"

    const-wide/16 v6, 0x0

    move-object/from16 v0, p1

    invoke-virtual {v0, v4, v6, v7}, Landroid/content/Intent;->getDoubleExtra(Ljava/lang/String;D)D

    move-result-wide v4

    double-to-float v13, v4

    .line 3281
    .local v13, "nLat":F
    move/from16 v0, v19

    move-object/from16 v1, v25

    move-object/from16 v2, v26

    invoke-static {v0, v13, v1, v2}, Lcom/tw/mapmatch/HelperFunctions;->WGS84_LongLati2TWNor(FF[I[I)I

    .line 3282
    const/4 v4, 0x0

    aget v4, v25, v4

    int-to-double v4, v4

    const-wide v6, 0x3ff3333333333333L    # 1.2

    mul-double/2addr v4, v6

    const/4 v6, 0x0

    aget v6, v26, v6

    int-to-double v6, v6

    invoke-static/range {v4 .. v9}, Lcom/tw/mapmatch/HelperFunctions;->reg2LonLat(DD[I[I)V

    .line 3284
    const/4 v4, 0x0

    cmpl-float v4, v19, v4

    if-lez v4, :cond_2

    const/4 v4, 0x0

    cmpl-float v4, v13, v4

    if-lez v4, :cond_2

    .line 3286
    const/4 v4, 0x0

    aget v4, v8, v4

    aput v4, v27, v12

    .line 3287
    const/4 v4, 0x0

    aget v4, v9, v4

    aput v4, v28, v12

    .line 3288
    add-int/lit8 v12, v12, 0x1

    .line 3292
    :cond_2
    const-string v4, "GOAL2_NAME"

    move-object/from16 v0, p1

    invoke-virtual {v0, v4}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v30

    .line 3296
    .local v30, "strGoalPoint2":Ljava/lang/String;
    const-string v4, "GOAL2_X"

    const-wide/16 v6, 0x0

    move-object/from16 v0, p1

    invoke-virtual {v0, v4, v6, v7}, Landroid/content/Intent;->getDoubleExtra(Ljava/lang/String;D)D

    move-result-wide v4

    double-to-float v0, v4

    move/from16 v20, v0

    .line 3297
    .local v20, "nLon2":F
    const-string v4, "GOAL2_Y"

    const-wide/16 v6, 0x0

    move-object/from16 v0, p1

    invoke-virtual {v0, v4, v6, v7}, Landroid/content/Intent;->getDoubleExtra(Ljava/lang/String;D)D

    move-result-wide v4

    double-to-float v14, v4

    .line 3298
    .local v14, "nLat2":F
    move/from16 v0, v20

    move-object/from16 v1, v25

    move-object/from16 v2, v26

    invoke-static {v0, v14, v1, v2}, Lcom/tw/mapmatch/HelperFunctions;->WGS84_LongLati2TWNor(FF[I[I)I

    .line 3299
    const/4 v4, 0x0

    aget v4, v25, v4

    int-to-double v4, v4

    const-wide v6, 0x3ff3333333333333L    # 1.2

    mul-double/2addr v4, v6

    const/4 v6, 0x0

    aget v6, v26, v6

    int-to-double v6, v6

    invoke-static/range {v4 .. v9}, Lcom/tw/mapmatch/HelperFunctions;->reg2LonLat(DD[I[I)V

    .line 3300
    const/4 v4, 0x0

    cmpl-float v4, v20, v4

    if-lez v4, :cond_3

    const/4 v4, 0x0

    cmpl-float v4, v14, v4

    if-lez v4, :cond_3

    .line 3302
    const/4 v4, 0x0

    aget v4, v8, v4

    aput v4, v27, v12

    .line 3303
    const/4 v4, 0x0

    aget v4, v9, v4

    aput v4, v28, v12

    .line 3304
    add-int/lit8 v12, v12, 0x1

    .line 3308
    :cond_3
    const-string v4, "GOAL3_NAME"

    move-object/from16 v0, p1

    invoke-virtual {v0, v4}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v31

    .line 3311
    .local v31, "strGoalPoint3":Ljava/lang/String;
    const-string v4, "GOAL3_X"

    const-wide/16 v6, 0x0

    move-object/from16 v0, p1

    invoke-virtual {v0, v4, v6, v7}, Landroid/content/Intent;->getDoubleExtra(Ljava/lang/String;D)D

    move-result-wide v4

    double-to-float v0, v4

    move/from16 v21, v0

    .line 3312
    .local v21, "nLon3":F
    const-string v4, "GOAL3_Y"

    const-wide/16 v6, 0x0

    move-object/from16 v0, p1

    invoke-virtual {v0, v4, v6, v7}, Landroid/content/Intent;->getDoubleExtra(Ljava/lang/String;D)D

    move-result-wide v4

    double-to-float v15, v4

    .line 3313
    .local v15, "nLat3":F
    move/from16 v0, v21

    move-object/from16 v1, v25

    move-object/from16 v2, v26

    invoke-static {v0, v15, v1, v2}, Lcom/tw/mapmatch/HelperFunctions;->WGS84_LongLati2TWNor(FF[I[I)I

    .line 3314
    const/4 v4, 0x0

    aget v4, v25, v4

    int-to-double v4, v4

    const-wide v6, 0x3ff3333333333333L    # 1.2

    mul-double/2addr v4, v6

    const/4 v6, 0x0

    aget v6, v26, v6

    int-to-double v6, v6

    invoke-static/range {v4 .. v9}, Lcom/tw/mapmatch/HelperFunctions;->reg2LonLat(DD[I[I)V

    .line 3315
    const/4 v4, 0x0

    cmpl-float v4, v21, v4

    if-lez v4, :cond_4

    const/4 v4, 0x0

    cmpl-float v4, v15, v4

    if-lez v4, :cond_4

    .line 3317
    const/4 v4, 0x0

    aget v4, v8, v4

    aput v4, v27, v12

    .line 3318
    const/4 v4, 0x0

    aget v4, v9, v4

    aput v4, v28, v12

    .line 3319
    add-int/lit8 v12, v12, 0x1

    .line 3323
    :cond_4
    const-string v4, "GOAL4_NAME"

    move-object/from16 v0, p1

    invoke-virtual {v0, v4}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v32

    .line 3326
    .local v32, "strGoalPoint4":Ljava/lang/String;
    const-string v4, "GOAL4_X"

    const-wide/16 v6, 0x0

    move-object/from16 v0, p1

    invoke-virtual {v0, v4, v6, v7}, Landroid/content/Intent;->getDoubleExtra(Ljava/lang/String;D)D

    move-result-wide v4

    double-to-float v0, v4

    move/from16 v22, v0

    .line 3327
    .local v22, "nLon4":F
    const-string v4, "GOAL4_Y"

    const-wide/16 v6, 0x0

    move-object/from16 v0, p1

    invoke-virtual {v0, v4, v6, v7}, Landroid/content/Intent;->getDoubleExtra(Ljava/lang/String;D)D

    move-result-wide v4

    double-to-float v0, v4

    move/from16 v16, v0

    .line 3328
    .local v16, "nLat4":F
    move/from16 v0, v22

    move/from16 v1, v16

    move-object/from16 v2, v25

    move-object/from16 v3, v26

    invoke-static {v0, v1, v2, v3}, Lcom/tw/mapmatch/HelperFunctions;->WGS84_LongLati2TWNor(FF[I[I)I

    .line 3329
    const/4 v4, 0x0

    aget v4, v25, v4

    int-to-double v4, v4

    const-wide v6, 0x3ff3333333333333L    # 1.2

    mul-double/2addr v4, v6

    const/4 v6, 0x0

    aget v6, v26, v6

    int-to-double v6, v6

    invoke-static/range {v4 .. v9}, Lcom/tw/mapmatch/HelperFunctions;->reg2LonLat(DD[I[I)V

    .line 3330
    const/4 v4, 0x0

    cmpl-float v4, v22, v4

    if-lez v4, :cond_5

    const/4 v4, 0x0

    cmpl-float v4, v16, v4

    if-lez v4, :cond_5

    .line 3332
    const/4 v4, 0x0

    aget v4, v8, v4

    aput v4, v27, v12

    .line 3333
    const/4 v4, 0x0

    aget v4, v9, v4

    aput v4, v28, v12

    .line 3334
    add-int/lit8 v12, v12, 0x1

    .line 3337
    :cond_5
    const-string v4, "GOAL5_NAME"

    move-object/from16 v0, p1

    invoke-virtual {v0, v4}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v33

    .line 3340
    .local v33, "strGoalPoint5":Ljava/lang/String;
    const-string v4, "GOAL5_X"

    const-wide/16 v6, 0x0

    move-object/from16 v0, p1

    invoke-virtual {v0, v4, v6, v7}, Landroid/content/Intent;->getDoubleExtra(Ljava/lang/String;D)D

    move-result-wide v4

    double-to-float v0, v4

    move/from16 v23, v0

    .line 3341
    .local v23, "nLon5":F
    const-string v4, "GOAL5_Y"

    const-wide/16 v6, 0x0

    move-object/from16 v0, p1

    invoke-virtual {v0, v4, v6, v7}, Landroid/content/Intent;->getDoubleExtra(Ljava/lang/String;D)D

    move-result-wide v4

    double-to-float v0, v4

    move/from16 v17, v0

    .line 3342
    .local v17, "nLat5":F
    move/from16 v0, v23

    move/from16 v1, v17

    move-object/from16 v2, v25

    move-object/from16 v3, v26

    invoke-static {v0, v1, v2, v3}, Lcom/tw/mapmatch/HelperFunctions;->WGS84_LongLati2TWNor(FF[I[I)I

    .line 3343
    const/4 v4, 0x0

    aget v4, v25, v4

    int-to-double v4, v4

    const-wide v6, 0x3ff3333333333333L    # 1.2

    mul-double/2addr v4, v6

    const/4 v6, 0x0

    aget v6, v26, v6

    int-to-double v6, v6

    invoke-static/range {v4 .. v9}, Lcom/tw/mapmatch/HelperFunctions;->reg2LonLat(DD[I[I)V

    .line 3344
    const/4 v4, 0x0

    cmpl-float v4, v23, v4

    if-lez v4, :cond_6

    const/4 v4, 0x0

    cmpl-float v4, v17, v4

    if-lez v4, :cond_6

    .line 3346
    const/4 v4, 0x0

    aget v4, v8, v4

    aput v4, v27, v12

    .line 3347
    const/4 v4, 0x0

    aget v4, v9, v4

    aput v4, v28, v12

    .line 3348
    add-int/lit8 v12, v12, 0x1

    .line 3351
    :cond_6
    const-string v4, "GOAL6_NAME"

    move-object/from16 v0, p1

    invoke-virtual {v0, v4}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v34

    .line 3354
    .local v34, "strGoalPoint6":Ljava/lang/String;
    const-string v4, "GOAL6_X"

    const-wide/16 v6, 0x0

    move-object/from16 v0, p1

    invoke-virtual {v0, v4, v6, v7}, Landroid/content/Intent;->getDoubleExtra(Ljava/lang/String;D)D

    move-result-wide v4

    double-to-float v0, v4

    move/from16 v24, v0

    .line 3355
    .local v24, "nLon6":F
    const-string v4, "GOAL6_Y"

    const-wide/16 v6, 0x0

    move-object/from16 v0, p1

    invoke-virtual {v0, v4, v6, v7}, Landroid/content/Intent;->getDoubleExtra(Ljava/lang/String;D)D

    move-result-wide v4

    double-to-float v0, v4

    move/from16 v18, v0

    .line 3356
    .local v18, "nLat6":F
    move/from16 v0, v24

    move/from16 v1, v18

    move-object/from16 v2, v25

    move-object/from16 v3, v26

    invoke-static {v0, v1, v2, v3}, Lcom/tw/mapmatch/HelperFunctions;->WGS84_LongLati2TWNor(FF[I[I)I

    .line 3357
    const/4 v4, 0x0

    aget v4, v25, v4

    int-to-double v4, v4

    const-wide v6, 0x3ff3333333333333L    # 1.2

    mul-double/2addr v4, v6

    const/4 v6, 0x0

    aget v6, v26, v6

    int-to-double v6, v6

    invoke-static/range {v4 .. v9}, Lcom/tw/mapmatch/HelperFunctions;->reg2LonLat(DD[I[I)V

    .line 3358
    const/4 v4, 0x0

    cmpl-float v4, v24, v4

    if-lez v4, :cond_7

    const/4 v4, 0x0

    cmpl-float v4, v18, v4

    if-lez v4, :cond_7

    .line 3360
    const/4 v4, 0x0

    aget v4, v8, v4

    aput v4, v27, v12

    .line 3361
    const/4 v4, 0x0

    aget v4, v9, v4

    aput v4, v28, v12

    .line 3362
    add-int/lit8 v12, v12, 0x1

    .line 3365
    :cond_7
    const v4, 0x2265b

    move-object/from16 v0, v27

    move-object/from16 v1, v28

    invoke-static {v4, v12, v0, v1}, Lcom/thinkware/sundo/inavi3d/Inavi;->NonePopupRunRouteForSolution(II[I[I)V

    goto/16 :goto_0
.end method


# virtual methods
.method public CheckExtState()V
    .locals 6

    .prologue
    const/4 v5, 0x1

    .line 2650
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mExtIntent:Landroid/content/Intent;

    if-nez v2, :cond_1

    .line 3111
    :cond_0
    :goto_0
    return-void

    .line 2654
    :cond_1
    iget-boolean v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mExtStart:Z

    if-eq v2, v5, :cond_0

    .line 2658
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->isClosedWarning()Z

    move-result v2

    if-eqz v2, :cond_0

    .line 2663
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mExtIntent:Landroid/content/Intent;

    if-eqz v2, :cond_2

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mExtIntent:Landroid/content/Intent;

    invoke-virtual {v2}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    move-result-object v2

    if-eqz v2, :cond_2

    .line 2664
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mExtIntent:Landroid/content/Intent;

    invoke-virtual {v2}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    move-result-object v2

    invoke-virtual {v2}, Landroid/os/Bundle;->size()I

    move-result v0

    .line 2665
    .local v0, "extrasSize":I
    const-string v2, "inavi3d_wooks"

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, " CheckEXTState :: extrasSize :: "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 2666
    const-string v2, "inavi3d_wooks"

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, " CheckEXTState :: toString :: "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mExtIntent:Landroid/content/Intent;

    invoke-virtual {v4}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    move-result-object v4

    invoke-virtual {v4}, Landroid/os/Bundle;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 2667
    const-string v2, "inavi3d_wooks"

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, " CheckEXTState :: toString :: "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mExtIntent:Landroid/content/Intent;

    invoke-virtual {v4}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    move-result-object v4

    invoke-virtual {v4}, Landroid/os/Bundle;->keySet()Ljava/util/Set;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 2669
    .end local v0    # "extrasSize":I
    :cond_2
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mExtIntent:Landroid/content/Intent;

    if-eqz v2, :cond_0

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mExtIntent:Landroid/content/Intent;

    invoke-virtual {v2}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    move-result-object v2

    if-eqz v2, :cond_0

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mExtIntent:Landroid/content/Intent;

    invoke-virtual {v2}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    move-result-object v2

    const-string v3, "EXTTYPE"

    invoke-virtual {v2, v3}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    if-nez v2, :cond_3

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mExtIntent:Landroid/content/Intent;

    invoke-virtual {v2}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    move-result-object v2

    const-string v3, "NIPTYPE"

    invoke-virtual {v2, v3}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    if-eqz v2, :cond_0

    .line 2671
    :cond_3
    iput-boolean v5, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mExtStart:Z

    .line 2672
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootLayout:Landroid/view/View;

    .line 2675
    .local v1, "rootLayout":Landroid/view/View;
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getExtIntent()Landroid/content/Intent;

    move-result-object v2

    invoke-virtual {v2}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    move-result-object v2

    const-string v3, "EXTTYPE"

    invoke-virtual {v2, v3}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const-string v3, "ExtDirectRoute"

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_4

    .line 2677
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/ui/popup/PopupManager;->isPopup()Z

    move-result v2

    if-eqz v2, :cond_4

    .line 2678
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/ui/popup/PopupManager;->dismiss()V

    .line 2682
    :cond_4
    new-instance v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$10;

    invoke-direct {v2, p0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$10;-><init>(Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;)V

    invoke-virtual {v1, v2}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    goto/16 :goto_0
.end method

.method public GPSCheckerStart()V
    .locals 1

    .prologue
    .line 3979
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mTimerTask:Ljava/util/TimerTask;

    if-eqz v0, :cond_0

    .line 3984
    :goto_0
    return-void

    .line 3982
    :cond_0
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->bRunning:Z

    .line 3983
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->doTimerTask()V

    goto :goto_0
.end method

.method public GPSCheckerStop()V
    .locals 4

    .prologue
    const/4 v3, 0x0

    .line 3987
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mTimerTask:Ljava/util/TimerTask;

    if-nez v0, :cond_0

    .line 3995
    :goto_0
    return-void

    .line 3990
    :cond_0
    sget-object v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->inavi_reference:Lcom/thinkware/sundo/inavi3d/Inavi;

    const v1, 0x222e0

    const v2, 0x22346

    invoke-virtual {v0, v1, v2, v3, v3}, Lcom/thinkware/sundo/inavi3d/Inavi;->PushMessage(IIII)V

    .line 3994
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->stopTask()V

    goto :goto_0
.end method

.method public IsFirstCurrnetOn()Z
    .locals 1

    .prologue
    .line 896
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mFirstCurrentOn:Z

    return v0
.end method

.method public RemoteControllerEvent(Landroid/view/KeyEvent;Landroid/view/View;)Z
    .locals 11
    .param p1, "event"    # Landroid/view/KeyEvent;
    .param p2, "CurrentView"    # Landroid/view/View;

    .prologue
    .line 1295
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getAction()I

    move-result v9

    if-nez v9, :cond_2

    .line 1297
    if-nez p2, :cond_0

    .line 1298
    const/4 v6, 0x1

    .line 1337
    :goto_0
    return v6

    .line 1300
    :cond_0
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getKeyCode()I

    move-result v9

    const/16 v10, 0x8d

    if-ne v9, v10, :cond_2

    .line 1302
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v9

    const-class v10, Landroid/widget/ListView;

    if-ne v9, v10, :cond_3

    move-object v3, p2

    .line 1303
    check-cast v3, Landroid/widget/ListView;

    .line 1304
    .local v3, "list":Landroid/widget/ListView;
    invoke-virtual {v3}, Landroid/widget/ListView;->getSelectedItemPosition()I

    move-result v2

    .line 1305
    .local v2, "index":I
    invoke-virtual {v3}, Landroid/widget/ListView;->getSelectedView()Landroid/view/View;

    move-result-object v9

    invoke-virtual {v9}, Landroid/view/View;->getTop()I

    move-result v8

    .line 1306
    .local v8, "top":I
    invoke-virtual {v3}, Landroid/widget/ListView;->getSelectedView()Landroid/view/View;

    move-result-object v9

    invoke-virtual {v9}, Landroid/view/View;->getHeight()I

    move-result v1

    .line 1308
    .local v1, "height":I
    invoke-virtual {v3}, Landroid/widget/ListView;->getBottom()I

    move-result v4

    .line 1309
    .local v4, "listbottom":I
    invoke-virtual {v3}, Landroid/widget/ListView;->getSelectedView()Landroid/view/View;

    move-result-object v9

    invoke-virtual {v9}, Landroid/view/View;->getBottom()I

    move-result v7

    .line 1310
    .local v7, "selectbottom":I
    invoke-virtual {v3}, Landroid/widget/ListView;->getChildCount()I

    move-result v0

    .line 1313
    .local v0, "childcount":I
    sub-int v9, v4, v7

    invoke-static {v9}, Ljava/lang/Math;->abs(I)I

    move-result v9

    if-ge v9, v1, :cond_1

    .line 1314
    const/4 v8, 0x0

    .line 1316
    :cond_1
    add-int/lit8 v9, v2, 0x1

    invoke-virtual {v3, v9, v8}, Landroid/widget/ListView;->setSelectionFromTop(II)V

    .line 1336
    .end local v0    # "childcount":I
    .end local v1    # "height":I
    .end local v2    # "index":I
    .end local v3    # "list":Landroid/widget/ListView;
    .end local v4    # "listbottom":I
    .end local v7    # "selectbottom":I
    .end local v8    # "top":I
    :cond_2
    :goto_1
    const/4 v6, 0x0

    .line 1337
    .local v6, "ret":Z
    goto :goto_0

    .line 1320
    .end local v6    # "ret":Z
    :cond_3
    const/16 v9, 0x82

    invoke-virtual {p2, v9}, Landroid/view/View;->focusSearch(I)Landroid/view/View;

    move-result-object v5

    .line 1321
    .local v5, "nextfocus":Landroid/view/View;
    if-eqz v5, :cond_2

    .line 1322
    invoke-virtual {v5}, Landroid/view/View;->requestFocus()Z

    goto :goto_1
.end method

.method public SetBarShown(Z)V
    .locals 0
    .param p1, "show"    # Z

    .prologue
    .line 2126
    iput-boolean p1, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mBarShown:Z

    .line 2127
    return-void
.end method

.method public SetHideBar(Z)V
    .locals 0
    .param p1, "hide"    # Z

    .prologue
    .line 2138
    iput-boolean p1, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mIsHideBar:Z

    .line 2139
    return-void
.end method

.method public backActivityFromMap()V
    .locals 2

    .prologue
    .line 387
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootLayout:Landroid/view/View;

    new-instance v1, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$1;

    invoke-direct {v1, p0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$1;-><init>(Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;)V

    invoke-virtual {v0, v1}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    .line 394
    return-void
.end method

.method public backActivityFromMap(Z)V
    .locals 14
    .param p1, "nameSearch"    # Z

    .prologue
    const/4 v13, 0x0

    const/4 v12, 0x1

    .line 399
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getActivityCount()I

    move-result v0

    .line 401
    .local v0, "activityCount":I
    if-lez v0, :cond_3

    .line 402
    iget-object v9, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    invoke-virtual {v9}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v8

    .line 404
    .local v8, "packageName":Ljava/lang/String;
    const/4 v1, 0x0

    .local v1, "activityIndex":I
    :goto_0
    if-ge v1, v0, :cond_3

    .line 405
    new-instance v7, Landroid/content/Intent;

    invoke-direct {v7}, Landroid/content/Intent;-><init>()V

    .line 407
    .local v7, "intent":Landroid/content/Intent;
    iget-object v9, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mActivityInfoArray:Ljava/util/ArrayList;

    invoke-virtual {v9, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$InnerActivityInfo;

    .line 408
    .local v6, "innerActivityInfo":Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$InnerActivityInfo;
    invoke-virtual {v6}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$InnerActivityInfo;->getActivityClassName()Ljava/lang/String;

    move-result-object v3

    .line 410
    .local v3, "className":Ljava/lang/String;
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getMainClassName()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v3, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-ne v9, v12, :cond_7

    .line 412
    add-int/lit8 v9, v0, -0x1

    if-ne v1, v9, :cond_7

    .line 414
    if-ne v0, v12, :cond_5

    if-nez p1, :cond_5

    .line 416
    iget-object v9, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mActivityInfoArray:Ljava/util/ArrayList;

    add-int/lit8 v10, v0, -0x1

    invoke-virtual {v9, v10}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$InnerActivityInfo;

    invoke-virtual {v9}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$InnerActivityInfo;->getInnerActivityClassName()Ljava/lang/String;

    move-result-object v5

    .line 418
    .local v5, "innerActivityClassName":Ljava/lang/String;
    const/4 v2, 0x0

    .line 420
    .local v2, "bExcuteCurrentOn":Z
    const-class v9, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;

    invoke-virtual {v9}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v5, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-eq v9, v12, :cond_0

    const-class v9, Lcom/thinkware/sundo/inavi3d/ui/EntireRouteActivity;

    invoke-virtual {v9}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v5, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-eq v9, v12, :cond_0

    const-class v9, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;

    invoke-virtual {v9}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v5, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-ne v9, v12, :cond_1

    :cond_0
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->isCurrentFlag()Z

    move-result v9

    if-nez v9, :cond_1

    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getRootActivityStatus()I

    move-result v9

    if-eq v9, v12, :cond_1

    .line 425
    const/4 v2, 0x1

    .line 427
    :cond_1
    if-nez v2, :cond_2

    const-class v9, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;

    invoke-virtual {v9}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v5, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-ne v9, v12, :cond_2

    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->isCurrentFlag()Z

    move-result v9

    if-ne v9, v12, :cond_2

    sget-boolean v9, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->isNameSearchOn:Z

    if-ne v9, v12, :cond_2

    .line 428
    const/4 v2, 0x1

    .line 430
    :cond_2
    if-ne v2, v12, :cond_4

    .line 432
    sget-object v9, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->inavi_reference:Lcom/thinkware/sundo/inavi3d/Inavi;

    const v10, 0x222e0

    const v11, 0x222e1

    invoke-virtual {v9, v10, v11, v13, v13}, Lcom/thinkware/sundo/inavi3d/Inavi;->PushMessage(IIII)V

    .line 437
    const-wide/16 v10, 0x1f4

    :try_start_0
    invoke-static {v10, v11}, Ljava/lang/Thread;->sleep(J)V
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0

    .line 443
    :goto_1
    const-class v9, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;

    invoke-virtual {v9}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v5, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-ne v9, v12, :cond_3

    .line 445
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->SaveOption()V

    .line 466
    .end local v1    # "activityIndex":I
    .end local v2    # "bExcuteCurrentOn":Z
    .end local v3    # "className":Ljava/lang/String;
    .end local v5    # "innerActivityClassName":Ljava/lang/String;
    .end local v6    # "innerActivityInfo":Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$InnerActivityInfo;
    .end local v7    # "intent":Landroid/content/Intent;
    .end local v8    # "packageName":Ljava/lang/String;
    :cond_3
    :goto_2
    return-void

    .line 438
    .restart local v1    # "activityIndex":I
    .restart local v2    # "bExcuteCurrentOn":Z
    .restart local v3    # "className":Ljava/lang/String;
    .restart local v5    # "innerActivityClassName":Ljava/lang/String;
    .restart local v6    # "innerActivityInfo":Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$InnerActivityInfo;
    .restart local v7    # "intent":Landroid/content/Intent;
    .restart local v8    # "packageName":Ljava/lang/String;
    :catch_0
    move-exception v4

    .line 440
    .local v4, "e":Ljava/lang/InterruptedException;
    invoke-virtual {v4}, Ljava/lang/InterruptedException;->printStackTrace()V

    goto :goto_1

    .line 449
    .end local v4    # "e":Ljava/lang/InterruptedException;
    :cond_4
    iget-object v9, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    invoke-virtual {p0, v9}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->popActivity(Landroid/content/Context;)V

    .line 452
    .end local v2    # "bExcuteCurrentOn":Z
    .end local v5    # "innerActivityClassName":Ljava/lang/String;
    :cond_5
    if-gt v0, v12, :cond_6

    if-ne p1, v12, :cond_7

    .line 453
    :cond_6
    iget-object v9, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    invoke-virtual {p0, v9}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->popActivity(Landroid/content/Context;)V

    goto :goto_2

    .line 458
    :cond_7
    new-instance v9, Landroid/content/ComponentName;

    invoke-direct {v9, v8, v3}, Landroid/content/ComponentName;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v7, v9}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;

    .line 459
    const/high16 v9, 0x30000

    invoke-virtual {v7, v9}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;

    .line 461
    iget-object v9, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    invoke-virtual {v9, v7}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    .line 404
    add-int/lit8 v1, v1, 0x1

    goto/16 :goto_0
.end method

.method public cancelAdasService()V
    .locals 2

    .prologue
    .line 5240
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    if-eqz v0, :cond_0

    .line 5241
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mAdasConnection:Landroid/content/ServiceConnection;

    invoke-virtual {v0, v1}, Landroid/content/Context;->unbindService(Landroid/content/ServiceConnection;)V

    .line 5243
    :cond_0
    return-void
.end method

.method public checkARCameraStatus()V
    .locals 8

    .prologue
    const/4 v7, 0x2

    const/4 v6, -0x1

    .line 4594
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v3

    invoke-virtual {v3}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->IsDAVINCIOrder()Z

    move-result v3

    const/4 v4, 0x1

    if-ne v3, v4, :cond_1

    .line 4597
    :try_start_0
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    invoke-virtual {v3}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v3

    const-string v4, "ar_camera_key"

    invoke-static {v3, v4}, Landroid/provider/Settings$System;->getInt(Landroid/content/ContentResolver;Ljava/lang/String;)I

    move-result v3

    iput v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mARCameraStatus:I

    .line 4598
    const-string v3, "ar_camera_key"

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "checkARCameraStatus() 1 :: "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    iget v5, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mARCameraStatus:I

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v3, v4}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catch Landroid/provider/Settings$SettingNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    .line 4621
    :cond_0
    :goto_0
    return-void

    .line 4599
    :catch_0
    move-exception v0

    .line 4600
    .local v0, "e":Landroid/provider/Settings$SettingNotFoundException;
    iput v7, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mARCameraStatus:I

    .line 4601
    invoke-virtual {v0}, Landroid/provider/Settings$SettingNotFoundException;->printStackTrace()V

    goto :goto_0

    .line 4604
    .end local v0    # "e":Landroid/provider/Settings$SettingNotFoundException;
    :cond_1
    const/4 v1, 0x0

    .line 4607
    .local v1, "otherAppsContext":Landroid/content/Context;
    :try_start_1
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    const-string v4, "com.android.settings"

    const/4 v5, 0x0

    invoke-virtual {v3, v4, v5}, Landroid/content/Context;->createPackageContext(Ljava/lang/String;I)Landroid/content/Context;
    :try_end_1
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_1 .. :try_end_1} :catch_1

    move-result-object v1

    .line 4613
    :goto_1
    const/4 v2, 0x0

    .line 4614
    .local v2, "pref":Landroid/content/SharedPreferences;
    const-string v3, "com.android.settings.shared_prefs"

    const/4 v4, 0x4

    invoke-virtual {v1, v3, v4}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v2

    .line 4615
    const-string v3, "ar_camera_key"

    invoke-interface {v2, v3, v6}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v3

    iput v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mARCameraStatus:I

    .line 4617
    iget v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mARCameraStatus:I

    if-ne v3, v6, :cond_0

    .line 4618
    iput v7, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mARCameraStatus:I

    goto :goto_0

    .line 4608
    .end local v2    # "pref":Landroid/content/SharedPreferences;
    :catch_1
    move-exception v0

    .line 4610
    .local v0, "e":Landroid/content/pm/PackageManager$NameNotFoundException;
    invoke-virtual {v0}, Landroid/content/pm/PackageManager$NameNotFoundException;->printStackTrace()V

    goto :goto_1
.end method

.method public checkAutoArMode(Lcom/thinkware/sundo/remoteTBT/TBTGuide;)Z
    .locals 1
    .param p1, "tbtGuide"    # Lcom/thinkware/sundo/remoteTBT/TBTGuide;

    .prologue
    .line 4686
    const/4 v0, 0x0

    return v0
.end method

.method public checkAutoRunInaviBySetting(Landroid/content/Context;)Z
    .locals 14
    .param p1, "context"    # Landroid/content/Context;

    .prologue
    const/16 v13, 0x9

    const/4 v11, 0x5

    const/4 v12, 0x1

    .line 3785
    invoke-direct {p0, p1}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->checkAutoRunInaviWithRouteinfo(Landroid/content/Context;)Z

    move-result v10

    if-ne v10, v12, :cond_0

    .line 3786
    iput-boolean v12, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mbAutoRunInaviByStting:Z

    .line 3787
    iget-boolean v10, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mbAutoRunInaviByStting:Z

    .line 3854
    :goto_0
    return v10

    .line 3790
    :cond_0
    const/4 v4, 0x0

    .line 3792
    .local v4, "micomFlag":Z
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v10

    invoke-virtual {v10}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetDeviceModelType()I

    move-result v10

    if-eq v10, v11, :cond_1

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v10

    invoke-virtual {v10}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetDeviceModelType()I

    move-result v10

    const/4 v11, 0x6

    if-eq v10, v11, :cond_1

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v10

    invoke-virtual {v10}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetDeviceModelType()I

    move-result v10

    if-ne v10, v13, :cond_3

    .line 3795
    :cond_1
    const/4 v4, 0x1

    .line 3816
    :cond_2
    :goto_1
    if-ne v4, v12, :cond_5

    .line 3819
    :try_start_0
    invoke-virtual {p1}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v10

    const-string v11, "settings_boot_pg"

    invoke-static {v10, v11}, Landroid/provider/Settings$System;->getInt(Landroid/content/ContentResolver;Ljava/lang/String;)I

    move-result v1

    .line 3821
    .local v1, "bootPg":I
    if-ne v1, v12, :cond_4

    .line 3822
    const/4 v10, 0x1

    iput-boolean v10, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mbAutoRunInaviByStting:Z

    .line 3823
    iget-boolean v10, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mbAutoRunInaviByStting:Z
    :try_end_0
    .catch Landroid/provider/Settings$SettingNotFoundException; {:try_start_0 .. :try_end_0} :catch_3

    goto :goto_0

    .line 3797
    .end local v1    # "bootPg":I
    :cond_3
    new-instance v3, Ljava/io/File;

    const-string v10, "/sys/firmware/micom_control"

    invoke-direct {v3, v10}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 3800
    .local v3, "file":Ljava/io/File;
    :try_start_1
    new-instance v6, Ljava/io/BufferedReader;

    new-instance v10, Ljava/io/FileReader;

    invoke-direct {v10, v3}, Ljava/io/FileReader;-><init>(Ljava/io/File;)V

    invoke-direct {v6, v10}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V

    .line 3802
    .local v6, "reader":Ljava/io/BufferedReader;
    invoke-virtual {v6}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    move-result-object v9

    .line 3803
    .local v9, "temp":Ljava/lang/String;
    const/16 v10, 0x1a

    invoke-virtual {v9, v10}, Ljava/lang/String;->charAt(I)C
    :try_end_1
    .catch Ljava/io/FileNotFoundException; {:try_start_1 .. :try_end_1} :catch_0
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_1

    move-result v7

    .line 3805
    .local v7, "result":I
    const/16 v10, 0x31

    if-ne v7, v10, :cond_2

    .line 3806
    const/4 v4, 0x1

    goto :goto_1

    .line 3809
    .end local v6    # "reader":Ljava/io/BufferedReader;
    .end local v7    # "result":I
    .end local v9    # "temp":Ljava/lang/String;
    :catch_0
    move-exception v2

    .line 3810
    .local v2, "e":Ljava/io/FileNotFoundException;
    invoke-virtual {v2}, Ljava/io/FileNotFoundException;->printStackTrace()V

    goto :goto_1

    .line 3811
    .end local v2    # "e":Ljava/io/FileNotFoundException;
    :catch_1
    move-exception v2

    .line 3812
    .local v2, "e":Ljava/io/IOException;
    invoke-virtual {v2}, Ljava/io/IOException;->printStackTrace()V

    goto :goto_1

    .line 3824
    .end local v2    # "e":Ljava/io/IOException;
    .end local v3    # "file":Ljava/io/File;
    .restart local v1    # "bootPg":I
    :cond_4
    if-ne v1, v13, :cond_5

    .line 3825
    const/4 v0, 0x0

    .line 3827
    .local v0, "LastAppContext":Landroid/content/Context;
    :try_start_2
    const-string v10, "com.thinkware.ivy.launcher"

    const/4 v11, 0x2

    invoke-virtual {p1, v10, v11}, Landroid/content/Context;->createPackageContext(Ljava/lang/String;I)Landroid/content/Context;
    :try_end_2
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_2 .. :try_end_2} :catch_2
    .catch Landroid/provider/Settings$SettingNotFoundException; {:try_start_2 .. :try_end_2} :catch_3

    move-result-object v0

    .line 3832
    :goto_2
    :try_start_3
    const-string v10, "com.thinkware.ivy.launcher.simple.prefs"

    const/4 v11, 0x5

    invoke-virtual {v0, v10, v11}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v5

    .line 3834
    .local v5, "pref":Landroid/content/SharedPreferences;
    const-string v10, "ivy.launcher.lastmode_packagename"

    const-string v11, ""

    invoke-interface {v5, v10, v11}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    .line 3836
    .local v8, "strPackageName":Ljava/lang/String;
    const-string v10, "lastmode"

    new-instance v11, Ljava/lang/StringBuilder;

    invoke-direct {v11}, Ljava/lang/StringBuilder;-><init>()V

    const-string v12, "strPackageName: "

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    invoke-virtual {v11, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v11

    invoke-static {v10, v11}, Lcom/thinkware/sundo/inavi3d/LOGTW;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 3837
    const-string v10, "lastmode"

    new-instance v11, Ljava/lang/StringBuilder;

    invoke-direct {v11}, Ljava/lang/StringBuilder;-><init>()V

    const-string v12, "getPackageName(): "

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v11

    invoke-static {v10, v11}, Lcom/thinkware/sundo/inavi3d/LOGTW;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 3839
    if-eqz v8, :cond_5

    .line 3840
    invoke-virtual {v8}, Ljava/lang/String;->isEmpty()Z

    move-result v10

    if-nez v10, :cond_5

    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v8, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_5

    .line 3841
    const/4 v10, 0x1

    iput-boolean v10, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mbAutoRunInaviByStting:Z

    .line 3842
    iget-boolean v10, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mbAutoRunInaviByStting:Z

    goto/16 :goto_0

    .line 3828
    .end local v5    # "pref":Landroid/content/SharedPreferences;
    .end local v8    # "strPackageName":Ljava/lang/String;
    :catch_2
    move-exception v2

    .line 3830
    .local v2, "e":Landroid/content/pm/PackageManager$NameNotFoundException;
    invoke-virtual {v2}, Landroid/content/pm/PackageManager$NameNotFoundException;->printStackTrace()V
    :try_end_3
    .catch Landroid/provider/Settings$SettingNotFoundException; {:try_start_3 .. :try_end_3} :catch_3

    goto :goto_2

    .line 3847
    .end local v0    # "LastAppContext":Landroid/content/Context;
    .end local v1    # "bootPg":I
    .end local v2    # "e":Landroid/content/pm/PackageManager$NameNotFoundException;
    :catch_3
    move-exception v2

    .line 3849
    .local v2, "e":Landroid/provider/Settings$SettingNotFoundException;
    invoke-virtual {v2}, Landroid/provider/Settings$SettingNotFoundException;->printStackTrace()V

    .line 3853
    .end local v2    # "e":Landroid/provider/Settings$SettingNotFoundException;
    :cond_5
    const/4 v10, 0x0

    iput-boolean v10, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mbAutoRunInaviByStting:Z

    .line 3854
    iget-boolean v10, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mbAutoRunInaviByStting:Z

    goto/16 :goto_0
.end method

.method public checkBSDStatus()V
    .locals 6

    .prologue
    const/4 v5, 0x0

    const/4 v4, 0x1

    .line 4571
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v2

    invoke-virtual {v2}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->IsDAVINCIOrder()Z

    move-result v2

    if-ne v2, v4, :cond_0

    .line 4573
    :try_start_0
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    invoke-virtual {v2}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v2

    const-string v3, "ar_camera_key"

    invoke-static {v2, v3}, Landroid/provider/Settings$System;->getInt(Landroid/content/ContentResolver;Ljava/lang/String;)I

    move-result v0

    .line 4574
    .local v0, "BSDStatus":I
    if-ne v0, v4, :cond_1

    .line 4575
    const/4 v2, 0x1

    iput-boolean v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mBSDStatusOn:Z

    .line 4584
    .end local v0    # "BSDStatus":I
    :cond_0
    :goto_0
    return-void

    .line 4577
    .restart local v0    # "BSDStatus":I
    :cond_1
    const/4 v2, 0x0

    iput-boolean v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mBSDStatusOn:Z
    :try_end_0
    .catch Landroid/provider/Settings$SettingNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    .line 4579
    .end local v0    # "BSDStatus":I
    :catch_0
    move-exception v1

    .line 4580
    .local v1, "e":Landroid/provider/Settings$SettingNotFoundException;
    iput-boolean v5, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mBSDStatusOn:Z

    .line 4581
    invoke-virtual {v1}, Landroid/provider/Settings$SettingNotFoundException;->printStackTrace()V

    goto :goto_0
.end method

.method public checkMoveRootActivity()Z
    .locals 4

    .prologue
    const/4 v2, 0x1

    const/4 v1, 0x0

    .line 1062
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mCurrentOn:Z

    if-ne v0, v2, :cond_0

    move v0, v1

    .line 1071
    :goto_0
    return v0

    .line 1066
    :cond_0
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getActivityCount()I

    move-result v0

    if-lez v0, :cond_1

    .line 1067
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mActivityInfoArray:Ljava/util/ArrayList;

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$InnerActivityInfo;

    invoke-static {v0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$InnerActivityInfo;->access$000(Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$InnerActivityInfo;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getMainClassName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-ne v0, v2, :cond_1

    move v0, v1

    .line 1068
    goto :goto_0

    :cond_1
    move v0, v2

    .line 1071
    goto :goto_0
.end method

.method public checkOBD2Overspeed()V
    .locals 4

    .prologue
    .line 4820
    invoke-static {}, Ljava/util/Calendar;->getInstance()Ljava/util/Calendar;

    move-result-object v2

    const/16 v3, 0xd

    invoke-virtual {v2, v3}, Ljava/util/Calendar;->get(I)I

    move-result v1

    .line 4821
    .local v1, "current_sec":I
    iget v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->m_nCurrentSecond:I

    if-eq v1, v2, :cond_0

    .line 4822
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/Inavi;->getTbtguide()Lcom/thinkware/sundo/remoteTBT/TBTGuide;

    move-result-object v2

    invoke-direct {p0, v2}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->isOverspeed(Lcom/thinkware/sundo/remoteTBT/TBTGuide;)Z

    move-result v0

    .line 4823
    .local v0, "bOverspeed":Z
    invoke-direct {p0, v0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->sendBroadcastToOBD2(Z)V

    .line 4826
    .end local v0    # "bOverspeed":Z
    :cond_0
    iput v1, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->m_nCurrentSecond:I

    .line 4827
    return-void
.end method

.method public checkSpecialCharactersForPointGroupName(Ljava/lang/String;)Z
    .locals 2
    .param p1, "strName"    # Ljava/lang/String;

    .prologue
    .line 5190
    const/4 v0, 0x0

    .line 5191
    .local v0, "isSpecial":Z
    const-string v1, "\\"

    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_0

    const-string v1, "/"

    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_0

    const-string v1, ":"

    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_0

    const-string v1, "*"

    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_0

    const-string v1, "?"

    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_0

    const-string v1, "\""

    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_0

    const-string v1, "<"

    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_0

    const-string v1, ">"

    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_0

    const-string v1, "|"

    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_1

    .line 5194
    :cond_0
    const/4 v0, 0x1

    .line 5196
    :cond_1
    return v0
.end method

.method public checkSpecialCharactersForRouteName(Ljava/lang/String;)Z
    .locals 2
    .param p1, "strName"    # Ljava/lang/String;

    .prologue
    .line 5178
    const/4 v0, 0x0

    .line 5179
    .local v0, "isSpecial":Z
    const-string v1, "\\"

    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_0

    const-string v1, "/"

    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_0

    const-string v1, ":"

    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_0

    const-string v1, "*"

    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_0

    const-string v1, "?"

    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_0

    const-string v1, "\""

    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_0

    const-string v1, "<"

    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_0

    const-string v1, ">"

    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_0

    const-string v1, "|"

    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_0

    const-string v1, "_"

    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_1

    .line 5183
    :cond_0
    const/4 v0, 0x1

    .line 5185
    :cond_1
    return v0
.end method

.method public checkWorkingDayInfo(II)Z
    .locals 19
    .param p1, "nX"    # I
    .param p2, "nY"    # I

    .prologue
    .line 5062
    const-string v2, "checkWorkingDayInfo"

    move-object/from16 v0, p0

    invoke-virtual {v0, v2}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->printState(Ljava/lang/String;)V

    .line 5064
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mPOIHasWorkingDayInfo:Lcom/thinkware/sundo/inavi3d/ui/component/CustumDefine$GUISearchPointData;

    if-nez v2, :cond_0

    .line 5065
    const/4 v2, 0x0

    .line 5142
    :goto_0
    return v2

    .line 5069
    :cond_0
    sget-object v2, Lcom/thinkware/sundo/inavi3d/Inavi;->mGPSInfo:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    if-eqz v2, :cond_1

    sget-object v2, Lcom/thinkware/sundo/inavi3d/Inavi;->mGPSInfo:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    iget-char v2, v2, Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;->Status:C

    const/16 v3, 0x41

    if-eq v2, v3, :cond_2

    .line 5071
    :cond_1
    const/4 v2, 0x1

    move-object/from16 v0, p0

    iput-boolean v2, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mNeedCheckMartWorking:Z

    .line 5072
    const/4 v2, 0x0

    goto :goto_0

    .line 5074
    :cond_2
    const/4 v2, 0x0

    move-object/from16 v0, p0

    iput-boolean v2, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mNeedCheckMartWorking:Z

    .line 5078
    move-object/from16 v0, p0

    iget v2, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mLastShowingPid:I

    move-object/from16 v0, p0

    iget-object v3, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mPOIHasWorkingDayInfo:Lcom/thinkware/sundo/inavi3d/ui/component/CustumDefine$GUISearchPointData;

    iget v3, v3, Lcom/thinkware/sundo/inavi3d/ui/component/CustumDefine$GUISearchPointData;->m_nPoiID:I

    if-eq v2, v3, :cond_3

    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mPOIHasWorkingDayInfo:Lcom/thinkware/sundo/inavi3d/ui/component/CustumDefine$GUISearchPointData;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/ui/component/CustumDefine$GUISearchPointData;->m_strWorkingDayInfo:Ljava/lang/String;

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_4

    .line 5080
    :cond_3
    const/4 v2, 0x0

    move-object/from16 v0, p0

    iput-object v2, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mPOIHasWorkingDayInfo:Lcom/thinkware/sundo/inavi3d/ui/component/CustumDefine$GUISearchPointData;

    .line 5081
    const/4 v2, 0x0

    goto :goto_0

    .line 5084
    :cond_4
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mPOIHasWorkingDayInfo:Lcom/thinkware/sundo/inavi3d/ui/component/CustumDefine$GUISearchPointData;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/ui/component/CustumDefine$GUISearchPointData;->m_strWorkingDayInfo:Ljava/lang/String;

    move-object/from16 v0, p0

    invoke-virtual {v0, v2}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->parseWorkingDayInfo(Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object v7

    .line 5085
    .local v7, "arrInfos":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$TempHoliDayInfo;>;"
    invoke-virtual {v7}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_5

    .line 5086
    const/4 v2, 0x0

    move-object/from16 v0, p0

    iput-object v2, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mPOIHasWorkingDayInfo:Lcom/thinkware/sundo/inavi3d/ui/component/CustumDefine$GUISearchPointData;

    .line 5087
    const/4 v2, 0x0

    goto :goto_0

    .line 5089
    :cond_5
    const/4 v14, 0x0

    .line 5090
    .local v14, "isFound":Z
    const-string v2, "bona"

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "\n\n"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    move-object/from16 v0, p0

    iget-object v4, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mPOIHasWorkingDayInfo:Lcom/thinkware/sundo/inavi3d/ui/component/CustumDefine$GUISearchPointData;

    iget-object v4, v4, Lcom/thinkware/sundo/inavi3d/ui/component/CustumDefine$GUISearchPointData;->m_strPoiName:Ljava/lang/String;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 5092
    new-instance v1, Ljava/util/GregorianCalendar;

    sget-object v2, Lcom/thinkware/sundo/inavi3d/Inavi;->mGPSInfo:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    iget-short v2, v2, Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;->Date_yy:S

    add-int/lit16 v2, v2, 0x7d0

    sget-object v3, Lcom/thinkware/sundo/inavi3d/Inavi;->mGPSInfo:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    iget-short v3, v3, Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;->Date_mm:S

    add-int/lit8 v3, v3, -0x1

    sget-object v4, Lcom/thinkware/sundo/inavi3d/Inavi;->mGPSInfo:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    iget-short v4, v4, Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;->Date_dd:S

    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->mGPSInfo:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    iget-short v5, v5, Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;->UTC_hh:S

    add-int/lit8 v5, v5, 0x9

    sget-object v6, Lcom/thinkware/sundo/inavi3d/Inavi;->mGPSInfo:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    iget-short v6, v6, Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;->UTC_mm:S

    invoke-direct/range {v1 .. v6}, Ljava/util/GregorianCalendar;-><init>(IIIII)V

    .line 5098
    .local v1, "calendar":Ljava/util/GregorianCalendar;
    const/4 v2, 0x5

    invoke-virtual {v1, v2}, Ljava/util/GregorianCalendar;->get(I)I

    move-result v2

    div-int/lit8 v3, v2, 0x7

    const/4 v2, 0x5

    invoke-virtual {v1, v2}, Ljava/util/GregorianCalendar;->get(I)I

    move-result v2

    rem-int/lit8 v2, v2, 0x7

    if-lez v2, :cond_7

    const/4 v2, 0x1

    :goto_1
    add-int v16, v3, v2

    .line 5099
    .local v16, "weekOfMonth":I
    const/4 v2, 0x7

    invoke-virtual {v1, v2}, Ljava/util/GregorianCalendar;->get(I)I

    move-result v9

    .line 5100
    .local v9, "dayOfWeek":I
    const/4 v2, 0x5

    invoke-virtual {v1, v2}, Ljava/util/GregorianCalendar;->get(I)I

    move-result v8

    .line 5101
    .local v8, "day":I
    new-instance v15, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$TempHoliDayInfo;

    move/from16 v0, v16

    invoke-direct {v15, v0, v9}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$TempHoliDayInfo;-><init>(II)V

    .line 5104
    .local v15, "today":Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$TempHoliDayInfo;
    const-string v2, "bona"

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "today : "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v15}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$TempHoliDayInfo;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 5105
    const-string v2, "bona"

    move-object/from16 v0, p0

    iget-object v3, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mPOIHasWorkingDayInfo:Lcom/thinkware/sundo/inavi3d/ui/component/CustumDefine$GUISearchPointData;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/ui/component/CustumDefine$GUISearchPointData;->m_strWorkingDayInfo:Ljava/lang/String;

    invoke-static {v2, v3}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 5108
    invoke-virtual {v7}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v11

    .local v11, "i$":Ljava/util/Iterator;
    :cond_6
    :goto_2
    invoke-interface {v11}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_9

    invoke-interface {v11}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$TempHoliDayInfo;

    .line 5110
    .local v12, "info":Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$TempHoliDayInfo;
    iget v2, v12, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$TempHoliDayInfo;->dayOfWeek:I

    if-ne v2, v9, :cond_8

    iget v2, v12, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$TempHoliDayInfo;->weekOfMonth:I

    move/from16 v0, v16

    if-ne v2, v0, :cond_8

    .line 5112
    const/4 v14, 0x1

    goto :goto_2

    .line 5098
    .end local v8    # "day":I
    .end local v9    # "dayOfWeek":I
    .end local v11    # "i$":Ljava/util/Iterator;
    .end local v12    # "info":Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$TempHoliDayInfo;
    .end local v15    # "today":Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$TempHoliDayInfo;
    .end local v16    # "weekOfMonth":I
    :cond_7
    const/4 v2, 0x0

    goto :goto_1

    .line 5114
    .restart local v8    # "day":I
    .restart local v9    # "dayOfWeek":I
    .restart local v11    # "i$":Ljava/util/Iterator;
    .restart local v12    # "info":Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$TempHoliDayInfo;
    .restart local v15    # "today":Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$TempHoliDayInfo;
    .restart local v16    # "weekOfMonth":I
    :cond_8
    iget v2, v12, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$TempHoliDayInfo;->weekOfMonth:I

    if-nez v2, :cond_6

    iget v2, v12, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$TempHoliDayInfo;->dayOfWeek:I

    if-ne v2, v8, :cond_6

    .line 5116
    const/4 v14, 0x1

    goto :goto_2

    .line 5120
    .end local v12    # "info":Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$TempHoliDayInfo;
    :cond_9
    if-nez v14, :cond_a

    .line 5121
    const/4 v2, 0x0

    move-object/from16 v0, p0

    iput-object v2, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mPOIHasWorkingDayInfo:Lcom/thinkware/sundo/inavi3d/ui/component/CustumDefine$GUISearchPointData;

    .line 5122
    const/4 v2, 0x0

    goto/16 :goto_0

    .line 5127
    :cond_a
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mPOIHasWorkingDayInfo:Lcom/thinkware/sundo/inavi3d/ui/component/CustumDefine$GUISearchPointData;

    iget v2, v2, Lcom/thinkware/sundo/inavi3d/ui/component/CustumDefine$GUISearchPointData;->m_nPointX:I

    sub-int v2, v2, p1

    invoke-static {v2}, Ljava/lang/Math;->abs(I)I

    move-result v2

    move-object/from16 v0, p0

    iget-object v3, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mPOIHasWorkingDayInfo:Lcom/thinkware/sundo/inavi3d/ui/component/CustumDefine$GUISearchPointData;

    iget v3, v3, Lcom/thinkware/sundo/inavi3d/ui/component/CustumDefine$GUISearchPointData;->m_nPointY:I

    sub-int v3, v3, p2

    invoke-static {v3}, Ljava/lang/Math;->abs(I)I

    move-result v3

    add-int v10, v2, v3

    .line 5128
    .local v10, "diff":I
    const/16 v2, 0xa

    if-ge v10, v2, :cond_c

    .line 5129
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mPOIHasWorkingDayInfo:Lcom/thinkware/sundo/inavi3d/ui/component/CustumDefine$GUISearchPointData;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/ui/component/CustumDefine$GUISearchPointData;->m_strWorkingDayInfo:Ljava/lang/String;

    const-string v3, "\n"

    invoke-virtual {v2, v3}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v13

    .line 5130
    .local v13, "infoArr":[Ljava/lang/String;
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mPOIHasWorkingDayInfo:Lcom/thinkware/sundo/inavi3d/ui/component/CustumDefine$GUISearchPointData;

    move-object/from16 v0, p0

    iget-object v3, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mPOIHasWorkingDayInfo:Lcom/thinkware/sundo/inavi3d/ui/component/CustumDefine$GUISearchPointData;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/ui/component/CustumDefine$GUISearchPointData;->m_strWorkingDayInfo:Ljava/lang/String;

    const-string v4, "\ud734\ubb34"

    const-string v5, "\ud734\uc810"

    invoke-virtual {v3, v4, v5}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v3

    iput-object v3, v2, Lcom/thinkware/sundo/inavi3d/ui/component/CustumDefine$GUISearchPointData;->m_strWorkingDayInfo:Ljava/lang/String;

    .line 5131
    if-eqz v13, :cond_b

    array-length v2, v13

    const/4 v3, 0x2

    if-lt v2, v3, :cond_b

    .line 5132
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mPOIHasWorkingDayInfo:Lcom/thinkware/sundo/inavi3d/ui/component/CustumDefine$GUISearchPointData;

    iget v2, v2, Lcom/thinkware/sundo/inavi3d/ui/component/CustumDefine$GUISearchPointData;->m_nPoiID:I

    move-object/from16 v0, p0

    iput v2, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mLastShowingPid:I

    .line 5133
    const/16 v2, 0x50

    const-string v3, ""

    const-string v4, "\uc54c\ub9bc"

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "%s\uc758 \ud734\uc810\uc77c\uc744 \ud655\uc778\ud558\uc138\uc694.\n\n"

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    move-object/from16 v0, p0

    iget-object v6, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mPOIHasWorkingDayInfo:Lcom/thinkware/sundo/inavi3d/ui/component/CustumDefine$GUISearchPointData;

    iget-object v6, v6, Lcom/thinkware/sundo/inavi3d/ui/component/CustumDefine$GUISearchPointData;->m_strWorkingDayInfo:Ljava/lang/String;

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    const/4 v6, 0x1

    new-array v6, v6, [Ljava/lang/Object;

    const/16 v17, 0x0

    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mPOIHasWorkingDayInfo:Lcom/thinkware/sundo/inavi3d/ui/component/CustumDefine$GUISearchPointData;

    move-object/from16 v18, v0

    move-object/from16 v0, v18

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/ui/component/CustumDefine$GUISearchPointData;->m_strPoiName:Ljava/lang/String;

    move-object/from16 v18, v0

    aput-object v18, v6, v17

    invoke-static {v5, v6}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v5

    const/16 v6, 0x2710

    invoke-static {v2, v3, v4, v5, v6}, Lcom/thinkware/sundo/inavi3d/ui/popup/PopupManager;->ShowNativePopup(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;I)Lcom/thinkware/sundo/inavi3d/ui/popup/InaviPopup;

    .line 5139
    :cond_b
    const/4 v2, 0x0

    move-object/from16 v0, p0

    iput-object v2, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mPOIHasWorkingDayInfo:Lcom/thinkware/sundo/inavi3d/ui/component/CustumDefine$GUISearchPointData;

    .line 5140
    const/4 v2, 0x1

    goto/16 :goto_0

    .line 5142
    .end local v13    # "infoArr":[Ljava/lang/String;
    :cond_c
    const/4 v2, 0x0

    goto/16 :goto_0
.end method

.method public checkWorkingDayInfoLive(II)Z
    .locals 11
    .param p1, "nX"    # I
    .param p2, "nY"    # I

    .prologue
    const/16 v10, 0xa

    const/4 v2, 0x1

    const/4 v3, 0x0

    const-wide v8, 0x3ff3333333333333L    # 1.2

    .line 5156
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mPOIHasWorkingDayInfoLive:Lcom/thinkware/sundo/inavi3d/livesearch/RSearchPOIResult;

    if-eqz v4, :cond_2

    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mPOIHasWorkingDayInfoLive:Lcom/thinkware/sundo/inavi3d/livesearch/RSearchPOIResult;

    iget-object v4, v4, Lcom/thinkware/sundo/inavi3d/livesearch/RSearchPOIResult;->detailInfo:Lcom/thinkware/sundo/inavi3d/livesearch/RSearchPOIResult$RPOIDetail;

    if-eqz v4, :cond_2

    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mPOIHasWorkingDayInfoLive:Lcom/thinkware/sundo/inavi3d/livesearch/RSearchPOIResult;

    iget-object v4, v4, Lcom/thinkware/sundo/inavi3d/livesearch/RSearchPOIResult;->detailInfo:Lcom/thinkware/sundo/inavi3d/livesearch/RSearchPOIResult$RPOIDetail;

    iget-boolean v4, v4, Lcom/thinkware/sundo/inavi3d/livesearch/RSearchPOIResult$RPOIDetail;->closing_flag:Z

    if-eqz v4, :cond_2

    iget v4, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mLastShowingPidLive:I

    iget-object v5, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mPOIHasWorkingDayInfoLive:Lcom/thinkware/sundo/inavi3d/livesearch/RSearchPOIResult;

    iget v5, v5, Lcom/thinkware/sundo/inavi3d/livesearch/RSearchPOIResult;->pid:I

    if-eq v4, v5, :cond_2

    .line 5161
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mPOIHasWorkingDayInfoLive:Lcom/thinkware/sundo/inavi3d/livesearch/RSearchPOIResult;

    iget v4, v4, Lcom/thinkware/sundo/inavi3d/livesearch/RSearchPOIResult;->idxdpx:I

    int-to-double v4, v4

    mul-double/2addr v4, v8

    int-to-double v6, p1

    sub-double/2addr v4, v6

    invoke-static {v4, v5}, Ljava/lang/Math;->abs(D)D

    move-result-wide v4

    iget-object v6, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mPOIHasWorkingDayInfoLive:Lcom/thinkware/sundo/inavi3d/livesearch/RSearchPOIResult;

    iget v6, v6, Lcom/thinkware/sundo/inavi3d/livesearch/RSearchPOIResult;->idxdpy:I

    sub-int/2addr v6, p2

    invoke-static {v6}, Ljava/lang/Math;->abs(I)I

    move-result v6

    int-to-double v6, v6

    add-double/2addr v4, v6

    double-to-int v0, v4

    .line 5162
    .local v0, "diffDp":I
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mPOIHasWorkingDayInfoLive:Lcom/thinkware/sundo/inavi3d/livesearch/RSearchPOIResult;

    iget v4, v4, Lcom/thinkware/sundo/inavi3d/livesearch/RSearchPOIResult;->idxqtx:I

    int-to-double v4, v4

    mul-double/2addr v4, v8

    int-to-double v6, p1

    sub-double/2addr v4, v6

    invoke-static {v4, v5}, Ljava/lang/Math;->abs(D)D

    move-result-wide v4

    iget-object v6, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mPOIHasWorkingDayInfoLive:Lcom/thinkware/sundo/inavi3d/livesearch/RSearchPOIResult;

    iget v6, v6, Lcom/thinkware/sundo/inavi3d/livesearch/RSearchPOIResult;->idxqty:I

    sub-int/2addr v6, p2

    invoke-static {v6}, Ljava/lang/Math;->abs(I)I

    move-result v6

    int-to-double v6, v6

    add-double/2addr v4, v6

    double-to-int v1, v4

    .line 5163
    .local v1, "diffQt":I
    if-lt v0, v10, :cond_0

    if-ge v1, v10, :cond_1

    .line 5164
    :cond_0
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mPOIHasWorkingDayInfoLive:Lcom/thinkware/sundo/inavi3d/livesearch/RSearchPOIResult;

    iget v4, v4, Lcom/thinkware/sundo/inavi3d/livesearch/RSearchPOIResult;->pid:I

    iput v4, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mLastShowingPidLive:I

    .line 5165
    const/16 v4, 0x30

    const-string v5, ""

    const-string v6, "\uc54c\ub9bc"

    const-string v7, "\uc624\ub298\uc740 %s\uc758 \ud734\uc810\uc77c\uc785\ub2c8\ub2e4.\n\n\uc804\ud654\ubc88\ud638: %s"

    const/4 v8, 0x2

    new-array v8, v8, [Ljava/lang/Object;

    iget-object v9, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mPOIHasWorkingDayInfoLive:Lcom/thinkware/sundo/inavi3d/livesearch/RSearchPOIResult;

    iget-object v9, v9, Lcom/thinkware/sundo/inavi3d/livesearch/RSearchPOIResult;->name:Ljava/lang/String;

    aput-object v9, v8, v3

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mPOIHasWorkingDayInfoLive:Lcom/thinkware/sundo/inavi3d/livesearch/RSearchPOIResult;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/livesearch/RSearchPOIResult;->detailInfo:Lcom/thinkware/sundo/inavi3d/livesearch/RSearchPOIResult$RPOIDetail;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/livesearch/RSearchPOIResult$RPOIDetail;->tel1:Ljava/lang/String;

    aput-object v3, v8, v2

    invoke-static {v7, v8}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    const/16 v7, 0x1b58

    invoke-static {v4, v5, v6, v3, v7}, Lcom/thinkware/sundo/inavi3d/ui/popup/PopupManager;->ShowNativePopup(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;I)Lcom/thinkware/sundo/inavi3d/ui/popup/InaviPopup;

    .line 5172
    .end local v0    # "diffDp":I
    .end local v1    # "diffQt":I
    :cond_1
    :goto_0
    return v2

    :cond_2
    move v2, v3

    goto :goto_0
.end method

.method public doTimerPause()V
    .locals 1

    .prologue
    .line 4018
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->bRunning:Z

    if-nez v0, :cond_0

    const/4 v0, 0x1

    :goto_0
    iput-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->bRunning:Z

    .line 4019
    return-void

    .line 4018
    :cond_0
    const/4 v0, 0x0

    goto :goto_0
.end method

.method public doTimerTask()V
    .locals 6

    .prologue
    .line 4033
    new-instance v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$12;

    invoke-direct {v0, p0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$12;-><init>(Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;)V

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mTimerTask:Ljava/util/TimerTask;

    .line 4065
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mTimer:Ljava/util/Timer;

    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mTimerTask:Ljava/util/TimerTask;

    const-wide/16 v2, 0x0

    const-wide/16 v4, 0x3e8

    invoke-virtual/range {v0 .. v5}, Ljava/util/Timer;->schedule(Ljava/util/TimerTask;JJ)V

    .line 4066
    return-void
.end method

.method public existRouteFile(Ljava/lang/String;)Z
    .locals 4
    .param p1, "filePath"    # Ljava/lang/String;

    .prologue
    .line 3766
    new-instance v1, Ljava/io/File;

    invoke-direct {v1, p1}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 3768
    .local v1, "folder":Ljava/io/File;
    new-instance v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$11;

    invoke-direct {v2, p0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$11;-><init>(Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;)V

    invoke-virtual {v1, v2}, Ljava/io/File;->listFiles(Ljava/io/FilenameFilter;)[Ljava/io/File;

    move-result-object v0

    .line 3775
    .local v0, "fileList":[Ljava/io/File;
    if-eqz v0, :cond_0

    array-length v2, v0

    if-lez v2, :cond_0

    .line 3776
    const-string v2, "inavi3d_woong_routetbl"

    const-string v3, "*.ihr :: exists :: true"

    invoke-static {v2, v3}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 3777
    const/4 v2, 0x1

    .line 3780
    :goto_0
    return v2

    .line 3779
    :cond_0
    const-string v2, "inavi3d_woong_routetbl"

    const-string v3, "*.ihr :: exists :: false"

    invoke-static {v2, v3}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 3780
    const/4 v2, 0x0

    goto :goto_0
.end method

.method public getARCameraOn()Z
    .locals 1

    .prologue
    .line 4565
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mARCameraOn:Z

    return v0
.end method

.method public getARCameraStatus()I
    .locals 3

    .prologue
    const/4 v2, 0x2

    .line 4625
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mARCameraOn:Z

    if-eqz v0, :cond_0

    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mIsShowScreenMirroring:Z

    const/4 v1, 0x1

    if-eq v0, v1, :cond_0

    iget v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mARCameraStatus:I

    if-ltz v0, :cond_0

    iget v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mARCameraStatus:I

    if-le v0, v2, :cond_1

    .line 4626
    :cond_0
    iput v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mARCameraStatus:I

    .line 4629
    :cond_1
    iget v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mARCameraStatus:I

    return v0
.end method

.method public getAction()Ljava/lang/String;
    .locals 3

    .prologue
    const/4 v2, 0x0

    .line 962
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getActivityCount()I

    move-result v0

    .line 964
    .local v0, "activityCount":I
    if-gtz v0, :cond_1

    .line 974
    :cond_0
    :goto_0
    return-object v2

    .line 968
    :cond_1
    invoke-direct {p0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getTopINavi3DActivityIndex()I

    move-result v1

    .line 970
    .local v1, "topIndex":I
    if-ltz v1, :cond_0

    .line 974
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mActivityInfoArray:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$InnerActivityInfo;

    invoke-virtual {v2}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$InnerActivityInfo;->getAction()Ljava/lang/String;

    move-result-object v2

    goto :goto_0
.end method

.method public getActivityCount()I
    .locals 1

    .prologue
    .line 953
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mActivityInfoArray:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    return v0
.end method

.method public getActivityName(I)Ljava/lang/String;
    .locals 2
    .param p1, "index"    # I

    .prologue
    .line 1102
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getActivityCount()I

    move-result v1

    if-ge p1, v1, :cond_0

    .line 1103
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mActivityInfoArray:Ljava/util/ArrayList;

    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$InnerActivityInfo;

    .line 1104
    .local v0, "activityInfo":Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$InnerActivityInfo;
    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$InnerActivityInfo;->getActivityClassName()Ljava/lang/String;

    move-result-object v1

    .line 1106
    .end local v0    # "activityInfo":Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$InnerActivityInfo;
    :goto_0
    return-object v1

    :cond_0
    const/4 v1, 0x0

    goto :goto_0
.end method

.method public getAutoArModeStatus(Z)I
    .locals 3
    .param p1, "isConfig"    # Z

    .prologue
    .line 4675
    const/4 v0, 0x1

    if-eq p1, v0, :cond_0

    iget v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->autoArModeStatus:I

    if-gez v0, :cond_1

    .line 4676
    :cond_0
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->getInstance()Lcom/thinkware/sundo/inavi3d/InaviConfig;

    move-result-object v0

    const/16 v1, 0x139

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->CNaviConfigGet(I)I

    move-result v0

    iput v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->autoArModeStatus:I

    .line 4677
    const-string v0, "inavi3d_wooks_auto"

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "getAutoArModeStatus() 1 !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! autoArModeStatus :: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->autoArModeStatus:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 4679
    :cond_1
    iget v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->autoArModeStatus:I

    return v0
.end method

.method public getDestroyInnerActivityClassName()Ljava/lang/String;
    .locals 1

    .prologue
    .line 868
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mDestroyInnerActivityClassName:Ljava/lang/String;

    return-object v0
.end method

.method public getEntireRouteMapLevel()I
    .locals 1

    .prologue
    .line 2565
    iget v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mEntireRouteMapLevel:I

    return v0
.end method

.method public getEntireRouteViewModeValue()I
    .locals 1

    .prologue
    .line 2525
    iget v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mEntireRouteViewMode:I

    return v0
.end method

.method public getExtForeGroundCallStatus()Z
    .locals 3

    .prologue
    .line 2643
    const-string v0, "inavi3d_wooks"

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, " getExtForeGroundCallStatus() :: mbExtForeGroundCallStatus :: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-boolean v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mbExtForeGroundCallStatus:Z

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 2644
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mbExtForeGroundCallStatus:Z

    return v0
.end method

.method public getExtIntent()Landroid/content/Intent;
    .locals 1

    .prologue
    .line 2621
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mExtIntent:Landroid/content/Intent;

    return-object v0
.end method

.method public getExtStatus()I
    .locals 3

    .prologue
    .line 2632
    const-string v0, "inavi3d_wooks"

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, " getExtStatus() :: mExtStatus :: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mExtStatus:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 2633
    iget v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mExtStatus:I

    return v0
.end method

.method public getHeapLogFlag()Z
    .locals 1

    .prologue
    .line 1430
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mHeapLogShow:Z

    return v0
.end method

.method public getHeapLogView(Landroid/content/Context;)Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$HeapLogView;
    .locals 2
    .param p1, "context"    # Landroid/content/Context;

    .prologue
    .line 1866
    sget-object v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mHeapLogView:Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$HeapLogView;

    if-nez v0, :cond_1

    .line 1867
    const-class v1, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$HeapLogView;

    monitor-enter v1

    .line 1868
    :try_start_0
    sget-object v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mHeapLogView:Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$HeapLogView;

    if-nez v0, :cond_0

    .line 1869
    new-instance v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$HeapLogView;

    invoke-direct {v0, p0, p1}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$HeapLogView;-><init>(Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;Landroid/content/Context;)V

    sput-object v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mHeapLogView:Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$HeapLogView;

    .line 1871
    :cond_0
    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 1873
    :cond_1
    sget-object v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mHeapLogView:Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$HeapLogView;

    return-object v0

    .line 1871
    :catchall_0
    move-exception v0

    :try_start_1
    monitor-exit v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw v0
.end method

.method public getInnerActivityClassName()Ljava/lang/String;
    .locals 3

    .prologue
    const/4 v2, 0x0

    .line 1046
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getActivityCount()I

    move-result v0

    .line 1048
    .local v0, "activityCount":I
    if-gtz v0, :cond_1

    .line 1058
    :cond_0
    :goto_0
    return-object v2

    .line 1052
    :cond_1
    invoke-direct {p0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getTopINavi3DActivityIndex()I

    move-result v1

    .line 1054
    .local v1, "topIndex":I
    if-ltz v1, :cond_0

    .line 1058
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mActivityInfoArray:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$InnerActivityInfo;

    invoke-virtual {v2}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$InnerActivityInfo;->getInnerActivityClassName()Ljava/lang/String;

    move-result-object v2

    goto :goto_0
.end method

.method public getInnerActivityClassName(I)Ljava/lang/String;
    .locals 3
    .param p1, "stackIndex"    # I

    .prologue
    .line 522
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getActivityCount()I

    move-result v2

    if-ge p1, v2, :cond_0

    .line 523
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mActivityInfoArray:Ljava/util/ArrayList;

    invoke-virtual {v2, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$InnerActivityInfo;

    .line 524
    .local v1, "innerActivityInfo":Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$InnerActivityInfo;
    invoke-virtual {v1}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$InnerActivityInfo;->getInnerActivityClassName()Ljava/lang/String;

    move-result-object v0

    .line 527
    .end local v1    # "innerActivityInfo":Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$InnerActivityInfo;
    :goto_0
    return-object v0

    :cond_0
    const/4 v0, 0x0

    goto :goto_0
.end method

.method public getInnerActivityView()Landroid/view/View;
    .locals 3

    .prologue
    const/4 v2, 0x0

    .line 1025
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getActivityCount()I

    move-result v0

    .line 1027
    .local v0, "activityCount":I
    if-gtz v0, :cond_1

    .line 1037
    :cond_0
    :goto_0
    return-object v2

    .line 1031
    :cond_1
    invoke-direct {p0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getTopINavi3DActivityIndex()I

    move-result v1

    .line 1033
    .local v1, "topIndex":I
    if-ltz v1, :cond_0

    .line 1037
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mActivityInfoArray:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$InnerActivityInfo;

    invoke-virtual {v2}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$InnerActivityInfo;->getInnerActivityView()Landroid/view/View;

    move-result-object v2

    goto :goto_0
.end method

.method public getInnerActivityView(I)Landroid/view/View;
    .locals 3
    .param p1, "stackIndex"    # I

    .prologue
    .line 506
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getActivityCount()I

    move-result v2

    if-ge p1, v2, :cond_0

    .line 507
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mActivityInfoArray:Ljava/util/ArrayList;

    invoke-virtual {v2, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$InnerActivityInfo;

    .line 508
    .local v0, "innerActivityInfo":Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$InnerActivityInfo;
    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$InnerActivityInfo;->getInnerActivityView()Landroid/view/View;

    move-result-object v1

    .line 511
    .end local v0    # "innerActivityInfo":Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$InnerActivityInfo;
    :goto_0
    return-object v1

    :cond_0
    const/4 v1, 0x0

    goto :goto_0
.end method

.method public getIntroView(Landroid/content/Context;)Landroid/view/View;
    .locals 7
    .param p1, "context"    # Landroid/content/Context;

    .prologue
    const/4 v4, 0x0

    const/high16 v6, 0x41300000    # 11.0f

    const/16 v5, 0xff

    .line 1965
    sget-object v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->IntroView:Landroid/view/View;

    if-nez v2, :cond_1

    .line 1966
    const-string v2, "layout_inflater"

    invoke-virtual {p1, v2}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/view/LayoutInflater;

    .line 1967
    .local v0, "inflate":Landroid/view/LayoutInflater;
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v2

    invoke-virtual {v2}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->isSupportAirMode()Z

    move-result v2

    const/4 v3, 0x1

    if-ne v2, v3, :cond_2

    .line 1968
    const v2, 0x7f03006a

    invoke-virtual {v0, v2, v4}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    move-result-object v2

    sput-object v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->IntroView:Landroid/view/View;

    .line 1973
    :goto_0
    sget-object v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->IntroView:Landroid/view/View;

    const v3, 0x7f0a03d3

    invoke-virtual {v2, v3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    .line 1974
    .local v1, "txtviewSimsa":Landroid/widget/TextView;
    if-eqz v1, :cond_0

    .line 1975
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->loadSimsa()Ljava/lang/String;

    move-result-object v2

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, " \uc544\uc774\ub098\ube443DS Ver "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    sget-object v4, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->kInaviVersionName:Ljava/lang/String;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1977
    :cond_0
    const/16 v2, 0x11

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setGravity(I)V

    .line 1978
    const/4 v2, 0x5

    invoke-static {v2}, Lcom/thinkware/sundo/inavi3d/TWFontManager;->getFont(I)Landroid/graphics/Typeface;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 1979
    invoke-virtual {v1, v6}, Landroid/widget/TextView;->setTextSize(F)V

    .line 1980
    const/16 v2, 0x4c

    invoke-static {v2, v5, v5, v5}, Landroid/graphics/Color;->argb(IIII)I

    move-result v2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setTextColor(I)V

    .line 1982
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v2

    invoke-virtual {v2}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->is_support_scale()Z

    move-result v2

    if-eqz v2, :cond_1

    .line 1983
    const/4 v2, 0x0

    invoke-virtual {v1, v2, v6}, Landroid/widget/TextView;->setTextSize(IF)V

    .line 1988
    .end local v0    # "inflate":Landroid/view/LayoutInflater;
    .end local v1    # "txtviewSimsa":Landroid/widget/TextView;
    :cond_1
    sget-object v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->IntroView:Landroid/view/View;

    return-object v2

    .line 1970
    .restart local v0    # "inflate":Landroid/view/LayoutInflater;
    :cond_2
    const v2, 0x7f03006b

    invoke-virtual {v0, v2, v4}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    move-result-object v2

    sput-object v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->IntroView:Landroid/view/View;

    goto :goto_0
.end method

.method public getIsDoOk()Z
    .locals 1

    .prologue
    .line 4812
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mIsDoOk:Z

    return v0
.end method

.method public getMISENLogView(Landroid/content/Context;)Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$MISENLogView;
    .locals 2
    .param p1, "context"    # Landroid/content/Context;

    .prologue
    .line 1417
    sget-object v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mMISENLogView:Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$MISENLogView;

    if-nez v0, :cond_1

    .line 1418
    const-class v1, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$MISENLogView;

    monitor-enter v1

    .line 1419
    :try_start_0
    sget-object v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mMISENLogView:Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$MISENLogView;

    if-nez v0, :cond_0

    .line 1420
    new-instance v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$MISENLogView;

    invoke-direct {v0, p0, p1}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$MISENLogView;-><init>(Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;Landroid/content/Context;)V

    sput-object v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mMISENLogView:Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$MISENLogView;

    .line 1422
    :cond_0
    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 1424
    :cond_1
    sget-object v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mMISENLogView:Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$MISENLogView;

    return-object v0

    .line 1422
    :catchall_0
    move-exception v0

    :try_start_1
    monitor-exit v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw v0
.end method

.method public getMISENShowFlag()Z
    .locals 1

    .prologue
    .line 1340
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mMISENDataShow:Z

    return v0
.end method

.method public getMainClassName()Ljava/lang/String;
    .locals 1

    .prologue
    .line 321
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootActivityClassName:Ljava/lang/String;

    return-object v0
.end method

.method public getNameSearchMapLevel()I
    .locals 1

    .prologue
    .line 2557
    iget v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mNameSearchMapLevel:I

    return v0
.end method

.method public getNameSearchViewModeValue()I
    .locals 1

    .prologue
    .line 2517
    iget v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mNameSearchViewMode:I

    return v0
.end method

.method public getOBD2LogFlag()Z
    .locals 1

    .prologue
    .line 1433
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mOBD2LogShow:Z

    return v0
.end method

.method public getOBD2LogView(Landroid/content/Context;)Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$OBD2LogView;
    .locals 2
    .param p1, "context"    # Landroid/content/Context;

    .prologue
    .line 1636
    sget-object v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mOBD2LogView:Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$OBD2LogView;

    if-nez v0, :cond_1

    .line 1637
    const-class v1, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$HeapLogView;

    monitor-enter v1

    .line 1638
    :try_start_0
    sget-object v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mOBD2LogView:Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$OBD2LogView;

    if-nez v0, :cond_0

    .line 1639
    new-instance v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$OBD2LogView;

    invoke-direct {v0, p0, p1}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$OBD2LogView;-><init>(Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;Landroid/content/Context;)V

    sput-object v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mOBD2LogView:Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$OBD2LogView;

    .line 1641
    :cond_0
    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 1643
    :cond_1
    sget-object v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mOBD2LogView:Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$OBD2LogView;

    return-object v0

    .line 1641
    :catchall_0
    move-exception v0

    :try_start_1
    monitor-exit v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw v0
.end method

.method public getPackageName(Landroid/content/Context;)Ljava/lang/String;
    .locals 1
    .param p1, "packageContext"    # Landroid/content/Context;

    .prologue
    .line 1115
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mPackageName:Ljava/lang/String;

    if-nez v0, :cond_0

    .line 1121
    const-string v0, "com.thinkware.sundo.inavi3d"

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mPackageName:Ljava/lang/String;

    .line 1123
    :cond_0
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mPackageName:Ljava/lang/String;

    return-object v0
.end method

.method public getPositionMovePoint()Lcom/thinkware/sundo/inavi3d/Struct/InaviPoint;
    .locals 3

    .prologue
    const/4 v2, 0x0

    .line 1004
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getActivityCount()I

    move-result v0

    .line 1006
    .local v0, "activityCount":I
    if-gtz v0, :cond_1

    .line 1016
    :cond_0
    :goto_0
    return-object v2

    .line 1010
    :cond_1
    invoke-direct {p0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getTopINavi3DActivityIndex()I

    move-result v1

    .line 1012
    .local v1, "topIndex":I
    if-ltz v1, :cond_0

    .line 1016
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mActivityInfoArray:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$InnerActivityInfo;

    invoke-virtual {v2}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$InnerActivityInfo;->getPositionMovePoint()Lcom/thinkware/sundo/inavi3d/Struct/InaviPoint;

    move-result-object v2

    goto :goto_0
.end method

.method public getPositionMoveType()I
    .locals 3

    .prologue
    const/4 v2, 0x0

    .line 983
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getActivityCount()I

    move-result v0

    .line 985
    .local v0, "activityCount":I
    if-gtz v0, :cond_1

    .line 995
    :cond_0
    :goto_0
    return v2

    .line 989
    :cond_1
    invoke-direct {p0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getTopINavi3DActivityIndex()I

    move-result v1

    .line 991
    .local v1, "topIndex":I
    if-ltz v1, :cond_0

    .line 995
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mActivityInfoArray:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$InnerActivityInfo;

    invoke-virtual {v2}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$InnerActivityInfo;->getPositionMoveType()I

    move-result v2

    goto :goto_0
.end method

.method public getResultMapmode()I
    .locals 3

    .prologue
    .line 4760
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->getInstance()Lcom/thinkware/sundo/inavi3d/InaviConfig;

    move-result-object v1

    const/16 v2, 0x107

    invoke-virtual {v1, v2}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->CNaviConfigGet(I)I

    move-result v0

    .line 4779
    .local v0, "resultMapmode":I
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v1

    invoke-virtual {v1}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->isSupportAirMode()Z

    move-result v1

    if-nez v1, :cond_1

    .line 4780
    const/4 v0, 0x0

    .line 4787
    :cond_0
    :goto_0
    return v0

    .line 4782
    :cond_1
    const/4 v1, 0x2

    if-ne v0, v1, :cond_0

    .line 4783
    const/4 v0, 0x1

    goto :goto_0
.end method

.method public getRootActivityStatus()I
    .locals 1

    .prologue
    .line 332
    iget v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootActivityStatus:I

    return v0
.end method

.method public getRoutePointManageViewModeValue()I
    .locals 1

    .prologue
    .line 2533
    iget v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRoutePointManageViewMode:I

    return v0
.end method

.method public getSuperCapPowerOff()Z
    .locals 1

    .prologue
    .line 4801
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->m_bSuperCapPowerOff:Z

    return v0
.end method

.method public getViewModeValue()I
    .locals 1

    .prologue
    .line 2541
    iget v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mViewMode:I

    return v0
.end method

.method public getWaitCursorForAsync(Landroid/content/Context;)Landroid/view/View;
    .locals 4
    .param p1, "context"    # Landroid/content/Context;

    .prologue
    const v3, 0x7f0a0a3f

    .line 1883
    const-string v0, "progress"

    const-string v1, "getWaitCursor"

    invoke-static {v0, v1}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 1884
    sget-object v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->WaitCursorForAsync:Landroid/view/View;

    if-nez v0, :cond_0

    .line 1885
    const-string v0, "layout_inflater"

    invoke-virtual {p1, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/view/LayoutInflater;

    const v1, 0x7f03016d

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    move-result-object v0

    sput-object v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->WaitCursorForAsync:Landroid/view/View;

    .line 1886
    sget-object v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->WaitCursorForAsync:Landroid/view/View;

    invoke-virtual {v0, v3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    new-instance v1, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$2;

    invoke-direct {v1, p0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$2;-><init>(Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;)V

    invoke-virtual {v0, v1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 1895
    sget-object v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->WaitCursorForAsync:Landroid/view/View;

    invoke-virtual {v0, v3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    new-instance v1, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$3;

    invoke-direct {v1, p0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$3;-><init>(Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;)V

    invoke-virtual {v0, v1}, Landroid/view/View;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    .line 1904
    :cond_0
    sget-object v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->WaitCursorForAsync:Landroid/view/View;

    return-object v0
.end method

.method public getWaitCursorForAsync1(Landroid/content/Context;)Landroid/view/View;
    .locals 4
    .param p1, "context"    # Landroid/content/Context;

    .prologue
    const v3, 0x7f0a0a40

    .line 1908
    sget-object v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->WaitCursorForAsync1:Landroid/view/View;

    if-nez v0, :cond_0

    .line 1909
    const-string v0, "layout_inflater"

    invoke-virtual {p1, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/view/LayoutInflater;

    const v1, 0x7f03016e

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    move-result-object v0

    sput-object v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->WaitCursorForAsync1:Landroid/view/View;

    .line 1910
    sget-object v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->WaitCursorForAsync1:Landroid/view/View;

    invoke-virtual {v0, v3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    new-instance v1, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$4;

    invoke-direct {v1, p0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$4;-><init>(Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;)V

    invoke-virtual {v0, v1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 1919
    sget-object v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->WaitCursorForAsync1:Landroid/view/View;

    invoke-virtual {v0, v3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    new-instance v1, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$5;

    invoke-direct {v1, p0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$5;-><init>(Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;)V

    invoke-virtual {v0, v1}, Landroid/view/View;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    .line 1928
    :cond_0
    sget-object v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->WaitCursorForAsync1:Landroid/view/View;

    return-object v0
.end method

.method public getWaterMark(Landroid/content/Context;Z)Landroid/view/View;
    .locals 5
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "isAir"    # Z

    .prologue
    const/16 v4, 0x71

    const/16 v3, 0x2f

    const/16 v2, 0x8

    .line 1932
    if-eqz p2, :cond_1

    .line 1934
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->m_warterMarkAir:Landroid/view/View;

    if-nez v0, :cond_0

    .line 1935
    new-instance v0, Landroid/view/View;

    invoke-direct {v0, p1}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->m_warterMarkAir:Landroid/view/View;

    .line 1936
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->m_warterMarkAir:Landroid/view/View;

    const v1, 0x7f020c09

    invoke-virtual {v0, v1}, Landroid/view/View;->setBackgroundResource(I)V

    .line 1937
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->m_warterMarkAir:Landroid/view/View;

    new-instance v1, Landroid/widget/FrameLayout$LayoutParams;

    invoke-direct {v1, v4, v3}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v1}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 1938
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->m_warterMarkAir:Landroid/view/View;

    invoke-virtual {v0, v2}, Landroid/view/View;->setVisibility(I)V

    .line 1939
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v0

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->is_support_scale()Z

    move-result v0

    if-eqz v0, :cond_0

    .line 1940
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INaviScaleManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INaviScaleManager;

    move-result-object v0

    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->m_warterMarkAir:Landroid/view/View;

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/inavi3d/INaviScaleManager;->scaleView(Landroid/view/View;)V

    .line 1946
    :cond_0
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->m_warterMarkAir:Landroid/view/View;

    .line 1960
    :goto_0
    return-object v0

    .line 1948
    :cond_1
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->m_warterMark3D:Landroid/view/View;

    if-nez v0, :cond_2

    .line 1949
    new-instance v0, Landroid/view/View;

    invoke-direct {v0, p1}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->m_warterMark3D:Landroid/view/View;

    .line 1950
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->m_warterMark3D:Landroid/view/View;

    new-instance v1, Landroid/widget/FrameLayout$LayoutParams;

    invoke-direct {v1, v4, v3}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v1}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 1951
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->m_warterMark3D:Landroid/view/View;

    const v1, 0x7f020c08

    invoke-virtual {v0, v1}, Landroid/view/View;->setBackgroundResource(I)V

    .line 1952
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->m_warterMark3D:Landroid/view/View;

    invoke-virtual {v0, v2}, Landroid/view/View;->setVisibility(I)V

    .line 1953
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v0

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->is_support_scale()Z

    move-result v0

    if-eqz v0, :cond_2

    .line 1954
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INaviScaleManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INaviScaleManager;

    move-result-object v0

    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->m_warterMark3D:Landroid/view/View;

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/inavi3d/INaviScaleManager;->scaleView(Landroid/view/View;)V

    .line 1960
    :cond_2
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->m_warterMark3D:Landroid/view/View;

    goto :goto_0
.end method

.method public getinavi()Landroid/content/Context;
    .locals 1

    .prologue
    .line 4754
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    return-object v0
.end method

.method public hideAdas(Z)V
    .locals 1
    .param p1, "animation"    # Z

    .prologue
    .line 5252
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mAdasService:Lcom/thinkware/sundo/inavi3dservice/AdasService;

    if-eqz v0, :cond_0

    .line 5253
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mAdasService:Lcom/thinkware/sundo/inavi3dservice/AdasService;

    invoke-virtual {v0, p1}, Lcom/thinkware/sundo/inavi3dservice/AdasService;->hideAdas(Z)V

    .line 5255
    :cond_0
    return-void
.end method

.method public hideBar()V
    .locals 2

    .prologue
    .line 2142
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    if-eqz v0, :cond_0

    .line 2143
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    check-cast v0, Landroid/app/Activity;

    invoke-virtual {v0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v0

    const/16 v1, 0xd04

    invoke-virtual {v0, v1}, Landroid/view/View;->setSystemUiVisibility(I)V

    .line 2149
    :cond_0
    return-void
.end method

.method public hideStatusBar()Z
    .locals 1

    .prologue
    .line 2300
    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->hideStatusBar(Z)Z

    move-result v0

    return v0
.end method

.method public hideStatusBar(Z)Z
    .locals 7
    .param p1, "isCheck"    # Z

    .prologue
    const/4 v5, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x0

    .line 2155
    goto/16 :goto_1

    :cond_0
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v3

    invoke-virtual {v3}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetDeviceModelType()I

    move-result v3

    const/4 v4, 0x3

    if-eq v3, v4, :cond_0

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v3

    invoke-virtual {v3}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetDeviceModelType()I

    move-result v3

    const/4 v4, 0x4

    if-eq v3, v4, :cond_0

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v3

    invoke-virtual {v3}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetDeviceModelType()I

    move-result v3

    const/4 v4, 0x5

    if-eq v3, v4, :cond_0

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v3

    invoke-virtual {v3}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetDeviceModelType()I

    move-result v3

    const/4 v4, 0x6

    if-eq v3, v4, :cond_0

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v3

    invoke-virtual {v3}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetDeviceModelType()I

    move-result v3

    const/4 v4, 0x7

    if-eq v3, v4, :cond_0

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v3

    invoke-virtual {v3}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetDeviceModelType()I

    move-result v3

    const/16 v4, 0x8

    if-eq v3, v4, :cond_0

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v3

    invoke-virtual {v3}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetDeviceModelType()I

    move-result v3

    const/16 v4, 0x9

    if-eq v3, v4, :cond_0

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v3

    invoke-virtual {v3}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->IsDAVINCIOrder()Z

    move-result v3

    if-ne v3, v1, :cond_1

    .line 2164
    invoke-virtual {p0, p1}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->hideStatusBarTaurus(Z)Z

    move-result v1

    .line 2196
    :goto_0
    return v1

    .line 2166
    :cond_1
    :goto_1
    const-string v3, "inavi3d_StatusBar"

    const-string v4, "\t\tCall hideStatusBar() - mBarShown(%b) mAllwaysBarShown(%b)"

    new-array v5, v5, [Ljava/lang/Object;

    iget-boolean v6, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mBarShown:Z

    invoke-static {v6}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v6

    aput-object v6, v5, v2

    iget-boolean v6, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mAllwaysBarShown:Z

    invoke-static {v6}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v6

    aput-object v6, v5, v1

    invoke-static {v4, v5}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v3, v4}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 2168
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    if-eqz v3, :cond_2

    iget-boolean v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mBarShown:Z

    if-eqz v3, :cond_2

    iget-boolean v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mAllwaysBarShown:Z

    if-eqz v3, :cond_3

    :cond_2
    if-nez p1, :cond_4

    .line 2169
    :cond_3
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootLayout:Landroid/view/View;

    .line 2172
    .local v0, "rootLayout":Landroid/view/View;
    new-instance v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$6;

    invoke-direct {v2, p0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$6;-><init>(Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;)V

    invoke-virtual {v0, v2}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    goto :goto_0

    .line 2194
    .end local v0    # "rootLayout":Landroid/view/View;
    :cond_4
    const-string v1, "inavi3d_StatusBar"

    const-string v3, "\t\tCall hideStatusBar() - Fail3"

    new-array v4, v2, [Ljava/lang/Object;

    invoke-static {v3, v4}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-static {v1, v3}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    move v1, v2

    .line 2196
    goto :goto_0
.end method

.method public hideStatusBarTaurus(Z)Z
    .locals 7
    .param p1, "isCheck"    # Z

    .prologue
    const/4 v2, 0x1

    const/4 v1, 0x0

    .line 2201
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v3

    invoke-virtual {v3}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->IsDAVINCIOrder()Z

    move-result v3

    if-ne v3, v2, :cond_2

    .line 2202
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v3

    if-eqz v3, :cond_0

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v3

    invoke-virtual {v3}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->checkForegroundInavi3d()Z

    move-result v3

    if-eqz v3, :cond_1

    :cond_0
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->isHideBar()Z

    move-result v3

    if-eq v3, v2, :cond_1

    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->isClosedWarning()Z

    move-result v3

    if-eqz v3, :cond_1

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v3

    invoke-virtual {v3}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->isTutorialShow()Z

    move-result v3

    if-eq v3, v2, :cond_1

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/RouteCompareManager;->getInstance()Lcom/thinkware/sundo/inavi3d/RouteCompareManager;

    move-result-object v3

    invoke-virtual {v3}, Lcom/thinkware/sundo/inavi3d/RouteCompareManager;->isShowMyRouteComparePopup()Z

    move-result v3

    if-ne v3, v2, :cond_2

    .line 2296
    :cond_1
    :goto_0
    return v1

    .line 2212
    :cond_2
    const-string v3, "inavi3d_StatusBar"

    const-string v4, "\t\tCall hideStatusBarTaurus() - mBarShown(%b) mAllwaysBarShown(%b)"

    const/4 v5, 0x2

    new-array v5, v5, [Ljava/lang/Object;

    iget-boolean v6, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mBarShown:Z

    invoke-static {v6}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v6

    aput-object v6, v5, v1

    iget-boolean v6, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mAllwaysBarShown:Z

    invoke-static {v6}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v6

    aput-object v6, v5, v2

    invoke-static {v4, v5}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v3, v4}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 2214
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    if-eqz v3, :cond_3

    iget-boolean v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mBarShown:Z

    if-eqz v3, :cond_3

    iget-boolean v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mAllwaysBarShown:Z

    if-eqz v3, :cond_4

    :cond_3
    if-nez p1, :cond_6

    .line 2215
    :cond_4
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootLayout:Landroid/view/View;

    .line 2218
    .local v0, "rootLayout":Landroid/view/View;
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->isInitFlag()Z

    move-result v3

    if-eqz v3, :cond_5

    .line 2219
    const-string v3, "ActivityLifeCycle"

    const-string v4, "HIDE STATUS BAR"

    invoke-static {v3, v4}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 2220
    new-instance v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$7;

    invoke-direct {v3, p0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$7;-><init>(Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;)V

    invoke-virtual {v0, v3}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    .line 2288
    invoke-virtual {p0, v1}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->SetBarShown(Z)V

    .line 2289
    const-string v3, "inavi3d_StatusBar"

    const-string v4, "\t\tCall hideStatusBarTaurus() - Success"

    new-array v1, v1, [Ljava/lang/Object;

    invoke-static {v4, v1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v3, v1}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    :goto_1
    move v1, v2

    .line 2293
    goto :goto_0

    .line 2291
    :cond_5
    const-string v3, "inavi3d_StatusBar"

    const-string v4, "\t\tCall hideStatusBarTaurus() - Fail1"

    new-array v1, v1, [Ljava/lang/Object;

    invoke-static {v4, v1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v3, v1}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_1

    .line 2295
    .end local v0    # "rootLayout":Landroid/view/View;
    :cond_6
    const-string v2, "inavi3d_StatusBar"

    const-string v3, "\t\tCall hideStatusBarTaurus() - Fail3"

    new-array v4, v1, [Ljava/lang/Object;

    invoke-static {v3, v4}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_0
.end method

.method public initAutoArMode()V
    .locals 3

    .prologue
    .line 4656
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->getInstance()Lcom/thinkware/sundo/inavi3d/InaviConfig;

    move-result-object v0

    const/16 v1, 0x5a

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->CNaviConfigGet(I)I

    move-result v0

    iput v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->camear_nomal_500:I

    .line 4657
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->getInstance()Lcom/thinkware/sundo/inavi3d/InaviConfig;

    move-result-object v0

    const/16 v1, 0x5b

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->CNaviConfigGet(I)I

    move-result v0

    iput v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->camear_nomal_300:I

    .line 4658
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->getInstance()Lcom/thinkware/sundo/inavi3d/InaviConfig;

    move-result-object v0

    const/16 v1, 0x5c

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->CNaviConfigGet(I)I

    move-result v0

    iput v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->camear_nomal_100:I

    .line 4660
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->getInstance()Lcom/thinkware/sundo/inavi3d/InaviConfig;

    move-result-object v0

    const/16 v1, 0x86

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->CNaviConfigGet(I)I

    move-result v0

    iput v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->nDinamic:I

    .line 4662
    const-string v0, "inavi3d_wooks_auto"

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "initAutoArMode() 1 !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! camear_nomal_500 :: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->camear_nomal_500:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 4663
    const-string v0, "inavi3d_wooks_auto"

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "initAutoArMode() 1 !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! camear_nomal_300 :: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->camear_nomal_300:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 4664
    const-string v0, "inavi3d_wooks_auto"

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "initAutoArMode() 1 !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! camear_nomal_100 :: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->camear_nomal_100:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 4665
    const-string v0, "inavi3d_wooks_auto"

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "initAutoArMode() 1 !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! nDinamic :: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->nDinamic:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 4666
    return-void
.end method

.method public isAINASearchCommands(Landroid/content/Intent;)Z
    .locals 5
    .param p1, "msg"    # Landroid/content/Intent;

    .prologue
    const/4 v2, 0x1

    .line 4495
    if-eqz p1, :cond_2

    invoke-virtual {p1}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    move-result-object v3

    if-eqz v3, :cond_2

    .line 4496
    invoke-virtual {p1}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    move-result-object v3

    const-string v4, "EXTTYPE"

    invoke-virtual {v3, v4}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 4498
    .local v1, "strExtType":Ljava/lang/String;
    if-eqz v1, :cond_2

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v3

    if-lez v3, :cond_2

    const-string v3, "VoiceCommander"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_2

    .line 4500
    const-string v3, "VOICE_COMMAND"

    invoke-virtual {p1, v3}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    if-eqz v3, :cond_2

    .line 4501
    const-string v3, "VOICE_COMMAND"

    invoke-virtual {p1, v3}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 4502
    .local v0, "strCommand":Ljava/lang/String;
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v3

    if-lez v3, :cond_2

    .line 4503
    const-string v3, "\uc9c0\uc5ed\uc124\uc815|\ubc18\uacbd\uc124\uc815|\ub2e4\uc2dc\ucc3e\uae30|\uccab\ubc88\uc9f8|\ub450\ubc88\uc9f8|\uc138\ubc88\uc9f8|\ub124\ubc88\uc9f8|\ub2e4\uc12f\ubc88\uc9f8|\uc5ec\uc12f\ubc88\uc9f8|\uc774\uc804\ud398\uc774\uc9c0|\ub2e4\uc74c\ud398\uc774\uc9c0|"

    invoke-virtual {v3, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v3

    if-ne v3, v2, :cond_1

    .line 4515
    .end local v0    # "strCommand":Ljava/lang/String;
    .end local v1    # "strExtType":Ljava/lang/String;
    :cond_0
    :goto_0
    return v2

    .line 4506
    .restart local v0    # "strCommand":Ljava/lang/String;
    .restart local v1    # "strExtType":Ljava/lang/String;
    :cond_1
    const-string v3, "\uc804\uad6d|\uacbd\uae30\ub3c4|\uc778\ucc9c|\uc11c\uc6b8|\uac15\uc6d0\ub3c4|\uc138\uc885|\ucda9\uccad\ubd81\ub3c4|\ucda9\uccad\ub0a8\ub3c4|\ub300\uc804|\uacbd\uc0c1\ubd81\ub3c4|\uacbd\uc0c1\ub0a8\ub3c4|\uc804\ub77c\ubd81\ub3c4|\uc804\ub77c\ub0a8\ub3c4|\ub300\uad6c|\uc6b8\uc0b0|\uad11\uc8fc|\ubd80\uc0b0|\uc81c\uc8fc\ub3c4|\ubc18\uacbd\uc77c\ud0a4\ub85c\ubbf8\ud130|\ubc18\uacbd\uc774\ud0a4\ub85c\ubbf8\ud130|\ubc18\uacbd\uc624\ud0a4\ub85c\ubbf8\ud130|\ubc18\uacbd\ud314\ud0a4\ub85c\ubbf8\ud130|\ubc18\uacbd\uc2ed\ud0a4\ub85c\ubbf8\ud130"

    invoke-virtual {v3, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v3

    if-eq v3, v2, :cond_0

    .line 4515
    .end local v0    # "strCommand":Ljava/lang/String;
    .end local v1    # "strExtType":Ljava/lang/String;
    :cond_2
    const/4 v2, 0x0

    goto :goto_0
.end method

.method public isAllwaysBarShow()Z
    .locals 1

    .prologue
    .line 2088
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mAllwaysBarShown:Z

    return v0
.end method

.method public isAutoRunInaviBySetting()Z
    .locals 1

    .prologue
    .line 3729
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mbAutoRunInaviByStting:Z

    return v0
.end method

.method public isBSDStatusOn()Z
    .locals 1

    .prologue
    .line 4587
    const/4 v0, 0x1

    return v0
.end method

.method public isBackActivity()Z
    .locals 1

    .prologue
    .line 1131
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mBackActivity:Z

    return v0
.end method

.method public isBarShown()Z
    .locals 1

    .prologue
    .line 2122
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mBarShown:Z

    return v0
.end method

.method public isCalledInaviFromLauncherInaviIcon()Z
    .locals 7

    .prologue
    const/4 v4, 0x1

    const/4 v5, 0x0

    .line 2579
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mActivityManager:Landroid/app/ActivityManager;

    const/16 v6, 0xa

    invoke-virtual {v3, v6}, Landroid/app/ActivityManager;->getRunningTasks(I)Ljava/util/List;

    move-result-object v0

    .line 2580
    .local v0, "info":Ljava/util/List;, "Ljava/util/List<Landroid/app/ActivityManager$RunningTaskInfo;>;"
    invoke-interface {v0, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/app/ActivityManager$RunningTaskInfo;

    iget-object v3, v3, Landroid/app/ActivityManager$RunningTaskInfo;->topActivity:Landroid/content/ComponentName;

    invoke-virtual {v3}, Landroid/content/ComponentName;->getPackageName()Ljava/lang/String;

    move-result-object v1

    .line 2581
    .local v1, "mayBeInaviPackage":Ljava/lang/String;
    invoke-interface {v0, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/app/ActivityManager$RunningTaskInfo;

    iget-object v3, v3, Landroid/app/ActivityManager$RunningTaskInfo;->topActivity:Landroid/content/ComponentName;

    invoke-virtual {v3}, Landroid/content/ComponentName;->getPackageName()Ljava/lang/String;

    move-result-object v2

    .line 2582
    .local v2, "mayBeLauncherPackage":Ljava/lang/String;
    const-string v3, ""

    invoke-virtual {v1, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v3

    if-eqz v3, :cond_0

    const-string v3, ""

    invoke-virtual {v2, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v3

    if-eqz v3, :cond_0

    move v3, v4

    .line 2585
    :goto_0
    return v3

    :cond_0
    move v3, v5

    goto :goto_0
.end method

.method public isClosedWarning()Z
    .locals 1

    .prologue
    .line 2110
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mBWarningClosed:Z

    return v0
.end method

.method public isCurrentFlag()Z
    .locals 1

    .prologue
    .line 904
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mCurrentOn:Z

    return v0
.end method

.method public isCurrentOffAndRootActivity()Z
    .locals 3

    .prologue
    .line 2099
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mActivityInfoArray:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v0

    .line 2100
    .local v0, "size":I
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->isCurrentFlag()Z

    move-result v1

    if-nez v1, :cond_1

    if-eqz v0, :cond_0

    if-lez v0, :cond_1

    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mActivityInfoArray:Ljava/util/ArrayList;

    add-int/lit8 v2, v0, -0x1

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$InnerActivityInfo;

    invoke-virtual {v1}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$InnerActivityInfo;->getActivityClassName()Ljava/lang/String;

    move-result-object v1

    const-string v2, "com.thinkware.sundo.inavi3d.INavi3DActivity"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_1

    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mActivityInfoArray:Ljava/util/ArrayList;

    add-int/lit8 v2, v0, -0x1

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$InnerActivityInfo;

    invoke-virtual {v1}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$InnerActivityInfo;->getInnerActivityClassName()Ljava/lang/String;

    move-result-object v1

    if-nez v1, :cond_1

    .line 2104
    :cond_0
    const/4 v1, 0x1

    .line 2106
    :goto_0
    return v1

    :cond_1
    const/4 v1, 0x0

    goto :goto_0
.end method

.method public isCurrentOnAndRootActivity()Z
    .locals 2

    .prologue
    const/4 v0, 0x1

    .line 2092
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->isCurrentFlag()Z

    move-result v1

    if-ne v1, v0, :cond_0

    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mActivityInfoArray:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-nez v1, :cond_0

    .line 2095
    :goto_0
    return v0

    :cond_0
    const/4 v0, 0x0

    goto :goto_0
.end method

.method public isDoingCurrentOn()Z
    .locals 1

    .prologue
    .line 892
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mIsDoingCurrentOn:Z

    return v0
.end method

.method public isEexcuteRenderInNameSrchActvity()Z
    .locals 1

    .prologue
    .line 2500
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mbEexcuteRenderInNameSrchActvity:Z

    return v0
.end method

.method public isEnabledTrafficMap()Z
    .locals 1

    .prologue
    .line 2549
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mbEnabledTrafficMap:Z

    return v0
.end method

.method public isExtCurrentMap()Z
    .locals 1

    .prologue
    .line 3498
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mbExtCurrentMap:Z

    return v0
.end method

.method public isHideBar()Z
    .locals 1

    .prologue
    .line 2134
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mIsHideBar:Z

    return v0
.end method

.method public isInitFlag()Z
    .locals 1

    .prologue
    .line 922
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mInitFlag:Z

    return v0
.end method

.method public isIntroView()Z
    .locals 1

    .prologue
    .line 1992
    sget-object v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->IntroView:Landroid/view/View;

    if-nez v0, :cond_0

    .line 1993
    const/4 v0, 0x0

    .line 1995
    :goto_0
    return v0

    :cond_0
    const/4 v0, 0x1

    goto :goto_0
.end method

.method public isLowMemory()Z
    .locals 1

    .prologue
    .line 3887
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mLowMemory:Z

    return v0
.end method

.method public isMoveActivity()Z
    .locals 3

    .prologue
    .line 3878
    const-string v0, "inavi3d_wooks_moveActivity"

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, " isMoveActivity :: moveActivity :: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-boolean v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mIsMoveActivity:Z

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 3879
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mIsMoveActivity:Z

    return v0
.end method

.method public isMoveRootActivity()Z
    .locals 1

    .prologue
    .line 3868
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mIsMoveRootActivity:Z

    return v0
.end method

.method public isMoveRootView()Z
    .locals 1

    .prologue
    .line 2574
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mMoveRootView:Z

    return v0
.end method

.method public isReadyDPMap()Z
    .locals 1

    .prologue
    .line 2493
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mbReadyForDPMap:Z

    return v0
.end method

.method public isRoadView()Z
    .locals 1

    .prologue
    .line 2084
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRoadViewShow:Z

    return v0
.end method

.method public isShowAdas()Z
    .locals 1

    .prologue
    .line 5204
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mIsShowAdas:Z

    return v0
.end method

.method public isShowScreenMirroring()Z
    .locals 1

    .prologue
    .line 4556
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mIsShowScreenMirroring:Z

    return v0
.end method

.method public isValidateTimeLock()Z
    .locals 1

    .prologue
    .line 2485
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mbValidateTimeLock:Z

    return v0
.end method

.method public lowMemoryStartProcess(Landroid/content/Context;)Z
    .locals 7
    .param p1, "context"    # Landroid/content/Context;

    .prologue
    const/4 v2, 0x0

    const/4 v3, 0x1

    .line 3939
    const-string v4, "inavi3d_wooks_lowmem"

    const-string v5, "lowMemoryStartProcess"

    invoke-static {v4, v5}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 3941
    invoke-static {v3}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->_CheckRunSpec(Z)I

    .line 3943
    const-string v1, ""

    .line 3945
    .local v1, "strStorageDir":Ljava/lang/String;
    sget-object v1, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->SD_EXT_STORAGE_PATH:Ljava/lang/String;

    .line 3946
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string v5, "/inavi3d/iNaviData/lowmemcheck.dat"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .line 3948
    const-string v4, "inavi3d_wooks_lowmem"

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "lowMemoryStartProcess :: path :: "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-static {v4, v5}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 3950
    new-instance v0, Ljava/io/File;

    invoke-direct {v0, v1}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 3952
    .local v0, "file":Ljava/io/File;
    if-nez v0, :cond_1

    .line 3974
    :cond_0
    :goto_0
    return v2

    .line 3956
    :cond_1
    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v4

    if-ne v4, v3, :cond_0

    .line 3957
    invoke-virtual {v0}, Ljava/io/File;->delete()Z

    .line 3958
    const-string v2, "inavi3d_wooks_lowmem"

    const-string v4, "files.exists() :: true"

    invoke-static {v2, v4}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    move v2, v3

    .line 3972
    goto :goto_0
.end method

.method public lowMemorykillProcess(Landroid/content/Context;)V
    .locals 11
    .param p1, "context"    # Landroid/content/Context;

    .prologue
    .line 3891
    const-string v8, "inavi3d_wooks_lowmem"

    const-string v9, "lowMemorykillProcess"

    invoke-static {v8, v9}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 3892
    const-string v6, ""

    .line 3894
    .local v6, "strStorageDir":Ljava/lang/String;
    sget-object v6, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->SD_EXT_STORAGE_PATH:Ljava/lang/String;

    .line 3895
    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v8, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    const-string v9, "/inavi3d/iNaviData/lowmemcheck.dat"

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    .line 3897
    const-string v8, "inavi3d_wooks_lowmem"

    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    const-string v10, "lowMemorykillProcess :: path :: "

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-static {v8, v9}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 3899
    new-instance v2, Ljava/io/File;

    invoke-direct {v2, v6}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 3901
    .local v2, "fileCheck":Ljava/io/File;
    invoke-virtual {v2}, Ljava/io/File;->exists()Z

    move-result v8

    const/4 v9, 0x1

    if-ne v8, v9, :cond_0

    .line 3902
    invoke-virtual {v2}, Ljava/io/File;->delete()Z

    .line 3905
    :cond_0
    new-instance v1, Ljava/io/File;

    invoke-direct {v1, v6}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 3906
    .local v1, "file":Ljava/io/File;
    const-string v7, "lowMemorykillProcess"

    .line 3908
    .local v7, "text":Ljava/lang/String;
    const/4 v3, 0x0

    .line 3910
    .local v3, "fos":Ljava/io/FileOutputStream;
    :try_start_0
    new-instance v4, Ljava/io/FileOutputStream;

    invoke-direct {v4, v1}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    .line 3911
    .end local v3    # "fos":Ljava/io/FileOutputStream;
    .local v4, "fos":Ljava/io/FileOutputStream;
    :try_start_1
    invoke-virtual {v7}, Ljava/lang/String;->getBytes()[B

    move-result-object v8

    invoke-virtual {v4, v8}, Ljava/io/FileOutputStream;->write([B)V

    .line 3912
    invoke-virtual {v4}, Ljava/io/FileOutputStream;->close()V
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_2

    move-object v3, v4

    .line 3917
    .end local v4    # "fos":Ljava/io/FileOutputStream;
    .restart local v3    # "fos":Ljava/io/FileOutputStream;
    :goto_0
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v8

    invoke-virtual {v8}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->quitGuidanceThread()V

    .line 3919
    const/4 v5, 0x0

    .line 3920
    .local v5, "sleepCount":I
    :goto_1
    sget-boolean v8, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->EndThread_Condition_Guidance:Z

    if-nez v8, :cond_1

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DPView;->isExecuteRender()Z

    move-result v8

    if-eqz v8, :cond_2

    .line 3922
    :cond_1
    const/16 v8, 0x64

    if-le v5, v8, :cond_3

    .line 3934
    :cond_2
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    move-result-object v8

    invoke-virtual {v8, p1}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->showStatusBarForce(Landroid/content/Context;)V

    .line 3935
    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result v8

    invoke-static {v8}, Landroid/os/Process;->killProcess(I)V

    .line 3936
    return-void

    .line 3913
    .end local v5    # "sleepCount":I
    :catch_0
    move-exception v0

    .line 3914
    .local v0, "e":Ljava/io/IOException;
    :goto_2
    invoke-virtual {v0}, Ljava/io/IOException;->printStackTrace()V

    goto :goto_0

    .line 3926
    .end local v0    # "e":Ljava/io/IOException;
    .restart local v5    # "sleepCount":I
    :cond_3
    const-wide/16 v8, 0x5

    :try_start_2
    invoke-static {v8, v9}, Ljava/lang/Thread;->sleep(J)V
    :try_end_2
    .catch Ljava/lang/InterruptedException; {:try_start_2 .. :try_end_2} :catch_1

    goto :goto_1

    .line 3927
    :catch_1
    move-exception v0

    .line 3929
    .local v0, "e":Ljava/lang/InterruptedException;
    invoke-virtual {v0}, Ljava/lang/InterruptedException;->printStackTrace()V

    goto :goto_1

    .line 3913
    .end local v0    # "e":Ljava/lang/InterruptedException;
    .end local v3    # "fos":Ljava/io/FileOutputStream;
    .end local v5    # "sleepCount":I
    .restart local v4    # "fos":Ljava/io/FileOutputStream;
    :catch_2
    move-exception v0

    move-object v3, v4

    .end local v4    # "fos":Ljava/io/FileOutputStream;
    .restart local v3    # "fos":Ljava/io/FileOutputStream;
    goto :goto_2
.end method

.method public moveCurrentLocation(Z)V
    .locals 1
    .param p1, "isCurrent"    # Z

    .prologue
    .line 615
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    if-nez v0, :cond_0

    .line 619
    :goto_0
    return-void

    .line 618
    :cond_0
    const/4 v0, 0x0

    invoke-direct {p0, v0, p1}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->moveToRootActivity(Landroid/content/Intent;Z)V

    goto :goto_0
.end method

.method public moveToActivity(Ljava/lang/String;)V
    .locals 8
    .param p1, "activityClassName"    # Ljava/lang/String;

    .prologue
    const/4 v7, 0x1

    .line 675
    iget-object v6, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    if-nez v6, :cond_1

    .line 706
    :cond_0
    :goto_0
    return-void

    .line 679
    :cond_1
    iget-object v6, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    invoke-virtual {v6}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v5

    .line 680
    .local v5, "packageName":Ljava/lang/String;
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getActivityCount()I

    move-result v0

    .line 682
    .local v0, "activityCount":I
    if-lez v0, :cond_0

    .line 683
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->backActivityFromMap()V

    .line 685
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getActivityCount()I

    move-result v0

    .line 687
    add-int/lit8 v1, v0, -0x1

    .local v1, "activityIndex":I
    :goto_1
    if-ltz v1, :cond_0

    .line 688
    iget-object v6, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mActivityInfoArray:Ljava/util/ArrayList;

    invoke-virtual {v6, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$InnerActivityInfo;

    .line 689
    .local v3, "innerActivityInfo":Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$InnerActivityInfo;
    invoke-virtual {v3}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$InnerActivityInfo;->getActivityClassName()Ljava/lang/String;

    move-result-object v2

    .line 691
    .local v2, "className":Ljava/lang/String;
    invoke-virtual {v2, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-ne v6, v7, :cond_2

    .line 692
    new-instance v4, Landroid/content/Intent;

    invoke-direct {v4}, Landroid/content/Intent;-><init>()V

    .line 693
    .local v4, "intent":Landroid/content/Intent;
    new-instance v6, Landroid/content/ComponentName;

    invoke-direct {v6, v5, v2}, Landroid/content/ComponentName;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v4, v6}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;

    .line 694
    const/high16 v6, 0x24010000

    invoke-virtual {v4, v6}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;

    .line 697
    iget-object v6, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    invoke-virtual {v6, v4}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    goto :goto_0

    .line 700
    .end local v4    # "intent":Landroid/content/Intent;
    :cond_2
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getMainClassName()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v2, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-ne v6, v7, :cond_3

    .line 701
    iget-object v6, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    invoke-virtual {p0, v6}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->popActivity(Landroid/content/Context;)V

    .line 687
    :cond_3
    add-int/lit8 v1, v1, -0x1

    goto :goto_1
.end method

.method public moveToInnerActivity(Ljava/lang/String;)V
    .locals 10
    .param p1, "innerActivityClassName"    # Ljava/lang/String;

    .prologue
    .line 710
    iget-object v8, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    if-nez v8, :cond_1

    .line 743
    :cond_0
    :goto_0
    return-void

    .line 714
    :cond_1
    iget-object v8, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    invoke-virtual {v8}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v5

    .line 715
    .local v5, "packageName":Ljava/lang/String;
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getActivityCount()I

    move-result v0

    .line 717
    .local v0, "activityCount":I
    if-lez v0, :cond_0

    .line 718
    add-int/lit8 v1, v0, -0x1

    .local v1, "activityIndex":I
    :goto_1
    if-ltz v1, :cond_0

    .line 719
    iget-object v8, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mActivityInfoArray:Ljava/util/ArrayList;

    invoke-virtual {v8, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$InnerActivityInfo;

    .line 720
    .local v3, "innerActivityInfo":Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$InnerActivityInfo;
    invoke-virtual {v3}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$InnerActivityInfo;->getActivityClassName()Ljava/lang/String;

    move-result-object v2

    .line 722
    .local v2, "className":Ljava/lang/String;
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getMainClassName()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v2, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v8

    if-nez v8, :cond_2

    .line 723
    new-instance v6, Landroid/content/Intent;

    invoke-direct {v6}, Landroid/content/Intent;-><init>()V

    .line 724
    .local v6, "popIntent":Landroid/content/Intent;
    new-instance v8, Landroid/content/ComponentName;

    invoke-direct {v8, v5, v2}, Landroid/content/ComponentName;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v6, v8}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;

    .line 725
    const/high16 v8, 0x30000

    invoke-virtual {v6, v8}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;

    .line 726
    iget-object v8, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    invoke-virtual {v8, v6}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    .line 727
    invoke-virtual {p0, v2}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->popActivityWithClassName(Ljava/lang/String;)V

    .line 718
    .end local v6    # "popIntent":Landroid/content/Intent;
    :goto_2
    add-int/lit8 v1, v1, -0x1

    goto :goto_1

    .line 729
    :cond_2
    invoke-virtual {v3}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$InnerActivityInfo;->getInnerActivityClassName()Ljava/lang/String;

    move-result-object v7

    .line 730
    .local v7, "tmpInnerName":Ljava/lang/String;
    if-eqz v7, :cond_3

    invoke-virtual {v7, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v8

    const/4 v9, 0x1

    if-ne v8, v9, :cond_3

    .line 731
    new-instance v4, Landroid/content/Intent;

    iget-object v8, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    const-class v9, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    invoke-direct {v4, v8, v9}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 732
    .local v4, "intent":Landroid/content/Intent;
    const/high16 v8, 0x24010000

    invoke-virtual {v4, v8}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;

    .line 735
    iget-object v8, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    invoke-virtual {v8, v4}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    goto :goto_0

    .line 738
    .end local v4    # "intent":Landroid/content/Intent;
    :cond_3
    iget-object v8, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    invoke-virtual {p0, v8}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->popActivity(Landroid/content/Context;)V

    goto :goto_2
.end method

.method parseWorkingDayInfo(Ljava/lang/String;)Ljava/util/ArrayList;
    .locals 8
    .param p1, "infoText"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")",
            "Ljava/util/ArrayList",
            "<",
            "Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$TempHoliDayInfo;",
            ">;"
        }
    .end annotation

    .prologue
    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v3, 0x4

    .line 4908
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 4909
    .local v0, "arrayListHolyDay":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$TempHoliDayInfo;>;"
    const-string v1, " "

    const-string v2, ""

    invoke-virtual {p1, v1, v2}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p1

    .line 4910
    const-string v1, "\ub9e4\uc8fc\uc77c\uc694\uc77c"

    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_0

    const-string v1, "\ud734\ubb34\uc77c:\uc77c\uc694\uc77c"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2

    .line 4912
    :cond_0
    new-instance v1, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$TempHoliDayInfo;

    invoke-direct {v1, v4, v4}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$TempHoliDayInfo;-><init>(II)V

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 4913
    new-instance v1, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$TempHoliDayInfo;

    invoke-direct {v1, v5, v4}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$TempHoliDayInfo;-><init>(II)V

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 4914
    new-instance v1, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$TempHoliDayInfo;

    const/4 v2, 0x3

    invoke-direct {v1, v2, v4}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$TempHoliDayInfo;-><init>(II)V

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 4915
    new-instance v1, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$TempHoliDayInfo;

    invoke-direct {v1, v3, v4}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$TempHoliDayInfo;-><init>(II)V

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 4916
    new-instance v1, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$TempHoliDayInfo;

    const/4 v2, 0x5

    invoke-direct {v1, v2, v4}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$TempHoliDayInfo;-><init>(II)V

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 5018
    :cond_1
    :goto_0
    return-object v0

    .line 4919
    :cond_2
    const-string v1, "\ub458\uc9f8,\ub137\uc9f8\uc8fc\uc77c\uc694\uc77c"

    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_3

    const-string v1, "2,4\ubc88\uc9f8\uc77c\uc694\uc77c"

    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_3

    const-string v1, "2,4\uc9f8\uc8fc\uc77c\uc694\uc77c"

    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_3

    const-string v1, "\ub458\uc9f8\uc8fc,\ub137\uc9f8\uc8fc\uc77c\uc694\uc77c"

    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_3

    const-string v1, "\ub458\uc9f8\uc8fc\ub137\uc9f8\uc8fc\uc77c\uc694\uc77c"

    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_3

    const-string v1, "\ub450\ubc88\uc9f8,\ub124\ubc88\uc9f8\uc77c\uc694\uc77c"

    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_3

    const-string v1, "\ub450\ubc88\uc9f8\ub124\ubc88\uc9f8\uc77c\uc694\uc77c"

    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_3

    const-string v1, "\ub458\uc9f8\uc8fc\ub137\uff1f\uc8fc\uc77c\uc694\uc77c"

    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_3

    const-string v1, "\ub9e4\uc6d42/4\uc8fc\uc77c\uc694\uc77c"

    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_4

    .line 4929
    :cond_3
    new-instance v1, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$TempHoliDayInfo;

    invoke-direct {v1, v5, v4}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$TempHoliDayInfo;-><init>(II)V

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 4930
    new-instance v1, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$TempHoliDayInfo;

    invoke-direct {v1, v3, v4}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$TempHoliDayInfo;-><init>(II)V

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_0

    .line 4933
    :cond_4
    const-string v1, "1,3\uc9f8\uc8fc\uc218\uc694\uc77c"

    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_5

    const-string v1, "\uccab\uc9f8\uc8fc,\uc14b\uc9f8\uc8fc\uc218\uc694\uc77c"

    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_6

    .line 4936
    :cond_5
    new-instance v1, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$TempHoliDayInfo;

    invoke-direct {v1, v4, v3}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$TempHoliDayInfo;-><init>(II)V

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 4937
    new-instance v1, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$TempHoliDayInfo;

    const/4 v2, 0x3

    invoke-direct {v1, v2, v3}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$TempHoliDayInfo;-><init>(II)V

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_0

    .line 4940
    :cond_6
    const-string v1, "2,4\ubc88\uc9f8\uc218\uc694\uc77c"

    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_7

    const-string v1, "\ub450\ubc88\uc9f8,\ub124\ubc88\uc9f8\uc218\uc694\uc77c"

    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_7

    const-string v1, "\ub458\uc9f8\uc8fc,\ub137\uc9f8\uc8fc\uc218\uc694\uc77c"

    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_7

    const-string v1, "\ub458\uc9f8,\ub137\uc9f8\uc8fc\uc218\uc694\uc77c"

    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_7

    const-string v1, "2,4\uc9f8\uc8fc\uc218\uc694\uc77c"

    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_7

    const-string v1, "\ub450\ubc88\uc9f8\ub124\ubc88\uc9f8\uc218\uc694\uc77c"

    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_7

    const-string v1, "\ub458\uc9f8\uc8fc\ub137\uc9f8\uc8fc\uc218\uc694\uc77c"

    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_8

    .line 4948
    :cond_7
    new-instance v1, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$TempHoliDayInfo;

    invoke-direct {v1, v5, v3}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$TempHoliDayInfo;-><init>(II)V

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 4949
    new-instance v1, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$TempHoliDayInfo;

    invoke-direct {v1, v3, v3}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$TempHoliDayInfo;-><init>(II)V

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto/16 :goto_0

    .line 4952
    :cond_8
    const-string v1, "2,4\ubc88\uc9f8\uc6d4\uc694\uc77c"

    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_9

    .line 4954
    new-instance v1, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$TempHoliDayInfo;

    invoke-direct {v1, v5, v5}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$TempHoliDayInfo;-><init>(II)V

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 4955
    new-instance v1, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$TempHoliDayInfo;

    invoke-direct {v1, v3, v5}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$TempHoliDayInfo;-><init>(II)V

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto/16 :goto_0

    .line 4958
    :cond_9
    const-string v1, "\ub458\uc9f8\uc8fc\uae08\uc694\uc77c,\ub137\uc9f8\uc8fc\ud1a0\uc694\uc77c"

    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_a

    const-string v1, "\ub458\uc9f8\uae08\uc694\uc77c,\ub137\uc9f8\ud1a0\uc694\uc77c"

    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_a

    const-string v1, "2\ubc88\uc9f8\uae08\uc694\uc77c,4\ubc88\uc9f8\ud1a0\uc694\uc77c"

    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_b

    .line 4962
    :cond_a
    new-instance v1, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$TempHoliDayInfo;

    invoke-direct {v1, v5, v7}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$TempHoliDayInfo;-><init>(II)V

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 4963
    new-instance v1, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$TempHoliDayInfo;

    const/4 v2, 0x7

    invoke-direct {v1, v3, v2}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$TempHoliDayInfo;-><init>(II)V

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto/16 :goto_0

    .line 4966
    :cond_b
    const-string v1, "\uccab\uc9f8\uc8fc\uc218\uc694\uc77c,\ub137\uc9f8\uc8fc\uc77c\uc694\uc77c"

    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_c

    .line 4967
    new-instance v1, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$TempHoliDayInfo;

    invoke-direct {v1, v4, v3}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$TempHoliDayInfo;-><init>(II)V

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 4968
    new-instance v1, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$TempHoliDayInfo;

    invoke-direct {v1, v3, v4}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$TempHoliDayInfo;-><init>(II)V

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto/16 :goto_0

    .line 4971
    :cond_c
    const-string v1, "\ub458\uc9f8\uc8fc\uc218\uc694\uc77c,\ub137\uc9f8\uc8fc\uc77c\uc694\uc77c"

    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_d

    .line 4972
    new-instance v1, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$TempHoliDayInfo;

    invoke-direct {v1, v5, v3}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$TempHoliDayInfo;-><init>(II)V

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 4973
    new-instance v1, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$TempHoliDayInfo;

    invoke-direct {v1, v3, v7}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$TempHoliDayInfo;-><init>(II)V

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto/16 :goto_0

    .line 4976
    :cond_d
    const-string v1, "\ub458\uc9f8\uc8fc,\ub137\uc9f8\uc8fc\uc6d4\uc694\uc77c"

    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_e

    .line 4977
    new-instance v1, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$TempHoliDayInfo;

    invoke-direct {v1, v5, v5}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$TempHoliDayInfo;-><init>(II)V

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 4978
    new-instance v1, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$TempHoliDayInfo;

    invoke-direct {v1, v3, v5}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$TempHoliDayInfo;-><init>(II)V

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto/16 :goto_0

    .line 4983
    :cond_e
    const-string v1, "10\uc77c,4\ubc88\uc9f8\uc77c\uc694\uc77c"

    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_f

    .line 4984
    new-instance v1, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$TempHoliDayInfo;

    const/16 v2, 0xa

    invoke-direct {v1, v6, v2}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$TempHoliDayInfo;-><init>(II)V

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 4985
    new-instance v1, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$TempHoliDayInfo;

    invoke-direct {v1, v3, v4}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$TempHoliDayInfo;-><init>(II)V

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto/16 :goto_0

    .line 4988
    :cond_f
    const-string v1, "\ub9e4\uc6d410\uc77c,\ub137\uc9f8\uc8fc\uc77c\uc694\uc77c"

    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_10

    .line 4989
    new-instance v1, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$TempHoliDayInfo;

    const/16 v2, 0xa

    invoke-direct {v1, v6, v2}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$TempHoliDayInfo;-><init>(II)V

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 4990
    new-instance v1, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$TempHoliDayInfo;

    invoke-direct {v1, v3, v4}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$TempHoliDayInfo;-><init>(II)V

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto/16 :goto_0

    .line 4993
    :cond_10
    const-string v1, "\uc6d48\uc77c,\ub137\uc9f8\uc8fc\uc77c\uc694\uc77c"

    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_11

    .line 4994
    new-instance v1, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$TempHoliDayInfo;

    const/16 v2, 0x8

    invoke-direct {v1, v6, v2}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$TempHoliDayInfo;-><init>(II)V

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 4995
    new-instance v1, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$TempHoliDayInfo;

    invoke-direct {v1, v3, v4}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$TempHoliDayInfo;-><init>(II)V

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto/16 :goto_0

    .line 4998
    :cond_11
    const-string v1, "10\uc77c,25\uc77c"

    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_12

    const-string v1, "10,25\uc77c"

    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_13

    .line 5000
    :cond_12
    new-instance v1, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$TempHoliDayInfo;

    const/16 v2, 0xa

    invoke-direct {v1, v6, v2}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$TempHoliDayInfo;-><init>(II)V

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 5001
    new-instance v1, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$TempHoliDayInfo;

    const/16 v2, 0x19

    invoke-direct {v1, v6, v2}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$TempHoliDayInfo;-><init>(II)V

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto/16 :goto_0

    .line 5004
    :cond_13
    const-string v1, "6\uc77c,21\uc77c"

    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_14

    .line 5005
    new-instance v1, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$TempHoliDayInfo;

    invoke-direct {v1, v6, v7}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$TempHoliDayInfo;-><init>(II)V

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 5006
    new-instance v1, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$TempHoliDayInfo;

    const/16 v2, 0x15

    invoke-direct {v1, v6, v2}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$TempHoliDayInfo;-><init>(II)V

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto/16 :goto_0

    .line 5009
    :cond_14
    const-string v1, "9\uc77c,24\uc77c"

    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_15

    .line 5010
    new-instance v1, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$TempHoliDayInfo;

    const/16 v2, 0x9

    invoke-direct {v1, v6, v2}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$TempHoliDayInfo;-><init>(II)V

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 5011
    new-instance v1, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$TempHoliDayInfo;

    const/16 v2, 0x18

    invoke-direct {v1, v6, v2}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$TempHoliDayInfo;-><init>(II)V

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto/16 :goto_0

    .line 5014
    :cond_15
    const-string v1, "\ub9e4\uc6d4\ub124\ubc88\uc9f8\uc77c\uc694\uc77c"

    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_1

    .line 5015
    new-instance v1, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$TempHoliDayInfo;

    invoke-direct {v1, v3, v4}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$TempHoliDayInfo;-><init>(II)V

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto/16 :goto_0
.end method

.method public pointDirectAdd(Landroid/content/Context;ILcom/thinkware/sundo/inavi3d/Struct/InaviPoint;)V
    .locals 15
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "mode"    # I
    .param p3, "point"    # Lcom/thinkware/sundo/inavi3d/Struct/InaviPoint;

    .prologue
    .line 5262
    new-instance v13, Landroid/content/Intent;

    const-class v1, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v0, p1

    invoke-direct {v13, v0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 5263
    .local v13, "msg":Landroid/content/Intent;
    const-string v1, "com.thinkware.sundo.inavi3d.directreg"

    invoke-virtual {v13, v1}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    .line 5264
    const-string v1, "point"

    move-object/from16 v0, p3

    invoke-virtual {v13, v1, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Landroid/os/Parcelable;)Landroid/content/Intent;

    .line 5265
    move-object/from16 v0, p3

    iget v1, v0, Lcom/thinkware/sundo/inavi3d/Struct/InaviPoint;->m_nPid:I

    if-lez v1, :cond_0

    .line 5266
    const-string v1, "pid"

    move-object/from16 v0, p3

    iget v2, v0, Lcom/thinkware/sundo/inavi3d/Struct/InaviPoint;->m_nPid:I

    invoke-virtual {v13, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 5268
    :cond_0
    packed-switch p2, :pswitch_data_0

    .line 5294
    :goto_0
    :pswitch_0
    const/4 v1, 0x4

    move/from16 v0, p2

    if-ne v0, v1, :cond_4

    .line 5295
    const-string v6, ""

    .line 5296
    .local v6, "pointName":Ljava/lang/String;
    move-object/from16 v0, p3

    iget-object v1, v0, Lcom/thinkware/sundo/inavi3d/Struct/InaviPoint;->m_strName:Ljava/lang/String;

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_3

    .line 5297
    move-object/from16 v0, p3

    iget-object v6, v0, Lcom/thinkware/sundo/inavi3d/Struct/InaviPoint;->m_strName:Ljava/lang/String;

    .line 5302
    :cond_1
    :goto_1
    const/16 v1, 0x274a

    invoke-static {v1}, Lcom/thinkware/sundo/inavi3d/Inavi;->setULogFreq(I)V

    .line 5304
    const v1, 0x22326

    const/4 v2, 0x0

    const/4 v3, 0x0

    move-object/from16 v0, p3

    iget v4, v0, Lcom/thinkware/sundo/inavi3d/Struct/InaviPoint;->m_nX:I

    move-object/from16 v0, p3

    iget v5, v0, Lcom/thinkware/sundo/inavi3d/Struct/InaviPoint;->m_nY:I

    invoke-static/range {v1 .. v6}, Lcom/thinkware/sundo/inavi3d/Inavi;->ProcessEventSlidingToolBarForPoint(IIIIILjava/lang/String;)Z

    move-result v14

    .line 5305
    .local v14, "ret":Z
    if-eqz v14, :cond_2

    .line 5306
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    move-result-object v1

    const-class v2, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;

    invoke-virtual {v2}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->moveToInnerActivity(Ljava/lang/String;)V

    .line 5340
    .end local v6    # "pointName":Ljava/lang/String;
    .end local v14    # "ret":Z
    :cond_2
    :goto_2
    return-void

    .line 5270
    :pswitch_1
    const-string v1, "type"

    const/4 v2, 0x1

    invoke-virtual {v13, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    goto :goto_0

    .line 5273
    :pswitch_2
    const-string v1, "type"

    const/4 v2, 0x2

    invoke-virtual {v13, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    goto :goto_0

    .line 5276
    :pswitch_3
    const-string v1, "type"

    const/4 v2, 0x3

    invoke-virtual {v13, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    goto :goto_0

    .line 5279
    :pswitch_4
    const-string v1, "type"

    const/4 v2, 0x4

    invoke-virtual {v13, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    goto :goto_0

    .line 5282
    :pswitch_5
    const-string v1, "type"

    const/16 v2, 0xb

    invoke-virtual {v13, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    goto :goto_0

    .line 5285
    :pswitch_6
    const-string v1, "type"

    const/16 v2, 0xc

    invoke-virtual {v13, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    goto :goto_0

    .line 5288
    :pswitch_7
    const-string v1, "type"

    const/16 v2, 0xd

    invoke-virtual {v13, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    goto :goto_0

    .line 5298
    .restart local v6    # "pointName":Ljava/lang/String;
    :cond_3
    move-object/from16 v0, p3

    iget-object v1, v0, Lcom/thinkware/sundo/inavi3d/Struct/InaviPoint;->m_strAdminName:Ljava/lang/String;

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_1

    .line 5299
    move-object/from16 v0, p3

    iget-object v6, v0, Lcom/thinkware/sundo/inavi3d/Struct/InaviPoint;->m_strAdminName:Ljava/lang/String;

    goto :goto_1

    .line 5308
    .end local v6    # "pointName":Ljava/lang/String;
    :cond_4
    const/4 v1, 0x3

    move/from16 v0, p2

    if-ne v0, v1, :cond_7

    .line 5309
    const-string v12, ""

    .line 5311
    .local v12, "strName":Ljava/lang/String;
    move-object/from16 v0, p3

    iget-object v1, v0, Lcom/thinkware/sundo/inavi3d/Struct/InaviPoint;->m_strName:Ljava/lang/String;

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_6

    .line 5312
    move-object/from16 v0, p3

    iget-object v12, v0, Lcom/thinkware/sundo/inavi3d/Struct/InaviPoint;->m_strName:Ljava/lang/String;

    .line 5317
    :cond_5
    :goto_3
    const/16 v1, 0x2749

    invoke-static {v1}, Lcom/thinkware/sundo/inavi3d/Inavi;->setULogFreq(I)V

    .line 5319
    const v7, 0x22327

    const/4 v8, 0x0

    const/4 v9, 0x0

    move-object/from16 v0, p3

    iget v10, v0, Lcom/thinkware/sundo/inavi3d/Struct/InaviPoint;->m_nX:I

    move-object/from16 v0, p3

    iget v11, v0, Lcom/thinkware/sundo/inavi3d/Struct/InaviPoint;->m_nY:I

    invoke-static/range {v7 .. v12}, Lcom/thinkware/sundo/inavi3d/Inavi;->ProcessEventSlidingToolBarForPoint(IIIIILjava/lang/String;)Z

    move-result v14

    .line 5320
    .restart local v14    # "ret":Z
    if-eqz v14, :cond_2

    .line 5321
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    move-result-object v1

    const-class v2, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;

    invoke-virtual {v2}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->moveToInnerActivity(Ljava/lang/String;)V

    goto :goto_2

    .line 5313
    .end local v14    # "ret":Z
    :cond_6
    move-object/from16 v0, p3

    iget-object v1, v0, Lcom/thinkware/sundo/inavi3d/Struct/InaviPoint;->m_strAdminName:Ljava/lang/String;

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_5

    .line 5314
    move-object/from16 v0, p3

    iget-object v12, v0, Lcom/thinkware/sundo/inavi3d/Struct/InaviPoint;->m_strAdminName:Ljava/lang/String;

    goto :goto_3

    .line 5323
    .end local v12    # "strName":Ljava/lang/String;
    :cond_7
    const/16 v1, 0xb

    move/from16 v0, p2

    if-ne v0, v1, :cond_a

    .line 5324
    const-string v12, ""

    .line 5325
    .restart local v12    # "strName":Ljava/lang/String;
    move-object/from16 v0, p3

    iget-object v1, v0, Lcom/thinkware/sundo/inavi3d/Struct/InaviPoint;->m_strName:Ljava/lang/String;

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_9

    .line 5326
    move-object/from16 v0, p3

    iget-object v12, v0, Lcom/thinkware/sundo/inavi3d/Struct/InaviPoint;->m_strName:Ljava/lang/String;

    .line 5331
    :cond_8
    :goto_4
    const/16 v1, 0x2749

    invoke-static {v1}, Lcom/thinkware/sundo/inavi3d/Inavi;->setULogFreq(I)V

    .line 5333
    const v7, 0x22327

    const/4 v8, 0x0

    const/4 v9, 0x0

    move-object/from16 v0, p3

    iget v10, v0, Lcom/thinkware/sundo/inavi3d/Struct/InaviPoint;->m_nX:I

    move-object/from16 v0, p3

    iget v11, v0, Lcom/thinkware/sundo/inavi3d/Struct/InaviPoint;->m_nY:I

    invoke-static/range {v7 .. v12}, Lcom/thinkware/sundo/inavi3d/Inavi;->ProcessEventSlidingToolBarForPoint(IIIIILjava/lang/String;)Z

    move-result v14

    .line 5334
    .restart local v14    # "ret":Z
    if-eqz v14, :cond_2

    .line 5335
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    move-result-object v1

    const-class v2, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;

    invoke-virtual {v2}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->moveToInnerActivity(Ljava/lang/String;)V

    goto/16 :goto_2

    .line 5327
    .end local v14    # "ret":Z
    :cond_9
    move-object/from16 v0, p3

    iget-object v1, v0, Lcom/thinkware/sundo/inavi3d/Struct/InaviPoint;->m_strAdminName:Ljava/lang/String;

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_8

    .line 5328
    move-object/from16 v0, p3

    iget-object v12, v0, Lcom/thinkware/sundo/inavi3d/Struct/InaviPoint;->m_strAdminName:Ljava/lang/String;

    goto :goto_4

    .line 5338
    .end local v12    # "strName":Ljava/lang/String;
    :cond_a
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    move-result-object v1

    move-object/from16 v0, p1

    invoke-virtual {v1, v0, v13}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->startActivityToMap(Landroid/content/Context;Landroid/content/Intent;)V

    goto/16 :goto_2

    .line 5268
    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_1
        :pswitch_2
        :pswitch_3
        :pswitch_4
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_5
        :pswitch_6
        :pswitch_7
    .end packed-switch
.end method

.method public popActivity(Landroid/content/Context;)V
    .locals 7
    .param p1, "packageContext"    # Landroid/content/Context;

    .prologue
    .line 816
    move-object v5, p1

    check-cast v5, Landroid/app/Activity;

    invoke-virtual {v5}, Landroid/app/Activity;->getParent()Landroid/app/Activity;

    move-result-object v5

    instance-of v5, v5, Landroid/app/TabActivity;

    if-nez v5, :cond_0

    move-object v5, p1

    check-cast v5, Landroid/app/Activity;

    invoke-virtual {v5}, Landroid/app/Activity;->getParent()Landroid/app/Activity;

    move-result-object v5

    instance-of v5, v5, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    if-eqz v5, :cond_1

    .line 841
    :cond_0
    :goto_0
    return-void

    .line 821
    :cond_1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v0

    .line 822
    .local v0, "className":Ljava/lang/String;
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getActivityCount()I

    move-result v2

    .line 824
    .local v2, "listCount":I
    if-lez v2, :cond_0

    .line 825
    add-int/lit8 v3, v2, -0x1

    .local v3, "listIndex":I
    :goto_1
    if-ltz v3, :cond_0

    .line 826
    invoke-virtual {p0, v3}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getActivityName(I)Ljava/lang/String;

    move-result-object v4

    .line 827
    .local v4, "tempClassName":Ljava/lang/String;
    invoke-virtual {v4, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    const/4 v6, 0x1

    if-ne v5, v6, :cond_3

    .line 829
    iget-object v5, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mActivityInfoArray:Ljava/util/ArrayList;

    invoke-virtual {v5, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$InnerActivityInfo;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$InnerActivityInfo;->getInnerActivityClassName()Ljava/lang/String;

    move-result-object v1

    .line 831
    .local v1, "innerActivityClassName":Ljava/lang/String;
    if-eqz v1, :cond_2

    .line 832
    iput-object v1, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mDestroyInnerActivityClassName:Ljava/lang/String;

    .line 836
    :cond_2
    iget-object v5, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mActivityInfoArray:Ljava/util/ArrayList;

    invoke-virtual {v5, v3}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    goto :goto_0

    .line 825
    .end local v1    # "innerActivityClassName":Ljava/lang/String;
    :cond_3
    add-int/lit8 v3, v3, -0x1

    goto :goto_1
.end method

.method public popActivityWithClassName(Ljava/lang/String;)V
    .locals 5
    .param p1, "className"    # Ljava/lang/String;

    .prologue
    const/4 v4, 0x1

    .line 844
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getMainClassName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-ne v3, v4, :cond_1

    .line 858
    :cond_0
    :goto_0
    return-void

    .line 847
    :cond_1
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getActivityCount()I

    move-result v0

    .line 849
    .local v0, "listCount":I
    if-lez v0, :cond_0

    .line 850
    add-int/lit8 v1, v0, -0x1

    .local v1, "listIndex":I
    :goto_1
    if-ltz v1, :cond_0

    .line 851
    invoke-virtual {p0, v1}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getActivityName(I)Ljava/lang/String;

    move-result-object v2

    .line 852
    .local v2, "tempClassName":Ljava/lang/String;
    invoke-virtual {v2, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-ne v3, v4, :cond_2

    .line 853
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mActivityInfoArray:Ljava/util/ArrayList;

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    goto :goto_0

    .line 850
    :cond_2
    add-int/lit8 v1, v1, -0x1

    goto :goto_1
.end method

.method public popAllActivity()V
    .locals 6

    .prologue
    const/16 v5, 0x3e8

    const/4 v4, 0x1

    .line 930
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getActivityCount()I

    move-result v1

    .line 932
    .local v1, "listCount":I
    if-lez v1, :cond_1

    .line 933
    iput-boolean v4, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mMoveRootView:Z

    .line 934
    add-int/lit8 v2, v1, -0x1

    .local v2, "listIndex":I
    :goto_0
    if-ltz v2, :cond_1

    .line 935
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mActivityInfoArray:Ljava/util/ArrayList;

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$InnerActivityInfo;

    invoke-virtual {v3}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$InnerActivityInfo;->getInnerActivityClassName()Ljava/lang/String;

    move-result-object v0

    .line 936
    .local v0, "innerActivityClassName":Ljava/lang/String;
    if-eqz v0, :cond_0

    .line 937
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    check-cast v3, Landroid/app/ActivityGroup;

    invoke-virtual {v3}, Landroid/app/ActivityGroup;->getLocalActivityManager()Landroid/app/LocalActivityManager;

    move-result-object v3

    invoke-virtual {v3, v0, v4}, Landroid/app/LocalActivityManager;->destroyActivity(Ljava/lang/String;Z)Landroid/view/Window;

    .line 934
    :cond_0
    add-int/lit8 v2, v2, -0x1

    goto :goto_0

    .line 941
    .end local v0    # "innerActivityClassName":Ljava/lang/String;
    .end local v2    # "listIndex":I
    :cond_1
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mActivityInfoArray:Ljava/util/ArrayList;

    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mActivityInfoArray:Ljava/util/ArrayList;

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->removeAll(Ljava/util/Collection;)Z

    .line 942
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->removeInnerActivity()V

    .line 943
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    move-result-object v3

    invoke-virtual {v3}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getExtStatus()I

    move-result v3

    if-eq v3, v5, :cond_2

    .line 944
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    move-result-object v3

    invoke-virtual {v3, v5}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->setExtStatus(I)V

    .line 946
    :cond_2
    return-void
.end method

.method printState(Ljava/lang/String;)V
    .locals 7
    .param p1, "text"    # Ljava/lang/String;

    .prologue
    .line 5022
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mGPSInfo:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    if-eqz v1, :cond_0

    .line 5023
    const-string v1, "bona"

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "========================="

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "========================="

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 5024
    new-instance v0, Ljava/util/GregorianCalendar;

    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mGPSInfo:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    iget-short v1, v1, Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;->Date_yy:S

    add-int/lit16 v1, v1, 0x7d0

    sget-object v2, Lcom/thinkware/sundo/inavi3d/Inavi;->mGPSInfo:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    iget-short v2, v2, Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;->Date_mm:S

    add-int/lit8 v2, v2, -0x1

    sget-object v3, Lcom/thinkware/sundo/inavi3d/Inavi;->mGPSInfo:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    iget-short v3, v3, Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;->Date_dd:S

    sget-object v4, Lcom/thinkware/sundo/inavi3d/Inavi;->mGPSInfo:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    iget-short v4, v4, Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;->UTC_hh:S

    add-int/lit8 v4, v4, 0x9

    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->mGPSInfo:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    iget-short v5, v5, Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;->UTC_mm:S

    invoke-direct/range {v0 .. v5}, Ljava/util/GregorianCalendar;-><init>(IIIII)V

    .line 5029
    .local v0, "now":Ljava/util/GregorianCalendar;
    new-instance v6, Ljava/text/SimpleDateFormat;

    const-string v1, "yyyy-MM-dd(E) hh:mm"

    invoke-direct {v6, v1}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;)V

    .line 5030
    .local v6, "fmt":Ljava/text/SimpleDateFormat;
    const-string v1, "bona"

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "setWorkingDayInfo date - "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v0}, Ljava/util/GregorianCalendar;->getTime()Ljava/util/Date;

    move-result-object v3

    invoke-virtual {v6, v3}, Ljava/text/SimpleDateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " // gpsStatus : "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    sget-object v3, Lcom/thinkware/sundo/inavi3d/Inavi;->mGPSInfo:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    iget-char v3, v3, Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;->Status:C

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 5032
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mPOIHasWorkingDayInfo:Lcom/thinkware/sundo/inavi3d/ui/component/CustumDefine$GUISearchPointData;

    if-eqz v1, :cond_1

    .line 5033
    const-string v1, "bona"

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "setWorkingDayInfo m_strPoiName - "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mPOIHasWorkingDayInfo:Lcom/thinkware/sundo/inavi3d/ui/component/CustumDefine$GUISearchPointData;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/ui/component/CustumDefine$GUISearchPointData;->m_strPoiName:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 5034
    const-string v1, "bona"

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "setWorkingDayInfo m_strWorkingDayInfo - "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mPOIHasWorkingDayInfo:Lcom/thinkware/sundo/inavi3d/ui/component/CustumDefine$GUISearchPointData;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/ui/component/CustumDefine$GUISearchPointData;->m_strWorkingDayInfo:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 5039
    :goto_0
    const-string v1, "bona"

    const-string v2, "=================================================="

    invoke-static {v1, v2}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 5041
    .end local v0    # "now":Ljava/util/GregorianCalendar;
    .end local v6    # "fmt":Ljava/text/SimpleDateFormat;
    :cond_0
    return-void

    .line 5036
    .restart local v0    # "now":Ljava/util/GregorianCalendar;
    .restart local v6    # "fmt":Ljava/text/SimpleDateFormat;
    :cond_1
    const-string v1, "bona"

    const-string v2, "setWorkingDayInfo - null"

    invoke-static {v1, v2}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_0
.end method

.method public pushActivity(Landroid/content/Context;)V
    .locals 6
    .param p1, "packageContext"    # Landroid/content/Context;

    .prologue
    .line 765
    move-object v4, p1

    check-cast v4, Landroid/app/Activity;

    invoke-virtual {v4}, Landroid/app/Activity;->getParent()Landroid/app/Activity;

    move-result-object v4

    instance-of v4, v4, Landroid/app/TabActivity;

    if-nez v4, :cond_0

    move-object v4, p1

    check-cast v4, Landroid/app/Activity;

    invoke-virtual {v4}, Landroid/app/Activity;->getParent()Landroid/app/Activity;

    move-result-object v4

    instance-of v4, v4, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    if-eqz v4, :cond_1

    .line 789
    :cond_0
    :goto_0
    return-void

    .line 772
    :cond_1
    const/4 v4, 0x1

    invoke-virtual {p0, v4}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->setMoveActivity(Z)V

    .line 774
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v0

    .line 775
    .local v0, "className":Ljava/lang/String;
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getActivityCount()I

    move-result v3

    .line 777
    .local v3, "listCount":I
    if-lez v3, :cond_2

    .line 778
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mActivityInfoArray:Ljava/util/ArrayList;

    add-int/lit8 v5, v3, -0x1

    invoke-virtual {v4, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$InnerActivityInfo;

    invoke-virtual {v4}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$InnerActivityInfo;->getInnerActivityClassName()Ljava/lang/String;

    move-result-object v1

    .line 780
    .local v1, "innerActivityClassName":Ljava/lang/String;
    if-eqz v1, :cond_2

    .line 781
    iput-object v1, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mDestroyInnerActivityClassName:Ljava/lang/String;

    .line 785
    .end local v1    # "innerActivityClassName":Ljava/lang/String;
    :cond_2
    new-instance v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$InnerActivityInfo;

    invoke-direct {v2, p0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$InnerActivityInfo;-><init>(Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;)V

    .line 786
    .local v2, "innerActivityInfo":Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$InnerActivityInfo;
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$InnerActivityInfo;->setActivityClassName(Ljava/lang/String;)V

    .line 788
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mActivityInfoArray:Ljava/util/ArrayList;

    invoke-virtual {v4, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_0
.end method

.method public pushActivityWithINavi3dActivity(Landroid/content/Context;Ljava/lang/String;ILcom/thinkware/sundo/inavi3d/Struct/InaviPoint;)V
    .locals 2
    .param p1, "packageContext"    # Landroid/content/Context;
    .param p2, "action"    # Ljava/lang/String;
    .param p3, "positionMoveType"    # I
    .param p4, "positionMovePoint"    # Lcom/thinkware/sundo/inavi3d/Struct/InaviPoint;

    .prologue
    .line 805
    new-instance v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$InnerActivityInfo;

    invoke-direct {v0, p0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$InnerActivityInfo;-><init>(Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;)V

    .line 806
    .local v0, "innerActivityInfo":Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$InnerActivityInfo;
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1, p2, p3, p4}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$InnerActivityInfo;->setINavi3DActivityInfo(Ljava/lang/String;Ljava/lang/String;ILcom/thinkware/sundo/inavi3d/Struct/InaviPoint;)V

    .line 808
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mActivityInfoArray:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 809
    return-void
.end method

.method public removeInnerActivity()V
    .locals 3

    .prologue
    .line 861
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mDestroyInnerActivityClassName:Ljava/lang/String;

    if-eqz v0, :cond_0

    .line 862
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    check-cast v0, Landroid/app/ActivityGroup;

    invoke-virtual {v0}, Landroid/app/ActivityGroup;->getLocalActivityManager()Landroid/app/LocalActivityManager;

    move-result-object v0

    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mDestroyInnerActivityClassName:Ljava/lang/String;

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/app/LocalActivityManager;->destroyActivity(Ljava/lang/String;Z)Landroid/view/Window;

    .line 863
    const/4 v0, 0x0

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mDestroyInnerActivityClassName:Ljava/lang/String;

    .line 865
    :cond_0
    return-void
.end method

.method public runAdasService()Z
    .locals 5

    .prologue
    const/4 v2, 0x1

    .line 5227
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    if-eqz v3, :cond_0

    .line 5229
    new-instance v1, Landroid/content/Intent;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    const-class v4, Lcom/thinkware/sundo/inavi3dservice/AdasService;

    invoke-direct {v1, v3, v4}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 5230
    .local v1, "intent":Landroid/content/Intent;
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mAdasConnection:Landroid/content/ServiceConnection;

    invoke-virtual {v3, v1, v4, v2}, Landroid/content/Context;->bindService(Landroid/content/Intent;Landroid/content/ServiceConnection;I)Z

    move-result v0

    .line 5232
    .local v0, "bRetVal":Z
    if-ne v0, v2, :cond_0

    .line 5236
    .end local v0    # "bRetVal":Z
    .end local v1    # "intent":Landroid/content/Intent;
    :goto_0
    return v2

    :cond_0
    const/4 v2, 0x0

    goto :goto_0
.end method

.method public sendVoiceCommand(Landroid/content/Intent;)V
    .locals 11
    .param p1, "intent"    # Landroid/content/Intent;

    .prologue
    .line 3673
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v8

    const-string v9, "activity"

    invoke-virtual {v8, v9}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/app/ActivityManager;

    .line 3674
    .local v0, "activityManager":Landroid/app/ActivityManager;
    const/4 v8, 0x1

    invoke-virtual {v0, v8}, Landroid/app/ActivityManager;->getRunningTasks(I)Ljava/util/List;

    move-result-object v6

    .line 3675
    .local v6, "task":Ljava/util/List;, "Ljava/util/List<Landroid/app/ActivityManager$RunningTaskInfo;>;"
    const/4 v8, 0x0

    invoke-interface {v6, v8}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Landroid/app/ActivityManager$RunningTaskInfo;

    iget-object v7, v8, Landroid/app/ActivityManager$RunningTaskInfo;->topActivity:Landroid/content/ComponentName;

    .line 3677
    .local v7, "topActivity":Landroid/content/ComponentName;
    new-instance v4, Ljava/lang/String;

    invoke-direct {v4}, Ljava/lang/String;-><init>()V

    .line 3678
    .local v4, "strEnableCommand":Ljava/lang/String;
    new-instance v3, Ljava/lang/String;

    invoke-direct {v3}, Ljava/lang/String;-><init>()V

    .line 3679
    .local v3, "strDisableCommand":Ljava/lang/String;
    new-instance v5, Ljava/lang/String;

    invoke-direct {v5}, Ljava/lang/String;-><init>()V

    .line 3684
    .local v5, "strHiddenCommand":Ljava/lang/String;
    :try_start_0
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v8

    invoke-virtual {v8}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->isRouteResultScene()Z

    move-result v8

    if-eqz v8, :cond_4

    .line 3685
    const-string v4, "\uc548\ub0b4\uc2dc\uc791:\uc9d1\uc73c\ub85c:\uc790\uc8fc\uac00\ub294\uacf3:\uacbd\ub85c\ucde8\uc18c"
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 3703
    :cond_0
    :goto_0
    invoke-virtual {v7}, Landroid/content/ComponentName;->getShortClassName()Ljava/lang/String;

    move-result-object v8

    const-string v9, ".INavi3DActivity"

    invoke-virtual {v8, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_1

    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->isCurrentFlag()Z

    move-result v8

    if-eqz v8, :cond_1

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v8

    invoke-virtual {v8}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->isShownNIP()Z

    move-result v8

    if-nez v8, :cond_1

    .line 3704
    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v8, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    const-string v9, "\uc9c0\ub3c4"

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    .line 3709
    :cond_1
    new-instance v2, Landroid/content/Intent;

    invoke-direct {v2}, Landroid/content/Intent;-><init>()V

    .line 3711
    .local v2, "intentVoice":Landroid/content/Intent;
    const-string v8, "PackageName"

    invoke-virtual {p1, v8}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v2, v8}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    .line 3712
    const-string v8, "COMMAND_LIST"

    invoke-virtual {v2, v8, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 3714
    invoke-virtual {v3}, Ljava/lang/String;->length()I

    move-result v8

    if-lez v8, :cond_2

    .line 3715
    const-string v8, "DISABLE_COMMANDS"

    invoke-virtual {v2, v8, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 3717
    :cond_2
    invoke-virtual {v5}, Ljava/lang/String;->length()I

    move-result v8

    if-lez v8, :cond_3

    .line 3718
    const-string v8, "HIDDEN_COMMANDS"

    invoke-virtual {v2, v8, v5}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 3721
    :cond_3
    const-string v8, "PackageName"

    const-string v9, "com.thinkware.inavi3ds"

    invoke-virtual {v2, v8, v9}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 3722
    const-string v8, "ActivityName"

    const-string v9, "com.thinkware.sundo.inavi3d.INavi3DActivity"

    invoke-virtual {v2, v8, v9}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 3724
    const-string v8, "spinell"

    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    const-string v10, "Send voice commands: "

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-static {v8, v9}, Lcom/thinkware/sundo/inavi3d/LOGTW;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 3725
    iget-object v8, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    invoke-virtual {v8, v2}, Landroid/content/Context;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;

    .line 3726
    return-void

    .line 3689
    .end local v2    # "intentVoice":Landroid/content/Intent;
    :cond_4
    :try_start_1
    const-string v4, "\uc9d1\uc73c\ub85c:\uc790\uc8fc\uac00\ub294\uacf3"

    .line 3690
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->IsValidRoute()Z

    move-result v8

    if-eqz v8, :cond_0

    .line 3691
    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v8, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    const-string v9, ":\uacbd\ub85c\ucde8\uc18c"

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    move-result-object v4

    goto/16 :goto_0

    .line 3694
    :catch_0
    move-exception v1

    .line 3695
    .local v1, "e":Ljava/lang/Exception;
    invoke-virtual {v1}, Ljava/lang/Exception;->printStackTrace()V

    goto/16 :goto_0
.end method

.method public sendVoiceCommandForTAURUS(Landroid/content/Intent;)V
    .locals 12
    .param p1, "intent"    # Landroid/content/Intent;

    .prologue
    const/4 v11, 0x0

    const/4 v10, 0x1

    .line 4411
    sget-object v8, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->inavi_reference:Lcom/thinkware/sundo/inavi3d/Inavi;

    invoke-virtual {v8}, Lcom/thinkware/sundo/inavi3d/Inavi;->isInitDone()Z

    move-result v8

    if-ne v8, v10, :cond_9

    .line 4412
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v8

    const-string v9, "activity"

    invoke-virtual {v8, v9}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/app/ActivityManager;

    .line 4413
    .local v0, "activityManager":Landroid/app/ActivityManager;
    invoke-virtual {v0, v10}, Landroid/app/ActivityManager;->getRunningTasks(I)Ljava/util/List;

    move-result-object v6

    .line 4414
    .local v6, "task":Ljava/util/List;, "Ljava/util/List<Landroid/app/ActivityManager$RunningTaskInfo;>;"
    invoke-interface {v6, v11}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Landroid/app/ActivityManager$RunningTaskInfo;

    iget-object v7, v8, Landroid/app/ActivityManager$RunningTaskInfo;->topActivity:Landroid/content/ComponentName;

    .line 4416
    .local v7, "topActivity":Landroid/content/ComponentName;
    new-instance v4, Ljava/lang/String;

    invoke-direct {v4}, Ljava/lang/String;-><init>()V

    .line 4417
    .local v4, "strEnableCommand":Ljava/lang/String;
    new-instance v3, Ljava/lang/String;

    invoke-direct {v3}, Ljava/lang/String;-><init>()V

    .line 4418
    .local v3, "strDisableCommand":Ljava/lang/String;
    new-instance v5, Ljava/lang/String;

    invoke-direct {v5}, Ljava/lang/String;-><init>()V

    .line 4423
    .local v5, "strHiddenCommand":Ljava/lang/String;
    :try_start_0
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v8

    invoke-virtual {v8}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->isRouteResultScene()Z

    move-result v8

    if-nez v8, :cond_0

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v8

    invoke-virtual {v8}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->isDetourResultScene()Z

    move-result v8

    if-eqz v8, :cond_b

    .line 4424
    :cond_0
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v8

    invoke-virtual {v8}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getAINASearching()Z

    move-result v8

    if-eqz v8, :cond_a

    .line 4425
    const-string v4, "\uc548\ub0b4\uc2dc\uc791"

    .line 4442
    :goto_0
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->isCurrentOnAndRootActivity()Z

    move-result v8

    if-eq v8, v10, :cond_1

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v8

    invoke-virtual {v8}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->isGpsModeScene()Z

    move-result v8

    if-ne v8, v10, :cond_2

    .line 4443
    :cond_1
    const-string v5, "\ud604\uc704\uce58"

    .line 4446
    :cond_2
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v8

    invoke-virtual {v8}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->isGpsModeScene()Z

    move-result v8

    if-nez v8, :cond_4

    .line 4447
    invoke-virtual {v5}, Ljava/lang/String;->length()I

    move-result v8

    if-lez v8, :cond_3

    .line 4448
    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v8, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    const-string v9, ":"

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    .line 4449
    :cond_3
    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v8, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    const-string v9, "\ub0b4\ube44\uac8c\uc774\uc158"

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    move-result-object v5

    .line 4463
    :cond_4
    :goto_1
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v8

    invoke-virtual {v8}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->isAINASearching()Z

    move-result v8

    if-eqz v8, :cond_5

    .line 4464
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v8

    invoke-virtual {v8, v11}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->onGetAINACommandList(I)Ljava/lang/String;

    move-result-object v4

    .line 4465
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v8

    invoke-virtual {v8, v10}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->onGetAINACommandList(I)Ljava/lang/String;

    move-result-object v3

    .line 4472
    :cond_5
    new-instance v2, Landroid/content/Intent;

    invoke-direct {v2}, Landroid/content/Intent;-><init>()V

    .line 4474
    .local v2, "intentVoice":Landroid/content/Intent;
    const-string v8, "PackageName"

    invoke-virtual {p1, v8}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v2, v8}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    .line 4475
    invoke-virtual {v4}, Ljava/lang/String;->length()I

    move-result v8

    if-lez v8, :cond_6

    .line 4476
    const-string v8, "COMMAND_LIST"

    invoke-virtual {v2, v8, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 4479
    :cond_6
    invoke-virtual {v3}, Ljava/lang/String;->length()I

    move-result v8

    if-lez v8, :cond_7

    .line 4480
    const-string v8, "DISABLE_COMMANDS"

    invoke-virtual {v2, v8, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 4482
    :cond_7
    invoke-virtual {v5}, Ljava/lang/String;->length()I

    move-result v8

    if-lez v8, :cond_8

    .line 4483
    const-string v8, "HIDDEN_COMMANDS"

    invoke-virtual {v2, v8, v5}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 4486
    :cond_8
    const-string v8, "PackageName"

    const-string v9, "com.thinkware.inavi3ds"

    invoke-virtual {v2, v8, v9}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 4487
    const-string v8, "ActivityName"

    const-string v9, "com.thinkware.sundo.inavi3d.INavi3DActivity"

    invoke-virtual {v2, v8, v9}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 4489
    const-string v8, "spinell"

    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    const-string v10, "Send voice commands: "

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-static {v8, v9}, Lcom/thinkware/sundo/inavi3d/LOGTW;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 4490
    iget-object v8, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    invoke-virtual {v8, v2}, Landroid/content/Context;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;

    .line 4492
    .end local v0    # "activityManager":Landroid/app/ActivityManager;
    .end local v2    # "intentVoice":Landroid/content/Intent;
    .end local v3    # "strDisableCommand":Ljava/lang/String;
    .end local v4    # "strEnableCommand":Ljava/lang/String;
    .end local v5    # "strHiddenCommand":Ljava/lang/String;
    .end local v6    # "task":Ljava/util/List;, "Ljava/util/List<Landroid/app/ActivityManager$RunningTaskInfo;>;"
    .end local v7    # "topActivity":Landroid/content/ComponentName;
    :cond_9
    return-void

    .line 4427
    .restart local v0    # "activityManager":Landroid/app/ActivityManager;
    .restart local v3    # "strDisableCommand":Ljava/lang/String;
    .restart local v4    # "strEnableCommand":Ljava/lang/String;
    .restart local v5    # "strHiddenCommand":Ljava/lang/String;
    .restart local v6    # "task":Ljava/util/List;, "Ljava/util/List<Landroid/app/ActivityManager$RunningTaskInfo;>;"
    .restart local v7    # "topActivity":Landroid/content/ComponentName;
    :cond_a
    :try_start_1
    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v8, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    const-string v9, "\uc548\ub0b4\uc2dc\uc791:\ud604\uc704\uce58:\uacbd\ub85c\ucde8\uc18c:\uc9d1\uc73c\ub85c:\uc790\uc8fc\uac00\ub294\uacf3"

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    goto/16 :goto_0

    .line 4432
    :cond_b
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->isCurrentOnAndRootActivity()Z

    move-result v8

    if-nez v8, :cond_c

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v8

    invoke-virtual {v8}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->isGpsModeScene()Z

    move-result v8

    if-nez v8, :cond_c

    .line 4433
    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v8, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    const-string v9, "\ud604\uc704\uce58:"

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    .line 4435
    :cond_c
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->IsValidRoute()Z

    move-result v8

    if-eqz v8, :cond_d

    .line 4436
    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v8, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    const-string v9, "\uacbd\ub85c\ucde8\uc18c:"

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    .line 4438
    :cond_d
    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v8, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    const-string v9, "\uc9d1\uc73c\ub85c:\uc790\uc8fc\uac00\ub294\uacf3"

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    move-result-object v4

    goto/16 :goto_0

    .line 4451
    :catch_0
    move-exception v1

    .line 4452
    .local v1, "e":Ljava/lang/Exception;
    invoke-virtual {v1}, Ljava/lang/Exception;->printStackTrace()V

    goto/16 :goto_1
.end method

.method public setARCameraOn(Z)V
    .locals 0
    .param p1, "ARCameraOn"    # Z

    .prologue
    .line 4561
    iput-boolean p1, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mARCameraOn:Z

    .line 4562
    return-void
.end method

.method public setAutoArModeStatus(I)V
    .locals 3
    .param p1, "arModeStatus"    # I

    .prologue
    .line 4669
    iput p1, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->autoArModeStatus:I

    .line 4670
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->getInstance()Lcom/thinkware/sundo/inavi3d/InaviConfig;

    move-result-object v0

    const/16 v1, 0x139

    iget v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->autoArModeStatus:I

    invoke-virtual {v0, v1, v2}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->CNaviConfigSet(II)Z

    .line 4671
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->getInstance()Lcom/thinkware/sundo/inavi3d/InaviConfig;

    move-result-object v0

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->SetConfigSave()Z

    .line 4672
    return-void
.end method

.method public setAutoRunInaviBySetting(Z)V
    .locals 0
    .param p1, "bValue"    # Z

    .prologue
    .line 3858
    iput-boolean p1, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mbAutoRunInaviByStting:Z

    .line 3859
    return-void
.end method

.method public setBackActivity(Z)V
    .locals 0
    .param p1, "backEvent"    # Z

    .prologue
    .line 1127
    iput-boolean p1, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mBackActivity:Z

    .line 1128
    return-void
.end method

.method public setClosedWarning(Z)V
    .locals 0
    .param p1, "value"    # Z

    .prologue
    .line 2114
    iput-boolean p1, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mBWarningClosed:Z

    .line 2115
    return-void
.end method

.method public setCurrentFlag(Z)V
    .locals 0
    .param p1, "isCurrent"    # Z

    .prologue
    .line 877
    iput-boolean p1, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mCurrentOn:Z

    .line 878
    return-void
.end method

.method public setDoingCurrentOn(Z)V
    .locals 0
    .param p1, "ing"    # Z

    .prologue
    .line 888
    iput-boolean p1, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mIsDoingCurrentOn:Z

    .line 889
    return-void
.end method

.method public setEexcuteRenderInNameSrchActvity(Z)V
    .locals 0
    .param p1, "mbEexcuteRenderInNameSrchActvity"    # Z

    .prologue
    .line 2504
    iput-boolean p1, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mbEexcuteRenderInNameSrchActvity:Z

    .line 2505
    return-void
.end method

.method public setEnabledTrafficMap(Z)V
    .locals 0
    .param p1, "flag"    # Z

    .prologue
    .line 2545
    iput-boolean p1, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mbEnabledTrafficMap:Z

    .line 2546
    return-void
.end method

.method public setEntireRouteMapLevel(I)V
    .locals 0
    .param p1, "mapLevel"    # I

    .prologue
    .line 2561
    iput p1, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mEntireRouteMapLevel:I

    .line 2562
    return-void
.end method

.method public setEntireRouteViewModeValue(I)V
    .locals 0
    .param p1, "viewMode"    # I

    .prologue
    .line 2521
    iput p1, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mEntireRouteViewMode:I

    .line 2522
    return-void
.end method

.method public setExtForeGroundCallStatus(Z)V
    .locals 3
    .param p1, "callStatus"    # Z

    .prologue
    .line 2637
    const-string v0, "inavi3d_wooks"

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, " setExtForeGroundCallStatus() :: mbExtForeGroundCallStatus :: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-boolean v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mbExtForeGroundCallStatus:Z

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 2638
    const-string v0, "inavi3d_wooks"

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, " setExtForeGroundCallStatus() :: callStatus :: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 2639
    iput-boolean p1, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mbExtForeGroundCallStatus:Z

    .line 2640
    const-string v0, "inavi3d_wooks"

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, " setExtForeGroundCallStatus() :: mbExtForeGroundCallStatus :: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-boolean v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mbExtForeGroundCallStatus:Z

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 2641
    return-void
.end method

.method public setExtIntent(Landroid/content/Intent;)V
    .locals 3
    .param p1, "nipIntent"    # Landroid/content/Intent;

    .prologue
    const/4 v2, 0x1

    .line 2590
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mExtStart:Z

    if-ne v0, v2, :cond_1

    .line 2618
    :cond_0
    :goto_0
    return-void

    .line 2594
    :cond_1
    if-eqz p1, :cond_0

    invoke-virtual {p1}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-virtual {p1}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    move-result-object v0

    const-string v1, "EXTTYPE"

    invoke-virtual {v0, v1}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_0

    .line 2595
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getRootActivityStatus()I

    move-result v0

    if-eq v0, v2, :cond_2

    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getRootActivityStatus()I

    move-result v0

    const/4 v1, 0x2

    if-ne v0, v1, :cond_3

    .line 2596
    :cond_2
    const/4 v0, 0x3

    invoke-virtual {p0, v0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->setRootActivityStatus(I)V

    .line 2599
    :cond_3
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v0

    if-eqz v0, :cond_5

    .line 2601
    invoke-virtual {p1}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    move-result-object v0

    const-string v1, "EXTTYPE"

    invoke-virtual {v0, v1}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "ExtCurrentOn"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_4

    .line 2602
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v0

    const/4 v1, -0x1

    iput v1, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_nCurrentNIPType:I

    .line 2605
    :cond_4
    invoke-virtual {p1}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    move-result-object v0

    const-string v1, "EXTTYPE"

    invoke-virtual {v0, v1}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "ExtCurrentOnHome"

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_5

    invoke-virtual {p1}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    move-result-object v0

    const-string v1, "EXTTYPE"

    invoke-virtual {v0, v1}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "ExtCurrentOn"

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_5

    invoke-virtual {p1}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    move-result-object v0

    const-string v1, "EXTTYPE"

    invoke-virtual {v0, v1}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "InitAuto"

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_6

    .line 2614
    :cond_5
    :goto_1
    iput-object p1, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mExtIntent:Landroid/content/Intent;

    .line 2615
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mExtIntent:Landroid/content/Intent;

    const-string v1, "android.intent.action.MAIN"

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    .line 2616
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mExtIntent:Landroid/content/Intent;

    const-string v1, "android.intent.category.LAUNCHER"

    invoke-virtual {v0, v1}, Landroid/content/Intent;->addCategory(Ljava/lang/String;)Landroid/content/Intent;

    goto/16 :goto_0

    .line 2608
    :cond_6
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v0

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->setTutorialShow(Z)V

    .line 2609
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v0

    invoke-virtual {v0, v2}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->setTutorialUserClose(Z)V

    goto :goto_1
.end method

.method public setExtStatus(I)V
    .locals 3
    .param p1, "extStatus"    # I

    .prologue
    .line 2625
    const-string v0, "inavi3d_wooks"

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, " setExtStatus() :: mExtStatus :: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mExtStatus:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 2626
    const-string v0, "inavi3d_wooks"

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, " setExtStatus() :: extStatus :: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 2627
    iput p1, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mExtStatus:I

    .line 2628
    const-string v0, "inavi3d_wooks"

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, " setExtStatus() :: mExtStatus :: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mExtStatus:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 2629
    return-void
.end method

.method public setFirstCurrentFlag(Z)V
    .locals 1
    .param p1, "isCurrent"    # Z

    .prologue
    .line 882
    const/4 v0, 0x1

    if-ne p1, v0, :cond_0

    .line 883
    iput-boolean p1, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mFirstCurrentOn:Z

    .line 884
    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->setDoingCurrentOn(Z)V

    .line 886
    :cond_0
    return-void
.end method

.method public setHeapLogFlag(Z)V
    .locals 0
    .param p1, "bFlag"    # Z

    .prologue
    .line 1427
    iput-boolean p1, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mHeapLogShow:Z

    .line 1428
    return-void
.end method

.method public setInitFlag(Z)V
    .locals 0
    .param p1, "initFlag"    # Z

    .prologue
    .line 913
    iput-boolean p1, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mInitFlag:Z

    .line 914
    return-void
.end method

.method public setInnerActivityClassName(Ljava/lang/String;)V
    .locals 4
    .param p1, "className"    # Ljava/lang/String;

    .prologue
    .line 491
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getActivityCount()I

    move-result v0

    .line 492
    .local v0, "activityInfoCount":I
    if-lez v0, :cond_0

    .line 493
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mActivityInfoArray:Ljava/util/ArrayList;

    add-int/lit8 v3, v0, -0x1

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$InnerActivityInfo;

    .line 494
    .local v1, "innerActivityInfo":Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$InnerActivityInfo;
    invoke-virtual {v1, p1}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$InnerActivityInfo;->setInnerActivityClassName(Ljava/lang/String;)V

    .line 496
    .end local v1    # "innerActivityInfo":Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$InnerActivityInfo;
    :cond_0
    return-void
.end method

.method public setInnerActivityView(Landroid/view/View;)V
    .locals 4
    .param p1, "view"    # Landroid/view/View;

    .prologue
    .line 477
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getActivityCount()I

    move-result v0

    .line 478
    .local v0, "activityInfoCount":I
    if-lez v0, :cond_0

    .line 479
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mActivityInfoArray:Ljava/util/ArrayList;

    add-int/lit8 v3, v0, -0x1

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$InnerActivityInfo;

    .line 480
    .local v1, "innerActivityInfo":Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$InnerActivityInfo;
    invoke-virtual {v1, p1}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$InnerActivityInfo;->setInnerActivityView(Landroid/view/View;)V

    .line 482
    .end local v1    # "innerActivityInfo":Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$InnerActivityInfo;
    :cond_0
    return-void
.end method

.method public setIsDoOk(Z)V
    .locals 0
    .param p1, "isDoOk"    # Z

    .prologue
    .line 4808
    iput-boolean p1, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mIsDoOk:Z

    .line 4809
    return-void
.end method

.method public setLowMemory(Z)V
    .locals 0
    .param p1, "lowMemory"    # Z

    .prologue
    .line 3883
    iput-boolean p1, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mLowMemory:Z

    .line 3884
    return-void
.end method

.method public setMISENShowFlag(Z)V
    .locals 0
    .param p1, "bFlag"    # Z

    .prologue
    .line 1343
    iput-boolean p1, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mMISENDataShow:Z

    .line 1344
    return-void
.end method

.method public setMoveActivity(Z)V
    .locals 3
    .param p1, "moveActivity"    # Z

    .prologue
    .line 3872
    const-string v0, "inavi3d_wooks_moveActivity"

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, " setMoveActivity :: moveActivity :: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-boolean v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mIsMoveActivity:Z

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 3873
    iput-boolean p1, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mIsMoveActivity:Z

    .line 3875
    return-void
.end method

.method public setMoveRootActivity(Z)V
    .locals 0
    .param p1, "moveRootActivity"    # Z

    .prologue
    .line 3863
    iput-boolean p1, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mIsMoveRootActivity:Z

    .line 3864
    return-void
.end method

.method public setMoveRootView(Z)V
    .locals 0
    .param p1, "moveRootView"    # Z

    .prologue
    .line 2570
    iput-boolean p1, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mMoveRootView:Z

    .line 2571
    return-void
.end method

.method public setNameSearchMapLevel(I)V
    .locals 0
    .param p1, "mapLevel"    # I

    .prologue
    .line 2553
    iput p1, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mNameSearchMapLevel:I

    .line 2554
    return-void
.end method

.method public setNameSearchViewModeValue(I)V
    .locals 0
    .param p1, "viewMode"    # I

    .prologue
    .line 2513
    iput p1, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mNameSearchViewMode:I

    .line 2514
    return-void
.end method

.method public setOBD2Connection(Z)V
    .locals 0
    .param p1, "bFlag"    # Z

    .prologue
    .line 1440
    iput-boolean p1, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mOBD2Connect:Z

    .line 1441
    return-void
.end method

.method public setOBD2LogFlag(Z)V
    .locals 0
    .param p1, "bFlag"    # Z

    .prologue
    .line 1436
    iput-boolean p1, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mOBD2LogShow:Z

    .line 1437
    return-void
.end method

.method public setReadyDPMap(Z)V
    .locals 0
    .param p1, "mbReadyDPMap"    # Z

    .prologue
    .line 2496
    iput-boolean p1, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mbReadyForDPMap:Z

    .line 2497
    return-void
.end method

.method public setRootActivityStatus(I)V
    .locals 1
    .param p1, "rootActivityStatus"    # I

    .prologue
    .line 325
    if-ltz p1, :cond_0

    const/4 v0, 0x4

    if-ge p1, v0, :cond_0

    .line 327
    iput p1, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootActivityStatus:I

    .line 329
    :cond_0
    return-void
.end method

.method public setRootContext(Landroid/content/Context;)V
    .locals 2
    .param p1, "rootContext"    # Landroid/content/Context;

    .prologue
    .line 312
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    iput-wide v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mStartTime:J

    .line 313
    iput-object p1, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    .line 314
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootActivityClassName:Ljava/lang/String;

    .line 315
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    const-string v1, "activity"

    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/app/ActivityManager;

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mActivityManager:Landroid/app/ActivityManager;

    .line 316
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootContext:Landroid/content/Context;

    check-cast v0, Landroid/app/Activity;

    invoke-virtual {v0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/View;->getRootView()Landroid/view/View;

    move-result-object v0

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootLayout:Landroid/view/View;

    .line 318
    return-void
.end method

.method public setRoutePointManageViewModeValue(I)V
    .locals 0
    .param p1, "viewMode"    # I

    .prologue
    .line 2529
    iput p1, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRoutePointManageViewMode:I

    .line 2530
    return-void
.end method

.method public setShowScreenMirroring(Z)V
    .locals 0
    .param p1, "showScreenMirroring"    # Z

    .prologue
    .line 4552
    iput-boolean p1, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mIsShowScreenMirroring:Z

    .line 4553
    return-void
.end method

.method public setSuperCapPowerOff(Z)V
    .locals 2
    .param p1, "bSuperCapPowerOff"    # Z

    .prologue
    .line 4794
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v0

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->isSupportSuperCapPowerOff()Z

    move-result v0

    const/4 v1, 0x1

    if-ne v0, v1, :cond_0

    .line 4795
    iput-boolean p1, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->m_bSuperCapPowerOff:Z

    .line 4796
    invoke-static {p1}, Lcom/thinkware/sundo/inavi3d/Inavi;->setSuperCapPowerOff(Z)V

    .line 4798
    :cond_0
    return-void
.end method

.method public setValidateTimeLock(Z)V
    .locals 0
    .param p1, "bValidateTimeLock"    # Z

    .prologue
    .line 2488
    iput-boolean p1, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mbValidateTimeLock:Z

    .line 2489
    return-void
.end method

.method public setViewModeValue(I)V
    .locals 0
    .param p1, "viewMode"    # I

    .prologue
    .line 2537
    iput p1, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mViewMode:I

    .line 2538
    return-void
.end method

.method public setWorkingDayInfo(Lcom/thinkware/sundo/inavi3d/ui/component/CustumDefine$GUISearchPointData;Z)V
    .locals 2
    .param p1, "poiInfo"    # Lcom/thinkware/sundo/inavi3d/ui/component/CustumDefine$GUISearchPointData;
    .param p2, "bIsRouteSearching"    # Z

    .prologue
    .line 5050
    if-nez p2, :cond_1

    sget-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->mGPSInfo:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    if-eqz v0, :cond_0

    sget-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->mGPSInfo:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    iget-char v0, v0, Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;->Status:C

    const/16 v1, 0x41

    if-eq v0, v1, :cond_1

    .line 5051
    :cond_0
    const-string v0, "setWorkingDayInfo"

    invoke-virtual {p0, v0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->printState(Ljava/lang/String;)V

    .line 5058
    :goto_0
    return-void

    .line 5054
    :cond_1
    if-nez p1, :cond_2

    const/4 v0, 0x0

    :goto_1
    iput v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mLastShowingPid:I

    .line 5055
    iput-object p1, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mPOIHasWorkingDayInfo:Lcom/thinkware/sundo/inavi3d/ui/component/CustumDefine$GUISearchPointData;

    .line 5056
    const-string v0, "setWorkingDayInfo"

    invoke-virtual {p0, v0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->printState(Ljava/lang/String;)V

    goto :goto_0

    .line 5054
    :cond_2
    iget v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mLastShowingPid:I

    goto :goto_1
.end method

.method public setWorkingDayInfoLive(Lcom/thinkware/sundo/inavi3d/livesearch/RSearchPOIResult;)V
    .locals 1
    .param p1, "poiInfo"    # Lcom/thinkware/sundo/inavi3d/livesearch/RSearchPOIResult;

    .prologue
    .line 5149
    if-nez p1, :cond_0

    const/4 v0, 0x0

    :goto_0
    iput v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mLastShowingPidLive:I

    .line 5150
    iput-object p1, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mPOIHasWorkingDayInfoLive:Lcom/thinkware/sundo/inavi3d/livesearch/RSearchPOIResult;

    .line 5151
    return-void

    .line 5149
    :cond_0
    iget v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mLastShowingPidLive:I

    goto :goto_0
.end method

.method public showAdas(IZ)V
    .locals 1
    .param p1, "status"    # I
    .param p2, "isShow"    # Z

    .prologue
    .line 5246
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mAdasService:Lcom/thinkware/sundo/inavi3dservice/AdasService;

    if-eqz v0, :cond_0

    .line 5247
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mAdasService:Lcom/thinkware/sundo/inavi3dservice/AdasService;

    invoke-virtual {v0, p1, p2}, Lcom/thinkware/sundo/inavi3dservice/AdasService;->setAdasEnable(IZ)V

    .line 5249
    :cond_0
    return-void
.end method

.method public showStatusBar()Z
    .locals 1

    .prologue
    .line 2479
    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->showStatusBar(Z)Z

    move-result v0

    return v0
.end method

.method public showStatusBar(Z)Z
    .locals 7
    .param p1, "isCheck"    # Z

    .prologue
    const/4 v5, 0x2

    const/4 v2, 0x1

    const/4 v1, 0x0

    .line 2308
    goto/16 :goto_1

    :cond_0
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v3

    invoke-virtual {v3}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetDeviceModelType()I

    move-result v3

    const/4 v4, 0x3

    if-eq v3, v4, :cond_0

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v3

    invoke-virtual {v3}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetDeviceModelType()I

    move-result v3

    const/4 v4, 0x4

    if-eq v3, v4, :cond_0

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v3

    invoke-virtual {v3}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetDeviceModelType()I

    move-result v3

    const/4 v4, 0x5

    if-eq v3, v4, :cond_0

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v3

    invoke-virtual {v3}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetDeviceModelType()I

    move-result v3

    const/4 v4, 0x6

    if-eq v3, v4, :cond_0

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v3

    invoke-virtual {v3}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetDeviceModelType()I

    move-result v3

    const/4 v4, 0x7

    if-eq v3, v4, :cond_0

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v3

    invoke-virtual {v3}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetDeviceModelType()I

    move-result v3

    const/16 v4, 0x8

    if-eq v3, v4, :cond_0

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v3

    invoke-virtual {v3}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetDeviceModelType()I

    move-result v3

    const/16 v4, 0x9

    if-eq v3, v4, :cond_0

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v3

    invoke-virtual {v3}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->IsDAVINCIOrder()Z

    move-result v3

    if-ne v3, v2, :cond_1

    .line 2317
    invoke-virtual {p0, p1}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->showStatusBarTaurus(Z)Z

    move-result v1

    .line 2373
    :goto_0
    return v1

    .line 2319
    :cond_1
    :goto_1
    const-string v3, "inavi3d_StatusBar"

    const-string v4, "\t\tCall showStatusBar() - mBarShown(%b) mAllwaysBarShown(%b)"

    new-array v5, v5, [Ljava/lang/Object;

    iget-boolean v6, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mBarShown:Z

    invoke-static {v6}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v6

    aput-object v6, v5, v1

    iget-boolean v6, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mAllwaysBarShown:Z

    invoke-static {v6}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v6

    aput-object v6, v5, v2

    invoke-static {v4, v5}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v3, v4}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 2320
    iget-boolean v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mBarShown:Z

    if-nez v3, :cond_2

    iget-boolean v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mAllwaysBarShown:Z

    if-eqz v3, :cond_3

    :cond_2
    if-nez p1, :cond_5

    .line 2321
    :cond_3
    iget-boolean v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mMoveRootView:Z

    if-ne v3, v2, :cond_4

    .line 2322
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mMoveRootView:Z

    .line 2323
    const-string v2, "inavi3d_StatusBar"

    const-string v3, "\t\tCall showStatusBar() - Fail 1"

    new-array v4, v1, [Ljava/lang/Object;

    invoke-static {v3, v4}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_0

    .line 2326
    :cond_4
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootLayout:Landroid/view/View;

    .line 2327
    .local v0, "rootLayout":Landroid/view/View;
    new-instance v1, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$8;

    invoke-direct {v1, p0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$8;-><init>(Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;)V

    invoke-virtual {v0, v1}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    move v1, v2

    .line 2368
    goto :goto_0

    .line 2370
    .end local v0    # "rootLayout":Landroid/view/View;
    :cond_5
    const-string v2, "inavi3d_StatusBar"

    const-string v3, "\t\tCall showStatusBar() - Fail3"

    new-array v4, v1, [Ljava/lang/Object;

    invoke-static {v3, v4}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_0
.end method

.method public showStatusBarForce(Landroid/content/Context;)V
    .locals 3
    .param p1, "context"    # Landroid/content/Context;

    .prologue
    const/4 v2, 0x1

    .line 2464
    if-nez p1, :cond_0

    .line 2476
    :goto_0
    return-void

    .line 2468
    :cond_0
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v1

    invoke-virtual {v1}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->IsDAVINCIOrder()Z

    move-result v1

    if-ne v1, v2, :cond_1

    .line 2469
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->showStatusBar()Z

    goto :goto_0

    .line 2471
    :cond_1
    new-instance v0, Landroid/content/Intent;

    const-string v1, "tw.intent.action.DIXON.STATUS_BAR.SHOW"

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 2472
    .local v0, "i":Landroid/content/Intent;
    const/high16 v1, 0x10000

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;

    .line 2473
    invoke-virtual {p1, v0}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V

    .line 2474
    invoke-virtual {p0, v2}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->SetBarShown(Z)V

    goto :goto_0
.end method

.method public showStatusBarTaurus(Z)Z
    .locals 9
    .param p1, "isCheck"    # Z

    .prologue
    const/4 v4, 0x1

    const/4 v3, 0x0

    .line 2377
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v5

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->IsDAVINCIOrder()Z

    move-result v5

    if-ne v5, v4, :cond_1

    .line 2378
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->isHideBar()Z

    move-result v5

    if-ne v5, v4, :cond_1

    .line 2460
    :cond_0
    :goto_0
    return v3

    .line 2382
    :cond_1
    const-string v5, "inavi3d_StatusBar"

    const-string v6, "\t\tCall showStatusBarTaurus() - mBarShown(%b) mAllwaysBarShown(%b)"

    const/4 v7, 0x2

    new-array v7, v7, [Ljava/lang/Object;

    iget-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mBarShown:Z

    invoke-static {v8}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v8

    aput-object v8, v7, v3

    iget-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mAllwaysBarShown:Z

    invoke-static {v8}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v8

    aput-object v8, v7, v4

    invoke-static {v6, v7}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v5, v6}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 2383
    iget-boolean v5, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mBarShown:Z

    if-nez v5, :cond_2

    iget-boolean v5, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mAllwaysBarShown:Z

    if-eqz v5, :cond_3

    :cond_2
    if-nez p1, :cond_7

    .line 2384
    :cond_3
    iget-boolean v5, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mMoveRootView:Z

    if-ne v5, v4, :cond_4

    .line 2385
    iput-boolean v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mMoveRootView:Z

    .line 2386
    const-string v4, "inavi3d_StatusBar"

    const-string v5, "\t\tCall showStatusBarTaurus() - Fail 1"

    new-array v6, v3, [Ljava/lang/Object;

    invoke-static {v5, v6}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v5

    invoke-static {v4, v5}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_0

    .line 2389
    :cond_4
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mRootLayout:Landroid/view/View;

    .line 2390
    .local v2, "rootLayout":Landroid/view/View;
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    move-result-object v5

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getExtIntent()Landroid/content/Intent;

    move-result-object v0

    .line 2392
    .local v0, "extIntent":Landroid/content/Intent;
    if-eqz v0, :cond_5

    .line 2393
    invoke-virtual {v0}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    move-result-object v5

    const-string v6, "EXTTYPE"

    invoke-virtual {v5, v6}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 2395
    .local v1, "extString":Ljava/lang/String;
    if-eqz v1, :cond_5

    .line 2397
    const-string v5, "VoiceCommander"

    invoke-virtual {v1, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eq v5, v4, :cond_0

    .line 2401
    iget-boolean v5, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mCurrentOn:Z

    if-eqz v5, :cond_5

    .line 2403
    const-string v4, "inavi3d_StatusBar"

    const-string v5, "\t\tCall showStatusBarTaurus() - Fail"

    new-array v6, v3, [Ljava/lang/Object;

    invoke-static {v5, v6}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v5

    invoke-static {v4, v5}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_0

    .line 2409
    .end local v1    # "extString":Ljava/lang/String;
    :cond_5
    iget-boolean v5, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mMoveRootView:Z

    if-ne v5, v4, :cond_6

    .line 2410
    iput-boolean v3, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mMoveRootView:Z

    .line 2411
    const-string v4, "inavi3d_StatusBar"

    const-string v5, "\t\tCall showStatusBarTaurus() - Fail"

    new-array v6, v3, [Ljava/lang/Object;

    invoke-static {v5, v6}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v5

    invoke-static {v4, v5}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    goto/16 :goto_0

    .line 2415
    :cond_6
    new-instance v5, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$9;

    invoke-direct {v5, p0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$9;-><init>(Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;)V

    invoke-virtual {v2, v5}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    .line 2454
    invoke-virtual {p0, v4}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->SetBarShown(Z)V

    .line 2456
    const-string v5, "inavi3d_StatusBar"

    const-string v6, "\t\tCall showStatusBarTaurus() - Success"

    new-array v3, v3, [Ljava/lang/Object;

    invoke-static {v6, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-static {v5, v3}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    move v3, v4

    .line 2457
    goto/16 :goto_0

    .line 2459
    .end local v0    # "extIntent":Landroid/content/Intent;
    .end local v2    # "rootLayout":Landroid/view/View;
    :cond_7
    const-string v4, "inavi3d_StatusBar"

    const-string v5, "\t\tCall showStatusBarTaurus() - Fail3"

    new-array v6, v3, [Ljava/lang/Object;

    invoke-static {v5, v6}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v5

    invoke-static {v4, v5}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    goto/16 :goto_0
.end method

.method public startActivityToMap(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 1
    .param p1, "packageContext"    # Landroid/content/Context;
    .param p2, "mapIntent"    # Landroid/content/Intent;

    .prologue
    .line 350
    const/4 v0, 0x0

    invoke-virtual {p0, p1, p2, v0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->startActivityToMap(Landroid/content/Context;Landroid/content/Intent;Landroid/content/Intent;)V

    .line 351
    return-void
.end method

.method public startActivityToMap(Landroid/content/Context;Landroid/content/Intent;Landroid/content/Intent;)V
    .locals 2
    .param p1, "packageContext"    # Landroid/content/Context;
    .param p2, "mapIntent"    # Landroid/content/Intent;
    .param p3, "innerIntent"    # Landroid/content/Intent;

    .prologue
    .line 373
    const-string v0, "InnerIntent"

    invoke-virtual {p2, v0, p3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Landroid/os/Parcelable;)Landroid/content/Intent;

    .line 374
    const-string v0, "pushActivity"

    const/4 v1, 0x1

    invoke-virtual {p2, v0, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    .line 375
    const/high16 v0, 0x30000

    invoke-virtual {p2, v0}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;

    .line 376
    invoke-virtual {p1, p2}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    .line 377
    return-void
.end method

.method public stopTask()V
    .locals 2

    .prologue
    const/4 v1, 0x0

    .line 4023
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mTimerTask:Ljava/util/TimerTask;

    if-eqz v0, :cond_0

    .line 4024
    iput v1, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mCounter:I

    .line 4025
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->bRunning:Z

    .line 4026
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mTimerTask:Ljava/util/TimerTask;

    invoke-virtual {v0}, Ljava/util/TimerTask;->cancel()Z

    .line 4027
    const/4 v0, 0x0

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->mTimerTask:Ljava/util/TimerTask;

    .line 4029
    :cond_0
    return-void
.end method

.method public tabButtonClearTop(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 1
    .param p1, "packageContext"    # Landroid/content/Context;
    .param p2, "intent"    # Landroid/content/Intent;

    .prologue
    .line 752
    move-object v0, p1

    check-cast v0, Landroid/app/Activity;

    invoke-virtual {v0}, Landroid/app/Activity;->finish()V

    .line 753
    if-eqz p2, :cond_0

    .line 754
    invoke-virtual {p1, p2}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    .line 758
    :goto_0
    return-void

    .line 756
    :cond_0
    invoke-virtual {p0, p1}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->popActivity(Landroid/content/Context;)V

    goto :goto_0
.end method
