.class Lcom/thinkware/sundo/ieve/IEVE$2;
.super Ljava/util/TimerTask;
.source "IEVE.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/thinkware/sundo/ieve/IEVE;->initialize(Ljava/lang/String;Landroid/graphics/Rect;Lcom/thinkware/sundo/ieve/ieveNScreenManager;IIIILjava/lang/String;)Z
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/thinkware/sundo/ieve/IEVE;


# direct methods
.method constructor <init>(Lcom/thinkware/sundo/ieve/IEVE;)V
    .locals 0

    .prologue
    .line 1
    iput-object p1, p0, Lcom/thinkware/sundo/ieve/IEVE$2;->a:Lcom/thinkware/sundo/ieve/IEVE;

    .line 1564
    invoke-direct {p0}, Ljava/util/TimerTask;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 8

    .prologue
    const/16 v7, 0x457

    .line 1567
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE$2;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v0}, Lcom/thinkware/sundo/ieve/IEVE;->f(Lcom/thinkware/sundo/ieve/IEVE;)Lcom/thinkware/sundo/ieve/ieveNative;

    move-result-object v0

    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE$2;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v1}, Lcom/thinkware/sundo/ieve/IEVE;->m(Lcom/thinkware/sundo/ieve/IEVE;)F

    move-result v1

    iget-object v2, p0, Lcom/thinkware/sundo/ieve/IEVE$2;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v2}, Lcom/thinkware/sundo/ieve/IEVE;->n(Lcom/thinkware/sundo/ieve/IEVE;)F

    move-result v2

    iget-object v3, p0, Lcom/thinkware/sundo/ieve/IEVE$2;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v3}, Lcom/thinkware/sundo/ieve/IEVE;->o(Lcom/thinkware/sundo/ieve/IEVE;)F

    move-result v3

    iget-object v4, p0, Lcom/thinkware/sundo/ieve/IEVE$2;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v4}, Lcom/thinkware/sundo/ieve/IEVE;->p(Lcom/thinkware/sundo/ieve/IEVE;)F

    move-result v4

    iget-object v5, p0, Lcom/thinkware/sundo/ieve/IEVE$2;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v5}, Lcom/thinkware/sundo/ieve/IEVE;->q(Lcom/thinkware/sundo/ieve/IEVE;)F

    move-result v5

    iget-object v6, p0, Lcom/thinkware/sundo/ieve/IEVE$2;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v6}, Lcom/thinkware/sundo/ieve/IEVE;->r(Lcom/thinkware/sundo/ieve/IEVE;)Z

    move-result v6

    invoke-virtual/range {v0 .. v6}, Lcom/thinkware/sundo/ieve/ieveNative;->SetCarControl(FFFFFZ)V

    .line 1568
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE$2;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v0}, Lcom/thinkware/sundo/ieve/IEVE;->f(Lcom/thinkware/sundo/ieve/IEVE;)Lcom/thinkware/sundo/ieve/ieveNative;

    move-result-object v0

    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE$2;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v1}, Lcom/thinkware/sundo/ieve/IEVE;->l(Lcom/thinkware/sundo/ieve/IEVE;)I

    move-result v1

    iget-object v2, p0, Lcom/thinkware/sundo/ieve/IEVE$2;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v2}, Lcom/thinkware/sundo/ieve/IEVE;->g(Lcom/thinkware/sundo/ieve/IEVE;)I

    move-result v2

    invoke-virtual {v0, v1, v2}, Lcom/thinkware/sundo/ieve/ieveNative;->SetCarSpeedK(II)V

    .line 1571
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE$2;->a:Lcom/thinkware/sundo/ieve/IEVE;

    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE$2;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v1}, Lcom/thinkware/sundo/ieve/IEVE;->f(Lcom/thinkware/sundo/ieve/IEVE;)Lcom/thinkware/sundo/ieve/ieveNative;

    move-result-object v1

    invoke-virtual {v1}, Lcom/thinkware/sundo/ieve/ieveNative;->GetRecogResultCSWS()I

    move-result v1

    invoke-static {v0, v1}, Lcom/thinkware/sundo/ieve/IEVE;->d(Lcom/thinkware/sundo/ieve/IEVE;I)V

    .line 1572
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE$2;->a:Lcom/thinkware/sundo/ieve/IEVE;

    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE$2;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v1}, Lcom/thinkware/sundo/ieve/IEVE;->f(Lcom/thinkware/sundo/ieve/IEVE;)Lcom/thinkware/sundo/ieve/ieveNative;

    move-result-object v1

    invoke-virtual {v1}, Lcom/thinkware/sundo/ieve/ieveNative;->GetRecogResultLDWS()I

    move-result v1

    invoke-static {v0, v1}, Lcom/thinkware/sundo/ieve/IEVE;->e(Lcom/thinkware/sundo/ieve/IEVE;I)V

    .line 1574
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE$2;->a:Lcom/thinkware/sundo/ieve/IEVE;

    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE$2;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v1}, Lcom/thinkware/sundo/ieve/IEVE;->h(Lcom/thinkware/sundo/ieve/IEVE;)Lcom/stradvision/pdvdtest/SV_ADAS;

    move-result-object v1

    invoke-virtual {v1}, Lcom/stradvision/pdvdtest/SV_ADAS;->GetRecogResultFCWS()I

    move-result v1

    invoke-static {v0, v1}, Lcom/thinkware/sundo/ieve/IEVE;->f(Lcom/thinkware/sundo/ieve/IEVE;I)V

    .line 1575
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE$2;->a:Lcom/thinkware/sundo/ieve/IEVE;

    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE$2;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v1}, Lcom/thinkware/sundo/ieve/IEVE;->h(Lcom/thinkware/sundo/ieve/IEVE;)Lcom/stradvision/pdvdtest/SV_ADAS;

    move-result-object v1

    invoke-virtual {v1}, Lcom/stradvision/pdvdtest/SV_ADAS;->GetRecogResultPCWS()I

    move-result v1

    invoke-static {v0, v1}, Lcom/thinkware/sundo/ieve/IEVE;->g(Lcom/thinkware/sundo/ieve/IEVE;I)V

    .line 1578
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE$2;->a:Lcom/thinkware/sundo/ieve/IEVE;

    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE$2;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v1}, Lcom/thinkware/sundo/ieve/IEVE;->f(Lcom/thinkware/sundo/ieve/IEVE;)Lcom/thinkware/sundo/ieve/ieveNative;

    move-result-object v1

    invoke-virtual {v1}, Lcom/thinkware/sundo/ieve/ieveNative;->GetRecogResultFVSA()I

    move-result v1

    invoke-static {v0, v1}, Lcom/thinkware/sundo/ieve/IEVE;->h(Lcom/thinkware/sundo/ieve/IEVE;I)V

    .line 1579
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE$2;->a:Lcom/thinkware/sundo/ieve/IEVE;

    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE$2;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v1}, Lcom/thinkware/sundo/ieve/IEVE;->f(Lcom/thinkware/sundo/ieve/IEVE;)Lcom/thinkware/sundo/ieve/ieveNative;

    move-result-object v1

    invoke-virtual {v1}, Lcom/thinkware/sundo/ieve/ieveNative;->GetRecogResultTLCA()I

    move-result v1

    invoke-static {v0, v1}, Lcom/thinkware/sundo/ieve/IEVE;->i(Lcom/thinkware/sundo/ieve/IEVE;I)V

    .line 1580
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE$2;->a:Lcom/thinkware/sundo/ieve/IEVE;

    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE$2;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v1}, Lcom/thinkware/sundo/ieve/IEVE;->f(Lcom/thinkware/sundo/ieve/IEVE;)Lcom/thinkware/sundo/ieve/ieveNative;

    move-result-object v1

    invoke-virtual {v1}, Lcom/thinkware/sundo/ieve/ieveNative;->GetRecogResultPLCA()I

    move-result v1

    invoke-static {v0, v1}, Lcom/thinkware/sundo/ieve/IEVE;->j(Lcom/thinkware/sundo/ieve/IEVE;I)V

    .line 1581
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE$2;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v0}, Lcom/thinkware/sundo/ieve/IEVE;->c(Lcom/thinkware/sundo/ieve/IEVE;)Landroid/os/Handler;

    move-result-object v0

    if-eqz v0, :cond_6

    .line 1582
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE$2;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v0}, Lcom/thinkware/sundo/ieve/IEVE;->s(Lcom/thinkware/sundo/ieve/IEVE;)I

    move-result v0

    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE$2;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v1}, Lcom/thinkware/sundo/ieve/IEVE;->t(Lcom/thinkware/sundo/ieve/IEVE;)I

    move-result v1

    if-eq v0, v1, :cond_0

    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE$2;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v0}, Lcom/thinkware/sundo/ieve/IEVE;->c(Lcom/thinkware/sundo/ieve/IEVE;)Landroid/os/Handler;

    move-result-object v0

    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE$2;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v1}, Lcom/thinkware/sundo/ieve/IEVE;->c(Lcom/thinkware/sundo/ieve/IEVE;)Landroid/os/Handler;

    move-result-object v1

    const v2, 0x8000

    iget-object v3, p0, Lcom/thinkware/sundo/ieve/IEVE$2;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v3}, Lcom/thinkware/sundo/ieve/IEVE;->s(Lcom/thinkware/sundo/ieve/IEVE;)I

    move-result v3

    invoke-static {v1, v7, v2, v3}, Landroid/os/Message;->obtain(Landroid/os/Handler;III)Landroid/os/Message;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    .line 1583
    :cond_0
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE$2;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v0}, Lcom/thinkware/sundo/ieve/IEVE;->u(Lcom/thinkware/sundo/ieve/IEVE;)I

    move-result v0

    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE$2;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v1}, Lcom/thinkware/sundo/ieve/IEVE;->v(Lcom/thinkware/sundo/ieve/IEVE;)I

    move-result v1

    if-eq v0, v1, :cond_1

    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE$2;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v0}, Lcom/thinkware/sundo/ieve/IEVE;->c(Lcom/thinkware/sundo/ieve/IEVE;)Landroid/os/Handler;

    move-result-object v0

    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE$2;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v1}, Lcom/thinkware/sundo/ieve/IEVE;->c(Lcom/thinkware/sundo/ieve/IEVE;)Landroid/os/Handler;

    move-result-object v1

    const/16 v2, 0x100

    iget-object v3, p0, Lcom/thinkware/sundo/ieve/IEVE$2;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v3}, Lcom/thinkware/sundo/ieve/IEVE;->u(Lcom/thinkware/sundo/ieve/IEVE;)I

    move-result v3

    invoke-static {v1, v7, v2, v3}, Landroid/os/Message;->obtain(Landroid/os/Handler;III)Landroid/os/Message;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    .line 1584
    :cond_1
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE$2;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v0}, Lcom/thinkware/sundo/ieve/IEVE;->w(Lcom/thinkware/sundo/ieve/IEVE;)I

    move-result v0

    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE$2;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v1}, Lcom/thinkware/sundo/ieve/IEVE;->x(Lcom/thinkware/sundo/ieve/IEVE;)I

    move-result v1

    if-eq v0, v1, :cond_2

    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE$2;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v0}, Lcom/thinkware/sundo/ieve/IEVE;->c(Lcom/thinkware/sundo/ieve/IEVE;)Landroid/os/Handler;

    move-result-object v0

    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE$2;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v1}, Lcom/thinkware/sundo/ieve/IEVE;->c(Lcom/thinkware/sundo/ieve/IEVE;)Landroid/os/Handler;

    move-result-object v1

    const/16 v2, 0x200

    iget-object v3, p0, Lcom/thinkware/sundo/ieve/IEVE$2;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v3}, Lcom/thinkware/sundo/ieve/IEVE;->w(Lcom/thinkware/sundo/ieve/IEVE;)I

    move-result v3

    invoke-static {v1, v7, v2, v3}, Landroid/os/Message;->obtain(Landroid/os/Handler;III)Landroid/os/Message;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    .line 1585
    :cond_2
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE$2;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v0}, Lcom/thinkware/sundo/ieve/IEVE;->y(Lcom/thinkware/sundo/ieve/IEVE;)I

    move-result v0

    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE$2;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v1}, Lcom/thinkware/sundo/ieve/IEVE;->z(Lcom/thinkware/sundo/ieve/IEVE;)I

    move-result v1

    if-eq v0, v1, :cond_3

    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE$2;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v0}, Lcom/thinkware/sundo/ieve/IEVE;->c(Lcom/thinkware/sundo/ieve/IEVE;)Landroid/os/Handler;

    move-result-object v0

    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE$2;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v1}, Lcom/thinkware/sundo/ieve/IEVE;->c(Lcom/thinkware/sundo/ieve/IEVE;)Landroid/os/Handler;

    move-result-object v1

    const/16 v2, 0x800

    iget-object v3, p0, Lcom/thinkware/sundo/ieve/IEVE$2;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v3}, Lcom/thinkware/sundo/ieve/IEVE;->y(Lcom/thinkware/sundo/ieve/IEVE;)I

    move-result v3

    invoke-static {v1, v7, v2, v3}, Landroid/os/Message;->obtain(Landroid/os/Handler;III)Landroid/os/Message;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    .line 1586
    :cond_3
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE$2;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v0}, Lcom/thinkware/sundo/ieve/IEVE;->A(Lcom/thinkware/sundo/ieve/IEVE;)I

    move-result v0

    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE$2;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v1}, Lcom/thinkware/sundo/ieve/IEVE;->B(Lcom/thinkware/sundo/ieve/IEVE;)I

    move-result v1

    if-eq v0, v1, :cond_4

    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE$2;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v0}, Lcom/thinkware/sundo/ieve/IEVE;->c(Lcom/thinkware/sundo/ieve/IEVE;)Landroid/os/Handler;

    move-result-object v0

    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE$2;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v1}, Lcom/thinkware/sundo/ieve/IEVE;->c(Lcom/thinkware/sundo/ieve/IEVE;)Landroid/os/Handler;

    move-result-object v1

    const/16 v2, 0x400

    iget-object v3, p0, Lcom/thinkware/sundo/ieve/IEVE$2;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v3}, Lcom/thinkware/sundo/ieve/IEVE;->A(Lcom/thinkware/sundo/ieve/IEVE;)I

    move-result v3

    invoke-static {v1, v7, v2, v3}, Landroid/os/Message;->obtain(Landroid/os/Handler;III)Landroid/os/Message;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    .line 1587
    :cond_4
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE$2;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v0}, Lcom/thinkware/sundo/ieve/IEVE;->C(Lcom/thinkware/sundo/ieve/IEVE;)I

    move-result v0

    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE$2;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v1}, Lcom/thinkware/sundo/ieve/IEVE;->D(Lcom/thinkware/sundo/ieve/IEVE;)I

    move-result v1

    if-eq v0, v1, :cond_5

    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE$2;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v0}, Lcom/thinkware/sundo/ieve/IEVE;->c(Lcom/thinkware/sundo/ieve/IEVE;)Landroid/os/Handler;

    move-result-object v0

    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE$2;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v1}, Lcom/thinkware/sundo/ieve/IEVE;->c(Lcom/thinkware/sundo/ieve/IEVE;)Landroid/os/Handler;

    move-result-object v1

    const/16 v2, 0x2000

    iget-object v3, p0, Lcom/thinkware/sundo/ieve/IEVE$2;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v3}, Lcom/thinkware/sundo/ieve/IEVE;->C(Lcom/thinkware/sundo/ieve/IEVE;)I

    move-result v3

    invoke-static {v1, v7, v2, v3}, Landroid/os/Message;->obtain(Landroid/os/Handler;III)Landroid/os/Message;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    .line 1588
    :cond_5
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE$2;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v0}, Lcom/thinkware/sundo/ieve/IEVE;->E(Lcom/thinkware/sundo/ieve/IEVE;)I

    move-result v0

    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE$2;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v1}, Lcom/thinkware/sundo/ieve/IEVE;->F(Lcom/thinkware/sundo/ieve/IEVE;)I

    move-result v1

    if-eq v0, v1, :cond_6

    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE$2;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v0}, Lcom/thinkware/sundo/ieve/IEVE;->c(Lcom/thinkware/sundo/ieve/IEVE;)Landroid/os/Handler;

    move-result-object v0

    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE$2;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v1}, Lcom/thinkware/sundo/ieve/IEVE;->c(Lcom/thinkware/sundo/ieve/IEVE;)Landroid/os/Handler;

    move-result-object v1

    const/16 v2, 0x1000

    iget-object v3, p0, Lcom/thinkware/sundo/ieve/IEVE$2;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v3}, Lcom/thinkware/sundo/ieve/IEVE;->E(Lcom/thinkware/sundo/ieve/IEVE;)I

    move-result v3

    invoke-static {v1, v7, v2, v3}, Landroid/os/Message;->obtain(Landroid/os/Handler;III)Landroid/os/Message;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    .line 1590
    :cond_6
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE$2;->a:Lcom/thinkware/sundo/ieve/IEVE;

    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE$2;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v1}, Lcom/thinkware/sundo/ieve/IEVE;->s(Lcom/thinkware/sundo/ieve/IEVE;)I

    move-result v1

    invoke-static {v0, v1}, Lcom/thinkware/sundo/ieve/IEVE;->k(Lcom/thinkware/sundo/ieve/IEVE;I)V

    .line 1591
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE$2;->a:Lcom/thinkware/sundo/ieve/IEVE;

    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE$2;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v1}, Lcom/thinkware/sundo/ieve/IEVE;->u(Lcom/thinkware/sundo/ieve/IEVE;)I

    move-result v1

    invoke-static {v0, v1}, Lcom/thinkware/sundo/ieve/IEVE;->l(Lcom/thinkware/sundo/ieve/IEVE;I)V

    .line 1592
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE$2;->a:Lcom/thinkware/sundo/ieve/IEVE;

    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE$2;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v1}, Lcom/thinkware/sundo/ieve/IEVE;->w(Lcom/thinkware/sundo/ieve/IEVE;)I

    move-result v1

    invoke-static {v0, v1}, Lcom/thinkware/sundo/ieve/IEVE;->m(Lcom/thinkware/sundo/ieve/IEVE;I)V

    .line 1593
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE$2;->a:Lcom/thinkware/sundo/ieve/IEVE;

    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE$2;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v1}, Lcom/thinkware/sundo/ieve/IEVE;->y(Lcom/thinkware/sundo/ieve/IEVE;)I

    move-result v1

    invoke-static {v0, v1}, Lcom/thinkware/sundo/ieve/IEVE;->n(Lcom/thinkware/sundo/ieve/IEVE;I)V

    .line 1594
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE$2;->a:Lcom/thinkware/sundo/ieve/IEVE;

    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE$2;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v1}, Lcom/thinkware/sundo/ieve/IEVE;->A(Lcom/thinkware/sundo/ieve/IEVE;)I

    move-result v1

    invoke-static {v0, v1}, Lcom/thinkware/sundo/ieve/IEVE;->o(Lcom/thinkware/sundo/ieve/IEVE;I)V

    .line 1595
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE$2;->a:Lcom/thinkware/sundo/ieve/IEVE;

    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE$2;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v1}, Lcom/thinkware/sundo/ieve/IEVE;->C(Lcom/thinkware/sundo/ieve/IEVE;)I

    move-result v1

    invoke-static {v0, v1}, Lcom/thinkware/sundo/ieve/IEVE;->p(Lcom/thinkware/sundo/ieve/IEVE;I)V

    .line 1596
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE$2;->a:Lcom/thinkware/sundo/ieve/IEVE;

    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE$2;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v1}, Lcom/thinkware/sundo/ieve/IEVE;->E(Lcom/thinkware/sundo/ieve/IEVE;)I

    move-result v1

    invoke-static {v0, v1}, Lcom/thinkware/sundo/ieve/IEVE;->q(Lcom/thinkware/sundo/ieve/IEVE;I)V

    .line 1599
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE$2;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v0}, Lcom/thinkware/sundo/ieve/IEVE;->h(Lcom/thinkware/sundo/ieve/IEVE;)Lcom/stradvision/pdvdtest/SV_ADAS;

    move-result-object v0

    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE$2;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v1}, Lcom/thinkware/sundo/ieve/IEVE;->l(Lcom/thinkware/sundo/ieve/IEVE;)I

    move-result v1

    int-to-float v1, v1

    const/high16 v2, 0x41200000    # 10.0f

    div-float/2addr v1, v2

    iget-object v2, p0, Lcom/thinkware/sundo/ieve/IEVE$2;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v2}, Lcom/thinkware/sundo/ieve/IEVE;->g(Lcom/thinkware/sundo/ieve/IEVE;)I

    move-result v2

    invoke-virtual {v0, v1, v2}, Lcom/stradvision/pdvdtest/SV_ADAS;->SetSpeed(FI)V

    .line 1600
    return-void
.end method
