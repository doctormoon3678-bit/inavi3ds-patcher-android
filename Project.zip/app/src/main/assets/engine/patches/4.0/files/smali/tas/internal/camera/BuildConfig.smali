.class public final Ltas/internal/camera/BuildConfig;
.super Ljava/lang/Object;
.source "BuildConfig.java"


# static fields
.field public static final SERVER_CLS:Ljava/lang/String; = "tas.service.camera.CameraServer"

.field public static final SERVER_PKG:Ljava/lang/String; = "tas.service.common"

.field private static final TAG:Ljava/lang/String; = "TasCAM<Build>"

.field public static final VERSION:Ljava/lang/String; = "2.0.14"

.field public static final VERSION_CODE:I = 0xf


# direct methods
.method public constructor <init>()V
    .locals 0

    .prologue
    .line 10
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static printVersion()V
    .locals 3

    .prologue
    .line 24
    const-string/jumbo v0, "TasCAM<Build>"

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    .line 25
    const-string/jumbo v2, "v"

    .line 24
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    .line 25
    const-string/jumbo v2, "2.0.14"

    .line 24
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    .line 26
    const-string/jumbo v2, "-"

    .line 24
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    .line 26
    const/16 v2, 0xf

    .line 24
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 23
    return-void
.end method
