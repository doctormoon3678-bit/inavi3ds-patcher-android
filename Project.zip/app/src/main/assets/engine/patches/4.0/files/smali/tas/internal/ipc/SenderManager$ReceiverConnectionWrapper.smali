.class Ltas/internal/ipc/SenderManager$ReceiverConnectionWrapper;
.super Ltas/internal/ipc/ReceiverConnection;
.source "SenderManager.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltas/internal/ipc/SenderManager;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "ReceiverConnectionWrapper"
.end annotation


# instance fields
.field receiver:Ltas/internal/ipc/SenderManager$ReceiverWrapper;

.field sender:Ltas/internal/ipc/server/RemoteSender;

.field final synthetic this$0:Ltas/internal/ipc/SenderManager;


# direct methods
.method constructor <init>(Ltas/internal/ipc/SenderManager;Landroid/content/Context;Ltas/internal/ipc/server/RemoteSender;Ltas/internal/ipc/SenderManager$ReceiverWrapper;Landroid/os/Looper;)V
    .locals 0
    .param p1, "this$0"    # Ltas/internal/ipc/SenderManager;
    .param p2, "context"    # Landroid/content/Context;
    .param p3, "sender"    # Ltas/internal/ipc/server/RemoteSender;
    .param p4, "receiver"    # Ltas/internal/ipc/SenderManager$ReceiverWrapper;
    .param p5, "l"    # Landroid/os/Looper;

    .prologue
    .line 618
    iput-object p1, p0, Ltas/internal/ipc/SenderManager$ReceiverConnectionWrapper;->this$0:Ltas/internal/ipc/SenderManager;

    .line 620
    invoke-direct {p0, p2, p4, p5}, Ltas/internal/ipc/ReceiverConnection;-><init>(Landroid/content/Context;Ltas/internal/ipc/server/RemoteReceiver;Landroid/os/Looper;)V

    .line 621
    iput-object p4, p0, Ltas/internal/ipc/SenderManager$ReceiverConnectionWrapper;->receiver:Ltas/internal/ipc/SenderManager$ReceiverWrapper;

    .line 622
    iput-object p3, p0, Ltas/internal/ipc/SenderManager$ReceiverConnectionWrapper;->sender:Ltas/internal/ipc/server/RemoteSender;

    .line 619
    return-void
.end method


# virtual methods
.method public onConnected()V
    .locals 3

    .prologue
    .line 627
    iget-object v0, p0, Ltas/internal/ipc/SenderManager$ReceiverConnectionWrapper;->this$0:Ltas/internal/ipc/SenderManager;

    iget-object v1, p0, Ltas/internal/ipc/SenderManager$ReceiverConnectionWrapper;->sender:Ltas/internal/ipc/server/RemoteSender;

    iget-object v2, p0, Ltas/internal/ipc/SenderManager$ReceiverConnectionWrapper;->receiver:Ltas/internal/ipc/SenderManager$ReceiverWrapper;

    invoke-static {v0, v1, v2}, Ltas/internal/ipc/SenderManager;->-wrap4(Ltas/internal/ipc/SenderManager;Ltas/internal/ipc/server/RemoteSender;Ltas/internal/ipc/SenderManager$ReceiverWrapper;)V

    .line 626
    return-void
.end method

.method public onDeath()V
    .locals 2

    .prologue
    .line 638
    iget-object v0, p0, Ltas/internal/ipc/SenderManager$ReceiverConnectionWrapper;->this$0:Ltas/internal/ipc/SenderManager;

    iget-object v1, p0, Ltas/internal/ipc/SenderManager$ReceiverConnectionWrapper;->receiver:Ltas/internal/ipc/SenderManager$ReceiverWrapper;

    invoke-static {v0, v1}, Ltas/internal/ipc/SenderManager;->-wrap5(Ltas/internal/ipc/SenderManager;Ltas/internal/ipc/SenderManager$ReceiverWrapper;)V

    .line 639
    invoke-virtual {p0}, Ltas/internal/ipc/SenderManager$ReceiverConnectionWrapper;->quitSafely()V

    .line 637
    return-void
.end method

.method public onDisconnected()V
    .locals 3

    .prologue
    .line 632
    iget-object v0, p0, Ltas/internal/ipc/SenderManager$ReceiverConnectionWrapper;->this$0:Ltas/internal/ipc/SenderManager;

    iget-object v1, p0, Ltas/internal/ipc/SenderManager$ReceiverConnectionWrapper;->sender:Ltas/internal/ipc/server/RemoteSender;

    iget-object v2, p0, Ltas/internal/ipc/SenderManager$ReceiverConnectionWrapper;->receiver:Ltas/internal/ipc/SenderManager$ReceiverWrapper;

    invoke-static {v0, v1, v2}, Ltas/internal/ipc/SenderManager;->-wrap6(Ltas/internal/ipc/SenderManager;Ltas/internal/ipc/server/RemoteSender;Ltas/internal/ipc/SenderManager$ReceiverWrapper;)V

    .line 633
    invoke-virtual {p0}, Ltas/internal/ipc/SenderManager$ReceiverConnectionWrapper;->quitSafely()V

    .line 631
    return-void
.end method
