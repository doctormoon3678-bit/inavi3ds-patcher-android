.class Ltas/internal/ipc/server/ServerManager$ReceiverHolder;
.super Ljava/lang/Object;
.source "ServerManager.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltas/internal/ipc/server/ServerManager;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "ReceiverHolder"
.end annotation


# instance fields
.field private handler:Ltas/internal/ipc/server/ServerManager$ClientHandler;

.field private r:Ltas/internal/ipc/server/RemoteReceiver;

.field private final senders:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List",
            "<",
            "Ltas/internal/ipc/server/RemoteSender;",
            ">;"
        }
    .end annotation
.end field

.field private watchAnonymous:Z

.field private final watchList:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List",
            "<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static synthetic -get0(Ltas/internal/ipc/server/ServerManager$ReceiverHolder;)Ltas/internal/ipc/server/RemoteReceiver;
    .locals 1

    iget-object v0, p0, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->r:Ltas/internal/ipc/server/RemoteReceiver;

    return-object v0
.end method

.method static synthetic -get1(Ltas/internal/ipc/server/ServerManager$ReceiverHolder;)Ljava/util/List;
    .locals 1

    iget-object v0, p0, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->senders:Ljava/util/List;

    return-object v0
.end method

.method static synthetic -get2(Ltas/internal/ipc/server/ServerManager$ReceiverHolder;)Z
    .locals 1

    iget-boolean v0, p0, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->watchAnonymous:Z

    return v0
.end method

.method static synthetic -get3(Ltas/internal/ipc/server/ServerManager$ReceiverHolder;)Ljava/util/List;
    .locals 1

    iget-object v0, p0, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->watchList:Ljava/util/List;

    return-object v0
.end method

.method static synthetic -set0(Ltas/internal/ipc/server/ServerManager$ReceiverHolder;Z)Z
    .locals 0

    iput-boolean p1, p0, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->watchAnonymous:Z

    return p1
.end method

.method static synthetic -wrap0(Ltas/internal/ipc/server/ServerManager$ReceiverHolder;Ltas/internal/ipc/server/RemoteSender;)Z
    .locals 1
    .param p1, "s"    # Ltas/internal/ipc/server/RemoteSender;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->hasSender(Ltas/internal/ipc/server/RemoteSender;)Z

    move-result v0

    return v0
.end method

.method static synthetic -wrap1(Ltas/internal/ipc/server/ServerManager$ReceiverHolder;Ljava/lang/String;)Z
    .locals 1
    .param p1, "name"    # Ljava/lang/String;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->isWatching(Ljava/lang/String;)Z

    move-result v0

    return v0
.end method

.method static synthetic -wrap2(Ltas/internal/ipc/server/ServerManager$ReceiverHolder;Ltas/internal/ipc/server/RemoteSender;)Z
    .locals 1
    .param p1, "s"    # Ltas/internal/ipc/server/RemoteSender;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->removeSender(Ltas/internal/ipc/server/RemoteSender;)Z

    move-result v0

    return v0
.end method

.method static synthetic -wrap3(Ltas/internal/ipc/server/ServerManager$ReceiverHolder;Ljava/lang/String;)Z
    .locals 1
    .param p1, "name"    # Ljava/lang/String;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->unwatch(Ljava/lang/String;)Z

    move-result v0

    return v0
.end method

.method static synthetic -wrap4(Ltas/internal/ipc/server/ServerManager$ReceiverHolder;Ltas/internal/ipc/server/RemoteSender;)V
    .locals 0
    .param p1, "s"    # Ltas/internal/ipc/server/RemoteSender;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->addSender(Ltas/internal/ipc/server/RemoteSender;)V

    return-void
.end method

.method static synthetic -wrap5(Ltas/internal/ipc/server/ServerManager$ReceiverHolder;)V
    .locals 0

    invoke-direct {p0}, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->binderDied()V

    return-void
.end method

.method static synthetic -wrap6(Ltas/internal/ipc/server/ServerManager$ReceiverHolder;Ljava/lang/String;)V
    .locals 0
    .param p1, "name"    # Ljava/lang/String;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->watch(Ljava/lang/String;)V

    return-void
.end method

.method private constructor <init>(Ltas/internal/ipc/server/ServerManager$ClientHandler;Ltas/internal/ipc/server/RemoteReceiver;)V
    .locals 1
    .param p1, "_c"    # Ltas/internal/ipc/server/ServerManager$ClientHandler;
    .param p2, "_r"    # Ltas/internal/ipc/server/RemoteReceiver;

    .prologue
    .line 1146
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1139
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->watchList:Ljava/util/List;

    .line 1141
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 1140
    iput-object v0, p0, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->senders:Ljava/util/List;

    .line 1147
    iput-object p1, p0, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->handler:Ltas/internal/ipc/server/ServerManager$ClientHandler;

    iput-object p2, p0, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->r:Ltas/internal/ipc/server/RemoteReceiver;

    .line 1146
    return-void
.end method

.method synthetic constructor <init>(Ltas/internal/ipc/server/ServerManager$ClientHandler;Ltas/internal/ipc/server/RemoteReceiver;Ltas/internal/ipc/server/ServerManager$ReceiverHolder;)V
    .locals 0
    .param p1, "_c"    # Ltas/internal/ipc/server/ServerManager$ClientHandler;
    .param p2, "_r"    # Ltas/internal/ipc/server/RemoteReceiver;

    .prologue
    invoke-direct {p0, p1, p2}, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;-><init>(Ltas/internal/ipc/server/ServerManager$ClientHandler;Ltas/internal/ipc/server/RemoteReceiver;)V

    return-void
.end method

.method private addSender(Ltas/internal/ipc/server/RemoteSender;)V
    .locals 1
    .param p1, "s"    # Ltas/internal/ipc/server/RemoteSender;

    .prologue
    .line 1167
    iget-object v0, p0, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->senders:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 1166
    return-void
.end method

.method private binderDied()V
    .locals 6

    .prologue
    .line 1175
    iget-object v3, p0, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->watchList:Ljava/util/List;

    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v2

    .local v2, "watch$iterator":Ljava/util/Iterator;
    :cond_0
    :goto_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_1

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    .line 1176
    .local v1, "watch":Ljava/lang/String;
    if-eqz v1, :cond_0

    .line 1177
    iget-object v3, p0, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->r:Ltas/internal/ipc/server/RemoteReceiver;

    invoke-static {v3}, Ltas/internal/ipc/server/RemoteReceiver;->obtain(Ltas/internal/ipc/server/RemoteReceiver;)Ltas/internal/ipc/server/RemoteReceiver;

    move-result-object v0

    .line 1178
    .local v0, "rr":Ltas/internal/ipc/server/RemoteReceiver;
    iput-object v1, v0, Ltas/internal/ipc/server/RemoteReceiver;->target:Ljava/lang/String;

    .line 1179
    iget-object v3, p0, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->handler:Ltas/internal/ipc/server/ServerManager$ClientHandler;

    const/16 v4, 0xb

    invoke-static {v3, v4, v0}, Ltas/internal/ipc/server/ServerManager$ClientHandler;->-wrap0(Ltas/internal/ipc/server/ServerManager$ClientHandler;ILtas/internal/ipc/server/RemoteReceiver;)V

    goto :goto_0

    .line 1181
    .end local v0    # "rr":Ltas/internal/ipc/server/RemoteReceiver;
    .end local v1    # "watch":Ljava/lang/String;
    :cond_1
    iget-boolean v3, p0, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->watchAnonymous:Z

    if-eqz v3, :cond_2

    .line 1182
    iget-object v3, p0, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->handler:Ltas/internal/ipc/server/ServerManager$ClientHandler;

    iget-object v4, p0, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->r:Ltas/internal/ipc/server/RemoteReceiver;

    const/16 v5, 0xd

    invoke-static {v3, v5, v4}, Ltas/internal/ipc/server/ServerManager$ClientHandler;->-wrap0(Ltas/internal/ipc/server/ServerManager$ClientHandler;ILtas/internal/ipc/server/RemoteReceiver;)V

    .line 1184
    :cond_2
    iget-object v3, p0, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->handler:Ltas/internal/ipc/server/ServerManager$ClientHandler;

    iget-object v4, p0, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->r:Ltas/internal/ipc/server/RemoteReceiver;

    const/4 v5, 0x1

    invoke-static {v3, v5, v4}, Ltas/internal/ipc/server/ServerManager$ClientHandler;->-wrap0(Ltas/internal/ipc/server/ServerManager$ClientHandler;ILtas/internal/ipc/server/RemoteReceiver;)V

    .line 1174
    return-void
.end method

.method private hasSender(Ltas/internal/ipc/server/RemoteSender;)Z
    .locals 1
    .param p1, "s"    # Ltas/internal/ipc/server/RemoteSender;

    .prologue
    .line 1163
    iget-object v0, p0, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->senders:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v0

    return v0
.end method

.method private isWatching(Ljava/lang/String;)Z
    .locals 1
    .param p1, "name"    # Ljava/lang/String;

    .prologue
    .line 1151
    iget-object v0, p0, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->watchList:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v0

    return v0
.end method

.method private removeSender(Ltas/internal/ipc/server/RemoteSender;)Z
    .locals 1
    .param p1, "s"    # Ltas/internal/ipc/server/RemoteSender;

    .prologue
    .line 1171
    iget-object v0, p0, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->senders:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->remove(Ljava/lang/Object;)Z

    move-result v0

    return v0
.end method

.method private unwatch(Ljava/lang/String;)Z
    .locals 1
    .param p1, "name"    # Ljava/lang/String;

    .prologue
    .line 1159
    iget-object v0, p0, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->watchList:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->remove(Ljava/lang/Object;)Z

    move-result v0

    return v0
.end method

.method private watch(Ljava/lang/String;)V
    .locals 1
    .param p1, "name"    # Ljava/lang/String;

    .prologue
    .line 1155
    iget-object v0, p0, Ltas/internal/ipc/server/ServerManager$ReceiverHolder;->watchList:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 1154
    return-void
.end method
