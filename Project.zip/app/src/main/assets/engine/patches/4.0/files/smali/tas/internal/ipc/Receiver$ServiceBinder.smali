.class final Ltas/internal/ipc/Receiver$ServiceBinder;
.super Ltas/internal/ipc/server/IRemoteTransmitter$Stub;
.source "Receiver.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltas/internal/ipc/Receiver;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "ServiceBinder"
.end annotation


# instance fields
.field private mM:Ljava/lang/ref/WeakReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference",
            "<",
            "Ltas/internal/ipc/ReceiverManager;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Ltas/internal/ipc/ReceiverManager;)V
    .locals 1
    .param p1, "m"    # Ltas/internal/ipc/ReceiverManager;

    .prologue
    .line 233
    invoke-direct {p0}, Ltas/internal/ipc/server/IRemoteTransmitter$Stub;-><init>()V

    .line 234
    new-instance v0, Ljava/lang/ref/WeakReference;

    invoke-direct {v0, p1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    iput-object v0, p0, Ltas/internal/ipc/Receiver$ServiceBinder;->mM:Ljava/lang/ref/WeakReference;

    .line 233
    return-void
.end method


# virtual methods
.method public transmit(Ltas/internal/ipc/server/RemoteMessage;)V
    .locals 2
    .param p1, "msg"    # Ltas/internal/ipc/server/RemoteMessage;

    .prologue
    .line 237
    iget-object v1, p0, Ltas/internal/ipc/Receiver$ServiceBinder;->mM:Ljava/lang/ref/WeakReference;

    invoke-virtual {v1}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/ipc/ReceiverManager;

    .line 238
    .local v0, "m":Ltas/internal/ipc/ReceiverManager;
    if-eqz v0, :cond_0

    .line 239
    invoke-virtual {v0, p1}, Ltas/internal/ipc/ReceiverManager;->transmit(Ltas/internal/ipc/server/RemoteMessage;)V

    .line 236
    :goto_0
    return-void

    .line 241
    :cond_0
    invoke-virtual {p1}, Ltas/internal/ipc/server/RemoteMessage;->recycle()V

    goto :goto_0
.end method
