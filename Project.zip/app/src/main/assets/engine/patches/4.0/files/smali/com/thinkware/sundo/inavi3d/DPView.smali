.class public Lcom/thinkware/sundo/inavi3d/DPView;
.super Landroid/opengl/GLSurfaceView;
.source "DPView.java"

# interfaces
.implements Landroid/opengl/GLSurfaceView$Renderer;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/thinkware/sundo/inavi3d/DPView$ListenerMain;
    }
.end annotation


# static fields
.field public static BackGroundRenderingStep:J

.field static TAG:Ljava/lang/String;

.field static TAG_MEM:Ljava/lang/String;

.field private static guideinfos:Lcom/thinkware/sundo/ieve/ieveGuideInfos;

.field private static isExecuteRender:Z

.field private static mHolder:Landroid/view/SurfaceHolder;

.field private static mIsSurfaceRunning:Z

.field static mb32Bit:Z

.field public static surfaceDestroyedCount:I


# instance fields
.field public bCheckThreasthart:Z

.field firstOnDraw:Z

.field private iNavi3DActivity:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

.field isSurfaceCreated:Z

.field private mAngleDirDP:F

.field private mAngleVrtDP:F

.field private mCarPosX:F

.field private mCarPosY:F

.field private mCarPosZ:F

.field private mCountFrame:I

.field private mFrameRate:F

.field private mIeve:Lcom/thinkware/sundo/ieve/IEVE;

.field private mInavi:Lcom/thinkware/sundo/inavi3d/Inavi;

.field private mIsDRGPS:Z

.field private mIsViewModeChanged:Z

.field mMainHandler:Landroid/os/Handler;

.field private mUptimeMsecPrevious:J

.field mValidDrag:Z

.field public mbFirstInit:Z

.field public mbIntiInavi:Z

.field onDrawFrameCall:Z

.field surfaceCreatedCount:I


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .prologue
    const/4 v1, 0x0

    .line 29
    const-string v0, "inavi3d_java"

    sput-object v0, Lcom/thinkware/sundo/inavi3d/DPView;->TAG:Ljava/lang/String;

    .line 30
    const-string v0, "inavi3d_mem"

    sput-object v0, Lcom/thinkware/sundo/inavi3d/DPView;->TAG_MEM:Ljava/lang/String;

    .line 31
    const/4 v0, 0x1

    sput-boolean v0, Lcom/thinkware/sundo/inavi3d/DPView;->mb32Bit:Z

    .line 37
    const/4 v0, 0x0

    sput-object v0, Lcom/thinkware/sundo/inavi3d/DPView;->mHolder:Landroid/view/SurfaceHolder;

    .line 38
    sput-boolean v1, Lcom/thinkware/sundo/inavi3d/DPView;->mIsSurfaceRunning:Z

    .line 41
    sput-boolean v1, Lcom/thinkware/sundo/inavi3d/DPView;->isExecuteRender:Z

    .line 194
    sput v1, Lcom/thinkware/sundo/inavi3d/DPView;->surfaceDestroyedCount:I

    .line 210
    const-wide/16 v0, -0x1

    sput-wide v0, Lcom/thinkware/sundo/inavi3d/DPView;->BackGroundRenderingStep:J

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/os/Handler;)V
    .locals 7
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "handler"    # Landroid/os/Handler;

    .prologue
    const/4 v6, 0x2

    const/4 v2, 0x0

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v1, 0x0

    .line 76
    invoke-direct {p0, p1}, Landroid/opengl/GLSurfaceView;-><init>(Landroid/content/Context;)V

    .line 32
    iput-object v2, p0, Lcom/thinkware/sundo/inavi3d/DPView;->mInavi:Lcom/thinkware/sundo/inavi3d/Inavi;

    .line 33
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/DPView;->mbIntiInavi:Z

    .line 34
    iput-boolean v5, p0, Lcom/thinkware/sundo/inavi3d/DPView;->mbFirstInit:Z

    .line 36
    iput-object v2, p0, Lcom/thinkware/sundo/inavi3d/DPView;->iNavi3DActivity:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    .line 39
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/DPView;->bCheckThreasthart:Z

    .line 46
    iput-object v2, p0, Lcom/thinkware/sundo/inavi3d/DPView;->mIeve:Lcom/thinkware/sundo/ieve/IEVE;

    .line 47
    iput v1, p0, Lcom/thinkware/sundo/inavi3d/DPView;->mCountFrame:I

    .line 48
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v2

    iput-wide v2, p0, Lcom/thinkware/sundo/inavi3d/DPView;->mUptimeMsecPrevious:J

    .line 49
    iput v4, p0, Lcom/thinkware/sundo/inavi3d/DPView;->mFrameRate:F

    .line 53
    iput v4, p0, Lcom/thinkware/sundo/inavi3d/DPView;->mAngleDirDP:F

    .line 54
    iput v4, p0, Lcom/thinkware/sundo/inavi3d/DPView;->mAngleVrtDP:F

    .line 55
    iput v4, p0, Lcom/thinkware/sundo/inavi3d/DPView;->mCarPosX:F

    .line 56
    iput v4, p0, Lcom/thinkware/sundo/inavi3d/DPView;->mCarPosY:F

    .line 57
    iput v4, p0, Lcom/thinkware/sundo/inavi3d/DPView;->mCarPosZ:F

    .line 60
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/DPView;->mIsDRGPS:Z

    .line 61
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/DPView;->mIsViewModeChanged:Z

    .line 154
    iput v1, p0, Lcom/thinkware/sundo/inavi3d/DPView;->surfaceCreatedCount:I

    .line 155
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/DPView;->isSurfaceCreated:Z

    .line 209
    iput-boolean v5, p0, Lcom/thinkware/sundo/inavi3d/DPView;->firstOnDraw:Z

    .line 243
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/DPView;->onDrawFrameCall:Z

    .line 585
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/DPView;->mValidDrag:Z

    .line 77
    check-cast p1, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    .end local p1    # "context":Landroid/content/Context;
    iput-object p1, p0, Lcom/thinkware/sundo/inavi3d/DPView;->iNavi3DActivity:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    .line 78
    iput-object p2, p0, Lcom/thinkware/sundo/inavi3d/DPView;->mMainHandler:Landroid/os/Handler;

    .line 79
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/DPView;->getHolder()Landroid/view/SurfaceHolder;

    move-result-object v1

    sput-object v1, Lcom/thinkware/sundo/inavi3d/DPView;->mHolder:Landroid/view/SurfaceHolder;

    .line 80
    sget-object v1, Lcom/thinkware/sundo/inavi3d/DPView;->mHolder:Landroid/view/SurfaceHolder;

    invoke-interface {v1, p0}, Landroid/view/SurfaceHolder;->addCallback(Landroid/view/SurfaceHolder$Callback;)V

    .line 81
    sget-object v1, Lcom/thinkware/sundo/inavi3d/DPView;->mHolder:Landroid/view/SurfaceHolder;

    invoke-interface {v1, v6}, Landroid/view/SurfaceHolder;->setType(I)V

    .line 85
    sget-object v1, Lcom/thinkware/sundo/inavi3d/DPView;->mHolder:Landroid/view/SurfaceHolder;

    invoke-interface {v1, v5}, Landroid/view/SurfaceHolder;->setFormat(I)V

    .line 87
    new-instance v0, Lcom/thinkware/sundo/inavi3d/DPView$1;

    invoke-direct {v0, p0}, Lcom/thinkware/sundo/inavi3d/DPView$1;-><init>(Lcom/thinkware/sundo/inavi3d/DPView;)V

    .line 122
    .local v0, "mCostumChooser":Landroid/opengl/GLSurfaceView$EGLConfigChooser;
    invoke-virtual {p0, v0}, Lcom/thinkware/sundo/inavi3d/DPView;->setEGLConfigChooser(Landroid/opengl/GLSurfaceView$EGLConfigChooser;)V

    .line 124
    invoke-virtual {p0, v6}, Lcom/thinkware/sundo/inavi3d/DPView;->setEGLContextClientVersion(I)V

    .line 125
    invoke-virtual {p0, p0}, Lcom/thinkware/sundo/inavi3d/DPView;->setRenderer(Landroid/opengl/GLSurfaceView$Renderer;)V

    .line 126
    invoke-virtual {p0, v5}, Lcom/thinkware/sundo/inavi3d/DPView;->setRenderMode(I)V

    .line 127
    invoke-virtual {p0, v5}, Lcom/thinkware/sundo/inavi3d/DPView;->setZOrderOnTop(Z)V

    .line 128
    invoke-virtual {p0, v5}, Lcom/thinkware/sundo/inavi3d/DPView;->setZOrderMediaOverlay(Z)V

    .line 129
    return-void
.end method

.method public static isExecuteRender()Z
    .locals 1

    .prologue
    .line 554
    sget-boolean v0, Lcom/thinkware/sundo/inavi3d/DPView;->isExecuteRender:Z

    return v0
.end method


# virtual methods
.method public isSurfaceRunning()Z
    .locals 1

    .prologue
    .line 132
    sget-boolean v0, Lcom/thinkware/sundo/inavi3d/DPView;->mIsSurfaceRunning:Z

    return v0
.end method

.method public onDrawFrame(Ljavax/microedition/khronos/opengles/GL10;)V
    .locals 7
    .param p1, "gl"    # Ljavax/microedition/khronos/opengles/GL10;

    .prologue
    const/4 v5, 0x1

    const/4 v6, 0x0

    .line 246
    iget-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/DPView;->onDrawFrameCall:Z

    if-nez v1, :cond_0

    .line 248
    iput-boolean v5, p0, Lcom/thinkware/sundo/inavi3d/DPView;->onDrawFrameCall:Z

    .line 250
    :cond_0
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v2

    .line 252
    .local v2, "uptime_msec":J
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    move-result-object v1

    if-eqz v1, :cond_1

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    move-result-object v1

    invoke-virtual {v1}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->isEexcuteRenderInNameSrchActvity()Z

    move-result v1

    if-eqz v1, :cond_2

    :cond_1
    iget-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/DPView;->mbIntiInavi:Z

    if-eqz v1, :cond_2

    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/DPView;->isSurfaceRunning()Z

    move-result v1

    if-nez v1, :cond_3

    .line 304
    :cond_2
    :goto_0
    return-void

    .line 257
    :cond_3
    iget-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/DPView;->firstOnDraw:Z

    if-eqz v1, :cond_4

    .line 258
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/DPView;->mMainHandler:Landroid/os/Handler;

    const/16 v4, 0x251c

    invoke-virtual {v1, v4}, Landroid/os/Handler;->sendEmptyMessage(I)Z

    .line 259
    iput-boolean v6, p0, Lcom/thinkware/sundo/inavi3d/DPView;->firstOnDraw:Z

    .line 262
    :cond_4
    iget-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/DPView;->bCheckThreasthart:Z

    if-nez v1, :cond_5

    sget-boolean v1, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->EndThread_Condition_Guidance:Z

    if-nez v1, :cond_5

    .line 264
    sput-boolean v5, Lcom/thinkware/sundo/inavi3d/DPView;->isExecuteRender:Z

    .line 265
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/DPView;->mInavi:Lcom/thinkware/sundo/inavi3d/Inavi;

    invoke-virtual {v1, v2, v3}, Lcom/thinkware/sundo/inavi3d/Inavi;->executeRender(J)V

    .line 266
    sput-boolean v6, Lcom/thinkware/sundo/inavi3d/DPView;->isExecuteRender:Z

    .line 269
    :try_start_0
    sget v1, Lcom/thinkware/sundo/inavi3d/DeviceState;->mSleepTime:I

    int-to-long v4, v1

    invoke-static {v4, v5}, Ljava/lang/Thread;->sleep(J)V
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0

    .line 301
    :goto_1
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/DPView;->setInfosIEVE()V

    goto :goto_0

    .line 270
    :catch_0
    move-exception v0

    .line 271
    .local v0, "e":Ljava/lang/InterruptedException;
    sput-boolean v6, Lcom/thinkware/sundo/inavi3d/DPView;->isExecuteRender:Z

    .line 272
    invoke-virtual {v0}, Ljava/lang/InterruptedException;->printStackTrace()V

    goto :goto_1

    .line 276
    .end local v0    # "e":Ljava/lang/InterruptedException;
    :cond_5
    const-wide/16 v4, 0x1e

    :try_start_1
    invoke-static {v4, v5}, Ljava/lang/Thread;->sleep(J)V
    :try_end_1
    .catch Ljava/lang/InterruptedException; {:try_start_1 .. :try_end_1} :catch_1

    goto :goto_1

    .line 277
    :catch_1
    move-exception v0

    .line 278
    .restart local v0    # "e":Ljava/lang/InterruptedException;
    sput-boolean v6, Lcom/thinkware/sundo/inavi3d/DPView;->isExecuteRender:Z

    .line 279
    invoke-virtual {v0}, Ljava/lang/InterruptedException;->printStackTrace()V

    goto :goto_1
.end method

.method public onSurfaceChanged(Ljavax/microedition/khronos/opengles/GL10;II)V
    .locals 8
    .param p1, "gl"    # Ljavax/microedition/khronos/opengles/GL10;
    .param p2, "width"    # I
    .param p3, "height"    # I

    .prologue
    .line 559
    const-string v2, "startCheck"

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "onSurfaceChanged - start : "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v4

    sget-wide v6, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->INAVISTARTTIME:J

    sub-long/2addr v4, v6

    invoke-virtual {v3, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Lcom/thinkware/sundo/inavi3d/LOGTW;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 560
    sget-object v2, Lcom/thinkware/sundo/inavi3d/DPView;->TAG:Ljava/lang/String;

    const-string v3, "[JAVA. DPView] onSurfaceChanged"

    invoke-static {v2, v3}, Lcom/thinkware/sundo/inavi3d/LOGTW;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 562
    iget-boolean v2, p0, Lcom/thinkware/sundo/inavi3d/DPView;->mbIntiInavi:Z

    if-nez v2, :cond_0

    iget-boolean v2, p0, Lcom/thinkware/sundo/inavi3d/DPView;->mbFirstInit:Z

    const/4 v3, 0x1

    if-ne v2, v3, :cond_0

    .line 563
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v0

    .line 564
    .local v0, "nStartTime":J
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/DPView;->mInavi:Lcom/thinkware/sundo/inavi3d/Inavi;

    sget-object v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->kStorageRoot:Ljava/lang/String;

    invoke-virtual {v2, v3, p2, p3}, Lcom/thinkware/sundo/inavi3d/Inavi;->Initialize(Ljava/lang/String;II)Z

    move-result v2

    iput-boolean v2, p0, Lcom/thinkware/sundo/inavi3d/DPView;->mbIntiInavi:Z

    .line 565
    const-string v2, "onDrawFrame"

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "onSurfaceChanged: "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v4

    sub-long/2addr v4, v0

    invoke-virtual {v3, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Lcom/thinkware/sundo/inavi3d/LOGTW;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 566
    const/4 v2, 0x0

    iput-boolean v2, p0, Lcom/thinkware/sundo/inavi3d/DPView;->mbFirstInit:Z

    .line 567
    sget-object v2, Lcom/thinkware/sundo/inavi3d/DPView;->TAG:Ljava/lang/String;

    const-string v3, "[JAVA. DPView] done  for DP!!!"

    invoke-static {v2, v3}, Lcom/thinkware/sundo/inavi3d/LOGTW;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 569
    .end local v0    # "nStartTime":J
    :cond_0
    const-string v2, "startCheck"

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "onSurfaceChanged - end : "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v4

    sget-wide v6, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->INAVISTARTTIME:J

    sub-long/2addr v4, v6

    invoke-virtual {v3, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Lcom/thinkware/sundo/inavi3d/LOGTW;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 570
    return-void
.end method

.method public onSurfaceCreated(Ljavax/microedition/khronos/opengles/GL10;Ljavax/microedition/khronos/egl/EGLConfig;)V
    .locals 8
    .param p1, "gl"    # Ljavax/microedition/khronos/opengles/GL10;
    .param p2, "config"    # Ljavax/microedition/khronos/egl/EGLConfig;

    .prologue
    .line 573
    const-string v2, "startCheck"

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "onSurfaceCreated - start : "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v4

    sget-wide v6, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->INAVISTARTTIME:J

    sub-long/2addr v4, v6

    invoke-virtual {v3, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Lcom/thinkware/sundo/inavi3d/LOGTW;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 574
    sget-object v2, Lcom/thinkware/sundo/inavi3d/DPView;->TAG:Ljava/lang/String;

    const-string v3, "[JAVA. DPView] onSurfaceCreated"

    invoke-static {v2, v3}, Lcom/thinkware/sundo/inavi3d/LOGTW;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 577
    sget-object v2, Lcom/thinkware/sundo/inavi3d/DPView;->TAG:Ljava/lang/String;

    const-string v3, "[JAVA. DPView] start Initialize for DP!!!"

    invoke-static {v2, v3}, Lcom/thinkware/sundo/inavi3d/LOGTW;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 578
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v0

    .line 579
    .local v0, "nStartTime":J
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/DPView;->mInavi:Lcom/thinkware/sundo/inavi3d/Inavi;

    invoke-virtual {v2}, Lcom/thinkware/sundo/inavi3d/Inavi;->initCallBack()V

    .line 580
    const-string v2, "onDrawFrame"

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "onSurfaceCreated: "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v4

    sub-long/2addr v4, v0

    invoke-virtual {v3, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Lcom/thinkware/sundo/inavi3d/LOGTW;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 581
    sget-object v2, Lcom/thinkware/sundo/inavi3d/DPView;->TAG:Ljava/lang/String;

    const-string v3, "[JAVA. DPView] init CallBack done!!!"

    invoke-static {v2, v3}, Lcom/thinkware/sundo/inavi3d/LOGTW;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 582
    const-string v2, "startCheck"

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "onSurfaceCreated - end : "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v4

    sget-wide v6, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->INAVISTARTTIME:J

    sub-long/2addr v4, v6

    invoke-virtual {v3, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Lcom/thinkware/sundo/inavi3d/LOGTW;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 584
    return-void
.end method

.method public onTouchEvent(Landroid/view/MotionEvent;)Z
    .locals 11
    .param p1, "event"    # Landroid/view/MotionEvent;

    .prologue
    .line 588
    const-string v0, "inavi3d_java"

    const-string v5, "dp onTouchEvent"

    invoke-static {v0, v5}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 590
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->IsFirstCurrnetOn()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->isDoingCurrentOn()Z

    move-result v0

    const/4 v5, 0x1

    if-ne v0, v5, :cond_1

    .line 592
    :cond_0
    const-string v0, "inavi3d_java"

    const-string v5, "dp onTouchEvent :: IsFirstCurrnetOn() == false"

    invoke-static {v0, v5}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 593
    const/4 v0, 0x0

    .line 745
    :goto_0
    return v0

    .line 596
    :cond_1
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/DPView;->iNavi3DActivity:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    if-nez v0, :cond_2

    .line 597
    invoke-super {p0, p1}, Landroid/opengl/GLSurfaceView;->onTouchEvent(Landroid/view/MotionEvent;)Z

    move-result v0

    goto :goto_0

    .line 599
    :cond_2
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/DPView;->mInavi:Lcom/thinkware/sundo/inavi3d/Inavi;

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/Inavi;->isInitDone()Z

    move-result v0

    if-eqz v0, :cond_3

    sget-boolean v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->initComponentCompleted:Z

    if-eqz v0, :cond_3

    sget-boolean v0, Lcom/thinkware/sundo/inavi3d/Inavi;->firstTBTGuide:Z

    const/4 v5, 0x1

    if-eq v0, v5, :cond_3

    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/DPView;->iNavi3DActivity:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-boolean v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->initDPTouch:Z

    if-nez v0, :cond_4

    .line 600
    :cond_3
    invoke-super {p0, p1}, Landroid/opengl/GLSurfaceView;->onTouchEvent(Landroid/view/MotionEvent;)Z

    move-result v0

    goto :goto_0

    .line 605
    :cond_4
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getPointerCount()I

    move-result v0

    const/4 v5, 0x1

    if-ne v0, v5, :cond_1a

    .line 606
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/DPView;->iNavi3DActivity:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->isShowInaviDialog()Z

    move-result v6

    .line 607
    .local v6, "showDialog":Z
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getRawX()F

    move-result v7

    .line 608
    .local v7, "x":F
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getRawY()F

    move-result v8

    .line 610
    .local v8, "y":F
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v0

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->is_support_scale()Z

    move-result v0

    if-eqz v0, :cond_5

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v0

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->isWideDisplay()Z

    move-result v0

    if-nez v0, :cond_5

    .line 611
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INaviScaleManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INaviScaleManager;

    move-result-object v0

    invoke-virtual {v0, v7}, Lcom/thinkware/sundo/inavi3d/INaviScaleManager;->scaleTouchX(F)F

    move-result v7

    .line 612
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INaviScaleManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INaviScaleManager;

    move-result-object v0

    invoke-virtual {v0, v8}, Lcom/thinkware/sundo/inavi3d/INaviScaleManager;->scaleTouchY(F)F

    move-result v8

    .line 615
    :cond_5
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/DPView;->iNavi3DActivity:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->isRouteTotalActivity()Z

    move-result v0

    if-eqz v0, :cond_6

    .line 616
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v0

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->is_support_scale()Z

    move-result v0

    if-eqz v0, :cond_8

    .line 617
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INaviScaleManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INaviScaleManager;

    move-result-object v0

    const/16 v5, 0x39

    invoke-virtual {v0, v5}, Lcom/thinkware/sundo/inavi3d/INaviScaleManager;->scaledPixelHeight(I)I

    move-result v0

    int-to-float v0, v0

    sub-float/2addr v8, v0

    .line 622
    :cond_6
    :goto_1
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v0

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetDeviceModelType()I

    move-result v0

    const/4 v5, 0x2

    if-eq v0, v5, :cond_7

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v0

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetDeviceModelType()I

    move-result v0

    const/4 v5, 0x3

    if-eq v0, v5, :cond_7

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v0

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetDeviceModelType()I

    move-result v0

    const/4 v5, 0x4

    if-eq v0, v5, :cond_7

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v0

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetDeviceModelType()I

    move-result v0

    const/4 v5, 0x5

    if-eq v0, v5, :cond_7

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v0

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetDeviceModelType()I

    move-result v0

    const/4 v5, 0x6

    if-eq v0, v5, :cond_7

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v0

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetDeviceModelType()I

    move-result v0

    const/4 v5, 0x7

    if-eq v0, v5, :cond_7

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v0

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetDeviceModelType()I

    move-result v0

    const/16 v5, 0x8

    if-eq v0, v5, :cond_7

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v0

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetDeviceModelType()I

    move-result v0

    const/16 v5, 0x9

    if-eq v0, v5, :cond_7

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v0

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->IsDAVINCIOrder()Z

    move-result v0

    const/4 v5, 0x1

    if-ne v0, v5, :cond_a

    .line 631
    :cond_7
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/DPView;->iNavi3DActivity:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->IsAvailableCompactAR()Z

    move-result v0

    const/4 v5, 0x1

    if-ne v0, v5, :cond_a

    .line 633
    const v0, 0x4419c000    # 615.0f

    cmpl-float v0, v7, v0

    if-lez v0, :cond_a

    .line 634
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/DPView;->iNavi3DActivity:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->hideZoomView()Z

    move-result v0

    const/4 v5, 0x1

    if-ne v0, v5, :cond_9

    .line 635
    invoke-super {p0, p1}, Landroid/opengl/GLSurfaceView;->onTouchEvent(Landroid/view/MotionEvent;)Z

    move-result v0

    goto/16 :goto_0

    .line 619
    :cond_8
    const/high16 v0, 0x42640000    # 57.0f

    sub-float/2addr v8, v0

    goto/16 :goto_1

    .line 636
    :cond_9
    sget v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_nPartitionMode:I

    if-nez v0, :cond_a

    .line 637
    invoke-super {p0, p1}, Landroid/opengl/GLSurfaceView;->onTouchEvent(Landroid/view/MotionEvent;)Z

    move-result v0

    goto/16 :goto_0

    .line 643
    :cond_a
    const-string v5, "touch"

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v9, "Single "

    invoke-virtual {v0, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v7}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v9, ","

    invoke-virtual {v0, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v8}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v9, " "

    invoke-virtual {v0, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getAction()I

    move-result v0

    if-nez v0, :cond_e

    const-string v0, "MotionEvent.ACTION_DOWN"

    :goto_2
    invoke-virtual {v9, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v5, v0}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 644
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getAction()I

    move-result v0

    if-nez v0, :cond_10

    .line 645
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/DPView;->iNavi3DActivity:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->isShownNIP()Z

    move-result v0

    if-eqz v0, :cond_b

    .line 647
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/DPView;->iNavi3DActivity:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->hideNIPHideButton()V

    .line 649
    :cond_b
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/DPView;->mValidDrag:Z

    .line 652
    if-nez v6, :cond_d

    .line 653
    sget-boolean v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_bOilRouteSearch:Z

    const/4 v5, 0x1

    if-ne v0, v5, :cond_c

    .line 654
    const/4 v0, 0x0

    sput-boolean v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_bOilRouteSearch:Z

    .line 655
    :cond_c
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/DPView;->mInavi:Lcom/thinkware/sundo/inavi3d/Inavi;

    sget v5, Lcom/thinkware/sundo/inavi3d/Inavi;->MULTI_BUTTONDOWN:I

    invoke-virtual {v0, v7, v8, v5}, Lcom/thinkware/sundo/inavi3d/Inavi;->onSingleButton(FFI)V

    .line 656
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/DPView;->iNavi3DActivity:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->hideRemoteFocus()V

    .line 745
    .end local v6    # "showDialog":Z
    .end local v7    # "x":F
    .end local v8    # "y":F
    :cond_d
    :goto_3
    const/4 v0, 0x1

    goto/16 :goto_0

    .line 643
    .restart local v6    # "showDialog":Z
    .restart local v7    # "x":F
    .restart local v8    # "y":F
    :cond_e
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getAction()I

    move-result v0

    const/4 v10, 0x2

    if-ne v0, v10, :cond_f

    const-string v0, "MotionEvent.ACTION_MOVE"

    goto :goto_2

    :cond_f
    const-string v0, "MotionEvent.ACTION_UP"

    goto :goto_2

    .line 659
    :cond_10
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getAction()I

    move-result v0

    const/4 v5, 0x2

    if-ne v0, v5, :cond_12

    .line 660
    if-nez v6, :cond_11

    .line 661
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/DPView;->mInavi:Lcom/thinkware/sundo/inavi3d/Inavi;

    sget v5, Lcom/thinkware/sundo/inavi3d/Inavi;->MULTI_BUTTONMOVE:I

    invoke-virtual {v0, v7, v8, v5}, Lcom/thinkware/sundo/inavi3d/Inavi;->onSingleButton(FFI)V

    .line 663
    :cond_11
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->getInstance()Lcom/thinkware/sundo/inavi3d/InaviConfig;

    move-result-object v0

    const/16 v5, 0xe1

    invoke-virtual {v0, v5}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->CNaviConfigGet(I)I

    move-result v0

    if-nez v0, :cond_d

    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/DPView;->mValidDrag:Z

    if-eqz v0, :cond_d

    .line 664
    invoke-super {p0, p1}, Landroid/opengl/GLSurfaceView;->onTouchEvent(Landroid/view/MotionEvent;)Z

    move-result v0

    goto/16 :goto_0

    .line 665
    :cond_12
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getAction()I

    move-result v0

    const/4 v5, 0x1

    if-ne v0, v5, :cond_d

    .line 666
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v0

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetDeviceModelType()I

    move-result v0

    const/4 v5, 0x2

    if-eq v0, v5, :cond_13

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v0

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetDeviceModelType()I

    move-result v0

    const/4 v5, 0x3

    if-eq v0, v5, :cond_13

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v0

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetDeviceModelType()I

    move-result v0

    const/4 v5, 0x4

    if-eq v0, v5, :cond_13

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v0

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetDeviceModelType()I

    move-result v0

    const/4 v5, 0x5

    if-eq v0, v5, :cond_13

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v0

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetDeviceModelType()I

    move-result v0

    const/4 v5, 0x6

    if-eq v0, v5, :cond_13

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v0

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetDeviceModelType()I

    move-result v0

    const/4 v5, 0x7

    if-eq v0, v5, :cond_13

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v0

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetDeviceModelType()I

    move-result v0

    const/16 v5, 0x8

    if-eq v0, v5, :cond_13

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v0

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetDeviceModelType()I

    move-result v0

    const/16 v5, 0x9

    if-eq v0, v5, :cond_13

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v0

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->IsDAVINCIOrder()Z

    move-result v0

    const/4 v5, 0x1

    if-ne v0, v5, :cond_14

    :cond_13
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/DPView;->iNavi3DActivity:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->isARMode()Z

    move-result v0

    const/4 v5, 0x1

    if-ne v0, v5, :cond_14

    sget-boolean v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->mbQuickMotion:Z

    if-nez v0, :cond_14

    .line 679
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/DPView;->iNavi3DActivity:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->isSimpleMapZoom()Z

    move-result v0

    if-nez v0, :cond_17

    .line 680
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/DPView;->iNavi3DActivity:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    const/4 v5, 0x0

    invoke-virtual {v0, v5}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->visibilityARModeButton(Z)V

    .line 695
    :cond_14
    :goto_4
    if-eqz v6, :cond_15

    .line 696
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/DPView;->iNavi3DActivity:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->DismissInaviDialog()V

    .line 698
    :cond_15
    if-nez v6, :cond_16

    .line 699
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/DPView;->mInavi:Lcom/thinkware/sundo/inavi3d/Inavi;

    sget v5, Lcom/thinkware/sundo/inavi3d/Inavi;->MULTI_BUTTONUP:I

    invoke-virtual {v0, v7, v8, v5}, Lcom/thinkware/sundo/inavi3d/Inavi;->onSingleButton(FFI)V

    .line 700
    :cond_16
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->getInstance()Lcom/thinkware/sundo/inavi3d/InaviConfig;

    move-result-object v0

    const/16 v5, 0xe1

    invoke-virtual {v0, v5}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->CNaviConfigGet(I)I

    move-result v0

    if-nez v0, :cond_d

    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/DPView;->mValidDrag:Z

    if-eqz v0, :cond_d

    .line 701
    invoke-super {p0, p1}, Landroid/opengl/GLSurfaceView;->onTouchEvent(Landroid/view/MotionEvent;)Z

    move-result v0

    goto/16 :goto_0

    .line 682
    :cond_17
    invoke-static {v7, v8}, Lcom/thinkware/sundo/inavi3d/Inavi;->CheckSimpleMapRect(FF)Z

    move-result v0

    if-nez v0, :cond_18

    .line 683
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/DPView;->iNavi3DActivity:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    const/4 v5, 0x0

    invoke-virtual {v0, v5}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->visibilityARModeButton(Z)V

    goto :goto_4

    .line 685
    :cond_18
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/Inavi;->IsSimpleMapZoom()Z

    move-result v0

    const/4 v5, 0x1

    if-ne v0, v5, :cond_19

    .line 686
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/DPView;->iNavi3DActivity:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    const/16 v5, 0xf

    invoke-virtual {v0, v5}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->ARSimpleMapZoomOutStartNew(I)V

    goto :goto_4

    .line 688
    :cond_19
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/DPView;->iNavi3DActivity:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    const/4 v5, 0x5

    invoke-virtual {v0, v5}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->ARSimpleMapZoomInStartNew(I)V

    goto :goto_4

    .line 705
    .end local v6    # "showDialog":Z
    .end local v7    # "x":F
    .end local v8    # "y":F
    :cond_1a
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getPointerCount()I

    move-result v0

    const/4 v5, 0x2

    if-ne v0, v5, :cond_d

    .line 706
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/DPView;->iNavi3DActivity:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->isSimulationMode()Z

    move-result v0

    if-eqz v0, :cond_1b

    .line 707
    const/4 v0, 0x1

    goto/16 :goto_0

    .line 708
    :cond_1b
    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/DPView;->mValidDrag:Z

    .line 709
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/DPView;->iNavi3DActivity:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    const/4 v5, 0x1

    invoke-virtual {v0, v5}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->QuickMotionReset(Z)V

    .line 711
    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getX(I)F

    move-result v1

    .line 712
    .local v1, "x1":F
    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getY(I)F

    move-result v2

    .line 714
    .local v2, "y1":F
    const/4 v0, 0x1

    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getX(I)F

    move-result v3

    .line 715
    .local v3, "x2":F
    const/4 v0, 0x1

    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getY(I)F

    move-result v4

    .line 717
    .local v4, "y2":F
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v0

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->is_support_scale()Z

    move-result v0

    if-eqz v0, :cond_1c

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v0

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->isWideDisplay()Z

    move-result v0

    if-nez v0, :cond_1c

    .line 718
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INaviScaleManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INaviScaleManager;

    move-result-object v0

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/inavi3d/INaviScaleManager;->scaleTouchX(F)F

    move-result v1

    .line 719
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INaviScaleManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INaviScaleManager;

    move-result-object v0

    invoke-virtual {v0, v3}, Lcom/thinkware/sundo/inavi3d/INaviScaleManager;->scaleTouchX(F)F

    move-result v3

    .line 720
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INaviScaleManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INaviScaleManager;

    move-result-object v0

    invoke-virtual {v0, v2}, Lcom/thinkware/sundo/inavi3d/INaviScaleManager;->scaleTouchY(F)F

    move-result v2

    .line 721
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INaviScaleManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INaviScaleManager;

    move-result-object v0

    invoke-virtual {v0, v4}, Lcom/thinkware/sundo/inavi3d/INaviScaleManager;->scaleTouchY(F)F

    move-result v4

    .line 724
    :cond_1c
    const-string v5, "touch"

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v9, "multi "

    invoke-virtual {v0, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v9, ","

    invoke-virtual {v0, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v9, "|"

    invoke-virtual {v0, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v9, ","

    invoke-virtual {v0, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v9, " "

    invoke-virtual {v0, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getAction()I

    move-result v0

    if-nez v0, :cond_1f

    const-string v0, "MotionEvent.ACTION_DOWN"

    :goto_5
    invoke-virtual {v9, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v5, v0}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 725
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getAction()I

    move-result v0

    const/16 v5, 0x105

    if-ne v0, v5, :cond_21

    .line 726
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/DPView;->iNavi3DActivity:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->isShownNIP()Z

    move-result v0

    if-eqz v0, :cond_1d

    .line 727
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/DPView;->iNavi3DActivity:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->hideNIP()V

    .line 729
    :cond_1d
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/DPView;->iNavi3DActivity:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->ResetQuickMuteCount()V

    .line 730
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/DPView;->mInavi:Lcom/thinkware/sundo/inavi3d/Inavi;

    sget v5, Lcom/thinkware/sundo/inavi3d/Inavi;->MULTI_BUTTONDOWN:I

    invoke-virtual/range {v0 .. v5}, Lcom/thinkware/sundo/inavi3d/Inavi;->onMultiButton(FFFFI)V

    .line 736
    :cond_1e
    :goto_6
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getAction()I

    move-result v0

    const/16 v5, 0x106

    if-ne v0, v5, :cond_d

    .line 738
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/DPView;->iNavi3DActivity:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->ResetQuickMuteCount()V

    .line 739
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/DPView;->mInavi:Lcom/thinkware/sundo/inavi3d/Inavi;

    sget v5, Lcom/thinkware/sundo/inavi3d/Inavi;->MULTI_BUTTONUP:I

    invoke-virtual/range {v0 .. v5}, Lcom/thinkware/sundo/inavi3d/Inavi;->onMultiButton(FFFFI)V

    goto/16 :goto_3

    .line 724
    :cond_1f
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getAction()I

    move-result v0

    const/4 v10, 0x2

    if-ne v0, v10, :cond_20

    const-string v0, "MotionEvent.ACTION_MOVE"

    goto :goto_5

    :cond_20
    const-string v0, "MotionEvent.ACTION_UP"

    goto :goto_5

    .line 732
    :cond_21
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getAction()I

    move-result v0

    const/4 v5, 0x2

    if-ne v0, v5, :cond_1e

    .line 733
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/DPView;->mInavi:Lcom/thinkware/sundo/inavi3d/Inavi;

    sget v5, Lcom/thinkware/sundo/inavi3d/Inavi;->MULTI_BUTTONMOVE:I

    invoke-virtual/range {v0 .. v5}, Lcom/thinkware/sundo/inavi3d/Inavi;->onMultiButton(FFFFI)V

    goto :goto_6
.end method

.method public setDRGPS(Z)V
    .locals 0
    .param p1, "enable"    # Z

    .prologue
    .line 309
    iput-boolean p1, p0, Lcom/thinkware/sundo/inavi3d/DPView;->mIsDRGPS:Z

    .line 310
    return-void
.end method

.method public setDisplay(Lcom/thinkware/sundo/inavi3d/Inavi;)V
    .locals 0
    .param p1, "inavi"    # Lcom/thinkware/sundo/inavi3d/Inavi;

    .prologue
    .line 136
    iput-object p1, p0, Lcom/thinkware/sundo/inavi3d/DPView;->mInavi:Lcom/thinkware/sundo/inavi3d/Inavi;

    .line 137
    return-void
.end method

.method public setIeve(Lcom/thinkware/sundo/ieve/IEVE;)V
    .locals 0
    .param p1, "ieve"    # Lcom/thinkware/sundo/ieve/IEVE;

    .prologue
    .line 140
    iput-object p1, p0, Lcom/thinkware/sundo/inavi3d/DPView;->mIeve:Lcom/thinkware/sundo/ieve/IEVE;

    .line 141
    return-void
.end method

.method public setInfosIEVE()V
    .locals 19

    .prologue
    .line 325
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/inavi3d/DPView;->mIeve:Lcom/thinkware/sundo/ieve/IEVE;

    if-eqz v2, :cond_0

    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/inavi3d/DPView;->mIeve:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-virtual {v2}, Lcom/thinkware/sundo/ieve/IEVE;->isInitialized()Z

    move-result v2

    if-eqz v2, :cond_0

    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/inavi3d/DPView;->mInavi:Lcom/thinkware/sundo/inavi3d/Inavi;

    if-nez v2, :cond_1

    .line 550
    :cond_0
    :goto_0
    return-void

    .line 329
    :cond_1
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/inavi3d/DPView;->mInavi:Lcom/thinkware/sundo/inavi3d/Inavi;

    invoke-virtual {v2}, Lcom/thinkware/sundo/inavi3d/Inavi;->isInitDone()Z

    move-result v2

    if-eqz v2, :cond_0

    .line 333
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/Inavi;->getTbtguide()Lcom/thinkware/sundo/remoteTBT/TBTGuide;

    move-result-object v17

    .line 334
    .local v17, "tbtGuide":Lcom/thinkware/sundo/remoteTBT/TBTGuide;
    if-eqz v17, :cond_0

    .line 338
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v2

    if-eqz v2, :cond_0

    .line 342
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v2

    invoke-virtual {v2}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->isSimul()Z

    move-result v2

    const/4 v3, 0x1

    if-ne v2, v3, :cond_6

    .line 343
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/inavi3d/DPView;->mIeve:Lcom/thinkware/sundo/ieve/IEVE;

    const/4 v3, 0x1

    invoke-virtual {v2, v3}, Lcom/thinkware/sundo/ieve/IEVE;->enableSimulationMode(Z)V

    .line 348
    :cond_2
    :goto_1
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/inavi3d/DPView;->mIeve:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-virtual {v2}, Lcom/thinkware/sundo/ieve/IEVE;->isSimulationMode()Z

    move-result v2

    const/4 v3, 0x1

    if-eq v2, v3, :cond_0

    .line 362
    const/4 v10, 0x0

    .line 363
    .local v10, "ieveSpeed":I
    const/16 v16, 0x0

    .line 365
    .local v16, "source":I
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v2

    invoke-virtual {v2}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->GetOBD2Connect()Z

    move-result v2

    const/4 v3, 0x1

    if-ne v2, v3, :cond_7

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v2

    invoke-virtual {v2}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->isSpeedUpdate()Z

    move-result v2

    const/4 v3, 0x1

    if-ne v2, v3, :cond_7

    .line 366
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v2

    invoke-virtual {v2}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getOBD2CurrentSpeed()F

    move-result v2

    float-to-int v10, v2

    .line 367
    mul-int/lit8 v10, v10, 0xa

    .line 368
    const/16 v16, 0x2

    .line 393
    :cond_3
    :goto_2
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/inavi3d/DPView;->mIeve:Lcom/thinkware/sundo/ieve/IEVE;

    move/from16 v0, v16

    invoke-virtual {v2, v10, v0}, Lcom/thinkware/sundo/ieve/IEVE;->setCarSpeedK(II)V

    .line 405
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/inavi3d/DPView;->mIeve:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-virtual {v2}, Lcom/thinkware/sundo/ieve/IEVE;->isInitializedAR()Z

    move-result v2

    const/4 v3, 0x1

    if-ne v2, v3, :cond_0

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    move-result-object v2

    invoke-virtual {v2}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getARCameraOn()Z

    move-result v2

    const/4 v3, 0x1

    if-ne v2, v3, :cond_0

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    move-result-object v2

    invoke-virtual {v2}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->isShowScreenMirroring()Z

    move-result v2

    if-nez v2, :cond_0

    .line 416
    sget v2, Lcom/thinkware/sundo/inavi3d/Inavi;->mCarPosX:F

    move-object/from16 v0, p0

    iput v2, v0, Lcom/thinkware/sundo/inavi3d/DPView;->mCarPosX:F

    .line 417
    sget v2, Lcom/thinkware/sundo/inavi3d/Inavi;->mCarPosY:F

    move-object/from16 v0, p0

    iput v2, v0, Lcom/thinkware/sundo/inavi3d/DPView;->mCarPosY:F

    .line 418
    sget v2, Lcom/thinkware/sundo/inavi3d/Inavi;->mCarPosZ:F

    move-object/from16 v0, p0

    iput v2, v0, Lcom/thinkware/sundo/inavi3d/DPView;->mCarPosZ:F

    .line 420
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/inavi3d/DPView;->mIeve:Lcom/thinkware/sundo/ieve/IEVE;

    sget v3, Lcom/thinkware/sundo/inavi3d/Inavi;->mCarAngleDir:F

    float-to-double v4, v3

    invoke-virtual {v2, v4, v5}, Lcom/thinkware/sundo/ieve/IEVE;->getAngleRegularFromGPS(D)D

    move-result-wide v2

    double-to-float v2, v2

    move-object/from16 v0, p0

    iput v2, v0, Lcom/thinkware/sundo/inavi3d/DPView;->mAngleDirDP:F

    .line 421
    const/4 v2, 0x0

    move-object/from16 v0, p0

    iput v2, v0, Lcom/thinkware/sundo/inavi3d/DPView;->mAngleVrtDP:F

    .line 423
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/inavi3d/DPView;->mIeve:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-virtual {v2}, Lcom/thinkware/sundo/ieve/IEVE;->getGuideInfos()Lcom/thinkware/sundo/ieve/ieveGuideInfos;

    move-result-object v2

    sput-object v2, Lcom/thinkware/sundo/inavi3d/DPView;->guideinfos:Lcom/thinkware/sundo/ieve/ieveGuideInfos;

    .line 424
    sget-object v2, Lcom/thinkware/sundo/inavi3d/DPView;->guideinfos:Lcom/thinkware/sundo/ieve/ieveGuideInfos;

    sget v3, Lcom/thinkware/sundo/inavi3d/Inavi;->mRoadAttribType:I

    iput v3, v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->roadattrib_roadtype:I

    .line 425
    sget-object v2, Lcom/thinkware/sundo/inavi3d/DPView;->guideinfos:Lcom/thinkware/sundo/ieve/ieveGuideInfos;

    sget v3, Lcom/thinkware/sundo/inavi3d/Inavi;->mRoadAttribSpec:I

    iput v3, v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->roadattrib_roadspec:I

    .line 426
    sget-object v2, Lcom/thinkware/sundo/inavi3d/DPView;->guideinfos:Lcom/thinkware/sundo/ieve/ieveGuideInfos;

    sget v3, Lcom/thinkware/sundo/inavi3d/Inavi;->mRoadAttribNumLane:I

    iput v3, v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->roadattrib_roadnumlane:I

    .line 428
    sget-object v2, Lcom/thinkware/sundo/inavi3d/DPView;->guideinfos:Lcom/thinkware/sundo/ieve/ieveGuideInfos;

    sget v3, Lcom/thinkware/sundo/inavi3d/Inavi;->mTurnPointX:I

    int-to-float v3, v3

    iput v3, v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->turnpoint_pos_x:F

    .line 429
    sget-object v2, Lcom/thinkware/sundo/inavi3d/DPView;->guideinfos:Lcom/thinkware/sundo/ieve/ieveGuideInfos;

    const/4 v3, 0x0

    iput v3, v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->turnpoint_pos_y:F

    .line 430
    sget-object v2, Lcom/thinkware/sundo/inavi3d/DPView;->guideinfos:Lcom/thinkware/sundo/ieve/ieveGuideInfos;

    sget v3, Lcom/thinkware/sundo/inavi3d/Inavi;->mTurnPointY:I

    int-to-float v3, v3

    iput v3, v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->turnpoint_pos_z:F

    .line 431
    sget-object v2, Lcom/thinkware/sundo/inavi3d/DPView;->guideinfos:Lcom/thinkware/sundo/ieve/ieveGuideInfos;

    sget v3, Lcom/thinkware/sundo/inavi3d/Inavi;->mTurnPointKind:I

    iput v3, v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->turnpoint_code:I

    .line 432
    sget-object v2, Lcom/thinkware/sundo/inavi3d/DPView;->guideinfos:Lcom/thinkware/sundo/ieve/ieveGuideInfos;

    sget v3, Lcom/thinkware/sundo/inavi3d/Inavi;->mTurnPointDist:I

    iput v3, v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->turnpoint_dist:I

    .line 433
    sget-object v2, Lcom/thinkware/sundo/inavi3d/DPView;->guideinfos:Lcom/thinkware/sundo/ieve/ieveGuideInfos;

    sget v3, Lcom/thinkware/sundo/inavi3d/Inavi;->mTurnPointPassedNumLane:I

    iput v3, v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->turnpoint_roadnumlane:I

    .line 435
    sget-object v2, Lcom/thinkware/sundo/inavi3d/DPView;->guideinfos:Lcom/thinkware/sundo/ieve/ieveGuideInfos;

    move-object/from16 v0, v17

    iget-char v3, v0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->camerakind:C

    iput v3, v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecamera_kind:I

    .line 436
    sget-object v2, Lcom/thinkware/sundo/inavi3d/DPView;->guideinfos:Lcom/thinkware/sundo/ieve/ieveGuideInfos;

    move-object/from16 v0, p0

    iget-object v3, v0, Lcom/thinkware/sundo/inavi3d/DPView;->mIeve:Lcom/thinkware/sundo/ieve/IEVE;

    sget v4, Lcom/thinkware/sundo/inavi3d/Inavi;->mSafeCameraPosrX:I

    invoke-virtual {v3, v4}, Lcom/thinkware/sundo/ieve/IEVE;->convertiNaviRegToFPoint3D_X(I)F

    move-result v3

    iput v3, v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecamera_pos_x:F

    .line 437
    sget-object v2, Lcom/thinkware/sundo/inavi3d/DPView;->guideinfos:Lcom/thinkware/sundo/ieve/ieveGuideInfos;

    const/4 v3, 0x0

    iput v3, v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecamera_pos_y:F

    .line 438
    sget-object v2, Lcom/thinkware/sundo/inavi3d/DPView;->guideinfos:Lcom/thinkware/sundo/ieve/ieveGuideInfos;

    move-object/from16 v0, p0

    iget-object v3, v0, Lcom/thinkware/sundo/inavi3d/DPView;->mIeve:Lcom/thinkware/sundo/ieve/IEVE;

    sget v4, Lcom/thinkware/sundo/inavi3d/Inavi;->mSafeCameraPosrY:I

    invoke-virtual {v3, v4}, Lcom/thinkware/sundo/ieve/IEVE;->convertiNaviRegToFPoint3D_Z(I)F

    move-result v3

    iput v3, v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecamera_pos_z:F

    .line 439
    sget-object v2, Lcom/thinkware/sundo/inavi3d/DPView;->guideinfos:Lcom/thinkware/sundo/ieve/ieveGuideInfos;

    move-object/from16 v0, v17

    iget v3, v0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->dist:I

    iput v3, v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecamera_dist:I

    .line 440
    sget-object v2, Lcom/thinkware/sundo/inavi3d/DPView;->guideinfos:Lcom/thinkware/sundo/ieve/ieveGuideInfos;

    move-object/from16 v0, v17

    iget v3, v0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->speedlimit:I

    iput v3, v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecamera_speedlimit:I

    .line 441
    sget-object v2, Lcom/thinkware/sundo/inavi3d/DPView;->guideinfos:Lcom/thinkware/sundo/ieve/ieveGuideInfos;

    move-object/from16 v0, v17

    iget v3, v0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->angle:I

    iput v3, v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecamera_angle:I

    .line 442
    sget-object v2, Lcom/thinkware/sundo/inavi3d/DPView;->guideinfos:Lcom/thinkware/sundo/ieve/ieveGuideInfos;

    sget v3, Lcom/thinkware/sundo/inavi3d/Inavi;->mSafecamera_leader:I

    iput v3, v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecamera_leader:I

    .line 443
    sget-object v2, Lcom/thinkware/sundo/inavi3d/DPView;->guideinfos:Lcom/thinkware/sundo/ieve/ieveGuideInfos;

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v3

    invoke-virtual {v3}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getShowSafeWarning()I

    move-result v3

    iput v3, v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecameraarea_isredbox:I

    .line 445
    sget-object v2, Lcom/thinkware/sundo/inavi3d/DPView;->guideinfos:Lcom/thinkware/sundo/ieve/ieveGuideInfos;

    sget v3, Lcom/thinkware/sundo/inavi3d/Inavi;->mSafeGuideKind:I

    iput v3, v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safeguide_kind:I

    .line 446
    sget-object v2, Lcom/thinkware/sundo/inavi3d/DPView;->guideinfos:Lcom/thinkware/sundo/ieve/ieveGuideInfos;

    move-object/from16 v0, p0

    iget-object v3, v0, Lcom/thinkware/sundo/inavi3d/DPView;->mIeve:Lcom/thinkware/sundo/ieve/IEVE;

    sget v4, Lcom/thinkware/sundo/inavi3d/Inavi;->mSafeGuidePosrX:I

    invoke-virtual {v3, v4}, Lcom/thinkware/sundo/ieve/IEVE;->convertiNaviRegToFPoint3D_X(I)F

    move-result v3

    iput v3, v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safeguide_pos_x:F

    .line 447
    sget-object v2, Lcom/thinkware/sundo/inavi3d/DPView;->guideinfos:Lcom/thinkware/sundo/ieve/ieveGuideInfos;

    const/4 v3, 0x0

    iput v3, v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safeguide_pos_y:F

    .line 448
    sget-object v2, Lcom/thinkware/sundo/inavi3d/DPView;->guideinfos:Lcom/thinkware/sundo/ieve/ieveGuideInfos;

    move-object/from16 v0, p0

    iget-object v3, v0, Lcom/thinkware/sundo/inavi3d/DPView;->mIeve:Lcom/thinkware/sundo/ieve/IEVE;

    sget v4, Lcom/thinkware/sundo/inavi3d/Inavi;->mSafeGuidePosrY:I

    invoke-virtual {v3, v4}, Lcom/thinkware/sundo/ieve/IEVE;->convertiNaviRegToFPoint3D_Z(I)F

    move-result v3

    iput v3, v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safeguide_pos_z:F

    .line 450
    sget-object v2, Lcom/thinkware/sundo/inavi3d/DPView;->guideinfos:Lcom/thinkware/sundo/ieve/ieveGuideInfos;

    move-object/from16 v0, v17

    iget v3, v0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->SpeedLimitZoneGuide_speed:I

    iput v3, v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->schoolzone_speed:I

    .line 451
    sget-object v2, Lcom/thinkware/sundo/inavi3d/DPView;->guideinfos:Lcom/thinkware/sundo/ieve/ieveGuideInfos;

    move-object/from16 v0, v17

    iget v3, v0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->SpeedLimitZoneGuide_len:I

    iput v3, v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->schoolzone_len:I

    .line 452
    sget-object v2, Lcom/thinkware/sundo/inavi3d/DPView;->guideinfos:Lcom/thinkware/sundo/ieve/ieveGuideInfos;

    move-object/from16 v0, v17

    iget v3, v0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->SpeedLimitZoneGuide_type:I

    iput v3, v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->schoolzone_type:I

    .line 453
    sget-object v2, Lcom/thinkware/sundo/inavi3d/DPView;->guideinfos:Lcom/thinkware/sundo/ieve/ieveGuideInfos;

    move-object/from16 v0, v17

    iget v3, v0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->SpeedLimitZoneGuide_status:I

    iput v3, v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->schoolzone_status:I

    .line 455
    sget-object v2, Lcom/thinkware/sundo/inavi3d/DPView;->guideinfos:Lcom/thinkware/sundo/ieve/ieveGuideInfos;

    move-object/from16 v0, v17

    iget v3, v0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->ConstructionGuide_speed:I

    iput v3, v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->constzone_speed:I

    .line 456
    sget-object v2, Lcom/thinkware/sundo/inavi3d/DPView;->guideinfos:Lcom/thinkware/sundo/ieve/ieveGuideInfos;

    move-object/from16 v0, v17

    iget v3, v0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->ConstructionGuide_len:I

    iput v3, v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->constzone_len:I

    .line 457
    sget-object v2, Lcom/thinkware/sundo/inavi3d/DPView;->guideinfos:Lcom/thinkware/sundo/ieve/ieveGuideInfos;

    move-object/from16 v0, v17

    iget v3, v0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->ConstructionGuide_type:I

    iput v3, v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->constzone_type:I

    .line 458
    sget-object v2, Lcom/thinkware/sundo/inavi3d/DPView;->guideinfos:Lcom/thinkware/sundo/ieve/ieveGuideInfos;

    move-object/from16 v0, v17

    iget v3, v0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->ConstructionGuide_status:I

    iput v3, v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->constzone_status:I

    .line 460
    sget-object v2, Lcom/thinkware/sundo/inavi3d/DPView;->guideinfos:Lcom/thinkware/sundo/ieve/ieveGuideInfos;

    sget v3, Lcom/thinkware/sundo/inavi3d/Inavi;->mInermediate_kind:I

    iput v3, v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->intermediate_kind:I

    .line 461
    sget-object v2, Lcom/thinkware/sundo/inavi3d/DPView;->guideinfos:Lcom/thinkware/sundo/ieve/ieveGuideInfos;

    sget v3, Lcom/thinkware/sundo/inavi3d/Inavi;->mInermediate_dist:I

    iput v3, v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->intermediate_dist:I

    .line 463
    sget-object v2, Lcom/thinkware/sundo/inavi3d/DPView;->guideinfos:Lcom/thinkware/sundo/ieve/ieveGuideInfos;

    move-object/from16 v0, v17

    iget-char v3, v0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->camerakind:C

    iput v3, v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecameraarea_kind:I

    .line 464
    sget-object v2, Lcom/thinkware/sundo/inavi3d/DPView;->guideinfos:Lcom/thinkware/sundo/ieve/ieveGuideInfos;

    move-object/from16 v0, v17

    iget v3, v0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->RemainDist:I

    iput v3, v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecameraarea_dist:I

    .line 465
    sget-object v2, Lcom/thinkware/sundo/inavi3d/DPView;->guideinfos:Lcom/thinkware/sundo/ieve/ieveGuideInfos;

    move-object/from16 v0, v17

    iget v3, v0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->speedlimit:I

    iput v3, v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecameraarea_speedlimit:I

    .line 466
    sget-object v2, Lcom/thinkware/sundo/inavi3d/DPView;->guideinfos:Lcom/thinkware/sundo/ieve/ieveGuideInfos;

    move-object/from16 v0, v17

    iget v3, v0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->camRecSpeed:I

    iput v3, v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecameraarea_speedrecom:I

    .line 467
    sget-object v2, Lcom/thinkware/sundo/inavi3d/DPView;->guideinfos:Lcom/thinkware/sundo/ieve/ieveGuideInfos;

    move-object/from16 v0, v17

    iget v3, v0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->pair_avrspeed:I

    iput v3, v2, Lcom/thinkware/sundo/ieve/ieveGuideInfos;->safecameraarea_speedavr:I

    .line 473
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/inavi3d/DPView;->mInavi:Lcom/thinkware/sundo/inavi3d/Inavi;

    invoke-virtual {v2}, Lcom/thinkware/sundo/inavi3d/Inavi;->IsEscapeRoute()Z

    move-result v11

    .line 475
    .local v11, "isEscapeRoute":Z
    const/4 v2, 0x1

    if-ne v11, v2, :cond_a

    .line 476
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/inavi3d/DPView;->mIeve:Lcom/thinkware/sundo/ieve/IEVE;

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-virtual {v2, v3, v4, v5}, Lcom/thinkware/sundo/ieve/IEVE;->setRouteLine([FIZ)V

    .line 496
    :goto_3
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/inavi3d/DPView;->mIeve:Lcom/thinkware/sundo/ieve/IEVE;

    sget-object v3, Lcom/thinkware/sundo/inavi3d/DPView;->guideinfos:Lcom/thinkware/sundo/ieve/ieveGuideInfos;

    invoke-virtual {v2, v3}, Lcom/thinkware/sundo/ieve/IEVE;->setGuideInfos(Lcom/thinkware/sundo/ieve/ieveGuideInfos;)V

    .line 499
    const/4 v8, 0x1

    .line 502
    .local v8, "isanimate_carangle":Z
    const/4 v2, 0x1

    if-eq v11, v2, :cond_4

    move-object/from16 v0, p0

    iget-boolean v2, v0, Lcom/thinkware/sundo/inavi3d/DPView;->mIsViewModeChanged:Z

    const/4 v3, 0x1

    if-ne v2, v3, :cond_5

    .line 503
    :cond_4
    const/4 v8, 0x0

    .line 504
    const/4 v2, 0x0

    move-object/from16 v0, p0

    iput-boolean v2, v0, Lcom/thinkware/sundo/inavi3d/DPView;->mIsViewModeChanged:Z

    .line 506
    :cond_5
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/inavi3d/DPView;->mIeve:Lcom/thinkware/sundo/ieve/IEVE;

    move-object/from16 v0, p0

    iget v3, v0, Lcom/thinkware/sundo/inavi3d/DPView;->mCarPosX:F

    move-object/from16 v0, p0

    iget v4, v0, Lcom/thinkware/sundo/inavi3d/DPView;->mCarPosY:F

    move-object/from16 v0, p0

    iget v5, v0, Lcom/thinkware/sundo/inavi3d/DPView;->mCarPosZ:F

    move-object/from16 v0, p0

    iget v6, v0, Lcom/thinkware/sundo/inavi3d/DPView;->mAngleDirDP:F

    move-object/from16 v0, p0

    iget v7, v0, Lcom/thinkware/sundo/inavi3d/DPView;->mAngleVrtDP:F

    invoke-virtual/range {v2 .. v8}, Lcom/thinkware/sundo/ieve/IEVE;->setCarControl(FFFFFZ)V

    goto/16 :goto_0

    .line 344
    .end local v8    # "isanimate_carangle":Z
    .end local v10    # "ieveSpeed":I
    .end local v11    # "isEscapeRoute":Z
    .end local v16    # "source":I
    :cond_6
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/inavi3d/DPView;->mIeve:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-virtual {v2}, Lcom/thinkware/sundo/ieve/IEVE;->isSimulationMode()Z

    move-result v2

    const/4 v3, 0x1

    if-ne v2, v3, :cond_2

    .line 345
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/inavi3d/DPView;->mIeve:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-virtual {v2}, Lcom/thinkware/sundo/ieve/IEVE;->getHandlerIeve()Landroid/os/Handler;

    move-result-object v9

    .line 346
    .local v9, "h":Landroid/os/Handler;
    const/16 v2, 0x776

    invoke-static {v9, v2}, Landroid/os/Message;->obtain(Landroid/os/Handler;I)Landroid/os/Message;

    move-result-object v2

    invoke-virtual {v9, v2}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto/16 :goto_1

    .line 370
    .end local v9    # "h":Landroid/os/Handler;
    .restart local v10    # "ieveSpeed":I
    .restart local v16    # "source":I
    :cond_7
    move-object/from16 v0, v17

    iget v13, v0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->mCurrentSpeed:I

    .line 371
    .local v13, "nCurrentSpeed":I
    sget v14, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->speed:I

    .line 372
    .local v14, "nMMCSpeed":I
    const/4 v2, 0x0

    invoke-static {v2}, Lcom/thinkware/sundo/inavi3d/Inavi;->GetGPSInfo(I)Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    move-result-object v2

    iget-short v10, v2, Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;->SpeedK:S

    .line 373
    const/16 v16, 0x0

    .line 377
    if-gtz v10, :cond_8

    if-lez v14, :cond_8

    .line 378
    mul-int/lit8 v10, v14, 0xa

    .line 381
    :cond_8
    if-gtz v10, :cond_9

    if-lez v13, :cond_9

    .line 382
    mul-int/lit8 v10, v13, 0xa

    .line 385
    :cond_9
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v2

    invoke-virtual {v2}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetUseDRConfig()Z

    move-result v2

    const/4 v3, 0x1

    if-ne v2, v3, :cond_3

    .line 386
    sget v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->nDRMisenShow:I

    if-eqz v2, :cond_3

    .line 387
    const/16 v16, 0x1

    goto/16 :goto_2

    .line 478
    .end local v13    # "nCurrentSpeed":I
    .end local v14    # "nMMCSpeed":I
    .restart local v11    # "isEscapeRoute":Z
    :cond_a
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/inavi3d/DPView;->mInavi:Lcom/thinkware/sundo/inavi3d/Inavi;

    invoke-virtual {v2}, Lcom/thinkware/sundo/inavi3d/Inavi;->GetRouteLineVerteces()[F

    move-result-object v18

    .line 479
    .local v18, "vertices":[F
    const/4 v15, 0x0

    .line 481
    .local v15, "numVertices":I
    if-eqz v18, :cond_c

    .line 482
    move-object/from16 v0, v18

    array-length v12, v0

    .line 483
    .local v12, "length":I
    div-int/lit8 v15, v12, 0x3

    .line 484
    if-lez v15, :cond_b

    .line 485
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/inavi3d/DPView;->mIeve:Lcom/thinkware/sundo/ieve/IEVE;

    const/4 v3, 0x0

    move-object/from16 v0, v18

    invoke-virtual {v2, v0, v15, v3}, Lcom/thinkware/sundo/ieve/IEVE;->setRouteLine([FIZ)V

    .line 489
    :goto_4
    const/16 v18, 0x0

    .line 490
    goto/16 :goto_3

    .line 487
    :cond_b
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/inavi3d/DPView;->mIeve:Lcom/thinkware/sundo/ieve/IEVE;

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-virtual {v2, v3, v4, v5}, Lcom/thinkware/sundo/ieve/IEVE;->setRouteLine([FIZ)V

    goto :goto_4

    .line 491
    .end local v12    # "length":I
    :cond_c
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/inavi3d/DPView;->mIeve:Lcom/thinkware/sundo/ieve/IEVE;

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-virtual {v2, v3, v4, v5}, Lcom/thinkware/sundo/ieve/IEVE;->setRouteLine([FIZ)V

    goto/16 :goto_3
.end method

.method public setScaleFixed()V
    .locals 3

    .prologue
    .line 749
    sget-object v0, Lcom/thinkware/sundo/inavi3d/DPView;->mHolder:Landroid/view/SurfaceHolder;

    if-eqz v0, :cond_0

    .line 750
    sget-object v0, Lcom/thinkware/sundo/inavi3d/DPView;->mHolder:Landroid/view/SurfaceHolder;

    const/16 v1, 0x400

    const/16 v2, 0x258

    invoke-interface {v0, v1, v2}, Landroid/view/SurfaceHolder;->setFixedSize(II)V

    .line 752
    :cond_0
    return-void
.end method

.method public setViewModeChanged()V
    .locals 1

    .prologue
    .line 313
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/DPView;->mIsViewModeChanged:Z

    .line 314
    return-void
.end method

.method public surfaceChanged(Landroid/view/SurfaceHolder;III)V
    .locals 8
    .param p1, "holder"    # Landroid/view/SurfaceHolder;
    .param p2, "format"    # I
    .param p3, "w"    # I
    .param p4, "h"    # I

    .prologue
    .line 145
    const-string v2, "startCheck"

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "surfaceChanged - start : "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v4

    sget-wide v6, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->INAVISTARTTIME:J

    sub-long/2addr v4, v6

    invoke-virtual {v3, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Lcom/thinkware/sundo/inavi3d/LOGTW;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 146
    sget-object v2, Lcom/thinkware/sundo/inavi3d/DPView;->TAG:Ljava/lang/String;

    const-string v3, "[JAVA. DPView] surfaceChanged"

    invoke-static {v2, v3}, Lcom/thinkware/sundo/inavi3d/LOGTW;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 147
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v0

    .line 148
    .local v0, "nStartTime":J
    invoke-super {p0, p1, p2, p3, p4}, Landroid/opengl/GLSurfaceView;->surfaceChanged(Landroid/view/SurfaceHolder;III)V

    .line 149
    const/4 v2, 0x1

    sput-boolean v2, Lcom/thinkware/sundo/inavi3d/DPView;->mIsSurfaceRunning:Z

    .line 150
    const-string v2, "onDrawFrame"

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "surfaceChanged: "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v4

    sub-long/2addr v4, v0

    invoke-virtual {v3, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Lcom/thinkware/sundo/inavi3d/LOGTW;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 151
    const-string v2, "startCheck"

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "surfaceChanged - end : "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v4

    sget-wide v6, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->INAVISTARTTIME:J

    sub-long/2addr v4, v6

    invoke-virtual {v3, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Lcom/thinkware/sundo/inavi3d/LOGTW;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 152
    return-void
.end method

.method public surfaceCreated(Landroid/view/SurfaceHolder;)V
    .locals 11
    .param p1, "holder"    # Landroid/view/SurfaceHolder;

    .prologue
    const/4 v10, 0x0

    .line 158
    const-string v4, "inavi3d_testlog"

    const-string v5, "surfaceCreated"

    invoke-static {v4, v5}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 159
    sget-object v4, Lcom/thinkware/sundo/inavi3d/DPView;->TAG:Ljava/lang/String;

    const-string v5, "[JAVA. DPView] surfaceCreated"

    invoke-static {v4, v5}, Lcom/thinkware/sundo/inavi3d/LOGTW;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 160
    const-string v4, "startCheck"

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "surfaceCreated - start : "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v6

    sget-wide v8, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->INAVISTARTTIME:J

    sub-long/2addr v6, v8

    invoke-virtual {v5, v6, v7}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-static {v4, v5}, Lcom/thinkware/sundo/inavi3d/LOGTW;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 161
    iget v4, p0, Lcom/thinkware/sundo/inavi3d/DPView;->surfaceCreatedCount:I

    add-int/lit8 v4, v4, 0x1

    iput v4, p0, Lcom/thinkware/sundo/inavi3d/DPView;->surfaceCreatedCount:I

    .line 162
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v2

    .line 165
    .local v2, "nStartTime":J
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    move-result-object v4

    invoke-virtual {v4}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getActivityCount()I

    move-result v0

    .line 166
    .local v0, "activityCount":I
    if-lez v0, :cond_0

    .line 167
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    move-result-object v4

    add-int/lit8 v5, v0, -0x1

    invoke-virtual {v4, v5}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getActivityName(I)Ljava/lang/String;

    move-result-object v1

    .line 168
    .local v1, "showActivityName":Ljava/lang/String;
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    move-result-object v4

    invoke-virtual {v4}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getMainClassName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_0

    .line 192
    .end local v1    # "showActivityName":Ljava/lang/String;
    :goto_0
    return-void

    .line 182
    :cond_0
    const-string v4, "inavi3d_FL"

    const-string v5, "NATIVE_UIMESSAGE_DP_SETROUTELINE 1"

    invoke-static {v4, v5}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 184
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/DPView;->iNavi3DActivity:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    if-eqz v4, :cond_1

    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/DPView;->iNavi3DActivity:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    invoke-virtual {v4}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInavi()Lcom/thinkware/sundo/inavi3d/Inavi;

    move-result-object v4

    if-eqz v4, :cond_1

    .line 185
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/DPView;->iNavi3DActivity:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    invoke-virtual {v4}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInavi()Lcom/thinkware/sundo/inavi3d/Inavi;

    move-result-object v4

    const v5, 0x222e0

    const v6, 0x22470

    invoke-virtual {v4, v5, v6, v10, v10}, Lcom/thinkware/sundo/inavi3d/Inavi;->PushMessage(IIII)V

    .line 188
    :cond_1
    const/4 v4, 0x1

    iput-boolean v4, p0, Lcom/thinkware/sundo/inavi3d/DPView;->isSurfaceCreated:Z

    .line 189
    invoke-super {p0, p1}, Landroid/opengl/GLSurfaceView;->surfaceCreated(Landroid/view/SurfaceHolder;)V

    .line 190
    const-string v4, "onDrawFrame"

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "surfaceCreated: "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v6

    sub-long/2addr v6, v2

    invoke-virtual {v5, v6, v7}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-static {v4, v5}, Lcom/thinkware/sundo/inavi3d/LOGTW;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 191
    const-string v4, "startCheck"

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "surfaceCreated - end : "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v6

    sget-wide v8, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->INAVISTARTTIME:J

    sub-long/2addr v6, v8

    invoke-virtual {v5, v6, v7}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-static {v4, v5}, Lcom/thinkware/sundo/inavi3d/LOGTW;->d(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_0
.end method

.method public surfaceDestroyed(Landroid/view/SurfaceHolder;)V
    .locals 3
    .param p1, "holder"    # Landroid/view/SurfaceHolder;

    .prologue
    const/4 v2, 0x0

    .line 197
    const-string v0, "inavi3d_testlog"

    const-string v1, "surfaceDestroyed"

    invoke-static {v0, v1}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 198
    sget-object v0, Lcom/thinkware/sundo/inavi3d/DPView;->TAG:Ljava/lang/String;

    const-string v1, "[JAVA. DPView] surfaceDestroyed"

    invoke-static {v0, v1}, Lcom/thinkware/sundo/inavi3d/LOGTW;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 200
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/DPView;->isSurfaceCreated:Z

    if-nez v0, :cond_0

    .line 207
    :goto_0
    return-void

    .line 203
    :cond_0
    iput-boolean v2, p0, Lcom/thinkware/sundo/inavi3d/DPView;->isSurfaceCreated:Z

    .line 204
    sput-boolean v2, Lcom/thinkware/sundo/inavi3d/DPView;->mIsSurfaceRunning:Z

    .line 205
    invoke-super {p0, p1}, Landroid/opengl/GLSurfaceView;->surfaceDestroyed(Landroid/view/SurfaceHolder;)V

    .line 206
    sget v0, Lcom/thinkware/sundo/inavi3d/DPView;->surfaceDestroyedCount:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lcom/thinkware/sundo/inavi3d/DPView;->surfaceDestroyedCount:I

    goto :goto_0
.end method
