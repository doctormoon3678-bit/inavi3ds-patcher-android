.class public interface abstract Ltas/util/backlight/KBacklight$PowerObserver;
.super Ljava/lang/Object;
.source "KBacklight.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltas/util/backlight/KBacklight;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "PowerObserver"
.end annotation


# virtual methods
.method public abstract onKBacklightPowerKeyPressed(II)V
.end method
