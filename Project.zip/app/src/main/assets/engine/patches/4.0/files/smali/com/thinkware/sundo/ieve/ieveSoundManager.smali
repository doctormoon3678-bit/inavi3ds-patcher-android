.class public Lcom/thinkware/sundo/ieve/ieveSoundManager;
.super Ljava/lang/Object;
.source "ieveSoundManager.java"


# static fields
.field public static final INAVI_STREAM:I = 0x1

.field public static final INAVI_STREAM_MUSIC:I = 0x3

.field public static final INAVI_STREAM_NOTIFICATION:I = 0x5

.field public static final INAVI_STREAM_RING:I = 0x2

.field public static final INAVI_STREAM_TYPE:I = 0xa

.field private static final a:Ljava/lang/String;


# instance fields
.field private b:Landroid/content/Context;

.field private c:Landroid/media/AudioManager;

.field private d:Landroid/media/SoundPool;

.field private e:Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap",
            "<",
            "Ljava/lang/Integer;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private f:I


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .prologue
    .line 12
    const-class v0, Lcom/thinkware/sundo/ieve/ieveSoundManager;

    invoke-virtual {v0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/thinkware/sundo/ieve/ieveSoundManager;->a:Ljava/lang/String;

    .line 19
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;I)V
    .locals 5
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "streamtype"    # I
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "UseSparseArrays",
            "InlinedApi"
        }
    .end annotation

    .prologue
    const/4 v1, 0x0

    const/4 v4, 0x0

    .line 29
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 13
    iput-object v1, p0, Lcom/thinkware/sundo/ieve/ieveSoundManager;->b:Landroid/content/Context;

    .line 21
    iput-object v1, p0, Lcom/thinkware/sundo/ieve/ieveSoundManager;->c:Landroid/media/AudioManager;

    .line 22
    iput-object v1, p0, Lcom/thinkware/sundo/ieve/ieveSoundManager;->d:Landroid/media/SoundPool;

    .line 23
    iput-object v1, p0, Lcom/thinkware/sundo/ieve/ieveSoundManager;->e:Ljava/util/HashMap;

    .line 24
    const/4 v1, 0x5

    iput v1, p0, Lcom/thinkware/sundo/ieve/ieveSoundManager;->f:I

    .line 30
    sget-object v1, Lcom/thinkware/sundo/ieve/ieveSoundManager;->a:Ljava/lang/String;

    const-string v2, "Constructor"

    invoke-static {v1, v2}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 31
    iput-object p1, p0, Lcom/thinkware/sundo/ieve/ieveSoundManager;->b:Landroid/content/Context;

    .line 33
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/ieveSoundManager;->b:Landroid/content/Context;

    if-nez v1, :cond_1

    .line 34
    const-string v1, "Context is null!"

    new-array v2, v4, [Ljava/lang/Object;

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    .line 35
    .local v0, "text":Ljava/lang/String;
    sget-object v1, Lcom/thinkware/sundo/ieve/ieveSoundManager;->a:Ljava/lang/String;

    invoke-static {v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 63
    .end local v0    # "text":Ljava/lang/String;
    :cond_0
    :goto_0
    return-void

    .line 38
    :cond_1
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/ieveSoundManager;->b:Landroid/content/Context;

    const-string v2, "audio"

    invoke-virtual {v1, v2}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/media/AudioManager;

    iput-object v1, p0, Lcom/thinkware/sundo/ieve/ieveSoundManager;->c:Landroid/media/AudioManager;

    .line 39
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/ieveSoundManager;->c:Landroid/media/AudioManager;

    if-nez v1, :cond_2

    .line 40
    const-string v1, "mAudioManager is null!"

    new-array v2, v4, [Ljava/lang/Object;

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    .line 41
    .restart local v0    # "text":Ljava/lang/String;
    sget-object v1, Lcom/thinkware/sundo/ieve/ieveSoundManager;->a:Ljava/lang/String;

    invoke-static {v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 43
    .end local v0    # "text":Ljava/lang/String;
    :cond_2
    iput p2, p0, Lcom/thinkware/sundo/ieve/ieveSoundManager;->f:I

    .line 44
    new-instance v1, Ljava/util/HashMap;

    invoke-direct {v1}, Ljava/util/HashMap;-><init>()V

    iput-object v1, p0, Lcom/thinkware/sundo/ieve/ieveSoundManager;->e:Ljava/util/HashMap;

    .line 45
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/ieveSoundManager;->e:Ljava/util/HashMap;

    if-nez v1, :cond_3

    .line 46
    const-string v1, "mSoundPoolList is null!"

    new-array v2, v4, [Ljava/lang/Object;

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    .line 47
    .restart local v0    # "text":Ljava/lang/String;
    sget-object v1, Lcom/thinkware/sundo/ieve/ieveSoundManager;->a:Ljava/lang/String;

    invoke-static {v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 57
    .end local v0    # "text":Ljava/lang/String;
    :cond_3
    new-instance v1, Landroid/media/SoundPool;

    const/4 v2, 0x4

    iget v3, p0, Lcom/thinkware/sundo/ieve/ieveSoundManager;->f:I

    invoke-direct {v1, v2, v3, v4}, Landroid/media/SoundPool;-><init>(III)V

    iput-object v1, p0, Lcom/thinkware/sundo/ieve/ieveSoundManager;->d:Landroid/media/SoundPool;

    .line 59
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/ieveSoundManager;->d:Landroid/media/SoundPool;

    if-nez v1, :cond_0

    .line 60
    const-string v1, "mSoundPool is null!"

    new-array v2, v4, [Ljava/lang/Object;

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    .line 61
    .restart local v0    # "text":Ljava/lang/String;
    sget-object v1, Lcom/thinkware/sundo/ieve/ieveSoundManager;->a:Ljava/lang/String;

    invoke-static {v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0
.end method

.method static synthetic a(Lcom/thinkware/sundo/ieve/ieveSoundManager;)Landroid/media/SoundPool;
    .locals 1

    .prologue
    .line 22
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveSoundManager;->d:Landroid/media/SoundPool;

    return-object v0
.end method

.method static synthetic a()Ljava/lang/String;
    .locals 1

    .prologue
    .line 12
    sget-object v0, Lcom/thinkware/sundo/ieve/ieveSoundManager;->a:Ljava/lang/String;

    return-object v0
.end method

.method static synthetic b(Lcom/thinkware/sundo/ieve/ieveSoundManager;)Ljava/util/HashMap;
    .locals 1

    .prologue
    .line 23
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveSoundManager;->e:Ljava/util/HashMap;

    return-object v0
.end method

.method static synthetic c(Lcom/thinkware/sundo/ieve/ieveSoundManager;)Landroid/content/Context;
    .locals 1

    .prologue
    .line 13
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveSoundManager;->b:Landroid/content/Context;

    return-object v0
.end method


# virtual methods
.method public addSound(II)Z
    .locals 6
    .param p1, "index"    # I
    .param p2, "rawid"    # I

    .prologue
    const/4 v1, 0x1

    const/4 v0, 0x0

    .line 66
    iget-object v2, p0, Lcom/thinkware/sundo/ieve/ieveSoundManager;->e:Ljava/util/HashMap;

    if-nez v2, :cond_0

    .line 89
    :goto_0
    return v0

    .line 67
    :cond_0
    if-nez p2, :cond_1

    .line 68
    sget-object v1, Lcom/thinkware/sundo/ieve/ieveSoundManager;->a:Ljava/lang/String;

    const-string v2, "addSound[Error]: rawid is 0"

    new-array v3, v0, [Ljava/lang/Object;

    invoke-static {v2, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    .line 71
    :cond_1
    iget-object v2, p0, Lcom/thinkware/sundo/ieve/ieveSoundManager;->e:Ljava/util/HashMap;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_2

    .line 72
    sget-object v2, Lcom/thinkware/sundo/ieve/ieveSoundManager;->a:Ljava/lang/String;

    const-string v3, "addSound[Already]: index[%d]"

    new-array v4, v1, [Ljava/lang/Object;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    aput-object v5, v4, v0

    invoke-static {v3, v4}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v2, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    move v0, v1

    .line 73
    goto :goto_0

    .line 75
    :cond_2
    new-instance v0, Ljava/lang/Thread;

    new-instance v2, Lcom/thinkware/sundo/ieve/ieveSoundManager$1;

    invoke-direct {v2, p0, p2, p1}, Lcom/thinkware/sundo/ieve/ieveSoundManager$1;-><init>(Lcom/thinkware/sundo/ieve/ieveSoundManager;II)V

    invoke-direct {v0, v2}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    .line 88
    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    move v0, v1

    .line 89
    goto :goto_0
.end method

.method public destroy()V
    .locals 6

    .prologue
    const/4 v5, 0x0

    .line 93
    sget-object v2, Lcom/thinkware/sundo/ieve/ieveSoundManager;->a:Ljava/lang/String;

    const-string v3, "destroy"

    invoke-static {v2, v3}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 94
    iget-object v2, p0, Lcom/thinkware/sundo/ieve/ieveSoundManager;->d:Landroid/media/SoundPool;

    if-nez v2, :cond_1

    .line 105
    :cond_0
    :goto_0
    return-void

    .line 95
    :cond_1
    iget-object v2, p0, Lcom/thinkware/sundo/ieve/ieveSoundManager;->e:Ljava/util/HashMap;

    if-eqz v2, :cond_0

    .line 96
    iget-object v2, p0, Lcom/thinkware/sundo/ieve/ieveSoundManager;->e:Ljava/util/HashMap;

    invoke-virtual {v2}, Ljava/util/HashMap;->keySet()Ljava/util/Set;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :cond_2
    :goto_1
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-nez v2, :cond_3

    .line 100
    iget-object v2, p0, Lcom/thinkware/sundo/ieve/ieveSoundManager;->d:Landroid/media/SoundPool;

    invoke-virtual {v2}, Landroid/media/SoundPool;->release()V

    .line 101
    iput-object v5, p0, Lcom/thinkware/sundo/ieve/ieveSoundManager;->d:Landroid/media/SoundPool;

    .line 102
    invoke-virtual {p0}, Lcom/thinkware/sundo/ieve/ieveSoundManager;->removeAllSound()V

    .line 103
    iput-object v5, p0, Lcom/thinkware/sundo/ieve/ieveSoundManager;->e:Ljava/util/HashMap;

    .line 104
    iput-object v5, p0, Lcom/thinkware/sundo/ieve/ieveSoundManager;->c:Landroid/media/AudioManager;

    goto :goto_0

    .line 96
    :cond_3
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Integer;

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v0

    .line 97
    .local v0, "i":I
    iget-object v2, p0, Lcom/thinkware/sundo/ieve/ieveSoundManager;->e:Ljava/util/HashMap;

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-virtual {v2, v4}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Integer;

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v1

    .line 98
    .local v1, "soundid":I
    if-lez v1, :cond_2

    iget-object v2, p0, Lcom/thinkware/sundo/ieve/ieveSoundManager;->d:Landroid/media/SoundPool;

    invoke-virtual {v2, v1}, Landroid/media/SoundPool;->unload(I)Z

    goto :goto_1
.end method

.method public getSoundMaxVolume()I
    .locals 2

    .prologue
    .line 108
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveSoundManager;->c:Landroid/media/AudioManager;

    if-nez v0, :cond_0

    const/16 v0, 0xf

    .line 109
    :goto_0
    return v0

    :cond_0
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveSoundManager;->c:Landroid/media/AudioManager;

    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveSoundManager;->f:I

    invoke-virtual {v0, v1}, Landroid/media/AudioManager;->getStreamMaxVolume(I)I

    move-result v0

    goto :goto_0
.end method

.method public getSoundVolume()I
    .locals 2

    .prologue
    .line 113
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveSoundManager;->c:Landroid/media/AudioManager;

    if-nez v0, :cond_0

    const/4 v0, 0x0

    .line 114
    :goto_0
    return v0

    :cond_0
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveSoundManager;->c:Landroid/media/AudioManager;

    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveSoundManager;->f:I

    invoke-virtual {v0, v1}, Landroid/media/AudioManager;->getStreamVolume(I)I

    move-result v0

    goto :goto_0
.end method

.method public playSound(IZZZ)V
    .locals 6
    .param p1, "index"    # I
    .param p2, "onleft"    # Z
    .param p3, "onright"    # Z
    .param p4, "loop"    # Z

    .prologue
    .line 118
    const/high16 v5, 0x3f800000    # 1.0f

    move-object v0, p0

    move v1, p1

    move v2, p2

    move v3, p3

    move v4, p4

    invoke-virtual/range {v0 .. v5}, Lcom/thinkware/sundo/ieve/ieveSoundManager;->playSound(IZZZF)V

    .line 119
    return-void
.end method

.method public playSound(IZZZF)V
    .locals 10
    .param p1, "index"    # I
    .param p2, "onleft"    # Z
    .param p3, "onright"    # Z
    .param p4, "loop"    # Z
    .param p5, "percent"    # F

    .prologue
    const/high16 v6, 0x3f800000    # 1.0f

    const/4 v9, 0x1

    const/4 v3, 0x0

    const/4 v5, 0x0

    .line 122
    if-gez p1, :cond_1

    .line 123
    sget-object v0, Lcom/thinkware/sundo/ieve/ieveSoundManager;->a:Ljava/lang/String;

    const-string v2, "playSound: index[%d]"

    new-array v3, v9, [Ljava/lang/Object;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    aput-object v4, v3, v5

    invoke-static {v2, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 142
    :cond_0
    :goto_0
    return-void

    .line 126
    :cond_1
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveSoundManager;->c:Landroid/media/AudioManager;

    if-eqz v0, :cond_0

    .line 127
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveSoundManager;->d:Landroid/media/SoundPool;

    if-eqz v0, :cond_0

    .line 128
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveSoundManager;->e:Ljava/util/HashMap;

    if-eqz v0, :cond_0

    .line 129
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveSoundManager;->e:Ljava/util/HashMap;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_2

    .line 130
    sget-object v0, Lcom/thinkware/sundo/ieve/ieveSoundManager;->a:Ljava/lang/String;

    const-string v2, "playSound: Invalid containsKey[%d]"

    new-array v3, v9, [Ljava/lang/Object;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    aput-object v4, v3, v5

    invoke-static {v2, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    .line 133
    :cond_2
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveSoundManager;->e:Ljava/util/HashMap;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v1

    .line 134
    .local v1, "soundid":I
    sget-object v0, Lcom/thinkware/sundo/ieve/ieveSoundManager;->a:Ljava/lang/String;

    const-string v2, "playSound: index[%d],soundid[%d],getlevel[%d],maxlevel[%d]"

    const/4 v4, 0x4

    new-array v4, v4, [Ljava/lang/Object;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    aput-object v8, v4, v5

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    aput-object v8, v4, v9

    const/4 v8, 0x2

    invoke-virtual {p0}, Lcom/thinkware/sundo/ieve/ieveSoundManager;->getSoundVolume()I

    move-result v9

    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    aput-object v9, v4, v8

    const/4 v8, 0x3

    invoke-virtual {p0}, Lcom/thinkware/sundo/ieve/ieveSoundManager;->getSoundMaxVolume()I

    move-result v9

    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    aput-object v9, v4, v8

    invoke-static {v2, v4}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v2}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 135
    if-lez v1, :cond_0

    .line 136
    invoke-virtual {p0}, Lcom/thinkware/sundo/ieve/ieveSoundManager;->getSoundVolume()I

    move-result v0

    int-to-float v0, v0

    invoke-virtual {p0}, Lcom/thinkware/sundo/ieve/ieveSoundManager;->getSoundMaxVolume()I

    move-result v2

    int-to-float v2, v2

    div-float v7, v0, v2

    .line 137
    .local v7, "fvolume":F
    cmpg-float v0, v7, v3

    if-gez v0, :cond_6

    const/4 v7, 0x0

    .line 139
    :cond_3
    :goto_1
    mul-float/2addr v7, p5

    .line 140
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveSoundManager;->d:Landroid/media/SoundPool;

    if-eqz p2, :cond_7

    move v2, v7

    :goto_2
    if-eqz p3, :cond_4

    move v3, v7

    :cond_4
    if-eqz p4, :cond_5

    const/4 v5, -0x1

    :cond_5
    move v4, p1

    invoke-virtual/range {v0 .. v6}, Landroid/media/SoundPool;->play(IFFIIF)I

    goto/16 :goto_0

    .line 138
    :cond_6
    cmpl-float v0, v7, v6

    if-lez v0, :cond_3

    const/high16 v7, 0x3f800000    # 1.0f

    goto :goto_1

    :cond_7
    move v2, v3

    .line 140
    goto :goto_2
.end method

.method public removeAllSound()V
    .locals 2

    .prologue
    .line 145
    sget-object v0, Lcom/thinkware/sundo/ieve/ieveSoundManager;->a:Ljava/lang/String;

    const-string v1, "removeAllSound"

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 146
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveSoundManager;->e:Ljava/util/HashMap;

    if-nez v0, :cond_0

    .line 148
    :goto_0
    return-void

    .line 147
    :cond_0
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveSoundManager;->e:Ljava/util/HashMap;

    invoke-virtual {v0}, Ljava/util/HashMap;->clear()V

    goto :goto_0
.end method

.method public removeSound(I)V
    .locals 5
    .param p1, "index"    # I

    .prologue
    .line 151
    sget-object v0, Lcom/thinkware/sundo/ieve/ieveSoundManager;->a:Ljava/lang/String;

    const-string v1, "removeSound[%d]"

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    aput-object v4, v2, v3

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 152
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveSoundManager;->e:Ljava/util/HashMap;

    if-nez v0, :cond_0

    .line 154
    :goto_0
    return-void

    .line 153
    :cond_0
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveSoundManager;->e:Ljava/util/HashMap;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_0
.end method

.method public setSoundVolume(I)V
    .locals 8
    .param p1, "volume"    # I

    .prologue
    const/4 v4, 0x0

    .line 157
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveSoundManager;->c:Landroid/media/AudioManager;

    if-nez v0, :cond_0

    .line 162
    return-void

    .line 158
    :cond_0
    if-gez p1, :cond_1

    const/4 p1, 0x0

    :cond_1
    const/16 v5, 0x28

    if-le p1, v5, :cond_2

    move p1, v5

    .line 159
    :cond_2
    invoke-virtual {p0}, Lcom/thinkware/sundo/ieve/ieveSoundManager;->getSoundMaxVolume()I

    move-result v6

    mul-int v7, p1, v6

    add-int/lit8 v7, v7, 0x14

    div-int/lit8 v7, v7, 0x28

    if-gez v7, :cond_3

    const/4 v7, 0x0

    :cond_3
    if-le v7, v6, :cond_4

    move v7, v6

    .line 160
    :cond_4
    sget-object v0, Lcom/thinkware/sundo/ieve/ieveSoundManager;->a:Ljava/lang/String;

    const-string v1, "setSoundVolume[%d]"

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    aput-object v3, v2, v4

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 161
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveSoundManager;->c:Landroid/media/AudioManager;

    iget v1, p0, Lcom/thinkware/sundo/ieve/ieveSoundManager;->f:I

    invoke-virtual {v0, v1, v7, v4}, Landroid/media/AudioManager;->setStreamVolume(III)V

    return-void
.end method

.method public stopSound(I)V
    .locals 6
    .param p1, "index"    # I

    .prologue
    const/4 v3, 0x1

    const/4 v5, 0x0

    .line 165
    if-gez p1, :cond_1

    .line 166
    sget-object v1, Lcom/thinkware/sundo/ieve/ieveSoundManager;->a:Ljava/lang/String;

    const-string v2, "stopSound: index[%d]"

    new-array v3, v3, [Ljava/lang/Object;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    aput-object v4, v3, v5

    invoke-static {v2, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 177
    :cond_0
    :goto_0
    return-void

    .line 169
    :cond_1
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/ieveSoundManager;->d:Landroid/media/SoundPool;

    if-eqz v1, :cond_0

    .line 170
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/ieveSoundManager;->e:Ljava/util/HashMap;

    if-eqz v1, :cond_0

    .line 171
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/ieveSoundManager;->e:Ljava/util/HashMap;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_2

    .line 172
    sget-object v1, Lcom/thinkware/sundo/ieve/ieveSoundManager;->a:Ljava/lang/String;

    const-string v2, "playSound: Invalid containsKey[%d]"

    new-array v3, v3, [Ljava/lang/Object;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    aput-object v4, v3, v5

    invoke-static {v2, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    .line 175
    :cond_2
    iget-object v1, p0, Lcom/thinkware/sundo/ieve/ieveSoundManager;->e:Ljava/util/HashMap;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v0

    .line 176
    .local v0, "soundid":I
    if-lez v0, :cond_0

    iget-object v1, p0, Lcom/thinkware/sundo/ieve/ieveSoundManager;->d:Landroid/media/SoundPool;

    invoke-virtual {v1, v0}, Landroid/media/SoundPool;->stop(I)V

    goto :goto_0
.end method
