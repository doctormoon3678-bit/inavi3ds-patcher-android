.class public Ltas/internal/camera/util/CameraMonitor;
.super Landroid/hardware/ICameraServiceListener$Stub;
.source "CameraMonitor.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ltas/internal/camera/util/CameraMonitor$Callback;,
        Ltas/internal/camera/util/CameraMonitor$SimpleCallback;,
        Ltas/internal/camera/util/CameraMonitor$H;,
        Ltas/internal/camera/util/CameraMonitor$1;
    }
.end annotation


# static fields
.field private static final CAMERA_SERVICE_BINDER_NAME:Ljava/lang/String; = "media.camera"

.field public static final CONNECT:I = 0x64

.field private static DBG:Z = false

.field public static final DISCONNECT:I = 0x65

.field public static final ERR_ALREADY_EXIST:I = -0x11

.field public static final ERR_BAD_VALUE:I = -0x16

.field public static final ERR_NO_INIT:I = -0x13

.field public static final ERR_UNKNOWN:I = -0x80000000

.field public static final OK:I = 0x0

.field public static final OPEN:I = 0xa

.field public static final RECONNECT:I = 0x66

.field private static REF:I = 0x0

.field public static final RELEASE:I = 0xb

.field public static final STATUS_NOT_AVAILABLE:I = -0x80000000

.field public static final STATUS_NOT_PRESENT:I = 0x0

.field public static final STATUS_PRESENT:I = 0x1


# instance fields
.field private TAG:Ljava/lang/String;

.field private mBinder:Landroid/os/IBinder;

.field private mCallback:Ltas/internal/camera/util/CameraMonitor$Callback;

.field private mCameraService:Landroid/hardware/ICameraService;

.field private mConnected:Z

.field private mContext:Landroid/content/Context;

.field private final mDeathRecipient:Landroid/os/IBinder$DeathRecipient;

.field private mH:Ltas/internal/camera/util/CameraMonitor$H;

.field private mHT:Landroid/os/HandlerThread;

.field private final mLock:Ljava/lang/Object;

.field private mMonitorAll:Z

.field private mMonitorCamids:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List",
            "<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private mNeedInitialState:Z

.field private mSkipCamids:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List",
            "<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private final mStatusMap:Landroid/util/ArrayMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/util/ArrayMap",
            "<",
            "Ljava/lang/String;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static synthetic -get0(Ltas/internal/camera/util/CameraMonitor;)Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Ltas/internal/camera/util/CameraMonitor;->TAG:Ljava/lang/String;

    return-object v0
.end method

.method static synthetic -get1(Ltas/internal/camera/util/CameraMonitor;)Ltas/internal/camera/util/CameraMonitor$Callback;
    .locals 1

    iget-object v0, p0, Ltas/internal/camera/util/CameraMonitor;->mCallback:Ltas/internal/camera/util/CameraMonitor$Callback;

    return-object v0
.end method

.method static synthetic -get2(Ltas/internal/camera/util/CameraMonitor;)Ltas/internal/camera/util/CameraMonitor$H;
    .locals 1

    iget-object v0, p0, Ltas/internal/camera/util/CameraMonitor;->mH:Ltas/internal/camera/util/CameraMonitor$H;

    return-object v0
.end method

.method static synthetic -set0(Ltas/internal/camera/util/CameraMonitor;Landroid/os/IBinder;)Landroid/os/IBinder;
    .locals 0

    iput-object p1, p0, Ltas/internal/camera/util/CameraMonitor;->mBinder:Landroid/os/IBinder;

    return-object p1
.end method

.method static synthetic -set1(Ltas/internal/camera/util/CameraMonitor;Landroid/hardware/ICameraService;)Landroid/hardware/ICameraService;
    .locals 0

    iput-object p1, p0, Ltas/internal/camera/util/CameraMonitor;->mCameraService:Landroid/hardware/ICameraService;

    return-object p1
.end method

.method static synthetic -set2(Ltas/internal/camera/util/CameraMonitor;Z)Z
    .locals 0

    iput-boolean p1, p0, Ltas/internal/camera/util/CameraMonitor;->mConnected:Z

    return p1
.end method

.method static synthetic -wrap0(Ltas/internal/camera/util/CameraMonitor;Z)V
    .locals 0
    .param p1, "autoConnect"    # Z

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/camera/util/CameraMonitor;->doConnect(Z)V

    return-void
.end method

.method static synthetic -wrap1(Ltas/internal/camera/util/CameraMonitor;Z)V
    .locals 0
    .param p1, "autoReconnect"    # Z

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/camera/util/CameraMonitor;->doReconnect(Z)V

    return-void
.end method

.method static constructor <clinit>()V
    .locals 1

    .prologue
    .line 30
    const/4 v0, 0x1

    sput-boolean v0, Ltas/internal/camera/util/CameraMonitor;->DBG:Z

    .line 32
    const/4 v0, 0x0

    sput v0, Ltas/internal/camera/util/CameraMonitor;->REF:I

    .line 27
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Ltas/internal/camera/util/CameraMonitor$Callback;)V
    .locals 1
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "callback"    # Ltas/internal/camera/util/CameraMonitor$Callback;

    .prologue
    .line 90
    const/4 v0, 0x0

    invoke-direct {p0, p1, p2, v0}, Ltas/internal/camera/util/CameraMonitor;-><init>(Landroid/content/Context;Ltas/internal/camera/util/CameraMonitor$Callback;Z)V

    .line 89
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Ltas/internal/camera/util/CameraMonitor$Callback;Z)V
    .locals 3
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "callback"    # Ltas/internal/camera/util/CameraMonitor$Callback;
    .param p3, "needInitialState"    # Z

    .prologue
    const/4 v2, 0x0

    const/4 v1, 0x0

    .line 93
    invoke-direct {p0}, Landroid/hardware/ICameraServiceListener$Stub;-><init>()V

    .line 29
    const-string/jumbo v0, "TasCAM<Monitor>"

    iput-object v0, p0, Ltas/internal/camera/util/CameraMonitor;->TAG:Ljava/lang/String;

    .line 53
    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, Ltas/internal/camera/util/CameraMonitor;->mLock:Ljava/lang/Object;

    .line 58
    iput-boolean v1, p0, Ltas/internal/camera/util/CameraMonitor;->mConnected:Z

    .line 61
    const/4 v0, 0x1

    iput-boolean v0, p0, Ltas/internal/camera/util/CameraMonitor;->mMonitorAll:Z

    .line 62
    iput-object v2, p0, Ltas/internal/camera/util/CameraMonitor;->mMonitorCamids:Ljava/util/List;

    .line 63
    iput-object v2, p0, Ltas/internal/camera/util/CameraMonitor;->mSkipCamids:Ljava/util/List;

    .line 66
    new-instance v0, Landroid/util/ArrayMap;

    invoke-direct {v0}, Landroid/util/ArrayMap;-><init>()V

    .line 65
    iput-object v0, p0, Ltas/internal/camera/util/CameraMonitor;->mStatusMap:Landroid/util/ArrayMap;

    .line 368
    new-instance v0, Ltas/internal/camera/util/CameraMonitor$1;

    invoke-direct {v0, p0}, Ltas/internal/camera/util/CameraMonitor$1;-><init>(Ltas/internal/camera/util/CameraMonitor;)V

    .line 367
    iput-object v0, p0, Ltas/internal/camera/util/CameraMonitor;->mDeathRecipient:Landroid/os/IBinder$DeathRecipient;

    .line 94
    sget v0, Ltas/internal/camera/util/CameraMonitor;->REF:I

    if-eqz v0, :cond_0

    .line 95
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v1, p0, Ltas/internal/camera/util/CameraMonitor;->TAG:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string/jumbo v1, "#"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    sget v1, Ltas/internal/camera/util/CameraMonitor;->REF:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Ltas/internal/camera/util/CameraMonitor;->TAG:Ljava/lang/String;

    .line 96
    :cond_0
    sget v0, Ltas/internal/camera/util/CameraMonitor;->REF:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Ltas/internal/camera/util/CameraMonitor;->REF:I

    .line 98
    iput-object p1, p0, Ltas/internal/camera/util/CameraMonitor;->mContext:Landroid/content/Context;

    .line 99
    iput-object p2, p0, Ltas/internal/camera/util/CameraMonitor;->mCallback:Ltas/internal/camera/util/CameraMonitor$Callback;

    .line 100
    iput-boolean p3, p0, Ltas/internal/camera/util/CameraMonitor;->mNeedInitialState:Z

    .line 102
    new-instance v0, Landroid/os/HandlerThread;

    iget-object v1, p0, Ltas/internal/camera/util/CameraMonitor;->TAG:Ljava/lang/String;

    invoke-direct {v0, v1}, Landroid/os/HandlerThread;-><init>(Ljava/lang/String;)V

    iput-object v0, p0, Ltas/internal/camera/util/CameraMonitor;->mHT:Landroid/os/HandlerThread;

    .line 103
    iget-object v0, p0, Ltas/internal/camera/util/CameraMonitor;->mHT:Landroid/os/HandlerThread;

    invoke-virtual {v0}, Landroid/os/HandlerThread;->start()V

    .line 104
    new-instance v0, Ltas/internal/camera/util/CameraMonitor$H;

    iget-object v1, p0, Ltas/internal/camera/util/CameraMonitor;->mHT:Landroid/os/HandlerThread;

    invoke-virtual {v1}, Landroid/os/HandlerThread;->getLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1, p0}, Ltas/internal/camera/util/CameraMonitor$H;-><init>(Landroid/os/Looper;Ltas/internal/camera/util/CameraMonitor;)V

    iput-object v0, p0, Ltas/internal/camera/util/CameraMonitor;->mH:Ltas/internal/camera/util/CameraMonitor$H;

    .line 93
    return-void
.end method

.method private cancel(I)V
    .locals 1
    .param p1, "what"    # I

    .prologue
    .line 449
    iget-object v0, p0, Ltas/internal/camera/util/CameraMonitor;->mH:Ltas/internal/camera/util/CameraMonitor$H;

    invoke-virtual {v0, p1}, Ltas/internal/camera/util/CameraMonitor$H;->removeMessages(I)V

    .line 448
    return-void
.end method

.method private doConnect(Z)V
    .locals 7
    .param p1, "autoConnect"    # Z

    .prologue
    .line 210
    iget-object v4, p0, Ltas/internal/camera/util/CameraMonitor;->mLock:Ljava/lang/Object;

    monitor-enter v4

    .line 212
    :try_start_0
    invoke-direct {p0}, Ltas/internal/camera/util/CameraMonitor;->getService()Landroid/hardware/ICameraService;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    move-result-object v2

    .line 213
    .local v2, "srv":Landroid/hardware/ICameraService;
    if-eqz v2, :cond_1

    .line 215
    :try_start_1
    invoke-interface {v2, p0}, Landroid/hardware/ICameraService;->addListener(Landroid/hardware/ICameraServiceListener;)I
    :try_end_1
    .catch Landroid/os/RemoteException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    move-result v1

    .line 225
    .local v1, "err":I
    :goto_0
    if-nez v1, :cond_2

    .line 226
    :try_start_2
    sget-boolean v3, Ltas/internal/camera/util/CameraMonitor;->DBG:Z

    if-eqz v3, :cond_0

    iget-object v3, p0, Ltas/internal/camera/util/CameraMonitor;->TAG:Ljava/lang/String;

    const-string/jumbo v5, "connected"

    invoke-static {v3, v5}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 227
    :cond_0
    const/16 v3, 0x64

    invoke-direct {p0, v3}, Ltas/internal/camera/util/CameraMonitor;->cancel(I)V

    .line 228
    iget-object v3, p0, Ltas/internal/camera/util/CameraMonitor;->mStatusMap:Landroid/util/ArrayMap;

    invoke-virtual {v3}, Landroid/util/ArrayMap;->clear()V

    .line 229
    const/4 v3, 0x1

    iput-boolean v3, p0, Ltas/internal/camera/util/CameraMonitor;->mConnected:Z

    .line 230
    iget-object v3, p0, Ltas/internal/camera/util/CameraMonitor;->mCallback:Ltas/internal/camera/util/CameraMonitor$Callback;

    invoke-interface {v3, p0}, Ltas/internal/camera/util/CameraMonitor$Callback;->onMonitorConnected(Ltas/internal/camera/util/CameraMonitor;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    :goto_1
    monitor-exit v4

    .line 209
    return-void

    .line 216
    .end local v1    # "err":I
    :catch_0
    move-exception v0

    .line 217
    .local v0, "e":Landroid/os/RemoteException;
    :try_start_3
    iget-object v3, p0, Ltas/internal/camera/util/CameraMonitor;->TAG:Ljava/lang/String;

    const-string/jumbo v5, "failed to addListener."

    invoke-static {v3, v5, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 218
    const/high16 v1, -0x80000000

    .restart local v1    # "err":I
    goto :goto_0

    .line 221
    .end local v0    # "e":Landroid/os/RemoteException;
    .end local v1    # "err":I
    :cond_1
    iget-object v3, p0, Ltas/internal/camera/util/CameraMonitor;->TAG:Ljava/lang/String;

    const-string/jumbo v5, "failed to get camera service."

    invoke-static {v3, v5}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 222
    const/16 v1, -0x13

    .restart local v1    # "err":I
    goto :goto_0

    .line 231
    :cond_2
    const/16 v3, -0x11

    if-ne v1, v3, :cond_3

    .line 232
    iget-object v3, p0, Ltas/internal/camera/util/CameraMonitor;->TAG:Ljava/lang/String;

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v6, "error, what=CONNECT, err="

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-static {v3, v5}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 233
    const/16 v3, 0x64

    invoke-direct {p0, v3}, Ltas/internal/camera/util/CameraMonitor;->cancel(I)V

    .line 234
    iget-object v3, p0, Ltas/internal/camera/util/CameraMonitor;->mCallback:Ltas/internal/camera/util/CameraMonitor$Callback;

    const/16 v5, 0x64

    invoke-interface {v3, p0, v5, v1}, Ltas/internal/camera/util/CameraMonitor$Callback;->onMonitorError(Ltas/internal/camera/util/CameraMonitor;II)V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    goto :goto_1

    .line 210
    .end local v1    # "err":I
    .end local v2    # "srv":Landroid/hardware/ICameraService;
    :catchall_0
    move-exception v3

    monitor-exit v4

    throw v3

    .line 236
    .restart local v1    # "err":I
    .restart local v2    # "srv":Landroid/hardware/ICameraService;
    :cond_3
    const/4 v3, 0x0

    :try_start_4
    iput-object v3, p0, Ltas/internal/camera/util/CameraMonitor;->mBinder:Landroid/os/IBinder;

    .line 237
    const/4 v3, 0x0

    iput-object v3, p0, Ltas/internal/camera/util/CameraMonitor;->mCameraService:Landroid/hardware/ICameraService;

    .line 239
    if-eqz p1, :cond_4

    .line 240
    const/4 v3, 0x1

    const/16 v5, 0xbb8

    invoke-virtual {p0, v3, v5}, Ltas/internal/camera/util/CameraMonitor;->connect(ZI)V

    goto :goto_1

    .line 242
    :cond_4
    iget-object v3, p0, Ltas/internal/camera/util/CameraMonitor;->TAG:Ljava/lang/String;

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v6, "error, what=CONNECT, err="

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-static {v3, v5}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 243
    iget-object v3, p0, Ltas/internal/camera/util/CameraMonitor;->mCallback:Ltas/internal/camera/util/CameraMonitor$Callback;

    const/16 v5, 0x64

    invoke-interface {v3, p0, v5, v1}, Ltas/internal/camera/util/CameraMonitor$Callback;->onMonitorError(Ltas/internal/camera/util/CameraMonitor;II)V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    goto :goto_1
.end method

.method private doLinkToDeath()V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .prologue
    .line 353
    iget-object v0, p0, Ltas/internal/camera/util/CameraMonitor;->mBinder:Landroid/os/IBinder;

    if-eqz v0, :cond_0

    .line 354
    iget-object v0, p0, Ltas/internal/camera/util/CameraMonitor;->mBinder:Landroid/os/IBinder;

    iget-object v1, p0, Ltas/internal/camera/util/CameraMonitor;->mDeathRecipient:Landroid/os/IBinder$DeathRecipient;

    const/4 v2, 0x0

    invoke-interface {v0, v1, v2}, Landroid/os/IBinder;->linkToDeath(Landroid/os/IBinder$DeathRecipient;I)V

    .line 352
    :cond_0
    return-void
.end method

.method private doReconnect(Z)V
    .locals 7
    .param p1, "autoReconnect"    # Z

    .prologue
    .line 293
    iget-object v4, p0, Ltas/internal/camera/util/CameraMonitor;->mLock:Ljava/lang/Object;

    monitor-enter v4

    .line 294
    const/4 v3, 0x0

    :try_start_0
    iput-object v3, p0, Ltas/internal/camera/util/CameraMonitor;->mBinder:Landroid/os/IBinder;

    .line 295
    const/4 v3, 0x0

    iput-object v3, p0, Ltas/internal/camera/util/CameraMonitor;->mCameraService:Landroid/hardware/ICameraService;

    .line 298
    invoke-direct {p0}, Ltas/internal/camera/util/CameraMonitor;->getService()Landroid/hardware/ICameraService;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    move-result-object v2

    .line 299
    .local v2, "srv":Landroid/hardware/ICameraService;
    if-eqz v2, :cond_2

    .line 301
    :try_start_1
    invoke-interface {v2, p0}, Landroid/hardware/ICameraService;->addListener(Landroid/hardware/ICameraServiceListener;)I
    :try_end_1
    .catch Landroid/os/RemoteException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    move-result v1

    .line 311
    .local v1, "err":I
    :goto_0
    if-eqz v1, :cond_0

    const/16 v3, -0x11

    if-ne v1, v3, :cond_3

    .line 312
    :cond_0
    :try_start_2
    sget-boolean v3, Ltas/internal/camera/util/CameraMonitor;->DBG:Z

    if-eqz v3, :cond_1

    iget-object v3, p0, Ltas/internal/camera/util/CameraMonitor;->TAG:Ljava/lang/String;

    const-string/jumbo v5, "reconnected"

    invoke-static {v3, v5}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 313
    :cond_1
    const/4 v1, 0x0

    .line 314
    const/16 v3, 0x66

    invoke-direct {p0, v3}, Ltas/internal/camera/util/CameraMonitor;->cancel(I)V

    .line 315
    iget-object v3, p0, Ltas/internal/camera/util/CameraMonitor;->mStatusMap:Landroid/util/ArrayMap;

    invoke-virtual {v3}, Landroid/util/ArrayMap;->clear()V

    .line 316
    const/4 v3, 0x1

    iput-boolean v3, p0, Ltas/internal/camera/util/CameraMonitor;->mConnected:Z

    .line 317
    iget-object v3, p0, Ltas/internal/camera/util/CameraMonitor;->mCallback:Ltas/internal/camera/util/CameraMonitor$Callback;

    invoke-interface {v3, p0}, Ltas/internal/camera/util/CameraMonitor$Callback;->onMonitorReconnected(Ltas/internal/camera/util/CameraMonitor;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    :goto_1
    monitor-exit v4

    .line 292
    return-void

    .line 302
    .end local v1    # "err":I
    :catch_0
    move-exception v0

    .line 303
    .local v0, "e":Landroid/os/RemoteException;
    :try_start_3
    iget-object v3, p0, Ltas/internal/camera/util/CameraMonitor;->TAG:Ljava/lang/String;

    const-string/jumbo v5, "failed to addListener."

    invoke-static {v3, v5, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 304
    const/high16 v1, -0x80000000

    .restart local v1    # "err":I
    goto :goto_0

    .line 307
    .end local v0    # "e":Landroid/os/RemoteException;
    .end local v1    # "err":I
    :cond_2
    iget-object v3, p0, Ltas/internal/camera/util/CameraMonitor;->TAG:Ljava/lang/String;

    const-string/jumbo v5, "failed to get camera service."

    invoke-static {v3, v5}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 308
    const/16 v1, -0x13

    .restart local v1    # "err":I
    goto :goto_0

    .line 320
    :cond_3
    if-eqz p1, :cond_4

    .line 321
    const/4 v3, 0x1

    const/16 v5, 0x5dc

    invoke-virtual {p0, v3, v5}, Ltas/internal/camera/util/CameraMonitor;->reconnect(ZI)V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    goto :goto_1

    .line 293
    .end local v1    # "err":I
    .end local v2    # "srv":Landroid/hardware/ICameraService;
    :catchall_0
    move-exception v3

    monitor-exit v4

    throw v3

    .line 323
    .restart local v1    # "err":I
    .restart local v2    # "srv":Landroid/hardware/ICameraService;
    :cond_4
    :try_start_4
    iget-object v3, p0, Ltas/internal/camera/util/CameraMonitor;->TAG:Ljava/lang/String;

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v6, "error, what=RECONNECT, err="

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-static {v3, v5}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 324
    iget-object v3, p0, Ltas/internal/camera/util/CameraMonitor;->mCallback:Ltas/internal/camera/util/CameraMonitor$Callback;

    const/16 v5, 0x66

    invoke-interface {v3, p0, v5, v1}, Ltas/internal/camera/util/CameraMonitor$Callback;->onMonitorError(Ltas/internal/camera/util/CameraMonitor;II)V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    goto :goto_1
.end method

.method private doUnlinkToDeath()Z
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/util/NoSuchElementException;
        }
    .end annotation

    .prologue
    const/4 v0, 0x0

    .line 359
    iget-object v1, p0, Ltas/internal/camera/util/CameraMonitor;->mBinder:Landroid/os/IBinder;

    if-eqz v1, :cond_0

    .line 360
    iget-object v1, p0, Ltas/internal/camera/util/CameraMonitor;->mBinder:Landroid/os/IBinder;

    iget-object v2, p0, Ltas/internal/camera/util/CameraMonitor;->mDeathRecipient:Landroid/os/IBinder$DeathRecipient;

    invoke-interface {v1, v2, v0}, Landroid/os/IBinder;->unlinkToDeath(Landroid/os/IBinder$DeathRecipient;I)Z

    move-result v0

    .line 359
    :cond_0
    return v0
.end method

.method private getService()Landroid/hardware/ICameraService;
    .locals 5

    .prologue
    const/4 v4, 0x0

    .line 331
    iget-object v2, p0, Ltas/internal/camera/util/CameraMonitor;->mCameraService:Landroid/hardware/ICameraService;

    if-nez v2, :cond_0

    .line 332
    const-string/jumbo v2, "media.camera"

    invoke-static {v2}, Landroid/os/ServiceManager;->getService(Ljava/lang/String;)Landroid/os/IBinder;

    move-result-object v2

    iput-object v2, p0, Ltas/internal/camera/util/CameraMonitor;->mBinder:Landroid/os/IBinder;

    .line 333
    iget-object v2, p0, Ltas/internal/camera/util/CameraMonitor;->mBinder:Landroid/os/IBinder;

    invoke-static {v2}, Landroid/hardware/ICameraService$Stub;->asInterface(Landroid/os/IBinder;)Landroid/hardware/ICameraService;

    move-result-object v2

    iput-object v2, p0, Ltas/internal/camera/util/CameraMonitor;->mCameraService:Landroid/hardware/ICameraService;

    .line 336
    :try_start_0
    invoke-direct {p0}, Ltas/internal/camera/util/CameraMonitor;->doUnlinkToDeath()Z
    :try_end_0
    .catch Ljava/util/NoSuchElementException; {:try_start_0 .. :try_end_0} :catch_0

    .line 342
    :goto_0
    :try_start_1
    invoke-direct {p0}, Ltas/internal/camera/util/CameraMonitor;->doLinkToDeath()V
    :try_end_1
    .catch Landroid/os/RemoteException; {:try_start_1 .. :try_end_1} :catch_1

    .line 349
    :cond_0
    :goto_1
    iget-object v2, p0, Ltas/internal/camera/util/CameraMonitor;->mCameraService:Landroid/hardware/ICameraService;

    return-object v2

    .line 337
    :catch_0
    move-exception v1

    .local v1, "e":Ljava/util/NoSuchElementException;
    goto :goto_0

    .line 343
    .end local v1    # "e":Ljava/util/NoSuchElementException;
    :catch_1
    move-exception v0

    .line 344
    .local v0, "e":Landroid/os/RemoteException;
    iget-object v2, p0, Ltas/internal/camera/util/CameraMonitor;->TAG:Ljava/lang/String;

    const-string/jumbo v3, "failed to linkToDeath."

    invoke-static {v2, v3, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 345
    iput-object v4, p0, Ltas/internal/camera/util/CameraMonitor;->mBinder:Landroid/os/IBinder;

    .line 346
    iput-object v4, p0, Ltas/internal/camera/util/CameraMonitor;->mCameraService:Landroid/hardware/ICameraService;

    goto :goto_1
.end method

.method private isAvailableStatus(I)Z
    .locals 1
    .param p1, "status"    # I

    .prologue
    const/4 v0, 0x1

    .line 364
    if-ne p1, v0, :cond_0

    :goto_0
    return v0

    :cond_0
    const/4 v0, 0x0

    goto :goto_0
.end method

.method private schedule(IIII)V
    .locals 4
    .param p1, "what"    # I
    .param p2, "arg1"    # I
    .param p3, "arg2"    # I
    .param p4, "delay"    # I

    .prologue
    .line 453
    iget-object v0, p0, Ltas/internal/camera/util/CameraMonitor;->mH:Ltas/internal/camera/util/CameraMonitor$H;

    iget-object v1, p0, Ltas/internal/camera/util/CameraMonitor;->mH:Ltas/internal/camera/util/CameraMonitor$H;

    invoke-virtual {v1, p1, p2, p3}, Ltas/internal/camera/util/CameraMonitor$H;->obtainMessage(III)Landroid/os/Message;

    move-result-object v1

    int-to-long v2, p4

    invoke-virtual {v0, v1, v2, v3}, Ltas/internal/camera/util/CameraMonitor$H;->sendMessageDelayed(Landroid/os/Message;J)Z

    .line 452
    return-void
.end method


# virtual methods
.method public asBinder()Landroid/os/IBinder;
    .locals 0

    .prologue
    .line 389
    return-object p0
.end method

.method public connect()V
    .locals 2

    .prologue
    .line 202
    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-virtual {p0, v0, v1}, Ltas/internal/camera/util/CameraMonitor;->connect(ZI)V

    .line 201
    return-void
.end method

.method public connect(ZI)V
    .locals 3
    .param p1, "autoConnect"    # Z
    .param p2, "delay"    # I

    .prologue
    const/4 v1, 0x0

    .line 206
    if-eqz p1, :cond_0

    const/4 v0, 0x1

    :goto_0
    const/16 v2, 0x64

    invoke-direct {p0, v2, v0, v1, p2}, Ltas/internal/camera/util/CameraMonitor;->schedule(IIII)V

    .line 205
    return-void

    :cond_0
    move v0, v1

    .line 206
    goto :goto_0
.end method

.method public disconnect()I
    .locals 7

    .prologue
    .line 254
    iget-object v4, p0, Ltas/internal/camera/util/CameraMonitor;->mLock:Ljava/lang/Object;

    monitor-enter v4

    .line 256
    :try_start_0
    invoke-direct {p0}, Ltas/internal/camera/util/CameraMonitor;->getService()Landroid/hardware/ICameraService;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    move-result-object v2

    .line 257
    .local v2, "srv":Landroid/hardware/ICameraService;
    if-eqz v2, :cond_1

    .line 260
    :try_start_1
    invoke-interface {v2, p0}, Landroid/hardware/ICameraService;->removeListener(Landroid/hardware/ICameraServiceListener;)I
    :try_end_1
    .catch Landroid/os/RemoteException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    move-result v1

    .line 271
    .local v1, "err":I
    :goto_0
    if-nez v1, :cond_2

    .line 272
    :try_start_2
    sget-boolean v3, Ltas/internal/camera/util/CameraMonitor;->DBG:Z

    if-eqz v3, :cond_0

    iget-object v3, p0, Ltas/internal/camera/util/CameraMonitor;->TAG:Ljava/lang/String;

    const-string/jumbo v5, "disconnected"

    invoke-static {v3, v5}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 273
    :cond_0
    const/4 v3, 0x0

    iput-boolean v3, p0, Ltas/internal/camera/util/CameraMonitor;->mConnected:Z

    .line 274
    iget-object v3, p0, Ltas/internal/camera/util/CameraMonitor;->mCallback:Ltas/internal/camera/util/CameraMonitor$Callback;

    invoke-interface {v3, p0}, Ltas/internal/camera/util/CameraMonitor$Callback;->onMonitorDisconnected(Ltas/internal/camera/util/CameraMonitor;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    :goto_1
    monitor-exit v4

    .line 280
    return v1

    .line 261
    .end local v1    # "err":I
    :catch_0
    move-exception v0

    .line 262
    .local v0, "e":Landroid/os/RemoteException;
    :try_start_3
    iget-object v3, p0, Ltas/internal/camera/util/CameraMonitor;->TAG:Ljava/lang/String;

    const-string/jumbo v5, "failed to removeListener."

    invoke-static {v3, v5, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 263
    const/high16 v1, -0x80000000

    .restart local v1    # "err":I
    goto :goto_0

    .line 267
    .end local v0    # "e":Landroid/os/RemoteException;
    .end local v1    # "err":I
    :cond_1
    iget-object v3, p0, Ltas/internal/camera/util/CameraMonitor;->TAG:Ljava/lang/String;

    const-string/jumbo v5, "failed to get camera service."

    invoke-static {v3, v5}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 268
    const/16 v1, -0x13

    .restart local v1    # "err":I
    goto :goto_0

    .line 276
    :cond_2
    iget-object v3, p0, Ltas/internal/camera/util/CameraMonitor;->TAG:Ljava/lang/String;

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v6, "error, what=DISCONNECT, err="

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-static {v3, v5}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 277
    iget-object v3, p0, Ltas/internal/camera/util/CameraMonitor;->mCallback:Ltas/internal/camera/util/CameraMonitor$Callback;

    const/16 v5, 0x65

    invoke-interface {v3, p0, v5, v1}, Ltas/internal/camera/util/CameraMonitor$Callback;->onMonitorError(Ltas/internal/camera/util/CameraMonitor;II)V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    goto :goto_1

    .line 254
    .end local v1    # "err":I
    .end local v2    # "srv":Landroid/hardware/ICameraService;
    :catchall_0
    move-exception v3

    monitor-exit v4

    throw v3
.end method

.method public getContext()Landroid/content/Context;
    .locals 1

    .prologue
    .line 108
    iget-object v0, p0, Ltas/internal/camera/util/CameraMonitor;->mContext:Landroid/content/Context;

    return-object v0
.end method

.method public isCameraOpened(I)Z
    .locals 5
    .param p1, "camid"    # I

    .prologue
    const/4 v2, 0x0

    .line 175
    iget-object v3, p0, Ltas/internal/camera/util/CameraMonitor;->mLock:Ljava/lang/Object;

    monitor-enter v3

    .line 176
    :try_start_0
    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v0

    .line 177
    .local v0, "id":Ljava/lang/String;
    iget-object v4, p0, Ltas/internal/camera/util/CameraMonitor;->mStatusMap:Landroid/util/ArrayMap;

    invoke-virtual {v4, v0}, Landroid/util/ArrayMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    .line 178
    .local v1, "status":Ljava/lang/Integer;
    if-eqz v1, :cond_0

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v4

    invoke-direct {p0, v4}, Ltas/internal/camera/util/CameraMonitor;->isAvailableStatus(I)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    move-result v4

    if-eqz v4, :cond_1

    :cond_0
    :goto_0
    monitor-exit v3

    return v2

    :cond_1
    const/4 v2, 0x1

    goto :goto_0

    .line 175
    .end local v0    # "id":Ljava/lang/String;
    .end local v1    # "status":Ljava/lang/Integer;
    :catchall_0
    move-exception v2

    monitor-exit v3

    throw v2
.end method

.method public isConnected()Z
    .locals 1

    .prologue
    .line 192
    iget-boolean v0, p0, Ltas/internal/camera/util/CameraMonitor;->mConnected:Z

    return v0
.end method

.method public monitor(Ljava/lang/Integer;)V
    .locals 2
    .param p1, "camid"    # Ljava/lang/Integer;

    .prologue
    .line 135
    iget-object v1, p0, Ltas/internal/camera/util/CameraMonitor;->mLock:Ljava/lang/Object;

    monitor-enter v1

    .line 136
    :try_start_0
    iget-object v0, p0, Ltas/internal/camera/util/CameraMonitor;->mSkipCamids:Ljava/util/List;

    if-eqz v0, :cond_0

    iget-object v0, p0, Ltas/internal/camera/util/CameraMonitor;->mSkipCamids:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 137
    iget-object v0, p0, Ltas/internal/camera/util/CameraMonitor;->mSkipCamids:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->remove(Ljava/lang/Object;)Z

    .line 139
    :cond_0
    iget-object v0, p0, Ltas/internal/camera/util/CameraMonitor;->mMonitorCamids:Ljava/util/List;

    if-nez v0, :cond_1

    .line 140
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Ltas/internal/camera/util/CameraMonitor;->mMonitorCamids:Ljava/util/List;

    .line 142
    :cond_1
    iget-object v0, p0, Ltas/internal/camera/util/CameraMonitor;->mMonitorCamids:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_2

    .line 143
    iget-object v0, p0, Ltas/internal/camera/util/CameraMonitor;->mMonitorCamids:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_2
    monitor-exit v1

    .line 134
    return-void

    .line 135
    :catchall_0
    move-exception v0

    monitor-exit v1

    throw v0
.end method

.method public monitorAll(Z)V
    .locals 2
    .param p1, "all"    # Z

    .prologue
    .line 120
    iget-object v1, p0, Ltas/internal/camera/util/CameraMonitor;->mLock:Ljava/lang/Object;

    monitor-enter v1

    .line 121
    :try_start_0
    iput-boolean p1, p0, Ltas/internal/camera/util/CameraMonitor;->mMonitorAll:Z

    .line 122
    if-eqz p1, :cond_1

    .line 123
    iget-object v0, p0, Ltas/internal/camera/util/CameraMonitor;->mSkipCamids:Ljava/util/List;

    if-eqz v0, :cond_0

    .line 124
    iget-object v0, p0, Ltas/internal/camera/util/CameraMonitor;->mSkipCamids:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->clear()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_0
    :goto_0
    monitor-exit v1

    .line 119
    return-void

    .line 127
    :cond_1
    :try_start_1
    iget-object v0, p0, Ltas/internal/camera/util/CameraMonitor;->mMonitorCamids:Ljava/util/List;

    if-eqz v0, :cond_0

    .line 128
    iget-object v0, p0, Ltas/internal/camera/util/CameraMonitor;->mMonitorCamids:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->clear()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_0

    .line 120
    :catchall_0
    move-exception v0

    monitor-exit v1

    throw v0
.end method

.method public needInitalState(Z)V
    .locals 0
    .param p1, "s"    # Z

    .prologue
    .line 112
    iput-boolean p1, p0, Ltas/internal/camera/util/CameraMonitor;->mNeedInitialState:Z

    .line 111
    return-void
.end method

.method public onStatusChanged(II)V
    .locals 6
    .param p1, "status"    # I
    .param p2, "camid"    # I

    .prologue
    .line 394
    iget-object v3, p0, Ltas/internal/camera/util/CameraMonitor;->mLock:Ljava/lang/Object;

    monitor-enter v3

    .line 395
    :try_start_0
    invoke-static {p2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v0

    .line 396
    .local v0, "id":Ljava/lang/String;
    iget-object v2, p0, Ltas/internal/camera/util/CameraMonitor;->mStatusMap:Landroid/util/ArrayMap;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-virtual {v2, v0, v4}, Landroid/util/ArrayMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    .line 398
    .local v1, "oldStatus":Ljava/lang/Integer;
    sget-boolean v2, Ltas/internal/camera/util/CameraMonitor;->DBG:Z

    if-eqz v2, :cond_0

    iget-object v2, p0, Ltas/internal/camera/util/CameraMonitor;->TAG:Ljava/lang/String;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v5, "camid="

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string/jumbo v5, ", status="

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v2, v4}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 400
    :cond_0
    iget-boolean v2, p0, Ltas/internal/camera/util/CameraMonitor;->mMonitorAll:Z

    if-nez v2, :cond_1

    .line 401
    iget-object v2, p0, Ltas/internal/camera/util/CameraMonitor;->mMonitorCamids:Ljava/util/List;

    if-eqz v2, :cond_2

    .line 402
    iget-object v2, p0, Ltas/internal/camera/util/CameraMonitor;->mMonitorCamids:Ljava/util/List;

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-interface {v2, v4}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_2

    .line 403
    :cond_1
    iget-boolean v2, p0, Ltas/internal/camera/util/CameraMonitor;->mMonitorAll:Z

    if-eqz v2, :cond_4

    iget-object v2, p0, Ltas/internal/camera/util/CameraMonitor;->mSkipCamids:Ljava/util/List;

    if-eqz v2, :cond_4

    .line 404
    iget-object v2, p0, Ltas/internal/camera/util/CameraMonitor;->mSkipCamids:Ljava/util/List;

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-interface {v2, v4}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v2

    .line 400
    if-eqz v2, :cond_4

    .line 405
    :cond_2
    sget-boolean v2, Ltas/internal/camera/util/CameraMonitor;->DBG:Z

    if-eqz v2, :cond_3

    iget-object v2, p0, Ltas/internal/camera/util/CameraMonitor;->TAG:Ljava/lang/String;

    const-string/jumbo v4, "skip."

    invoke-static {v2, v4}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_3
    monitor-exit v3

    .line 406
    return-void

    .line 409
    :cond_4
    if-nez v1, :cond_9

    .line 410
    :try_start_1
    iget-boolean v2, p0, Ltas/internal/camera/util/CameraMonitor;->mNeedInitialState:Z

    if-nez v2, :cond_6

    .line 411
    sget-boolean v2, Ltas/internal/camera/util/CameraMonitor;->DBG:Z

    if-eqz v2, :cond_5

    iget-object v2, p0, Ltas/internal/camera/util/CameraMonitor;->TAG:Ljava/lang/String;

    const-string/jumbo v4, "don\'t care the first status."

    invoke-static {v2, v4}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :cond_5
    monitor-exit v3

    .line 412
    return-void

    .line 414
    :cond_6
    :try_start_2
    sget-boolean v2, Ltas/internal/camera/util/CameraMonitor;->DBG:Z

    if-eqz v2, :cond_7

    iget-object v2, p0, Ltas/internal/camera/util/CameraMonitor;->TAG:Ljava/lang/String;

    const-string/jumbo v4, "initial status"

    invoke-static {v2, v4}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 425
    :cond_7
    :goto_0
    const/high16 v2, -0x80000000

    if-ne p1, v2, :cond_c

    .line 426
    const/16 v2, 0xa

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-direct {p0, v2, p2, v4, v5}, Ltas/internal/camera/util/CameraMonitor;->schedule(IIII)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    :cond_8
    :goto_1
    monitor-exit v3

    .line 393
    return-void

    .line 416
    :cond_9
    :try_start_3
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v2

    if-ne v2, p1, :cond_b

    .line 417
    sget-boolean v2, Ltas/internal/camera/util/CameraMonitor;->DBG:Z

    if-eqz v2, :cond_a

    iget-object v2, p0, Ltas/internal/camera/util/CameraMonitor;->TAG:Ljava/lang/String;

    const-string/jumbo v4, "status not changed. return."

    invoke-static {v2, v4}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    :cond_a
    monitor-exit v3

    .line 418
    return-void

    .line 421
    :cond_b
    :try_start_4
    sget-boolean v2, Ltas/internal/camera/util/CameraMonitor;->DBG:Z

    if-eqz v2, :cond_7

    iget-object v2, p0, Ltas/internal/camera/util/CameraMonitor;->TAG:Ljava/lang/String;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v5, "onStatusChanged: status: "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v4

    .line 422
    const-string/jumbo v5, " -> "

    .line 421
    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v2, v4}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    goto :goto_0

    .line 394
    .end local v0    # "id":Ljava/lang/String;
    .end local v1    # "oldStatus":Ljava/lang/Integer;
    :catchall_0
    move-exception v2

    monitor-exit v3

    throw v2

    .line 427
    .restart local v0    # "id":Ljava/lang/String;
    .restart local v1    # "oldStatus":Ljava/lang/Integer;
    :cond_c
    const/4 v2, 0x1

    if-ne p1, v2, :cond_8

    .line 428
    const/16 v2, 0xb

    const/4 v4, 0x0

    const/4 v5, 0x0

    :try_start_5
    invoke-direct {p0, v2, p2, v4, v5}, Ltas/internal/camera/util/CameraMonitor;->schedule(IIII)V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    goto :goto_1
.end method

.method public onTorchStatusChanged(ILjava/lang/String;)V
    .locals 0
    .param p1, "status"    # I
    .param p2, "camid"    # Ljava/lang/String;

    .prologue
    .line 436
    return-void
.end method

.method public reconnect()V
    .locals 2

    .prologue
    .line 285
    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-virtual {p0, v0, v1}, Ltas/internal/camera/util/CameraMonitor;->reconnect(ZI)V

    .line 284
    return-void
.end method

.method public reconnect(ZI)V
    .locals 3
    .param p1, "autoReconnect"    # Z
    .param p2, "delay"    # I

    .prologue
    const/4 v1, 0x0

    .line 289
    if-eqz p1, :cond_0

    const/4 v0, 0x1

    :goto_0
    const/16 v2, 0x66

    invoke-direct {p0, v2, v0, v1, p2}, Ltas/internal/camera/util/CameraMonitor;->schedule(IIII)V

    .line 288
    return-void

    :cond_0
    move v0, v1

    .line 289
    goto :goto_0
.end method

.method public release()V
    .locals 2

    .prologue
    const/4 v1, 0x0

    .line 183
    invoke-virtual {p0}, Ltas/internal/camera/util/CameraMonitor;->disconnect()I

    .line 184
    iget-object v0, p0, Ltas/internal/camera/util/CameraMonitor;->mHT:Landroid/os/HandlerThread;

    invoke-virtual {v0}, Landroid/os/HandlerThread;->quitSafely()Z

    .line 185
    const/4 v0, 0x0

    iput-boolean v0, p0, Ltas/internal/camera/util/CameraMonitor;->mNeedInitialState:Z

    .line 186
    iput-object v1, p0, Ltas/internal/camera/util/CameraMonitor;->mBinder:Landroid/os/IBinder;

    .line 187
    iput-object v1, p0, Ltas/internal/camera/util/CameraMonitor;->mCameraService:Landroid/hardware/ICameraService;

    .line 188
    iput-object v1, p0, Ltas/internal/camera/util/CameraMonitor;->mCallback:Ltas/internal/camera/util/CameraMonitor$Callback;

    .line 182
    return-void
.end method

.method public reset()V
    .locals 2

    .prologue
    .line 163
    iget-object v1, p0, Ltas/internal/camera/util/CameraMonitor;->mLock:Ljava/lang/Object;

    monitor-enter v1

    .line 164
    const/4 v0, 0x1

    :try_start_0
    iput-boolean v0, p0, Ltas/internal/camera/util/CameraMonitor;->mMonitorAll:Z

    .line 165
    iget-object v0, p0, Ltas/internal/camera/util/CameraMonitor;->mMonitorCamids:Ljava/util/List;

    if-eqz v0, :cond_0

    .line 166
    iget-object v0, p0, Ltas/internal/camera/util/CameraMonitor;->mMonitorCamids:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->clear()V

    .line 168
    :cond_0
    iget-object v0, p0, Ltas/internal/camera/util/CameraMonitor;->mSkipCamids:Ljava/util/List;

    if-eqz v0, :cond_1

    .line 169
    iget-object v0, p0, Ltas/internal/camera/util/CameraMonitor;->mSkipCamids:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->clear()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_1
    monitor-exit v1

    .line 162
    return-void

    .line 163
    :catchall_0
    move-exception v0

    monitor-exit v1

    throw v0
.end method

.method public setCallback(Ltas/internal/camera/util/CameraMonitor$Callback;)V
    .locals 0
    .param p1, "l"    # Ltas/internal/camera/util/CameraMonitor$Callback;

    .prologue
    .line 116
    iput-object p1, p0, Ltas/internal/camera/util/CameraMonitor;->mCallback:Ltas/internal/camera/util/CameraMonitor$Callback;

    .line 115
    return-void
.end method

.method public skip(Ljava/lang/Integer;)V
    .locals 2
    .param p1, "camid"    # Ljava/lang/Integer;

    .prologue
    .line 149
    iget-object v1, p0, Ltas/internal/camera/util/CameraMonitor;->mLock:Ljava/lang/Object;

    monitor-enter v1

    .line 150
    :try_start_0
    iget-object v0, p0, Ltas/internal/camera/util/CameraMonitor;->mMonitorCamids:Ljava/util/List;

    if-eqz v0, :cond_0

    iget-object v0, p0, Ltas/internal/camera/util/CameraMonitor;->mMonitorCamids:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 151
    iget-object v0, p0, Ltas/internal/camera/util/CameraMonitor;->mMonitorCamids:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->remove(Ljava/lang/Object;)Z

    .line 153
    :cond_0
    iget-object v0, p0, Ltas/internal/camera/util/CameraMonitor;->mSkipCamids:Ljava/util/List;

    if-nez v0, :cond_1

    .line 154
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Ltas/internal/camera/util/CameraMonitor;->mSkipCamids:Ljava/util/List;

    .line 156
    :cond_1
    iget-object v0, p0, Ltas/internal/camera/util/CameraMonitor;->mSkipCamids:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_2

    .line 157
    iget-object v0, p0, Ltas/internal/camera/util/CameraMonitor;->mSkipCamids:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_2
    monitor-exit v1

    .line 148
    return-void

    .line 149
    :catchall_0
    move-exception v0

    monitor-exit v1

    throw v0
.end method
