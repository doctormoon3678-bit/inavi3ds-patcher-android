.class public final Ltas/internal/iobrigade/connector/type/GenericMsg;
.super Ljava/lang/Object;
.source "GenericMsg.java"


# direct methods
.method public constructor <init>()V
    .locals 0

    .prologue
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
