.class Lcom/thinkware/sundo/ieve/a;
.super Ljava/lang/Object;
.source "ieveTextView.java"


# static fields
.field public static final a:I = 0x0

.field public static final b:I = 0x1

.field public static final c:I = 0x2

.field public static final d:I = 0x0

.field public static final e:I = 0x1

.field public static final f:I = 0x2


# instance fields
.field public g:Ljava/lang/String;

.field public h:F

.field public i:F

.field public j:F

.field public k:I

.field public l:Z

.field public m:Z

.field public n:Z

.field public o:I

.field public p:I

.field public q:Landroid/graphics/Typeface;


# direct methods
.method constructor <init>()V
    .locals 3

    .prologue
    const/4 v2, 0x0

    const/4 v1, 0x0

    .line 16
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 25
    const-string v0, ""

    iput-object v0, p0, Lcom/thinkware/sundo/ieve/a;->g:Ljava/lang/String;

    .line 26
    iput v2, p0, Lcom/thinkware/sundo/ieve/a;->h:F

    .line 27
    iput v2, p0, Lcom/thinkware/sundo/ieve/a;->i:F

    .line 28
    const/high16 v0, 0x41400000    # 12.0f

    iput v0, p0, Lcom/thinkware/sundo/ieve/a;->j:F

    .line 29
    const/4 v0, -0x1

    iput v0, p0, Lcom/thinkware/sundo/ieve/a;->k:I

    .line 30
    iput-boolean v1, p0, Lcom/thinkware/sundo/ieve/a;->l:Z

    .line 31
    iput-boolean v1, p0, Lcom/thinkware/sundo/ieve/a;->m:Z

    .line 32
    iput-boolean v1, p0, Lcom/thinkware/sundo/ieve/a;->n:Z

    .line 33
    iput v1, p0, Lcom/thinkware/sundo/ieve/a;->o:I

    .line 34
    iput v1, p0, Lcom/thinkware/sundo/ieve/a;->p:I

    .line 35
    sget-object v0, Landroid/graphics/Typeface;->DEFAULT:Landroid/graphics/Typeface;

    iput-object v0, p0, Lcom/thinkware/sundo/ieve/a;->q:Landroid/graphics/Typeface;

    .line 16
    return-void
.end method


# virtual methods
.method public a(Ljava/lang/String;FFFIZZZIILandroid/graphics/Typeface;)V
    .locals 0
    .param p1, "_text"    # Ljava/lang/String;
    .param p2, "_posx"    # F
    .param p3, "_posy"    # F
    .param p4, "_size"    # F
    .param p5, "_color"    # I
    .param p6, "_shadow"    # Z
    .param p7, "_italic"    # Z
    .param p8, "_underline"    # Z
    .param p9, "_alignh"    # I
    .param p10, "_alignv"    # I
    .param p11, "_type"    # Landroid/graphics/Typeface;

    .prologue
    .line 38
    iput-object p1, p0, Lcom/thinkware/sundo/ieve/a;->g:Ljava/lang/String;

    .line 39
    iput p2, p0, Lcom/thinkware/sundo/ieve/a;->h:F

    .line 40
    iput p3, p0, Lcom/thinkware/sundo/ieve/a;->i:F

    .line 41
    iput p4, p0, Lcom/thinkware/sundo/ieve/a;->j:F

    .line 42
    iput p5, p0, Lcom/thinkware/sundo/ieve/a;->k:I

    .line 43
    iput-boolean p6, p0, Lcom/thinkware/sundo/ieve/a;->l:Z

    .line 44
    iput-boolean p7, p0, Lcom/thinkware/sundo/ieve/a;->m:Z

    .line 45
    iput-boolean p8, p0, Lcom/thinkware/sundo/ieve/a;->n:Z

    .line 46
    iput p9, p0, Lcom/thinkware/sundo/ieve/a;->o:I

    .line 47
    iput p10, p0, Lcom/thinkware/sundo/ieve/a;->p:I

    .line 48
    if-nez p11, :cond_0

    sget-object p11, Landroid/graphics/Typeface;->DEFAULT:Landroid/graphics/Typeface;

    .end local p11    # "_type":Landroid/graphics/Typeface;
    :cond_0
    iput-object p11, p0, Lcom/thinkware/sundo/ieve/a;->q:Landroid/graphics/Typeface;

    .line 49
    return-void
.end method
