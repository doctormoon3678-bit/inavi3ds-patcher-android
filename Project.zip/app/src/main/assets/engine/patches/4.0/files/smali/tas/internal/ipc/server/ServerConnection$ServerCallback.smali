.class Ltas/internal/ipc/server/ServerConnection$ServerCallback;
.super Ltas/internal/ipc/server/IServerCallback$Stub;
.source "ServerConnection.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltas/internal/ipc/server/ServerConnection;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "ServerCallback"
.end annotation


# instance fields
.field private mRCB:Ltas/internal/ipc/server/ServerConnection$ReceiverCallback;

.field private mSCB:Ltas/internal/ipc/server/ServerConnection$SenderCallback;


# direct methods
.method private constructor <init>()V
    .locals 0

    .prologue
    .line 510
    invoke-direct {p0}, Ltas/internal/ipc/server/IServerCallback$Stub;-><init>()V

    return-void
.end method

.method synthetic constructor <init>(Ltas/internal/ipc/server/ServerConnection$ServerCallback;)V
    .locals 0

    .prologue
    invoke-direct {p0}, Ltas/internal/ipc/server/ServerConnection$ServerCallback;-><init>()V

    return-void
.end method


# virtual methods
.method public onReceiverOffline(Ltas/internal/ipc/server/RemoteSender;Ltas/internal/ipc/server/RemoteReceiver;)V
    .locals 1
    .param p1, "s"    # Ltas/internal/ipc/server/RemoteSender;
    .param p2, "r"    # Ltas/internal/ipc/server/RemoteReceiver;

    .prologue
    .line 530
    iget-object v0, p0, Ltas/internal/ipc/server/ServerConnection$ServerCallback;->mSCB:Ltas/internal/ipc/server/ServerConnection$SenderCallback;

    if-eqz v0, :cond_0

    iget-object v0, p0, Ltas/internal/ipc/server/ServerConnection$ServerCallback;->mSCB:Ltas/internal/ipc/server/ServerConnection$SenderCallback;

    invoke-interface {v0, p1, p2}, Ltas/internal/ipc/server/ServerConnection$SenderCallback;->onReceiverOffline(Ltas/internal/ipc/server/RemoteSender;Ltas/internal/ipc/server/RemoteReceiver;)V

    .line 529
    :cond_0
    return-void
.end method

.method public onReceiverOnline(Ltas/internal/ipc/server/RemoteSender;Ltas/internal/ipc/server/RemoteReceiver;)V
    .locals 1
    .param p1, "s"    # Ltas/internal/ipc/server/RemoteSender;
    .param p2, "r"    # Ltas/internal/ipc/server/RemoteReceiver;

    .prologue
    .line 525
    iget-object v0, p0, Ltas/internal/ipc/server/ServerConnection$ServerCallback;->mSCB:Ltas/internal/ipc/server/ServerConnection$SenderCallback;

    if-eqz v0, :cond_0

    iget-object v0, p0, Ltas/internal/ipc/server/ServerConnection$ServerCallback;->mSCB:Ltas/internal/ipc/server/ServerConnection$SenderCallback;

    invoke-interface {v0, p1, p2}, Ltas/internal/ipc/server/ServerConnection$SenderCallback;->onReceiverOnline(Ltas/internal/ipc/server/RemoteSender;Ltas/internal/ipc/server/RemoteReceiver;)V

    .line 524
    :cond_0
    return-void
.end method

.method public onReceiverUpdate(Ltas/internal/ipc/server/RemoteSender;Ltas/internal/ipc/server/RemoteReceiver;)V
    .locals 1
    .param p1, "s"    # Ltas/internal/ipc/server/RemoteSender;
    .param p2, "r"    # Ltas/internal/ipc/server/RemoteReceiver;

    .prologue
    .line 535
    iget-object v0, p0, Ltas/internal/ipc/server/ServerConnection$ServerCallback;->mSCB:Ltas/internal/ipc/server/ServerConnection$SenderCallback;

    if-eqz v0, :cond_0

    iget-object v0, p0, Ltas/internal/ipc/server/ServerConnection$ServerCallback;->mSCB:Ltas/internal/ipc/server/ServerConnection$SenderCallback;

    invoke-interface {v0, p1, p2}, Ltas/internal/ipc/server/ServerConnection$SenderCallback;->onReceiverUpdate(Ltas/internal/ipc/server/RemoteSender;Ltas/internal/ipc/server/RemoteReceiver;)V

    .line 534
    :cond_0
    return-void
.end method

.method public onSenderOffline(Ltas/internal/ipc/server/RemoteReceiver;Ltas/internal/ipc/server/RemoteSender;)V
    .locals 1
    .param p1, "r"    # Ltas/internal/ipc/server/RemoteReceiver;
    .param p2, "s"    # Ltas/internal/ipc/server/RemoteSender;

    .prologue
    .line 545
    iget-object v0, p0, Ltas/internal/ipc/server/ServerConnection$ServerCallback;->mRCB:Ltas/internal/ipc/server/ServerConnection$ReceiverCallback;

    if-eqz v0, :cond_0

    iget-object v0, p0, Ltas/internal/ipc/server/ServerConnection$ServerCallback;->mRCB:Ltas/internal/ipc/server/ServerConnection$ReceiverCallback;

    invoke-interface {v0, p1, p2}, Ltas/internal/ipc/server/ServerConnection$ReceiverCallback;->onSenderOffline(Ltas/internal/ipc/server/RemoteReceiver;Ltas/internal/ipc/server/RemoteSender;)V

    .line 544
    :cond_0
    return-void
.end method

.method public onSenderOnline(Ltas/internal/ipc/server/RemoteReceiver;Ltas/internal/ipc/server/RemoteSender;)V
    .locals 1
    .param p1, "r"    # Ltas/internal/ipc/server/RemoteReceiver;
    .param p2, "s"    # Ltas/internal/ipc/server/RemoteSender;

    .prologue
    .line 540
    iget-object v0, p0, Ltas/internal/ipc/server/ServerConnection$ServerCallback;->mRCB:Ltas/internal/ipc/server/ServerConnection$ReceiverCallback;

    if-eqz v0, :cond_0

    iget-object v0, p0, Ltas/internal/ipc/server/ServerConnection$ServerCallback;->mRCB:Ltas/internal/ipc/server/ServerConnection$ReceiverCallback;

    invoke-interface {v0, p1, p2}, Ltas/internal/ipc/server/ServerConnection$ReceiverCallback;->onSenderOnline(Ltas/internal/ipc/server/RemoteReceiver;Ltas/internal/ipc/server/RemoteSender;)V

    .line 539
    :cond_0
    return-void
.end method

.method public onSenderUpdate(Ltas/internal/ipc/server/RemoteReceiver;Ltas/internal/ipc/server/RemoteSender;)V
    .locals 1
    .param p1, "r"    # Ltas/internal/ipc/server/RemoteReceiver;
    .param p2, "s"    # Ltas/internal/ipc/server/RemoteSender;

    .prologue
    .line 550
    iget-object v0, p0, Ltas/internal/ipc/server/ServerConnection$ServerCallback;->mRCB:Ltas/internal/ipc/server/ServerConnection$ReceiverCallback;

    if-eqz v0, :cond_0

    iget-object v0, p0, Ltas/internal/ipc/server/ServerConnection$ServerCallback;->mRCB:Ltas/internal/ipc/server/ServerConnection$ReceiverCallback;

    invoke-interface {v0, p1, p2}, Ltas/internal/ipc/server/ServerConnection$ReceiverCallback;->onSenderUpdate(Ltas/internal/ipc/server/RemoteReceiver;Ltas/internal/ipc/server/RemoteSender;)V

    .line 549
    :cond_0
    return-void
.end method

.method setReceiverCallback(Ltas/internal/ipc/server/ServerConnection$ReceiverCallback;)V
    .locals 0
    .param p1, "cb"    # Ltas/internal/ipc/server/ServerConnection$ReceiverCallback;

    .prologue
    .line 520
    iput-object p1, p0, Ltas/internal/ipc/server/ServerConnection$ServerCallback;->mRCB:Ltas/internal/ipc/server/ServerConnection$ReceiverCallback;

    .line 519
    return-void
.end method

.method setSenderCallback(Ltas/internal/ipc/server/ServerConnection$SenderCallback;)V
    .locals 0
    .param p1, "cb"    # Ltas/internal/ipc/server/ServerConnection$SenderCallback;

    .prologue
    .line 516
    iput-object p1, p0, Ltas/internal/ipc/server/ServerConnection$ServerCallback;->mSCB:Ltas/internal/ipc/server/ServerConnection$SenderCallback;

    .line 515
    return-void
.end method

.method public transmit(Ltas/internal/ipc/server/RemoteMessage;)V
    .locals 1
    .param p1, "msg"    # Ltas/internal/ipc/server/RemoteMessage;

    .prologue
    .line 555
    iget-object v0, p0, Ltas/internal/ipc/server/ServerConnection$ServerCallback;->mRCB:Ltas/internal/ipc/server/ServerConnection$ReceiverCallback;

    if-eqz v0, :cond_0

    iget-object v0, p0, Ltas/internal/ipc/server/ServerConnection$ServerCallback;->mRCB:Ltas/internal/ipc/server/ServerConnection$ReceiverCallback;

    invoke-interface {v0, p1}, Ltas/internal/ipc/server/ServerConnection$ReceiverCallback;->transmit(Ltas/internal/ipc/server/RemoteMessage;)V

    .line 554
    :goto_0
    return-void

    .line 556
    :cond_0
    invoke-virtual {p1}, Ltas/internal/ipc/server/RemoteMessage;->recycle()V

    goto :goto_0
.end method
