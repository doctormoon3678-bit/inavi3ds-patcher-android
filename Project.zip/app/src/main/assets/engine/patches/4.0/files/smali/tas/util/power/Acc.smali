.class public final Ltas/util/power/Acc;
.super Ljava/lang/Object;
.source "Acc.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ltas/util/power/Acc$Observer;
    }
.end annotation


# static fields
.field public static final ACC_OFF:I = 0x1

.field public static final ACC_ON:I = 0x0

.field private static final DEVPATH:Ljava/lang/String;

.field private static final TAG:Ljava/lang/String; = "TasUtil<Acc>"

.field private static sOff:Z

.field private static sSelf:Ltas/util/power/Acc;


# instance fields
.field private final ACC:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List",
            "<",
            "Ltas/util/power/Acc$Observer;",
            ">;"
        }
    .end annotation
.end field

.field private COUNT:I

.field private final OBSERVER:Landroid/os/UEventObserver;


# direct methods
.method static synthetic -wrap0(Ltas/util/power/Acc;Landroid/os/UEventObserver$UEvent;)V
    .locals 0
    .param p1, "event"    # Landroid/os/UEventObserver$UEvent;

    .prologue
    invoke-direct {p0, p1}, Ltas/util/power/Acc;->onAccUEvent(Landroid/os/UEventObserver$UEvent;)V

    return-void
.end method

.method static constructor <clinit>()V
    .locals 1

    .prologue
    .line 25
    const-string/jumbo v0, "DEVPATH=/devices/virtual/switch/s3c-pic"

    sput-object v0, Ltas/util/power/Acc;->DEVPATH:Ljava/lang/String;

    .line 14
    return-void
.end method

.method private constructor <init>()V
    .locals 1

    .prologue
    .line 69
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 70
    const/4 v0, 0x0

    iput v0, p0, Ltas/util/power/Acc;->COUNT:I

    .line 71
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Ltas/util/power/Acc;->ACC:Ljava/util/List;

    .line 72
    new-instance v0, Ltas/util/power/Acc$1;

    invoke-direct {v0, p0}, Ltas/util/power/Acc$1;-><init>(Ltas/util/power/Acc;)V

    iput-object v0, p0, Ltas/util/power/Acc;->OBSERVER:Landroid/os/UEventObserver;

    .line 69
    return-void
.end method

.method private addObserver(Ljava/lang/Object;Ljava/util/List;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(TT;",
            "Ljava/util/List",
            "<TT;>;)V"
        }
    .end annotation

    .prologue
    .line 80
    .local p1, "t":Ljava/lang/Object;, "TT;"
    .local p2, "l":Ljava/util/List;, "Ljava/util/List<TT;>;"
    const-class v1, Ltas/util/power/Acc;

    monitor-enter v1

    .line 81
    if-eqz p1, :cond_0

    :try_start_0
    invoke-interface {p2, p1}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2

    .line 85
    :cond_0
    :goto_0
    iget v0, p0, Ltas/util/power/Acc;->COUNT:I

    const/4 v2, 0x1

    if-ne v0, v2, :cond_1

    .line 86
    invoke-direct {p0}, Ltas/util/power/Acc;->startLocked()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_1
    monitor-exit v1

    .line 79
    return-void

    .line 82
    :cond_2
    :try_start_1
    invoke-interface {p2, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 83
    iget v0, p0, Ltas/util/power/Acc;->COUNT:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Ltas/util/power/Acc;->COUNT:I
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_0

    .line 80
    :catchall_0
    move-exception v0

    monitor-exit v1

    throw v0
.end method

.method public static addObserver(Ltas/util/power/Acc$Observer;)V
    .locals 2
    .param p0, "o"    # Ltas/util/power/Acc$Observer;

    .prologue
    .line 42
    invoke-static {}, Ltas/util/power/Acc;->get()Ltas/util/power/Acc;

    move-result-object v0

    .local v0, "a":Ltas/util/power/Acc;
    iget-object v1, v0, Ltas/util/power/Acc;->ACC:Ljava/util/List;

    invoke-direct {v0, p0, v1}, Ltas/util/power/Acc;->addObserver(Ljava/lang/Object;Ljava/util/List;)V

    .line 41
    return-void
.end method

.method private static get()Ltas/util/power/Acc;
    .locals 2

    .prologue
    .line 63
    const-class v1, Ltas/util/power/Acc;

    monitor-enter v1

    .line 64
    :try_start_0
    sget-object v0, Ltas/util/power/Acc;->sSelf:Ltas/util/power/Acc;

    if-nez v0, :cond_0

    new-instance v0, Ltas/util/power/Acc;

    invoke-direct {v0}, Ltas/util/power/Acc;-><init>()V

    sput-object v0, Ltas/util/power/Acc;->sSelf:Ltas/util/power/Acc;

    .line 65
    :cond_0
    sget-object v0, Ltas/util/power/Acc;->sSelf:Ltas/util/power/Acc;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit v1

    return-object v0

    .line 63
    :catchall_0
    move-exception v0

    monitor-exit v1

    throw v0
.end method

.method public static isOff()Z
    .locals 1

    .prologue
    .line 50
    sget-boolean v0, Ltas/util/power/Acc;->sOff:Z

    return v0
.end method

.method private onAccUEvent(Landroid/os/UEventObserver$UEvent;)V
    .locals 10
    .param p1, "event"    # Landroid/os/UEventObserver$UEvent;

    .prologue
    const/4 v5, 0x0

    const/4 v6, 0x1

    .line 112
    const-string/jumbo v7, "SWITCH_STATE"

    invoke-virtual {p1, v7}, Landroid/os/UEventObserver$UEvent;->get(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 113
    .local v4, "str":Ljava/lang/String;
    if-eqz v4, :cond_0

    iget-object v7, p0, Ltas/util/power/Acc;->ACC:Ljava/util/List;

    if-nez v7, :cond_1

    :cond_0
    return-void

    :cond_1
    iget-object v7, p0, Ltas/util/power/Acc;->ACC:Ljava/util/List;

    invoke-interface {v7}, Ljava/util/List;->isEmpty()Z

    move-result v7

    if-nez v7, :cond_0

    .line 118
    :try_start_0
    invoke-static {v4}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I
    :try_end_0
    .catch Ljava/lang/NumberFormatException; {:try_start_0 .. :try_end_0} :catch_0

    move-result v3

    .line 124
    .local v3, "state":I
    :goto_0
    const-string/jumbo v7, "TasUtil<Acc>"

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v9, "acc state: "

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-static {v7, v8}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 126
    const-class v7, Ltas/util/power/Acc;

    monitor-enter v7

    .line 127
    if-ne v3, v6, :cond_2

    move v5, v6

    :cond_2
    :try_start_1
    sput-boolean v5, Ltas/util/power/Acc;->sOff:Z

    .line 128
    if-ne v3, v6, :cond_4

    .line 129
    iget-object v5, p0, Ltas/util/power/Acc;->ACC:Ljava/util/List;

    invoke-interface {v5}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v2

    .local v2, "o$iterator":Ljava/util/Iterator;
    :cond_3
    :goto_1
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_6

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ltas/util/power/Acc$Observer;

    .line 130
    .local v1, "o":Ltas/util/power/Acc$Observer;
    if-eqz v1, :cond_3

    invoke-interface {v1}, Ltas/util/power/Acc$Observer;->onAccOff()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_1

    .line 126
    .end local v1    # "o":Ltas/util/power/Acc$Observer;
    .end local v2    # "o$iterator":Ljava/util/Iterator;
    :catchall_0
    move-exception v5

    monitor-exit v7

    throw v5

    .line 119
    .end local v3    # "state":I
    :catch_0
    move-exception v0

    .line 120
    .local v0, "e":Ljava/lang/NumberFormatException;
    const-string/jumbo v7, "TasUtil<Acc>"

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v9, "invalid state: "

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-static {v7, v8, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 121
    const/4 v3, 0x1

    .restart local v3    # "state":I
    goto :goto_0

    .line 132
    .end local v0    # "e":Ljava/lang/NumberFormatException;
    :cond_4
    if-nez v3, :cond_6

    .line 133
    :try_start_2
    iget-object v5, p0, Ltas/util/power/Acc;->ACC:Ljava/util/List;

    invoke-interface {v5}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v2

    .restart local v2    # "o$iterator":Ljava/util/Iterator;
    :cond_5
    :goto_2
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_6

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ltas/util/power/Acc$Observer;

    .line 134
    .restart local v1    # "o":Ltas/util/power/Acc$Observer;
    if-eqz v1, :cond_5

    invoke-interface {v1}, Ltas/util/power/Acc$Observer;->onAccOn()V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    goto :goto_2

    .end local v1    # "o":Ltas/util/power/Acc$Observer;
    .end local v2    # "o$iterator":Ljava/util/Iterator;
    :cond_6
    monitor-exit v7

    .line 111
    return-void
.end method

.method private removeObserver(Ljava/lang/Object;Ljava/util/List;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(TT;",
            "Ljava/util/List",
            "<TT;>;)V"
        }
    .end annotation

    .prologue
    .line 92
    .local p1, "t":Ljava/lang/Object;, "TT;"
    .local p2, "l":Ljava/util/List;, "Ljava/util/List<TT;>;"
    const-class v1, Ltas/util/power/Acc;

    monitor-enter v1

    .line 93
    if-eqz p1, :cond_0

    :try_start_0
    invoke-interface {p2, p1}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 94
    invoke-interface {p2, p1}, Ljava/util/List;->remove(Ljava/lang/Object;)Z

    .line 95
    iget v0, p0, Ltas/util/power/Acc;->COUNT:I

    add-int/lit8 v0, v0, -0x1

    iput v0, p0, Ltas/util/power/Acc;->COUNT:I

    .line 97
    :cond_0
    iget v0, p0, Ltas/util/power/Acc;->COUNT:I

    if-nez v0, :cond_1

    .line 98
    invoke-direct {p0}, Ltas/util/power/Acc;->stopLocked()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_1
    monitor-exit v1

    .line 91
    return-void

    .line 92
    :catchall_0
    move-exception v0

    monitor-exit v1

    throw v0
.end method

.method public static removeObserver(Ltas/util/power/Acc$Observer;)V
    .locals 2
    .param p0, "o"    # Ltas/util/power/Acc$Observer;

    .prologue
    .line 46
    invoke-static {}, Ltas/util/power/Acc;->get()Ltas/util/power/Acc;

    move-result-object v0

    .local v0, "a":Ltas/util/power/Acc;
    iget-object v1, v0, Ltas/util/power/Acc;->ACC:Ljava/util/List;

    invoke-direct {v0, p0, v1}, Ltas/util/power/Acc;->removeObserver(Ljava/lang/Object;Ljava/util/List;)V

    .line 45
    return-void
.end method

.method private startLocked()V
    .locals 2

    .prologue
    .line 104
    iget-object v0, p0, Ltas/util/power/Acc;->OBSERVER:Landroid/os/UEventObserver;

    sget-object v1, Ltas/util/power/Acc;->DEVPATH:Ljava/lang/String;

    invoke-virtual {v0, v1}, Landroid/os/UEventObserver;->startObserving(Ljava/lang/String;)V

    .line 103
    return-void
.end method

.method private stopLocked()V
    .locals 1

    .prologue
    .line 108
    iget-object v0, p0, Ltas/util/power/Acc;->OBSERVER:Landroid/os/UEventObserver;

    invoke-virtual {v0}, Landroid/os/UEventObserver;->stopObserving()V

    .line 107
    return-void
.end method
