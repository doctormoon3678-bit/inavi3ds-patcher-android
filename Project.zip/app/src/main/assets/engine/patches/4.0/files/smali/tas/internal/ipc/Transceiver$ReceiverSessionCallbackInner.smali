.class Ltas/internal/ipc/Transceiver$ReceiverSessionCallbackInner;
.super Ljava/lang/Object;
.source "Transceiver.java"

# interfaces
.implements Ltas/ipc/ReceiverSession$Callback;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltas/internal/ipc/Transceiver;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "ReceiverSessionCallbackInner"
.end annotation


# instance fields
.field private mS:Ltas/ipc/TransceiverSession;


# direct methods
.method private constructor <init>(Ltas/ipc/TransceiverSession;)V
    .locals 0
    .param p1, "s"    # Ltas/ipc/TransceiverSession;

    .prologue
    .line 231
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 232
    iput-object p1, p0, Ltas/internal/ipc/Transceiver$ReceiverSessionCallbackInner;->mS:Ltas/ipc/TransceiverSession;

    .line 231
    return-void
.end method

.method synthetic constructor <init>(Ltas/ipc/TransceiverSession;Ltas/internal/ipc/Transceiver$ReceiverSessionCallbackInner;)V
    .locals 0
    .param p1, "s"    # Ltas/ipc/TransceiverSession;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/ipc/Transceiver$ReceiverSessionCallbackInner;-><init>(Ltas/ipc/TransceiverSession;)V

    return-void
.end method


# virtual methods
.method public onReceive(Ltas/ipc/ReceiverSession;ILtas/ipc/MsgData;)V
    .locals 2
    .param p1, "session"    # Ltas/ipc/ReceiverSession;
    .param p2, "what"    # I
    .param p3, "msg"    # Ltas/ipc/MsgData;

    .prologue
    .line 264
    iget-object v0, p0, Ltas/internal/ipc/Transceiver$ReceiverSessionCallbackInner;->mS:Ltas/ipc/TransceiverSession;

    iget-object v0, v0, Ltas/ipc/TransceiverSession;->cb:Ltas/ipc/TransceiverSession$Callback;

    if-eqz v0, :cond_0

    .line 265
    iget-object v0, p0, Ltas/internal/ipc/Transceiver$ReceiverSessionCallbackInner;->mS:Ltas/ipc/TransceiverSession;

    iget-object v0, v0, Ltas/ipc/TransceiverSession;->cb:Ltas/ipc/TransceiverSession$Callback;

    iget-object v1, p0, Ltas/internal/ipc/Transceiver$ReceiverSessionCallbackInner;->mS:Ltas/ipc/TransceiverSession;

    invoke-interface {v0, v1, p2, p3}, Ltas/ipc/TransceiverSession$Callback;->onReceive(Ltas/ipc/TransceiverSession;ILtas/ipc/MsgData;)V

    .line 263
    :cond_0
    return-void
.end method

.method public onSenderOffline(Ltas/ipc/ReceiverSession;)V
    .locals 3
    .param p1, "session"    # Ltas/ipc/ReceiverSession;

    .prologue
    const/4 v2, 0x0

    .line 249
    iget-object v0, p0, Ltas/internal/ipc/Transceiver$ReceiverSessionCallbackInner;->mS:Ltas/ipc/TransceiverSession;

    iget-object v0, v0, Ltas/ipc/TransceiverSession;->cb:Ltas/ipc/TransceiverSession$Callback;

    if-eqz v0, :cond_0

    .line 250
    iget-object v0, p0, Ltas/internal/ipc/Transceiver$ReceiverSessionCallbackInner;->mS:Ltas/ipc/TransceiverSession;

    iget-object v0, v0, Ltas/ipc/TransceiverSession;->cb:Ltas/ipc/TransceiverSession$Callback;

    iget-object v1, p0, Ltas/internal/ipc/Transceiver$ReceiverSessionCallbackInner;->mS:Ltas/ipc/TransceiverSession;

    invoke-interface {v0, v1}, Ltas/ipc/TransceiverSession$Callback;->onSenderOffline(Ltas/ipc/TransceiverSession;)V

    .line 252
    :cond_0
    iget-object v0, p0, Ltas/internal/ipc/Transceiver$ReceiverSessionCallbackInner;->mS:Ltas/ipc/TransceiverSession;

    iput-object v2, v0, Ltas/ipc/TransceiverSession;->r:Ltas/ipc/ReceiverSession;

    .line 248
    return-void
.end method

.method public onSenderOnline(Ltas/ipc/ReceiverSession;)V
    .locals 2
    .param p1, "session"    # Ltas/ipc/ReceiverSession;

    .prologue
    .line 236
    iget-object v0, p0, Ltas/internal/ipc/Transceiver$ReceiverSessionCallbackInner;->mS:Ltas/ipc/TransceiverSession;

    iget-object v0, v0, Ltas/ipc/TransceiverSession;->pkg:Ljava/lang/String;

    if-nez v0, :cond_0

    .line 237
    iget-object v0, p0, Ltas/internal/ipc/Transceiver$ReceiverSessionCallbackInner;->mS:Ltas/ipc/TransceiverSession;

    iget-object v1, p1, Ltas/ipc/ReceiverSession;->pkg:Ljava/lang/String;

    iput-object v1, v0, Ltas/ipc/TransceiverSession;->pkg:Ljava/lang/String;

    .line 239
    :cond_0
    iget-object v0, p0, Ltas/internal/ipc/Transceiver$ReceiverSessionCallbackInner;->mS:Ltas/ipc/TransceiverSession;

    iget-object v0, v0, Ltas/ipc/TransceiverSession;->name:Ljava/lang/String;

    if-nez v0, :cond_1

    .line 240
    iget-object v0, p0, Ltas/internal/ipc/Transceiver$ReceiverSessionCallbackInner;->mS:Ltas/ipc/TransceiverSession;

    iget-object v1, p1, Ltas/ipc/ReceiverSession;->name:Ljava/lang/String;

    iput-object v1, v0, Ltas/ipc/TransceiverSession;->name:Ljava/lang/String;

    .line 242
    :cond_1
    iget-object v0, p0, Ltas/internal/ipc/Transceiver$ReceiverSessionCallbackInner;->mS:Ltas/ipc/TransceiverSession;

    iput-object p1, v0, Ltas/ipc/TransceiverSession;->r:Ltas/ipc/ReceiverSession;

    .line 243
    iget-object v0, p0, Ltas/internal/ipc/Transceiver$ReceiverSessionCallbackInner;->mS:Ltas/ipc/TransceiverSession;

    iget-object v0, v0, Ltas/ipc/TransceiverSession;->cb:Ltas/ipc/TransceiverSession$Callback;

    if-eqz v0, :cond_2

    .line 244
    iget-object v0, p0, Ltas/internal/ipc/Transceiver$ReceiverSessionCallbackInner;->mS:Ltas/ipc/TransceiverSession;

    iget-object v0, v0, Ltas/ipc/TransceiverSession;->cb:Ltas/ipc/TransceiverSession$Callback;

    iget-object v1, p0, Ltas/internal/ipc/Transceiver$ReceiverSessionCallbackInner;->mS:Ltas/ipc/TransceiverSession;

    invoke-interface {v0, v1}, Ltas/ipc/TransceiverSession$Callback;->onSenderOnline(Ltas/ipc/TransceiverSession;)V

    .line 235
    :cond_2
    return-void
.end method

.method public onSenderUpdate(Ltas/ipc/ReceiverSession;Landroid/os/Bundle;)V
    .locals 2
    .param p1, "session"    # Ltas/ipc/ReceiverSession;
    .param p2, "extra"    # Landroid/os/Bundle;

    .prologue
    .line 257
    iget-object v0, p0, Ltas/internal/ipc/Transceiver$ReceiverSessionCallbackInner;->mS:Ltas/ipc/TransceiverSession;

    iget-object v0, v0, Ltas/ipc/TransceiverSession;->cb:Ltas/ipc/TransceiverSession$Callback;

    if-eqz v0, :cond_0

    .line 258
    iget-object v0, p0, Ltas/internal/ipc/Transceiver$ReceiverSessionCallbackInner;->mS:Ltas/ipc/TransceiverSession;

    iget-object v0, v0, Ltas/ipc/TransceiverSession;->cb:Ltas/ipc/TransceiverSession$Callback;

    iget-object v1, p0, Ltas/internal/ipc/Transceiver$ReceiverSessionCallbackInner;->mS:Ltas/ipc/TransceiverSession;

    invoke-interface {v0, v1, p2}, Ltas/ipc/TransceiverSession$Callback;->onSenderUpdate(Ltas/ipc/TransceiverSession;Landroid/os/Bundle;)V

    .line 256
    :cond_0
    return-void
.end method
