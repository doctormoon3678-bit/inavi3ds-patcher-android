.class Ltas/internal/iobrigade/connector/EventNodeHelper$1;
.super Landroid/os/Handler;
.source "EventNodeHelper.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ltas/internal/iobrigade/connector/EventNodeHelper;->setConsumer(Ltas/internal/iobrigade/connector/IRemoteIOEvent;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Ltas/internal/iobrigade/connector/EventNodeHelper;

.field final synthetic val$listener:Ltas/internal/iobrigade/connector/IRemoteIOEvent;


# direct methods
.method constructor <init>(Ltas/internal/iobrigade/connector/EventNodeHelper;Landroid/os/Looper;Landroid/os/Handler$Callback;ZLtas/internal/iobrigade/connector/IRemoteIOEvent;)V
    .locals 0
    .param p2, "$anonymous0"    # Landroid/os/Looper;
    .param p3, "$anonymous1"    # Landroid/os/Handler$Callback;
    .param p4, "$anonymous2"    # Z

    .prologue
    .line 47
    .local p1, "this$0":Ltas/internal/iobrigade/connector/EventNodeHelper;, "Ltas/internal/iobrigade/connector/EventNodeHelper<TT;>;"
    .local p5, "val$listener":Ltas/internal/iobrigade/connector/IRemoteIOEvent;, "Ltas/internal/iobrigade/connector/IRemoteIOEvent<TT;>;"
    iput-object p1, p0, Ltas/internal/iobrigade/connector/EventNodeHelper$1;->this$0:Ltas/internal/iobrigade/connector/EventNodeHelper;

    iput-object p5, p0, Ltas/internal/iobrigade/connector/EventNodeHelper$1;->val$listener:Ltas/internal/iobrigade/connector/IRemoteIOEvent;

    invoke-direct {p0, p2, p3, p4}, Landroid/os/Handler;-><init>(Landroid/os/Looper;Landroid/os/Handler$Callback;Z)V

    return-void
.end method


# virtual methods
.method public handleMessage(Landroid/os/Message;)V
    .locals 2
    .param p1, "msg"    # Landroid/os/Message;

    .prologue
    .line 50
    iget-object v0, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v0, Ltas/internal/iobrigade/connector/IOData;

    .line 51
    .local v0, "data":Ltas/internal/iobrigade/connector/IOData;
    iget-object v1, p0, Ltas/internal/iobrigade/connector/EventNodeHelper$1;->val$listener:Ltas/internal/iobrigade/connector/IRemoteIOEvent;

    invoke-interface {v1, v0}, Ltas/internal/iobrigade/connector/IRemoteIOEvent;->onRemoteEvent(Ltas/internal/iobrigade/connector/IOData;)V

    .line 49
    return-void
.end method
