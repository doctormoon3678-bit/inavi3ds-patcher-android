.class public Ltas/camera/CameraCommand;
.super Ltas/camera/CameraMessage;
.source "CameraCommand.java"


# direct methods
.method public constructor <init>()V
    .locals 0

    .prologue
    .line 4
    invoke-direct {p0}, Ltas/camera/CameraMessage;-><init>()V

    return-void
.end method

.method public constructor <init>(I)V
    .locals 0
    .param p1, "what"    # I

    .prologue
    .line 5
    invoke-direct {p0, p1}, Ltas/camera/CameraMessage;-><init>(I)V

    return-void
.end method
