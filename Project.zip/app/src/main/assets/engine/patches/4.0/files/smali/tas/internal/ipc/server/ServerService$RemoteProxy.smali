.class Ltas/internal/ipc/server/ServerService$RemoteProxy;
.super Ltas/internal/ipc/server/IServerService$Stub;
.source "ServerService.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltas/internal/ipc/server/ServerService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "RemoteProxy"
.end annotation


# instance fields
.field private mM:Ljava/lang/ref/WeakReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference",
            "<",
            "Ltas/internal/ipc/server/ServerService;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Ltas/internal/ipc/server/ServerService;)V
    .locals 1
    .param p1, "m"    # Ltas/internal/ipc/server/ServerService;

    .prologue
    .line 64
    invoke-direct {p0}, Ltas/internal/ipc/server/IServerService$Stub;-><init>()V

    .line 65
    new-instance v0, Ljava/lang/ref/WeakReference;

    invoke-direct {v0, p1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    iput-object v0, p0, Ltas/internal/ipc/server/ServerService$RemoteProxy;->mM:Ljava/lang/ref/WeakReference;

    .line 64
    return-void
.end method


# virtual methods
.method public registerReceiver(Ltas/internal/ipc/server/RemoteReceiver;)V
    .locals 3
    .param p1, "receiver"    # Ltas/internal/ipc/server/RemoteReceiver;

    .prologue
    .line 70
    iget-object v1, p0, Ltas/internal/ipc/server/ServerService$RemoteProxy;->mM:Ljava/lang/ref/WeakReference;

    invoke-virtual {v1}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/ipc/server/ServerService;

    .line 71
    .local v0, "m":Ltas/internal/ipc/server/ServerService;
    if-eqz v0, :cond_0

    invoke-static {v0}, Ltas/internal/ipc/server/ServerService;->-get0(Ltas/internal/ipc/server/ServerService;)Ltas/internal/ipc/server/ServerManager;

    move-result-object v1

    invoke-static {}, Ltas/internal/ipc/server/ServerService$RemoteProxy;->getCallingPid()I

    move-result v2

    invoke-virtual {v1, v2, p1}, Ltas/internal/ipc/server/ServerManager;->registerReceiver(ILtas/internal/ipc/server/RemoteReceiver;)V

    .line 69
    :goto_0
    return-void

    .line 72
    :cond_0
    const-string/jumbo v1, "TasIPC<ServerService>"

    const-string/jumbo v2, "registerReceiver: server is dead."

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0
.end method

.method public registerSender(Ltas/internal/ipc/server/RemoteSender;)V
    .locals 3
    .param p1, "sender"    # Ltas/internal/ipc/server/RemoteSender;

    .prologue
    .line 91
    iget-object v1, p0, Ltas/internal/ipc/server/ServerService$RemoteProxy;->mM:Ljava/lang/ref/WeakReference;

    invoke-virtual {v1}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/ipc/server/ServerService;

    .line 92
    .local v0, "m":Ltas/internal/ipc/server/ServerService;
    if-eqz v0, :cond_0

    invoke-static {v0}, Ltas/internal/ipc/server/ServerService;->-get0(Ltas/internal/ipc/server/ServerService;)Ltas/internal/ipc/server/ServerManager;

    move-result-object v1

    invoke-static {}, Ltas/internal/ipc/server/ServerService$RemoteProxy;->getCallingPid()I

    move-result v2

    invoke-virtual {v1, v2, p1}, Ltas/internal/ipc/server/ServerManager;->registerSender(ILtas/internal/ipc/server/RemoteSender;)V

    .line 90
    :goto_0
    return-void

    .line 93
    :cond_0
    const-string/jumbo v1, "TasIPC<ServerService>"

    const-string/jumbo v2, "registerSender: server is dead."

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0
.end method

.method public setCallback(Ltas/internal/ipc/server/IServerCallback;)V
    .locals 3
    .param p1, "cb"    # Ltas/internal/ipc/server/IServerCallback;

    .prologue
    .line 168
    iget-object v1, p0, Ltas/internal/ipc/server/ServerService$RemoteProxy;->mM:Ljava/lang/ref/WeakReference;

    invoke-virtual {v1}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/ipc/server/ServerService;

    .line 169
    .local v0, "m":Ltas/internal/ipc/server/ServerService;
    if-eqz v0, :cond_0

    invoke-static {v0}, Ltas/internal/ipc/server/ServerService;->-get0(Ltas/internal/ipc/server/ServerService;)Ltas/internal/ipc/server/ServerManager;

    move-result-object v1

    invoke-static {}, Ltas/internal/ipc/server/ServerService$RemoteProxy;->getCallingPid()I

    move-result v2

    invoke-virtual {v1, v2, p1}, Ltas/internal/ipc/server/ServerManager;->setCallback(ILtas/internal/ipc/server/IServerCallback;)V

    .line 167
    :goto_0
    return-void

    .line 170
    :cond_0
    const-string/jumbo v1, "TasIPC<ServerService>"

    const-string/jumbo v2, "setCallback: server is dead."

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0
.end method

.method public transmit(Ltas/internal/ipc/server/RemoteMessage;)V
    .locals 2
    .param p1, "msg"    # Ltas/internal/ipc/server/RemoteMessage;

    .prologue
    .line 175
    iget-object v1, p0, Ltas/internal/ipc/server/ServerService$RemoteProxy;->mM:Ljava/lang/ref/WeakReference;

    invoke-virtual {v1}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/ipc/server/ServerService;

    .line 176
    .local v0, "m":Ltas/internal/ipc/server/ServerService;
    if-eqz v0, :cond_0

    invoke-static {v0}, Ltas/internal/ipc/server/ServerService;->-get0(Ltas/internal/ipc/server/ServerService;)Ltas/internal/ipc/server/ServerManager;

    move-result-object v1

    invoke-virtual {v1, p1}, Ltas/internal/ipc/server/ServerManager;->transmit(Ltas/internal/ipc/server/RemoteMessage;)V

    .line 174
    :goto_0
    return-void

    .line 177
    :cond_0
    invoke-virtual {p1}, Ltas/internal/ipc/server/RemoteMessage;->recycle()V

    goto :goto_0
.end method

.method public unregisterReceiver(Ltas/internal/ipc/server/RemoteReceiver;)V
    .locals 3
    .param p1, "receiver"    # Ltas/internal/ipc/server/RemoteReceiver;

    .prologue
    .line 77
    iget-object v1, p0, Ltas/internal/ipc/server/ServerService$RemoteProxy;->mM:Ljava/lang/ref/WeakReference;

    invoke-virtual {v1}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/ipc/server/ServerService;

    .line 78
    .local v0, "m":Ltas/internal/ipc/server/ServerService;
    if-eqz v0, :cond_0

    invoke-static {v0}, Ltas/internal/ipc/server/ServerService;->-get0(Ltas/internal/ipc/server/ServerService;)Ltas/internal/ipc/server/ServerManager;

    move-result-object v1

    invoke-static {}, Ltas/internal/ipc/server/ServerService$RemoteProxy;->getCallingPid()I

    move-result v2

    invoke-virtual {v1, v2, p1}, Ltas/internal/ipc/server/ServerManager;->unregisterReceiver(ILtas/internal/ipc/server/RemoteReceiver;)V

    .line 76
    :goto_0
    return-void

    .line 79
    :cond_0
    const-string/jumbo v1, "TasIPC<ServerService>"

    const-string/jumbo v2, "unregisterReceiver: server is dead."

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0
.end method

.method public unregisterSender(Ltas/internal/ipc/server/RemoteSender;)V
    .locals 3
    .param p1, "sender"    # Ltas/internal/ipc/server/RemoteSender;

    .prologue
    .line 98
    iget-object v1, p0, Ltas/internal/ipc/server/ServerService$RemoteProxy;->mM:Ljava/lang/ref/WeakReference;

    invoke-virtual {v1}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/ipc/server/ServerService;

    .line 99
    .local v0, "m":Ltas/internal/ipc/server/ServerService;
    if-eqz v0, :cond_0

    invoke-static {v0}, Ltas/internal/ipc/server/ServerService;->-get0(Ltas/internal/ipc/server/ServerService;)Ltas/internal/ipc/server/ServerManager;

    move-result-object v1

    invoke-static {}, Ltas/internal/ipc/server/ServerService$RemoteProxy;->getCallingPid()I

    move-result v2

    invoke-virtual {v1, v2, p1}, Ltas/internal/ipc/server/ServerManager;->unregisterSender(ILtas/internal/ipc/server/RemoteSender;)V

    .line 97
    :goto_0
    return-void

    .line 100
    :cond_0
    const-string/jumbo v1, "TasIPC<ServerService>"

    const-string/jumbo v2, "unregisterSender: server is dead."

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0
.end method

.method public unwatchAnonymousReceiver(Ltas/internal/ipc/server/RemoteSender;)V
    .locals 3
    .param p1, "sender"    # Ltas/internal/ipc/server/RemoteSender;

    .prologue
    .line 133
    iget-object v1, p0, Ltas/internal/ipc/server/ServerService$RemoteProxy;->mM:Ljava/lang/ref/WeakReference;

    invoke-virtual {v1}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/ipc/server/ServerService;

    .line 134
    .local v0, "m":Ltas/internal/ipc/server/ServerService;
    if-eqz v0, :cond_0

    invoke-static {v0}, Ltas/internal/ipc/server/ServerService;->-get0(Ltas/internal/ipc/server/ServerService;)Ltas/internal/ipc/server/ServerManager;

    move-result-object v1

    invoke-static {}, Ltas/internal/ipc/server/ServerService$RemoteProxy;->getCallingPid()I

    move-result v2

    invoke-virtual {v1, v2, p1}, Ltas/internal/ipc/server/ServerManager;->unwatchAnonymousReceiver(ILtas/internal/ipc/server/RemoteSender;)V

    .line 132
    :goto_0
    return-void

    .line 135
    :cond_0
    const-string/jumbo v1, "TasIPC<ServerService>"

    const-string/jumbo v2, "unwatchAnonymousReceiver: server is dead."

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0
.end method

.method public unwatchAnonymousSender(Ltas/internal/ipc/server/RemoteReceiver;)V
    .locals 3
    .param p1, "receiver"    # Ltas/internal/ipc/server/RemoteReceiver;

    .prologue
    .line 161
    iget-object v1, p0, Ltas/internal/ipc/server/ServerService$RemoteProxy;->mM:Ljava/lang/ref/WeakReference;

    invoke-virtual {v1}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/ipc/server/ServerService;

    .line 162
    .local v0, "m":Ltas/internal/ipc/server/ServerService;
    if-eqz v0, :cond_0

    invoke-static {v0}, Ltas/internal/ipc/server/ServerService;->-get0(Ltas/internal/ipc/server/ServerService;)Ltas/internal/ipc/server/ServerManager;

    move-result-object v1

    invoke-static {}, Ltas/internal/ipc/server/ServerService$RemoteProxy;->getCallingPid()I

    move-result v2

    invoke-virtual {v1, v2, p1}, Ltas/internal/ipc/server/ServerManager;->unwatchAnonymousSender(ILtas/internal/ipc/server/RemoteReceiver;)V

    .line 160
    :goto_0
    return-void

    .line 163
    :cond_0
    const-string/jumbo v1, "TasIPC<ServerService>"

    const-string/jumbo v2, "unwatchAnonymousSender: server is dead."

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0
.end method

.method public unwatchReceiver(Ltas/internal/ipc/server/RemoteSender;)V
    .locals 3
    .param p1, "sender"    # Ltas/internal/ipc/server/RemoteSender;

    .prologue
    .line 119
    iget-object v1, p0, Ltas/internal/ipc/server/ServerService$RemoteProxy;->mM:Ljava/lang/ref/WeakReference;

    invoke-virtual {v1}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/ipc/server/ServerService;

    .line 120
    .local v0, "m":Ltas/internal/ipc/server/ServerService;
    if-eqz v0, :cond_0

    invoke-static {v0}, Ltas/internal/ipc/server/ServerService;->-get0(Ltas/internal/ipc/server/ServerService;)Ltas/internal/ipc/server/ServerManager;

    move-result-object v1

    invoke-static {}, Ltas/internal/ipc/server/ServerService$RemoteProxy;->getCallingPid()I

    move-result v2

    invoke-virtual {v1, v2, p1}, Ltas/internal/ipc/server/ServerManager;->unwatchReceiver(ILtas/internal/ipc/server/RemoteSender;)V

    .line 118
    :goto_0
    return-void

    .line 121
    :cond_0
    const-string/jumbo v1, "TasIPC<ServerService>"

    const-string/jumbo v2, "unwatchReceiver: server is dead."

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0
.end method

.method public unwatchSender(Ltas/internal/ipc/server/RemoteReceiver;)V
    .locals 3
    .param p1, "receiver"    # Ltas/internal/ipc/server/RemoteReceiver;

    .prologue
    .line 147
    iget-object v1, p0, Ltas/internal/ipc/server/ServerService$RemoteProxy;->mM:Ljava/lang/ref/WeakReference;

    invoke-virtual {v1}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/ipc/server/ServerService;

    .line 148
    .local v0, "m":Ltas/internal/ipc/server/ServerService;
    if-eqz v0, :cond_0

    invoke-static {v0}, Ltas/internal/ipc/server/ServerService;->-get0(Ltas/internal/ipc/server/ServerService;)Ltas/internal/ipc/server/ServerManager;

    move-result-object v1

    invoke-static {}, Ltas/internal/ipc/server/ServerService$RemoteProxy;->getCallingPid()I

    move-result v2

    invoke-virtual {v1, v2, p1}, Ltas/internal/ipc/server/ServerManager;->unwatchSender(ILtas/internal/ipc/server/RemoteReceiver;)V

    .line 146
    :goto_0
    return-void

    .line 149
    :cond_0
    const-string/jumbo v1, "TasIPC<ServerService>"

    const-string/jumbo v2, "unwatchSender: server is dead."

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0
.end method

.method public updateReceiver(Ltas/internal/ipc/server/RemoteReceiver;)V
    .locals 3
    .param p1, "receiver"    # Ltas/internal/ipc/server/RemoteReceiver;

    .prologue
    .line 84
    iget-object v1, p0, Ltas/internal/ipc/server/ServerService$RemoteProxy;->mM:Ljava/lang/ref/WeakReference;

    invoke-virtual {v1}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/ipc/server/ServerService;

    .line 85
    .local v0, "m":Ltas/internal/ipc/server/ServerService;
    if-eqz v0, :cond_0

    invoke-static {v0}, Ltas/internal/ipc/server/ServerService;->-get0(Ltas/internal/ipc/server/ServerService;)Ltas/internal/ipc/server/ServerManager;

    move-result-object v1

    invoke-static {}, Ltas/internal/ipc/server/ServerService$RemoteProxy;->getCallingPid()I

    move-result v2

    invoke-virtual {v1, v2, p1}, Ltas/internal/ipc/server/ServerManager;->updateReceiver(ILtas/internal/ipc/server/RemoteReceiver;)V

    .line 83
    :goto_0
    return-void

    .line 86
    :cond_0
    const-string/jumbo v1, "TasIPC<ServerService>"

    const-string/jumbo v2, "updateReceiver: server is dead."

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0
.end method

.method public updateSender(Ltas/internal/ipc/server/RemoteSender;)V
    .locals 3
    .param p1, "sender"    # Ltas/internal/ipc/server/RemoteSender;

    .prologue
    .line 105
    iget-object v1, p0, Ltas/internal/ipc/server/ServerService$RemoteProxy;->mM:Ljava/lang/ref/WeakReference;

    invoke-virtual {v1}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/ipc/server/ServerService;

    .line 106
    .local v0, "m":Ltas/internal/ipc/server/ServerService;
    if-eqz v0, :cond_0

    invoke-static {v0}, Ltas/internal/ipc/server/ServerService;->-get0(Ltas/internal/ipc/server/ServerService;)Ltas/internal/ipc/server/ServerManager;

    move-result-object v1

    invoke-static {}, Ltas/internal/ipc/server/ServerService$RemoteProxy;->getCallingPid()I

    move-result v2

    invoke-virtual {v1, v2, p1}, Ltas/internal/ipc/server/ServerManager;->updateSender(ILtas/internal/ipc/server/RemoteSender;)V

    .line 104
    :goto_0
    return-void

    .line 107
    :cond_0
    const-string/jumbo v1, "TasIPC<ServerService>"

    const-string/jumbo v2, "updateSender: server is dead."

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0
.end method

.method public watchAnonymousReceiver(Ltas/internal/ipc/server/RemoteSender;)V
    .locals 3
    .param p1, "sender"    # Ltas/internal/ipc/server/RemoteSender;

    .prologue
    .line 126
    iget-object v1, p0, Ltas/internal/ipc/server/ServerService$RemoteProxy;->mM:Ljava/lang/ref/WeakReference;

    invoke-virtual {v1}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/ipc/server/ServerService;

    .line 127
    .local v0, "m":Ltas/internal/ipc/server/ServerService;
    if-eqz v0, :cond_0

    invoke-static {v0}, Ltas/internal/ipc/server/ServerService;->-get0(Ltas/internal/ipc/server/ServerService;)Ltas/internal/ipc/server/ServerManager;

    move-result-object v1

    invoke-static {}, Ltas/internal/ipc/server/ServerService$RemoteProxy;->getCallingPid()I

    move-result v2

    invoke-virtual {v1, v2, p1}, Ltas/internal/ipc/server/ServerManager;->watchAnonymousReceiver(ILtas/internal/ipc/server/RemoteSender;)V

    .line 125
    :goto_0
    return-void

    .line 128
    :cond_0
    const-string/jumbo v1, "TasIPC<ServerService>"

    const-string/jumbo v2, "watchAnonymousReceiver: server is dead."

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0
.end method

.method public watchAnonymousSender(Ltas/internal/ipc/server/RemoteReceiver;)V
    .locals 3
    .param p1, "receiver"    # Ltas/internal/ipc/server/RemoteReceiver;

    .prologue
    .line 154
    iget-object v1, p0, Ltas/internal/ipc/server/ServerService$RemoteProxy;->mM:Ljava/lang/ref/WeakReference;

    invoke-virtual {v1}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/ipc/server/ServerService;

    .line 155
    .local v0, "m":Ltas/internal/ipc/server/ServerService;
    if-eqz v0, :cond_0

    invoke-static {v0}, Ltas/internal/ipc/server/ServerService;->-get0(Ltas/internal/ipc/server/ServerService;)Ltas/internal/ipc/server/ServerManager;

    move-result-object v1

    invoke-static {}, Ltas/internal/ipc/server/ServerService$RemoteProxy;->getCallingPid()I

    move-result v2

    invoke-virtual {v1, v2, p1}, Ltas/internal/ipc/server/ServerManager;->watchAnonymousSender(ILtas/internal/ipc/server/RemoteReceiver;)V

    .line 153
    :goto_0
    return-void

    .line 156
    :cond_0
    const-string/jumbo v1, "TasIPC<ServerService>"

    const-string/jumbo v2, "watchAnonymousSender: server is dead."

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0
.end method

.method public watchReceiver(Ltas/internal/ipc/server/RemoteSender;)V
    .locals 3
    .param p1, "sender"    # Ltas/internal/ipc/server/RemoteSender;

    .prologue
    .line 112
    iget-object v1, p0, Ltas/internal/ipc/server/ServerService$RemoteProxy;->mM:Ljava/lang/ref/WeakReference;

    invoke-virtual {v1}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/ipc/server/ServerService;

    .line 113
    .local v0, "m":Ltas/internal/ipc/server/ServerService;
    if-eqz v0, :cond_0

    invoke-static {v0}, Ltas/internal/ipc/server/ServerService;->-get0(Ltas/internal/ipc/server/ServerService;)Ltas/internal/ipc/server/ServerManager;

    move-result-object v1

    invoke-static {}, Ltas/internal/ipc/server/ServerService$RemoteProxy;->getCallingPid()I

    move-result v2

    invoke-virtual {v1, v2, p1}, Ltas/internal/ipc/server/ServerManager;->watchReceiver(ILtas/internal/ipc/server/RemoteSender;)V

    .line 111
    :goto_0
    return-void

    .line 114
    :cond_0
    const-string/jumbo v1, "TasIPC<ServerService>"

    const-string/jumbo v2, "watchReceiver: server is dead."

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0
.end method

.method public watchSender(Ltas/internal/ipc/server/RemoteReceiver;)V
    .locals 3
    .param p1, "receiver"    # Ltas/internal/ipc/server/RemoteReceiver;

    .prologue
    .line 140
    iget-object v1, p0, Ltas/internal/ipc/server/ServerService$RemoteProxy;->mM:Ljava/lang/ref/WeakReference;

    invoke-virtual {v1}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/ipc/server/ServerService;

    .line 141
    .local v0, "m":Ltas/internal/ipc/server/ServerService;
    if-eqz v0, :cond_0

    invoke-static {v0}, Ltas/internal/ipc/server/ServerService;->-get0(Ltas/internal/ipc/server/ServerService;)Ltas/internal/ipc/server/ServerManager;

    move-result-object v1

    invoke-static {}, Ltas/internal/ipc/server/ServerService$RemoteProxy;->getCallingPid()I

    move-result v2

    invoke-virtual {v1, v2, p1}, Ltas/internal/ipc/server/ServerManager;->watchSender(ILtas/internal/ipc/server/RemoteReceiver;)V

    .line 139
    :goto_0
    return-void

    .line 142
    :cond_0
    const-string/jumbo v1, "TasIPC<ServerService>"

    const-string/jumbo v2, "watchSender: server is dead."

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0
.end method
