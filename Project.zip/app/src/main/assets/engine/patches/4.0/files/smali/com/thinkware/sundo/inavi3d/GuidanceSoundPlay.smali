.class public Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;
.super Ljava/lang/Object;
.source "GuidanceSoundPlay.java"


# static fields
.field static final ASYNC_MODE:I = 0x0

.field static final REV_PLAY_NOSTOP:I = 0x1

.field public static final SAMPLE_22:I = 0x5622

.field public static final SAMPLE_44:I = 0xac44

.field static final SYNC_MODE:I = 0x1

.field static final WAVE_CLICK:I = 0x1

.field static final WaveStartBroadCast:Ljava/lang/String; = "tw.intent.action.StartWave"

.field static final WaveStopBroadCast:Ljava/lang/String; = "tw.intent.action.StopWave"

.field static bSoundCancel:Z

.field static bSoundEnd:Z

.field static bSoundMute:Z

.field static bSoundStart:Z

.field static bplayclickStart:Z

.field static fiNaviVolume:I

.field static inaviactivity:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

.field public static mAudioManager:Landroid/media/AudioManager;

.field static m_mediaplayer:Landroid/media/MediaPlayer;

.field static m_mediaplayer_click:Landroid/media/MediaPlayer;

.field static m_mediaplayer_file:Landroid/media/MediaPlayer;

.field static soundthread:Ljava/lang/Thread;

.field static wave_src:[B


# instance fields
.field final FILE_DATA:I

.field final MEMORY_DATA:I

.field final PREV_PLAY_STOP:I


# direct methods
.method static constructor <clinit>()V
    .locals 3

    .prologue
    const/4 v2, 0x0

    const/4 v1, 0x0

    .line 23
    sput-object v2, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer_click:Landroid/media/MediaPlayer;

    .line 24
    sput-object v2, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer:Landroid/media/MediaPlayer;

    .line 25
    sput-object v2, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer_file:Landroid/media/MediaPlayer;

    .line 34
    sput v1, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->fiNaviVolume:I

    .line 38
    sput-boolean v1, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->bplayclickStart:Z

    .line 39
    sput-boolean v1, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->bSoundMute:Z

    .line 40
    const/4 v0, 0x1

    sput-boolean v0, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->bSoundEnd:Z

    .line 41
    sput-boolean v1, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->bSoundCancel:Z

    .line 42
    sput-boolean v1, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->bSoundStart:Z

    .line 45
    sput-object v2, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->wave_src:[B

    return-void
.end method

.method constructor <init>(Landroid/content/Context;)V
    .locals 2
    .param p1, "context"    # Landroid/content/Context;

    .prologue
    const/4 v1, 0x0

    .line 54
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 29
    iput v1, p0, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->FILE_DATA:I

    .line 30
    const/4 v0, 0x1

    iput v0, p0, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->MEMORY_DATA:I

    .line 31
    iput v1, p0, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->PREV_PLAY_STOP:I

    move-object v0, p1

    .line 55
    check-cast v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    sput-object v0, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->inaviactivity:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    .line 56
    invoke-virtual {p0, p1}, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->initSound(Landroid/content/Context;)V

    .line 57
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->initClickSound()V

    .line 58
    return-void
.end method

.method public static GetAdasVolume()I
    .locals 1

    .prologue
    .line 119
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->GetAdasVolumeSystem()I

    move-result v0

    return v0
.end method

.method public static GetAdasVolumeConfig()I
    .locals 2

    .prologue
    .line 66
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->getInstance()Lcom/thinkware/sundo/inavi3d/InaviConfig;

    move-result-object v0

    const/16 v1, 0x13b

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->CNaviConfigGet(I)I

    move-result v0

    return v0
.end method

.method public static GetAdasVolumeSystem()I
    .locals 2

    .prologue
    .line 62
    sget-object v0, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->mAudioManager:Landroid/media/AudioManager;

    sget v1, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->ADAS_STREAM_TYPE:I

    invoke-virtual {v0, v1}, Landroid/media/AudioManager;->getStreamVolume(I)I

    move-result v0

    return v0
.end method

.method public static GetInaviVolume()I
    .locals 1

    .prologue
    .line 115
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->GetInaviVolumeSystem()I

    move-result v0

    return v0
.end method

.method public static GetInaviVolumeConfig()I
    .locals 2

    .prologue
    .line 76
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->getInstance()Lcom/thinkware/sundo/inavi3d/InaviConfig;

    move-result-object v0

    const/16 v1, 0x44

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->CNaviConfigGet(I)I

    move-result v0

    return v0
.end method

.method public static GetInaviVolumeSystem()I
    .locals 2

    .prologue
    .line 72
    sget-object v0, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->mAudioManager:Landroid/media/AudioManager;

    sget v1, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->INAVI_STREAM_TYPE:I

    invoke-virtual {v0, v1}, Landroid/media/AudioManager;->getStreamVolume(I)I

    move-result v0

    return v0
.end method

.method public static SetAdasVolumeSystem(IZ)V
    .locals 3
    .param p0, "vol"    # I
    .param p1, "playsound"    # Z

    .prologue
    .line 81
    const/4 v0, 0x4

    .line 83
    .local v0, "sFlag":I
    if-nez p1, :cond_0

    .line 84
    const/4 v0, 0x0

    .line 85
    :cond_0
    sget-object v1, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->mAudioManager:Landroid/media/AudioManager;

    sget v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->ADAS_STREAM_TYPE:I

    invoke-virtual {v1, v2, p0, v0}, Landroid/media/AudioManager;->setStreamVolume(III)V

    .line 86
    return-void
.end method

.method public static SetInaviVolumeSystem(IZ)V
    .locals 3
    .param p0, "vol"    # I
    .param p1, "playsound"    # Z

    .prologue
    .line 101
    const/4 v0, 0x4

    .line 103
    .local v0, "sFlag":I
    if-nez p1, :cond_0

    .line 104
    const/4 v0, 0x0

    .line 105
    :cond_0
    sget-object v1, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->mAudioManager:Landroid/media/AudioManager;

    sget v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->INAVI_STREAM_TYPE:I

    invoke-virtual {v1, v2, p0, v0}, Landroid/media/AudioManager;->setStreamVolume(III)V

    .line 106
    return-void
.end method

.method public static SetVolumeAdas(IZ)V
    .locals 2
    .param p0, "index"    # I
    .param p1, "playsound"    # Z

    .prologue
    .line 142
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v0

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->IsDAVINCIOrder()Z

    move-result v0

    const/4 v1, 0x1

    if-ne v0, v1, :cond_0

    .line 143
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getARCameraStatus()I

    move-result v0

    if-eqz v0, :cond_0

    .line 155
    :goto_0
    return-void

    .line 148
    :cond_0
    if-gez p0, :cond_1

    .line 149
    const/4 p0, 0x0

    .line 150
    :cond_1
    const/4 v0, 0x4

    if-le p0, v0, :cond_2

    .line 151
    const/4 p0, 0x4

    .line 154
    :cond_2
    invoke-static {p0}, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->indexToVolume(I)I

    move-result p0

    invoke-static {p0, p1}, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->SetAdasVolumeSystem(IZ)V

    goto :goto_0
.end method

.method public static SetVolumeInavi(IZ)V
    .locals 3
    .param p0, "index"    # I
    .param p1, "playsound"    # Z

    .prologue
    .line 124
    if-gez p0, :cond_0

    .line 125
    const/4 p0, 0x0

    .line 126
    :cond_0
    const/4 v0, 0x4

    if-le p0, v0, :cond_1

    const/4 p0, 0x4

    .line 135
    :cond_1
    sget-object v0, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->inaviactivity:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    if-eqz v0, :cond_2

    sget-object v0, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->inaviactivity:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->guidanceSoundPlay:Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;

    if-eqz v0, :cond_2

    invoke-virtual {v0, p0}, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->SetInaviVolumeConfig(I)V

    :cond_2
    return-void
.end method

.method static SoundPlay(I)V
    .locals 5
    .param p0, "index"    # I

    .prologue
    const/4 v4, 0x1

    .line 367
    sget-boolean v2, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->bplayclickStart:Z

    if-eq v4, v2, :cond_1

    .line 369
    const-string v2, "sound"

    const-string v3, " click start - 1 "

    invoke-static {v2, v3}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 370
    if-ne p0, v4, :cond_1

    .line 372
    sput-boolean v4, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->bplayclickStart:Z

    .line 375
    :try_start_0
    sget-object v2, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer:Landroid/media/MediaPlayer;

    if-eqz v2, :cond_0

    .line 376
    sget-object v2, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer:Landroid/media/MediaPlayer;

    invoke-virtual {v2}, Landroid/media/MediaPlayer;->isPlaying()Z

    move-result v2

    if-eqz v2, :cond_0

    .line 378
    sget-object v2, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer:Landroid/media/MediaPlayer;

    invoke-virtual {v2}, Landroid/media/MediaPlayer;->stop()V

    .line 379
    const/4 v2, 0x1

    sput-boolean v2, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->bSoundEnd:Z

    .line 380
    const/4 v2, 0x0

    sput-boolean v2, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->bSoundCancel:Z

    .line 381
    sget-object v2, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->inaviactivity:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    sget-boolean v3, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->bSoundEnd:Z

    invoke-virtual {v2, v3}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->PlaySoundStatus(Z)V

    .line 382
    sget-object v2, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->inaviactivity:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    invoke-virtual {v2}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->SendVolumeResume()V

    .line 386
    :cond_0
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->getSoundVolume()F

    move-result v1

    .line 387
    .local v1, "soundVolume":F
    sget-object v2, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer_click:Landroid/media/MediaPlayer;

    invoke-virtual {v2, v1, v1}, Landroid/media/MediaPlayer;->setVolume(FF)V

    .line 388
    sget-object v2, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer_click:Landroid/media/MediaPlayer;

    sget v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->INAVI_STREAM_TYPE:I

    invoke-virtual {v2, v3}, Landroid/media/MediaPlayer;->setAudioStreamType(I)V

    .line 389
    sget-object v2, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer_click:Landroid/media/MediaPlayer;

    invoke-virtual {v2}, Landroid/media/MediaPlayer;->start()V
    :try_end_0
    .catch Ljava/lang/IllegalStateException; {:try_start_0 .. :try_end_0} :catch_0

    .line 397
    .end local v1    # "soundVolume":F
    :cond_1
    :goto_0
    return-void

    .line 390
    :catch_0
    move-exception v0

    .line 391
    .local v0, "e":Ljava/lang/IllegalStateException;
    const-string v2, "sound"

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "Click IllegalStateException"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v0}, Ljava/lang/IllegalStateException;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 392
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->readyGuideSound()V

    .line 393
    invoke-virtual {v0}, Ljava/lang/IllegalStateException;->printStackTrace()V

    goto :goto_0
.end method

.method static SoundPlay(IZ)V
    .locals 5
    .param p0, "index"    # I
    .param p1, "bClickSound"    # Z

    .prologue
    const/4 v4, 0x1

    .line 402
    sget-boolean v2, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->bplayclickStart:Z

    if-ne v4, v2, :cond_0

    if-nez p1, :cond_2

    .line 404
    :cond_0
    const-string v2, "sound"

    const-string v3, " click start - 1 "

    invoke-static {v2, v3}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 405
    if-ne p0, v4, :cond_2

    .line 407
    sput-boolean v4, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->bplayclickStart:Z

    .line 410
    :try_start_0
    sget-object v2, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer:Landroid/media/MediaPlayer;

    if-eqz v2, :cond_1

    .line 411
    sget-object v2, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer:Landroid/media/MediaPlayer;

    invoke-virtual {v2}, Landroid/media/MediaPlayer;->isPlaying()Z

    move-result v2

    if-eqz v2, :cond_1

    .line 413
    sget-object v2, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer:Landroid/media/MediaPlayer;

    invoke-virtual {v2}, Landroid/media/MediaPlayer;->stop()V

    .line 414
    const/4 v2, 0x1

    sput-boolean v2, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->bSoundEnd:Z

    .line 415
    const/4 v2, 0x0

    sput-boolean v2, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->bSoundCancel:Z

    .line 416
    sget-object v2, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->inaviactivity:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    sget-boolean v3, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->bSoundEnd:Z

    invoke-virtual {v2, v3}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->PlaySoundStatus(Z)V

    .line 417
    sget-object v2, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->inaviactivity:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    invoke-virtual {v2}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->SendVolumeResume()V

    .line 421
    :cond_1
    if-eqz p1, :cond_2

    .line 422
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->getSoundVolume()F

    move-result v1

    .line 423
    .local v1, "soundVolume":F
    sget-object v2, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer_click:Landroid/media/MediaPlayer;

    invoke-virtual {v2, v1, v1}, Landroid/media/MediaPlayer;->setVolume(FF)V

    .line 424
    sget-object v2, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer_click:Landroid/media/MediaPlayer;

    sget v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->INAVI_STREAM_TYPE:I

    invoke-virtual {v2, v3}, Landroid/media/MediaPlayer;->setAudioStreamType(I)V

    .line 425
    sget-object v2, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer_click:Landroid/media/MediaPlayer;

    invoke-virtual {v2}, Landroid/media/MediaPlayer;->start()V
    :try_end_0
    .catch Ljava/lang/IllegalStateException; {:try_start_0 .. :try_end_0} :catch_0

    .line 435
    .end local v1    # "soundVolume":F
    :cond_2
    :goto_0
    return-void

    .line 428
    :catch_0
    move-exception v0

    .line 429
    .local v0, "e":Ljava/lang/IllegalStateException;
    const-string v2, "sound"

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "Click IllegalStateException"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v0}, Ljava/lang/IllegalStateException;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 430
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->readyGuideSound()V

    .line 431
    invoke-virtual {v0}, Ljava/lang/IllegalStateException;->printStackTrace()V

    goto :goto_0
.end method

.method static SoundPlay(Ljava/lang/String;II)V
    .locals 10
    .param p0, "wavefile"    # Ljava/lang/String;
    .param p1, "playmode"    # I
    .param p2, "prevplaycontrol"    # I

    .prologue
    const/4 v9, 0x1

    const/4 v8, 0x0

    .line 438
    const-string v5, "sound"

    const-string v6, " file start - start "

    invoke-static {v5, v6}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 440
    sget-object v5, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->inaviactivity:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->SendVolumePause()V

    .line 441
    sget-boolean v5, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->bSoundEnd:Z

    if-ne v5, v9, :cond_2

    .line 443
    const-string v5, "sound"

    const-string v6, " file start - 2"

    invoke-static {v5, v6}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 444
    sput-boolean v8, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->bSoundEnd:Z

    .line 445
    sget-object v5, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->inaviactivity:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    sget-boolean v6, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->bSoundEnd:Z

    invoke-virtual {v5, v6}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->PlaySoundStatus(Z)V

    .line 446
    const/4 v1, 0x0

    .line 449
    .local v1, "istr":Ljava/io/FileInputStream;
    :try_start_0
    new-instance v2, Ljava/io/FileInputStream;

    invoke-direct {v2, p0}, Ljava/io/FileInputStream;-><init>(Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/IllegalStateException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_2

    .line 451
    .end local v1    # "istr":Ljava/io/FileInputStream;
    .local v2, "istr":Ljava/io/FileInputStream;
    :try_start_1
    sget-object v5, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer_file:Landroid/media/MediaPlayer;

    if-eqz v5, :cond_0

    .line 453
    sget-object v5, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer_file:Landroid/media/MediaPlayer;

    invoke-virtual {v5}, Landroid/media/MediaPlayer;->release()V

    .line 454
    const/4 v5, 0x0

    sput-object v5, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer_file:Landroid/media/MediaPlayer;

    .line 457
    :cond_0
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->getSoundVolume()F

    move-result v3

    .line 458
    .local v3, "soundVolume":F
    new-instance v5, Landroid/media/MediaPlayer;

    invoke-direct {v5}, Landroid/media/MediaPlayer;-><init>()V

    sput-object v5, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer_file:Landroid/media/MediaPlayer;

    .line 459
    sget-object v5, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer_file:Landroid/media/MediaPlayer;

    invoke-virtual {v5, v3, v3}, Landroid/media/MediaPlayer;->setVolume(FF)V

    .line 460
    sget-object v5, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer_file:Landroid/media/MediaPlayer;

    sget v6, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->INAVI_STREAM_TYPE:I

    invoke-virtual {v5, v6}, Landroid/media/MediaPlayer;->setAudioStreamType(I)V

    .line 461
    sget-object v5, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer_file:Landroid/media/MediaPlayer;

    invoke-virtual {v2}, Ljava/io/FileInputStream;->getFD()Ljava/io/FileDescriptor;

    move-result-object v6

    invoke-virtual {v5, v6}, Landroid/media/MediaPlayer;->setDataSource(Ljava/io/FileDescriptor;)V

    .line 462
    const-string v5, "sound"

    const-string v6, " file start - prepare"

    invoke-static {v5, v6}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 463
    sget-object v5, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer_file:Landroid/media/MediaPlayer;

    invoke-virtual {v5}, Landroid/media/MediaPlayer;->prepare()V

    .line 464
    sget-object v5, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer_file:Landroid/media/MediaPlayer;

    new-instance v6, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay$3;

    invoke-direct {v6}, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay$3;-><init>()V

    invoke-virtual {v5, v6}, Landroid/media/MediaPlayer;->setOnCompletionListener(Landroid/media/MediaPlayer$OnCompletionListener;)V

    .line 477
    new-instance v4, Landroid/content/Intent;

    invoke-direct {v4}, Landroid/content/Intent;-><init>()V

    .line 478
    .local v4, "startintent":Landroid/content/Intent;
    const-string v5, "tw.intent.action.StartWave"

    invoke-virtual {v4, v5}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    .line 479
    const-string v5, "duration"

    sget-object v6, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer_file:Landroid/media/MediaPlayer;

    invoke-virtual {v6}, Landroid/media/MediaPlayer;->getDuration()I

    move-result v6

    invoke-virtual {v4, v5, v6}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 480
    sget-object v5, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->inaviactivity:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    invoke-virtual {v5, v4}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->sendBroadcast(Landroid/content/Intent;)V

    .line 481
    sget-object v5, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer_file:Landroid/media/MediaPlayer;

    invoke-virtual {v5}, Landroid/media/MediaPlayer;->start()V

    .line 482
    const-string v5, "sound"

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, " file start - play Time: "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    sget-object v7, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer_file:Landroid/media/MediaPlayer;

    invoke-virtual {v7}, Landroid/media/MediaPlayer;->getDuration()I

    move-result v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v5, v6}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 483
    invoke-virtual {v2}, Ljava/io/FileInputStream;->close()V
    :try_end_1
    .catch Ljava/lang/IllegalArgumentException; {:try_start_1 .. :try_end_1} :catch_6
    .catch Ljava/lang/IllegalStateException; {:try_start_1 .. :try_end_1} :catch_5
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_4

    .line 510
    .end local v2    # "istr":Ljava/io/FileInputStream;
    .end local v3    # "soundVolume":F
    .end local v4    # "startintent":Landroid/content/Intent;
    :goto_0
    return-void

    .line 485
    .restart local v1    # "istr":Ljava/io/FileInputStream;
    :catch_0
    move-exception v0

    .line 486
    .local v0, "e":Ljava/lang/IllegalArgumentException;
    :goto_1
    const-string v5, "sound"

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, " IllegalArgumentException"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v0}, Ljava/lang/IllegalArgumentException;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v5, v6}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 487
    invoke-virtual {v0}, Ljava/lang/IllegalArgumentException;->printStackTrace()V

    .line 495
    .end local v0    # "e":Ljava/lang/IllegalArgumentException;
    :goto_2
    if-eqz v1, :cond_1

    .line 497
    :try_start_2
    invoke-virtual {v1}, Ljava/io/FileInputStream;->close()V
    :try_end_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_3

    .line 503
    :cond_1
    :goto_3
    sput-boolean v9, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->bSoundEnd:Z

    .line 504
    sput-boolean v8, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->bSoundCancel:Z

    .line 505
    sget-object v5, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->inaviactivity:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    sget-boolean v6, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->bSoundEnd:Z

    invoke-virtual {v5, v6}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->PlaySoundStatus(Z)V

    .line 506
    const-string v5, "sound"

    const-string v6, " file start - 4"

    invoke-static {v5, v6}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 508
    .end local v1    # "istr":Ljava/io/FileInputStream;
    :cond_2
    sget-object v5, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->inaviactivity:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->SendVolumeResume()V

    .line 509
    const-string v5, "sound"

    const-string v6, " file start - end "

    invoke-static {v5, v6}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_0

    .line 488
    .restart local v1    # "istr":Ljava/io/FileInputStream;
    :catch_1
    move-exception v0

    .line 489
    .local v0, "e":Ljava/lang/IllegalStateException;
    :goto_4
    const-string v5, "sound"

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "IllegalStateException"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v0}, Ljava/lang/IllegalStateException;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v5, v6}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 490
    invoke-virtual {v0}, Ljava/lang/IllegalStateException;->printStackTrace()V

    goto :goto_2

    .line 491
    .end local v0    # "e":Ljava/lang/IllegalStateException;
    :catch_2
    move-exception v0

    .line 492
    .local v0, "e":Ljava/io/IOException;
    :goto_5
    const-string v5, "sound"

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "IOException2"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v0}, Ljava/io/IOException;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v5, v6}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 493
    invoke-virtual {v0}, Ljava/io/IOException;->printStackTrace()V

    goto :goto_2

    .line 498
    .end local v0    # "e":Ljava/io/IOException;
    :catch_3
    move-exception v0

    .line 500
    .restart local v0    # "e":Ljava/io/IOException;
    invoke-virtual {v0}, Ljava/io/IOException;->printStackTrace()V

    goto :goto_3

    .line 491
    .end local v0    # "e":Ljava/io/IOException;
    .end local v1    # "istr":Ljava/io/FileInputStream;
    .restart local v2    # "istr":Ljava/io/FileInputStream;
    :catch_4
    move-exception v0

    move-object v1, v2

    .end local v2    # "istr":Ljava/io/FileInputStream;
    .restart local v1    # "istr":Ljava/io/FileInputStream;
    goto :goto_5

    .line 488
    .end local v1    # "istr":Ljava/io/FileInputStream;
    .restart local v2    # "istr":Ljava/io/FileInputStream;
    :catch_5
    move-exception v0

    move-object v1, v2

    .end local v2    # "istr":Ljava/io/FileInputStream;
    .restart local v1    # "istr":Ljava/io/FileInputStream;
    goto :goto_4

    .line 485
    .end local v1    # "istr":Ljava/io/FileInputStream;
    .restart local v2    # "istr":Ljava/io/FileInputStream;
    :catch_6
    move-exception v0

    move-object v1, v2

    .end local v2    # "istr":Ljava/io/FileInputStream;
    .restart local v1    # "istr":Ljava/io/FileInputStream;
    goto/16 :goto_1
.end method

.method static SoundPlay([BII)Z
    .locals 1
    .param p0, "src"    # [B
    .param p1, "playmode"    # I
    .param p2, "prevplaycontrol"    # I

    .prologue
    .line 343
    const/4 v0, 0x0

    invoke-static {p0, v0}, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->playstream([BZ)Z

    move-result v0

    return v0
.end method

.method static getSoundVolume()F
    .locals 4

    .prologue
    .line 201
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->GetInaviVolumeConfig()I

    move-result v0

    .line 202
    .local v0, "inaviVolume":I
    if-gez v0, :cond_0

    const/4 v0, 0x0

    :cond_0
    const/4 v1, 0x4

    if-le v0, v1, :cond_1

    const/4 v0, 0x4

    :cond_1
    int-to-float v2, v0

    const/high16 v3, 0x40800000    # 4.0f

    div-float/2addr v2, v3

    return v2
.end method

.method static iNavisysVolume(F)V
    .locals 0
    .param p0, "fVolume"    # F

    .prologue
    .line 198
    return-void
.end method

.method public static indexToVolume(I)I
    .locals 4
    .param p0, "index"    # I

    .prologue
    .line 519
    sget-object v0, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->mAudioManager:Landroid/media/AudioManager;

    sget v1, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->INAVI_STREAM_TYPE:I

    invoke-virtual {v0, v1}, Landroid/media/AudioManager;->getStreamMaxVolume(I)I

    move-result v1

    .line 521
    .local v1, "maxVol":I
    if-gez p0, :cond_0

    const/4 p0, 0x0

    :cond_0
    const/4 v2, 0x4

    if-le p0, v2, :cond_1

    const/4 p0, 0x4

    :cond_1
    mul-int v2, p0, v1

    add-int/lit8 v2, v2, 0x2

    div-int/lit8 v2, v2, 0x4

    if-gez v2, :cond_2

    const/4 v2, 0x0

    :cond_2
    if-le v2, v1, :cond_3

    move v2, v1

    :cond_3
    return v2
.end method

.method static initClickSound()V
    .locals 2

    .prologue
    .line 353
    const/4 v0, 0x0

    sput-object v0, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer_click:Landroid/media/MediaPlayer;

    .line 354
    new-instance v0, Landroid/media/MediaPlayer;

    invoke-direct {v0}, Landroid/media/MediaPlayer;-><init>()V

    sput-object v0, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer_click:Landroid/media/MediaPlayer;

    .line 355
    sget-object v0, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->inaviactivity:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    const/high16 v1, 0x7f050000

    invoke-static {v0, v1}, Landroid/media/MediaPlayer;->create(Landroid/content/Context;I)Landroid/media/MediaPlayer;

    move-result-object v0

    sput-object v0, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer_click:Landroid/media/MediaPlayer;

    .line 356
    sget-object v0, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer_click:Landroid/media/MediaPlayer;

    new-instance v1, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay$2;

    invoke-direct {v1}, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay$2;-><init>()V

    invoke-virtual {v0, v1}, Landroid/media/MediaPlayer;->setOnCompletionListener(Landroid/media/MediaPlayer$OnCompletionListener;)V

    .line 362
    return-void
.end method

.method static playstream([BZ)Z
    .locals 12
    .param p0, "src"    # [B
    .param p1, "samplePlay"    # Z

    .prologue
    const/4 v8, 0x1

    const/4 v7, 0x0

    .line 250
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    move-result-object v9

    invoke-virtual {v9}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getSuperCapPowerOff()Z

    move-result v9

    if-ne v9, v8, :cond_1

    .line 329
    :cond_0
    :goto_0
    return v7

    .line 255
    :cond_1
    sget-boolean v9, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->bSoundEnd:Z

    if-ne v9, v8, :cond_0

    .line 259
    const/4 v9, 0x0

    :try_start_0
    sput-boolean v9, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->bSoundEnd:Z

    .line 260
    sget-object v9, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->inaviactivity:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    sget-boolean v10, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->bSoundEnd:Z

    invoke-virtual {v9, v10}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->PlaySoundStatus(Z)V

    .line 261
    sget-object v9, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->inaviactivity:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    invoke-virtual {v9}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->SendVolumePause()V

    .line 264
    if-eqz p1, :cond_3

    .line 265
    new-instance v6, Ljava/lang/String;

    invoke-direct {v6, p0}, Ljava/lang/String;-><init>([B)V

    .line 274
    .local v6, "str_wave_path":Ljava/lang/String;
    :goto_1
    const-string v9, "wavewave"

    invoke-static {v9, v6}, Lcom/thinkware/sundo/inavi3d/LOGTW;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 278
    new-instance v3, Ljava/io/FileInputStream;

    invoke-direct {v3, v6}, Ljava/io/FileInputStream;-><init>(Ljava/lang/String;)V

    .line 280
    .local v3, "istr":Ljava/io/FileInputStream;
    sget-object v9, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer:Landroid/media/MediaPlayer;

    if-eqz v9, :cond_2

    .line 282
    sget-object v9, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer:Landroid/media/MediaPlayer;

    invoke-virtual {v9}, Landroid/media/MediaPlayer;->release()V

    .line 283
    const/4 v9, 0x0

    sput-object v9, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer:Landroid/media/MediaPlayer;

    .line 285
    :cond_2
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->getSoundVolume()F

    move-result v4

    .line 286
    .local v4, "soundVolume":F
    new-instance v9, Landroid/media/MediaPlayer;

    invoke-direct {v9}, Landroid/media/MediaPlayer;-><init>()V

    sput-object v9, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer:Landroid/media/MediaPlayer;

    .line 287
    sget-object v9, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer:Landroid/media/MediaPlayer;

    invoke-virtual {v9, v4, v4}, Landroid/media/MediaPlayer;->setVolume(FF)V

    .line 288
    sget-object v9, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer:Landroid/media/MediaPlayer;

    sget v10, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->INAVI_STREAM_TYPE:I

    invoke-virtual {v9, v10}, Landroid/media/MediaPlayer;->setAudioStreamType(I)V

    .line 289
    sget-object v9, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer:Landroid/media/MediaPlayer;

    invoke-virtual {v3}, Ljava/io/FileInputStream;->getFD()Ljava/io/FileDescriptor;

    move-result-object v10

    invoke-virtual {v9, v10}, Landroid/media/MediaPlayer;->setDataSource(Ljava/io/FileDescriptor;)V

    .line 290
    sget-object v9, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer:Landroid/media/MediaPlayer;

    invoke-virtual {v9}, Landroid/media/MediaPlayer;->prepare()V

    .line 291
    sget-object v9, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer:Landroid/media/MediaPlayer;

    new-instance v10, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay$1;

    invoke-direct {v10}, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay$1;-><init>()V

    invoke-virtual {v9, v10}, Landroid/media/MediaPlayer;->setOnCompletionListener(Landroid/media/MediaPlayer$OnCompletionListener;)V

    .line 306
    new-instance v5, Landroid/content/Intent;

    invoke-direct {v5}, Landroid/content/Intent;-><init>()V

    .line 307
    .local v5, "startintent":Landroid/content/Intent;
    const-string v9, "tw.intent.action.StartWave"

    invoke-virtual {v5, v9}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    .line 308
    const-string v9, "duration"

    sget-object v10, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer:Landroid/media/MediaPlayer;

    invoke-virtual {v10}, Landroid/media/MediaPlayer;->getDuration()I

    move-result v10

    invoke-virtual {v5, v9, v10}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 309
    sget-object v9, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->inaviactivity:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    invoke-virtual {v9, v5}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->sendBroadcast(Landroid/content/Intent;)V

    .line 311
    sget-object v9, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer:Landroid/media/MediaPlayer;

    invoke-virtual {v9}, Landroid/media/MediaPlayer;->start()V

    .line 312
    const-string v9, "wavewave"

    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    const-string v11, "waveStart Time: "

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    sget-object v11, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer:Landroid/media/MediaPlayer;

    invoke-virtual {v11}, Landroid/media/MediaPlayer;->getDuration()I

    move-result v11

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v10

    invoke-static {v9, v10}, Lcom/thinkware/sundo/inavi3d/LOGTW;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 314
    invoke-virtual {v3}, Ljava/io/FileInputStream;->close()V

    move v7, v8

    .line 315
    goto/16 :goto_0

    .line 267
    .end local v3    # "istr":Ljava/io/FileInputStream;
    .end local v4    # "soundVolume":F
    .end local v5    # "startintent":Landroid/content/Intent;
    .end local v6    # "str_wave_path":Ljava/lang/String;
    :cond_3
    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    sget-object v10, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->DATA_DIRECTORY:Ljava/lang/String;

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    const-string v10, "/guidesound.wav"

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    .line 269
    .restart local v6    # "str_wave_path":Ljava/lang/String;
    new-instance v0, Ljava/io/FileOutputStream;

    invoke-direct {v0, v6}, Ljava/io/FileOutputStream;-><init>(Ljava/lang/String;)V

    .line 271
    .local v0, "buf":Ljava/io/FileOutputStream;
    const/4 v9, 0x0

    array-length v10, p0

    invoke-virtual {v0, p0, v9, v10}, Ljava/io/FileOutputStream;->write([BII)V

    .line 272
    invoke-virtual {v0}, Ljava/io/FileOutputStream;->close()V
    :try_end_0
    .catch Ljava/io/FileNotFoundException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_2
    .catch Ljava/lang/IllegalStateException; {:try_start_0 .. :try_end_0} :catch_3

    goto/16 :goto_1

    .line 316
    .end local v0    # "buf":Ljava/io/FileOutputStream;
    .end local v6    # "str_wave_path":Ljava/lang/String;
    :catch_0
    move-exception v2

    .line 317
    .local v2, "e1":Ljava/io/FileNotFoundException;
    invoke-virtual {v2}, Ljava/io/FileNotFoundException;->printStackTrace()V

    .line 326
    .end local v2    # "e1":Ljava/io/FileNotFoundException;
    :goto_2
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->readyGuideSound()V

    goto/16 :goto_0

    .line 318
    :catch_1
    move-exception v1

    .line 319
    .local v1, "e":Ljava/io/IOException;
    invoke-virtual {v1}, Ljava/io/IOException;->printStackTrace()V

    goto :goto_2

    .line 320
    .end local v1    # "e":Ljava/io/IOException;
    :catch_2
    move-exception v1

    .line 321
    .local v1, "e":Ljava/lang/IllegalArgumentException;
    invoke-virtual {v1}, Ljava/lang/IllegalArgumentException;->printStackTrace()V

    goto :goto_2

    .line 322
    .end local v1    # "e":Ljava/lang/IllegalArgumentException;
    :catch_3
    move-exception v1

    .line 323
    .local v1, "e":Ljava/lang/IllegalStateException;
    invoke-virtual {v1}, Ljava/lang/IllegalStateException;->printStackTrace()V

    goto :goto_2
.end method

.method private static readyGuideSound()V
    .locals 2

    .prologue
    const/4 v1, 0x0

    .line 333
    sput-boolean v1, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->bplayclickStart:Z

    .line 334
    const/4 v0, 0x1

    sput-boolean v0, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->bSoundEnd:Z

    .line 335
    sput-boolean v1, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->bSoundCancel:Z

    .line 336
    sget-object v0, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->inaviactivity:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    sget-boolean v1, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->bSoundEnd:Z

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->PlaySoundStatus(Z)V

    .line 337
    sget-object v0, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->inaviactivity:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->SendVolumeResume()V

    .line 338
    sget-object v0, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer:Landroid/media/MediaPlayer;

    if-eqz v0, :cond_0

    .line 339
    sget-object v0, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer:Landroid/media/MediaPlayer;

    invoke-virtual {v0}, Landroid/media/MediaPlayer;->stop()V

    .line 340
    :cond_0
    return-void
.end method

.method public static releaseClickSound()V
    .locals 2

    .prologue
    .line 347
    const-string v0, "sound"

    const-string v1, " releaseClickSound "

    invoke-static {v0, v1}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 348
    sget-object v0, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer_click:Landroid/media/MediaPlayer;

    invoke-virtual {v0}, Landroid/media/MediaPlayer;->release()V

    .line 349
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->initClickSound()V

    .line 350
    return-void
.end method

.method public static volumeToIndex(I)I
    .locals 5
    .param p0, "vol"    # I

    .prologue
    .line 506
    const/4 v0, 0x0

    .line 508
    .local v0, "retIdx":I
    if-nez p0, :cond_0

    return v0

    :cond_0
    sget-object v1, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->mAudioManager:Landroid/media/AudioManager;

    sget v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->INAVI_STREAM_TYPE:I

    invoke-virtual {v1, v2}, Landroid/media/AudioManager;->getStreamMaxVolume(I)I

    move-result v2

    if-gtz v2, :cond_1

    return v0

    :cond_1
    if-gez p0, :cond_2

    const/4 p0, 0x0

    :cond_2
    if-le p0, v2, :cond_3

    move p0, v2

    :cond_3
    mul-int/lit8 v3, p0, 0x4

    div-int/lit8 v4, v2, 0x2

    add-int/2addr v3, v4

    div-int v0, v3, v2

    if-gez v0, :cond_4

    const/4 v0, 0x0

    :cond_4
    const/4 v4, 0x4

    if-le v0, v4, :cond_5

    const/4 v0, 0x4

    :cond_5
    return v0
.end method


# virtual methods
.method public SetAdasVolumeConfig(I)V
    .locals 2
    .param p1, "vol"    # I

    .prologue
    .line 89
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v0

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->IsDAVINCIOrder()Z

    move-result v0

    const/4 v1, 0x1

    if-ne v0, v1, :cond_0

    .line 90
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getARCameraStatus()I

    move-result v0

    if-eqz v0, :cond_0

    .line 97
    :goto_0
    return-void

    .line 95
    :cond_0
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->getInstance()Lcom/thinkware/sundo/inavi3d/InaviConfig;

    move-result-object v0

    const/16 v1, 0x13b

    invoke-virtual {v0, v1, p1}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->CNaviConfigSet(II)Z

    .line 96
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->getInstance()Lcom/thinkware/sundo/inavi3d/InaviConfig;

    move-result-object v0

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->SetConfigSave()Z

    goto :goto_0
.end method

.method public SetInaviVolumeConfig(I)V
    .locals 2
    .param p1, "vol"    # I

    .prologue
    .line 109
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->getInstance()Lcom/thinkware/sundo/inavi3d/InaviConfig;

    move-result-object v0

    const/16 v1, 0x44

    invoke-virtual {v0, v1, p1}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->CNaviConfigSet(II)Z

    .line 110
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->getInstance()Lcom/thinkware/sundo/inavi3d/InaviConfig;

    move-result-object v0

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->SetConfigSave()Z

    .line 111
    return-void
.end method

.method initSound(Landroid/content/Context;)V
    .locals 1
    .param p1, "context"    # Landroid/content/Context;

    .prologue
    .line 514
    const-string v0, "audio"

    invoke-virtual {p1, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/media/AudioManager;

    sput-object v0, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->mAudioManager:Landroid/media/AudioManager;

    .line 515
    return-void
.end method
