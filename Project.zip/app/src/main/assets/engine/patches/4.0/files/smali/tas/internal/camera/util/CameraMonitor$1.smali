.class Ltas/internal/camera/util/CameraMonitor$1;
.super Ljava/lang/Object;
.source "CameraMonitor.java"

# interfaces
.implements Landroid/os/IBinder$DeathRecipient;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltas/internal/camera/util/CameraMonitor;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Ltas/internal/camera/util/CameraMonitor;


# direct methods
.method constructor <init>(Ltas/internal/camera/util/CameraMonitor;)V
    .locals 0
    .param p1, "this$0"    # Ltas/internal/camera/util/CameraMonitor;

    .prologue
    .line 368
    iput-object p1, p0, Ltas/internal/camera/util/CameraMonitor$1;->this$0:Ltas/internal/camera/util/CameraMonitor;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public binderDied()V
    .locals 3

    .prologue
    const/4 v2, 0x0

    .line 371
    iget-object v0, p0, Ltas/internal/camera/util/CameraMonitor$1;->this$0:Ltas/internal/camera/util/CameraMonitor;

    invoke-static {v0}, Ltas/internal/camera/util/CameraMonitor;->-get0(Ltas/internal/camera/util/CameraMonitor;)Ljava/lang/String;

    move-result-object v0

    const-string/jumbo v1, "binderDied"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 373
    iget-object v0, p0, Ltas/internal/camera/util/CameraMonitor$1;->this$0:Ltas/internal/camera/util/CameraMonitor;

    invoke-static {v0, v2}, Ltas/internal/camera/util/CameraMonitor;->-set0(Ltas/internal/camera/util/CameraMonitor;Landroid/os/IBinder;)Landroid/os/IBinder;

    .line 374
    iget-object v0, p0, Ltas/internal/camera/util/CameraMonitor$1;->this$0:Ltas/internal/camera/util/CameraMonitor;

    invoke-static {v0, v2}, Ltas/internal/camera/util/CameraMonitor;->-set1(Ltas/internal/camera/util/CameraMonitor;Landroid/hardware/ICameraService;)Landroid/hardware/ICameraService;

    .line 375
    iget-object v0, p0, Ltas/internal/camera/util/CameraMonitor$1;->this$0:Ltas/internal/camera/util/CameraMonitor;

    const/4 v1, 0x0

    invoke-static {v0, v1}, Ltas/internal/camera/util/CameraMonitor;->-set2(Ltas/internal/camera/util/CameraMonitor;Z)Z

    .line 377
    iget-object v0, p0, Ltas/internal/camera/util/CameraMonitor$1;->this$0:Ltas/internal/camera/util/CameraMonitor;

    invoke-static {v0}, Ltas/internal/camera/util/CameraMonitor;->-get2(Ltas/internal/camera/util/CameraMonitor;)Ltas/internal/camera/util/CameraMonitor$H;

    move-result-object v0

    new-instance v1, Ltas/internal/camera/util/CameraMonitor$1$1;

    invoke-direct {v1, p0}, Ltas/internal/camera/util/CameraMonitor$1$1;-><init>(Ltas/internal/camera/util/CameraMonitor$1;)V

    invoke-virtual {v0, v1}, Ltas/internal/camera/util/CameraMonitor$H;->post(Ljava/lang/Runnable;)Z

    .line 370
    return-void
.end method
