.class Ltas/internal/camera/Dispatcher;
.super Ljava/lang/Object;
.source "Dispatcher.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ltas/internal/camera/Dispatcher$EventQueue;
    }
.end annotation


# static fields
.field private static final DBG:Z = true

.field private static final TAG:Ljava/lang/String; = "TasCAM<Dispatcher>"


# instance fields
.field channel:Ltas/internal/camera/InputChannel;

.field private mPendings:Ljava/util/Queue;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Queue",
            "<",
            "Ltas/internal/camera/server/RemoteMessage;",
            ">;"
        }
    .end annotation
.end field

.field q:Ltas/internal/camera/Dispatcher$EventQueue;

.field server:Ltas/internal/camera/server/ServerOutGoing;


# direct methods
.method static synthetic -wrap0(Ltas/internal/camera/Dispatcher;Ltas/internal/camera/server/RemoteMessage;)Z
    .locals 1
    .param p1, "msg"    # Ltas/internal/camera/server/RemoteMessage;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/camera/Dispatcher;->onCableState(Ltas/internal/camera/server/RemoteMessage;)Z

    move-result v0

    return v0
.end method

.method static synthetic -wrap1(Ltas/internal/camera/Dispatcher;Ltas/internal/camera/server/RemoteMessage;)Z
    .locals 1
    .param p1, "msg"    # Ltas/internal/camera/server/RemoteMessage;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/camera/Dispatcher;->onCameraMessage(Ltas/internal/camera/server/RemoteMessage;)Z

    move-result v0

    return v0
.end method

.method static synthetic -wrap2(Ltas/internal/camera/Dispatcher;Ltas/internal/camera/server/RemoteMessage;)Z
    .locals 1
    .param p1, "msg"    # Ltas/internal/camera/server/RemoteMessage;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/camera/Dispatcher;->onCameraState(Ltas/internal/camera/server/RemoteMessage;)Z

    move-result v0

    return v0
.end method

.method static synthetic -wrap3(Ltas/internal/camera/Dispatcher;Ltas/internal/camera/server/RemoteMessage;)Z
    .locals 1
    .param p1, "msg"    # Ltas/internal/camera/server/RemoteMessage;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/camera/Dispatcher;->onEvent(Ltas/internal/camera/server/RemoteMessage;)Z

    move-result v0

    return v0
.end method

.method static synthetic -wrap4(Ltas/internal/camera/Dispatcher;Ltas/internal/camera/server/RemoteMessage;)Z
    .locals 1
    .param p1, "msg"    # Ltas/internal/camera/server/RemoteMessage;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/camera/Dispatcher;->onExtraState(Ltas/internal/camera/server/RemoteMessage;)Z

    move-result v0

    return v0
.end method

.method static synthetic -wrap5(Ltas/internal/camera/Dispatcher;Ltas/internal/camera/server/RemoteMessage;)Z
    .locals 1
    .param p1, "msg"    # Ltas/internal/camera/server/RemoteMessage;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/camera/Dispatcher;->onMediaServerState(Ltas/internal/camera/server/RemoteMessage;)Z

    move-result v0

    return v0
.end method

.method static synthetic -wrap6(Ltas/internal/camera/Dispatcher;Ltas/internal/camera/server/RemoteMessage;)Z
    .locals 1
    .param p1, "msg"    # Ltas/internal/camera/server/RemoteMessage;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/camera/Dispatcher;->post(Ltas/internal/camera/server/RemoteMessage;)Z

    move-result v0

    return v0
.end method

.method constructor <init>(Ltas/internal/camera/server/ServerOutGoing;)V
    .locals 0
    .param p1, "_server"    # Ltas/internal/camera/server/ServerOutGoing;

    .prologue
    .line 29
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 30
    iput-object p1, p0, Ltas/internal/camera/Dispatcher;->server:Ltas/internal/camera/server/ServerOutGoing;

    .line 29
    return-void
.end method

.method private addEvent(Ltas/internal/camera/server/RemoteMessage;)V
    .locals 2
    .param p1, "msg"    # Ltas/internal/camera/server/RemoteMessage;

    .prologue
    .line 188
    iget-object v1, p0, Ltas/internal/camera/Dispatcher;->q:Ltas/internal/camera/Dispatcher$EventQueue;

    if-eqz v1, :cond_0

    .line 189
    iget-object v1, p0, Ltas/internal/camera/Dispatcher;->q:Ltas/internal/camera/Dispatcher$EventQueue;

    invoke-virtual {v1, p1}, Ltas/internal/camera/Dispatcher$EventQueue;->offer(Ljava/lang/Object;)V

    .line 187
    :goto_0
    return-void

    .line 191
    :cond_0
    const/4 v0, 0x0

    .line 192
    .local v0, "ready":Z
    iget-object v1, p1, Ltas/internal/camera/server/RemoteMessage;->params:Ltas/internal/camera/InputParams;

    iget v1, v1, Ltas/internal/camera/InputParams;->what:I

    packed-switch v1, :pswitch_data_0

    .line 214
    invoke-direct {p0, p1}, Ltas/internal/camera/Dispatcher;->onEvent(Ltas/internal/camera/server/RemoteMessage;)Z

    move-result v0

    .line 218
    .local v0, "ready":Z
    :goto_1
    if-eqz v0, :cond_1

    .line 219
    invoke-direct {p0, p1}, Ltas/internal/camera/Dispatcher;->post(Ltas/internal/camera/server/RemoteMessage;)Z

    goto :goto_0

    .line 194
    .local v0, "ready":Z
    :pswitch_0
    invoke-direct {p0, p1}, Ltas/internal/camera/Dispatcher;->onCableState(Ltas/internal/camera/server/RemoteMessage;)Z

    move-result v0

    .local v0, "ready":Z
    goto :goto_1

    .line 198
    .local v0, "ready":Z
    :pswitch_1
    invoke-direct {p0, p1}, Ltas/internal/camera/Dispatcher;->onCameraState(Ltas/internal/camera/server/RemoteMessage;)Z

    move-result v0

    .local v0, "ready":Z
    goto :goto_1

    .line 202
    .local v0, "ready":Z
    :pswitch_2
    invoke-direct {p0, p1}, Ltas/internal/camera/Dispatcher;->onCameraMessage(Ltas/internal/camera/server/RemoteMessage;)Z

    move-result v0

    .local v0, "ready":Z
    goto :goto_1

    .line 206
    .local v0, "ready":Z
    :pswitch_3
    invoke-direct {p0, p1}, Ltas/internal/camera/Dispatcher;->onMediaServerState(Ltas/internal/camera/server/RemoteMessage;)Z

    move-result v0

    .local v0, "ready":Z
    goto :goto_1

    .line 210
    .local v0, "ready":Z
    :pswitch_4
    invoke-direct {p0, p1}, Ltas/internal/camera/Dispatcher;->onExtraState(Ltas/internal/camera/server/RemoteMessage;)Z

    move-result v0

    .local v0, "ready":Z
    goto :goto_1

    .line 221
    :cond_1
    invoke-virtual {p1}, Ltas/internal/camera/server/RemoteMessage;->recycle()V

    goto :goto_0

    .line 192
    nop

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_0
        :pswitch_1
        :pswitch_2
        :pswitch_4
        :pswitch_3
    .end packed-switch
.end method

.method private addPendingEvent(Ltas/internal/camera/server/RemoteMessage;)V
    .locals 2
    .param p1, "msg"    # Ltas/internal/camera/server/RemoteMessage;

    .prologue
    .line 227
    iget-object v0, p0, Ltas/internal/camera/Dispatcher;->mPendings:Ljava/util/Queue;

    if-nez v0, :cond_0

    .line 228
    new-instance v0, Ljava/util/ArrayDeque;

    const/4 v1, 0x2

    invoke-direct {v0, v1}, Ljava/util/ArrayDeque;-><init>(I)V

    iput-object v0, p0, Ltas/internal/camera/Dispatcher;->mPendings:Ljava/util/Queue;

    .line 230
    :cond_0
    iget-object v0, p0, Ltas/internal/camera/Dispatcher;->mPendings:Ljava/util/Queue;

    invoke-interface {v0, p1}, Ljava/util/Queue;->offer(Ljava/lang/Object;)Z

    .line 226
    return-void
.end method

.method private createCableEvent(Ltas/internal/camera/InputSourceInner;Z)Ltas/internal/camera/server/RemoteMessage;
    .locals 6
    .param p1, "input"    # Ltas/internal/camera/InputSourceInner;
    .param p2, "plugged"    # Z

    .prologue
    const/4 v2, 0x1

    const/4 v4, 0x0

    .line 130
    if-eqz p2, :cond_0

    move v3, v2

    :goto_0
    const/4 v5, 0x0

    move-object v0, p0

    move-object v1, p1

    .line 129
    invoke-direct/range {v0 .. v5}, Ltas/internal/camera/Dispatcher;->createEvent(Ltas/internal/camera/InputSourceInner;IIILjava/lang/String;)Ltas/internal/camera/server/RemoteMessage;

    move-result-object v0

    return-object v0

    :cond_0
    move v3, v4

    .line 130
    goto :goto_0
.end method

.method private createCameraEvent(Ltas/internal/camera/InputSourceInner;Z)Ltas/internal/camera/server/RemoteMessage;
    .locals 6
    .param p1, "input"    # Ltas/internal/camera/InputSourceInner;
    .param p2, "opened"    # Z

    .prologue
    const/4 v4, 0x0

    .line 136
    if-eqz p2, :cond_0

    const/4 v3, 0x1

    .line 135
    :goto_0
    const/4 v2, 0x2

    .line 136
    const/4 v5, 0x0

    move-object v0, p0

    move-object v1, p1

    .line 135
    invoke-direct/range {v0 .. v5}, Ltas/internal/camera/Dispatcher;->createEvent(Ltas/internal/camera/InputSourceInner;IIILjava/lang/String;)Ltas/internal/camera/server/RemoteMessage;

    move-result-object v0

    return-object v0

    :cond_0
    move v3, v4

    .line 136
    goto :goto_0
.end method

.method private createEvent(Ltas/internal/camera/InputSourceInner;IIILjava/lang/String;)Ltas/internal/camera/server/RemoteMessage;
    .locals 3
    .param p1, "input"    # Ltas/internal/camera/InputSourceInner;
    .param p2, "what"    # I
    .param p3, "arg1"    # I
    .param p4, "arg2"    # I
    .param p5, "proc"    # Ljava/lang/String;

    .prologue
    const/4 v2, 0x0

    .line 160
    invoke-static {}, Ltas/internal/camera/server/RemoteMessage;->obtain()Ltas/internal/camera/server/RemoteMessage;

    move-result-object v0

    .line 161
    .local v0, "ev":Ltas/internal/camera/server/RemoteMessage;
    iget-object v1, v0, Ltas/internal/camera/server/RemoteMessage;->params:Ltas/internal/camera/InputParams;

    .line 162
    .local v1, "params":Ltas/internal/camera/InputParams;
    if-eqz p1, :cond_0

    iget-object v2, p1, Ltas/internal/camera/InputSourceInner;->camcls:Ljava/lang/String;

    :cond_0
    iput-object v2, v1, Ltas/internal/camera/InputParams;->cam:Ljava/lang/String;

    .line 163
    iput p2, v1, Ltas/internal/camera/InputParams;->what:I

    .line 164
    iget-object v2, v1, Ltas/internal/camera/InputParams;->msg:Ltas/camera/CameraMessage;

    iput p3, v2, Ltas/camera/CameraMessage;->arg1:I

    .line 165
    iget-object v2, v1, Ltas/internal/camera/InputParams;->msg:Ltas/camera/CameraMessage;

    iput p4, v2, Ltas/camera/CameraMessage;->arg2:I

    .line 166
    const/4 v2, 0x0

    iput v2, v1, Ltas/internal/camera/InputParams;->pid:I

    .line 167
    iput-object p5, v1, Ltas/internal/camera/InputParams;->proc:Ljava/lang/String;

    .line 168
    return-object v0
.end method

.method private createEvent(Ltas/internal/camera/InputSourceInner;ILtas/camera/CameraMessage;Ljava/lang/String;)Ltas/internal/camera/server/RemoteMessage;
    .locals 3
    .param p1, "input"    # Ltas/internal/camera/InputSourceInner;
    .param p2, "what"    # I
    .param p3, "msg"    # Ltas/camera/CameraMessage;
    .param p4, "proc"    # Ljava/lang/String;

    .prologue
    const/4 v2, 0x0

    .line 175
    invoke-static {}, Ltas/internal/camera/server/RemoteMessage;->obtain()Ltas/internal/camera/server/RemoteMessage;

    move-result-object v0

    .line 176
    .local v0, "ev":Ltas/internal/camera/server/RemoteMessage;
    iget-object v1, v0, Ltas/internal/camera/server/RemoteMessage;->params:Ltas/internal/camera/InputParams;

    .line 177
    .local v1, "params":Ltas/internal/camera/InputParams;
    if-eqz p1, :cond_0

    iget-object v2, p1, Ltas/internal/camera/InputSourceInner;->camcls:Ljava/lang/String;

    :cond_0
    iput-object v2, v1, Ltas/internal/camera/InputParams;->cam:Ljava/lang/String;

    .line 178
    iput p2, v1, Ltas/internal/camera/InputParams;->what:I

    .line 179
    if-eqz p3, :cond_1

    .line 180
    iget-object v2, v1, Ltas/internal/camera/InputParams;->msg:Ltas/camera/CameraMessage;

    invoke-virtual {v2, p3}, Ltas/camera/CameraMessage;->copy(Ltas/camera/CameraMessage;)V

    .line 182
    :cond_1
    const/4 v2, 0x0

    iput v2, v1, Ltas/internal/camera/InputParams;->pid:I

    .line 183
    iput-object p4, v1, Ltas/internal/camera/InputParams;->proc:Ljava/lang/String;

    .line 184
    return-object v0
.end method

.method private createExtraStateEvent(Ltas/internal/camera/InputSourceInner;IILjava/lang/String;)Ltas/internal/camera/server/RemoteMessage;
    .locals 6
    .param p1, "input"    # Ltas/internal/camera/InputSourceInner;
    .param p2, "state"    # I
    .param p3, "flag"    # I
    .param p4, "proc"    # Ljava/lang/String;

    .prologue
    .line 149
    const/4 v2, 0x4

    move-object v0, p0

    move-object v1, p1

    move v3, p2

    move v4, p3

    move-object v5, p4

    invoke-direct/range {v0 .. v5}, Ltas/internal/camera/Dispatcher;->createEvent(Ltas/internal/camera/InputSourceInner;IIILjava/lang/String;)Ltas/internal/camera/server/RemoteMessage;

    move-result-object v0

    return-object v0
.end method

.method private createMediaServerEvent(Z)Ltas/internal/camera/server/RemoteMessage;
    .locals 6
    .param p1, "alive"    # Z

    .prologue
    const/4 v1, 0x0

    const/4 v4, 0x0

    .line 154
    if-eqz p1, :cond_0

    const/4 v3, 0x1

    .line 153
    :goto_0
    const/4 v2, 0x5

    move-object v0, p0

    move-object v5, v1

    invoke-direct/range {v0 .. v5}, Ltas/internal/camera/Dispatcher;->createEvent(Ltas/internal/camera/InputSourceInner;IIILjava/lang/String;)Ltas/internal/camera/server/RemoteMessage;

    move-result-object v0

    return-object v0

    :cond_0
    move v3, v4

    .line 154
    goto :goto_0
.end method

.method private createMessageEvent(Ltas/internal/camera/InputSourceInner;Ltas/camera/CameraMessage;Ljava/lang/String;)Ltas/internal/camera/server/RemoteMessage;
    .locals 1
    .param p1, "input"    # Ltas/internal/camera/InputSourceInner;
    .param p2, "msg"    # Ltas/camera/CameraMessage;
    .param p3, "proc"    # Ljava/lang/String;

    .prologue
    .line 142
    const/4 v0, 0x3

    invoke-direct {p0, p1, v0, p2, p3}, Ltas/internal/camera/Dispatcher;->createEvent(Ltas/internal/camera/InputSourceInner;ILtas/camera/CameraMessage;Ljava/lang/String;)Ltas/internal/camera/server/RemoteMessage;

    move-result-object v0

    return-object v0
.end method

.method private onCableState(Ltas/internal/camera/server/RemoteMessage;)Z
    .locals 2
    .param p1, "msg"    # Ltas/internal/camera/server/RemoteMessage;

    .prologue
    .line 234
    iget-object v0, p0, Ltas/internal/camera/Dispatcher;->channel:Ltas/internal/camera/InputChannel;

    iget-object v1, p1, Ltas/internal/camera/server/RemoteMessage;->params:Ltas/internal/camera/InputParams;

    invoke-virtual {v0, v1}, Ltas/internal/camera/InputChannel;->onNotifyCableState(Ltas/internal/camera/InputParams;)Z

    move-result v0

    return v0
.end method

.method private onCameraMessage(Ltas/internal/camera/server/RemoteMessage;)Z
    .locals 2
    .param p1, "msg"    # Ltas/internal/camera/server/RemoteMessage;

    .prologue
    .line 242
    iget-object v0, p0, Ltas/internal/camera/Dispatcher;->channel:Ltas/internal/camera/InputChannel;

    iget-object v1, p1, Ltas/internal/camera/server/RemoteMessage;->params:Ltas/internal/camera/InputParams;

    invoke-virtual {v0, v1}, Ltas/internal/camera/InputChannel;->onNotifyCameraMessage(Ltas/internal/camera/InputParams;)Z

    move-result v0

    return v0
.end method

.method private onCameraState(Ltas/internal/camera/server/RemoteMessage;)Z
    .locals 2
    .param p1, "msg"    # Ltas/internal/camera/server/RemoteMessage;

    .prologue
    .line 238
    iget-object v0, p0, Ltas/internal/camera/Dispatcher;->channel:Ltas/internal/camera/InputChannel;

    iget-object v1, p1, Ltas/internal/camera/server/RemoteMessage;->params:Ltas/internal/camera/InputParams;

    invoke-virtual {v0, v1}, Ltas/internal/camera/InputChannel;->onNotifyCameraState(Ltas/internal/camera/InputParams;)Z

    move-result v0

    return v0
.end method

.method private onEvent(Ltas/internal/camera/server/RemoteMessage;)Z
    .locals 1
    .param p1, "msg"    # Ltas/internal/camera/server/RemoteMessage;

    .prologue
    .line 254
    const/4 v0, 0x1

    return v0
.end method

.method private onExtraState(Ltas/internal/camera/server/RemoteMessage;)Z
    .locals 2
    .param p1, "msg"    # Ltas/internal/camera/server/RemoteMessage;

    .prologue
    .line 246
    iget-object v0, p0, Ltas/internal/camera/Dispatcher;->channel:Ltas/internal/camera/InputChannel;

    iget-object v1, p1, Ltas/internal/camera/server/RemoteMessage;->params:Ltas/internal/camera/InputParams;

    invoke-virtual {v0, v1}, Ltas/internal/camera/InputChannel;->onNotifyExtraState(Ltas/internal/camera/InputParams;)Z

    move-result v0

    return v0
.end method

.method private onMediaServerState(Ltas/internal/camera/server/RemoteMessage;)Z
    .locals 2
    .param p1, "msg"    # Ltas/internal/camera/server/RemoteMessage;

    .prologue
    .line 250
    iget-object v0, p0, Ltas/internal/camera/Dispatcher;->channel:Ltas/internal/camera/InputChannel;

    iget-object v1, p1, Ltas/internal/camera/server/RemoteMessage;->params:Ltas/internal/camera/InputParams;

    invoke-virtual {v0, v1}, Ltas/internal/camera/InputChannel;->onNotifyMediaServerState(Ltas/internal/camera/InputParams;)Z

    move-result v0

    return v0
.end method

.method private post(Ltas/internal/camera/server/RemoteMessage;)Z
    .locals 2
    .param p1, "msg"    # Ltas/internal/camera/server/RemoteMessage;

    .prologue
    .line 258
    const-string/jumbo v0, "TasCAM<Dispatcher>"

    invoke-virtual {p1}, Ltas/internal/camera/server/RemoteMessage;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 259
    iget-object v0, p0, Ltas/internal/camera/Dispatcher;->server:Ltas/internal/camera/server/ServerOutGoing;

    invoke-virtual {v0, p1}, Ltas/internal/camera/server/ServerOutGoing;->post(Ltas/internal/camera/server/RemoteMessage;)V

    .line 260
    invoke-virtual {p1}, Ltas/internal/camera/server/RemoteMessage;->recycle()V

    .line 261
    const/4 v0, 0x1

    return v0
.end method


# virtual methods
.method cleanupLocked()V
    .locals 3

    .prologue
    .line 117
    iget-object v2, p0, Ltas/internal/camera/Dispatcher;->q:Ltas/internal/camera/Dispatcher$EventQueue;

    if-eqz v2, :cond_0

    iget-object v2, p0, Ltas/internal/camera/Dispatcher;->q:Ltas/internal/camera/Dispatcher$EventQueue;

    invoke-virtual {v2}, Ltas/internal/camera/Dispatcher$EventQueue;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_1

    .line 116
    :cond_0
    return-void

    .line 118
    :cond_1
    iget-object v2, p0, Ltas/internal/camera/Dispatcher;->q:Ltas/internal/camera/Dispatcher$EventQueue;

    invoke-virtual {v2}, Ltas/internal/camera/Dispatcher$EventQueue;->iterator()Ljava/util/Iterator;

    move-result-object v0

    .line 119
    .local v0, "iter":Ljava/util/Iterator;, "Ljava/util/Iterator<Ltas/internal/camera/server/RemoteMessage;>;"
    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_0

    .line 120
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ltas/internal/camera/server/RemoteMessage;

    .line 121
    .local v1, "msg":Ltas/internal/camera/server/RemoteMessage;
    invoke-virtual {v1}, Ltas/internal/camera/server/RemoteMessage;->recycle()V

    .line 122
    invoke-interface {v0}, Ljava/util/Iterator;->remove()V

    goto :goto_0
.end method

.method dispatchCableStateLocked(Ltas/internal/camera/InputSourceInner;Z)V
    .locals 1
    .param p1, "input"    # Ltas/internal/camera/InputSourceInner;
    .param p2, "plugged"    # Z

    .prologue
    .line 47
    invoke-direct {p0, p1, p2}, Ltas/internal/camera/Dispatcher;->createCableEvent(Ltas/internal/camera/InputSourceInner;Z)Ltas/internal/camera/server/RemoteMessage;

    move-result-object v0

    invoke-direct {p0, v0}, Ltas/internal/camera/Dispatcher;->addEvent(Ltas/internal/camera/server/RemoteMessage;)V

    .line 46
    return-void
.end method

.method dispatchCameraStateLocked(Ltas/internal/camera/InputSourceInner;Z)V
    .locals 1
    .param p1, "input"    # Ltas/internal/camera/InputSourceInner;
    .param p2, "opened"    # Z

    .prologue
    .line 52
    invoke-direct {p0, p1, p2}, Ltas/internal/camera/Dispatcher;->createCameraEvent(Ltas/internal/camera/InputSourceInner;Z)Ltas/internal/camera/server/RemoteMessage;

    move-result-object v0

    invoke-direct {p0, v0}, Ltas/internal/camera/Dispatcher;->addEvent(Ltas/internal/camera/server/RemoteMessage;)V

    .line 51
    return-void
.end method

.method dispatchExtraStateLocked(Ltas/internal/camera/InputSourceInner;IILjava/lang/String;)V
    .locals 1
    .param p1, "input"    # Ltas/internal/camera/InputSourceInner;
    .param p2, "state"    # I
    .param p3, "flag"    # I
    .param p4, "proc"    # Ljava/lang/String;

    .prologue
    .line 75
    invoke-direct {p0, p1, p2, p3, p4}, Ltas/internal/camera/Dispatcher;->createExtraStateEvent(Ltas/internal/camera/InputSourceInner;IILjava/lang/String;)Ltas/internal/camera/server/RemoteMessage;

    move-result-object v0

    invoke-direct {p0, v0}, Ltas/internal/camera/Dispatcher;->addEvent(Ltas/internal/camera/server/RemoteMessage;)V

    .line 74
    return-void
.end method

.method dispatchMediaServerStateLocked(Z)V
    .locals 1
    .param p1, "alive"    # Z

    .prologue
    .line 79
    invoke-direct {p0, p1}, Ltas/internal/camera/Dispatcher;->createMediaServerEvent(Z)Ltas/internal/camera/server/RemoteMessage;

    move-result-object v0

    invoke-direct {p0, v0}, Ltas/internal/camera/Dispatcher;->addEvent(Ltas/internal/camera/server/RemoteMessage;)V

    .line 78
    return-void
.end method

.method dispatchMessageLocked(Ltas/internal/camera/InputSourceInner;Ltas/camera/CameraMessage;Ljava/lang/String;Z)V
    .locals 2
    .param p1, "input"    # Ltas/internal/camera/InputSourceInner;
    .param p2, "msg"    # Ltas/camera/CameraMessage;
    .param p3, "proc"    # Ljava/lang/String;
    .param p4, "now"    # Z

    .prologue
    .line 59
    invoke-direct {p0, p1, p2, p3}, Ltas/internal/camera/Dispatcher;->createMessageEvent(Ltas/internal/camera/InputSourceInner;Ltas/camera/CameraMessage;Ljava/lang/String;)Ltas/internal/camera/server/RemoteMessage;

    move-result-object v0

    .line 60
    .local v0, "rmsg":Ltas/internal/camera/server/RemoteMessage;
    if-eqz p4, :cond_1

    .line 61
    invoke-direct {p0, v0}, Ltas/internal/camera/Dispatcher;->onCameraMessage(Ltas/internal/camera/server/RemoteMessage;)Z

    move-result v1

    if-eqz v1, :cond_0

    .line 62
    invoke-direct {p0, v0}, Ltas/internal/camera/Dispatcher;->post(Ltas/internal/camera/server/RemoteMessage;)Z

    .line 58
    :goto_0
    return-void

    .line 64
    :cond_0
    invoke-virtual {v0}, Ltas/internal/camera/server/RemoteMessage;->recycle()V

    goto :goto_0

    .line 67
    :cond_1
    invoke-direct {p0, v0}, Ltas/internal/camera/Dispatcher;->addEvent(Ltas/internal/camera/server/RemoteMessage;)V

    goto :goto_0
.end method

.method dispatchPendingsLocked()V
    .locals 4

    .prologue
    const/4 v3, 0x0

    .line 106
    iget-object v2, p0, Ltas/internal/camera/Dispatcher;->mPendings:Ljava/util/Queue;

    if-nez v2, :cond_0

    .line 107
    return-void

    .line 109
    :cond_0
    iget-object v2, p0, Ltas/internal/camera/Dispatcher;->mPendings:Ljava/util/Queue;

    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    .local v1, "msg$iterator":Ljava/util/Iterator;
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/camera/server/RemoteMessage;

    .line 110
    .local v0, "msg":Ltas/internal/camera/server/RemoteMessage;
    invoke-direct {p0, v0}, Ltas/internal/camera/Dispatcher;->addEvent(Ltas/internal/camera/server/RemoteMessage;)V

    goto :goto_0

    .line 112
    .end local v0    # "msg":Ltas/internal/camera/server/RemoteMessage;
    :cond_1
    iget-object v2, p0, Ltas/internal/camera/Dispatcher;->mPendings:Ljava/util/Queue;

    invoke-interface {v2}, Ljava/util/Queue;->clear()V

    .line 113
    iput-object v3, p0, Ltas/internal/camera/Dispatcher;->mPendings:Ljava/util/Queue;

    .line 105
    return-void
.end method

.method initializeEventQueue()V
    .locals 2

    .prologue
    const/4 v1, 0x0

    .line 34
    iget-object v0, p0, Ltas/internal/camera/Dispatcher;->q:Ltas/internal/camera/Dispatcher$EventQueue;

    if-nez v0, :cond_0

    new-instance v0, Ltas/internal/camera/Dispatcher$EventQueue;

    invoke-direct {v0, p0, v1}, Ltas/internal/camera/Dispatcher$EventQueue;-><init>(Ltas/internal/camera/Dispatcher;Ltas/internal/camera/Dispatcher$EventQueue;)V

    iput-object v0, p0, Ltas/internal/camera/Dispatcher;->q:Ltas/internal/camera/Dispatcher$EventQueue;

    .line 33
    :cond_0
    return-void
.end method

.method pause()V
    .locals 1

    .prologue
    .line 42
    iget-object v0, p0, Ltas/internal/camera/Dispatcher;->q:Ltas/internal/camera/Dispatcher$EventQueue;

    if-eqz v0, :cond_0

    iget-object v0, p0, Ltas/internal/camera/Dispatcher;->q:Ltas/internal/camera/Dispatcher$EventQueue;

    invoke-virtual {v0}, Ltas/internal/camera/Dispatcher$EventQueue;->pause()I

    .line 41
    :cond_0
    return-void
.end method

.method pendingCableStateLocked(Ltas/internal/camera/InputSourceInner;Z)V
    .locals 1
    .param p1, "input"    # Ltas/internal/camera/InputSourceInner;
    .param p2, "plugged"    # Z

    .prologue
    .line 84
    invoke-direct {p0, p1, p2}, Ltas/internal/camera/Dispatcher;->createCableEvent(Ltas/internal/camera/InputSourceInner;Z)Ltas/internal/camera/server/RemoteMessage;

    move-result-object v0

    invoke-direct {p0, v0}, Ltas/internal/camera/Dispatcher;->addPendingEvent(Ltas/internal/camera/server/RemoteMessage;)V

    .line 83
    return-void
.end method

.method pendingCameraStateLocked(Ltas/internal/camera/InputSourceInner;Z)V
    .locals 1
    .param p1, "input"    # Ltas/internal/camera/InputSourceInner;
    .param p2, "opened"    # Z

    .prologue
    .line 89
    invoke-direct {p0, p1, p2}, Ltas/internal/camera/Dispatcher;->createCameraEvent(Ltas/internal/camera/InputSourceInner;Z)Ltas/internal/camera/server/RemoteMessage;

    move-result-object v0

    invoke-direct {p0, v0}, Ltas/internal/camera/Dispatcher;->addPendingEvent(Ltas/internal/camera/server/RemoteMessage;)V

    .line 88
    return-void
.end method

.method pendingExtraStateLocked(Ltas/internal/camera/InputSourceInner;IILjava/lang/String;)V
    .locals 1
    .param p1, "input"    # Ltas/internal/camera/InputSourceInner;
    .param p2, "state"    # I
    .param p3, "flag"    # I
    .param p4, "proc"    # Ljava/lang/String;

    .prologue
    .line 102
    invoke-direct {p0, p1, p2, p3, p4}, Ltas/internal/camera/Dispatcher;->createExtraStateEvent(Ltas/internal/camera/InputSourceInner;IILjava/lang/String;)Ltas/internal/camera/server/RemoteMessage;

    move-result-object v0

    invoke-direct {p0, v0}, Ltas/internal/camera/Dispatcher;->addPendingEvent(Ltas/internal/camera/server/RemoteMessage;)V

    .line 101
    return-void
.end method

.method pendingMessageLocked(Ltas/internal/camera/InputSourceInner;Ltas/camera/CameraMessage;Ljava/lang/String;)V
    .locals 1
    .param p1, "input"    # Ltas/internal/camera/InputSourceInner;
    .param p2, "msg"    # Ltas/camera/CameraMessage;
    .param p3, "proc"    # Ljava/lang/String;

    .prologue
    .line 95
    invoke-direct {p0, p1, p2, p3}, Ltas/internal/camera/Dispatcher;->createMessageEvent(Ltas/internal/camera/InputSourceInner;Ltas/camera/CameraMessage;Ljava/lang/String;)Ltas/internal/camera/server/RemoteMessage;

    move-result-object v0

    invoke-direct {p0, v0}, Ltas/internal/camera/Dispatcher;->addPendingEvent(Ltas/internal/camera/server/RemoteMessage;)V

    .line 94
    return-void
.end method

.method resume()V
    .locals 1

    .prologue
    .line 38
    iget-object v0, p0, Ltas/internal/camera/Dispatcher;->q:Ltas/internal/camera/Dispatcher$EventQueue;

    if-eqz v0, :cond_0

    iget-object v0, p0, Ltas/internal/camera/Dispatcher;->q:Ltas/internal/camera/Dispatcher$EventQueue;

    invoke-virtual {v0}, Ltas/internal/camera/Dispatcher$EventQueue;->resume()I

    .line 37
    :cond_0
    return-void
.end method
