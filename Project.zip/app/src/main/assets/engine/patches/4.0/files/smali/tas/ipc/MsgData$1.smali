.class final Ltas/ipc/MsgData$1;
.super Ljava/lang/Object;
.source "MsgData.java"

# interfaces
.implements Ltas/internal/ipc/util/SyncdPool$Callback;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltas/ipc/MsgData;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ltas/internal/ipc/util/SyncdPool$Callback",
        "<",
        "Ltas/ipc/MsgData;",
        ">;"
    }
.end annotation


# direct methods
.method constructor <init>()V
    .locals 0

    .prologue
    .line 181
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public bridge synthetic getNext(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1
    .param p1, "msg"    # Ljava/lang/Object;

    .prologue
    .line 188
    check-cast p1, Ltas/ipc/MsgData;

    .end local p1    # "msg":Ljava/lang/Object;
    invoke-virtual {p0, p1}, Ltas/ipc/MsgData$1;->getNext(Ltas/ipc/MsgData;)Ltas/ipc/MsgData;

    move-result-object v0

    return-object v0
.end method

.method public getNext(Ltas/ipc/MsgData;)Ltas/ipc/MsgData;
    .locals 1
    .param p1, "msg"    # Ltas/ipc/MsgData;

    .prologue
    .line 189
    invoke-static {p1}, Ltas/ipc/MsgData;->-get0(Ltas/ipc/MsgData;)Ltas/ipc/MsgData;

    move-result-object v0

    return-object v0
.end method

.method public bridge synthetic newInstance()Ljava/lang/Object;
    .locals 1

    .prologue
    .line 182
    invoke-virtual {p0}, Ltas/ipc/MsgData$1;->newInstance()Ltas/ipc/MsgData;

    move-result-object v0

    return-object v0
.end method

.method public newInstance()Ltas/ipc/MsgData;
    .locals 3

    .prologue
    .line 183
    new-instance v0, Ltas/ipc/MsgData;

    invoke-direct {v0}, Ltas/ipc/MsgData;-><init>()V

    .line 184
    .local v0, "msg":Ltas/ipc/MsgData;
    invoke-static {}, Ltas/ipc/MsgData;->-get1()I

    move-result v1

    add-int/lit8 v2, v1, 0x1

    invoke-static {v2}, Ltas/ipc/MsgData;->-set2(I)I

    invoke-static {v0, v1}, Ltas/ipc/MsgData;->-set1(Ltas/ipc/MsgData;I)I

    .line 185
    return-object v0
.end method

.method public bridge synthetic setNext(Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 0
    .param p1, "msg"    # Ljava/lang/Object;
    .param p2, "next"    # Ljava/lang/Object;

    .prologue
    .line 192
    check-cast p1, Ltas/ipc/MsgData;

    .end local p1    # "msg":Ljava/lang/Object;
    check-cast p2, Ltas/ipc/MsgData;

    .end local p2    # "next":Ljava/lang/Object;
    invoke-virtual {p0, p1, p2}, Ltas/ipc/MsgData$1;->setNext(Ltas/ipc/MsgData;Ltas/ipc/MsgData;)V

    return-void
.end method

.method public setNext(Ltas/ipc/MsgData;Ltas/ipc/MsgData;)V
    .locals 0
    .param p1, "msg"    # Ltas/ipc/MsgData;
    .param p2, "next"    # Ltas/ipc/MsgData;

    .prologue
    .line 193
    invoke-static {p1, p2}, Ltas/ipc/MsgData;->-set0(Ltas/ipc/MsgData;Ltas/ipc/MsgData;)Ltas/ipc/MsgData;

    .line 192
    return-void
.end method
