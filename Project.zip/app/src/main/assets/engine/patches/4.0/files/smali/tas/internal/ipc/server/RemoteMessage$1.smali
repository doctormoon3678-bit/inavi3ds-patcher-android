.class final Ltas/internal/ipc/server/RemoteMessage$1;
.super Ljava/lang/Object;
.source "RemoteMessage.java"

# interfaces
.implements Landroid/os/Parcelable$Creator;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltas/internal/ipc/server/RemoteMessage;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Landroid/os/Parcelable$Creator",
        "<",
        "Ltas/internal/ipc/server/RemoteMessage;",
        ">;"
    }
.end annotation


# direct methods
.method constructor <init>()V
    .locals 0

    .prologue
    .line 37
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public bridge synthetic createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;
    .locals 1
    .param p1, "source"    # Landroid/os/Parcel;

    .prologue
    .line 38
    invoke-virtual {p0, p1}, Ltas/internal/ipc/server/RemoteMessage$1;->createFromParcel(Landroid/os/Parcel;)Ltas/internal/ipc/server/RemoteMessage;

    move-result-object v0

    return-object v0
.end method

.method public createFromParcel(Landroid/os/Parcel;)Ltas/internal/ipc/server/RemoteMessage;
    .locals 3
    .param p1, "source"    # Landroid/os/Parcel;

    .prologue
    .line 39
    invoke-static {}, Ltas/internal/ipc/server/RemoteMessage;->-get1()Ltas/internal/ipc/util/SyncdPool;

    move-result-object v1

    invoke-virtual {v1}, Ltas/internal/ipc/util/SyncdPool;->allocate()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/ipc/server/RemoteMessage;

    .line 40
    .local v0, "rmsg":Ltas/internal/ipc/server/RemoteMessage;
    invoke-static {}, Ltas/internal/ipc/server/RemoteMessage;->-get3()I

    move-result v1

    add-int/lit8 v2, v1, 0x1

    invoke-static {v2}, Ltas/internal/ipc/server/RemoteMessage;->-set4(I)I

    invoke-static {v0, v1}, Ltas/internal/ipc/server/RemoteMessage;->-set5(Ltas/internal/ipc/server/RemoteMessage;I)I

    .line 41
    invoke-virtual {v0, p1}, Ltas/internal/ipc/server/RemoteMessage;->readFromParcel(Landroid/os/Parcel;)V

    .line 42
    const/4 v1, 0x1

    invoke-static {v0, v1}, Ltas/internal/ipc/server/RemoteMessage;->-set0(Ltas/internal/ipc/server/RemoteMessage;Z)Z

    .line 43
    return-object v0
.end method

.method public bridge synthetic newArray(I)[Ljava/lang/Object;
    .locals 1
    .param p1, "size"    # I

    .prologue
    .line 46
    invoke-virtual {p0, p1}, Ltas/internal/ipc/server/RemoteMessage$1;->newArray(I)[Ltas/internal/ipc/server/RemoteMessage;

    move-result-object v0

    return-object v0
.end method

.method public newArray(I)[Ltas/internal/ipc/server/RemoteMessage;
    .locals 1
    .param p1, "size"    # I

    .prologue
    .line 47
    new-array v0, p1, [Ltas/internal/ipc/server/RemoteMessage;

    return-object v0
.end method
