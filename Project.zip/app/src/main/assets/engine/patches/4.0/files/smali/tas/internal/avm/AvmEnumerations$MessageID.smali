.class public final enum Ltas/internal/avm/AvmEnumerations$MessageID;
.super Ljava/lang/Enum;
.source "AvmEnumerations.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltas/internal/avm/AvmEnumerations;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "MessageID"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum",
        "<",
        "Ltas/internal/avm/AvmEnumerations$MessageID;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Ltas/internal/avm/AvmEnumerations$MessageID;

.field public static final enum AVM_CVBS_OUT_CONTROL:Ltas/internal/avm/AvmEnumerations$MessageID;

.field public static final enum AVM_READY_INFO:Ltas/internal/avm/AvmEnumerations$MessageID;

.field public static final enum AVM_START_INFO:Ltas/internal/avm/AvmEnumerations$MessageID;

.field public static final enum BOOT_MODE_REQUEST:Ltas/internal/avm/AvmEnumerations$MessageID;

.field public static final enum CALIBRATION_STATUS:Ltas/internal/avm/AvmEnumerations$MessageID;

.field public static final enum CONNECT_STATUS:Ltas/internal/avm/AvmEnumerations$MessageID;

.field public static final enum DISPALY_CONTROL:Ltas/internal/avm/AvmEnumerations$MessageID;

.field public static final enum INVALID_MESSAGE:Ltas/internal/avm/AvmEnumerations$MessageID;

.field public static final enum KEYBOX_EVENT_INFO:Ltas/internal/avm/AvmEnumerations$MessageID;

.field public static final enum PGS_REQUEST:Ltas/internal/avm/AvmEnumerations$MessageID;

.field public static final enum QUICK_VIEW_CONTROL:Ltas/internal/avm/AvmEnumerations$MessageID;

.field public static final enum RESET_REQUEST:Ltas/internal/avm/AvmEnumerations$MessageID;

.field public static final enum SETUP_DATA_REQUEST:Ltas/internal/avm/AvmEnumerations$MessageID;

.field public static final enum SETUP_DATA_SET:Ltas/internal/avm/AvmEnumerations$MessageID;

.field public static final enum TOPVIEW_COORD:Ltas/internal/avm/AvmEnumerations$MessageID;

.field public static final enum UPGRADE_STATUS:Ltas/internal/avm/AvmEnumerations$MessageID;

.field public static final enum VIEW_MODE_CONTROL:Ltas/internal/avm/AvmEnumerations$MessageID;


# instance fields
.field private id:I


# direct methods
.method static constructor <clinit>()V
    .locals 9

    .prologue
    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v4, 0x0

    .line 18
    new-instance v0, Ltas/internal/avm/AvmEnumerations$MessageID;

    const-string/jumbo v1, "INVALID_MESSAGE"

    invoke-direct {v0, v1, v4, v4}, Ltas/internal/avm/AvmEnumerations$MessageID;-><init>(Ljava/lang/String;II)V

    sput-object v0, Ltas/internal/avm/AvmEnumerations$MessageID;->INVALID_MESSAGE:Ltas/internal/avm/AvmEnumerations$MessageID;

    .line 19
    new-instance v0, Ltas/internal/avm/AvmEnumerations$MessageID;

    const-string/jumbo v1, "AVM_START_INFO"

    invoke-direct {v0, v1, v5, v5}, Ltas/internal/avm/AvmEnumerations$MessageID;-><init>(Ljava/lang/String;II)V

    sput-object v0, Ltas/internal/avm/AvmEnumerations$MessageID;->AVM_START_INFO:Ltas/internal/avm/AvmEnumerations$MessageID;

    .line 20
    new-instance v0, Ltas/internal/avm/AvmEnumerations$MessageID;

    const-string/jumbo v1, "DISPALY_CONTROL"

    const/4 v2, 0x2

    invoke-direct {v0, v1, v2, v6}, Ltas/internal/avm/AvmEnumerations$MessageID;-><init>(Ljava/lang/String;II)V

    .line 21
    sput-object v0, Ltas/internal/avm/AvmEnumerations$MessageID;->DISPALY_CONTROL:Ltas/internal/avm/AvmEnumerations$MessageID;

    .line 22
    new-instance v0, Ltas/internal/avm/AvmEnumerations$MessageID;

    const-string/jumbo v1, "AVM_READY_INFO"

    const/4 v2, 0x3

    invoke-direct {v0, v1, v2, v7}, Ltas/internal/avm/AvmEnumerations$MessageID;-><init>(Ljava/lang/String;II)V

    sput-object v0, Ltas/internal/avm/AvmEnumerations$MessageID;->AVM_READY_INFO:Ltas/internal/avm/AvmEnumerations$MessageID;

    .line 23
    new-instance v0, Ltas/internal/avm/AvmEnumerations$MessageID;

    const-string/jumbo v1, "UPGRADE_STATUS"

    invoke-direct {v0, v1, v6, v8}, Ltas/internal/avm/AvmEnumerations$MessageID;-><init>(Ljava/lang/String;II)V

    sput-object v0, Ltas/internal/avm/AvmEnumerations$MessageID;->UPGRADE_STATUS:Ltas/internal/avm/AvmEnumerations$MessageID;

    .line 24
    new-instance v0, Ltas/internal/avm/AvmEnumerations$MessageID;

    const-string/jumbo v1, "CONNECT_STATUS"

    const/16 v2, 0x11

    invoke-direct {v0, v1, v7, v2}, Ltas/internal/avm/AvmEnumerations$MessageID;-><init>(Ljava/lang/String;II)V

    sput-object v0, Ltas/internal/avm/AvmEnumerations$MessageID;->CONNECT_STATUS:Ltas/internal/avm/AvmEnumerations$MessageID;

    .line 25
    new-instance v0, Ltas/internal/avm/AvmEnumerations$MessageID;

    const-string/jumbo v1, "AVM_CVBS_OUT_CONTROL"

    const/16 v2, 0x12

    invoke-direct {v0, v1, v8, v2}, Ltas/internal/avm/AvmEnumerations$MessageID;-><init>(Ljava/lang/String;II)V

    sput-object v0, Ltas/internal/avm/AvmEnumerations$MessageID;->AVM_CVBS_OUT_CONTROL:Ltas/internal/avm/AvmEnumerations$MessageID;

    .line 26
    new-instance v0, Ltas/internal/avm/AvmEnumerations$MessageID;

    const-string/jumbo v1, "VIEW_MODE_CONTROL"

    const/4 v2, 0x7

    const/16 v3, 0x13

    invoke-direct {v0, v1, v2, v3}, Ltas/internal/avm/AvmEnumerations$MessageID;-><init>(Ljava/lang/String;II)V

    sput-object v0, Ltas/internal/avm/AvmEnumerations$MessageID;->VIEW_MODE_CONTROL:Ltas/internal/avm/AvmEnumerations$MessageID;

    .line 27
    new-instance v0, Ltas/internal/avm/AvmEnumerations$MessageID;

    const-string/jumbo v1, "KEYBOX_EVENT_INFO"

    const/16 v2, 0x8

    const/16 v3, 0x14

    invoke-direct {v0, v1, v2, v3}, Ltas/internal/avm/AvmEnumerations$MessageID;-><init>(Ljava/lang/String;II)V

    sput-object v0, Ltas/internal/avm/AvmEnumerations$MessageID;->KEYBOX_EVENT_INFO:Ltas/internal/avm/AvmEnumerations$MessageID;

    .line 28
    new-instance v0, Ltas/internal/avm/AvmEnumerations$MessageID;

    const-string/jumbo v1, "QUICK_VIEW_CONTROL"

    const/16 v2, 0x9

    const/16 v3, 0x15

    invoke-direct {v0, v1, v2, v3}, Ltas/internal/avm/AvmEnumerations$MessageID;-><init>(Ljava/lang/String;II)V

    sput-object v0, Ltas/internal/avm/AvmEnumerations$MessageID;->QUICK_VIEW_CONTROL:Ltas/internal/avm/AvmEnumerations$MessageID;

    .line 29
    new-instance v0, Ltas/internal/avm/AvmEnumerations$MessageID;

    const-string/jumbo v1, "SETUP_DATA_SET"

    const/16 v2, 0xa

    const/16 v3, 0x16

    invoke-direct {v0, v1, v2, v3}, Ltas/internal/avm/AvmEnumerations$MessageID;-><init>(Ljava/lang/String;II)V

    sput-object v0, Ltas/internal/avm/AvmEnumerations$MessageID;->SETUP_DATA_SET:Ltas/internal/avm/AvmEnumerations$MessageID;

    .line 30
    new-instance v0, Ltas/internal/avm/AvmEnumerations$MessageID;

    const-string/jumbo v1, "SETUP_DATA_REQUEST"

    const/16 v2, 0xb

    const/16 v3, 0x17

    invoke-direct {v0, v1, v2, v3}, Ltas/internal/avm/AvmEnumerations$MessageID;-><init>(Ljava/lang/String;II)V

    sput-object v0, Ltas/internal/avm/AvmEnumerations$MessageID;->SETUP_DATA_REQUEST:Ltas/internal/avm/AvmEnumerations$MessageID;

    .line 31
    new-instance v0, Ltas/internal/avm/AvmEnumerations$MessageID;

    const-string/jumbo v1, "BOOT_MODE_REQUEST"

    const/16 v2, 0xc

    const/16 v3, 0x18

    invoke-direct {v0, v1, v2, v3}, Ltas/internal/avm/AvmEnumerations$MessageID;-><init>(Ljava/lang/String;II)V

    sput-object v0, Ltas/internal/avm/AvmEnumerations$MessageID;->BOOT_MODE_REQUEST:Ltas/internal/avm/AvmEnumerations$MessageID;

    .line 32
    new-instance v0, Ltas/internal/avm/AvmEnumerations$MessageID;

    const-string/jumbo v1, "CALIBRATION_STATUS"

    const/16 v2, 0xd

    const/16 v3, 0x19

    invoke-direct {v0, v1, v2, v3}, Ltas/internal/avm/AvmEnumerations$MessageID;-><init>(Ljava/lang/String;II)V

    sput-object v0, Ltas/internal/avm/AvmEnumerations$MessageID;->CALIBRATION_STATUS:Ltas/internal/avm/AvmEnumerations$MessageID;

    .line 33
    new-instance v0, Ltas/internal/avm/AvmEnumerations$MessageID;

    const-string/jumbo v1, "RESET_REQUEST"

    const/16 v2, 0xe

    const/16 v3, 0x20

    invoke-direct {v0, v1, v2, v3}, Ltas/internal/avm/AvmEnumerations$MessageID;-><init>(Ljava/lang/String;II)V

    sput-object v0, Ltas/internal/avm/AvmEnumerations$MessageID;->RESET_REQUEST:Ltas/internal/avm/AvmEnumerations$MessageID;

    .line 34
    new-instance v0, Ltas/internal/avm/AvmEnumerations$MessageID;

    const-string/jumbo v1, "PGS_REQUEST"

    const/16 v2, 0xf

    const/16 v3, 0x30

    invoke-direct {v0, v1, v2, v3}, Ltas/internal/avm/AvmEnumerations$MessageID;-><init>(Ljava/lang/String;II)V

    sput-object v0, Ltas/internal/avm/AvmEnumerations$MessageID;->PGS_REQUEST:Ltas/internal/avm/AvmEnumerations$MessageID;

    .line 35
    new-instance v0, Ltas/internal/avm/AvmEnumerations$MessageID;

    const-string/jumbo v1, "TOPVIEW_COORD"

    const/16 v2, 0x10

    const/16 v3, 0x31

    invoke-direct {v0, v1, v2, v3}, Ltas/internal/avm/AvmEnumerations$MessageID;-><init>(Ljava/lang/String;II)V

    sput-object v0, Ltas/internal/avm/AvmEnumerations$MessageID;->TOPVIEW_COORD:Ltas/internal/avm/AvmEnumerations$MessageID;

    .line 17
    const/16 v0, 0x11

    new-array v0, v0, [Ltas/internal/avm/AvmEnumerations$MessageID;

    sget-object v1, Ltas/internal/avm/AvmEnumerations$MessageID;->INVALID_MESSAGE:Ltas/internal/avm/AvmEnumerations$MessageID;

    aput-object v1, v0, v4

    sget-object v1, Ltas/internal/avm/AvmEnumerations$MessageID;->AVM_START_INFO:Ltas/internal/avm/AvmEnumerations$MessageID;

    aput-object v1, v0, v5

    sget-object v1, Ltas/internal/avm/AvmEnumerations$MessageID;->DISPALY_CONTROL:Ltas/internal/avm/AvmEnumerations$MessageID;

    const/4 v2, 0x2

    aput-object v1, v0, v2

    sget-object v1, Ltas/internal/avm/AvmEnumerations$MessageID;->AVM_READY_INFO:Ltas/internal/avm/AvmEnumerations$MessageID;

    const/4 v2, 0x3

    aput-object v1, v0, v2

    sget-object v1, Ltas/internal/avm/AvmEnumerations$MessageID;->UPGRADE_STATUS:Ltas/internal/avm/AvmEnumerations$MessageID;

    aput-object v1, v0, v6

    sget-object v1, Ltas/internal/avm/AvmEnumerations$MessageID;->CONNECT_STATUS:Ltas/internal/avm/AvmEnumerations$MessageID;

    aput-object v1, v0, v7

    sget-object v1, Ltas/internal/avm/AvmEnumerations$MessageID;->AVM_CVBS_OUT_CONTROL:Ltas/internal/avm/AvmEnumerations$MessageID;

    aput-object v1, v0, v8

    sget-object v1, Ltas/internal/avm/AvmEnumerations$MessageID;->VIEW_MODE_CONTROL:Ltas/internal/avm/AvmEnumerations$MessageID;

    const/4 v2, 0x7

    aput-object v1, v0, v2

    sget-object v1, Ltas/internal/avm/AvmEnumerations$MessageID;->KEYBOX_EVENT_INFO:Ltas/internal/avm/AvmEnumerations$MessageID;

    const/16 v2, 0x8

    aput-object v1, v0, v2

    sget-object v1, Ltas/internal/avm/AvmEnumerations$MessageID;->QUICK_VIEW_CONTROL:Ltas/internal/avm/AvmEnumerations$MessageID;

    const/16 v2, 0x9

    aput-object v1, v0, v2

    sget-object v1, Ltas/internal/avm/AvmEnumerations$MessageID;->SETUP_DATA_SET:Ltas/internal/avm/AvmEnumerations$MessageID;

    const/16 v2, 0xa

    aput-object v1, v0, v2

    sget-object v1, Ltas/internal/avm/AvmEnumerations$MessageID;->SETUP_DATA_REQUEST:Ltas/internal/avm/AvmEnumerations$MessageID;

    const/16 v2, 0xb

    aput-object v1, v0, v2

    sget-object v1, Ltas/internal/avm/AvmEnumerations$MessageID;->BOOT_MODE_REQUEST:Ltas/internal/avm/AvmEnumerations$MessageID;

    const/16 v2, 0xc

    aput-object v1, v0, v2

    sget-object v1, Ltas/internal/avm/AvmEnumerations$MessageID;->CALIBRATION_STATUS:Ltas/internal/avm/AvmEnumerations$MessageID;

    const/16 v2, 0xd

    aput-object v1, v0, v2

    sget-object v1, Ltas/internal/avm/AvmEnumerations$MessageID;->RESET_REQUEST:Ltas/internal/avm/AvmEnumerations$MessageID;

    const/16 v2, 0xe

    aput-object v1, v0, v2

    sget-object v1, Ltas/internal/avm/AvmEnumerations$MessageID;->PGS_REQUEST:Ltas/internal/avm/AvmEnumerations$MessageID;

    const/16 v2, 0xf

    aput-object v1, v0, v2

    sget-object v1, Ltas/internal/avm/AvmEnumerations$MessageID;->TOPVIEW_COORD:Ltas/internal/avm/AvmEnumerations$MessageID;

    const/16 v2, 0x10

    aput-object v1, v0, v2

    sput-object v0, Ltas/internal/avm/AvmEnumerations$MessageID;->$VALUES:[Ltas/internal/avm/AvmEnumerations$MessageID;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .locals 0
    .param p3, "id"    # I

    .prologue
    .line 38
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 39
    iput p3, p0, Ltas/internal/avm/AvmEnumerations$MessageID;->id:I

    .line 38
    return-void
.end method

.method public static createFromValue(I)Ltas/internal/avm/AvmEnumerations$MessageID;
    .locals 5
    .param p0, "id"    # I

    .prologue
    .line 54
    invoke-static {}, Ltas/internal/avm/AvmEnumerations$MessageID;->values()[Ltas/internal/avm/AvmEnumerations$MessageID;

    move-result-object v2

    const/4 v1, 0x0

    array-length v3, v2

    :goto_0
    if-ge v1, v3, :cond_1

    aget-object v0, v2, v1

    .line 55
    .local v0, "i":Ltas/internal/avm/AvmEnumerations$MessageID;
    invoke-virtual {v0}, Ltas/internal/avm/AvmEnumerations$MessageID;->toInteger()I

    move-result v4

    if-ne v4, p0, :cond_0

    .line 56
    return-object v0

    .line 54
    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    .line 60
    .end local v0    # "i":Ltas/internal/avm/AvmEnumerations$MessageID;
    :cond_1
    sget-object v1, Ltas/internal/avm/AvmEnumerations$MessageID;->INVALID_MESSAGE:Ltas/internal/avm/AvmEnumerations$MessageID;

    return-object v1
.end method

.method public static getRandomForTest()Ltas/internal/avm/AvmEnumerations$MessageID;
    .locals 4

    .prologue
    .line 47
    invoke-static {}, Ljava/util/concurrent/ThreadLocalRandom;->current()Ljava/util/concurrent/ThreadLocalRandom;

    move-result-object v1

    .line 48
    .local v1, "random":Ljava/util/concurrent/ThreadLocalRandom;
    invoke-static {}, Ltas/internal/avm/AvmEnumerations;->-get0()[Ltas/internal/avm/AvmEnumerations$MessageID;

    move-result-object v2

    array-length v2, v2

    add-int/lit8 v2, v2, -0x1

    const/4 v3, 0x0

    invoke-virtual {v1, v3, v2}, Ljava/util/concurrent/ThreadLocalRandom;->nextInt(II)I

    move-result v0

    .line 49
    .local v0, "rand":I
    invoke-static {}, Ltas/internal/avm/AvmEnumerations;->-get0()[Ltas/internal/avm/AvmEnumerations$MessageID;

    move-result-object v2

    aget-object v2, v2, v0

    return-object v2
.end method

.method public static valueOf(Ljava/lang/String;)Ltas/internal/avm/AvmEnumerations$MessageID;
    .locals 1
    .param p0, "name"    # Ljava/lang/String;

    .prologue
    .line 17
    const-class v0, Ltas/internal/avm/AvmEnumerations$MessageID;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object v0

    check-cast v0, Ltas/internal/avm/AvmEnumerations$MessageID;

    return-object v0
.end method

.method public static values()[Ltas/internal/avm/AvmEnumerations$MessageID;
    .locals 1

    .prologue
    .line 17
    sget-object v0, Ltas/internal/avm/AvmEnumerations$MessageID;->$VALUES:[Ltas/internal/avm/AvmEnumerations$MessageID;

    return-object v0
.end method


# virtual methods
.method public toInteger()I
    .locals 1

    .prologue
    .line 43
    iget v0, p0, Ltas/internal/avm/AvmEnumerations$MessageID;->id:I

    return v0
.end method
