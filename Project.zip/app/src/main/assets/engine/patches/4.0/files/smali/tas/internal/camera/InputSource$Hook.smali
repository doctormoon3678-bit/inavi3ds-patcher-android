.class Ltas/internal/camera/InputSource$Hook;
.super Ljava/lang/Object;
.source "InputSource.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltas/internal/camera/InputSource;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "Hook"
.end annotation


# instance fields
.field final impl:Ltas/internal/camera/InputSourceInner;

.field final input:Ltas/internal/camera/InputSource;


# direct methods
.method static synthetic -wrap0(Ltas/internal/camera/InputSource$Hook;)Z
    .locals 1

    invoke-direct {p0}, Ltas/internal/camera/InputSource$Hook;->isPlugged()Z

    move-result v0

    return v0
.end method

.method static synthetic -wrap1(Ltas/internal/camera/InputSource$Hook;)I
    .locals 1

    invoke-direct {p0}, Ltas/internal/camera/InputSource$Hook;->port()I

    move-result v0

    return v0
.end method

.method static synthetic -wrap10(Ltas/internal/camera/InputSource$Hook;I)V
    .locals 0
    .param p1, "state"    # I

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/camera/InputSource$Hook;->notifyState(I)V

    return-void
.end method

.method static synthetic -wrap11(Ltas/internal/camera/InputSource$Hook;)V
    .locals 0

    invoke-direct {p0}, Ltas/internal/camera/InputSource$Hook;->plug()V

    return-void
.end method

.method static synthetic -wrap12(Ltas/internal/camera/InputSource$Hook;IILjava/lang/String;)V
    .locals 0
    .param p1, "state"    # I
    .param p2, "flag"    # I
    .param p3, "proc"    # Ljava/lang/String;

    .prologue
    invoke-direct {p0, p1, p2, p3}, Ltas/internal/camera/InputSource$Hook;->reportExtraState(IILjava/lang/String;)V

    return-void
.end method

.method static synthetic -wrap13(Ltas/internal/camera/InputSource$Hook;Ltas/camera/CameraMessage;Ljava/lang/String;Z)V
    .locals 0
    .param p1, "msg"    # Ltas/camera/CameraMessage;
    .param p2, "proc"    # Ljava/lang/String;
    .param p3, "now"    # Z

    .prologue
    invoke-direct {p0, p1, p2, p3}, Ltas/internal/camera/InputSource$Hook;->sendMessage(Ltas/camera/CameraMessage;Ljava/lang/String;Z)V

    return-void
.end method

.method static synthetic -wrap14(Ltas/internal/camera/InputSource$Hook;)V
    .locals 0

    invoke-direct {p0}, Ltas/internal/camera/InputSource$Hook;->unplug()V

    return-void
.end method

.method static synthetic -wrap2(Ltas/internal/camera/InputSource$Hook;)Ljava/lang/String;
    .locals 1

    invoke-direct {p0}, Ltas/internal/camera/InputSource$Hook;->camid()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method static synthetic -wrap3(Ltas/internal/camera/InputSource$Hook;)Ljava/lang/String;
    .locals 1

    invoke-direct {p0}, Ltas/internal/camera/InputSource$Hook;->camname()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method static synthetic -wrap4(Ltas/internal/camera/InputSource$Hook;Z)Ltas/internal/camera/InputSource;
    .locals 1
    .param p1, "recursive"    # Z

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/camera/InputSource$Hook;->getCurrInput(Z)Ltas/internal/camera/InputSource;

    move-result-object v0

    return-object v0
.end method

.method static synthetic -wrap5(Ltas/internal/camera/InputSource$Hook;)Ltas/internal/camera/InputSource;
    .locals 1

    invoke-direct {p0}, Ltas/internal/camera/InputSource$Hook;->getParent()Ltas/internal/camera/InputSource;

    move-result-object v0

    return-object v0
.end method

.method static synthetic -wrap6(Ltas/internal/camera/InputSource$Hook;ILtas/internal/camera/InputSource;)V
    .locals 0
    .param p1, "port"    # I
    .param p2, "input"    # Ltas/internal/camera/InputSource;

    .prologue
    invoke-direct {p0, p1, p2}, Ltas/internal/camera/InputSource$Hook;->addInput(ILtas/internal/camera/InputSource;)V

    return-void
.end method

.method static synthetic -wrap7(Ltas/internal/camera/InputSource$Hook;)V
    .locals 0

    invoke-direct {p0}, Ltas/internal/camera/InputSource$Hook;->initializeInputQueue()V

    return-void
.end method

.method static synthetic -wrap8(Ltas/internal/camera/InputSource$Hook;)V
    .locals 0

    invoke-direct {p0}, Ltas/internal/camera/InputSource$Hook;->initializeStateQueue()V

    return-void
.end method

.method static synthetic -wrap9(Ltas/internal/camera/InputSource$Hook;Ltas/internal/camera/InputSource;)V
    .locals 0
    .param p1, "input"    # Ltas/internal/camera/InputSource;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/camera/InputSource$Hook;->notifyInput(Ltas/internal/camera/InputSource;)V

    return-void
.end method

.method private constructor <init>(Ltas/internal/camera/InputSource;I)V
    .locals 2
    .param p1, "_input"    # Ltas/internal/camera/InputSource;
    .param p2, "maxinputs"    # I

    .prologue
    const/4 v1, 0x0

    .line 341
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 342
    iput-object p1, p0, Ltas/internal/camera/InputSource$Hook;->input:Ltas/internal/camera/InputSource;

    .line 343
    new-instance v0, Ltas/internal/camera/InputSourceInner;

    invoke-direct {v0, p0, v1, v1, p2}, Ltas/internal/camera/InputSourceInner;-><init>(Ltas/internal/camera/InputSource$Hook;Ljava/lang/Class;Ljava/lang/String;I)V

    iput-object v0, p0, Ltas/internal/camera/InputSource$Hook;->impl:Ltas/internal/camera/InputSourceInner;

    .line 341
    return-void
.end method

.method synthetic constructor <init>(Ltas/internal/camera/InputSource;ILtas/internal/camera/InputSource$Hook;)V
    .locals 0
    .param p1, "_input"    # Ltas/internal/camera/InputSource;
    .param p2, "maxinputs"    # I

    .prologue
    invoke-direct {p0, p1, p2}, Ltas/internal/camera/InputSource$Hook;-><init>(Ltas/internal/camera/InputSource;I)V

    return-void
.end method

.method private constructor <init>(Ltas/internal/camera/InputSource;Ljava/lang/Class;Ljava/lang/String;)V
    .locals 2
    .param p1, "_input"    # Ltas/internal/camera/InputSource;
    .param p3, "_camid"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ltas/internal/camera/InputSource;",
            "Ljava/lang/Class",
            "<*>;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .prologue
    .line 346
    .local p2, "_camcls":Ljava/lang/Class;, "Ljava/lang/Class<*>;"
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 348
    iput-object p1, p0, Ltas/internal/camera/InputSource$Hook;->input:Ltas/internal/camera/InputSource;

    .line 349
    new-instance v0, Ltas/internal/camera/InputSourceInner;

    const/4 v1, 0x0

    invoke-direct {v0, p0, p2, p3, v1}, Ltas/internal/camera/InputSourceInner;-><init>(Ltas/internal/camera/InputSource$Hook;Ljava/lang/Class;Ljava/lang/String;I)V

    iput-object v0, p0, Ltas/internal/camera/InputSource$Hook;->impl:Ltas/internal/camera/InputSourceInner;

    .line 347
    return-void
.end method

.method synthetic constructor <init>(Ltas/internal/camera/InputSource;Ljava/lang/Class;Ljava/lang/String;Ltas/internal/camera/InputSource$Hook;)V
    .locals 0
    .param p1, "_input"    # Ltas/internal/camera/InputSource;
    .param p2, "_camcls"    # Ljava/lang/Class;
    .param p3, "_camid"    # Ljava/lang/String;

    .prologue
    invoke-direct {p0, p1, p2, p3}, Ltas/internal/camera/InputSource$Hook;-><init>(Ltas/internal/camera/InputSource;Ljava/lang/Class;Ljava/lang/String;)V

    return-void
.end method

.method private addInput(ILtas/internal/camera/InputSource;)V
    .locals 2
    .param p1, "port"    # I
    .param p2, "input"    # Ltas/internal/camera/InputSource;

    .prologue
    .line 370
    iget-object v0, p0, Ltas/internal/camera/InputSource$Hook;->impl:Ltas/internal/camera/InputSourceInner;

    iget-object v1, p2, Ltas/internal/camera/InputSource;->hook:Ltas/internal/camera/InputSource$Hook;

    iget-object v1, v1, Ltas/internal/camera/InputSource$Hook;->impl:Ltas/internal/camera/InputSourceInner;

    invoke-virtual {v0, p1, v1}, Ltas/internal/camera/InputSourceInner;->addInput(ILtas/internal/camera/InputSourceInner;)V

    .line 369
    return-void
.end method

.method private camid()Ljava/lang/String;
    .locals 1

    .prologue
    .line 353
    iget-object v0, p0, Ltas/internal/camera/InputSource$Hook;->impl:Ltas/internal/camera/InputSourceInner;

    iget-object v0, v0, Ltas/internal/camera/InputSourceInner;->camid:Ljava/lang/String;

    return-object v0
.end method

.method private camname()Ljava/lang/String;
    .locals 1

    .prologue
    .line 357
    iget-object v0, p0, Ltas/internal/camera/InputSource$Hook;->impl:Ltas/internal/camera/InputSourceInner;

    iget-object v0, v0, Ltas/internal/camera/InputSourceInner;->camname:Ljava/lang/String;

    return-object v0
.end method

.method private getCurrInput(Z)Ltas/internal/camera/InputSource;
    .locals 3
    .param p1, "recursive"    # Z

    .prologue
    const/4 v1, 0x0

    .line 374
    iget-object v2, p0, Ltas/internal/camera/InputSource$Hook;->impl:Ltas/internal/camera/InputSourceInner;

    invoke-virtual {v2, p1}, Ltas/internal/camera/InputSourceInner;->getCurrInput(Z)Ltas/internal/camera/InputSourceInner;

    move-result-object v0

    .line 375
    .local v0, "input":Ltas/internal/camera/InputSourceInner;
    if-eqz v0, :cond_0

    iget-object v1, v0, Ltas/internal/camera/InputSourceInner;->hook:Ltas/internal/camera/InputSource$Hook;

    iget-object v1, v1, Ltas/internal/camera/InputSource$Hook;->input:Ltas/internal/camera/InputSource;

    :cond_0
    return-object v1
.end method

.method private getParent()Ltas/internal/camera/InputSource;
    .locals 3

    .prologue
    const/4 v1, 0x0

    .line 365
    iget-object v2, p0, Ltas/internal/camera/InputSource$Hook;->impl:Ltas/internal/camera/InputSourceInner;

    invoke-virtual {v2}, Ltas/internal/camera/InputSourceInner;->getParent()Ltas/internal/camera/InputSourceInner;

    move-result-object v0

    .line 366
    .local v0, "input":Ltas/internal/camera/InputSourceInner;
    if-eqz v0, :cond_0

    iget-object v1, v0, Ltas/internal/camera/InputSourceInner;->hook:Ltas/internal/camera/InputSource$Hook;

    iget-object v1, v1, Ltas/internal/camera/InputSource$Hook;->input:Ltas/internal/camera/InputSource;

    :cond_0
    return-object v1
.end method

.method private initializeInputQueue()V
    .locals 1

    .prologue
    .line 383
    iget-object v0, p0, Ltas/internal/camera/InputSource$Hook;->impl:Ltas/internal/camera/InputSourceInner;

    invoke-virtual {v0}, Ltas/internal/camera/InputSourceInner;->initializeInputQueue()V

    .line 382
    return-void
.end method

.method private initializeStateQueue()V
    .locals 1

    .prologue
    .line 379
    iget-object v0, p0, Ltas/internal/camera/InputSource$Hook;->impl:Ltas/internal/camera/InputSourceInner;

    invoke-virtual {v0}, Ltas/internal/camera/InputSourceInner;->initializeStateQueue()V

    .line 378
    return-void
.end method

.method private isPlugged()Z
    .locals 1

    .prologue
    .line 395
    iget-object v0, p0, Ltas/internal/camera/InputSource$Hook;->impl:Ltas/internal/camera/InputSourceInner;

    invoke-virtual {v0}, Ltas/internal/camera/InputSourceInner;->isPlugged()Z

    move-result v0

    return v0
.end method

.method private notifyInput(Ltas/internal/camera/InputSource;)V
    .locals 2
    .param p1, "input"    # Ltas/internal/camera/InputSource;

    .prologue
    const/4 v0, 0x0

    .line 407
    iget-object v1, p0, Ltas/internal/camera/InputSource$Hook;->impl:Ltas/internal/camera/InputSourceInner;

    if-eqz p1, :cond_0

    iget-object v0, p1, Ltas/internal/camera/InputSource;->hook:Ltas/internal/camera/InputSource$Hook;

    iget-object v0, v0, Ltas/internal/camera/InputSource$Hook;->impl:Ltas/internal/camera/InputSourceInner;

    :cond_0
    invoke-virtual {v1, v0}, Ltas/internal/camera/InputSourceInner;->notifyInput(Ltas/internal/camera/InputSourceInner;)V

    .line 406
    return-void
.end method

.method private notifyState(I)V
    .locals 1
    .param p1, "state"    # I

    .prologue
    .line 403
    iget-object v0, p0, Ltas/internal/camera/InputSource$Hook;->impl:Ltas/internal/camera/InputSourceInner;

    invoke-virtual {v0, p1}, Ltas/internal/camera/InputSourceInner;->notifyState(I)V

    .line 402
    return-void
.end method

.method private plug()V
    .locals 1

    .prologue
    .line 387
    iget-object v0, p0, Ltas/internal/camera/InputSource$Hook;->impl:Ltas/internal/camera/InputSourceInner;

    invoke-virtual {v0}, Ltas/internal/camera/InputSourceInner;->plug()V

    .line 386
    return-void
.end method

.method private port()I
    .locals 1

    .prologue
    .line 361
    iget-object v0, p0, Ltas/internal/camera/InputSource$Hook;->impl:Ltas/internal/camera/InputSourceInner;

    invoke-virtual {v0}, Ltas/internal/camera/InputSourceInner;->port()I

    move-result v0

    return v0
.end method

.method private reportExtraState(IILjava/lang/String;)V
    .locals 1
    .param p1, "state"    # I
    .param p2, "flag"    # I
    .param p3, "proc"    # Ljava/lang/String;

    .prologue
    .line 417
    iget-object v0, p0, Ltas/internal/camera/InputSource$Hook;->impl:Ltas/internal/camera/InputSourceInner;

    invoke-virtual {v0, p1, p2, p3}, Ltas/internal/camera/InputSourceInner;->reportExtraState(IILjava/lang/String;)V

    .line 416
    return-void
.end method

.method private sendMessage(Ltas/camera/CameraMessage;Ljava/lang/String;Z)V
    .locals 1
    .param p1, "msg"    # Ltas/camera/CameraMessage;
    .param p2, "proc"    # Ljava/lang/String;
    .param p3, "now"    # Z

    .prologue
    .line 412
    iget-object v0, p0, Ltas/internal/camera/InputSource$Hook;->impl:Ltas/internal/camera/InputSourceInner;

    invoke-virtual {v0, p1, p2, p3}, Ltas/internal/camera/InputSourceInner;->sendMessage(Ltas/camera/CameraMessage;Ljava/lang/String;Z)V

    .line 411
    return-void
.end method

.method private unplug()V
    .locals 1

    .prologue
    .line 391
    iget-object v0, p0, Ltas/internal/camera/InputSource$Hook;->impl:Ltas/internal/camera/InputSourceInner;

    invoke-virtual {v0}, Ltas/internal/camera/InputSourceInner;->unplug()V

    .line 390
    return-void
.end method


# virtual methods
.method public isOpened()Z
    .locals 1

    .prologue
    .line 399
    iget-object v0, p0, Ltas/internal/camera/InputSource$Hook;->impl:Ltas/internal/camera/InputSourceInner;

    invoke-virtual {v0}, Ltas/internal/camera/InputSourceInner;->isOpened()Z

    move-result v0

    return v0
.end method

.method onClose(Ltas/internal/camera/InputSource;)V
    .locals 1
    .param p1, "target"    # Ltas/internal/camera/InputSource;

    .prologue
    .line 446
    iget-object v0, p0, Ltas/internal/camera/InputSource$Hook;->input:Ltas/internal/camera/InputSource;

    invoke-virtual {v0, p1}, Ltas/internal/camera/InputSource;->onClose(Ltas/internal/camera/InputSource;)V

    .line 445
    return-void
.end method

.method onCommand(Ltas/internal/camera/InputSource;Ltas/camera/CameraCommand;Ljava/lang/String;)I
    .locals 1
    .param p1, "target"    # Ltas/internal/camera/InputSource;
    .param p2, "cmd"    # Ltas/camera/CameraCommand;
    .param p3, "proc"    # Ljava/lang/String;

    .prologue
    .line 426
    iget-object v0, p0, Ltas/internal/camera/InputSource$Hook;->input:Ltas/internal/camera/InputSource;

    invoke-virtual {v0, p1, p2, p3}, Ltas/internal/camera/InputSource;->onCommand(Ltas/internal/camera/InputSource;Ltas/camera/CameraCommand;Ljava/lang/String;)I

    move-result v0

    return v0
.end method

.method onOpen(Ltas/internal/camera/InputSource;)V
    .locals 1
    .param p1, "target"    # Ltas/internal/camera/InputSource;

    .prologue
    .line 442
    iget-object v0, p0, Ltas/internal/camera/InputSource$Hook;->input:Ltas/internal/camera/InputSource;

    invoke-virtual {v0, p1}, Ltas/internal/camera/InputSource;->onOpen(Ltas/internal/camera/InputSource;)V

    .line 441
    return-void
.end method

.method onPlug()V
    .locals 1

    .prologue
    .line 434
    iget-object v0, p0, Ltas/internal/camera/InputSource$Hook;->input:Ltas/internal/camera/InputSource;

    invoke-virtual {v0}, Ltas/internal/camera/InputSource;->onPlug()V

    .line 433
    return-void
.end method

.method onRequest(Ljava/lang/String;)I
    .locals 1
    .param p1, "proc"    # Ljava/lang/String;

    .prologue
    .line 421
    iget-object v0, p0, Ltas/internal/camera/InputSource$Hook;->input:Ltas/internal/camera/InputSource;

    invoke-virtual {v0, p1}, Ltas/internal/camera/InputSource;->onRequest(Ljava/lang/String;)I

    move-result v0

    return v0
.end method

.method onStateChanged(I)Z
    .locals 1
    .param p1, "state"    # I

    .prologue
    .line 430
    iget-object v0, p0, Ltas/internal/camera/InputSource$Hook;->input:Ltas/internal/camera/InputSource;

    invoke-virtual {v0, p1}, Ltas/internal/camera/InputSource;->onStateChanged(I)Z

    move-result v0

    return v0
.end method

.method onSystemMasterClear(Ljava/lang/String;)V
    .locals 1
    .param p1, "reason"    # Ljava/lang/String;

    .prologue
    .line 454
    iget-object v0, p0, Ltas/internal/camera/InputSource$Hook;->input:Ltas/internal/camera/InputSource;

    invoke-virtual {v0, p1}, Ltas/internal/camera/InputSource;->onSystemMasterClear(Ljava/lang/String;)V

    .line 453
    return-void
.end method

.method onSystemShutdown()V
    .locals 1

    .prologue
    .line 450
    iget-object v0, p0, Ltas/internal/camera/InputSource$Hook;->input:Ltas/internal/camera/InputSource;

    invoke-virtual {v0}, Ltas/internal/camera/InputSource;->onSystemShutdown()V

    .line 449
    return-void
.end method

.method onUnplug()V
    .locals 1

    .prologue
    .line 438
    iget-object v0, p0, Ltas/internal/camera/InputSource$Hook;->input:Ltas/internal/camera/InputSource;

    invoke-virtual {v0}, Ltas/internal/camera/InputSource;->onUnplug()V

    .line 437
    return-void
.end method
