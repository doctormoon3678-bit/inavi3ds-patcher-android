.class public interface abstract Ltas/internal/avm/IAvmStatusListener;
.super Ljava/lang/Object;
.source "IAvmStatusListener.java"


# virtual methods
.method public abstract onBootModeReceived(Ltas/internal/avm/AvmEnumerations$BootMode;)V
.end method

.method public abstract onCalibrationStatusReceived(Ltas/internal/avm/AvmEnumerations$CalibrationStatus;)V
.end method

.method public abstract onConnectionStatusChanged(I)V
.end method

.method public abstract onMessageReceived(Ljava/lang/String;)V
.end method

.method public abstract onPGSReceived(Ltas/internal/avm/AvmEnumerations$ViewMode;[B)V
.end method

.method public abstract onSetupDataReceived(Ljava/util/Map;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map",
            "<",
            "Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;",
            "Ljava/lang/Byte;",
            ">;)V"
        }
    .end annotation
.end method

.method public abstract onTopViewCoordReceived([B)V
.end method

.method public abstract onUpgradeStatusReceived(Ltas/internal/avm/AvmEnumerations$UpgradeMode;)V
.end method

.method public abstract onViewModeAck(Ltas/internal/avm/AvmEnumerations$ViewMode;)V
.end method
