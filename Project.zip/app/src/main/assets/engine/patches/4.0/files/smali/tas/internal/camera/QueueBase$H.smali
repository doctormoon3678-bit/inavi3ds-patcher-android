.class Ltas/internal/camera/QueueBase$H;
.super Landroid/os/Handler;
.source "QueueBase.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltas/internal/camera/QueueBase;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "H"
.end annotation


# instance fields
.field private mM:Ljava/lang/ref/WeakReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference",
            "<",
            "Ltas/internal/camera/QueueBase;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method private constructor <init>(Ltas/internal/camera/QueueBase;Landroid/os/Looper;)V
    .locals 1
    .param p1, "m"    # Ltas/internal/camera/QueueBase;
    .param p2, "l"    # Landroid/os/Looper;

    .prologue
    .line 207
    .local p0, "this":Ltas/internal/camera/QueueBase$H;, "Ltas/internal/camera/QueueBase<TT;>.H;"
    invoke-direct {p0, p2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    new-instance v0, Ljava/lang/ref/WeakReference;

    invoke-direct {v0, p1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    iput-object v0, p0, Ltas/internal/camera/QueueBase$H;->mM:Ljava/lang/ref/WeakReference;

    .line 206
    return-void
.end method

.method synthetic constructor <init>(Ltas/internal/camera/QueueBase;Landroid/os/Looper;Ltas/internal/camera/QueueBase$H;)V
    .locals 0
    .param p1, "m"    # Ltas/internal/camera/QueueBase;
    .param p2, "l"    # Landroid/os/Looper;

    .prologue
    .local p0, "this":Ltas/internal/camera/QueueBase$H;, "Ltas/internal/camera/QueueBase<TT;>.H;"
    invoke-direct {p0, p1, p2}, Ltas/internal/camera/QueueBase$H;-><init>(Ltas/internal/camera/QueueBase;Landroid/os/Looper;)V

    return-void
.end method


# virtual methods
.method public handleMessage(Landroid/os/Message;)V
    .locals 2
    .param p1, "msg"    # Landroid/os/Message;

    .prologue
    .line 210
    .local p0, "this":Ltas/internal/camera/QueueBase$H;, "Ltas/internal/camera/QueueBase<TT;>.H;"
    iget-object v1, p0, Ltas/internal/camera/QueueBase$H;->mM:Ljava/lang/ref/WeakReference;

    invoke-virtual {v1}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/camera/QueueBase;

    .line 211
    .local v0, "m":Ltas/internal/camera/QueueBase;
    if-eqz v0, :cond_0

    invoke-virtual {v0, p1}, Ltas/internal/camera/QueueBase;->handleMessage(Landroid/os/Message;)V

    .line 209
    :cond_0
    return-void
.end method
