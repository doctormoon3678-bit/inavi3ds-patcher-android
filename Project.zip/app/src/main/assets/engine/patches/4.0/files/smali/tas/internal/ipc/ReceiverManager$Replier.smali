.class Ltas/internal/ipc/ReceiverManager$Replier;
.super Ljava/lang/Object;
.source "ReceiverManager.java"

# interfaces
.implements Landroid/os/IBinder$DeathRecipient;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltas/internal/ipc/ReceiverManager;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "Replier"
.end annotation


# instance fields
.field private mReceiver:Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;

.field private mRemote:Ltas/internal/ipc/server/IRemoteTransmitter;

.field private mSender:Ltas/internal/ipc/server/RemoteSender;

.field final synthetic this$0:Ltas/internal/ipc/ReceiverManager;


# direct methods
.method constructor <init>(Ltas/internal/ipc/ReceiverManager;Ltas/internal/ipc/server/RemoteSender;Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;)V
    .locals 1
    .param p1, "this$0"    # Ltas/internal/ipc/ReceiverManager;
    .param p2, "sender"    # Ltas/internal/ipc/server/RemoteSender;
    .param p3, "rw"    # Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;

    .prologue
    .line 557
    iput-object p1, p0, Ltas/internal/ipc/ReceiverManager$Replier;->this$0:Ltas/internal/ipc/ReceiverManager;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 558
    iput-object p2, p0, Ltas/internal/ipc/ReceiverManager$Replier;->mSender:Ltas/internal/ipc/server/RemoteSender;

    .line 559
    iput-object p3, p0, Ltas/internal/ipc/ReceiverManager$Replier;->mReceiver:Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;

    .line 560
    iget-object v0, p2, Ltas/internal/ipc/server/RemoteSender;->replier:Landroid/os/IBinder;

    invoke-static {v0}, Ltas/internal/ipc/server/IRemoteTransmitter$Stub;->asInterface(Landroid/os/IBinder;)Ltas/internal/ipc/server/IRemoteTransmitter;

    move-result-object v0

    iput-object v0, p0, Ltas/internal/ipc/ReceiverManager$Replier;->mRemote:Ltas/internal/ipc/server/IRemoteTransmitter;

    .line 561
    iget-object v0, p2, Ltas/internal/ipc/server/RemoteSender;->replier:Landroid/os/IBinder;

    invoke-direct {p0, v0}, Ltas/internal/ipc/ReceiverManager$Replier;->linkToDeath(Landroid/os/IBinder;)V

    .line 562
    const/4 v0, 0x0

    iput-object v0, p2, Ltas/internal/ipc/server/RemoteSender;->replier:Landroid/os/IBinder;

    .line 557
    return-void
.end method

.method private linkToDeath(Landroid/os/IBinder;)V
    .locals 3
    .param p1, "binder"    # Landroid/os/IBinder;

    .prologue
    .line 595
    const/4 v1, 0x0

    :try_start_0
    invoke-interface {p1, p0, v1}, Landroid/os/IBinder;->linkToDeath(Landroid/os/IBinder$DeathRecipient;I)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    .line 593
    :goto_0
    return-void

    .line 596
    :catch_0
    move-exception v0

    .line 597
    .local v0, "e":Landroid/os/RemoteException;
    const-string/jumbo v1, "TasIPC<ReceiverManager>"

    const-string/jumbo v2, "failed to linkToDeath."

    invoke-static {v1, v2, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    goto :goto_0
.end method


# virtual methods
.method public binderDied()V
    .locals 3

    .prologue
    .line 589
    const-string/jumbo v0, "TasIPC<ReceiverManager>"

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "["

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Ltas/internal/ipc/ReceiverManager$Replier;->mSender:Ltas/internal/ipc/server/RemoteSender;

    iget-object v2, v2, Ltas/internal/ipc/server/RemoteSender;->name:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string/jumbo v2, "] replier died."

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 590
    const/4 v0, 0x0

    iput-object v0, p0, Ltas/internal/ipc/ReceiverManager$Replier;->mRemote:Ltas/internal/ipc/server/IRemoteTransmitter;

    .line 588
    return-void
.end method

.method reply(Ltas/ipc/MsgData;)V
    .locals 4
    .param p1, "msg"    # Ltas/ipc/MsgData;

    .prologue
    .line 566
    iget-object v2, p0, Ltas/internal/ipc/ReceiverManager$Replier;->mRemote:Ltas/internal/ipc/server/IRemoteTransmitter;

    if-nez v2, :cond_0

    .line 567
    const-string/jumbo v2, "TasIPC<ReceiverManager>"

    const-string/jumbo v3, "replier not available"

    invoke-static {v2, v3}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 568
    return-void

    .line 576
    :cond_0
    iget-object v2, p0, Ltas/internal/ipc/ReceiverManager$Replier;->mSender:Ltas/internal/ipc/server/RemoteSender;

    iget-object v3, p0, Ltas/internal/ipc/ReceiverManager$Replier;->mReceiver:Ltas/internal/ipc/ReceiverManager$ReceiverWrapper;

    invoke-static {v2, v3, p1}, Ltas/internal/ipc/server/RemoteMessage;->obtain(Ltas/internal/ipc/server/RemoteSender;Ltas/internal/ipc/server/RemoteReceiver;Ltas/ipc/MsgData;)Ltas/internal/ipc/server/RemoteMessage;

    move-result-object v1

    .line 579
    .local v1, "rmsg":Ltas/internal/ipc/server/RemoteMessage;
    :try_start_0
    iget-object v2, p0, Ltas/internal/ipc/ReceiverManager$Replier;->mRemote:Ltas/internal/ipc/server/IRemoteTransmitter;

    invoke-interface {v2, v1}, Ltas/internal/ipc/server/IRemoteTransmitter;->transmit(Ltas/internal/ipc/server/RemoteMessage;)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 583
    invoke-virtual {v1}, Ltas/internal/ipc/server/RemoteMessage;->recycle()V

    .line 565
    :goto_0
    return-void

    .line 580
    :catch_0
    move-exception v0

    .line 581
    .local v0, "e":Landroid/os/RemoteException;
    :try_start_1
    const-string/jumbo v2, "TasIPC<ReceiverManager>"

    const-string/jumbo v3, "failed to reply."

    invoke-static {v2, v3, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 583
    invoke-virtual {v1}, Ltas/internal/ipc/server/RemoteMessage;->recycle()V

    goto :goto_0

    .line 582
    .end local v0    # "e":Landroid/os/RemoteException;
    :catchall_0
    move-exception v2

    .line 583
    invoke-virtual {v1}, Ltas/internal/ipc/server/RemoteMessage;->recycle()V

    .line 582
    throw v2
.end method
