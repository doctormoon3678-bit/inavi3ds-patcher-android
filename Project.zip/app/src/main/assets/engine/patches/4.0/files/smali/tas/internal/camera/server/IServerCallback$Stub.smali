.class public abstract Ltas/internal/camera/server/IServerCallback$Stub;
.super Landroid/os/Binder;
.source "IServerCallback.java"

# interfaces
.implements Ltas/internal/camera/server/IServerCallback;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltas/internal/camera/server/IServerCallback;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "Stub"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ltas/internal/camera/server/IServerCallback$Stub$Proxy;
    }
.end annotation


# static fields
.field private static final DESCRIPTOR:Ljava/lang/String; = "tas.internal.camera.server.IServerCallback"

.field static final TRANSACTION_onCableState:I = 0x2

.field static final TRANSACTION_onCameraMessage:I = 0x5

.field static final TRANSACTION_onCameraState:I = 0x3

.field static final TRANSACTION_onExtraState:I = 0x4

.field static final TRANSACTION_onInitialState:I = 0x1

.field static final TRANSACTION_onMediaServerState:I = 0x6


# direct methods
.method public constructor <init>()V
    .locals 1

    .prologue
    .line 13
    invoke-direct {p0}, Landroid/os/Binder;-><init>()V

    .line 15
    const-string/jumbo v0, "tas.internal.camera.server.IServerCallback"

    invoke-virtual {p0, p0, v0}, Ltas/internal/camera/server/IServerCallback$Stub;->attachInterface(Landroid/os/IInterface;Ljava/lang/String;)V

    .line 13
    return-void
.end method

.method public static asInterface(Landroid/os/IBinder;)Ltas/internal/camera/server/IServerCallback;
    .locals 2
    .param p0, "obj"    # Landroid/os/IBinder;

    .prologue
    const/4 v1, 0x0

    .line 23
    if-nez p0, :cond_0

    .line 24
    return-object v1

    .line 26
    :cond_0
    const-string/jumbo v1, "tas.internal.camera.server.IServerCallback"

    invoke-interface {p0, v1}, Landroid/os/IBinder;->queryLocalInterface(Ljava/lang/String;)Landroid/os/IInterface;

    move-result-object v0

    .line 27
    .local v0, "iin":Landroid/os/IInterface;
    if-eqz v0, :cond_1

    instance-of v1, v0, Ltas/internal/camera/server/IServerCallback;

    if-eqz v1, :cond_1

    .line 28
    check-cast v0, Ltas/internal/camera/server/IServerCallback;

    .end local v0    # "iin":Landroid/os/IInterface;
    return-object v0

    .line 30
    .restart local v0    # "iin":Landroid/os/IInterface;
    :cond_1
    new-instance v1, Ltas/internal/camera/server/IServerCallback$Stub$Proxy;

    invoke-direct {v1, p0}, Ltas/internal/camera/server/IServerCallback$Stub$Proxy;-><init>(Landroid/os/IBinder;)V

    return-object v1
.end method


# virtual methods
.method public asBinder()Landroid/os/IBinder;
    .locals 0

    .prologue
    .line 34
    return-object p0
.end method

.method public onTransact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    .locals 3
    .param p1, "code"    # I
    .param p2, "data"    # Landroid/os/Parcel;
    .param p3, "reply"    # Landroid/os/Parcel;
    .param p4, "flags"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .prologue
    const/4 v2, 0x1

    .line 38
    sparse-switch p1, :sswitch_data_0

    .line 130
    invoke-super {p0, p1, p2, p3, p4}, Landroid/os/Binder;->onTransact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z

    move-result v1

    return v1

    .line 42
    :sswitch_0
    const-string/jumbo v1, "tas.internal.camera.server.IServerCallback"

    invoke-virtual {p3, v1}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    .line 43
    return v2

    .line 47
    :sswitch_1
    const-string/jumbo v1, "tas.internal.camera.server.IServerCallback"

    invoke-virtual {p2, v1}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 49
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    if-eqz v1, :cond_0

    .line 50
    sget-object v1, Ltas/internal/camera/server/RemoteMessage;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-interface {v1, p2}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/camera/server/RemoteMessage;

    .line 55
    :goto_0
    invoke-virtual {p0, v0}, Ltas/internal/camera/server/IServerCallback$Stub;->onInitialState(Ltas/internal/camera/server/RemoteMessage;)V

    .line 56
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 57
    return v2

    .line 53
    :cond_0
    const/4 v0, 0x0

    .local v0, "_arg0":Ltas/internal/camera/server/RemoteMessage;
    goto :goto_0

    .line 61
    .end local v0    # "_arg0":Ltas/internal/camera/server/RemoteMessage;
    :sswitch_2
    const-string/jumbo v1, "tas.internal.camera.server.IServerCallback"

    invoke-virtual {p2, v1}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 63
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    if-eqz v1, :cond_1

    .line 64
    sget-object v1, Ltas/internal/camera/server/RemoteMessage;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-interface {v1, p2}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/camera/server/RemoteMessage;

    .line 69
    :goto_1
    invoke-virtual {p0, v0}, Ltas/internal/camera/server/IServerCallback$Stub;->onCableState(Ltas/internal/camera/server/RemoteMessage;)V

    .line 70
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 71
    return v2

    .line 67
    :cond_1
    const/4 v0, 0x0

    .restart local v0    # "_arg0":Ltas/internal/camera/server/RemoteMessage;
    goto :goto_1

    .line 75
    .end local v0    # "_arg0":Ltas/internal/camera/server/RemoteMessage;
    :sswitch_3
    const-string/jumbo v1, "tas.internal.camera.server.IServerCallback"

    invoke-virtual {p2, v1}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 77
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    if-eqz v1, :cond_2

    .line 78
    sget-object v1, Ltas/internal/camera/server/RemoteMessage;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-interface {v1, p2}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/camera/server/RemoteMessage;

    .line 83
    :goto_2
    invoke-virtual {p0, v0}, Ltas/internal/camera/server/IServerCallback$Stub;->onCameraState(Ltas/internal/camera/server/RemoteMessage;)V

    .line 84
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 85
    return v2

    .line 81
    :cond_2
    const/4 v0, 0x0

    .restart local v0    # "_arg0":Ltas/internal/camera/server/RemoteMessage;
    goto :goto_2

    .line 89
    .end local v0    # "_arg0":Ltas/internal/camera/server/RemoteMessage;
    :sswitch_4
    const-string/jumbo v1, "tas.internal.camera.server.IServerCallback"

    invoke-virtual {p2, v1}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 91
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    if-eqz v1, :cond_3

    .line 92
    sget-object v1, Ltas/internal/camera/server/RemoteMessage;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-interface {v1, p2}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/camera/server/RemoteMessage;

    .line 97
    :goto_3
    invoke-virtual {p0, v0}, Ltas/internal/camera/server/IServerCallback$Stub;->onExtraState(Ltas/internal/camera/server/RemoteMessage;)V

    .line 98
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 99
    return v2

    .line 95
    :cond_3
    const/4 v0, 0x0

    .restart local v0    # "_arg0":Ltas/internal/camera/server/RemoteMessage;
    goto :goto_3

    .line 103
    .end local v0    # "_arg0":Ltas/internal/camera/server/RemoteMessage;
    :sswitch_5
    const-string/jumbo v1, "tas.internal.camera.server.IServerCallback"

    invoke-virtual {p2, v1}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 105
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    if-eqz v1, :cond_4

    .line 106
    sget-object v1, Ltas/internal/camera/server/RemoteMessage;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-interface {v1, p2}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/camera/server/RemoteMessage;

    .line 111
    :goto_4
    invoke-virtual {p0, v0}, Ltas/internal/camera/server/IServerCallback$Stub;->onCameraMessage(Ltas/internal/camera/server/RemoteMessage;)V

    .line 112
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 113
    return v2

    .line 109
    :cond_4
    const/4 v0, 0x0

    .restart local v0    # "_arg0":Ltas/internal/camera/server/RemoteMessage;
    goto :goto_4

    .line 117
    .end local v0    # "_arg0":Ltas/internal/camera/server/RemoteMessage;
    :sswitch_6
    const-string/jumbo v1, "tas.internal.camera.server.IServerCallback"

    invoke-virtual {p2, v1}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 119
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    if-eqz v1, :cond_5

    .line 120
    sget-object v1, Ltas/internal/camera/server/RemoteMessage;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-interface {v1, p2}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/camera/server/RemoteMessage;

    .line 125
    :goto_5
    invoke-virtual {p0, v0}, Ltas/internal/camera/server/IServerCallback$Stub;->onMediaServerState(Ltas/internal/camera/server/RemoteMessage;)V

    .line 126
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 127
    return v2

    .line 123
    :cond_5
    const/4 v0, 0x0

    .restart local v0    # "_arg0":Ltas/internal/camera/server/RemoteMessage;
    goto :goto_5

    .line 38
    :sswitch_data_0
    .sparse-switch
        0x1 -> :sswitch_1
        0x2 -> :sswitch_2
        0x3 -> :sswitch_3
        0x4 -> :sswitch_4
        0x5 -> :sswitch_5
        0x6 -> :sswitch_6
        0x5f4e5446 -> :sswitch_0
    .end sparse-switch
.end method
