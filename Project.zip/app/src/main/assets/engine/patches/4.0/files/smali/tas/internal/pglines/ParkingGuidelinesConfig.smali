.class public final Ltas/internal/pglines/ParkingGuidelinesConfig;
.super Ljava/lang/Object;
.source "ParkingGuidelinesConfig.java"


# static fields
.field private static final DEBUG:Z = true

.field private static final ERROR_ACCESS:I = -0xfe

.field private static final ERROR_ONOFF:I = -0xff

.field private static final ERROR_WRITE:I = -0xfd

.field private static final TAG:Ljava/lang/String; = "ParkingGuidelinesConfig"


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .prologue
    .line 13
    const-string/jumbo v0, "twpglinesconfig_jni"

    invoke-static {v0}, Ljava/lang/System;->loadLibrary(Ljava/lang/String;)V

    .line 3
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .prologue
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static savePGLinesSetting(Ljava/lang/String;)V
    .locals 4
    .param p0, "pglinesSetting"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ltas/internal/pglines/ParkingGuidelinesConfigException;
        }
    .end annotation

    .prologue
    .line 22
    const-string/jumbo v1, "ParkingGuidelinesConfig"

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "savePGLinesConfigSettings: "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 26
    invoke-static {p0}, Ltas/internal/pglines/ParkingGuidelinesConfig;->tryToSavePGLinesConfigSetting(Ljava/lang/String;)I

    move-result v0

    .line 28
    .local v0, "ret":I
    packed-switch v0, :pswitch_data_0

    .line 19
    return-void

    .line 30
    :pswitch_0
    new-instance v1, Ltas/internal/pglines/ParkingGuidelinesConfigException;

    .line 31
    const-string/jumbo v2, "save error: incorrect input on/off values"

    .line 30
    invoke-direct {v1, v2}, Ltas/internal/pglines/ParkingGuidelinesConfigException;-><init>(Ljava/lang/String;)V

    throw v1

    .line 34
    :pswitch_1
    new-instance v1, Ltas/internal/pglines/ParkingGuidelinesConfigException;

    .line 35
    const-string/jumbo v2, "save error: access denied"

    .line 34
    invoke-direct {v1, v2}, Ltas/internal/pglines/ParkingGuidelinesConfigException;-><init>(Ljava/lang/String;)V

    throw v1

    .line 38
    :pswitch_2
    new-instance v1, Ltas/internal/pglines/ParkingGuidelinesConfigException;

    .line 39
    const-string/jumbo v2, "save error: writing failure"

    .line 38
    invoke-direct {v1, v2}, Ltas/internal/pglines/ParkingGuidelinesConfigException;-><init>(Ljava/lang/String;)V

    throw v1

    .line 28
    nop

    :pswitch_data_0
    .packed-switch -0xff
        :pswitch_0
        :pswitch_1
        :pswitch_2
    .end packed-switch
.end method

.method private static native tryToSavePGLinesConfigSetting(Ljava/lang/String;)I
.end method
