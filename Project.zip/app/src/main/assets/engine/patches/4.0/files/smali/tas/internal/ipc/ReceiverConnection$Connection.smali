.class Ltas/internal/ipc/ReceiverConnection$Connection;
.super Ltas/internal/ipc/util/ServiceConnectionAbstract;
.source "ReceiverConnection.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltas/internal/ipc/ReceiverConnection;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "Connection"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ltas/internal/ipc/util/ServiceConnectionAbstract",
        "<",
        "Ltas/internal/ipc/server/IRemoteTransmitter;",
        ">;"
    }
.end annotation


# static fields
.field private static final MSG_TRANSMIT:I = 0x65


# direct methods
.method constructor <init>(Ljava/lang/String;Landroid/os/Looper;)V
    .locals 0
    .param p1, "name"    # Ljava/lang/String;
    .param p2, "l"    # Landroid/os/Looper;

    .prologue
    .line 85
    invoke-direct {p0, p1, p2}, Ltas/internal/ipc/util/ServiceConnectionAbstract;-><init>(Ljava/lang/String;Landroid/os/Looper;)V

    .line 84
    return-void
.end method


# virtual methods
.method public bridge synthetic handleMessage(Landroid/os/IInterface;Landroid/os/Message;)V
    .locals 0
    .param p1, "remote"    # Landroid/os/IInterface;
    .param p2, "msg"    # Landroid/os/Message;

    .prologue
    .line 98
    check-cast p1, Ltas/internal/ipc/server/IRemoteTransmitter;

    .end local p1    # "remote":Landroid/os/IInterface;
    invoke-virtual {p0, p1, p2}, Ltas/internal/ipc/ReceiverConnection$Connection;->handleMessage(Ltas/internal/ipc/server/IRemoteTransmitter;Landroid/os/Message;)V

    return-void
.end method

.method public handleMessage(Ltas/internal/ipc/server/IRemoteTransmitter;Landroid/os/Message;)V
    .locals 4
    .param p1, "remote"    # Ltas/internal/ipc/server/IRemoteTransmitter;
    .param p2, "msg"    # Landroid/os/Message;

    .prologue
    .line 100
    iget v2, p2, Landroid/os/Message;->what:I

    packed-switch v2, :pswitch_data_0

    .line 98
    :goto_0
    return-void

    .line 102
    :pswitch_0
    iget-object v1, p2, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v1, Ltas/internal/ipc/server/RemoteMessage;

    .line 104
    .local v1, "remoteMessage":Ltas/internal/ipc/server/RemoteMessage;
    :try_start_0
    invoke-interface {p1, v1}, Ltas/internal/ipc/server/IRemoteTransmitter;->transmit(Ltas/internal/ipc/server/RemoteMessage;)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 108
    invoke-virtual {v1}, Ltas/internal/ipc/server/RemoteMessage;->recycle()V

    goto :goto_0

    .line 105
    :catch_0
    move-exception v0

    .line 106
    .local v0, "e":Landroid/os/RemoteException;
    :try_start_1
    const-string/jumbo v2, "TasIPC<ReceiverConnection>"

    const-string/jumbo v3, "failed to send."

    invoke-static {v2, v3, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 108
    invoke-virtual {v1}, Ltas/internal/ipc/server/RemoteMessage;->recycle()V

    goto :goto_0

    .line 107
    .end local v0    # "e":Landroid/os/RemoteException;
    :catchall_0
    move-exception v2

    .line 108
    invoke-virtual {v1}, Ltas/internal/ipc/server/RemoteMessage;->recycle()V

    .line 107
    throw v2

    .line 100
    :pswitch_data_0
    .packed-switch 0x65
        :pswitch_0
    .end packed-switch
.end method

.method public bridge synthetic onConnected(Landroid/os/IBinder;)Landroid/os/IInterface;
    .locals 1
    .param p1, "binder"    # Landroid/os/IBinder;

    .prologue
    .line 93
    invoke-virtual {p0, p1}, Ltas/internal/ipc/ReceiverConnection$Connection;->onConnected(Landroid/os/IBinder;)Ltas/internal/ipc/server/IRemoteTransmitter;

    move-result-object v0

    return-object v0
.end method

.method public onConnected(Landroid/os/IBinder;)Ltas/internal/ipc/server/IRemoteTransmitter;
    .locals 1
    .param p1, "binder"    # Landroid/os/IBinder;

    .prologue
    .line 94
    invoke-static {p1}, Ltas/internal/ipc/server/IRemoteTransmitter$Stub;->asInterface(Landroid/os/IBinder;)Ltas/internal/ipc/server/IRemoteTransmitter;

    move-result-object v0

    return-object v0
.end method

.method transmit(Ltas/internal/ipc/server/RemoteMessage;)V
    .locals 1
    .param p1, "msg"    # Ltas/internal/ipc/server/RemoteMessage;

    .prologue
    .line 89
    const/16 v0, 0x65

    invoke-virtual {p0, v0, p1}, Ltas/internal/ipc/ReceiverConnection$Connection;->schedule(ILjava/lang/Object;)V

    .line 88
    return-void
.end method
