.class Ltas/internal/ipc/ReceiverConnection;
.super Ljava/lang/Object;
.source "ReceiverConnection.java"

# interfaces
.implements Ltas/internal/ipc/util/ServiceConnectionAbstract$Callback;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ltas/internal/ipc/ReceiverConnection$Connection;
    }
.end annotation


# static fields
.field private static final DBG:Z = true

.field private static final TAG:Ljava/lang/String; = "TasIPC<ReceiverConnection>"


# instance fields
.field private C:Ltas/internal/ipc/ReceiverConnection$Connection;

.field private mContext:Landroid/content/Context;

.field private mReceiver:Ltas/internal/ipc/server/RemoteReceiver;


# direct methods
.method constructor <init>(Landroid/content/Context;Ltas/internal/ipc/server/RemoteReceiver;Landroid/os/Looper;)V
    .locals 2
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "receiver"    # Ltas/internal/ipc/server/RemoteReceiver;
    .param p3, "l"    # Landroid/os/Looper;

    .prologue
    .line 33
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 34
    iput-object p1, p0, Ltas/internal/ipc/ReceiverConnection;->mContext:Landroid/content/Context;

    .line 35
    iput-object p2, p0, Ltas/internal/ipc/ReceiverConnection;->mReceiver:Ltas/internal/ipc/server/RemoteReceiver;

    .line 36
    new-instance v0, Ltas/internal/ipc/ReceiverConnection$Connection;

    const-string/jumbo v1, "RConnection-Remote"

    invoke-direct {v0, v1, p3}, Ltas/internal/ipc/ReceiverConnection$Connection;-><init>(Ljava/lang/String;Landroid/os/Looper;)V

    iput-object v0, p0, Ltas/internal/ipc/ReceiverConnection;->C:Ltas/internal/ipc/ReceiverConnection$Connection;

    .line 37
    iget-object v0, p0, Ltas/internal/ipc/ReceiverConnection;->C:Ltas/internal/ipc/ReceiverConnection$Connection;

    invoke-virtual {v0, p0}, Ltas/internal/ipc/ReceiverConnection$Connection;->addCallback(Ltas/internal/ipc/util/ServiceConnectionAbstract$Callback;)V

    .line 33
    return-void
.end method


# virtual methods
.method public connect()V
    .locals 5

    .prologue
    .line 62
    iget-object v0, p0, Ltas/internal/ipc/ReceiverConnection;->C:Ltas/internal/ipc/ReceiverConnection$Connection;

    iget-object v1, p0, Ltas/internal/ipc/ReceiverConnection;->mContext:Landroid/content/Context;

    iget-object v2, p0, Ltas/internal/ipc/ReceiverConnection;->mReceiver:Ltas/internal/ipc/server/RemoteReceiver;

    iget-object v2, v2, Ltas/internal/ipc/server/RemoteReceiver;->pkg:Ljava/lang/String;

    .line 63
    const-class v3, Ltas/ipc/MsgReceiverService;

    invoke-virtual {v3}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v3

    .line 64
    const/4 v4, 0x1

    .line 62
    invoke-virtual {v0, v1, v2, v3, v4}, Ltas/internal/ipc/ReceiverConnection$Connection;->connect(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;I)V

    .line 61
    return-void
.end method

.method public disconnect()V
    .locals 1

    .prologue
    .line 68
    iget-object v0, p0, Ltas/internal/ipc/ReceiverConnection;->C:Ltas/internal/ipc/ReceiverConnection$Connection;

    invoke-virtual {v0}, Ltas/internal/ipc/ReceiverConnection$Connection;->disconnect()V

    .line 67
    return-void
.end method

.method public getContext()Landroid/content/Context;
    .locals 1

    .prologue
    .line 41
    iget-object v0, p0, Ltas/internal/ipc/ReceiverConnection;->mContext:Landroid/content/Context;

    return-object v0
.end method

.method public getReceiver()Ltas/internal/ipc/server/RemoteReceiver;
    .locals 1

    .prologue
    .line 45
    iget-object v0, p0, Ltas/internal/ipc/ReceiverConnection;->mReceiver:Ltas/internal/ipc/server/RemoteReceiver;

    return-object v0
.end method

.method public isConnected()Z
    .locals 1

    .prologue
    .line 58
    iget-object v0, p0, Ltas/internal/ipc/ReceiverConnection;->C:Ltas/internal/ipc/ReceiverConnection$Connection;

    invoke-virtual {v0}, Ltas/internal/ipc/ReceiverConnection$Connection;->isConnected()Z

    move-result v0

    return v0
.end method

.method public onConnected()V
    .locals 0

    .prologue
    .line 49
    return-void
.end method

.method public onDeath()V
    .locals 0

    .prologue
    .line 55
    return-void
.end method

.method public onDisconnected()V
    .locals 0

    .prologue
    .line 52
    return-void
.end method

.method public quitSafely()V
    .locals 1

    .prologue
    .line 72
    iget-object v0, p0, Ltas/internal/ipc/ReceiverConnection;->C:Ltas/internal/ipc/ReceiverConnection$Connection;

    invoke-virtual {v0}, Ltas/internal/ipc/ReceiverConnection$Connection;->quitSafely()V

    .line 71
    return-void
.end method

.method public transmit(Ltas/internal/ipc/server/RemoteMessage;)V
    .locals 1
    .param p1, "msg"    # Ltas/internal/ipc/server/RemoteMessage;

    .prologue
    .line 76
    iget-object v0, p0, Ltas/internal/ipc/ReceiverConnection;->C:Ltas/internal/ipc/ReceiverConnection$Connection;

    invoke-virtual {v0, p1}, Ltas/internal/ipc/ReceiverConnection$Connection;->transmit(Ltas/internal/ipc/server/RemoteMessage;)V

    .line 75
    return-void
.end method
