.class public Ltas/ipc/SenderSession;
.super Ljava/lang/Object;
.source "SenderSession.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ltas/ipc/SenderSession$Callback;,
        Ltas/ipc/SenderSession$SimpleCallback;
    }
.end annotation


# instance fields
.field public cb:Ltas/ipc/SenderSession$Callback;

.field public final extra:Landroid/os/Bundle;

.field public final id:J

.field public final name:Ljava/lang/String;

.field public online:Z

.field public final owner:Ltas/internal/ipc/Sender;

.field public final p2pMode:Z

.field public final pkg:Ljava/lang/String;

.field public final q:Ljava/util/Queue;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Queue",
            "<",
            "Ltas/ipc/MsgData;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Ltas/internal/ipc/Sender;JLjava/lang/String;Ljava/lang/String;ZLandroid/os/Bundle;)V
    .locals 2
    .param p1, "_owner"    # Ltas/internal/ipc/Sender;
    .param p2, "_id"    # J
    .param p4, "_pkg"    # Ljava/lang/String;
    .param p5, "_name"    # Ljava/lang/String;
    .param p6, "_p2pMode"    # Z
    .param p7, "_extra"    # Landroid/os/Bundle;

    .prologue
    const/4 v1, 0x0

    .line 30
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 24
    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    iput-object v0, p0, Ltas/ipc/SenderSession;->extra:Landroid/os/Bundle;

    .line 27
    iput-object v1, p0, Ltas/ipc/SenderSession;->cb:Ltas/ipc/SenderSession$Callback;

    .line 28
    new-instance v0, Ljava/util/ArrayDeque;

    const/16 v1, 0xa

    invoke-direct {v0, v1}, Ljava/util/ArrayDeque;-><init>(I)V

    iput-object v0, p0, Ltas/ipc/SenderSession;->q:Ljava/util/Queue;

    .line 33
    iput-object p1, p0, Ltas/ipc/SenderSession;->owner:Ltas/internal/ipc/Sender;

    .line 34
    iput-wide p2, p0, Ltas/ipc/SenderSession;->id:J

    .line 35
    iput-object p4, p0, Ltas/ipc/SenderSession;->pkg:Ljava/lang/String;

    .line 36
    iput-object p5, p0, Ltas/ipc/SenderSession;->name:Ljava/lang/String;

    .line 37
    iput-boolean p6, p0, Ltas/ipc/SenderSession;->p2pMode:Z

    .line 38
    if-eqz p7, :cond_0

    .line 39
    iget-object v0, p0, Ltas/ipc/SenderSession;->extra:Landroid/os/Bundle;

    invoke-virtual {v0, p7}, Landroid/os/Bundle;->putAll(Landroid/os/Bundle;)V

    .line 41
    :cond_0
    const/4 v0, 0x1

    iput-boolean v0, p0, Ltas/ipc/SenderSession;->online:Z

    .line 32
    return-void
.end method


# virtual methods
.method public destroy()V
    .locals 4

    .prologue
    .line 48
    iget-object v0, p0, Ltas/ipc/SenderSession;->owner:Ltas/internal/ipc/Sender;

    iget-wide v2, p0, Ltas/ipc/SenderSession;->id:J

    invoke-virtual {v0, v2, v3}, Ltas/internal/ipc/Sender;->destroySession(J)V

    .line 47
    return-void
.end method

.method public dumpToString(Ljava/lang/StringBuilder;)Ljava/lang/StringBuilder;
    .locals 4
    .param p1, "sb"    # Ljava/lang/StringBuilder;

    .prologue
    .line 215
    const-string/jumbo v0, "RemoteReceiver {"

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 216
    const-string/jumbo v1, " id="

    .line 215
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 216
    iget-wide v2, p0, Ltas/ipc/SenderSession;->id:J

    .line 215
    invoke-virtual {v0, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 217
    const-string/jumbo v1, " name="

    .line 215
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 217
    iget-object v1, p0, Ltas/ipc/SenderSession;->name:Ljava/lang/String;

    .line 215
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 218
    const-string/jumbo v1, " online="

    .line 215
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 218
    iget-boolean v1, p0, Ltas/ipc/SenderSession;->online:Z

    .line 215
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 219
    const-string/jumbo v1, " }"

    .line 215
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    return-object v0
.end method

.method public send(I)V
    .locals 1
    .param p1, "what"    # I

    .prologue
    .line 55
    invoke-static {p1}, Ltas/ipc/MsgData;->obtain(I)Ltas/ipc/MsgData;

    move-result-object v0

    invoke-virtual {p0, v0}, Ltas/ipc/SenderSession;->send(Ltas/ipc/MsgData;)V

    .line 54
    return-void
.end method

.method public send(III)V
    .locals 1
    .param p1, "what"    # I
    .param p2, "arg1"    # I
    .param p3, "arg2"    # I

    .prologue
    .line 64
    invoke-static {p1, p2, p3}, Ltas/ipc/MsgData;->obtain(III)Ltas/ipc/MsgData;

    move-result-object v0

    invoke-virtual {p0, v0}, Ltas/ipc/SenderSession;->send(Ltas/ipc/MsgData;)V

    .line 63
    return-void
.end method

.method public varargs send(III[I)V
    .locals 1
    .param p1, "what"    # I
    .param p2, "arg1"    # I
    .param p3, "arg2"    # I
    .param p4, "args"    # [I

    .prologue
    .line 74
    invoke-static {p1, p2, p3, p4}, Ltas/ipc/MsgData;->obtain(III[I)Ltas/ipc/MsgData;

    move-result-object v0

    invoke-virtual {p0, v0}, Ltas/ipc/SenderSession;->send(Ltas/ipc/MsgData;)V

    .line 73
    return-void
.end method

.method public send(III[ILjava/lang/String;Ljava/lang/String;[BLandroid/os/Bundle;)V
    .locals 1
    .param p1, "what"    # I
    .param p2, "arg1"    # I
    .param p3, "arg2"    # I
    .param p4, "args"    # [I
    .param p5, "str1"    # Ljava/lang/String;
    .param p6, "str2"    # Ljava/lang/String;
    .param p7, "bytes"    # [B
    .param p8, "bundle"    # Landroid/os/Bundle;

    .prologue
    .line 131
    invoke-static/range {p1 .. p8}, Ltas/ipc/MsgData;->obtain(III[ILjava/lang/String;Ljava/lang/String;[BLandroid/os/Bundle;)Ltas/ipc/MsgData;

    move-result-object v0

    invoke-virtual {p0, v0}, Ltas/ipc/SenderSession;->send(Ltas/ipc/MsgData;)V

    .line 130
    return-void
.end method

.method public send(ILandroid/os/Bundle;)V
    .locals 1
    .param p1, "what"    # I
    .param p2, "bundle"    # Landroid/os/Bundle;

    .prologue
    .line 115
    invoke-static {p1, p2}, Ltas/ipc/MsgData;->obtain(ILandroid/os/Bundle;)Ltas/ipc/MsgData;

    move-result-object v0

    invoke-virtual {p0, v0}, Ltas/ipc/SenderSession;->send(Ltas/ipc/MsgData;)V

    .line 114
    return-void
.end method

.method public send(ILjava/lang/String;)V
    .locals 1
    .param p1, "what"    # I
    .param p2, "str1"    # Ljava/lang/String;

    .prologue
    .line 82
    invoke-static {p1, p2}, Ltas/ipc/MsgData;->obtain(ILjava/lang/String;)Ltas/ipc/MsgData;

    move-result-object v0

    invoke-virtual {p0, v0}, Ltas/ipc/SenderSession;->send(Ltas/ipc/MsgData;)V

    .line 81
    return-void
.end method

.method public send(ILjava/lang/String;Ljava/lang/String;)V
    .locals 1
    .param p1, "what"    # I
    .param p2, "str1"    # Ljava/lang/String;
    .param p3, "str2"    # Ljava/lang/String;

    .prologue
    .line 91
    invoke-static {p1, p2, p3}, Ltas/ipc/MsgData;->obtain(ILjava/lang/String;Ljava/lang/String;)Ltas/ipc/MsgData;

    move-result-object v0

    invoke-virtual {p0, v0}, Ltas/ipc/SenderSession;->send(Ltas/ipc/MsgData;)V

    .line 90
    return-void
.end method

.method public send(I[B)V
    .locals 1
    .param p1, "what"    # I
    .param p2, "bytes"    # [B

    .prologue
    .line 107
    invoke-static {p1, p2}, Ltas/ipc/MsgData;->obtain(I[B)Ltas/ipc/MsgData;

    move-result-object v0

    invoke-virtual {p0, v0}, Ltas/ipc/SenderSession;->send(Ltas/ipc/MsgData;)V

    .line 106
    return-void
.end method

.method public send(I[I)V
    .locals 1
    .param p1, "what"    # I
    .param p2, "args"    # [I

    .prologue
    .line 99
    invoke-static {p1, p2}, Ltas/ipc/MsgData;->obtain(I[I)Ltas/ipc/MsgData;

    move-result-object v0

    invoke-virtual {p0, v0}, Ltas/ipc/SenderSession;->send(Ltas/ipc/MsgData;)V

    .line 98
    return-void
.end method

.method public send(Ltas/ipc/MsgData;)V
    .locals 1
    .param p1, "msg"    # Ltas/ipc/MsgData;

    .prologue
    .line 138
    iget-object v0, p0, Ltas/ipc/SenderSession;->owner:Ltas/internal/ipc/Sender;

    invoke-virtual {v0, p0, p1}, Ltas/internal/ipc/Sender;->send(Ltas/ipc/SenderSession;Ltas/ipc/MsgData;)V

    .line 137
    return-void
.end method

.method public toString()Ljava/lang/String;
    .locals 1

    .prologue
    .line 223
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0, v0}, Ltas/ipc/SenderSession;->dumpToString(Ljava/lang/StringBuilder;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
