.class public Ltas/internal/camera/client/CameraProxy;
.super Ljava/lang/Object;
.source "CameraProxy.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ltas/internal/camera/client/CameraProxy$Dispatcher;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ltas/camera/CameraId;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation


# static fields
.field private static sServer:Ltas/internal/camera/client/ServerConnection;


# instance fields
.field final cam:Ltas/camera/CameraId;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TT;"
        }
    .end annotation
.end field

.field private mCameraListener:Ltas/camera/CameraListener;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ltas/camera/CameraListener",
            "<TT;>;"
        }
    .end annotation
.end field

.field private mDispatcher:Ltas/internal/camera/client/CameraProxy$Dispatcher;

.field private mPendingRequest:Z

.field private mStateListener:Ltas/camera/CameraStateListener;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ltas/camera/CameraStateListener",
            "<TT;>;"
        }
    .end annotation
.end field

.field private mWatched:Z


# direct methods
.method static synthetic -wrap0(Ltas/internal/camera/client/CameraProxy;Z)V
    .locals 0
    .param p1, "plugged"    # Z

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/camera/client/CameraProxy;->onCableState(Z)V

    return-void
.end method

.method static synthetic -wrap1(Ltas/internal/camera/client/CameraProxy;Ltas/camera/CameraMessage;)V
    .locals 0
    .param p1, "msg"    # Ltas/camera/CameraMessage;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/camera/client/CameraProxy;->onCameraMessage(Ltas/camera/CameraMessage;)V

    return-void
.end method

.method static synthetic -wrap2(Ltas/internal/camera/client/CameraProxy;Z)V
    .locals 0
    .param p1, "opened"    # Z

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/camera/client/CameraProxy;->onCameraState(Z)V

    return-void
.end method

.method static synthetic -wrap3(Ltas/internal/camera/client/CameraProxy;II)V
    .locals 0
    .param p1, "cmd"    # I
    .param p2, "result"    # I

    .prologue
    invoke-direct {p0, p1, p2}, Ltas/internal/camera/client/CameraProxy;->onCommandResult(II)V

    return-void
.end method

.method static synthetic -wrap4(Ltas/internal/camera/client/CameraProxy;II)V
    .locals 0
    .param p1, "state"    # I
    .param p2, "flag"    # I

    .prologue
    invoke-direct {p0, p1, p2}, Ltas/internal/camera/client/CameraProxy;->onExtraState(II)V

    return-void
.end method

.method static synthetic -wrap5(Ltas/internal/camera/client/CameraProxy;)V
    .locals 0

    invoke-direct {p0}, Ltas/internal/camera/client/CameraProxy;->onMediaServerDied()V

    return-void
.end method

.method static synthetic -wrap6(Ltas/internal/camera/client/CameraProxy;I)V
    .locals 0
    .param p1, "result"    # I

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/camera/client/CameraProxy;->onRequestResult(I)V

    return-void
.end method

.method static constructor <clinit>()V
    .locals 1

    .prologue
    .line 401
    invoke-static {}, Ltas/internal/camera/client/ServerConnection;->get()Ltas/internal/camera/client/ServerConnection;

    move-result-object v0

    sput-object v0, Ltas/internal/camera/client/CameraProxy;->sServer:Ltas/internal/camera/client/ServerConnection;

    .line 25
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Ltas/camera/CameraId;)V
    .locals 1
    .param p1, "context"    # Landroid/content/Context;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "TT;)V"
        }
    .end annotation

    .prologue
    .line 36
    .local p0, "this":Ltas/internal/camera/client/CameraProxy;, "Ltas/internal/camera/client/CameraProxy<TT;>;"
    .local p2, "_cam":Ltas/camera/CameraId;, "TT;"
    invoke-static {}, Landroid/os/Looper;->myLooper()Landroid/os/Looper;

    move-result-object v0

    invoke-direct {p0, p1, p2, v0}, Ltas/internal/camera/client/CameraProxy;-><init>(Landroid/content/Context;Ltas/camera/CameraId;Landroid/os/Looper;)V

    .line 35
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Ltas/camera/CameraId;Landroid/os/Looper;)V
    .locals 2
    .param p1, "context"    # Landroid/content/Context;
    .param p3, "l"    # Landroid/os/Looper;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "TT;",
            "Landroid/os/Looper;",
            ")V"
        }
    .end annotation

    .prologue
    .line 39
    .local p0, "this":Ltas/internal/camera/client/CameraProxy;, "Ltas/internal/camera/client/CameraProxy<TT;>;"
    .local p2, "_cam":Ltas/camera/CameraId;, "TT;"
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 40
    iput-object p2, p0, Ltas/internal/camera/client/CameraProxy;->cam:Ltas/camera/CameraId;

    .line 41
    new-instance v0, Ltas/internal/camera/client/CameraProxy$Dispatcher;

    const/4 v1, 0x0

    invoke-direct {v0, p3, p0, v1}, Ltas/internal/camera/client/CameraProxy$Dispatcher;-><init>(Landroid/os/Looper;Ltas/internal/camera/client/CameraProxy;Ltas/internal/camera/client/CameraProxy$Dispatcher;)V

    iput-object v0, p0, Ltas/internal/camera/client/CameraProxy;->mDispatcher:Ltas/internal/camera/client/CameraProxy$Dispatcher;

    .line 42
    invoke-direct {p0, p1}, Ltas/internal/camera/client/CameraProxy;->connectToServer(Landroid/content/Context;)V

    .line 39
    return-void
.end method

.method private cancelThisCamera()V
    .locals 1

    .prologue
    .line 390
    .local p0, "this":Ltas/internal/camera/client/CameraProxy;, "Ltas/internal/camera/client/CameraProxy<TT;>;"
    iget-object v0, p0, Ltas/internal/camera/client/CameraProxy;->mCameraListener:Ltas/camera/CameraListener;

    if-eqz v0, :cond_0

    .line 391
    sget-object v0, Ltas/internal/camera/client/CameraProxy;->sServer:Ltas/internal/camera/client/ServerConnection;

    invoke-virtual {v0, p0}, Ltas/internal/camera/client/ServerConnection;->cancel(Ltas/internal/camera/client/CameraProxy;)V

    .line 389
    :cond_0
    return-void
.end method

.method private commandThisCamera(Ltas/camera/CameraCommand;)V
    .locals 1
    .param p1, "cmd"    # Ltas/camera/CameraCommand;

    .prologue
    .line 396
    .local p0, "this":Ltas/internal/camera/client/CameraProxy;, "Ltas/internal/camera/client/CameraProxy<TT;>;"
    iget-object v0, p0, Ltas/internal/camera/client/CameraProxy;->mCameraListener:Ltas/camera/CameraListener;

    if-eqz v0, :cond_0

    .line 397
    sget-object v0, Ltas/internal/camera/client/CameraProxy;->sServer:Ltas/internal/camera/client/ServerConnection;

    invoke-virtual {v0, p0, p1}, Ltas/internal/camera/client/ServerConnection;->command(Ltas/internal/camera/client/CameraProxy;Ltas/camera/CameraCommand;)V

    .line 395
    :cond_0
    return-void
.end method

.method private connectToServer(Landroid/content/Context;)V
    .locals 1
    .param p1, "context"    # Landroid/content/Context;

    .prologue
    .line 355
    .local p0, "this":Ltas/internal/camera/client/CameraProxy;, "Ltas/internal/camera/client/CameraProxy<TT;>;"
    sget-object v0, Ltas/internal/camera/client/CameraProxy;->sServer:Ltas/internal/camera/client/ServerConnection;

    invoke-virtual {v0, p0}, Ltas/internal/camera/client/ServerConnection;->hasClient(Ltas/internal/camera/client/CameraProxy;)Z

    move-result v0

    if-nez v0, :cond_0

    .line 356
    sget-object v0, Ltas/internal/camera/client/CameraProxy;->sServer:Ltas/internal/camera/client/ServerConnection;

    invoke-virtual {v0, p1}, Ltas/internal/camera/client/ServerConnection;->connect(Landroid/content/Context;)V

    .line 357
    sget-object v0, Ltas/internal/camera/client/CameraProxy;->sServer:Ltas/internal/camera/client/ServerConnection;

    invoke-virtual {v0, p0}, Ltas/internal/camera/client/ServerConnection;->addClient(Ltas/internal/camera/client/CameraProxy;)V

    .line 354
    :cond_0
    return-void
.end method

.method private disconnectFromServer()V
    .locals 1

    .prologue
    .line 362
    .local p0, "this":Ltas/internal/camera/client/CameraProxy;, "Ltas/internal/camera/client/CameraProxy<TT;>;"
    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Ltas/internal/camera/client/CameraProxy;->setListener(Ltas/camera/BaseListener;)V

    .line 363
    sget-object v0, Ltas/internal/camera/client/CameraProxy;->sServer:Ltas/internal/camera/client/ServerConnection;

    invoke-virtual {v0, p0}, Ltas/internal/camera/client/ServerConnection;->hasClient(Ltas/internal/camera/client/CameraProxy;)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 364
    sget-object v0, Ltas/internal/camera/client/CameraProxy;->sServer:Ltas/internal/camera/client/ServerConnection;

    invoke-virtual {v0, p0}, Ltas/internal/camera/client/ServerConnection;->removeClient(Ltas/internal/camera/client/CameraProxy;)V

    .line 365
    sget-object v0, Ltas/internal/camera/client/CameraProxy;->sServer:Ltas/internal/camera/client/ServerConnection;

    invoke-virtual {v0}, Ltas/internal/camera/client/ServerConnection;->disconnect()V

    .line 361
    :cond_0
    return-void
.end method

.method private onCableState(Z)V
    .locals 2
    .param p1, "plugged"    # Z

    .prologue
    .line 179
    .local p0, "this":Ltas/internal/camera/client/CameraProxy;, "Ltas/internal/camera/client/CameraProxy<TT;>;"
    iget-object v0, p0, Ltas/internal/camera/client/CameraProxy;->cam:Ltas/camera/CameraId;

    iput-boolean p1, v0, Ltas/camera/CameraId;->plugged:Z

    .line 180
    iget-object v0, p0, Ltas/internal/camera/client/CameraProxy;->mStateListener:Ltas/camera/CameraStateListener;

    if-eqz v0, :cond_0

    .line 181
    iget-object v0, p0, Ltas/internal/camera/client/CameraProxy;->mStateListener:Ltas/camera/CameraStateListener;

    iget-object v1, p0, Ltas/internal/camera/client/CameraProxy;->cam:Ltas/camera/CameraId;

    invoke-interface {v0, v1, p1}, Ltas/camera/CameraStateListener;->onCableState(Ltas/camera/CameraId;Z)V

    .line 178
    :cond_0
    return-void
.end method

.method private onCameraMessage(Ltas/camera/CameraMessage;)V
    .locals 2
    .param p1, "msg"    # Ltas/camera/CameraMessage;

    .prologue
    .line 213
    .local p0, "this":Ltas/internal/camera/client/CameraProxy;, "Ltas/internal/camera/client/CameraProxy<TT;>;"
    iget-object v0, p0, Ltas/internal/camera/client/CameraProxy;->mCameraListener:Ltas/camera/CameraListener;

    if-eqz v0, :cond_0

    .line 214
    iget-object v0, p0, Ltas/internal/camera/client/CameraProxy;->mCameraListener:Ltas/camera/CameraListener;

    iget-object v1, p0, Ltas/internal/camera/client/CameraProxy;->cam:Ltas/camera/CameraId;

    invoke-interface {v0, v1, p1}, Ltas/camera/CameraListener;->onExtraMessage(Ltas/camera/CameraId;Ltas/camera/CameraMessage;)V

    .line 212
    :cond_0
    return-void
.end method

.method private onCameraState(Z)V
    .locals 4
    .param p1, "opened"    # Z

    .prologue
    .line 186
    .local p0, "this":Ltas/internal/camera/client/CameraProxy;, "Ltas/internal/camera/client/CameraProxy<TT;>;"
    iget-object v0, p0, Ltas/internal/camera/client/CameraProxy;->cam:Ltas/camera/CameraId;

    iput-boolean p1, v0, Ltas/camera/CameraId;->opened:Z

    .line 187
    iget-object v0, p0, Ltas/internal/camera/client/CameraProxy;->mStateListener:Ltas/camera/CameraStateListener;

    if-eqz v0, :cond_0

    .line 188
    iget-object v1, p0, Ltas/internal/camera/client/CameraProxy;->mStateListener:Ltas/camera/CameraStateListener;

    iget-object v2, p0, Ltas/internal/camera/client/CameraProxy;->cam:Ltas/camera/CameraId;

    if-eqz p1, :cond_1

    .line 189
    const/4 v0, 0x1

    .line 190
    :goto_0
    const/4 v3, 0x0

    .line 188
    invoke-interface {v1, v2, v0, v3}, Ltas/camera/CameraStateListener;->onExtraState(Ltas/camera/CameraId;II)V

    .line 185
    :cond_0
    return-void

    .line 190
    :cond_1
    const/4 v0, 0x2

    goto :goto_0
.end method

.method private onCommandResult(II)V
    .locals 2
    .param p1, "cmd"    # I
    .param p2, "result"    # I

    .prologue
    .line 207
    .local p0, "this":Ltas/internal/camera/client/CameraProxy;, "Ltas/internal/camera/client/CameraProxy<TT;>;"
    iget-object v0, p0, Ltas/internal/camera/client/CameraProxy;->mCameraListener:Ltas/camera/CameraListener;

    if-eqz v0, :cond_0

    .line 208
    iget-object v0, p0, Ltas/internal/camera/client/CameraProxy;->mCameraListener:Ltas/camera/CameraListener;

    iget-object v1, p0, Ltas/internal/camera/client/CameraProxy;->cam:Ltas/camera/CameraId;

    invoke-interface {v0, v1, p1, p2}, Ltas/camera/CameraListener;->onCommandResult(Ltas/camera/CameraId;II)V

    .line 206
    :cond_0
    return-void
.end method

.method private onExtraState(II)V
    .locals 2
    .param p1, "state"    # I
    .param p2, "flag"    # I

    .prologue
    .line 195
    .local p0, "this":Ltas/internal/camera/client/CameraProxy;, "Ltas/internal/camera/client/CameraProxy<TT;>;"
    iget-object v0, p0, Ltas/internal/camera/client/CameraProxy;->mCameraListener:Ltas/camera/CameraListener;

    if-eqz v0, :cond_0

    .line 196
    iget-object v0, p0, Ltas/internal/camera/client/CameraProxy;->mCameraListener:Ltas/camera/CameraListener;

    iget-object v1, p0, Ltas/internal/camera/client/CameraProxy;->cam:Ltas/camera/CameraId;

    invoke-interface {v0, v1, p1, p2}, Ltas/camera/CameraListener;->onExtraState(Ltas/camera/CameraId;II)V

    .line 194
    :cond_0
    return-void
.end method

.method private onMediaServerDied()V
    .locals 4

    .prologue
    .local p0, "this":Ltas/internal/camera/client/CameraProxy;, "Ltas/internal/camera/client/CameraProxy<TT;>;"
    const/4 v1, 0x0

    .line 219
    iget-object v0, p0, Ltas/internal/camera/client/CameraProxy;->cam:Ltas/camera/CameraId;

    iput-object v1, v0, Ltas/camera/CameraId;->id:Ljava/lang/String;

    .line 220
    iget-object v0, p0, Ltas/internal/camera/client/CameraProxy;->cam:Ltas/camera/CameraId;

    const/4 v1, -0x1

    iput v1, v0, Ltas/camera/CameraId;->idCompat:I

    .line 221
    iget-object v0, p0, Ltas/internal/camera/client/CameraProxy;->mCameraListener:Ltas/camera/CameraListener;

    if-eqz v0, :cond_0

    .line 222
    iget-object v0, p0, Ltas/internal/camera/client/CameraProxy;->mCameraListener:Ltas/camera/CameraListener;

    iget-object v1, p0, Ltas/internal/camera/client/CameraProxy;->cam:Ltas/camera/CameraId;

    const/4 v2, -0x6

    const/4 v3, 0x0

    invoke-interface {v0, v1, v2, v3}, Ltas/camera/CameraListener;->onExtraState(Ltas/camera/CameraId;II)V

    .line 218
    :cond_0
    return-void
.end method

.method private onRequestResult(I)V
    .locals 2
    .param p1, "result"    # I

    .prologue
    .line 201
    .local p0, "this":Ltas/internal/camera/client/CameraProxy;, "Ltas/internal/camera/client/CameraProxy<TT;>;"
    iget-object v0, p0, Ltas/internal/camera/client/CameraProxy;->mCameraListener:Ltas/camera/CameraListener;

    if-eqz v0, :cond_0

    .line 202
    iget-object v0, p0, Ltas/internal/camera/client/CameraProxy;->mCameraListener:Ltas/camera/CameraListener;

    iget-object v1, p0, Ltas/internal/camera/client/CameraProxy;->cam:Ltas/camera/CameraId;

    invoke-interface {v0, v1, p1}, Ltas/camera/CameraListener;->onRequestResult(Ltas/camera/CameraId;I)V

    .line 200
    :cond_0
    return-void
.end method

.method private requestThisCamera()V
    .locals 1

    .prologue
    .line 384
    .local p0, "this":Ltas/internal/camera/client/CameraProxy;, "Ltas/internal/camera/client/CameraProxy<TT;>;"
    iget-object v0, p0, Ltas/internal/camera/client/CameraProxy;->mCameraListener:Ltas/camera/CameraListener;

    if-eqz v0, :cond_0

    .line 385
    sget-object v0, Ltas/internal/camera/client/CameraProxy;->sServer:Ltas/internal/camera/client/ServerConnection;

    invoke-virtual {v0, p0}, Ltas/internal/camera/client/ServerConnection;->request(Ltas/internal/camera/client/CameraProxy;)V

    .line 383
    :cond_0
    return-void
.end method

.method private unwatchThisCamera()V
    .locals 1

    .prologue
    .line 377
    .local p0, "this":Ltas/internal/camera/client/CameraProxy;, "Ltas/internal/camera/client/CameraProxy<TT;>;"
    iget-boolean v0, p0, Ltas/internal/camera/client/CameraProxy;->mWatched:Z

    if-eqz v0, :cond_0

    .line 378
    const/4 v0, 0x0

    iput-boolean v0, p0, Ltas/internal/camera/client/CameraProxy;->mWatched:Z

    .line 379
    sget-object v0, Ltas/internal/camera/client/CameraProxy;->sServer:Ltas/internal/camera/client/ServerConnection;

    invoke-virtual {v0, p0}, Ltas/internal/camera/client/ServerConnection;->unwatch(Ltas/internal/camera/client/CameraProxy;)V

    .line 376
    :cond_0
    return-void
.end method

.method private watchThisCamera()V
    .locals 1

    .prologue
    .line 370
    .local p0, "this":Ltas/internal/camera/client/CameraProxy;, "Ltas/internal/camera/client/CameraProxy<TT;>;"
    iget-boolean v0, p0, Ltas/internal/camera/client/CameraProxy;->mWatched:Z

    if-nez v0, :cond_0

    .line 371
    const/4 v0, 0x1

    iput-boolean v0, p0, Ltas/internal/camera/client/CameraProxy;->mWatched:Z

    .line 372
    sget-object v0, Ltas/internal/camera/client/CameraProxy;->sServer:Ltas/internal/camera/client/ServerConnection;

    invoke-virtual {v0, p0}, Ltas/internal/camera/client/ServerConnection;->watch(Ltas/internal/camera/client/CameraProxy;)V

    .line 369
    :cond_0
    return-void
.end method


# virtual methods
.method public cancel()V
    .locals 0

    .prologue
    .line 62
    .local p0, "this":Ltas/internal/camera/client/CameraProxy;, "Ltas/internal/camera/client/CameraProxy<TT;>;"
    invoke-direct {p0}, Ltas/internal/camera/client/CameraProxy;->cancelThisCamera()V

    .line 61
    return-void
.end method

.method public command(Ltas/camera/CameraCommand;)V
    .locals 0
    .param p1, "cmd"    # Ltas/camera/CameraCommand;

    .prologue
    .line 66
    .local p0, "this":Ltas/internal/camera/client/CameraProxy;, "Ltas/internal/camera/client/CameraProxy<TT;>;"
    invoke-direct {p0, p1}, Ltas/internal/camera/client/CameraProxy;->commandThisCamera(Ltas/camera/CameraCommand;)V

    .line 65
    return-void
.end method

.method dispatchCableState(Z)V
    .locals 1
    .param p1, "plugged"    # Z

    .prologue
    .line 115
    .local p0, "this":Ltas/internal/camera/client/CameraProxy;, "Ltas/internal/camera/client/CameraProxy<TT;>;"
    iget-object v0, p0, Ltas/internal/camera/client/CameraProxy;->mDispatcher:Ltas/internal/camera/client/CameraProxy$Dispatcher;

    invoke-static {v0, p1}, Ltas/internal/camera/client/CameraProxy$Dispatcher;->-wrap0(Ltas/internal/camera/client/CameraProxy$Dispatcher;Z)V

    .line 114
    return-void
.end method

.method dispatchCameraMessage(Ltas/internal/camera/client/ServerConnection$Holder;)V
    .locals 1
    .param p1, "holder"    # Ltas/internal/camera/client/ServerConnection$Holder;

    .prologue
    .line 123
    .local p0, "this":Ltas/internal/camera/client/CameraProxy;, "Ltas/internal/camera/client/CameraProxy<TT;>;"
    iget-object v0, p0, Ltas/internal/camera/client/CameraProxy;->mDispatcher:Ltas/internal/camera/client/CameraProxy$Dispatcher;

    invoke-static {v0, p1}, Ltas/internal/camera/client/CameraProxy$Dispatcher;->-wrap1(Ltas/internal/camera/client/CameraProxy$Dispatcher;Ltas/internal/camera/client/ServerConnection$Holder;)V

    .line 122
    return-void
.end method

.method dispatchCameraState(Z)V
    .locals 1
    .param p1, "opened"    # Z

    .prologue
    .line 119
    .local p0, "this":Ltas/internal/camera/client/CameraProxy;, "Ltas/internal/camera/client/CameraProxy<TT;>;"
    iget-object v0, p0, Ltas/internal/camera/client/CameraProxy;->mDispatcher:Ltas/internal/camera/client/CameraProxy$Dispatcher;

    invoke-static {v0, p1}, Ltas/internal/camera/client/CameraProxy$Dispatcher;->-wrap2(Ltas/internal/camera/client/CameraProxy$Dispatcher;Z)V

    .line 118
    return-void
.end method

.method dispatchCommandResult(II)V
    .locals 1
    .param p1, "cmd"    # I
    .param p2, "result"    # I

    .prologue
    .line 131
    .local p0, "this":Ltas/internal/camera/client/CameraProxy;, "Ltas/internal/camera/client/CameraProxy<TT;>;"
    iget-object v0, p0, Ltas/internal/camera/client/CameraProxy;->mDispatcher:Ltas/internal/camera/client/CameraProxy$Dispatcher;

    invoke-static {v0, p1, p2}, Ltas/internal/camera/client/CameraProxy$Dispatcher;->-wrap3(Ltas/internal/camera/client/CameraProxy$Dispatcher;II)V

    .line 130
    return-void
.end method

.method dispatchExtraState(II)V
    .locals 1
    .param p1, "state"    # I
    .param p2, "flag"    # I

    .prologue
    .line 144
    .local p0, "this":Ltas/internal/camera/client/CameraProxy;, "Ltas/internal/camera/client/CameraProxy<TT;>;"
    iget-object v0, p0, Ltas/internal/camera/client/CameraProxy;->mDispatcher:Ltas/internal/camera/client/CameraProxy$Dispatcher;

    invoke-static {v0, p1, p2}, Ltas/internal/camera/client/CameraProxy$Dispatcher;->-wrap4(Ltas/internal/camera/client/CameraProxy$Dispatcher;II)V

    .line 143
    return-void
.end method

.method dispatchInitialState(Ltas/camera/CameraMessage;)V
    .locals 5
    .param p1, "msg"    # Ltas/camera/CameraMessage;

    .prologue
    .local p0, "this":Ltas/internal/camera/client/CameraProxy;, "Ltas/internal/camera/client/CameraProxy<TT;>;"
    const/4 v2, 0x1

    const/4 v3, 0x0

    .line 148
    iget-object v1, p0, Ltas/internal/camera/client/CameraProxy;->cam:Ltas/camera/CameraId;

    if-eqz v1, :cond_0

    iget-object v1, p0, Ltas/internal/camera/client/CameraProxy;->cam:Ltas/camera/CameraId;

    iget-object v1, v1, Ltas/camera/CameraId;->id:Ljava/lang/String;

    if-nez v1, :cond_0

    .line 149
    iget-object v1, p0, Ltas/internal/camera/client/CameraProxy;->cam:Ltas/camera/CameraId;

    iget-object v4, p1, Ltas/camera/CameraMessage;->str1:Ljava/lang/String;

    iput-object v4, v1, Ltas/camera/CameraId;->id:Ljava/lang/String;

    .line 150
    iget-object v1, p0, Ltas/internal/camera/client/CameraProxy;->cam:Ltas/camera/CameraId;

    const/4 v4, -0x1

    iput v4, v1, Ltas/camera/CameraId;->idCompat:I

    .line 152
    iget-object v1, p0, Ltas/internal/camera/client/CameraProxy;->cam:Ltas/camera/CameraId;

    iget-object v1, v1, Ltas/camera/CameraId;->id:Ljava/lang/String;

    if-eqz v1, :cond_3

    .line 154
    :try_start_0
    iget-object v1, p0, Ltas/internal/camera/client/CameraProxy;->cam:Ltas/camera/CameraId;

    iget-object v4, p0, Ltas/internal/camera/client/CameraProxy;->cam:Ltas/camera/CameraId;

    iget-object v4, v4, Ltas/camera/CameraId;->id:Ljava/lang/String;

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    move-result v4

    iput v4, v1, Ltas/camera/CameraId;->idCompat:I
    :try_end_0
    .catch Ljava/lang/NumberFormatException; {:try_start_0 .. :try_end_0} :catch_0

    .line 158
    :goto_0
    iget-object v4, p0, Ltas/internal/camera/client/CameraProxy;->mDispatcher:Ltas/internal/camera/client/CameraProxy$Dispatcher;

    iget v1, p1, Ltas/camera/CameraMessage;->arg1:I

    if-ne v1, v2, :cond_1

    move v1, v2

    :goto_1
    invoke-static {v4, v1}, Ltas/internal/camera/client/CameraProxy$Dispatcher;->-wrap0(Ltas/internal/camera/client/CameraProxy$Dispatcher;Z)V

    .line 159
    iget-object v1, p0, Ltas/internal/camera/client/CameraProxy;->mDispatcher:Ltas/internal/camera/client/CameraProxy$Dispatcher;

    iget v4, p1, Ltas/camera/CameraMessage;->arg2:I

    if-ne v4, v2, :cond_2

    :goto_2
    invoke-static {v1, v2}, Ltas/internal/camera/client/CameraProxy$Dispatcher;->-wrap2(Ltas/internal/camera/client/CameraProxy$Dispatcher;Z)V

    .line 161
    iget-boolean v1, p0, Ltas/internal/camera/client/CameraProxy;->mPendingRequest:Z

    if-eqz v1, :cond_0

    .line 162
    iput-boolean v3, p0, Ltas/internal/camera/client/CameraProxy;->mPendingRequest:Z

    .line 163
    iget v1, p1, Ltas/camera/CameraMessage;->arg1:I

    if-nez v1, :cond_0

    .line 165
    iget-object v1, p0, Ltas/internal/camera/client/CameraProxy;->cam:Ltas/camera/CameraId;

    const/16 v2, 0x1f7

    invoke-virtual {v1, v2}, Ltas/camera/CameraId;->obtainCommand(I)Ltas/camera/CameraCommand;

    move-result-object v1

    .line 164
    invoke-direct {p0, v1}, Ltas/internal/camera/client/CameraProxy;->commandThisCamera(Ltas/camera/CameraCommand;)V

    .line 147
    :cond_0
    :goto_3
    return-void

    :cond_1
    move v1, v3

    .line 158
    goto :goto_1

    :cond_2
    move v2, v3

    .line 159
    goto :goto_2

    .line 169
    :cond_3
    iget-object v1, p0, Ltas/internal/camera/client/CameraProxy;->mDispatcher:Ltas/internal/camera/client/CameraProxy$Dispatcher;

    const/4 v2, -0x5

    invoke-static {v1, v2, v3}, Ltas/internal/camera/client/CameraProxy$Dispatcher;->-wrap4(Ltas/internal/camera/client/CameraProxy$Dispatcher;II)V

    goto :goto_3

    .line 155
    :catch_0
    move-exception v0

    .local v0, "e":Ljava/lang/NumberFormatException;
    goto :goto_0
.end method

.method dispatchMediaServerState(Z)V
    .locals 1
    .param p1, "alive"    # Z

    .prologue
    .line 135
    .local p0, "this":Ltas/internal/camera/client/CameraProxy;, "Ltas/internal/camera/client/CameraProxy<TT;>;"
    if-eqz p1, :cond_0

    .line 136
    invoke-direct {p0}, Ltas/internal/camera/client/CameraProxy;->watchThisCamera()V

    .line 134
    :goto_0
    return-void

    .line 138
    :cond_0
    invoke-direct {p0}, Ltas/internal/camera/client/CameraProxy;->unwatchThisCamera()V

    .line 139
    iget-object v0, p0, Ltas/internal/camera/client/CameraProxy;->mDispatcher:Ltas/internal/camera/client/CameraProxy$Dispatcher;

    invoke-static {v0}, Ltas/internal/camera/client/CameraProxy$Dispatcher;->-wrap5(Ltas/internal/camera/client/CameraProxy$Dispatcher;)V

    goto :goto_0
.end method

.method dispatchRequestResult(I)V
    .locals 1
    .param p1, "result"    # I

    .prologue
    .line 127
    .local p0, "this":Ltas/internal/camera/client/CameraProxy;, "Ltas/internal/camera/client/CameraProxy<TT;>;"
    iget-object v0, p0, Ltas/internal/camera/client/CameraProxy;->mDispatcher:Ltas/internal/camera/client/CameraProxy$Dispatcher;

    invoke-static {v0, p1}, Ltas/internal/camera/client/CameraProxy$Dispatcher;->-wrap6(Ltas/internal/camera/client/CameraProxy$Dispatcher;I)V

    .line 126
    return-void
.end method

.method isCamera(Ljava/lang/String;)Z
    .locals 2
    .param p1, "name"    # Ljava/lang/String;

    .prologue
    .local p0, "this":Ltas/internal/camera/client/CameraProxy;, "Ltas/internal/camera/client/CameraProxy<TT;>;"
    const/4 v0, 0x0

    .line 175
    if-eqz p1, :cond_0

    iget-object v1, p0, Ltas/internal/camera/client/CameraProxy;->cam:Ltas/camera/CameraId;

    invoke-virtual {v1}, Ltas/camera/CameraId;->getClass()Ljava/lang/Class;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1, p1}, Ljava/lang/String;->compareTo(Ljava/lang/String;)I

    move-result v1

    if-nez v1, :cond_0

    const/4 v0, 0x1

    :cond_0
    return v0
.end method

.method public release()V
    .locals 0

    .prologue
    .line 46
    .local p0, "this":Ltas/internal/camera/client/CameraProxy;, "Ltas/internal/camera/client/CameraProxy<TT;>;"
    invoke-direct {p0}, Ltas/internal/camera/client/CameraProxy;->disconnectFromServer()V

    .line 45
    return-void
.end method

.method public request()V
    .locals 2

    .prologue
    .line 50
    .local p0, "this":Ltas/internal/camera/client/CameraProxy;, "Ltas/internal/camera/client/CameraProxy<TT;>;"
    iget-object v0, p0, Ltas/internal/camera/client/CameraProxy;->cam:Ltas/camera/CameraId;

    iget-object v0, v0, Ltas/camera/CameraId;->id:Ljava/lang/String;

    if-nez v0, :cond_0

    .line 51
    const/4 v0, 0x1

    iput-boolean v0, p0, Ltas/internal/camera/client/CameraProxy;->mPendingRequest:Z

    .line 52
    return-void

    .line 54
    :cond_0
    iget-object v0, p0, Ltas/internal/camera/client/CameraProxy;->cam:Ltas/camera/CameraId;

    iget-boolean v0, v0, Ltas/camera/CameraId;->plugged:Z

    if-nez v0, :cond_1

    .line 55
    iget-object v0, p0, Ltas/internal/camera/client/CameraProxy;->cam:Ltas/camera/CameraId;

    const/16 v1, 0x1f7

    invoke-virtual {v0, v1}, Ltas/camera/CameraId;->obtainCommand(I)Ltas/camera/CameraCommand;

    move-result-object v0

    invoke-direct {p0, v0}, Ltas/internal/camera/client/CameraProxy;->commandThisCamera(Ltas/camera/CameraCommand;)V

    .line 56
    return-void

    .line 58
    :cond_1
    invoke-direct {p0}, Ltas/internal/camera/client/CameraProxy;->requestThisCamera()V

    .line 49
    return-void
.end method

.method public setCameraListener(Ltas/camera/CameraListener;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ltas/camera/CameraListener",
            "<TT;>;)V"
        }
    .end annotation

    .prologue
    .line 101
    .local p0, "this":Ltas/internal/camera/client/CameraProxy;, "Ltas/internal/camera/client/CameraProxy<TT;>;"
    .local p1, "l":Ltas/camera/CameraListener;, "Ltas/camera/CameraListener<TT;>;"
    iget-object v0, p0, Ltas/internal/camera/client/CameraProxy;->mCameraListener:Ltas/camera/CameraListener;

    if-eqz v0, :cond_1

    .line 102
    iput-object p1, p0, Ltas/internal/camera/client/CameraProxy;->mCameraListener:Ltas/camera/CameraListener;

    .line 103
    if-nez p1, :cond_0

    .line 104
    invoke-direct {p0}, Ltas/internal/camera/client/CameraProxy;->unwatchThisCamera()V

    .line 100
    :cond_0
    :goto_0
    return-void

    .line 107
    :cond_1
    iput-object p1, p0, Ltas/internal/camera/client/CameraProxy;->mCameraListener:Ltas/camera/CameraListener;

    .line 108
    if-eqz p1, :cond_0

    .line 109
    invoke-direct {p0}, Ltas/internal/camera/client/CameraProxy;->watchThisCamera()V

    goto :goto_0
.end method

.method public setCameraStateListener(Ltas/camera/CameraStateListener;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ltas/camera/CameraStateListener",
            "<TT;>;)V"
        }
    .end annotation

    .prologue
    .line 87
    .local p0, "this":Ltas/internal/camera/client/CameraProxy;, "Ltas/internal/camera/client/CameraProxy<TT;>;"
    .local p1, "l":Ltas/camera/CameraStateListener;, "Ltas/camera/CameraStateListener<TT;>;"
    iget-object v0, p0, Ltas/internal/camera/client/CameraProxy;->mStateListener:Ltas/camera/CameraStateListener;

    if-eqz v0, :cond_1

    .line 88
    iput-object p1, p0, Ltas/internal/camera/client/CameraProxy;->mStateListener:Ltas/camera/CameraStateListener;

    .line 89
    if-nez p1, :cond_0

    .line 90
    invoke-direct {p0}, Ltas/internal/camera/client/CameraProxy;->unwatchThisCamera()V

    .line 86
    :cond_0
    :goto_0
    return-void

    .line 93
    :cond_1
    iput-object p1, p0, Ltas/internal/camera/client/CameraProxy;->mStateListener:Ltas/camera/CameraStateListener;

    .line 94
    if-eqz p1, :cond_0

    .line 95
    invoke-direct {p0}, Ltas/internal/camera/client/CameraProxy;->watchThisCamera()V

    goto :goto_0
.end method

.method public setListener(Ltas/camera/BaseListener;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ltas/camera/BaseListener",
            "<TT;>;)V"
        }
    .end annotation

    .prologue
    .local p0, "this":Ltas/internal/camera/client/CameraProxy;, "Ltas/internal/camera/client/CameraProxy<TT;>;"
    .local p1, "l":Ltas/camera/BaseListener;, "Ltas/camera/BaseListener<TT;>;"
    const/4 v0, 0x0

    .line 73
    if-eqz p1, :cond_2

    .line 74
    instance-of v0, p1, Ltas/camera/CameraStateListener;

    if-eqz v0, :cond_0

    move-object v0, p1

    .line 75
    check-cast v0, Ltas/camera/CameraStateListener;

    invoke-virtual {p0, v0}, Ltas/internal/camera/client/CameraProxy;->setCameraStateListener(Ltas/camera/CameraStateListener;)V

    .line 77
    :cond_0
    instance-of v0, p1, Ltas/camera/CameraListener;

    if-eqz v0, :cond_1

    .line 78
    check-cast p1, Ltas/camera/CameraListener;

    .end local p1    # "l":Ltas/camera/BaseListener;, "Ltas/camera/BaseListener<TT;>;"
    invoke-virtual {p0, p1}, Ltas/internal/camera/client/CameraProxy;->setCameraListener(Ltas/camera/CameraListener;)V

    .line 72
    :cond_1
    :goto_0
    return-void

    .line 81
    .restart local p1    # "l":Ltas/camera/BaseListener;, "Ltas/camera/BaseListener<TT;>;"
    :cond_2
    invoke-virtual {p0, v0}, Ltas/internal/camera/client/CameraProxy;->setCameraStateListener(Ltas/camera/CameraStateListener;)V

    .line 82
    invoke-virtual {p0, v0}, Ltas/internal/camera/client/CameraProxy;->setCameraListener(Ltas/camera/CameraListener;)V

    goto :goto_0
.end method
