.class Ltas/internal/ipc/server/ServerManager$SenderHolder;
.super Ljava/lang/Object;
.source "ServerManager.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltas/internal/ipc/server/ServerManager;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "SenderHolder"
.end annotation


# instance fields
.field private handler:Ltas/internal/ipc/server/ServerManager$ClientHandler;

.field private final receivers:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List",
            "<",
            "Ltas/internal/ipc/server/RemoteReceiver;",
            ">;"
        }
    .end annotation
.end field

.field private s:Ltas/internal/ipc/server/RemoteSender;

.field private watchAnonymous:Z

.field private final watchList:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List",
            "<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static synthetic -get0(Ltas/internal/ipc/server/ServerManager$SenderHolder;)Ljava/util/List;
    .locals 1

    iget-object v0, p0, Ltas/internal/ipc/server/ServerManager$SenderHolder;->receivers:Ljava/util/List;

    return-object v0
.end method

.method static synthetic -get1(Ltas/internal/ipc/server/ServerManager$SenderHolder;)Ltas/internal/ipc/server/RemoteSender;
    .locals 1

    iget-object v0, p0, Ltas/internal/ipc/server/ServerManager$SenderHolder;->s:Ltas/internal/ipc/server/RemoteSender;

    return-object v0
.end method

.method static synthetic -get2(Ltas/internal/ipc/server/ServerManager$SenderHolder;)Z
    .locals 1

    iget-boolean v0, p0, Ltas/internal/ipc/server/ServerManager$SenderHolder;->watchAnonymous:Z

    return v0
.end method

.method static synthetic -get3(Ltas/internal/ipc/server/ServerManager$SenderHolder;)Ljava/util/List;
    .locals 1

    iget-object v0, p0, Ltas/internal/ipc/server/ServerManager$SenderHolder;->watchList:Ljava/util/List;

    return-object v0
.end method

.method static synthetic -set0(Ltas/internal/ipc/server/ServerManager$SenderHolder;Z)Z
    .locals 0

    iput-boolean p1, p0, Ltas/internal/ipc/server/ServerManager$SenderHolder;->watchAnonymous:Z

    return p1
.end method

.method static synthetic -wrap0(Ltas/internal/ipc/server/ServerManager$SenderHolder;Ltas/internal/ipc/server/RemoteReceiver;)Z
    .locals 1
    .param p1, "r"    # Ltas/internal/ipc/server/RemoteReceiver;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/ipc/server/ServerManager$SenderHolder;->hasReceiver(Ltas/internal/ipc/server/RemoteReceiver;)Z

    move-result v0

    return v0
.end method

.method static synthetic -wrap1(Ltas/internal/ipc/server/ServerManager$SenderHolder;Ljava/lang/String;)Z
    .locals 1
    .param p1, "name"    # Ljava/lang/String;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/ipc/server/ServerManager$SenderHolder;->isWatching(Ljava/lang/String;)Z

    move-result v0

    return v0
.end method

.method static synthetic -wrap2(Ltas/internal/ipc/server/ServerManager$SenderHolder;Ltas/internal/ipc/server/RemoteReceiver;)Z
    .locals 1
    .param p1, "r"    # Ltas/internal/ipc/server/RemoteReceiver;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/ipc/server/ServerManager$SenderHolder;->removeReceiver(Ltas/internal/ipc/server/RemoteReceiver;)Z

    move-result v0

    return v0
.end method

.method static synthetic -wrap3(Ltas/internal/ipc/server/ServerManager$SenderHolder;Ljava/lang/String;)Z
    .locals 1
    .param p1, "name"    # Ljava/lang/String;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/ipc/server/ServerManager$SenderHolder;->unwatch(Ljava/lang/String;)Z

    move-result v0

    return v0
.end method

.method static synthetic -wrap4(Ltas/internal/ipc/server/ServerManager$SenderHolder;Ltas/internal/ipc/server/RemoteReceiver;)V
    .locals 0
    .param p1, "r"    # Ltas/internal/ipc/server/RemoteReceiver;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/ipc/server/ServerManager$SenderHolder;->addReceiver(Ltas/internal/ipc/server/RemoteReceiver;)V

    return-void
.end method

.method static synthetic -wrap5(Ltas/internal/ipc/server/ServerManager$SenderHolder;)V
    .locals 0

    invoke-direct {p0}, Ltas/internal/ipc/server/ServerManager$SenderHolder;->binderDied()V

    return-void
.end method

.method static synthetic -wrap6(Ltas/internal/ipc/server/ServerManager$SenderHolder;Ljava/lang/String;)V
    .locals 0
    .param p1, "name"    # Ljava/lang/String;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/ipc/server/ServerManager$SenderHolder;->watch(Ljava/lang/String;)V

    return-void
.end method

.method private constructor <init>(Ltas/internal/ipc/server/ServerManager$ClientHandler;Ltas/internal/ipc/server/RemoteSender;)V
    .locals 1
    .param p1, "_c"    # Ltas/internal/ipc/server/ServerManager$ClientHandler;
    .param p2, "_s"    # Ltas/internal/ipc/server/RemoteSender;

    .prologue
    .line 1096
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1089
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Ltas/internal/ipc/server/ServerManager$SenderHolder;->watchList:Ljava/util/List;

    .line 1091
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 1090
    iput-object v0, p0, Ltas/internal/ipc/server/ServerManager$SenderHolder;->receivers:Ljava/util/List;

    .line 1097
    iput-object p1, p0, Ltas/internal/ipc/server/ServerManager$SenderHolder;->handler:Ltas/internal/ipc/server/ServerManager$ClientHandler;

    iput-object p2, p0, Ltas/internal/ipc/server/ServerManager$SenderHolder;->s:Ltas/internal/ipc/server/RemoteSender;

    .line 1096
    return-void
.end method

.method synthetic constructor <init>(Ltas/internal/ipc/server/ServerManager$ClientHandler;Ltas/internal/ipc/server/RemoteSender;Ltas/internal/ipc/server/ServerManager$SenderHolder;)V
    .locals 0
    .param p1, "_c"    # Ltas/internal/ipc/server/ServerManager$ClientHandler;
    .param p2, "_s"    # Ltas/internal/ipc/server/RemoteSender;

    .prologue
    invoke-direct {p0, p1, p2}, Ltas/internal/ipc/server/ServerManager$SenderHolder;-><init>(Ltas/internal/ipc/server/ServerManager$ClientHandler;Ltas/internal/ipc/server/RemoteSender;)V

    return-void
.end method

.method private addReceiver(Ltas/internal/ipc/server/RemoteReceiver;)V
    .locals 1
    .param p1, "r"    # Ltas/internal/ipc/server/RemoteReceiver;

    .prologue
    .line 1117
    iget-object v0, p0, Ltas/internal/ipc/server/ServerManager$SenderHolder;->receivers:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 1116
    return-void
.end method

.method private binderDied()V
    .locals 6

    .prologue
    .line 1125
    iget-object v3, p0, Ltas/internal/ipc/server/ServerManager$SenderHolder;->watchList:Ljava/util/List;

    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v2

    .local v2, "watch$iterator":Ljava/util/Iterator;
    :cond_0
    :goto_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_1

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    .line 1126
    .local v1, "watch":Ljava/lang/String;
    if-eqz v1, :cond_0

    .line 1127
    iget-object v3, p0, Ltas/internal/ipc/server/ServerManager$SenderHolder;->s:Ltas/internal/ipc/server/RemoteSender;

    invoke-static {v3}, Ltas/internal/ipc/server/RemoteSender;->obtain(Ltas/internal/ipc/server/RemoteSender;)Ltas/internal/ipc/server/RemoteSender;

    move-result-object v0

    .line 1128
    .local v0, "rs":Ltas/internal/ipc/server/RemoteSender;
    iput-object v1, v0, Ltas/internal/ipc/server/RemoteSender;->target:Ljava/lang/String;

    .line 1129
    iget-object v3, p0, Ltas/internal/ipc/server/ServerManager$SenderHolder;->handler:Ltas/internal/ipc/server/ServerManager$ClientHandler;

    const/4 v4, 0x7

    invoke-static {v3, v4, v0}, Ltas/internal/ipc/server/ServerManager$ClientHandler;->-wrap1(Ltas/internal/ipc/server/ServerManager$ClientHandler;ILtas/internal/ipc/server/RemoteSender;)V

    goto :goto_0

    .line 1131
    .end local v0    # "rs":Ltas/internal/ipc/server/RemoteSender;
    .end local v1    # "watch":Ljava/lang/String;
    :cond_1
    iget-boolean v3, p0, Ltas/internal/ipc/server/ServerManager$SenderHolder;->watchAnonymous:Z

    if-eqz v3, :cond_2

    .line 1132
    iget-object v3, p0, Ltas/internal/ipc/server/ServerManager$SenderHolder;->handler:Ltas/internal/ipc/server/ServerManager$ClientHandler;

    iget-object v4, p0, Ltas/internal/ipc/server/ServerManager$SenderHolder;->s:Ltas/internal/ipc/server/RemoteSender;

    const/16 v5, 0x9

    invoke-static {v3, v5, v4}, Ltas/internal/ipc/server/ServerManager$ClientHandler;->-wrap1(Ltas/internal/ipc/server/ServerManager$ClientHandler;ILtas/internal/ipc/server/RemoteSender;)V

    .line 1134
    :cond_2
    iget-object v3, p0, Ltas/internal/ipc/server/ServerManager$SenderHolder;->handler:Ltas/internal/ipc/server/ServerManager$ClientHandler;

    iget-object v4, p0, Ltas/internal/ipc/server/ServerManager$SenderHolder;->s:Ltas/internal/ipc/server/RemoteSender;

    const/4 v5, 0x4

    invoke-static {v3, v5, v4}, Ltas/internal/ipc/server/ServerManager$ClientHandler;->-wrap1(Ltas/internal/ipc/server/ServerManager$ClientHandler;ILtas/internal/ipc/server/RemoteSender;)V

    .line 1124
    return-void
.end method

.method private hasReceiver(Ltas/internal/ipc/server/RemoteReceiver;)Z
    .locals 1
    .param p1, "r"    # Ltas/internal/ipc/server/RemoteReceiver;

    .prologue
    .line 1113
    iget-object v0, p0, Ltas/internal/ipc/server/ServerManager$SenderHolder;->receivers:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v0

    return v0
.end method

.method private isWatching(Ljava/lang/String;)Z
    .locals 1
    .param p1, "name"    # Ljava/lang/String;

    .prologue
    .line 1101
    iget-object v0, p0, Ltas/internal/ipc/server/ServerManager$SenderHolder;->watchList:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v0

    return v0
.end method

.method private removeReceiver(Ltas/internal/ipc/server/RemoteReceiver;)Z
    .locals 1
    .param p1, "r"    # Ltas/internal/ipc/server/RemoteReceiver;

    .prologue
    .line 1121
    iget-object v0, p0, Ltas/internal/ipc/server/ServerManager$SenderHolder;->receivers:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->remove(Ljava/lang/Object;)Z

    move-result v0

    return v0
.end method

.method private unwatch(Ljava/lang/String;)Z
    .locals 1
    .param p1, "name"    # Ljava/lang/String;

    .prologue
    .line 1109
    iget-object v0, p0, Ltas/internal/ipc/server/ServerManager$SenderHolder;->watchList:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->remove(Ljava/lang/Object;)Z

    move-result v0

    return v0
.end method

.method private watch(Ljava/lang/String;)V
    .locals 1
    .param p1, "name"    # Ljava/lang/String;

    .prologue
    .line 1105
    iget-object v0, p0, Ltas/internal/ipc/server/ServerManager$SenderHolder;->watchList:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 1104
    return-void
.end method
