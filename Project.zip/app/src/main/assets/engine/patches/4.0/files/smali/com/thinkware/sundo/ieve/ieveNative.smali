.class public Lcom/thinkware/sundo/ieve/ieveNative;
.super Ljava/lang/Object;
.source "ieveNative.java"


# static fields
.field private static final a:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 6

    .prologue
    const/4 v5, 0x1

    .line 6
    const-class v3, Lcom/thinkware/sundo/ieve/ieveNative;

    invoke-virtual {v3}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v3

    sput-object v3, Lcom/thinkware/sundo/ieve/ieveNative;->a:Ljava/lang/String;

    .line 9
    const-string v0, "ieve"

    .line 11
    .local v0, "LIB_NAME":Ljava/lang/String;
    :try_start_0
    const-string v3, "ieve"

    invoke-static {v3}, Ljava/lang/System;->loadLibrary(Ljava/lang/String;)V

    .line 12
    sget-object v3, Lcom/thinkware/sundo/ieve/ieveNative;->a:Ljava/lang/String;

    const-string v4, "Native library libieve.so loaded"

    invoke-static {v3, v4}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_0
    .catch Ljava/lang/UnsatisfiedLinkError; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/SecurityException; {:try_start_0 .. :try_end_0} :catch_1

    .line 22
    :goto_0
    return-void

    .line 14
    :catch_0
    move-exception v2

    .line 15
    .local v2, "ule":Ljava/lang/UnsatisfiedLinkError;
    sget-object v3, Lcom/thinkware/sundo/ieve/ieveNative;->a:Ljava/lang/String;

    const-string v4, "The library libieve.so could not be loaded"

    invoke-static {v3, v4}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 16
    invoke-static {v5}, Ljava/lang/System;->exit(I)V

    goto :goto_0

    .line 18
    .end local v2    # "ule":Ljava/lang/UnsatisfiedLinkError;
    :catch_1
    move-exception v1

    .line 19
    .local v1, "e":Ljava/lang/SecurityException;
    sget-object v3, Lcom/thinkware/sundo/ieve/ieveNative;->a:Ljava/lang/String;

    const-string v4, "The library libieve.so was not allowed to be loaded"

    invoke-static {v3, v4}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 20
    invoke-static {v5}, Ljava/lang/System;->exit(I)V

    goto :goto_0
.end method

.method public constructor <init>()V
    .locals 0

    .prologue
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public native CheckDebugMode()V
.end method

.method public native CheckPickPlane(II)[I
.end method

.method public native ConfirmRegistration(Ljava/lang/String;)Z
.end method

.method public native ConvertNV21ToABGR([BII)[I
.end method

.method public native ConvertNV21ToBGR24([BII)[B
.end method

.method public native ConvertNV21ToNV12([BII)[B
.end method

.method public native ConvertiNaviRegToFP3DX(I)F
.end method

.method public native ConvertiNaviRegToFP3DZ(I)F
.end method

.method public native Create()Z
.end method

.method public native Destroy()Z
.end method

.method public native EnableModeAR(Z)Z
.end method

.method public native EnableModeDR(Z)Z
.end method

.method public native EnableModeFindVP(Z)Z
.end method

.method public native EnableModeRecogCSWS(Z)Z
.end method

.method public native EnableModeRecogFCWS(Z)Z
.end method

.method public native EnableModeRecogFVSA(Z)Z
.end method

.method public native EnableModeRecogLDWC(Z)Z
.end method

.method public native EnableModeRecogLDWS(Z)Z
.end method

.method public native EnableModeRecogPCWS(Z)Z
.end method

.method public native EnableModeRecogPLCA(Z)Z
.end method

.method public native EnableModeRecogTLCA(Z)Z
.end method

.method public native EnableModeRecogUFCW(Z)Z
.end method

.method public native GetAngleRegularFromGPS(D)D
.end method

.method public native GetCalcDistFCWS()F
.end method

.method public native GetCalcTTCFCWS()F
.end method

.method public native GetCarAngleDirectionAR()F
.end method

.method public native GetCarAngleDirectionFromDR()F
.end method

.method public native GetCarAngleDirectionFromVP()F
.end method

.method public native GetCarAngleVerticalAR()F
.end method

.method public native GetCarAngleVerticalFromDR()F
.end method

.method public native GetCarAngleVerticalFromVP()F
.end method

.method public native GetCarShadowGPS()Z
.end method

.method public native GetCarSpeedK()I
.end method

.method public native GetCarSpeedKDummyDR()I
.end method

.method public native GetCarStatusGPS()I
.end method

.method public native GetCarType()I
.end method

.method public native GetCountNotFindVP()I
.end method

.method public native GetCountNotifyFVSA()I
.end method

.method public native GetCountNotifyTLCA()I
.end method

.method public native GetCountTryFoundVP()I
.end method

.method public native GetDeviceCameraHeight()I
.end method

.method public native GetDeviceCameraHeightDefault()I
.end method

.method public native GetDeviceCameraHeightMax()I
.end method

.method public native GetDeviceCameraHeightMin()I
.end method

.method public native GetDeviceCameraModelType()I
.end method

.method public native GetDistMeterOfArcOnEarth(DDDD)D
.end method

.method public native GetDistMeterOfLatitude(DD)D
.end method

.method public native GetDistMeterOfLongitude(DDD)D
.end method

.method public native GetFrameRateADAS()D
.end method

.method public native GetFrameRateAR()D
.end method

.method public native GetFreqCountIEVE()D
.end method

.method public native GetHandDrive()I
.end method

.method public native GetHistoryRecogLDWS()[I
.end method

.method public native GetIeveGuideCode()I
.end method

.method public native GetIeveMode()I
.end method

.method public native GetLanguage()I
.end method

.method public native GetLastRecogCSWS()I
.end method

.method public native GetLastRecogFCWS()I
.end method

.method public native GetLastRecogFVSA()I
.end method

.method public native GetLastRecogLDWS()I
.end method

.method public native GetLastRecogPCWS()I
.end method

.method public native GetLastRecogPLCA()I
.end method

.method public native GetLastRecogTLCA()I
.end method

.method public native GetMovedPixelDirectionFromDR()I
.end method

.method public native GetMovedPixelVerticalFromDR()I
.end method

.method public native GetOBD2InfoBrakeSwitch()I
.end method

.method public native GetOBD2InfoGearMode()I
.end method

.method public native GetOBD2InfoSteeringDegree()F
.end method

.method public native GetProcessTimeDR()D
.end method

.method public native GetProcessTimeFCWS()D
.end method

.method public native GetProcessTimeFCWSAvr()D
.end method

.method public native GetProcessTimeFVSA()D
.end method

.method public native GetProcessTimeFVSAAvr()D
.end method

.method public native GetProcessTimeLDWS()D
.end method

.method public native GetProcessTimeLDWSAvr()D
.end method

.method public native GetProcessTimeRecog()D
.end method

.method public native GetProcessTimeRecogAvr()D
.end method

.method public native GetProcessTimeSetImage()D
.end method

.method public native GetProcessTimeSetImageAvr()D
.end method

.method public native GetProcessTimeTLCA()D
.end method

.method public native GetProcessTimeTLCAAvr()D
.end method

.method public native GetProcessTimeVP()D
.end method

.method public native GetProposeToAdjustCamera()I
.end method

.method public native GetROIBottom()I
.end method

.method public native GetROIBottomDefault()I
.end method

.method public native GetROILeft()I
.end method

.method public native GetROILeftDefault()I
.end method

.method public native GetROILeftStep()I
.end method

.method public native GetROILeftStepDefault()I
.end method

.method public native GetROIRight()I
.end method

.method public native GetROIRightDefault()I
.end method

.method public native GetROIRightStep()I
.end method

.method public native GetROIRightStepDefault()I
.end method

.method public native GetRecogResultCSWS()I
.end method

.method public native GetRecogResultFCWS()I
.end method

.method public native GetRecogResultFVSA()I
.end method

.method public native GetRecogResultLDWS()I
.end method

.method public native GetRecogResultPCWS()I
.end method

.method public native GetRecogResultPLCA()I
.end method

.method public native GetRecogResultTLCA()I
.end method

.method public native GetRecogResultVP()I
.end method

.method public native GetSensitivityCSWS()I
.end method

.method public native GetSensitivityFCWS()I
.end method

.method public native GetSensitivityPCWS()I
.end method

.method public native GetTickCountIEVE(I)D
.end method

.method public native GetUseSunFilm()Z
.end method

.method public native GetVanishingPointXFromImage()I
.end method

.method public native GetVanishingPointYFromImage()I
.end method

.method public native GetVersion()Ljava/lang/String;
.end method

.method public native GetVersionFCWS()Ljava/lang/String;
.end method

.method public native GetVersionFVSA()Ljava/lang/String;
.end method

.method public native GetVersionLDWS()Ljava/lang/String;
.end method

.method public native GetVersionPCWS()Ljava/lang/String;
.end method

.method public native GetVersionTLCA()Ljava/lang/String;
.end method

.method public native Initialize(Lcom/thinkware/sundo/ieve/ieveInitInfos;)I
.end method

.method public native InitializeJNI()Z
.end method

.method public native IsDebugFuncOn()Z
.end method

.method public native IsEnableModeAR()Z
.end method

.method public native IsEnableModeDR()Z
.end method

.method public native IsEnableModeFindVP()Z
.end method

.method public native IsEnableModeRecogCSWS()Z
.end method

.method public native IsEnableModeRecogFCWS()Z
.end method

.method public native IsEnableModeRecogFVSA()Z
.end method

.method public native IsEnableModeRecogLDWC()Z
.end method

.method public native IsEnableModeRecogLDWS()Z
.end method

.method public native IsEnableModeRecogPCWS()Z
.end method

.method public native IsEnableModeRecogPLCA()Z
.end method

.method public native IsEnableModeRecogTLCA()Z
.end method

.method public native IsEnableModeRecogUFCW()Z
.end method

.method public native IsFullMode()Z
.end method

.method public native IsInitialized()Z
.end method

.method public native IsInitializedAR()Z
.end method

.method public native IsInitializedJNI()Z
.end method

.method public native IsRecognizing()Z
.end method

.method public native IsRendering()Z
.end method

.method public native IsRunDR()Z
.end method

.method public native IsShowBGCover()Z
.end method

.method public native IsShowDebugCamera()Z
.end method

.method public native IsShowDebugFCWS()Z
.end method

.method public native IsShowDebugLDWS()Z
.end method

.method public native IsShowDebugLineDR()Z
.end method

.method public native IsShowDebugLineGrid()Z
.end method

.method public native IsShowDebugPCWS()Z
.end method

.method public native IsShowDebugTLCA()Z
.end method

.method public native IsTurnedOnTurnLampL()Z
.end method

.method public native IsTurnedOnTurnLampR()Z
.end method

.method public native PerformADAS([B)I
.end method

.method public native RenderAR(Z)Z
.end method

.method public native ResetADAS()V
.end method

.method public native ResetDR()V
.end method

.method public native SetCarControl(FFFFFZ)V
.end method

.method public native SetCarShadowGPS(Z)V
.end method

.method public native SetCarSpeedK(II)V
.end method

.method public native SetCarStatusGPS(I)V
.end method

.method public native SetCarType(IZ)V
.end method

.method public native SetDeviceCameraHeight(I)V
.end method

.method public native SetDeviceCameraHeightDefault()V
.end method

.method public native SetDrawCube(Z)V
.end method

.method public native SetFullMode(Z)V
.end method

.method public native SetGuideInfos(Lcom/thinkware/sundo/ieve/ieveGuideInfos;)V
.end method

.method public native SetHandDrive(I)Z
.end method

.method public native SetLanguage(I)Z
.end method

.method public native SetOBD2InfoBrakeSwitch(I)V
.end method

.method public native SetOBD2InfoGearMode(I)V
.end method

.method public native SetOBD2InfoSteeringDegree(F)V
.end method

.method public native SetOBD2Infos(FII)V
.end method

.method public native SetOperateAtSpeedKLDWS(I)Z
.end method

.method public native SetProposeToAdjustCamera(I)Z
.end method

.method public native SetROIBottom(I)V
.end method

.method public native SetROIBottomDefault()V
.end method

.method public native SetROILeft(I)V
.end method

.method public native SetROILeftDefault()V
.end method

.method public native SetROILeftStep(I)V
.end method

.method public native SetROIRight(I)V
.end method

.method public native SetROIRightDefault()V
.end method

.method public native SetROIRightStep(I)V
.end method

.method public native SetRouteLine([FIZ)V
.end method

.method public native SetScreenPosLeaderLine(IIII)V
.end method

.method public native SetScreenPosTLCA(II)V
.end method

.method public native SetSensitivityCSWS(I)V
.end method

.method public native SetSensitivityFCWS(I)V
.end method

.method public native SetSensitivityPCWS(I)V
.end method

.method public native SetSizeScreen(II)V
.end method

.method public native SetSizeView(IIII)V
.end method

.method public native SetSundown(CCC)V
.end method

.method public native SetSunup(CCC)V
.end method

.method public native SetTurnedOnTurnLamp(ZZ)V
.end method

.method public native SetUseSunFilm(Z)V
.end method

.method public native SetVanishingPointDefault()V
.end method

.method public native SetVanishingPointX(I)Z
.end method

.method public native SetVanishingPointY(I)Z
.end method

.method public native ShowBGCoverOverCamera(Z)V
.end method

.method public native SleepIEVE(IZ)V
.end method

.method public native onDrawFrame()V
.end method

.method public native onSurfaceChanged(II)V
.end method

.method public native onSurfaceCreated()V
.end method
