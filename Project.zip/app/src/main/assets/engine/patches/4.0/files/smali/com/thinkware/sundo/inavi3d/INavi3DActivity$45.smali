.class Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;
.super Ljava/lang/Object;
.source "INavi3DActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->InitMapButtons()Z
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;


# direct methods
.method constructor <init>(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)V
    .locals 0

    .prologue
    .line 14099
    iput-object p1, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 8

    .prologue
    const/4 v7, 0x0

    .line 14102
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v2

    .line 14103
    .local v2, "startTime":J
    const-string v4, "InitStatus"

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "2 - Start : "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-static {v4, v5}, Lcom/thinkware/sundo/inavi3d/LOGTW;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 14105
    iget-object v5, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    const v6, 0x7f0a0853

    invoke-virtual {v4, v6}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->findViewById(I)Landroid/view/View;

    move-result-object v4

    check-cast v4, Landroid/widget/ImageButton;

    iput-object v4, v5, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_QuickMenuButton:Landroid/widget/ImageButton;

    .line 14106
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v4, v4, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_QuickMenuButton:Landroid/widget/ImageButton;

    iget-object v5, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v5, v5, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->MapClickListener:Landroid/view/View$OnClickListener;

    invoke-virtual {v4, v5}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 14107
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v4, v4, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_QuickMenuButton:Landroid/widget/ImageButton;

    iget-object v5, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    invoke-virtual {v4, v5}, Landroid/widget/ImageButton;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    .line 14109
    iget-object v5, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    const v6, 0x7f0a02f8

    invoke-virtual {v4, v6}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->findViewById(I)Landroid/view/View;

    move-result-object v4

    check-cast v4, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;

    iput-object v4, v5, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_DestInfo:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;

    .line 14110
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v4, v4, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_DestInfo:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;

    iget-object v5, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    invoke-virtual {v4, v5}, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;->setListener(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)V

    .line 14111
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v4, v4, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_DestInfo:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;

    iget-object v5, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v5, v5, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->MapClickListener:Landroid/view/View$OnClickListener;

    invoke-virtual {v4, v5}, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 14113
    iget-object v5, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    const v6, 0x7f0a00a6

    invoke-virtual {v4, v6}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->findViewById(I)Landroid/view/View;

    move-result-object v4

    check-cast v4, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;

    iput-object v4, v5, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_DestInfoAR:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;

    .line 14114
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v4, v4, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_DestInfoAR:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;

    iget-object v5, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    invoke-virtual {v4, v5}, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;->setListener(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)V

    .line 14115
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v4, v4, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_DestInfoAR:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;

    iget-object v5, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v5, v5, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->MapClickListener:Landroid/view/View$OnClickListener;

    invoke-virtual {v4, v5}, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuideAR;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 14146
    iget-object v5, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    const v6, 0x7f0a05cc

    invoke-virtual {v4, v6}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->findViewById(I)Landroid/view/View;

    move-result-object v4

    check-cast v4, Landroid/widget/RelativeLayout;

    iput-object v4, v5, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_LocalGuideLayout:Landroid/widget/RelativeLayout;

    .line 14148
    iget-object v5, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    const v6, 0x7f0a02f7

    invoke-virtual {v4, v6}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->findViewById(I)Landroid/view/View;

    move-result-object v4

    check-cast v4, Landroid/widget/RelativeLayout;

    iput-object v4, v5, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_DestInfoLayout:Landroid/widget/RelativeLayout;

    .line 14152
    iget-object v5, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    const v6, 0x7f0a00a5

    invoke-virtual {v4, v6}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->findViewById(I)Landroid/view/View;

    move-result-object v4

    check-cast v4, Landroid/widget/RelativeLayout;

    iput-object v4, v5, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_DestInfoLayoutAR:Landroid/widget/RelativeLayout;

    .line 14155
    iget-object v5, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    const v6, 0x7f0a084d

    invoke-virtual {v4, v6}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->findViewById(I)Landroid/view/View;

    move-result-object v4

    check-cast v4, Lcom/thinkware/sundo/inavi3d/ui/component/TrafficButton;

    iput-object v4, v5, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_TrafficButton:Lcom/thinkware/sundo/inavi3d/ui/component/TrafficButton;

    .line 14156
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v4, v4, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_TrafficButton:Lcom/thinkware/sundo/inavi3d/ui/component/TrafficButton;

    iget-object v5, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v5, v5, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->MapClickListener:Landroid/view/View$OnClickListener;

    invoke-virtual {v4, v5}, Lcom/thinkware/sundo/inavi3d/ui/component/TrafficButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 14158
    iget-object v5, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    const v6, 0x7f0a0888

    invoke-virtual {v4, v6}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->findViewById(I)Landroid/view/View;

    move-result-object v4

    check-cast v4, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/LaneInfoView;

    iput-object v4, v5, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_LaneInfoview:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/LaneInfoView;

    .line 14159
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v4, v4, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_LaneInfoview:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/LaneInfoView;

    iget-object v5, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v5, v5, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->MapClickListener:Landroid/view/View$OnClickListener;

    invoke-virtual {v4, v5}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/LaneInfoView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 14161
    iget-object v5, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    const v6, 0x7f0a0820

    invoke-virtual {v4, v6}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->findViewById(I)Landroid/view/View;

    move-result-object v4

    check-cast v4, Landroid/widget/LinearLayout;

    iput-object v4, v5, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_CurrentOffLayOut:Landroid/widget/LinearLayout;

    .line 14162
    iget-object v5, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    const v6, 0x7f0a0844

    invoke-virtual {v4, v6}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->findViewById(I)Landroid/view/View;

    move-result-object v4

    check-cast v4, Landroid/widget/LinearLayout;

    iput-object v4, v5, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_CurrentOnLayOut:Landroid/widget/LinearLayout;

    .line 14163
    iget-object v5, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    const v6, 0x7f0a07f7

    invoke-virtual {v4, v6}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->findViewById(I)Landroid/view/View;

    move-result-object v4

    check-cast v4, Landroid/widget/LinearLayout;

    iput-object v4, v5, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_RouteResultLayOut:Landroid/widget/LinearLayout;

    .line 14165
    iget-object v5, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    const v6, 0x7f0a0468

    invoke-virtual {v4, v6}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->findViewById(I)Landroid/view/View;

    move-result-object v4

    check-cast v4, Landroid/widget/LinearLayout;

    iput-object v4, v5, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_PLogLayout:Landroid/widget/LinearLayout;

    .line 14169
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    const-string v5, "null"

    invoke-static {v4, v5, v7}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v4

    sput-object v4, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->mToastAR:Landroid/widget/Toast;

    .line 14171
    iget-object v5, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    const v6, 0x7f0a08bc

    invoke-virtual {v4, v6}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->findViewById(I)Landroid/view/View;

    move-result-object v4

    check-cast v4, Landroid/widget/ImageButton;

    iput-object v4, v5, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_MainmenuAR:Landroid/widget/ImageButton;

    .line 14172
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v4, v4, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_MainmenuAR:Landroid/widget/ImageButton;

    iget-object v5, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v5, v5, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->MapClickListener:Landroid/view/View$OnClickListener;

    invoke-virtual {v4, v5}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 14174
    iget-object v5, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    const v6, 0x7f0a0861

    invoke-virtual {v4, v6}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->findViewById(I)Landroid/view/View;

    move-result-object v4

    check-cast v4, Landroid/widget/RelativeLayout;

    iput-object v4, v5, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_CurrentOnLayOutNormal:Landroid/widget/RelativeLayout;

    .line 14175
    iget-object v5, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    const v6, 0x7f0a0845

    invoke-virtual {v4, v6}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->findViewById(I)Landroid/view/View;

    move-result-object v4

    check-cast v4, Landroid/widget/RelativeLayout;

    iput-object v4, v5, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_CurrentOnLayOutAR:Landroid/widget/RelativeLayout;

    .line 14177
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v4

    invoke-virtual {v4}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->isWideDisplay()Z

    move-result v4

    if-eqz v4, :cond_0

    .line 14178
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INaviScaleManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INaviScaleManager;

    move-result-object v4

    iget-object v5, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v5, v5, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_MainmenuAR:Landroid/widget/ImageButton;

    const/4 v6, 0x1

    invoke-virtual {v4, v5, v6}, Lcom/thinkware/sundo/inavi3d/INaviScaleManager;->scaleImageView(Landroid/view/View;I)V

    .line 14179
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v4, v4, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_CurrentOnLayOutAR:Landroid/widget/RelativeLayout;

    const v5, 0x7f0a08d3

    invoke-virtual {v4, v5}, Landroid/widget/RelativeLayout;->findViewById(I)Landroid/view/View;

    move-result-object v1

    .line 14180
    .local v1, "v":Landroid/view/View;
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INaviScaleManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INaviScaleManager;

    move-result-object v4

    invoke-virtual {v4, v1}, Lcom/thinkware/sundo/inavi3d/INaviScaleManager;->restoreView(Landroid/view/View;)V

    .line 14183
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v4, v4, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_CurrentOnLayOutAR:Landroid/widget/RelativeLayout;

    const v5, 0x7f0a08cc

    invoke-virtual {v4, v5}, Landroid/widget/RelativeLayout;->findViewById(I)Landroid/view/View;

    move-result-object v0

    .line 14184
    .local v0, "speedometer":Landroid/view/View;
    const/4 v4, 0x0

    invoke-virtual {v0, v4}, Landroid/view/View;->setPivotX(F)V

    .line 14185
    const v4, 0x3f572045

    invoke-virtual {v0, v4}, Landroid/view/View;->setScaleX(F)V

    .line 14188
    .end local v0    # "speedometer":Landroid/view/View;
    .end local v1    # "v":Landroid/view/View;
    :cond_0
    iget-object v5, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    const v6, 0x7f0a08bd

    invoke-virtual {v4, v6}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->findViewById(I)Landroid/view/View;

    move-result-object v4

    check-cast v4, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/DriveCourseViewAR;

    iput-object v4, v5, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_CourseViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/DriveCourseViewAR;

    .line 14189
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v4, v4, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_CourseViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/DriveCourseViewAR;

    iget-object v5, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v5, v5, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->MapClickListener:Landroid/view/View$OnClickListener;

    invoke-virtual {v4, v5}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/DriveCourseViewAR;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 14191
    iget-object v5, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    const v6, 0x7f0a08bf

    invoke-virtual {v4, v6}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->findViewById(I)Landroid/view/View;

    move-result-object v4

    check-cast v4, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/DriveCourseCurrentViewAR;

    iput-object v4, v5, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_CourseRightViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/DriveCourseCurrentViewAR;

    .line 14192
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v4, v4, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_CourseRightViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/DriveCourseCurrentViewAR;

    iget-object v5, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v5, v5, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->MapClickListener:Landroid/view/View$OnClickListener;

    invoke-virtual {v4, v5}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/DriveCourseCurrentViewAR;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 14195
    iget-object v5, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    const v6, 0x7f0a08be

    invoke-virtual {v4, v6}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->findViewById(I)Landroid/view/View;

    move-result-object v4

    check-cast v4, Landroid/widget/Button;

    iput-object v4, v5, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_DriveCourseViewRouteCancelButtonAR:Landroid/widget/Button;

    .line 14196
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v4, v4, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_DriveCourseViewRouteCancelButtonAR:Landroid/widget/Button;

    iget-object v5, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v5, v5, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->MapClickListener:Landroid/view/View$OnClickListener;

    invoke-virtual {v4, v5}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 14199
    iget-object v5, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    const v6, 0x7f0a08c0

    invoke-virtual {v4, v6}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->findViewById(I)Landroid/view/View;

    move-result-object v4

    check-cast v4, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaViewAR;

    iput-object v4, v5, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_TurnAreaViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaViewAR;

    .line 14203
    iget-object v5, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    const v6, 0x7f0a08c1

    invoke-virtual {v4, v6}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->findViewById(I)Landroid/view/View;

    move-result-object v4

    check-cast v4, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/HighwayTurnAreaViewAR;

    iput-object v4, v5, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_HighwayTurnAreaViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/HighwayTurnAreaViewAR;

    .line 14207
    iget-object v5, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    const v6, 0x7f0a08b6

    invoke-virtual {v4, v6}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->findViewById(I)Landroid/view/View;

    move-result-object v4

    check-cast v4, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/LaneInfoViewAR;

    iput-object v4, v5, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_LaneInfoviewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/LaneInfoViewAR;

    .line 14208
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v4, v4, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_LaneInfoviewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/LaneInfoViewAR;

    if-eqz v4, :cond_1

    invoke-virtual {v4, v7}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/LaneInfoViewAR;->setClickable(Z)V

    .line 14209
    invoke-virtual {v4, v7}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/LaneInfoViewAR;->setFocusable(Z)V

    .line 14216
    :cond_1
    iget-object v5, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    const v6, @@RES:id/view_stradvision_ar@@

    invoke-virtual {v4, v6}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->findViewById(I)Landroid/view/View;

    move-result-object v4

    check-cast v4, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/StradvisionViewAR;

    iput-object v4, v5, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StradvisionViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/StradvisionViewAR;

    .line 14217
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v4, v4, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StradvisionViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/StradvisionViewAR;

    if-eqz v4, :cond_2

    invoke-virtual {v4, v7}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/StradvisionViewAR;->setClickable(Z)V

    .line 14218
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v4, v4, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StradvisionViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/StradvisionViewAR;

    invoke-virtual {v4, v7}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/StradvisionViewAR;->setFocusable(Z)V

    .line 14220
    :cond_2
    iget-object v5, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    const v6, 0x7f0a08d0

    invoke-virtual {v4, v6}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->findViewById(I)Landroid/view/View;

    move-result-object v4

    check-cast v4, Landroid/widget/RelativeLayout;

    iput-object v4, v5, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_bsdLsyoutAR:Landroid/widget/RelativeLayout;

    .line 14221
    if-eqz v4, :cond_3

    const/4 v5, 0x4

    invoke-virtual {v4, v5}, Landroid/widget/RelativeLayout;->setVisibility(I)V

    .line 14222
    :cond_3
    iget-object v5, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    const v6, 0x7f0a08d1

    invoke-virtual {v4, v6}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->findViewById(I)Landroid/view/View;

    move-result-object v4

    check-cast v4, Landroid/widget/ImageView;

    iput-object v4, v5, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_bsdImageViewAR:Landroid/widget/ImageView;

    .line 14233
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v4

    invoke-virtual {v4}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->getScaleType()I

    move-result v4

    const/4 v5, 0x3

    if-ne v4, v5, :cond_4

    .line 14234
    iget-object v5, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    const v6, 0x7f0a08d5

    invoke-virtual {v4, v6}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->findViewById(I)Landroid/view/View;

    move-result-object v4

    check-cast v4, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TrafficProgressBar;

    iput-object v4, v5, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->mTrafficProgressBarAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TrafficProgressBar;

    .line 14235
    iget-object v5, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    const v6, 0x7f0a08d4

    invoke-virtual {v4, v6}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->findViewById(I)Landroid/view/View;

    move-result-object v4

    check-cast v4, Landroid/widget/RelativeLayout;

    iput-object v4, v5, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->mTrafficProgressBarLayoutAR:Landroid/widget/RelativeLayout;

    .line 14237
    :cond_4
    iget-object v5, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    const v6, 0x7f0a08b2

    invoke-virtual {v4, v6}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->findViewById(I)Landroid/view/View;

    move-result-object v4

    check-cast v4, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TrafficProgressBar;

    iput-object v4, v5, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->mTrafficProgressBar:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TrafficProgressBar;

    .line 14238
    iget-object v5, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$45;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    const v6, 0x7f0a08b0

    invoke-virtual {v4, v6}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->findViewById(I)Landroid/view/View;

    move-result-object v4

    check-cast v4, Landroid/widget/RelativeLayout;

    iput-object v4, v5, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->mTrafficProgressBarLayout:Landroid/widget/RelativeLayout;

    .line 14240
    const-string v4, "InitStatus"

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "2 - End : "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v6

    sub-long/2addr v6, v2

    invoke-virtual {v5, v6, v7}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-static {v4, v5}, Lcom/thinkware/sundo/inavi3d/LOGTW;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 14241
    return-void
.end method
