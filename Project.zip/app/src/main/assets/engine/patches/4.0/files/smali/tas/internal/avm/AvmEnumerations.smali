.class public Ltas/internal/avm/AvmEnumerations;
.super Ljava/lang/Object;
.source "AvmEnumerations.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ltas/internal/avm/AvmEnumerations$MessageID;,
        Ltas/internal/avm/AvmEnumerations$CalibrationStatus;,
        Ltas/internal/avm/AvmEnumerations$ViewMode;,
        Ltas/internal/avm/AvmEnumerations$UpgradeMode;,
        Ltas/internal/avm/AvmEnumerations$KeyBoxEvent;,
        Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;,
        Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;,
        Ltas/internal/avm/AvmEnumerations$PGSDataType;,
        Ltas/internal/avm/AvmEnumerations$PGSCoordType;,
        Ltas/internal/avm/AvmEnumerations$BootMode;
    }
.end annotation


# static fields
.field private static final RANDOM_TEST_ALLOWED_LIST:[Ltas/internal/avm/AvmEnumerations$MessageID;


# direct methods
.method static synthetic -get0()[Ltas/internal/avm/AvmEnumerations$MessageID;
    .locals 1

    sget-object v0, Ltas/internal/avm/AvmEnumerations;->RANDOM_TEST_ALLOWED_LIST:[Ltas/internal/avm/AvmEnumerations$MessageID;

    return-object v0
.end method

.method static constructor <clinit>()V
    .locals 3

    .prologue
    .line 6
    const/4 v0, 0x4

    new-array v0, v0, [Ltas/internal/avm/AvmEnumerations$MessageID;

    .line 8
    const/16 v1, 0x13

    invoke-static {v1}, Ltas/internal/avm/AvmEnumerations$MessageID;->createFromValue(I)Ltas/internal/avm/AvmEnumerations$MessageID;

    move-result-object v1

    const/4 v2, 0x0

    aput-object v1, v0, v2

    .line 10
    const/16 v1, 0x16

    invoke-static {v1}, Ltas/internal/avm/AvmEnumerations$MessageID;->createFromValue(I)Ltas/internal/avm/AvmEnumerations$MessageID;

    move-result-object v1

    const/4 v2, 0x1

    aput-object v1, v0, v2

    .line 11
    const/16 v1, 0x17

    invoke-static {v1}, Ltas/internal/avm/AvmEnumerations$MessageID;->createFromValue(I)Ltas/internal/avm/AvmEnumerations$MessageID;

    move-result-object v1

    const/4 v2, 0x2

    aput-object v1, v0, v2

    .line 14
    const/16 v1, 0x30

    invoke-static {v1}, Ltas/internal/avm/AvmEnumerations$MessageID;->createFromValue(I)Ltas/internal/avm/AvmEnumerations$MessageID;

    move-result-object v1

    const/4 v2, 0x3

    aput-object v1, v0, v2

    .line 6
    sput-object v0, Ltas/internal/avm/AvmEnumerations;->RANDOM_TEST_ALLOWED_LIST:[Ltas/internal/avm/AvmEnumerations$MessageID;

    .line 5
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .prologue
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
