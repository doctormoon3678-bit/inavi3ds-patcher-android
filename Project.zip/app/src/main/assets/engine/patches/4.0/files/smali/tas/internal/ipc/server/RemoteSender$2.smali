.class final Ltas/internal/ipc/server/RemoteSender$2;
.super Ljava/lang/Object;
.source "RemoteSender.java"

# interfaces
.implements Ltas/internal/ipc/util/SyncdPool$Callback;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltas/internal/ipc/server/RemoteSender;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ltas/internal/ipc/util/SyncdPool$Callback",
        "<",
        "Ltas/internal/ipc/server/RemoteSender;",
        ">;"
    }
.end annotation


# direct methods
.method constructor <init>()V
    .locals 0

    .prologue
    .line 70
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public bridge synthetic getNext(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1
    .param p1, "s"    # Ljava/lang/Object;

    .prologue
    .line 78
    check-cast p1, Ltas/internal/ipc/server/RemoteSender;

    .end local p1    # "s":Ljava/lang/Object;
    invoke-virtual {p0, p1}, Ltas/internal/ipc/server/RemoteSender$2;->getNext(Ltas/internal/ipc/server/RemoteSender;)Ltas/internal/ipc/server/RemoteSender;

    move-result-object v0

    return-object v0
.end method

.method public getNext(Ltas/internal/ipc/server/RemoteSender;)Ltas/internal/ipc/server/RemoteSender;
    .locals 1
    .param p1, "s"    # Ltas/internal/ipc/server/RemoteSender;

    .prologue
    .line 79
    invoke-static {p1}, Ltas/internal/ipc/server/RemoteSender;->-get0(Ltas/internal/ipc/server/RemoteSender;)Ltas/internal/ipc/server/RemoteSender;

    move-result-object v0

    return-object v0
.end method

.method public bridge synthetic newInstance()Ljava/lang/Object;
    .locals 1

    .prologue
    .line 71
    invoke-virtual {p0}, Ltas/internal/ipc/server/RemoteSender$2;->newInstance()Ltas/internal/ipc/server/RemoteSender;

    move-result-object v0

    return-object v0
.end method

.method public newInstance()Ltas/internal/ipc/server/RemoteSender;
    .locals 3

    .prologue
    const/4 v1, 0x0

    .line 72
    new-instance v0, Ltas/internal/ipc/server/RemoteSender;

    invoke-direct {v0, v1, v1}, Ltas/internal/ipc/server/RemoteSender;-><init>(Ltas/internal/ipc/server/RemoteSender;Ltas/internal/ipc/server/RemoteSender;)V

    .line 73
    .local v0, "s":Ltas/internal/ipc/server/RemoteSender;
    const/4 v1, 0x1

    invoke-static {v0, v1}, Ltas/internal/ipc/server/RemoteSender;->-set0(Ltas/internal/ipc/server/RemoteSender;Z)Z

    .line 74
    invoke-static {}, Ltas/internal/ipc/server/RemoteSender;->-get1()I

    move-result v1

    add-int/lit8 v2, v1, 0x1

    invoke-static {v2}, Ltas/internal/ipc/server/RemoteSender;->-set3(I)I

    invoke-static {v0, v1}, Ltas/internal/ipc/server/RemoteSender;->-set2(Ltas/internal/ipc/server/RemoteSender;I)I

    .line 75
    return-object v0
.end method

.method public bridge synthetic setNext(Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 0
    .param p1, "s"    # Ljava/lang/Object;
    .param p2, "next"    # Ljava/lang/Object;

    .prologue
    .line 82
    check-cast p1, Ltas/internal/ipc/server/RemoteSender;

    .end local p1    # "s":Ljava/lang/Object;
    check-cast p2, Ltas/internal/ipc/server/RemoteSender;

    .end local p2    # "next":Ljava/lang/Object;
    invoke-virtual {p0, p1, p2}, Ltas/internal/ipc/server/RemoteSender$2;->setNext(Ltas/internal/ipc/server/RemoteSender;Ltas/internal/ipc/server/RemoteSender;)V

    return-void
.end method

.method public setNext(Ltas/internal/ipc/server/RemoteSender;Ltas/internal/ipc/server/RemoteSender;)V
    .locals 0
    .param p1, "s"    # Ltas/internal/ipc/server/RemoteSender;
    .param p2, "next"    # Ltas/internal/ipc/server/RemoteSender;

    .prologue
    .line 83
    invoke-static {p1, p2}, Ltas/internal/ipc/server/RemoteSender;->-set1(Ltas/internal/ipc/server/RemoteSender;Ltas/internal/ipc/server/RemoteSender;)Ltas/internal/ipc/server/RemoteSender;

    .line 82
    return-void
.end method
