.class public Lcom/thinkware/sundo/inavi3d/liveroute/ControlRouteTable;
.super Ljava/lang/Object;
.source "ControlRouteTable.java"


# static fields
.field public static final ERR_CHECKSUM:I = 0x61

.field public static final ERR_FAIL:I = -0x1

.field public static final ERR_MR_VERSION:I = 0x33

.field public static final ERR_SMART_ROUTE:I = 0x78

.field public static final ERR_SMART_ROUTE2:I = 0x79

.field public static final SUCCESS:I


# instance fields
.field private HIPASS_ADD:Z

.field private byte_order_data:[B

.field private errormsg:Ljava/lang/String;

.field private http_routetable:Lcom/thinkware/sundo/inavi3d/liveroute/HttpUtil;

.field private jso:Lorg/json/JSONObject;

.field private mapVersion:I

.field private rdata:Ljava/lang/String;

.field private result:I

.field private rid:Ljava/lang/String;

.field private route_data:[B


# direct methods
.method public constructor <init>()V
    .locals 2

    .prologue
    const/4 v1, 0x0

    .line 20
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 22
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/liveroute/ControlRouteTable;->HIPASS_ADD:Z

    .line 37
    const/4 v0, -0x1

    iput v0, p0, Lcom/thinkware/sundo/inavi3d/liveroute/ControlRouteTable;->mapVersion:I

    .line 39
    new-instance v0, Lcom/thinkware/sundo/inavi3d/liveroute/HttpUtil;

    invoke-direct {v0}, Lcom/thinkware/sundo/inavi3d/liveroute/HttpUtil;-><init>()V

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/liveroute/ControlRouteTable;->http_routetable:Lcom/thinkware/sundo/inavi3d/liveroute/HttpUtil;

    .line 41
    iput-object v1, p0, Lcom/thinkware/sundo/inavi3d/liveroute/ControlRouteTable;->jso:Lorg/json/JSONObject;

    .line 42
    const/4 v0, 0x0

    iput v0, p0, Lcom/thinkware/sundo/inavi3d/liveroute/ControlRouteTable;->result:I

    .line 43
    iput-object v1, p0, Lcom/thinkware/sundo/inavi3d/liveroute/ControlRouteTable;->errormsg:Ljava/lang/String;

    .line 44
    iput-object v1, p0, Lcom/thinkware/sundo/inavi3d/liveroute/ControlRouteTable;->rid:Ljava/lang/String;

    .line 45
    iput-object v1, p0, Lcom/thinkware/sundo/inavi3d/liveroute/ControlRouteTable;->rdata:Ljava/lang/String;

    .line 46
    iput-object v1, p0, Lcom/thinkware/sundo/inavi3d/liveroute/ControlRouteTable;->route_data:[B

    .line 47
    iput-object v1, p0, Lcom/thinkware/sundo/inavi3d/liveroute/ControlRouteTable;->byte_order_data:[B

    return-void
.end method

.method private CheckSum([B)I
    .locals 14
    .param p1, "data"    # [B

    .prologue
    const-wide/32 v12, 0xffff

    const/16 v10, 0x10

    const/4 v8, 0x1

    .line 975
    new-instance v0, Ljava/io/ByteArrayInputStream;

    const/4 v3, 0x2

    array-length v6, p1

    add-int/lit8 v6, v6, 0x2

    invoke-direct {v0, p1, v3, v6}, Ljava/io/ByteArrayInputStream;-><init>([BII)V

    .line 977
    .local v0, "bais":Ljava/io/ByteArrayInputStream;
    new-instance v1, Ljava/io/DataInputStream;

    invoke-direct {v1, v0}, Ljava/io/DataInputStream;-><init>(Ljava/io/InputStream;)V

    .line 978
    .local v1, "dis":Ljava/io/DataInputStream;
    const-wide/16 v4, 0x0

    .line 980
    .local v4, "sum1":J
    :try_start_0
    invoke-virtual {v1}, Ljava/io/DataInputStream;->available()I

    move-result v2

    .line 981
    .local v2, "n":I
    :goto_0
    if-le v2, v8, :cond_0

    .line 982
    invoke-direct {p0, v1}, Lcom/thinkware/sundo/inavi3d/liveroute/ControlRouteTable;->byte2UnsignedShort(Ljava/io/DataInputStream;)I

    move-result v3

    int-to-long v6, v3

    add-long/2addr v4, v6

    .line 983
    invoke-virtual {v1}, Ljava/io/DataInputStream;->available()I

    move-result v2

    goto :goto_0

    .line 985
    :cond_0
    if-ne v2, v8, :cond_1

    .line 986
    invoke-direct {p0, v1}, Lcom/thinkware/sundo/inavi3d/liveroute/ControlRouteTable;->byte2UnsignedChar(Ljava/io/DataInputStream;)I
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    move-result v3

    int-to-long v6, v3

    add-long/2addr v4, v6

    .line 988
    :cond_1
    and-long v6, v4, v12

    shr-long v8, v4, v10

    add-long v4, v6, v8

    .line 989
    shr-long v6, v4, v10

    add-long/2addr v4, v6

    .line 990
    const-wide/16 v6, -0x1

    xor-long/2addr v4, v6

    .line 991
    and-long/2addr v4, v12

    .line 996
    if-eqz v1, :cond_2

    .line 997
    :try_start_1
    invoke-virtual {v1}, Ljava/io/DataInputStream;->close()V

    .line 999
    :cond_2
    if-eqz v0, :cond_3

    .line 1000
    invoke-virtual {v0}, Ljava/io/ByteArrayInputStream;->close()V
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_3

    .line 1005
    .end local v2    # "n":I
    :cond_3
    :goto_1
    long-to-int v3, v4

    return v3

    .line 993
    :catch_0
    move-exception v3

    .line 996
    if-eqz v1, :cond_4

    .line 997
    :try_start_2
    invoke-virtual {v1}, Ljava/io/DataInputStream;->close()V

    .line 999
    :cond_4
    if-eqz v0, :cond_3

    .line 1000
    invoke-virtual {v0}, Ljava/io/ByteArrayInputStream;->close()V
    :try_end_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_1

    goto :goto_1

    .line 1002
    :catch_1
    move-exception v3

    goto :goto_1

    .line 995
    :catchall_0
    move-exception v3

    .line 996
    if-eqz v1, :cond_5

    .line 997
    :try_start_3
    invoke-virtual {v1}, Ljava/io/DataInputStream;->close()V

    .line 999
    :cond_5
    if-eqz v0, :cond_6

    .line 1000
    invoke-virtual {v0}, Ljava/io/ByteArrayInputStream;->close()V
    :try_end_3
    .catch Ljava/io/IOException; {:try_start_3 .. :try_end_3} :catch_2

    .line 1003
    :cond_6
    :goto_2
    throw v3

    .line 1002
    :catch_2
    move-exception v6

    goto :goto_2

    .restart local v2    # "n":I
    :catch_3
    move-exception v3

    goto :goto_1
.end method

.method private byte2UnsignedChar(Ljava/io/DataInputStream;)I
    .locals 5
    .param p1, "dis"    # Ljava/io/DataInputStream;

    .prologue
    .line 1022
    const/4 v3, 0x1

    new-array v2, v3, [B

    .line 1024
    .local v2, "value":[B
    const/4 v3, 0x0

    :try_start_0
    array-length v4, v2

    invoke-virtual {p1, v2, v3, v4}, Ljava/io/DataInputStream;->read([BII)I

    .line 1025
    const/4 v3, 0x0

    aget-byte v3, v2, v3
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    and-int/lit16 v0, v3, 0xff

    .line 1026
    .local v0, "b0":I
    shl-int/lit8 v3, v0, 0x0

    .line 1030
    .end local v0    # "b0":I
    :goto_0
    return v3

    .line 1027
    :catch_0
    move-exception v1

    .line 1028
    .local v1, "e":Ljava/io/IOException;
    invoke-virtual {v1}, Ljava/io/IOException;->printStackTrace()V

    .line 1030
    const/16 v3, -0xff

    goto :goto_0
.end method

.method private byte2UnsignedShort(Ljava/io/DataInputStream;)I
    .locals 6
    .param p1, "dis"    # Ljava/io/DataInputStream;

    .prologue
    .line 1009
    const/4 v4, 0x2

    new-array v3, v4, [B

    .line 1011
    .local v3, "value":[B
    const/4 v4, 0x0

    :try_start_0
    array-length v5, v3

    invoke-virtual {p1, v3, v4, v5}, Ljava/io/DataInputStream;->read([BII)I

    .line 1012
    const/4 v4, 0x0

    aget-byte v4, v3, v4

    and-int/lit16 v0, v4, 0xff

    .line 1013
    .local v0, "b0":I
    const/4 v4, 0x1

    aget-byte v4, v3, v4
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    and-int/lit16 v1, v4, 0xff

    .line 1014
    .local v1, "b1":I
    shl-int/lit8 v4, v1, 0x8

    shl-int/lit8 v5, v0, 0x0

    add-int/2addr v4, v5

    .line 1018
    .end local v0    # "b0":I
    .end local v1    # "b1":I
    :goto_0
    return v4

    .line 1015
    :catch_0
    move-exception v2

    .line 1016
    .local v2, "e":Ljava/io/IOException;
    invoke-virtual {v2}, Ljava/io/IOException;->printStackTrace()V

    .line 1018
    const/16 v4, -0xff

    goto :goto_0
.end method

.method private getMrVersion()Ljava/lang/String;
    .locals 9

    .prologue
    .line 1035
    sget-boolean v6, Lcom/thinkware/sundo/inavi3d/liveroute/HttpUtil;->conn_switch:Z

    if-nez v6, :cond_0

    .line 1039
    :cond_0
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    sget-object v7, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->SD_EXT_STORAGE_PATH:Ljava/lang/String;

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, "/inavi3d/mapdata/mrdata/mrmanage.bin"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    .line 1042
    .local v4, "strMrdataDir":Ljava/lang/String;
    :try_start_0
    new-instance v2, Ljava/io/File;

    invoke-direct {v2, v4}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 1043
    .local v2, "file":Ljava/io/File;
    const/4 v3, 0x0

    .line 1045
    .local v3, "in":Ljava/io/BufferedInputStream;
    new-instance v3, Ljava/io/BufferedInputStream;

    .end local v3    # "in":Ljava/io/BufferedInputStream;
    new-instance v6, Ljava/io/FileInputStream;

    invoke-direct {v6, v2}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V

    invoke-direct {v3, v6}, Ljava/io/BufferedInputStream;-><init>(Ljava/io/InputStream;)V

    .line 1046
    .restart local v3    # "in":Ljava/io/BufferedInputStream;
    invoke-virtual {v3}, Ljava/io/BufferedInputStream;->available()I

    move-result v6

    new-array v0, v6, [B

    .line 1047
    .local v0, "data":[B
    invoke-virtual {v3, v0}, Ljava/io/BufferedInputStream;->read([B)I

    .line 1049
    invoke-virtual {v3}, Ljava/io/BufferedInputStream;->close()V

    .line 1051
    const/16 v6, 0x10

    new-array v5, v6, [B

    .line 1053
    .local v5, "tmpData":[B
    const/16 v6, 0x1d8

    const/4 v7, 0x0

    const/16 v8, 0x10

    invoke-static {v0, v6, v5, v7, v8}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 1055
    new-instance v6, Ljava/lang/String;

    invoke-direct {v6, v5}, Ljava/lang/String;-><init>([B)V

    invoke-virtual {v6}, Ljava/lang/String;->trim()Ljava/lang/String;
    :try_end_0
    .catch Ljava/io/FileNotFoundException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_1

    move-result-object v6

    .line 1063
    .end local v0    # "data":[B
    .end local v2    # "file":Ljava/io/File;
    .end local v3    # "in":Ljava/io/BufferedInputStream;
    .end local v5    # "tmpData":[B
    :goto_0
    return-object v6

    .line 1056
    :catch_0
    move-exception v1

    .line 1058
    .local v1, "e":Ljava/io/FileNotFoundException;
    invoke-virtual {v1}, Ljava/io/FileNotFoundException;->printStackTrace()V

    .line 1063
    .end local v1    # "e":Ljava/io/FileNotFoundException;
    :goto_1
    const/4 v6, 0x0

    goto :goto_0

    .line 1059
    :catch_1
    move-exception v1

    .line 1061
    .local v1, "e":Ljava/io/IOException;
    invoke-virtual {v1}, Ljava/io/IOException;->printStackTrace()V

    goto :goto_1
.end method


# virtual methods
.method public get_byte_order_data()[B
    .locals 1

    .prologue
    .line 1073
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/liveroute/ControlRouteTable;->byte_order_data:[B

    return-object v0
.end method

.method public get_byte_order_data([BI)[B
    .locals 30
    .param p1, "in"    # [B
    .param p2, "length"    # I

    .prologue
    .line 361
    const/16 v24, 0x0

    .line 362
    .local v24, "temp_data":[B
    const/16 v20, 0x0

    .line 364
    .local v20, "network_check_sum":I
    const/16 v21, 0x0

    .line 366
    .local v21, "offset":I
    const/4 v13, 0x0

    .line 367
    .local v13, "i":I
    const/16 v17, 0x0

    .line 368
    .local v17, "mapid_linkid_count":I
    const/4 v15, 0x0

    .line 369
    .local v15, "linkid_count":I
    const/16 v18, 0x0

    .line 370
    .local v18, "mapid_vertex_count":I
    const/16 v26, 0x0

    .line 371
    .local v26, "vertex_count":I
    const/16 v16, 0x0

    .line 372
    .local v16, "mapid_guide_count":I
    const/4 v12, 0x0

    .line 373
    .local v12, "guide_count":I
    const/4 v10, 0x0

    .line 374
    .local v10, "etcinfo_count":I
    const/4 v8, 0x0

    .line 375
    .local v8, "charge_count":I
    const/4 v4, 0x0

    .line 376
    .local v4, "accident_count":I
    const/4 v5, 0x0

    .line 377
    .local v5, "affect_count":I
    const/16 v25, 0x0

    .line 379
    .local v25, "time_domain_length":I
    move-object/from16 v0, p1

    array-length v0, v0

    move/from16 v27, v0

    const/16 v28, 0x2

    move/from16 v0, v27

    move/from16 v1, v28

    if-ge v0, v1, :cond_0

    .line 381
    const/16 v27, 0x0

    .line 967
    :goto_0
    return-object v27

    .line 384
    :cond_0
    invoke-direct/range {p0 .. p1}, Lcom/thinkware/sundo/inavi3d/liveroute/ControlRouteTable;->CheckSum([B)I

    move-result v20

    .line 385
    const-string v27, "inavi3d_route"

    new-instance v28, Ljava/lang/StringBuilder;

    invoke-direct/range {v28 .. v28}, Ljava/lang/StringBuilder;-><init>()V

    const-string v29, "====NETWORK CHECK SUM["

    invoke-virtual/range {v28 .. v29}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v28

    move-object/from16 v0, v28

    move/from16 v1, v20

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v28

    const-string v29, "]======"

    invoke-virtual/range {v28 .. v29}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v28

    invoke-virtual/range {v28 .. v28}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v28

    invoke-static/range {v27 .. v28}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 386
    const-string v27, "inavi3d_route"

    new-instance v28, Ljava/lang/StringBuilder;

    invoke-direct/range {v28 .. v28}, Ljava/lang/StringBuilder;-><init>()V

    const-string v29, "length["

    invoke-virtual/range {v28 .. v29}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v28

    move-object/from16 v0, v28

    move/from16 v1, p2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v28

    const-string v29, "]"

    invoke-virtual/range {v28 .. v29}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v28

    invoke-virtual/range {v28 .. v28}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v28

    invoke-static/range {v27 .. v28}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 388
    invoke-static/range {p2 .. p2}, Ljava/nio/ByteBuffer;->allocate(I)Ljava/nio/ByteBuffer;

    move-result-object v7

    .line 389
    .local v7, "buf":Ljava/nio/ByteBuffer;
    invoke-static/range {p1 .. p1}, Ljava/nio/ByteBuffer;->wrap([B)Ljava/nio/ByteBuffer;

    move-result-object v14

    .line 391
    .local v14, "inbuf":Ljava/nio/ByteBuffer;
    sget-object v27, Ljava/nio/ByteOrder;->LITTLE_ENDIAN:Ljava/nio/ByteOrder;

    move-object/from16 v0, v27

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->order(Ljava/nio/ByteOrder;)Ljava/nio/ByteBuffer;

    .line 393
    const-string v27, "inavi3d_route"

    new-instance v28, Ljava/lang/StringBuilder;

    invoke-direct/range {v28 .. v28}, Ljava/lang/StringBuilder;-><init>()V

    const-string v29, "in_checksum["

    invoke-virtual/range {v28 .. v29}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v28

    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getShort(I)S

    move-result v29

    invoke-virtual/range {v28 .. v29}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v28

    const-string v29, "]"

    invoke-virtual/range {v28 .. v29}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v28

    invoke-virtual/range {v28 .. v28}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v28

    invoke-static/range {v27 .. v28}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 395
    const/16 v27, 0x0

    aget-byte v27, p1, v27

    move/from16 v0, v27

    and-int/lit16 v11, v0, 0xff

    .line 396
    .local v11, "firstByte":I
    const/16 v27, 0x1

    aget-byte v27, p1, v27

    move/from16 v0, v27

    and-int/lit16 v0, v0, 0xff

    move/from16 v23, v0

    .line 397
    .local v23, "secondByte":I
    shl-int/lit8 v27, v11, 0x8

    or-int v27, v27, v23

    move/from16 v0, v27

    int-to-char v6, v0

    .line 398
    .local v6, "anUnsignedShort":I
    const-string v27, "inavi3d_route"

    new-instance v28, Ljava/lang/StringBuilder;

    invoke-direct/range {v28 .. v28}, Ljava/lang/StringBuilder;-><init>()V

    const-string v29, "anUnsignedShort["

    invoke-virtual/range {v28 .. v29}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v28

    move-object/from16 v0, v28

    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v28

    const-string v29, "]"

    invoke-virtual/range {v28 .. v29}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v28

    invoke-virtual/range {v28 .. v28}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v28

    invoke-static/range {v27 .. v28}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 400
    move/from16 v0, v20

    if-eq v0, v6, :cond_1

    .line 401
    const-string v27, "inavi3d_route"

    new-instance v28, Ljava/lang/StringBuilder;

    invoke-direct/range {v28 .. v28}, Ljava/lang/StringBuilder;-><init>()V

    const-string v29, "ERR: network_check_sum["

    invoke-virtual/range {v28 .. v29}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v28

    move-object/from16 v0, v28

    move/from16 v1, v20

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v28

    const-string v29, "] diff read_checksum["

    invoke-virtual/range {v28 .. v29}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v28

    move-object/from16 v0, v28

    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v28

    const-string v29, "]"

    invoke-virtual/range {v28 .. v29}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v28

    invoke-virtual/range {v28 .. v28}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v28

    invoke-static/range {v27 .. v28}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 403
    const/16 v27, 0x0

    goto/16 :goto_0

    .line 407
    :cond_1
    const/16 v27, 0x1

    move/from16 v0, v27

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    .line 408
    const/16 v27, 0x1

    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v28

    move/from16 v0, v27

    move/from16 v1, v28

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    .line 409
    add-int/lit8 v21, v21, 0x2

    .line 414
    move-object/from16 v0, p0

    iget v0, v0, Lcom/thinkware/sundo/inavi3d/liveroute/ControlRouteTable;->mapVersion:I

    move/from16 v27, v0

    if-lez v27, :cond_2

    .line 415
    move-object/from16 v0, p0

    iget v0, v0, Lcom/thinkware/sundo/inavi3d/liveroute/ControlRouteTable;->mapVersion:I

    move/from16 v27, v0

    move-object/from16 v0, p0

    move/from16 v1, v27

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/inavi3d/liveroute/ControlRouteTable;->little2big(I)I

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->putInt(II)Ljava/nio/ByteBuffer;

    .line 419
    :goto_1
    add-int/lit8 v21, v21, 0x4

    .line 422
    new-instance v22, Ljava/lang/String;

    const/16 v27, 0x28

    move-object/from16 v0, v22

    move-object/from16 v1, p1

    move/from16 v2, v21

    move/from16 v3, v27

    invoke-direct {v0, v1, v2, v3}, Ljava/lang/String;-><init>([BII)V

    .line 423
    .local v22, "optionName":Ljava/lang/String;
    invoke-virtual/range {v22 .. v22}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v27

    const-string v28, "real_traffic"

    invoke-virtual/range {v27 .. v28}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v27

    const/16 v28, 0x1

    move/from16 v0, v27

    move/from16 v1, v28

    if-ne v0, v1, :cond_3

    .line 424
    const-string v22, "real_traffic1"

    .line 425
    move/from16 v0, v21

    invoke-virtual {v7, v0}, Ljava/nio/ByteBuffer;->position(I)Ljava/nio/Buffer;

    .line 426
    invoke-virtual/range {v22 .. v22}, Ljava/lang/String;->getBytes()[B

    move-result-object v27

    move-object/from16 v0, v27

    invoke-virtual {v7, v0}, Ljava/nio/ByteBuffer;->put([B)Ljava/nio/ByteBuffer;

    .line 443
    :goto_2
    add-int/lit8 v21, v21, 0x28

    .line 446
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->putInt(II)Ljava/nio/ByteBuffer;

    .line 447
    add-int/lit8 v21, v21, 0x4

    .line 449
    const-string v27, "inavi3d_route"

    new-instance v28, Ljava/lang/StringBuilder;

    invoke-direct/range {v28 .. v28}, Ljava/lang/StringBuilder;-><init>()V

    const-string v29, "startx :: inbuf.getInt("

    invoke-virtual/range {v28 .. v29}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v28

    move-object/from16 v0, v28

    move/from16 v1, v21

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v28

    const-string v29, ")"

    invoke-virtual/range {v28 .. v29}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v28

    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v29

    invoke-virtual/range {v28 .. v29}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v28

    invoke-virtual/range {v28 .. v28}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v28

    invoke-static/range {v27 .. v28}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 450
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->putInt(II)Ljava/nio/ByteBuffer;

    .line 451
    add-int/lit8 v21, v21, 0x4

    .line 453
    const-string v27, "inavi3d_route"

    new-instance v28, Ljava/lang/StringBuilder;

    invoke-direct/range {v28 .. v28}, Ljava/lang/StringBuilder;-><init>()V

    const-string v29, "starty :: inbuf.getInt("

    invoke-virtual/range {v28 .. v29}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v28

    move-object/from16 v0, v28

    move/from16 v1, v21

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v28

    const-string v29, ")"

    invoke-virtual/range {v28 .. v29}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v28

    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v29

    invoke-virtual/range {v28 .. v29}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v28

    invoke-virtual/range {v28 .. v28}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v28

    invoke-static/range {v27 .. v28}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 454
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->putInt(II)Ljava/nio/ByteBuffer;

    .line 455
    add-int/lit8 v21, v21, 0x4

    .line 457
    const-string v27, "inavi3d_route"

    new-instance v28, Ljava/lang/StringBuilder;

    invoke-direct/range {v28 .. v28}, Ljava/lang/StringBuilder;-><init>()V

    const-string v29, "targetx :: inbuf.getInt("

    invoke-virtual/range {v28 .. v29}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v28

    move-object/from16 v0, v28

    move/from16 v1, v21

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v28

    const-string v29, ")"

    invoke-virtual/range {v28 .. v29}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v28

    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v29

    invoke-virtual/range {v28 .. v29}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v28

    invoke-virtual/range {v28 .. v28}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v28

    invoke-static/range {v27 .. v28}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 458
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->putInt(II)Ljava/nio/ByteBuffer;

    .line 459
    add-int/lit8 v21, v21, 0x4

    .line 461
    const-string v27, "inavi3d_route"

    new-instance v28, Ljava/lang/StringBuilder;

    invoke-direct/range {v28 .. v28}, Ljava/lang/StringBuilder;-><init>()V

    const-string v29, "targety :: inbuf.getInt("

    invoke-virtual/range {v28 .. v29}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v28

    move-object/from16 v0, v28

    move/from16 v1, v21

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v28

    const-string v29, ")"

    invoke-virtual/range {v28 .. v29}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v28

    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v29

    invoke-virtual/range {v28 .. v29}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v28

    invoke-virtual/range {v28 .. v28}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v28

    invoke-static/range {v27 .. v28}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 462
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->putInt(II)Ljava/nio/ByteBuffer;

    .line 463
    add-int/lit8 v21, v21, 0x4

    .line 465
    const-string v27, "inavi3d_route"

    new-instance v28, Ljava/lang/StringBuilder;

    invoke-direct/range {v28 .. v28}, Ljava/lang/StringBuilder;-><init>()V

    const-string v29, "route1_x :: inbuf.getInt("

    invoke-virtual/range {v28 .. v29}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v28

    move-object/from16 v0, v28

    move/from16 v1, v21

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v28

    const-string v29, ")"

    invoke-virtual/range {v28 .. v29}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v28

    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v29

    invoke-virtual/range {v28 .. v29}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v28

    invoke-virtual/range {v28 .. v28}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v28

    invoke-static/range {v27 .. v28}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 466
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->putInt(II)Ljava/nio/ByteBuffer;

    .line 467
    add-int/lit8 v21, v21, 0x4

    .line 469
    const-string v27, "inavi3d_route"

    new-instance v28, Ljava/lang/StringBuilder;

    invoke-direct/range {v28 .. v28}, Ljava/lang/StringBuilder;-><init>()V

    const-string v29, "route1_y :: inbuf.getInt("

    invoke-virtual/range {v28 .. v29}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v28

    move-object/from16 v0, v28

    move/from16 v1, v21

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v28

    const-string v29, ")"

    invoke-virtual/range {v28 .. v29}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v28

    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v29

    invoke-virtual/range {v28 .. v29}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v28

    invoke-virtual/range {v28 .. v28}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v28

    invoke-static/range {v27 .. v28}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 470
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->putInt(II)Ljava/nio/ByteBuffer;

    .line 471
    add-int/lit8 v21, v21, 0x4

    .line 473
    const-string v27, "inavi3d_route"

    new-instance v28, Ljava/lang/StringBuilder;

    invoke-direct/range {v28 .. v28}, Ljava/lang/StringBuilder;-><init>()V

    const-string v29, "route2_x :: inbuf.getInt("

    invoke-virtual/range {v28 .. v29}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v28

    move-object/from16 v0, v28

    move/from16 v1, v21

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v28

    const-string v29, ")"

    invoke-virtual/range {v28 .. v29}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v28

    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v29

    invoke-virtual/range {v28 .. v29}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v28

    invoke-virtual/range {v28 .. v28}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v28

    invoke-static/range {v27 .. v28}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 474
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->putInt(II)Ljava/nio/ByteBuffer;

    .line 475
    add-int/lit8 v21, v21, 0x4

    .line 477
    const-string v27, "inavi3d_route"

    new-instance v28, Ljava/lang/StringBuilder;

    invoke-direct/range {v28 .. v28}, Ljava/lang/StringBuilder;-><init>()V

    const-string v29, "route2_y :: inbuf.getInt("

    invoke-virtual/range {v28 .. v29}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v28

    move-object/from16 v0, v28

    move/from16 v1, v21

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v28

    const-string v29, ")"

    invoke-virtual/range {v28 .. v29}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v28

    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v29

    invoke-virtual/range {v28 .. v29}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v28

    invoke-virtual/range {v28 .. v28}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v28

    invoke-static/range {v27 .. v28}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 478
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->putInt(II)Ljava/nio/ByteBuffer;

    .line 479
    add-int/lit8 v21, v21, 0x4

    .line 481
    const-string v27, "inavi3d_route"

    new-instance v28, Ljava/lang/StringBuilder;

    invoke-direct/range {v28 .. v28}, Ljava/lang/StringBuilder;-><init>()V

    const-string v29, "route3_x :: inbuf.getInt("

    invoke-virtual/range {v28 .. v29}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v28

    move-object/from16 v0, v28

    move/from16 v1, v21

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v28

    const-string v29, ")"

    invoke-virtual/range {v28 .. v29}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v28

    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v29

    invoke-virtual/range {v28 .. v29}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v28

    invoke-virtual/range {v28 .. v28}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v28

    invoke-static/range {v27 .. v28}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 482
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->putInt(II)Ljava/nio/ByteBuffer;

    .line 483
    add-int/lit8 v21, v21, 0x4

    .line 485
    const-string v27, "inavi3d_route"

    new-instance v28, Ljava/lang/StringBuilder;

    invoke-direct/range {v28 .. v28}, Ljava/lang/StringBuilder;-><init>()V

    const-string v29, "route3_y :: inbuf.getInt("

    invoke-virtual/range {v28 .. v29}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v28

    move-object/from16 v0, v28

    move/from16 v1, v21

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v28

    const-string v29, ")"

    invoke-virtual/range {v28 .. v29}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v28

    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v29

    invoke-virtual/range {v28 .. v29}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v28

    invoke-virtual/range {v28 .. v28}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v28

    invoke-static/range {v27 .. v28}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 486
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->putInt(II)Ljava/nio/ByteBuffer;

    .line 487
    add-int/lit8 v21, v21, 0x4

    .line 489
    const-string v27, "inavi3d_route"

    new-instance v28, Ljava/lang/StringBuilder;

    invoke-direct/range {v28 .. v28}, Ljava/lang/StringBuilder;-><init>()V

    const-string v29, "route4_x :: inbuf.getInt("

    invoke-virtual/range {v28 .. v29}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v28

    move-object/from16 v0, v28

    move/from16 v1, v21

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v28

    const-string v29, ")"

    invoke-virtual/range {v28 .. v29}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v28

    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v29

    invoke-virtual/range {v28 .. v29}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v28

    invoke-virtual/range {v28 .. v28}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v28

    invoke-static/range {v27 .. v28}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 490
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->putInt(II)Ljava/nio/ByteBuffer;

    .line 491
    add-int/lit8 v21, v21, 0x4

    .line 493
    const-string v27, "inavi3d_route"

    new-instance v28, Ljava/lang/StringBuilder;

    invoke-direct/range {v28 .. v28}, Ljava/lang/StringBuilder;-><init>()V

    const-string v29, "route4_y :: inbuf.getInt("

    invoke-virtual/range {v28 .. v29}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v28

    move-object/from16 v0, v28

    move/from16 v1, v21

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v28

    const-string v29, ")"

    invoke-virtual/range {v28 .. v29}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v28

    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v29

    invoke-virtual/range {v28 .. v29}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v28

    invoke-virtual/range {v28 .. v28}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v28

    invoke-static/range {v27 .. v28}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 494
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->putInt(II)Ljava/nio/ByteBuffer;

    .line 495
    add-int/lit8 v21, v21, 0x4

    .line 497
    const-string v27, "inavi3d_route"

    new-instance v28, Ljava/lang/StringBuilder;

    invoke-direct/range {v28 .. v28}, Ljava/lang/StringBuilder;-><init>()V

    const-string v29, "route5_x :: inbuf.getInt("

    invoke-virtual/range {v28 .. v29}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v28

    move-object/from16 v0, v28

    move/from16 v1, v21

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v28

    const-string v29, ")"

    invoke-virtual/range {v28 .. v29}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v28

    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v29

    invoke-virtual/range {v28 .. v29}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v28

    invoke-virtual/range {v28 .. v28}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v28

    invoke-static/range {v27 .. v28}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 498
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->putInt(II)Ljava/nio/ByteBuffer;

    .line 499
    add-int/lit8 v21, v21, 0x4

    .line 501
    const-string v27, "inavi3d_route"

    new-instance v28, Ljava/lang/StringBuilder;

    invoke-direct/range {v28 .. v28}, Ljava/lang/StringBuilder;-><init>()V

    const-string v29, "route5_y :: inbuf.getInt("

    invoke-virtual/range {v28 .. v29}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v28

    move-object/from16 v0, v28

    move/from16 v1, v21

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v28

    const-string v29, ")"

    invoke-virtual/range {v28 .. v29}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v28

    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v29

    invoke-virtual/range {v28 .. v29}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v28

    invoke-virtual/range {v28 .. v28}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v28

    invoke-static/range {v27 .. v28}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 502
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->putInt(II)Ljava/nio/ByteBuffer;

    .line 503
    add-int/lit8 v21, v21, 0x4

    .line 505
    move/from16 v0, v21

    invoke-virtual {v7, v0}, Ljava/nio/ByteBuffer;->position(I)Ljava/nio/Buffer;

    .line 506
    const/16 v27, 0x28

    move-object/from16 v0, p1

    move/from16 v1, v21

    move/from16 v2, v27

    invoke-virtual {v7, v0, v1, v2}, Ljava/nio/ByteBuffer;->put([BII)Ljava/nio/ByteBuffer;

    .line 507
    add-int/lit8 v21, v21, 0x28

    .line 509
    move/from16 v0, v21

    invoke-virtual {v7, v0}, Ljava/nio/ByteBuffer;->position(I)Ljava/nio/Buffer;

    .line 510
    const/16 v27, 0x28

    move-object/from16 v0, p1

    move/from16 v1, v21

    move/from16 v2, v27

    invoke-virtual {v7, v0, v1, v2}, Ljava/nio/ByteBuffer;->put([BII)Ljava/nio/ByteBuffer;

    .line 511
    add-int/lit8 v21, v21, 0x28

    .line 513
    move/from16 v0, v21

    invoke-virtual {v7, v0}, Ljava/nio/ByteBuffer;->position(I)Ljava/nio/Buffer;

    .line 514
    const/16 v27, 0x28

    move-object/from16 v0, p1

    move/from16 v1, v21

    move/from16 v2, v27

    invoke-virtual {v7, v0, v1, v2}, Ljava/nio/ByteBuffer;->put([BII)Ljava/nio/ByteBuffer;

    .line 515
    add-int/lit8 v21, v21, 0x28

    .line 517
    move/from16 v0, v21

    invoke-virtual {v7, v0}, Ljava/nio/ByteBuffer;->position(I)Ljava/nio/Buffer;

    .line 518
    const/16 v27, 0x28

    move-object/from16 v0, p1

    move/from16 v1, v21

    move/from16 v2, v27

    invoke-virtual {v7, v0, v1, v2}, Ljava/nio/ByteBuffer;->put([BII)Ljava/nio/ByteBuffer;

    .line 519
    add-int/lit8 v21, v21, 0x28

    .line 521
    move/from16 v0, v21

    invoke-virtual {v7, v0}, Ljava/nio/ByteBuffer;->position(I)Ljava/nio/Buffer;

    .line 522
    const/16 v27, 0x28

    move-object/from16 v0, p1

    move/from16 v1, v21

    move/from16 v2, v27

    invoke-virtual {v7, v0, v1, v2}, Ljava/nio/ByteBuffer;->put([BII)Ljava/nio/ByteBuffer;

    .line 523
    add-int/lit8 v21, v21, 0x28

    .line 525
    move/from16 v0, v21

    invoke-virtual {v7, v0}, Ljava/nio/ByteBuffer;->position(I)Ljava/nio/Buffer;

    .line 526
    const/16 v27, 0x28

    move-object/from16 v0, p1

    move/from16 v1, v21

    move/from16 v2, v27

    invoke-virtual {v7, v0, v1, v2}, Ljava/nio/ByteBuffer;->put([BII)Ljava/nio/ByteBuffer;

    .line 527
    add-int/lit8 v21, v21, 0x28

    .line 529
    move/from16 v0, v21

    invoke-virtual {v7, v0}, Ljava/nio/ByteBuffer;->position(I)Ljava/nio/Buffer;

    .line 530
    const/16 v27, 0x28

    move-object/from16 v0, p1

    move/from16 v1, v21

    move/from16 v2, v27

    invoke-virtual {v7, v0, v1, v2}, Ljava/nio/ByteBuffer;->put([BII)Ljava/nio/ByteBuffer;

    .line 531
    add-int/lit8 v21, v21, 0x28

    .line 533
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->putInt(II)Ljava/nio/ByteBuffer;

    .line 534
    add-int/lit8 v21, v21, 0x4

    .line 536
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->putInt(II)Ljava/nio/ByteBuffer;

    .line 537
    add-int/lit8 v21, v21, 0x4

    .line 539
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->putInt(II)Ljava/nio/ByteBuffer;

    .line 540
    add-int/lit8 v21, v21, 0x4

    .line 542
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->putInt(II)Ljava/nio/ByteBuffer;

    .line 543
    add-int/lit8 v21, v21, 0x4

    .line 545
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->putInt(II)Ljava/nio/ByteBuffer;

    .line 546
    add-int/lit8 v21, v21, 0x4

    .line 548
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->putInt(II)Ljava/nio/ByteBuffer;

    .line 549
    add-int/lit8 v21, v21, 0x4

    .line 551
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->putInt(II)Ljava/nio/ByteBuffer;

    .line 552
    add-int/lit8 v21, v21, 0x4

    .line 554
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->putInt(II)Ljava/nio/ByteBuffer;

    .line 555
    add-int/lit8 v21, v21, 0x4

    .line 557
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->putInt(II)Ljava/nio/ByteBuffer;

    .line 558
    add-int/lit8 v21, v21, 0x4

    .line 561
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->putInt(II)Ljava/nio/ByteBuffer;

    .line 562
    add-int/lit8 v21, v21, 0x4

    .line 564
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->putInt(II)Ljava/nio/ByteBuffer;

    .line 565
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v27

    move-object/from16 v0, p0

    move/from16 v1, v27

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/inavi3d/liveroute/ControlRouteTable;->little2big(I)I

    move-result v17

    .line 566
    add-int/lit8 v21, v21, 0x4

    .line 568
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->putInt(II)Ljava/nio/ByteBuffer;

    .line 569
    add-int/lit8 v21, v21, 0x4

    .line 571
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->putInt(II)Ljava/nio/ByteBuffer;

    .line 572
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v27

    move-object/from16 v0, p0

    move/from16 v1, v27

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/inavi3d/liveroute/ControlRouteTable;->little2big(I)I

    move-result v15

    .line 573
    add-int/lit8 v21, v21, 0x4

    .line 575
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->putInt(II)Ljava/nio/ByteBuffer;

    .line 576
    add-int/lit8 v21, v21, 0x4

    .line 578
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->putInt(II)Ljava/nio/ByteBuffer;

    .line 579
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v27

    move-object/from16 v0, p0

    move/from16 v1, v27

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/inavi3d/liveroute/ControlRouteTable;->little2big(I)I

    move-result v18

    .line 580
    add-int/lit8 v21, v21, 0x4

    .line 582
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->putInt(II)Ljava/nio/ByteBuffer;

    .line 583
    add-int/lit8 v21, v21, 0x4

    .line 585
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->putInt(II)Ljava/nio/ByteBuffer;

    .line 586
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v27

    move-object/from16 v0, p0

    move/from16 v1, v27

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/inavi3d/liveroute/ControlRouteTable;->little2big(I)I

    move-result v26

    .line 587
    add-int/lit8 v21, v21, 0x4

    .line 589
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->putInt(II)Ljava/nio/ByteBuffer;

    .line 590
    add-int/lit8 v21, v21, 0x4

    .line 592
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->putInt(II)Ljava/nio/ByteBuffer;

    .line 593
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v27

    move-object/from16 v0, p0

    move/from16 v1, v27

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/inavi3d/liveroute/ControlRouteTable;->little2big(I)I

    move-result v16

    .line 594
    add-int/lit8 v21, v21, 0x4

    .line 596
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->putInt(II)Ljava/nio/ByteBuffer;

    .line 597
    add-int/lit8 v21, v21, 0x4

    .line 599
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->putInt(II)Ljava/nio/ByteBuffer;

    .line 600
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v27

    move-object/from16 v0, p0

    move/from16 v1, v27

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/inavi3d/liveroute/ControlRouteTable;->little2big(I)I

    move-result v12

    .line 601
    add-int/lit8 v21, v21, 0x4

    .line 603
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->putInt(II)Ljava/nio/ByteBuffer;

    .line 604
    add-int/lit8 v21, v21, 0x4

    .line 606
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->putInt(II)Ljava/nio/ByteBuffer;

    .line 607
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v27

    move-object/from16 v0, p0

    move/from16 v1, v27

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/inavi3d/liveroute/ControlRouteTable;->little2big(I)I

    move-result v10

    .line 608
    add-int/lit8 v21, v21, 0x4

    .line 610
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->putInt(II)Ljava/nio/ByteBuffer;

    .line 611
    add-int/lit8 v21, v21, 0x4

    .line 613
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->putInt(II)Ljava/nio/ByteBuffer;

    .line 614
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v27

    move-object/from16 v0, p0

    move/from16 v1, v27

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/inavi3d/liveroute/ControlRouteTable;->little2big(I)I

    move-result v8

    .line 615
    add-int/lit8 v21, v21, 0x4

    .line 617
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->putInt(II)Ljava/nio/ByteBuffer;

    .line 618
    add-int/lit8 v21, v21, 0x4

    .line 620
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->putInt(II)Ljava/nio/ByteBuffer;

    .line 621
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v27

    move-object/from16 v0, p0

    move/from16 v1, v27

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/inavi3d/liveroute/ControlRouteTable;->little2big(I)I

    move-result v4

    .line 622
    add-int/lit8 v21, v21, 0x4

    .line 624
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->putInt(II)Ljava/nio/ByteBuffer;

    .line 625
    add-int/lit8 v21, v21, 0x4

    .line 627
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->putInt(II)Ljava/nio/ByteBuffer;

    .line 628
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v27

    move-object/from16 v0, p0

    move/from16 v1, v27

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/inavi3d/liveroute/ControlRouteTable;->little2big(I)I

    move-result v5

    .line 629
    add-int/lit8 v21, v21, 0x4

    .line 631
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->putInt(II)Ljava/nio/ByteBuffer;

    .line 632
    add-int/lit8 v21, v21, 0x4

    .line 634
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->putInt(II)Ljava/nio/ByteBuffer;

    .line 635
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v27

    move-object/from16 v0, p0

    move/from16 v1, v27

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/inavi3d/liveroute/ControlRouteTable;->little2big(I)I

    move-result v25

    .line 636
    add-int/lit8 v21, v21, 0x4

    .line 639
    const/4 v13, 0x0

    :goto_3
    move/from16 v0, v17

    if-ge v13, v0, :cond_7

    .line 642
    add-int/lit8 v27, v21, 0x1

    move/from16 v0, v27

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    .line 643
    add-int/lit8 v27, v21, 0x1

    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v28

    move/from16 v0, v27

    move/from16 v1, v28

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    .line 644
    add-int/lit8 v21, v21, 0x2

    .line 647
    add-int/lit8 v27, v21, 0x1

    move/from16 v0, v27

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    .line 648
    add-int/lit8 v27, v21, 0x1

    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v28

    move/from16 v0, v27

    move/from16 v1, v28

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    .line 649
    add-int/lit8 v21, v21, 0x2

    .line 651
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->putInt(II)Ljava/nio/ByteBuffer;

    .line 652
    add-int/lit8 v21, v21, 0x4

    .line 639
    add-int/lit8 v13, v13, 0x1

    goto :goto_3

    .line 417
    .end local v22    # "optionName":Ljava/lang/String;
    :cond_2
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->putInt(II)Ljava/nio/ByteBuffer;

    goto/16 :goto_1

    .line 427
    .restart local v22    # "optionName":Ljava/lang/String;
    :cond_3
    invoke-virtual/range {v22 .. v22}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v27

    const-string v28, "real_traffic_freeroad"

    invoke-virtual/range {v27 .. v28}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v27

    const/16 v28, 0x1

    move/from16 v0, v27

    move/from16 v1, v28

    if-ne v0, v1, :cond_4

    .line 428
    const-string v22, "real_traffic1_freeroad"

    .line 429
    move/from16 v0, v21

    invoke-virtual {v7, v0}, Ljava/nio/ByteBuffer;->position(I)Ljava/nio/Buffer;

    .line 430
    invoke-virtual/range {v22 .. v22}, Ljava/lang/String;->getBytes()[B

    move-result-object v27

    move-object/from16 v0, v27

    invoke-virtual {v7, v0}, Ljava/nio/ByteBuffer;->put([B)Ljava/nio/ByteBuffer;

    goto/16 :goto_2

    .line 431
    :cond_4
    invoke-virtual/range {v22 .. v22}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v27

    const-string v28, "real_traffic2"

    invoke-virtual/range {v27 .. v28}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v27

    const/16 v28, 0x1

    move/from16 v0, v27

    move/from16 v1, v28

    if-ne v0, v1, :cond_5

    .line 432
    const-string v22, "real_traffic3"

    .line 433
    move/from16 v0, v21

    invoke-virtual {v7, v0}, Ljava/nio/ByteBuffer;->position(I)Ljava/nio/Buffer;

    .line 434
    invoke-virtual/range {v22 .. v22}, Ljava/lang/String;->getBytes()[B

    move-result-object v27

    move-object/from16 v0, v27

    invoke-virtual {v7, v0}, Ljava/nio/ByteBuffer;->put([B)Ljava/nio/ByteBuffer;

    goto/16 :goto_2

    .line 435
    :cond_5
    invoke-virtual/range {v22 .. v22}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v27

    const-string v28, "real_traffic2_freeroad"

    invoke-virtual/range {v27 .. v28}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v27

    const/16 v28, 0x1

    move/from16 v0, v27

    move/from16 v1, v28

    if-ne v0, v1, :cond_6

    .line 436
    const-string v22, "real_traffic3_freeroad"

    .line 437
    move/from16 v0, v21

    invoke-virtual {v7, v0}, Ljava/nio/ByteBuffer;->position(I)Ljava/nio/Buffer;

    .line 438
    invoke-virtual/range {v22 .. v22}, Ljava/lang/String;->getBytes()[B

    move-result-object v27

    move-object/from16 v0, v27

    invoke-virtual {v7, v0}, Ljava/nio/ByteBuffer;->put([B)Ljava/nio/ByteBuffer;

    goto/16 :goto_2

    .line 440
    :cond_6
    move/from16 v0, v21

    invoke-virtual {v7, v0}, Ljava/nio/ByteBuffer;->position(I)Ljava/nio/Buffer;

    .line 441
    const/16 v27, 0x28

    move-object/from16 v0, p1

    move/from16 v1, v21

    move/from16 v2, v27

    invoke-virtual {v7, v0, v1, v2}, Ljava/nio/ByteBuffer;->put([BII)Ljava/nio/ByteBuffer;

    goto/16 :goto_2

    .line 656
    :cond_7
    const/4 v13, 0x0

    :goto_4
    if-ge v13, v15, :cond_8

    .line 659
    add-int/lit8 v27, v21, 0x1

    move/from16 v0, v27

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    .line 660
    add-int/lit8 v27, v21, 0x1

    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v28

    move/from16 v0, v27

    move/from16 v1, v28

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    .line 661
    add-int/lit8 v21, v21, 0x2

    .line 664
    add-int/lit8 v27, v21, 0x1

    move/from16 v0, v27

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    .line 665
    add-int/lit8 v27, v21, 0x1

    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v28

    move/from16 v0, v27

    move/from16 v1, v28

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    .line 666
    add-int/lit8 v21, v21, 0x2

    .line 669
    add-int/lit8 v27, v21, 0x1

    move/from16 v0, v27

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    .line 670
    add-int/lit8 v27, v21, 0x1

    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v28

    move/from16 v0, v27

    move/from16 v1, v28

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    .line 671
    add-int/lit8 v21, v21, 0x2

    .line 674
    add-int/lit8 v27, v21, 0x1

    move/from16 v0, v27

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    .line 675
    add-int/lit8 v27, v21, 0x1

    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v28

    move/from16 v0, v27

    move/from16 v1, v28

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    .line 676
    add-int/lit8 v21, v21, 0x2

    .line 678
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->putInt(II)Ljava/nio/ByteBuffer;

    .line 679
    add-int/lit8 v21, v21, 0x4

    .line 681
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->putInt(II)Ljava/nio/ByteBuffer;

    .line 682
    add-int/lit8 v21, v21, 0x4

    .line 684
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->putInt(II)Ljava/nio/ByteBuffer;

    .line 685
    add-int/lit8 v21, v21, 0x4

    .line 687
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    .line 688
    add-int/lit8 v21, v21, 0x1

    .line 690
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    .line 691
    add-int/lit8 v21, v21, 0x1

    .line 693
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    .line 694
    add-int/lit8 v21, v21, 0x1

    .line 696
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    .line 697
    add-int/lit8 v21, v21, 0x1

    .line 699
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    .line 700
    add-int/lit8 v21, v21, 0x1

    .line 702
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    .line 703
    add-int/lit8 v21, v21, 0x1

    .line 705
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    .line 706
    add-int/lit8 v21, v21, 0x1

    .line 708
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    .line 709
    add-int/lit8 v21, v21, 0x1

    .line 656
    add-int/lit8 v13, v13, 0x1

    goto/16 :goto_4

    .line 713
    :cond_8
    const/4 v13, 0x0

    :goto_5
    move/from16 v0, v18

    if-ge v13, v0, :cond_9

    .line 716
    add-int/lit8 v27, v21, 0x1

    move/from16 v0, v27

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    .line 717
    add-int/lit8 v27, v21, 0x1

    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v28

    move/from16 v0, v27

    move/from16 v1, v28

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    .line 718
    add-int/lit8 v21, v21, 0x2

    .line 721
    add-int/lit8 v27, v21, 0x1

    move/from16 v0, v27

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    .line 722
    add-int/lit8 v27, v21, 0x1

    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v28

    move/from16 v0, v27

    move/from16 v1, v28

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    .line 723
    add-int/lit8 v21, v21, 0x2

    .line 725
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->putInt(II)Ljava/nio/ByteBuffer;

    .line 726
    add-int/lit8 v21, v21, 0x4

    .line 713
    add-int/lit8 v13, v13, 0x1

    goto :goto_5

    .line 729
    :cond_9
    const/4 v13, 0x0

    :goto_6
    move/from16 v0, v26

    if-ge v13, v0, :cond_a

    .line 731
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->putInt(II)Ljava/nio/ByteBuffer;

    .line 732
    add-int/lit8 v21, v21, 0x4

    .line 734
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->putInt(II)Ljava/nio/ByteBuffer;

    .line 735
    add-int/lit8 v21, v21, 0x4

    .line 729
    add-int/lit8 v13, v13, 0x1

    goto :goto_6

    .line 738
    :cond_a
    const/4 v13, 0x0

    :goto_7
    move/from16 v0, v16

    if-ge v13, v0, :cond_b

    .line 741
    add-int/lit8 v27, v21, 0x1

    move/from16 v0, v27

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    .line 742
    add-int/lit8 v27, v21, 0x1

    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v28

    move/from16 v0, v27

    move/from16 v1, v28

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    .line 743
    add-int/lit8 v21, v21, 0x2

    .line 746
    add-int/lit8 v27, v21, 0x1

    move/from16 v0, v27

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    .line 747
    add-int/lit8 v27, v21, 0x1

    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v28

    move/from16 v0, v27

    move/from16 v1, v28

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    .line 748
    add-int/lit8 v21, v21, 0x2

    .line 750
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->putInt(II)Ljava/nio/ByteBuffer;

    .line 751
    add-int/lit8 v21, v21, 0x4

    .line 738
    add-int/lit8 v13, v13, 0x1

    goto :goto_7

    .line 754
    :cond_b
    const/4 v13, 0x0

    :goto_8
    if-ge v13, v12, :cond_c

    .line 757
    add-int/lit8 v27, v21, 0x1

    move/from16 v0, v27

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    .line 758
    add-int/lit8 v27, v21, 0x1

    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v28

    move/from16 v0, v27

    move/from16 v1, v28

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    .line 759
    add-int/lit8 v21, v21, 0x2

    .line 762
    add-int/lit8 v27, v21, 0x1

    move/from16 v0, v27

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    .line 763
    add-int/lit8 v27, v21, 0x1

    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v28

    move/from16 v0, v27

    move/from16 v1, v28

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    .line 764
    add-int/lit8 v21, v21, 0x2

    .line 767
    add-int/lit8 v27, v21, 0x1

    move/from16 v0, v27

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    .line 768
    add-int/lit8 v27, v21, 0x1

    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v28

    move/from16 v0, v27

    move/from16 v1, v28

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    .line 769
    add-int/lit8 v21, v21, 0x2

    .line 771
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    .line 772
    add-int/lit8 v21, v21, 0x1

    .line 774
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    .line 775
    add-int/lit8 v21, v21, 0x1

    .line 754
    add-int/lit8 v13, v13, 0x1

    goto/16 :goto_8

    .line 778
    :cond_c
    const/4 v13, 0x0

    :goto_9
    if-ge v13, v10, :cond_d

    .line 781
    add-int/lit8 v27, v21, 0x1

    move/from16 v0, v27

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    .line 782
    add-int/lit8 v27, v21, 0x1

    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v28

    move/from16 v0, v27

    move/from16 v1, v28

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    .line 783
    add-int/lit8 v21, v21, 0x2

    .line 786
    add-int/lit8 v27, v21, 0x1

    move/from16 v0, v27

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    .line 787
    add-int/lit8 v27, v21, 0x1

    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v28

    move/from16 v0, v27

    move/from16 v1, v28

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    .line 788
    add-int/lit8 v21, v21, 0x2

    .line 791
    add-int/lit8 v27, v21, 0x1

    move/from16 v0, v27

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    .line 792
    add-int/lit8 v27, v21, 0x1

    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v28

    move/from16 v0, v27

    move/from16 v1, v28

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    .line 793
    add-int/lit8 v21, v21, 0x2

    .line 778
    add-int/lit8 v13, v13, 0x1

    goto :goto_9

    .line 796
    :cond_d
    const/4 v13, 0x0

    :goto_a
    if-ge v13, v8, :cond_f

    .line 799
    add-int/lit8 v27, v21, 0x1

    move/from16 v0, v27

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    .line 800
    add-int/lit8 v27, v21, 0x1

    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v28

    move/from16 v0, v27

    move/from16 v1, v28

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    .line 801
    add-int/lit8 v21, v21, 0x2

    .line 803
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    .line 804
    add-int/lit8 v21, v21, 0x1

    .line 806
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    .line 807
    add-int/lit8 v21, v21, 0x1

    .line 809
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->putInt(II)Ljava/nio/ByteBuffer;

    .line 810
    add-int/lit8 v21, v21, 0x4

    .line 812
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->putInt(II)Ljava/nio/ByteBuffer;

    .line 813
    add-int/lit8 v21, v21, 0x4

    .line 815
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->putInt(II)Ljava/nio/ByteBuffer;

    .line 816
    add-int/lit8 v21, v21, 0x4

    .line 818
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->putInt(II)Ljava/nio/ByteBuffer;

    .line 819
    add-int/lit8 v21, v21, 0x4

    .line 821
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->putInt(II)Ljava/nio/ByteBuffer;

    .line 822
    add-int/lit8 v21, v21, 0x4

    .line 824
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->putInt(II)Ljava/nio/ByteBuffer;

    .line 825
    add-int/lit8 v21, v21, 0x4

    .line 827
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->putInt(II)Ljava/nio/ByteBuffer;

    .line 828
    add-int/lit8 v21, v21, 0x4

    .line 832
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->putInt(II)Ljava/nio/ByteBuffer;

    .line 833
    add-int/lit8 v21, v21, 0x4

    .line 835
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->putInt(II)Ljava/nio/ByteBuffer;

    .line 836
    add-int/lit8 v21, v21, 0x4

    .line 838
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->putInt(II)Ljava/nio/ByteBuffer;

    .line 839
    add-int/lit8 v21, v21, 0x4

    .line 841
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->putInt(II)Ljava/nio/ByteBuffer;

    .line 842
    add-int/lit8 v21, v21, 0x4

    .line 844
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->putInt(II)Ljava/nio/ByteBuffer;

    .line 845
    add-int/lit8 v21, v21, 0x4

    .line 847
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->putInt(II)Ljava/nio/ByteBuffer;

    .line 848
    add-int/lit8 v21, v21, 0x4

    .line 850
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->putInt(II)Ljava/nio/ByteBuffer;

    .line 851
    add-int/lit8 v21, v21, 0x4

    .line 853
    move/from16 v0, v21

    invoke-virtual {v7, v0}, Ljava/nio/ByteBuffer;->position(I)Ljava/nio/Buffer;

    .line 854
    const/16 v27, 0x28

    move-object/from16 v0, p1

    move/from16 v1, v21

    move/from16 v2, v27

    invoke-virtual {v7, v0, v1, v2}, Ljava/nio/ByteBuffer;->put([BII)Ljava/nio/ByteBuffer;

    .line 855
    add-int/lit8 v21, v21, 0x28

    .line 857
    const/16 v19, 0x0

    .local v19, "n":I
    :goto_b
    const/16 v27, 0x6

    move/from16 v0, v19

    move/from16 v1, v27

    if-ge v0, v1, :cond_e

    .line 859
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->putInt(II)Ljava/nio/ByteBuffer;

    .line 860
    add-int/lit8 v21, v21, 0x4

    .line 862
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->putInt(II)Ljava/nio/ByteBuffer;

    .line 863
    add-int/lit8 v21, v21, 0x4

    .line 865
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->putInt(II)Ljava/nio/ByteBuffer;

    .line 866
    add-int/lit8 v21, v21, 0x4

    .line 868
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->putInt(II)Ljava/nio/ByteBuffer;

    .line 869
    add-int/lit8 v21, v21, 0x4

    .line 871
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->putInt(II)Ljava/nio/ByteBuffer;

    .line 872
    add-int/lit8 v21, v21, 0x4

    .line 874
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->putInt(II)Ljava/nio/ByteBuffer;

    .line 875
    add-int/lit8 v21, v21, 0x4

    .line 878
    add-int/lit8 v27, v21, 0x1

    move/from16 v0, v27

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    .line 879
    add-int/lit8 v27, v21, 0x1

    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v28

    move/from16 v0, v27

    move/from16 v1, v28

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    .line 880
    add-int/lit8 v21, v21, 0x2

    .line 882
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    .line 883
    add-int/lit8 v21, v21, 0x1

    .line 885
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    .line 886
    add-int/lit8 v21, v21, 0x1

    .line 857
    add-int/lit8 v19, v19, 0x1

    goto/16 :goto_b

    .line 891
    :cond_e
    add-int/lit8 v27, v21, 0x1

    move/from16 v0, v27

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    .line 892
    add-int/lit8 v27, v21, 0x1

    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v28

    move/from16 v0, v27

    move/from16 v1, v28

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    .line 893
    add-int/lit8 v21, v21, 0x2

    .line 896
    add-int/lit8 v27, v21, 0x1

    move/from16 v0, v27

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    .line 897
    add-int/lit8 v27, v21, 0x1

    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v28

    move/from16 v0, v27

    move/from16 v1, v28

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    .line 898
    add-int/lit8 v21, v21, 0x2

    .line 901
    add-int/lit8 v27, v21, 0x1

    move/from16 v0, v27

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    .line 902
    add-int/lit8 v27, v21, 0x1

    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v28

    move/from16 v0, v27

    move/from16 v1, v28

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    .line 903
    add-int/lit8 v21, v21, 0x2

    .line 906
    add-int/lit8 v27, v21, 0x1

    move/from16 v0, v27

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    .line 907
    add-int/lit8 v27, v21, 0x1

    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v28

    move/from16 v0, v27

    move/from16 v1, v28

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    .line 908
    add-int/lit8 v21, v21, 0x2

    .line 911
    add-int/lit8 v27, v21, 0x1

    move/from16 v0, v27

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    .line 912
    add-int/lit8 v27, v21, 0x1

    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v28

    move/from16 v0, v27

    move/from16 v1, v28

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    .line 913
    add-int/lit8 v21, v21, 0x2

    .line 916
    add-int/lit8 v27, v21, 0x1

    move/from16 v0, v27

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    .line 917
    add-int/lit8 v27, v21, 0x1

    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v28

    move/from16 v0, v27

    move/from16 v1, v28

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    .line 918
    add-int/lit8 v21, v21, 0x2

    .line 796
    add-int/lit8 v13, v13, 0x1

    goto/16 :goto_a

    .line 922
    .end local v19    # "n":I
    :cond_f
    const/4 v13, 0x0

    :goto_c
    if-ge v13, v4, :cond_10

    .line 924
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->putInt(II)Ljava/nio/ByteBuffer;

    .line 925
    add-int/lit8 v21, v21, 0x4

    .line 928
    add-int/lit8 v27, v21, 0x1

    move/from16 v0, v27

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    .line 929
    add-int/lit8 v27, v21, 0x1

    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v28

    move/from16 v0, v27

    move/from16 v1, v28

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    .line 930
    add-int/lit8 v21, v21, 0x2

    .line 933
    add-int/lit8 v27, v21, 0x1

    move/from16 v0, v27

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    .line 934
    add-int/lit8 v27, v21, 0x1

    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v28

    move/from16 v0, v27

    move/from16 v1, v28

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    .line 935
    add-int/lit8 v21, v21, 0x2

    .line 937
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    .line 938
    add-int/lit8 v21, v21, 0x1

    .line 940
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    .line 941
    add-int/lit8 v21, v21, 0x1

    .line 943
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    .line 944
    add-int/lit8 v21, v21, 0x1

    .line 946
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    .line 947
    add-int/lit8 v21, v21, 0x1

    .line 922
    add-int/lit8 v13, v13, 0x1

    goto/16 :goto_c

    .line 950
    :cond_10
    const/4 v13, 0x0

    :goto_d
    if-ge v13, v5, :cond_11

    .line 952
    move/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v27

    move/from16 v0, v21

    move/from16 v1, v27

    invoke-virtual {v7, v0, v1}, Ljava/nio/ByteBuffer;->putInt(II)Ljava/nio/ByteBuffer;

    .line 953
    add-int/lit8 v21, v21, 0x4

    .line 950
    add-int/lit8 v13, v13, 0x1

    goto :goto_d

    .line 957
    :cond_11
    move/from16 v0, v21

    invoke-virtual {v7, v0}, Ljava/nio/ByteBuffer;->position(I)Ljava/nio/Buffer;

    .line 958
    move-object/from16 v0, p1

    move/from16 v1, v21

    move/from16 v2, v25

    invoke-virtual {v7, v0, v1, v2}, Ljava/nio/ByteBuffer;->put([BII)Ljava/nio/ByteBuffer;

    .line 959
    add-int v21, v21, v25

    .line 961
    invoke-virtual {v7}, Ljava/nio/ByteBuffer;->array()[B

    move-result-object v24

    .line 963
    move-object/from16 v0, p0

    move-object/from16 v1, v24

    invoke-direct {v0, v1}, Lcom/thinkware/sundo/inavi3d/liveroute/ControlRouteTable;->CheckSum([B)I

    move-result v27

    move/from16 v0, v27

    int-to-short v9, v0

    .line 964
    .local v9, "check_sum":S
    const/16 v27, 0x0

    and-int/lit16 v0, v9, 0xff

    move/from16 v28, v0

    move/from16 v0, v28

    int-to-byte v0, v0

    move/from16 v28, v0

    aput-byte v28, v24, v27

    .line 965
    const/16 v27, 0x1

    shr-int/lit8 v28, v9, 0x8

    move/from16 v0, v28

    and-int/lit16 v0, v0, 0xff

    move/from16 v28, v0

    move/from16 v0, v28

    int-to-byte v0, v0

    move/from16 v28, v0

    aput-byte v28, v24, v27

    move-object/from16 v27, v24

    .line 967
    goto/16 :goto_0
.end method

.method public get_errormsg()Ljava/lang/String;
    .locals 1

    .prologue
    .line 1071
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/liveroute/ControlRouteTable;->errormsg:Ljava/lang/String;

    return-object v0
.end method

.method public get_rdata()Ljava/lang/String;
    .locals 1

    .prologue
    .line 1070
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/liveroute/ControlRouteTable;->rdata:Ljava/lang/String;

    return-object v0
.end method

.method public get_rid()Ljava/lang/String;
    .locals 1

    .prologue
    .line 1068
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/liveroute/ControlRouteTable;->rid:Ljava/lang/String;

    return-object v0
.end method

.method public get_route_data()[B
    .locals 1

    .prologue
    .line 1072
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/liveroute/ControlRouteTable;->route_data:[B

    return-object v0
.end method

.method little2big(I)I
    .locals 2
    .param p1, "i"    # I

    .prologue
    .line 971
    and-int/lit16 v0, p1, 0xff

    shl-int/lit8 v0, v0, 0x18

    const v1, 0xff00

    and-int/2addr v1, p1

    shl-int/lit8 v1, v1, 0x8

    add-int/2addr v0, v1

    const/high16 v1, 0xff0000

    and-int/2addr v1, p1

    shr-int/lit8 v1, v1, 0x8

    add-int/2addr v0, v1

    shr-int/lit8 v1, p1, 0x18

    and-int/lit16 v1, v1, 0xff

    add-int/2addr v0, v1

    return v0
.end method

.method public make_param(Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;)Lorg/json/JSONObject;
    .locals 18
    .param p1, "item"    # Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;

    .prologue
    .line 53
    if-nez p1, :cond_0

    .line 54
    const/4 v8, 0x0

    .line 277
    :goto_0
    return-object v8

    .line 57
    :cond_0
    new-instance v8, Lorg/json/JSONObject;

    invoke-direct {v8}, Lorg/json/JSONObject;-><init>()V

    .line 59
    .local v8, "obj":Lorg/json/JSONObject;
    :try_start_0
    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->uuid:Ljava/lang/String;

    if-eqz v15, :cond_1

    const-string v16, "unknown"

    move-object/from16 v0, v16

    invoke-virtual {v15, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v16

    if-eqz v16, :cond_1

    const-string v15, "60003180"

    move-object/from16 v0, p1

    iput-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->uuid:Ljava/lang/String;

    :cond_1
    if-eqz v15, :cond_2

    const-string v15, "uuid"

    move-object/from16 v0, p1

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->uuid:Ljava/lang/String;

    move-object/from16 v16, v0

    move-object/from16 v0, v16

    invoke-virtual {v8, v15, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 60
    :cond_2
    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->oem:Ljava/lang/String;

    if-eqz v15, :cond_3

    const-string v15, "oem"

    move-object/from16 v0, p1

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->oem:Ljava/lang/String;

    move-object/from16 v16, v0

    move-object/from16 v0, v16

    invoke-virtual {v8, v15, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 62
    :cond_3
    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->requestInfo:Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;

    if-eqz v15, :cond_19

    .line 63
    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->requestInfo:Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;

    iget v15, v15, Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;->styp:I

    if-ltz v15, :cond_4

    const-string v15, "stype"

    new-instance v16, Ljava/lang/StringBuilder;

    invoke-direct/range {v16 .. v16}, Ljava/lang/StringBuilder;-><init>()V

    const-string v17, ""

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v16

    move-object/from16 v0, p1

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->requestInfo:Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;

    move-object/from16 v17, v0

    move-object/from16 v0, v17

    iget v0, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;->styp:I

    move/from16 v17, v0

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v16

    invoke-virtual/range {v16 .. v16}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v16

    move-object/from16 v0, v16

    invoke-virtual {v8, v15, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 64
    :cond_4
    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->requestInfo:Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;

    iget v15, v15, Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;->sopt1:I

    if-ltz v15, :cond_5

    .line 68
    const-string v15, "sopt1"

    new-instance v16, Ljava/lang/StringBuilder;

    invoke-direct/range {v16 .. v16}, Ljava/lang/StringBuilder;-><init>()V

    const-string v17, ""

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v16

    move-object/from16 v0, p1

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->requestInfo:Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;

    move-object/from16 v17, v0

    move-object/from16 v0, v17

    iget v0, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;->sopt1:I

    move/from16 v17, v0

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v16

    invoke-virtual/range {v16 .. v16}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v16

    move-object/from16 v0, v16

    invoke-virtual {v8, v15, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 71
    :cond_5
    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->requestInfo:Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;

    iget v15, v15, Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;->sopt2:I

    if-ltz v15, :cond_6

    const-string v15, "sopt2"

    new-instance v16, Ljava/lang/StringBuilder;

    invoke-direct/range {v16 .. v16}, Ljava/lang/StringBuilder;-><init>()V

    const-string v17, ""

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v16

    move-object/from16 v0, p1

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->requestInfo:Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;

    move-object/from16 v17, v0

    move-object/from16 v0, v17

    iget v0, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;->sopt2:I

    move/from16 v17, v0

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v16

    invoke-virtual/range {v16 .. v16}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v16

    move-object/from16 v0, v16

    invoke-virtual {v8, v15, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 72
    :cond_6
    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->requestInfo:Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;

    iget v15, v15, Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;->sopt3:I

    if-ltz v15, :cond_7

    const-string v15, "sopt3"

    new-instance v16, Ljava/lang/StringBuilder;

    invoke-direct/range {v16 .. v16}, Ljava/lang/StringBuilder;-><init>()V

    const-string v17, ""

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v16

    move-object/from16 v0, p1

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->requestInfo:Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;

    move-object/from16 v17, v0

    move-object/from16 v0, v17

    iget v0, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;->sopt3:I

    move/from16 v17, v0

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v16

    invoke-virtual/range {v16 .. v16}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v16

    move-object/from16 v0, v16

    invoke-virtual {v8, v15, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 73
    :cond_7
    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->requestInfo:Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;

    iget v15, v15, Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;->coordinate:I

    if-ltz v15, :cond_8

    const-string v15, "coordinate"

    new-instance v16, Ljava/lang/StringBuilder;

    invoke-direct/range {v16 .. v16}, Ljava/lang/StringBuilder;-><init>()V

    const-string v17, ""

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v16

    move-object/from16 v0, p1

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->requestInfo:Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;

    move-object/from16 v17, v0

    move-object/from16 v0, v17

    iget v0, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;->coordinate:I

    move/from16 v17, v0

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v16

    invoke-virtual/range {v16 .. v16}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v16

    move-object/from16 v0, v16

    invoke-virtual {v8, v15, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 74
    :cond_8
    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->requestInfo:Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;

    iget v15, v15, Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;->nameflag:I

    if-ltz v15, :cond_9

    const-string v15, "nameflag"

    new-instance v16, Ljava/lang/StringBuilder;

    invoke-direct/range {v16 .. v16}, Ljava/lang/StringBuilder;-><init>()V

    const-string v17, ""

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v16

    move-object/from16 v0, p1

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->requestInfo:Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;

    move-object/from16 v17, v0

    move-object/from16 v0, v17

    iget v0, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;->nameflag:I

    move/from16 v17, v0

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v16

    invoke-virtual/range {v16 .. v16}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v16

    move-object/from16 v0, v16

    invoke-virtual {v8, v15, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 77
    :cond_9
    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->requestInfo:Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;

    iget v15, v15, Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;->version:I

    if-ltz v15, :cond_a

    .line 78
    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->requestInfo:Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;

    iget v15, v15, Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;->version:I

    move-object/from16 v0, p0

    iput v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/ControlRouteTable;->mapVersion:I

    .line 80
    const-string v15, "version"

    invoke-direct/range {p0 .. p0}, Lcom/thinkware/sundo/inavi3d/liveroute/ControlRouteTable;->getMrVersion()Ljava/lang/String;

    move-result-object v16

    move-object/from16 v0, v16

    invoke-virtual {v8, v15, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 83
    :cond_a
    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->requestInfo:Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;

    iget v15, v15, Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;->restype:I

    if-ltz v15, :cond_b

    const-string v15, "restype"

    new-instance v16, Ljava/lang/StringBuilder;

    invoke-direct/range {v16 .. v16}, Ljava/lang/StringBuilder;-><init>()V

    const-string v17, ""

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v16

    move-object/from16 v0, p1

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->requestInfo:Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;

    move-object/from16 v17, v0

    move-object/from16 v0, v17

    iget v0, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;->restype:I

    move/from16 v17, v0

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v16

    invoke-virtual/range {v16 .. v16}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v16

    move-object/from16 v0, v16

    invoke-virtual {v8, v15, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 84
    :cond_b
    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->requestInfo:Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;

    iget v15, v15, Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;->maxroutesize:I

    if-ltz v15, :cond_c

    const-string v15, "maxroutesize"

    new-instance v16, Ljava/lang/StringBuilder;

    invoke-direct/range {v16 .. v16}, Ljava/lang/StringBuilder;-><init>()V

    const-string v17, ""

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v16

    move-object/from16 v0, p1

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->requestInfo:Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;

    move-object/from16 v17, v0

    move-object/from16 v0, v17

    iget v0, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;->maxroutesize:I

    move/from16 v17, v0

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v16

    invoke-virtual/range {v16 .. v16}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v16

    move-object/from16 v0, v16

    invoke-virtual {v8, v15, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 86
    :cond_c
    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->requestInfo:Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;

    iget v15, v15, Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;->dtype:I

    if-ltz v15, :cond_d

    const-string v15, "dtype"

    new-instance v16, Ljava/lang/StringBuilder;

    invoke-direct/range {v16 .. v16}, Ljava/lang/StringBuilder;-><init>()V

    const-string v17, ""

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v16

    move-object/from16 v0, p1

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->requestInfo:Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;

    move-object/from16 v17, v0

    move-object/from16 v0, v17

    iget v0, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;->dtype:I

    move/from16 v17, v0

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v16

    invoke-virtual/range {v16 .. v16}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v16

    move-object/from16 v0, v16

    invoke-virtual {v8, v15, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 88
    :cond_d
    const-string v15, "file_linkid"

    new-instance v16, Ljava/lang/StringBuilder;

    invoke-direct/range {v16 .. v16}, Ljava/lang/StringBuilder;-><init>()V

    const-string v17, ""

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v16

    move-object/from16 v0, p1

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->requestInfo:Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;

    move-object/from16 v17, v0

    move-object/from16 v0, v17

    iget v0, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;->file_linkid:I

    move/from16 v17, v0

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v16

    invoke-virtual/range {v16 .. v16}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v16

    move-object/from16 v0, v16

    invoke-virtual {v8, v15, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 89
    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->requestInfo:Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;

    iget-object v15, v15, Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;->rid:Ljava/lang/String;

    if-eqz v15, :cond_e

    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->requestInfo:Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;

    iget-object v15, v15, Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;->rid:Ljava/lang/String;

    invoke-virtual {v15}, Ljava/lang/String;->isEmpty()Z

    move-result v15

    if-nez v15, :cond_e

    const-string v15, "rid"

    new-instance v16, Ljava/lang/StringBuilder;

    invoke-direct/range {v16 .. v16}, Ljava/lang/StringBuilder;-><init>()V

    const-string v17, ""

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v16

    move-object/from16 v0, p1

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->requestInfo:Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;

    move-object/from16 v17, v0

    move-object/from16 v0, v17

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;->rid:Ljava/lang/String;

    move-object/from16 v17, v0

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v16

    invoke-virtual/range {v16 .. v16}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v16

    move-object/from16 v0, v16

    invoke-virtual {v8, v15, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 90
    :cond_e
    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->requestInfo:Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;

    iget v15, v15, Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;->remain_time:I

    if-ltz v15, :cond_f

    const-string v15, "remain_time"

    new-instance v16, Ljava/lang/StringBuilder;

    invoke-direct/range {v16 .. v16}, Ljava/lang/StringBuilder;-><init>()V

    const-string v17, ""

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v16

    move-object/from16 v0, p1

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->requestInfo:Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;

    move-object/from16 v17, v0

    move-object/from16 v0, v17

    iget v0, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;->remain_time:I

    move/from16 v17, v0

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v16

    invoke-virtual/range {v16 .. v16}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v16

    move-object/from16 v0, v16

    invoke-virtual {v8, v15, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 91
    :cond_f
    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->requestInfo:Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;

    iget v15, v15, Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;->remain_distance:I

    if-ltz v15, :cond_10

    const-string v15, "remain_distance"

    new-instance v16, Ljava/lang/StringBuilder;

    invoke-direct/range {v16 .. v16}, Ljava/lang/StringBuilder;-><init>()V

    const-string v17, ""

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v16

    move-object/from16 v0, p1

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->requestInfo:Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;

    move-object/from16 v17, v0

    move-object/from16 v0, v17

    iget v0, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;->remain_distance:I

    move/from16 v17, v0

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v16

    invoke-virtual/range {v16 .. v16}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v16

    move-object/from16 v0, v16

    invoke-virtual {v8, v15, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 92
    :cond_10
    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->requestInfo:Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;

    iget v15, v15, Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;->home_x:I

    if-ltz v15, :cond_11

    const-string v15, "home_x"

    new-instance v16, Ljava/lang/StringBuilder;

    invoke-direct/range {v16 .. v16}, Ljava/lang/StringBuilder;-><init>()V

    const-string v17, ""

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v16

    move-object/from16 v0, p1

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->requestInfo:Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;

    move-object/from16 v17, v0

    move-object/from16 v0, v17

    iget v0, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;->home_x:I

    move/from16 v17, v0

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v16

    invoke-virtual/range {v16 .. v16}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v16

    move-object/from16 v0, v16

    invoke-virtual {v8, v15, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 93
    :cond_11
    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->requestInfo:Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;

    iget v15, v15, Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;->home_y:I

    if-ltz v15, :cond_12

    const-string v15, "home_y"

    new-instance v16, Ljava/lang/StringBuilder;

    invoke-direct/range {v16 .. v16}, Ljava/lang/StringBuilder;-><init>()V

    const-string v17, ""

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v16

    move-object/from16 v0, p1

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->requestInfo:Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;

    move-object/from16 v17, v0

    move-object/from16 v0, v17

    iget v0, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;->home_y:I

    move/from16 v17, v0

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v16

    invoke-virtual/range {v16 .. v16}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v16

    move-object/from16 v0, v16

    invoke-virtual {v8, v15, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 94
    :cond_12
    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->requestInfo:Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;

    iget v15, v15, Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;->fav_x:I

    if-ltz v15, :cond_13

    const-string v15, "fav_x"

    new-instance v16, Ljava/lang/StringBuilder;

    invoke-direct/range {v16 .. v16}, Ljava/lang/StringBuilder;-><init>()V

    const-string v17, ""

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v16

    move-object/from16 v0, p1

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->requestInfo:Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;

    move-object/from16 v17, v0

    move-object/from16 v0, v17

    iget v0, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;->fav_x:I

    move/from16 v17, v0

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v16

    invoke-virtual/range {v16 .. v16}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v16

    move-object/from16 v0, v16

    invoke-virtual {v8, v15, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 95
    :cond_13
    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->requestInfo:Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;

    iget v15, v15, Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;->fav_y:I

    if-ltz v15, :cond_14

    const-string v15, "fav_y"

    new-instance v16, Ljava/lang/StringBuilder;

    invoke-direct/range {v16 .. v16}, Ljava/lang/StringBuilder;-><init>()V

    const-string v17, ""

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v16

    move-object/from16 v0, p1

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->requestInfo:Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;

    move-object/from16 v17, v0

    move-object/from16 v0, v17

    iget v0, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;->fav_y:I

    move/from16 v17, v0

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v16

    invoke-virtual/range {v16 .. v16}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v16

    move-object/from16 v0, v16

    invoke-virtual {v8, v15, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 96
    :cond_14
    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->requestInfo:Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;

    iget v15, v15, Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;->cur_admcode:I

    if-ltz v15, :cond_15

    const-string v15, "cur_admcode"

    new-instance v16, Ljava/lang/StringBuilder;

    invoke-direct/range {v16 .. v16}, Ljava/lang/StringBuilder;-><init>()V

    const-string v17, ""

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v16

    move-object/from16 v0, p1

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->requestInfo:Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;

    move-object/from16 v17, v0

    move-object/from16 v0, v17

    iget v0, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;->cur_admcode:I

    move/from16 v17, v0

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v16

    invoke-virtual/range {v16 .. v16}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v16

    move-object/from16 v0, v16

    invoke-virtual {v8, v15, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 97
    :cond_15
    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->requestInfo:Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;

    iget v15, v15, Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;->poi_admcode:I

    if-ltz v15, :cond_16

    const-string v15, "poi_admcode"

    new-instance v16, Ljava/lang/StringBuilder;

    invoke-direct/range {v16 .. v16}, Ljava/lang/StringBuilder;-><init>()V

    const-string v17, ""

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v16

    move-object/from16 v0, p1

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->requestInfo:Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;

    move-object/from16 v17, v0

    move-object/from16 v0, v17

    iget v0, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;->poi_admcode:I

    move/from16 v17, v0

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v16

    invoke-virtual/range {v16 .. v16}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v16

    move-object/from16 v0, v16

    invoke-virtual {v8, v15, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 98
    :cond_16
    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->requestInfo:Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;

    iget v15, v15, Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;->poi_catecode:I

    if-ltz v15, :cond_17

    const-string v15, "poi_catecode"

    new-instance v16, Ljava/lang/StringBuilder;

    invoke-direct/range {v16 .. v16}, Ljava/lang/StringBuilder;-><init>()V

    const-string v17, ""

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v16

    move-object/from16 v0, p1

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->requestInfo:Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;

    move-object/from16 v17, v0

    move-object/from16 v0, v17

    iget v0, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;->poi_catecode:I

    move/from16 v17, v0

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v16

    invoke-virtual/range {v16 .. v16}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v16

    move-object/from16 v0, v16

    invoke-virtual {v8, v15, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 99
    :cond_17
    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->requestInfo:Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;

    iget v15, v15, Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;->poi_name:I

    if-ltz v15, :cond_18

    const-string v15, "poi_name"

    new-instance v16, Ljava/lang/StringBuilder;

    invoke-direct/range {v16 .. v16}, Ljava/lang/StringBuilder;-><init>()V

    const-string v17, ""

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v16

    move-object/from16 v0, p1

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->requestInfo:Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;

    move-object/from16 v17, v0

    move-object/from16 v0, v17

    iget v0, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;->poi_name:I

    move/from16 v17, v0

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v16

    invoke-virtual/range {v16 .. v16}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v16

    move-object/from16 v0, v16

    invoke-virtual {v8, v15, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 100
    :cond_18
    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->requestInfo:Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;

    iget v15, v15, Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;->pid:I

    if-ltz v15, :cond_19

    const-string v15, "pid"

    new-instance v16, Ljava/lang/StringBuilder;

    invoke-direct/range {v16 .. v16}, Ljava/lang/StringBuilder;-><init>()V

    const-string v17, ""

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v16

    move-object/from16 v0, p1

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->requestInfo:Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;

    move-object/from16 v17, v0

    move-object/from16 v0, v17

    iget v0, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RequestInfo;->pid:I

    move/from16 v17, v0

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v16

    invoke-virtual/range {v16 .. v16}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v16

    move-object/from16 v0, v16

    invoke-virtual {v8, v15, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 103
    :cond_19
    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->strtloc:Lcom/thinkware/sundo/inavi3d/liveroute/LocInfo;

    if-eqz v15, :cond_1a

    .line 104
    new-instance v9, Lorg/json/JSONObject;

    invoke-direct {v9}, Lorg/json/JSONObject;-><init>()V

    .line 105
    .local v9, "tmp":Lorg/json/JSONObject;
    const-string v15, "lonx"

    new-instance v16, Ljava/lang/StringBuilder;

    invoke-direct/range {v16 .. v16}, Ljava/lang/StringBuilder;-><init>()V

    const-string v17, ""

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v16

    move-object/from16 v0, p1

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->strtloc:Lcom/thinkware/sundo/inavi3d/liveroute/LocInfo;

    move-object/from16 v17, v0

    move-object/from16 v0, v17

    iget v0, v0, Lcom/thinkware/sundo/inavi3d/liveroute/LocInfo;->lonx:I

    move/from16 v17, v0

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v16

    invoke-virtual/range {v16 .. v16}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v16

    move-object/from16 v0, v16

    invoke-virtual {v9, v15, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 106
    const-string v15, "laty"

    new-instance v16, Ljava/lang/StringBuilder;

    invoke-direct/range {v16 .. v16}, Ljava/lang/StringBuilder;-><init>()V

    const-string v17, ""

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v16

    move-object/from16 v0, p1

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->strtloc:Lcom/thinkware/sundo/inavi3d/liveroute/LocInfo;

    move-object/from16 v17, v0

    move-object/from16 v0, v17

    iget v0, v0, Lcom/thinkware/sundo/inavi3d/liveroute/LocInfo;->laty:I

    move/from16 v17, v0

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v16

    invoke-virtual/range {v16 .. v16}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v16

    move-object/from16 v0, v16

    invoke-virtual {v9, v15, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 107
    const-string v15, "name"

    new-instance v16, Ljava/lang/StringBuilder;

    invoke-direct/range {v16 .. v16}, Ljava/lang/StringBuilder;-><init>()V

    const-string v17, ""

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v16

    move-object/from16 v0, p1

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->strtloc:Lcom/thinkware/sundo/inavi3d/liveroute/LocInfo;

    move-object/from16 v17, v0

    move-object/from16 v0, v17

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/liveroute/LocInfo;->name:Ljava/lang/String;

    move-object/from16 v17, v0

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v16

    invoke-virtual/range {v16 .. v16}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v16

    move-object/from16 v0, v16

    invoke-virtual {v9, v15, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 108
    const-string v15, "mapid"

    new-instance v16, Ljava/lang/StringBuilder;

    invoke-direct/range {v16 .. v16}, Ljava/lang/StringBuilder;-><init>()V

    const-string v17, ""

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v16

    move-object/from16 v0, p1

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->strtloc:Lcom/thinkware/sundo/inavi3d/liveroute/LocInfo;

    move-object/from16 v17, v0

    move-object/from16 v0, v17

    iget v0, v0, Lcom/thinkware/sundo/inavi3d/liveroute/LocInfo;->mapid:I

    move/from16 v17, v0

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v16

    invoke-virtual/range {v16 .. v16}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v16

    move-object/from16 v0, v16

    invoke-virtual {v9, v15, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 109
    const-string v15, "linkid"

    new-instance v16, Ljava/lang/StringBuilder;

    invoke-direct/range {v16 .. v16}, Ljava/lang/StringBuilder;-><init>()V

    const-string v17, ""

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v16

    move-object/from16 v0, p1

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->strtloc:Lcom/thinkware/sundo/inavi3d/liveroute/LocInfo;

    move-object/from16 v17, v0

    move-object/from16 v0, v17

    iget v0, v0, Lcom/thinkware/sundo/inavi3d/liveroute/LocInfo;->linkid:I

    move/from16 v17, v0

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v16

    invoke-virtual/range {v16 .. v16}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v16

    move-object/from16 v0, v16

    invoke-virtual {v9, v15, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 110
    const-string v15, "nodeid"

    new-instance v16, Ljava/lang/StringBuilder;

    invoke-direct/range {v16 .. v16}, Ljava/lang/StringBuilder;-><init>()V

    const-string v17, ""

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v16

    move-object/from16 v0, p1

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->strtloc:Lcom/thinkware/sundo/inavi3d/liveroute/LocInfo;

    move-object/from16 v17, v0

    move-object/from16 v0, v17

    iget v0, v0, Lcom/thinkware/sundo/inavi3d/liveroute/LocInfo;->nodeid:I

    move/from16 v17, v0

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v16

    invoke-virtual/range {v16 .. v16}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v16

    move-object/from16 v0, v16

    invoke-virtual {v9, v15, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 111
    const-string v15, "direction"

    new-instance v16, Ljava/lang/StringBuilder;

    invoke-direct/range {v16 .. v16}, Ljava/lang/StringBuilder;-><init>()V

    const-string v17, ""

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v16

    move-object/from16 v0, p1

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->strtloc:Lcom/thinkware/sundo/inavi3d/liveroute/LocInfo;

    move-object/from16 v17, v0

    move-object/from16 v0, v17

    iget v0, v0, Lcom/thinkware/sundo/inavi3d/liveroute/LocInfo;->direction:I

    move/from16 v17, v0

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v16

    invoke-virtual/range {v16 .. v16}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v16

    move-object/from16 v0, v16

    invoke-virtual {v9, v15, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 112
    const-string v15, "startloc"

    invoke-virtual {v8, v15, v9}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 115
    .end local v9    # "tmp":Lorg/json/JSONObject;
    :cond_1a
    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->endloc:Lcom/thinkware/sundo/inavi3d/liveroute/LocInfo;

    if-eqz v15, :cond_1b

    .line 116
    new-instance v9, Lorg/json/JSONObject;

    invoke-direct {v9}, Lorg/json/JSONObject;-><init>()V

    .line 117
    .restart local v9    # "tmp":Lorg/json/JSONObject;
    const-string v15, "lonx"

    new-instance v16, Ljava/lang/StringBuilder;

    invoke-direct/range {v16 .. v16}, Ljava/lang/StringBuilder;-><init>()V

    const-string v17, ""

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v16

    move-object/from16 v0, p1

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->endloc:Lcom/thinkware/sundo/inavi3d/liveroute/LocInfo;

    move-object/from16 v17, v0

    move-object/from16 v0, v17

    iget v0, v0, Lcom/thinkware/sundo/inavi3d/liveroute/LocInfo;->lonx:I

    move/from16 v17, v0

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v16

    invoke-virtual/range {v16 .. v16}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v16

    move-object/from16 v0, v16

    invoke-virtual {v9, v15, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 118
    const-string v15, "laty"

    new-instance v16, Ljava/lang/StringBuilder;

    invoke-direct/range {v16 .. v16}, Ljava/lang/StringBuilder;-><init>()V

    const-string v17, ""

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v16

    move-object/from16 v0, p1

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->endloc:Lcom/thinkware/sundo/inavi3d/liveroute/LocInfo;

    move-object/from16 v17, v0

    move-object/from16 v0, v17

    iget v0, v0, Lcom/thinkware/sundo/inavi3d/liveroute/LocInfo;->laty:I

    move/from16 v17, v0

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v16

    invoke-virtual/range {v16 .. v16}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v16

    move-object/from16 v0, v16

    invoke-virtual {v9, v15, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 119
    const-string v15, "name"

    new-instance v16, Ljava/lang/StringBuilder;

    invoke-direct/range {v16 .. v16}, Ljava/lang/StringBuilder;-><init>()V

    const-string v17, ""

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v16

    move-object/from16 v0, p1

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->endloc:Lcom/thinkware/sundo/inavi3d/liveroute/LocInfo;

    move-object/from16 v17, v0

    move-object/from16 v0, v17

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/liveroute/LocInfo;->name:Ljava/lang/String;

    move-object/from16 v17, v0

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v16

    invoke-virtual/range {v16 .. v16}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v16

    move-object/from16 v0, v16

    invoke-virtual {v9, v15, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 120
    const-string v15, "mapid"

    new-instance v16, Ljava/lang/StringBuilder;

    invoke-direct/range {v16 .. v16}, Ljava/lang/StringBuilder;-><init>()V

    const-string v17, ""

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v16

    move-object/from16 v0, p1

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->endloc:Lcom/thinkware/sundo/inavi3d/liveroute/LocInfo;

    move-object/from16 v17, v0

    move-object/from16 v0, v17

    iget v0, v0, Lcom/thinkware/sundo/inavi3d/liveroute/LocInfo;->mapid:I

    move/from16 v17, v0

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v16

    invoke-virtual/range {v16 .. v16}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v16

    move-object/from16 v0, v16

    invoke-virtual {v9, v15, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 121
    const-string v15, "linkid"

    new-instance v16, Ljava/lang/StringBuilder;

    invoke-direct/range {v16 .. v16}, Ljava/lang/StringBuilder;-><init>()V

    const-string v17, ""

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v16

    move-object/from16 v0, p1

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->endloc:Lcom/thinkware/sundo/inavi3d/liveroute/LocInfo;

    move-object/from16 v17, v0

    move-object/from16 v0, v17

    iget v0, v0, Lcom/thinkware/sundo/inavi3d/liveroute/LocInfo;->linkid:I

    move/from16 v17, v0

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v16

    invoke-virtual/range {v16 .. v16}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v16

    move-object/from16 v0, v16

    invoke-virtual {v9, v15, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 122
    const-string v15, "nodeid"

    new-instance v16, Ljava/lang/StringBuilder;

    invoke-direct/range {v16 .. v16}, Ljava/lang/StringBuilder;-><init>()V

    const-string v17, ""

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v16

    move-object/from16 v0, p1

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->endloc:Lcom/thinkware/sundo/inavi3d/liveroute/LocInfo;

    move-object/from16 v17, v0

    move-object/from16 v0, v17

    iget v0, v0, Lcom/thinkware/sundo/inavi3d/liveroute/LocInfo;->nodeid:I

    move/from16 v17, v0

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v16

    invoke-virtual/range {v16 .. v16}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v16

    move-object/from16 v0, v16

    invoke-virtual {v9, v15, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 123
    const-string v15, "direction"

    new-instance v16, Ljava/lang/StringBuilder;

    invoke-direct/range {v16 .. v16}, Ljava/lang/StringBuilder;-><init>()V

    const-string v17, ""

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v16

    move-object/from16 v0, p1

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->endloc:Lcom/thinkware/sundo/inavi3d/liveroute/LocInfo;

    move-object/from16 v17, v0

    move-object/from16 v0, v17

    iget v0, v0, Lcom/thinkware/sundo/inavi3d/liveroute/LocInfo;->direction:I

    move/from16 v17, v0

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v16

    invoke-virtual/range {v16 .. v16}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v16

    move-object/from16 v0, v16

    invoke-virtual {v9, v15, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 124
    const-string v15, "endloc"

    invoke-virtual {v8, v15, v9}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 127
    .end local v9    # "tmp":Lorg/json/JSONObject;
    :cond_1b
    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->viaLoc:Ljava/util/ArrayList;

    if-eqz v15, :cond_1e

    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->viaLoc:Ljava/util/ArrayList;

    invoke-virtual {v15}, Ljava/util/ArrayList;->size()I

    move-result v15

    if-lez v15, :cond_1e

    .line 128
    new-instance v7, Lorg/json/JSONArray;

    invoke-direct {v7}, Lorg/json/JSONArray;-><init>()V

    .line 129
    .local v7, "jArray":Lorg/json/JSONArray;
    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->viaLoc:Ljava/util/ArrayList;

    invoke-virtual {v15}, Ljava/util/ArrayList;->size()I

    move-result v14

    .line 130
    .local v14, "viaCount":I
    const/4 v6, 0x0

    .local v6, "index":I
    :goto_1
    if-ge v6, v14, :cond_1d

    .line 131
    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->viaLoc:Ljava/util/ArrayList;

    invoke-virtual {v15, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Lcom/thinkware/sundo/inavi3d/liveroute/LocInfo;

    iget-object v15, v15, Lcom/thinkware/sundo/inavi3d/liveroute/LocInfo;->name:Ljava/lang/String;

    if-eqz v15, :cond_1c

    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->viaLoc:Ljava/util/ArrayList;

    invoke-virtual {v15, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Lcom/thinkware/sundo/inavi3d/liveroute/LocInfo;

    iget-object v15, v15, Lcom/thinkware/sundo/inavi3d/liveroute/LocInfo;->name:Ljava/lang/String;

    invoke-virtual {v15}, Ljava/lang/String;->isEmpty()Z

    move-result v15

    if-nez v15, :cond_1c

    .line 132
    new-instance v9, Lorg/json/JSONObject;

    invoke-direct {v9}, Lorg/json/JSONObject;-><init>()V

    .line 133
    .restart local v9    # "tmp":Lorg/json/JSONObject;
    const-string v16, "lonx"

    new-instance v15, Ljava/lang/StringBuilder;

    invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V

    const-string v17, ""

    move-object/from16 v0, v17

    invoke-virtual {v15, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v17

    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->viaLoc:Ljava/util/ArrayList;

    invoke-virtual {v15, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Lcom/thinkware/sundo/inavi3d/liveroute/LocInfo;

    iget v15, v15, Lcom/thinkware/sundo/inavi3d/liveroute/LocInfo;->lonx:I

    move-object/from16 v0, v17

    invoke-virtual {v0, v15}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v15

    invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v15

    move-object/from16 v0, v16

    invoke-virtual {v9, v0, v15}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 134
    const-string v16, "laty"

    new-instance v15, Ljava/lang/StringBuilder;

    invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V

    const-string v17, ""

    move-object/from16 v0, v17

    invoke-virtual {v15, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v17

    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->viaLoc:Ljava/util/ArrayList;

    invoke-virtual {v15, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Lcom/thinkware/sundo/inavi3d/liveroute/LocInfo;

    iget v15, v15, Lcom/thinkware/sundo/inavi3d/liveroute/LocInfo;->laty:I

    move-object/from16 v0, v17

    invoke-virtual {v0, v15}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v15

    invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v15

    move-object/from16 v0, v16

    invoke-virtual {v9, v0, v15}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 135
    const-string v16, "name"

    new-instance v15, Ljava/lang/StringBuilder;

    invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V

    const-string v17, ""

    move-object/from16 v0, v17

    invoke-virtual {v15, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v17

    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->viaLoc:Ljava/util/ArrayList;

    invoke-virtual {v15, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Lcom/thinkware/sundo/inavi3d/liveroute/LocInfo;

    iget-object v15, v15, Lcom/thinkware/sundo/inavi3d/liveroute/LocInfo;->name:Ljava/lang/String;

    move-object/from16 v0, v17

    invoke-virtual {v0, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v15

    invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v15

    move-object/from16 v0, v16

    invoke-virtual {v9, v0, v15}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 136
    const-string v16, "mapid"

    new-instance v15, Ljava/lang/StringBuilder;

    invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V

    const-string v17, ""

    move-object/from16 v0, v17

    invoke-virtual {v15, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v17

    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->viaLoc:Ljava/util/ArrayList;

    invoke-virtual {v15, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Lcom/thinkware/sundo/inavi3d/liveroute/LocInfo;

    iget v15, v15, Lcom/thinkware/sundo/inavi3d/liveroute/LocInfo;->mapid:I

    move-object/from16 v0, v17

    invoke-virtual {v0, v15}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v15

    invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v15

    move-object/from16 v0, v16

    invoke-virtual {v9, v0, v15}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 137
    const-string v16, "linkid"

    new-instance v15, Ljava/lang/StringBuilder;

    invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V

    const-string v17, ""

    move-object/from16 v0, v17

    invoke-virtual {v15, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v17

    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->viaLoc:Ljava/util/ArrayList;

    invoke-virtual {v15, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Lcom/thinkware/sundo/inavi3d/liveroute/LocInfo;

    iget v15, v15, Lcom/thinkware/sundo/inavi3d/liveroute/LocInfo;->linkid:I

    move-object/from16 v0, v17

    invoke-virtual {v0, v15}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v15

    invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v15

    move-object/from16 v0, v16

    invoke-virtual {v9, v0, v15}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 138
    const-string v16, "nodeid"

    new-instance v15, Ljava/lang/StringBuilder;

    invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V

    const-string v17, ""

    move-object/from16 v0, v17

    invoke-virtual {v15, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v17

    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->viaLoc:Ljava/util/ArrayList;

    invoke-virtual {v15, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Lcom/thinkware/sundo/inavi3d/liveroute/LocInfo;

    iget v15, v15, Lcom/thinkware/sundo/inavi3d/liveroute/LocInfo;->nodeid:I

    move-object/from16 v0, v17

    invoke-virtual {v0, v15}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v15

    invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v15

    move-object/from16 v0, v16

    invoke-virtual {v9, v0, v15}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 139
    const-string v16, "direction"

    new-instance v15, Ljava/lang/StringBuilder;

    invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V

    const-string v17, ""

    move-object/from16 v0, v17

    invoke-virtual {v15, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v17

    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->viaLoc:Ljava/util/ArrayList;

    invoke-virtual {v15, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Lcom/thinkware/sundo/inavi3d/liveroute/LocInfo;

    iget v15, v15, Lcom/thinkware/sundo/inavi3d/liveroute/LocInfo;->direction:I

    move-object/from16 v0, v17

    invoke-virtual {v0, v15}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v15

    invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v15

    move-object/from16 v0, v16

    invoke-virtual {v9, v0, v15}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 140
    invoke-virtual {v7, v9}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    .line 130
    .end local v9    # "tmp":Lorg/json/JSONObject;
    :cond_1c
    add-int/lit8 v6, v6, 0x1

    goto/16 :goto_1

    .line 143
    :cond_1d
    const-string v15, "vialoc"

    invoke-virtual {v8, v15, v7}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 146
    .end local v6    # "index":I
    .end local v7    # "jArray":Lorg/json/JSONArray;
    .end local v14    # "viaCount":I
    :cond_1e
    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->evas_list:Ljava/util/ArrayList;

    if-eqz v15, :cond_20

    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->evas_list:Ljava/util/ArrayList;

    invoke-virtual {v15}, Ljava/util/ArrayList;->size()I

    move-result v15

    if-lez v15, :cond_20

    .line 147
    new-instance v7, Lorg/json/JSONArray;

    invoke-direct {v7}, Lorg/json/JSONArray;-><init>()V

    .line 148
    .restart local v7    # "jArray":Lorg/json/JSONArray;
    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->evas_list:Ljava/util/ArrayList;

    invoke-virtual {v15}, Ljava/util/ArrayList;->size()I

    move-result v2

    .line 149
    .local v2, "evasCount":I
    const/4 v6, 0x0

    .restart local v6    # "index":I
    :goto_2
    if-ge v6, v2, :cond_1f

    .line 150
    new-instance v13, Lorg/json/JSONObject;

    invoke-direct {v13}, Lorg/json/JSONObject;-><init>()V

    .line 151
    .local v13, "unit":Lorg/json/JSONObject;
    const-string v16, "mapid"

    new-instance v15, Ljava/lang/StringBuilder;

    invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V

    const-string v17, ""

    move-object/from16 v0, v17

    invoke-virtual {v15, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v17

    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->evas_list:Ljava/util/ArrayList;

    invoke-virtual {v15, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Lcom/thinkware/sundo/inavi3d/liveroute/EvasInfo;

    iget v15, v15, Lcom/thinkware/sundo/inavi3d/liveroute/EvasInfo;->n_mapid:I

    move-object/from16 v0, v17

    invoke-virtual {v0, v15}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v15

    invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v15

    move-object/from16 v0, v16

    invoke-virtual {v13, v0, v15}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 152
    const-string v16, "linkid"

    new-instance v15, Ljava/lang/StringBuilder;

    invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V

    const-string v17, ""

    move-object/from16 v0, v17

    invoke-virtual {v15, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v17

    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->evas_list:Ljava/util/ArrayList;

    invoke-virtual {v15, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Lcom/thinkware/sundo/inavi3d/liveroute/EvasInfo;

    iget v15, v15, Lcom/thinkware/sundo/inavi3d/liveroute/EvasInfo;->n_linkid:I

    move-object/from16 v0, v17

    invoke-virtual {v0, v15}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v15

    invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v15

    move-object/from16 v0, v16

    invoke-virtual {v13, v0, v15}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 153
    const-string v16, "nodeid"

    new-instance v15, Ljava/lang/StringBuilder;

    invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V

    const-string v17, ""

    move-object/from16 v0, v17

    invoke-virtual {v15, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v17

    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->evas_list:Ljava/util/ArrayList;

    invoke-virtual {v15, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Lcom/thinkware/sundo/inavi3d/liveroute/EvasInfo;

    iget v15, v15, Lcom/thinkware/sundo/inavi3d/liveroute/EvasInfo;->n_nodeid:I

    move-object/from16 v0, v17

    invoke-virtual {v0, v15}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v15

    invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v15

    move-object/from16 v0, v16

    invoke-virtual {v13, v0, v15}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 154
    const-string v16, "ext"

    new-instance v15, Ljava/lang/StringBuilder;

    invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V

    const-string v17, ""

    move-object/from16 v0, v17

    invoke-virtual {v15, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v17

    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->evas_list:Ljava/util/ArrayList;

    invoke-virtual {v15, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Lcom/thinkware/sundo/inavi3d/liveroute/EvasInfo;

    iget v15, v15, Lcom/thinkware/sundo/inavi3d/liveroute/EvasInfo;->n_ext:I

    move-object/from16 v0, v17

    invoke-virtual {v0, v15}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v15

    invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v15

    move-object/from16 v0, v16

    invoke-virtual {v13, v0, v15}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 155
    const-string v16, "lposition"

    new-instance v15, Ljava/lang/StringBuilder;

    invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V

    const-string v17, ""

    move-object/from16 v0, v17

    invoke-virtual {v15, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v17

    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->evas_list:Ljava/util/ArrayList;

    invoke-virtual {v15, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Lcom/thinkware/sundo/inavi3d/liveroute/EvasInfo;

    iget v15, v15, Lcom/thinkware/sundo/inavi3d/liveroute/EvasInfo;->n_lposition:I

    move-object/from16 v0, v17

    invoke-virtual {v0, v15}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v15

    invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v15

    move-object/from16 v0, v16

    invoke-virtual {v13, v0, v15}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 156
    invoke-virtual {v7, v13}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    .line 149
    add-int/lit8 v6, v6, 0x1

    goto/16 :goto_2

    .line 158
    .end local v13    # "unit":Lorg/json/JSONObject;
    :cond_1f
    const-string v15, "evas_list"

    invoke-virtual {v8, v15, v7}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 161
    .end local v2    # "evasCount":I
    .end local v6    # "index":I
    .end local v7    # "jArray":Lorg/json/JSONArray;
    :cond_20
    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->event_list:Ljava/util/ArrayList;

    if-eqz v15, :cond_22

    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->event_list:Ljava/util/ArrayList;

    invoke-virtual {v15}, Ljava/util/ArrayList;->size()I

    move-result v15

    if-lez v15, :cond_22

    .line 162
    new-instance v7, Lorg/json/JSONArray;

    invoke-direct {v7}, Lorg/json/JSONArray;-><init>()V

    .line 163
    .restart local v7    # "jArray":Lorg/json/JSONArray;
    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->event_list:Ljava/util/ArrayList;

    invoke-virtual {v15}, Ljava/util/ArrayList;->size()I

    move-result v3

    .line 164
    .local v3, "eventCount":I
    const/4 v6, 0x0

    .restart local v6    # "index":I
    :goto_3
    if-ge v6, v3, :cond_21

    .line 165
    new-instance v13, Lorg/json/JSONObject;

    invoke-direct {v13}, Lorg/json/JSONObject;-><init>()V

    .line 166
    .restart local v13    # "unit":Lorg/json/JSONObject;
    const-string v16, "eid"

    new-instance v15, Ljava/lang/StringBuilder;

    invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V

    const-string v17, ""

    move-object/from16 v0, v17

    invoke-virtual {v15, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v17

    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->event_list:Ljava/util/ArrayList;

    invoke-virtual {v15, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Lcom/thinkware/sundo/inavi3d/liveroute/EventInfo;

    iget v15, v15, Lcom/thinkware/sundo/inavi3d/liveroute/EventInfo;->eid:I

    move-object/from16 v0, v17

    invoke-virtual {v0, v15}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v15

    invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v15

    move-object/from16 v0, v16

    invoke-virtual {v13, v0, v15}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 167
    invoke-virtual {v7, v13}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    .line 164
    add-int/lit8 v6, v6, 0x1

    goto :goto_3

    .line 169
    .end local v13    # "unit":Lorg/json/JSONObject;
    :cond_21
    const-string v15, "eventlist"

    invoke-virtual {v8, v15, v7}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 173
    .end local v3    # "eventCount":I
    .end local v6    # "index":I
    .end local v7    # "jArray":Lorg/json/JSONArray;
    :cond_22
    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->extension_list:Ljava/util/ArrayList;

    if-nez v15, :cond_23

    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->extension_list:Ljava/util/ArrayList;

    invoke-virtual {v15}, Ljava/util/ArrayList;->size()I

    move-result v15

    if-lez v15, :cond_2a

    .line 174
    :cond_23
    new-instance v7, Lorg/json/JSONArray;

    invoke-direct {v7}, Lorg/json/JSONArray;-><init>()V

    .line 176
    .restart local v7    # "jArray":Lorg/json/JSONArray;
    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->extension_list:Ljava/util/ArrayList;

    invoke-virtual {v15}, Ljava/util/ArrayList;->size()I

    move-result v4

    .line 177
    .local v4, "extensionCount":I
    const/4 v6, 0x0

    .restart local v6    # "index":I
    :goto_4
    if-ge v6, v4, :cond_29

    .line 178
    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->extension_list:Ljava/util/ArrayList;

    invoke-virtual {v15, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Lcom/thinkware/sundo/inavi3d/liveroute/ExtensionInfo;

    iget v5, v15, Lcom/thinkware/sundo/inavi3d/liveroute/ExtensionInfo;->htype:I

    .line 179
    .local v5, "htype":I
    const/4 v15, 0x2

    if-ne v5, v15, :cond_25

    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->extension_list:Ljava/util/ArrayList;

    invoke-virtual {v15, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Lcom/thinkware/sundo/inavi3d/liveroute/ExtensionInfo;

    iget-object v15, v15, Lcom/thinkware/sundo/inavi3d/liveroute/ExtensionInfo;->srhoptname:Ljava/lang/String;

    if-eqz v15, :cond_25

    .line 180
    new-instance v9, Lorg/json/JSONObject;

    invoke-direct {v9}, Lorg/json/JSONObject;-><init>()V

    .line 181
    .restart local v9    # "tmp":Lorg/json/JSONObject;
    const-string v16, "htype"

    new-instance v15, Ljava/lang/StringBuilder;

    invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V

    const-string v17, ""

    move-object/from16 v0, v17

    invoke-virtual {v15, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v17

    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->extension_list:Ljava/util/ArrayList;

    invoke-virtual {v15, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Lcom/thinkware/sundo/inavi3d/liveroute/ExtensionInfo;

    iget v15, v15, Lcom/thinkware/sundo/inavi3d/liveroute/ExtensionInfo;->htype:I

    move-object/from16 v0, v17

    invoke-virtual {v0, v15}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v15

    invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v15

    move-object/from16 v0, v16

    invoke-virtual {v9, v0, v15}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 183
    const-string v16, "srhoptname"

    new-instance v15, Ljava/lang/StringBuilder;

    invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V

    const-string v17, ""

    move-object/from16 v0, v17

    invoke-virtual {v15, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v17

    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->extension_list:Ljava/util/ArrayList;

    invoke-virtual {v15, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Lcom/thinkware/sundo/inavi3d/liveroute/ExtensionInfo;

    iget-object v15, v15, Lcom/thinkware/sundo/inavi3d/liveroute/ExtensionInfo;->srhoptname:Ljava/lang/String;

    move-object/from16 v0, v17

    invoke-virtual {v0, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v15

    invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v15

    move-object/from16 v0, v16

    invoke-virtual {v9, v0, v15}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 184
    const-string v16, "directivity"

    new-instance v15, Ljava/lang/StringBuilder;

    invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V

    const-string v17, ""

    move-object/from16 v0, v17

    invoke-virtual {v15, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v17

    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->extension_list:Ljava/util/ArrayList;

    invoke-virtual {v15, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Lcom/thinkware/sundo/inavi3d/liveroute/ExtensionInfo;

    iget v15, v15, Lcom/thinkware/sundo/inavi3d/liveroute/ExtensionInfo;->directivity:I

    move-object/from16 v0, v17

    invoke-virtual {v0, v15}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v15

    invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v15

    move-object/from16 v0, v16

    invoke-virtual {v9, v0, v15}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 185
    const-string v16, "last_index"

    new-instance v15, Ljava/lang/StringBuilder;

    invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V

    const-string v17, ""

    move-object/from16 v0, v17

    invoke-virtual {v15, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v17

    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->extension_list:Ljava/util/ArrayList;

    invoke-virtual {v15, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Lcom/thinkware/sundo/inavi3d/liveroute/ExtensionInfo;

    iget v15, v15, Lcom/thinkware/sundo/inavi3d/liveroute/ExtensionInfo;->last_index:I

    move-object/from16 v0, v17

    invoke-virtual {v0, v15}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v15

    invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v15

    move-object/from16 v0, v16

    invoke-virtual {v9, v0, v15}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 186
    const-string v16, "evas_distance"

    new-instance v15, Ljava/lang/StringBuilder;

    invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V

    const-string v17, ""

    move-object/from16 v0, v17

    invoke-virtual {v15, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v17

    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->extension_list:Ljava/util/ArrayList;

    invoke-virtual {v15, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Lcom/thinkware/sundo/inavi3d/liveroute/ExtensionInfo;

    iget v15, v15, Lcom/thinkware/sundo/inavi3d/liveroute/ExtensionInfo;->evas_distance:I

    move-object/from16 v0, v17

    invoke-virtual {v0, v15}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v15

    invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v15

    move-object/from16 v0, v16

    invoke-virtual {v9, v0, v15}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 187
    invoke-virtual {v7, v9}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    .line 177
    .end local v9    # "tmp":Lorg/json/JSONObject;
    :cond_24
    :goto_5
    add-int/lit8 v6, v6, 0x1

    goto/16 :goto_4

    .line 188
    :cond_25
    move-object/from16 v0, p0

    iget-boolean v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/ControlRouteTable;->HIPASS_ADD:Z

    const/16 v16, 0x1

    move/from16 v0, v16

    if-ne v15, v0, :cond_26

    const/4 v15, 0x6

    if-ne v5, v15, :cond_26

    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->extension_list:Ljava/util/ArrayList;

    invoke-virtual {v15, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Lcom/thinkware/sundo/inavi3d/liveroute/ExtensionInfo;

    iget v15, v15, Lcom/thinkware/sundo/inavi3d/liveroute/ExtensionInfo;->disgroup:I

    if-lez v15, :cond_26

    .line 189
    new-instance v9, Lorg/json/JSONObject;

    invoke-direct {v9}, Lorg/json/JSONObject;-><init>()V

    .line 190
    .restart local v9    # "tmp":Lorg/json/JSONObject;
    const-string v16, "htype"

    new-instance v15, Ljava/lang/StringBuilder;

    invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V

    const-string v17, ""

    move-object/from16 v0, v17

    invoke-virtual {v15, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v17

    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->extension_list:Ljava/util/ArrayList;

    invoke-virtual {v15, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Lcom/thinkware/sundo/inavi3d/liveroute/ExtensionInfo;

    iget v15, v15, Lcom/thinkware/sundo/inavi3d/liveroute/ExtensionInfo;->htype:I

    move-object/from16 v0, v17

    invoke-virtual {v0, v15}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v15

    invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v15

    move-object/from16 v0, v16

    invoke-virtual {v9, v0, v15}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 191
    const-string v16, "has_hipass"

    new-instance v15, Ljava/lang/StringBuilder;

    invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V

    const-string v17, ""

    move-object/from16 v0, v17

    invoke-virtual {v15, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v17

    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->extension_list:Ljava/util/ArrayList;

    invoke-virtual {v15, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Lcom/thinkware/sundo/inavi3d/liveroute/ExtensionInfo;

    iget v15, v15, Lcom/thinkware/sundo/inavi3d/liveroute/ExtensionInfo;->disgroup:I

    and-int/lit8 v15, v15, 0x1

    move-object/from16 v0, v17

    invoke-virtual {v0, v15}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v15

    invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v15

    move-object/from16 v0, v16

    invoke-virtual {v9, v0, v15}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 192
    const-string v16, "over_three"

    new-instance v15, Ljava/lang/StringBuilder;

    invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V

    const-string v17, ""

    move-object/from16 v0, v17

    invoke-virtual {v15, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v17

    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->extension_list:Ljava/util/ArrayList;

    invoke-virtual {v15, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Lcom/thinkware/sundo/inavi3d/liveroute/ExtensionInfo;

    iget v15, v15, Lcom/thinkware/sundo/inavi3d/liveroute/ExtensionInfo;->disgroup:I

    and-int/lit8 v15, v15, 0x2

    shr-int/lit8 v15, v15, 0x1

    move-object/from16 v0, v17

    invoke-virtual {v0, v15}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v15

    invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v15

    move-object/from16 v0, v16

    invoke-virtual {v9, v0, v15}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 193
    const-string v16, "limited_vehicle"

    new-instance v15, Ljava/lang/StringBuilder;

    invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V

    const-string v17, ""

    move-object/from16 v0, v17

    invoke-virtual {v15, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v17

    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->extension_list:Ljava/util/ArrayList;

    invoke-virtual {v15, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Lcom/thinkware/sundo/inavi3d/liveroute/ExtensionInfo;

    iget v15, v15, Lcom/thinkware/sundo/inavi3d/liveroute/ExtensionInfo;->disgroup:I

    and-int/lit8 v15, v15, 0x4

    shr-int/lit8 v15, v15, 0x2

    move-object/from16 v0, v17

    invoke-virtual {v0, v15}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v15

    invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v15

    move-object/from16 v0, v16

    invoke-virtual {v9, v0, v15}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 194
    const-string v16, "cartype"

    new-instance v15, Ljava/lang/StringBuilder;

    invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V

    const-string v17, ""

    move-object/from16 v0, v17

    invoke-virtual {v15, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v17

    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->extension_list:Ljava/util/ArrayList;

    invoke-virtual {v15, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Lcom/thinkware/sundo/inavi3d/liveroute/ExtensionInfo;

    iget v15, v15, Lcom/thinkware/sundo/inavi3d/liveroute/ExtensionInfo;->disgroup:I

    and-int/lit8 v15, v15, 0x38

    shr-int/lit8 v15, v15, 0x3

    move-object/from16 v0, v17

    invoke-virtual {v0, v15}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v15

    invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v15

    move-object/from16 v0, v16

    invoke-virtual {v9, v0, v15}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 195
    const-string v16, "discount_highway"

    new-instance v15, Ljava/lang/StringBuilder;

    invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V

    const-string v17, ""

    move-object/from16 v0, v17

    invoke-virtual {v15, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v17

    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->extension_list:Ljava/util/ArrayList;

    invoke-virtual {v15, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Lcom/thinkware/sundo/inavi3d/liveroute/ExtensionInfo;

    iget v15, v15, Lcom/thinkware/sundo/inavi3d/liveroute/ExtensionInfo;->disgroup:I

    and-int/lit16 v15, v15, 0xc0

    shr-int/lit8 v15, v15, 0x6

    move-object/from16 v0, v17

    invoke-virtual {v0, v15}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v15

    invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v15

    move-object/from16 v0, v16

    invoke-virtual {v9, v0, v15}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 196
    const-string v16, "discount_rushhour"

    new-instance v15, Ljava/lang/StringBuilder;

    invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V

    const-string v17, ""

    move-object/from16 v0, v17

    invoke-virtual {v15, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v17

    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->extension_list:Ljava/util/ArrayList;

    invoke-virtual {v15, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Lcom/thinkware/sundo/inavi3d/liveroute/ExtensionInfo;

    iget v15, v15, Lcom/thinkware/sundo/inavi3d/liveroute/ExtensionInfo;->disgroup:I

    and-int/lit16 v15, v15, 0x300

    shr-int/lit8 v15, v15, 0x8

    move-object/from16 v0, v17

    invoke-virtual {v0, v15}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v15

    invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v15

    move-object/from16 v0, v16

    invoke-virtual {v9, v0, v15}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 198
    const-string v16, "livelog"

    new-instance v15, Ljava/lang/StringBuilder;

    invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V

    const-string v17, "has_hipass : "

    move-object/from16 v0, v17

    invoke-virtual {v15, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v17

    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->extension_list:Ljava/util/ArrayList;

    invoke-virtual {v15, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Lcom/thinkware/sundo/inavi3d/liveroute/ExtensionInfo;

    iget v15, v15, Lcom/thinkware/sundo/inavi3d/liveroute/ExtensionInfo;->disgroup:I

    and-int/lit8 v15, v15, 0x1

    move-object/from16 v0, v17

    invoke-virtual {v0, v15}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v15

    invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v15

    move-object/from16 v0, v16

    invoke-static {v0, v15}, Lcom/thinkware/sundo/inavi3d/LOGTW;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 199
    const-string v16, "livelog"

    new-instance v15, Ljava/lang/StringBuilder;

    invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V

    const-string v17, "over_three : "

    move-object/from16 v0, v17

    invoke-virtual {v15, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v17

    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->extension_list:Ljava/util/ArrayList;

    invoke-virtual {v15, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Lcom/thinkware/sundo/inavi3d/liveroute/ExtensionInfo;

    iget v15, v15, Lcom/thinkware/sundo/inavi3d/liveroute/ExtensionInfo;->disgroup:I

    and-int/lit8 v15, v15, 0x2

    shr-int/lit8 v15, v15, 0x1

    move-object/from16 v0, v17

    invoke-virtual {v0, v15}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v15

    invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v15

    move-object/from16 v0, v16

    invoke-static {v0, v15}, Lcom/thinkware/sundo/inavi3d/LOGTW;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 200
    const-string v16, "livelog"

    new-instance v15, Ljava/lang/StringBuilder;

    invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V

    const-string v17, "limited_vehicle : "

    move-object/from16 v0, v17

    invoke-virtual {v15, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v17

    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->extension_list:Ljava/util/ArrayList;

    invoke-virtual {v15, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Lcom/thinkware/sundo/inavi3d/liveroute/ExtensionInfo;

    iget v15, v15, Lcom/thinkware/sundo/inavi3d/liveroute/ExtensionInfo;->disgroup:I

    and-int/lit8 v15, v15, 0x4

    shr-int/lit8 v15, v15, 0x2

    move-object/from16 v0, v17

    invoke-virtual {v0, v15}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v15

    invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v15

    move-object/from16 v0, v16

    invoke-static {v0, v15}, Lcom/thinkware/sundo/inavi3d/LOGTW;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 201
    const-string v16, "livelog"

    new-instance v15, Ljava/lang/StringBuilder;

    invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V

    const-string v17, "cartype : "

    move-object/from16 v0, v17

    invoke-virtual {v15, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v17

    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->extension_list:Ljava/util/ArrayList;

    invoke-virtual {v15, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Lcom/thinkware/sundo/inavi3d/liveroute/ExtensionInfo;

    iget v15, v15, Lcom/thinkware/sundo/inavi3d/liveroute/ExtensionInfo;->disgroup:I

    and-int/lit8 v15, v15, 0x38

    shr-int/lit8 v15, v15, 0x3

    move-object/from16 v0, v17

    invoke-virtual {v0, v15}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v15

    invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v15

    move-object/from16 v0, v16

    invoke-static {v0, v15}, Lcom/thinkware/sundo/inavi3d/LOGTW;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 202
    const-string v16, "livelog"

    new-instance v15, Ljava/lang/StringBuilder;

    invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V

    const-string v17, "discount_highway : "

    move-object/from16 v0, v17

    invoke-virtual {v15, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v17

    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->extension_list:Ljava/util/ArrayList;

    invoke-virtual {v15, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Lcom/thinkware/sundo/inavi3d/liveroute/ExtensionInfo;

    iget v15, v15, Lcom/thinkware/sundo/inavi3d/liveroute/ExtensionInfo;->disgroup:I

    and-int/lit16 v15, v15, 0xc0

    shr-int/lit8 v15, v15, 0x6

    move-object/from16 v0, v17

    invoke-virtual {v0, v15}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v15

    invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v15

    move-object/from16 v0, v16

    invoke-static {v0, v15}, Lcom/thinkware/sundo/inavi3d/LOGTW;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 203
    const-string v16, "livelog"

    new-instance v15, Ljava/lang/StringBuilder;

    invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V

    const-string v17, "discount_rushhour : "

    move-object/from16 v0, v17

    invoke-virtual {v15, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v17

    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->extension_list:Ljava/util/ArrayList;

    invoke-virtual {v15, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Lcom/thinkware/sundo/inavi3d/liveroute/ExtensionInfo;

    iget v15, v15, Lcom/thinkware/sundo/inavi3d/liveroute/ExtensionInfo;->disgroup:I

    and-int/lit16 v15, v15, 0x300

    shr-int/lit8 v15, v15, 0x8

    move-object/from16 v0, v17

    invoke-virtual {v0, v15}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v15

    invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v15

    move-object/from16 v0, v16

    invoke-static {v0, v15}, Lcom/thinkware/sundo/inavi3d/LOGTW;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 205
    invoke-virtual {v7, v9}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto/16 :goto_5

    .line 257
    .end local v4    # "extensionCount":I
    .end local v5    # "htype":I
    .end local v6    # "index":I
    .end local v7    # "jArray":Lorg/json/JSONArray;
    .end local v9    # "tmp":Lorg/json/JSONObject;
    :catch_0
    move-exception v1

    .line 259
    .local v1, "e":Ljava/lang/Exception;
    sget-object v15, Ljava/lang/System;->out:Ljava/io/PrintStream;

    invoke-virtual {v1, v15}, Ljava/lang/Exception;->printStackTrace(Ljava/io/PrintStream;)V

    .line 260
    const/4 v8, 0x0

    goto/16 :goto_0

    .line 206
    .end local v1    # "e":Ljava/lang/Exception;
    .restart local v4    # "extensionCount":I
    .restart local v5    # "htype":I
    .restart local v6    # "index":I
    .restart local v7    # "jArray":Lorg/json/JSONArray;
    :cond_26
    const/4 v15, 0x6

    if-ne v5, v15, :cond_27

    :try_start_1
    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->extension_list:Ljava/util/ArrayList;

    invoke-virtual {v15, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Lcom/thinkware/sundo/inavi3d/liveroute/ExtensionInfo;

    iget v15, v15, Lcom/thinkware/sundo/inavi3d/liveroute/ExtensionInfo;->disgroup:I

    if-lez v15, :cond_27

    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->extension_list:Ljava/util/ArrayList;

    invoke-virtual {v15, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Lcom/thinkware/sundo/inavi3d/liveroute/ExtensionInfo;

    iget v15, v15, Lcom/thinkware/sundo/inavi3d/liveroute/ExtensionInfo;->disgroup:I

    const/16 v16, 0xff

    move/from16 v0, v16

    if-ge v15, v0, :cond_27

    move-object/from16 v0, p0

    iget-boolean v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/ControlRouteTable;->HIPASS_ADD:Z

    if-nez v15, :cond_27

    .line 207
    new-instance v9, Lorg/json/JSONObject;

    invoke-direct {v9}, Lorg/json/JSONObject;-><init>()V

    .line 208
    .restart local v9    # "tmp":Lorg/json/JSONObject;
    const-string v16, "htype"

    new-instance v15, Ljava/lang/StringBuilder;

    invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V

    const-string v17, ""

    move-object/from16 v0, v17

    invoke-virtual {v15, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v17

    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->extension_list:Ljava/util/ArrayList;

    invoke-virtual {v15, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Lcom/thinkware/sundo/inavi3d/liveroute/ExtensionInfo;

    iget v15, v15, Lcom/thinkware/sundo/inavi3d/liveroute/ExtensionInfo;->htype:I

    move-object/from16 v0, v17

    invoke-virtual {v0, v15}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v15

    invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v15

    move-object/from16 v0, v16

    invoke-virtual {v9, v0, v15}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 209
    const-string v16, "disgroup"

    new-instance v15, Ljava/lang/StringBuilder;

    invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V

    const-string v17, ""

    move-object/from16 v0, v17

    invoke-virtual {v15, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v17

    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->extension_list:Ljava/util/ArrayList;

    invoke-virtual {v15, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Lcom/thinkware/sundo/inavi3d/liveroute/ExtensionInfo;

    iget v15, v15, Lcom/thinkware/sundo/inavi3d/liveroute/ExtensionInfo;->disgroup:I

    move-object/from16 v0, v17

    invoke-virtual {v0, v15}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v15

    invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v15

    move-object/from16 v0, v16

    invoke-virtual {v9, v0, v15}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 210
    const-string v16, "cartype"

    new-instance v15, Ljava/lang/StringBuilder;

    invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V

    const-string v17, ""

    move-object/from16 v0, v17

    invoke-virtual {v15, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v17

    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->extension_list:Ljava/util/ArrayList;

    invoke-virtual {v15, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Lcom/thinkware/sundo/inavi3d/liveroute/ExtensionInfo;

    iget v15, v15, Lcom/thinkware/sundo/inavi3d/liveroute/ExtensionInfo;->cartype:I

    move-object/from16 v0, v17

    invoke-virtual {v0, v15}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v15

    invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v15

    move-object/from16 v0, v16

    invoke-virtual {v9, v0, v15}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 211
    const-string v16, "capacity"

    new-instance v15, Ljava/lang/StringBuilder;

    invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V

    const-string v17, ""

    move-object/from16 v0, v17

    invoke-virtual {v15, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v17

    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->extension_list:Ljava/util/ArrayList;

    invoke-virtual {v15, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Lcom/thinkware/sundo/inavi3d/liveroute/ExtensionInfo;

    iget v15, v15, Lcom/thinkware/sundo/inavi3d/liveroute/ExtensionInfo;->capacity:I

    move-object/from16 v0, v17

    invoke-virtual {v0, v15}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v15

    invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v15

    move-object/from16 v0, v16

    invoke-virtual {v9, v0, v15}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 212
    const-string v16, "discrate"

    new-instance v15, Ljava/lang/StringBuilder;

    invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V

    const-string v17, ""

    move-object/from16 v0, v17

    invoke-virtual {v15, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v17

    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->extension_list:Ljava/util/ArrayList;

    invoke-virtual {v15, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Lcom/thinkware/sundo/inavi3d/liveroute/ExtensionInfo;

    iget v15, v15, Lcom/thinkware/sundo/inavi3d/liveroute/ExtensionInfo;->discrate:I

    move-object/from16 v0, v17

    invoke-virtual {v0, v15}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v15

    invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v15

    move-object/from16 v0, v16

    invoke-virtual {v9, v0, v15}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 213
    invoke-virtual {v7, v9}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    goto/16 :goto_5

    .line 214
    .end local v9    # "tmp":Lorg/json/JSONObject;
    :cond_27
    const/4 v15, 0x7

    if-ne v5, v15, :cond_24

    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->extension_list:Ljava/util/ArrayList;

    invoke-virtual {v15, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Lcom/thinkware/sundo/inavi3d/liveroute/ExtensionInfo;

    iget v15, v15, Lcom/thinkware/sundo/inavi3d/liveroute/ExtensionInfo;->tollCount:I

    if-lez v15, :cond_24

    .line 215
    new-instance v9, Lorg/json/JSONObject;

    invoke-direct {v9}, Lorg/json/JSONObject;-><init>()V

    .line 216
    .restart local v9    # "tmp":Lorg/json/JSONObject;
    const-string v16, "htype"

    new-instance v15, Ljava/lang/StringBuilder;

    invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V

    const-string v17, ""

    move-object/from16 v0, v17

    invoke-virtual {v15, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v17

    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->extension_list:Ljava/util/ArrayList;

    invoke-virtual {v15, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Lcom/thinkware/sundo/inavi3d/liveroute/ExtensionInfo;

    iget v15, v15, Lcom/thinkware/sundo/inavi3d/liveroute/ExtensionInfo;->htype:I

    move-object/from16 v0, v17

    invoke-virtual {v0, v15}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v15

    invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v15

    move-object/from16 v0, v16

    invoke-virtual {v9, v0, v15}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 217
    const-string v16, "srhoptname"

    new-instance v15, Ljava/lang/StringBuilder;

    invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V

    const-string v17, ""

    move-object/from16 v0, v17

    invoke-virtual {v15, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v17

    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->extension_list:Ljava/util/ArrayList;

    invoke-virtual {v15, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Lcom/thinkware/sundo/inavi3d/liveroute/ExtensionInfo;

    iget-object v15, v15, Lcom/thinkware/sundo/inavi3d/liveroute/ExtensionInfo;->srhoptname:Ljava/lang/String;

    move-object/from16 v0, v17

    invoke-virtual {v0, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v15

    invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v15

    move-object/from16 v0, v16

    invoke-virtual {v9, v0, v15}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 218
    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->extension_list:Ljava/util/ArrayList;

    invoke-virtual {v15, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Lcom/thinkware/sundo/inavi3d/liveroute/ExtensionInfo;

    iget v11, v15, Lcom/thinkware/sundo/inavi3d/liveroute/ExtensionInfo;->tollCount:I

    .line 219
    .local v11, "tollCount":I
    new-instance v10, Lorg/json/JSONArray;

    invoke-direct {v10}, Lorg/json/JSONArray;-><init>()V

    .line 220
    .local v10, "tmpArray":Lorg/json/JSONArray;
    const/4 v12, 0x0

    .local v12, "tollIndex":I
    :goto_6
    if-ge v12, v11, :cond_28

    .line 221
    new-instance v13, Lorg/json/JSONObject;

    invoke-direct {v13}, Lorg/json/JSONObject;-><init>()V

    .line 222
    .restart local v13    # "unit":Lorg/json/JSONObject;
    const-string v16, "tolltype"

    new-instance v15, Ljava/lang/StringBuilder;

    invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V

    const-string v17, ""

    move-object/from16 v0, v17

    invoke-virtual {v15, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v17

    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->extension_list:Ljava/util/ArrayList;

    invoke-virtual {v15, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Lcom/thinkware/sundo/inavi3d/liveroute/ExtensionInfo;

    iget-object v15, v15, Lcom/thinkware/sundo/inavi3d/liveroute/ExtensionInfo;->tolllist:[Lcom/thinkware/sundo/inavi3d/liveroute/PassTollInfo;

    aget-object v15, v15, v12

    iget v15, v15, Lcom/thinkware/sundo/inavi3d/liveroute/PassTollInfo;->tolltype:I

    move-object/from16 v0, v17

    invoke-virtual {v0, v15}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v15

    invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v15

    move-object/from16 v0, v16

    invoke-virtual {v13, v0, v15}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 223
    const-string v16, "tollidx"

    new-instance v15, Ljava/lang/StringBuilder;

    invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V

    const-string v17, ""

    move-object/from16 v0, v17

    invoke-virtual {v15, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v17

    move-object/from16 v0, p1

    iget-object v15, v0, Lcom/thinkware/sundo/inavi3d/liveroute/RouteRequestItem;->extension_list:Ljava/util/ArrayList;

    invoke-virtual {v15, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Lcom/thinkware/sundo/inavi3d/liveroute/ExtensionInfo;

    iget-object v15, v15, Lcom/thinkware/sundo/inavi3d/liveroute/ExtensionInfo;->tolllist:[Lcom/thinkware/sundo/inavi3d/liveroute/PassTollInfo;

    aget-object v15, v15, v12

    iget v15, v15, Lcom/thinkware/sundo/inavi3d/liveroute/PassTollInfo;->tollidx:I

    move-object/from16 v0, v17

    invoke-virtual {v0, v15}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v15

    invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v15

    move-object/from16 v0, v16

    invoke-virtual {v13, v0, v15}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 224
    invoke-virtual {v10, v13}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    .line 220
    add-int/lit8 v12, v12, 0x1

    goto :goto_6

    .line 226
    .end local v13    # "unit":Lorg/json/JSONObject;
    :cond_28
    const-string v15, "tolllist"

    invoke-virtual {v9, v15, v10}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 227
    invoke-virtual {v7, v9}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    goto/16 :goto_5

    .line 230
    .end local v5    # "htype":I
    .end local v9    # "tmp":Lorg/json/JSONObject;
    .end local v10    # "tmpArray":Lorg/json/JSONArray;
    .end local v11    # "tollCount":I
    .end local v12    # "tollIndex":I
    :cond_29
    const-string v15, "extension_list"

    invoke-virtual {v8, v15, v7}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 233
    .end local v4    # "extensionCount":I
    .end local v6    # "index":I
    .end local v7    # "jArray":Lorg/json/JSONArray;
    :cond_2a
    const-string v15, "poi_catecode"

    const-string v16, ""

    move-object/from16 v0, v16

    invoke-virtual {v8, v15, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 234
    const-string v15, "pid"

    const-string v16, ""

    move-object/from16 v0, v16

    invoke-virtual {v8, v15, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 235
    const-string v15, "poi_name"

    const-string v16, ""

    move-object/from16 v0, v16

    invoke-virtual {v8, v15, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 236
    const-string v15, "poi_admcode"

    const-string v16, ""

    move-object/from16 v0, v16

    invoke-virtual {v8, v15, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 237
    const-string v15, "cur_admcode"

    const-string v16, ""

    move-object/from16 v0, v16

    invoke-virtual {v8, v15, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    goto/16 :goto_0
.end method

.method public receive_response(Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;Ljava/lang/String;)I
    .locals 12
    .param p1, "type"    # Ljava/lang/String;
    .param p2, "host"    # Ljava/lang/String;
    .param p3, "port"    # I
    .param p4, "app"    # Ljava/lang/String;
    .param p5, "method"    # Ljava/lang/String;
    .param p6, "param"    # Lorg/json/JSONObject;
    .param p7, "encoding"    # Ljava/lang/String;

    .prologue
    .line 285
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/liveroute/ControlRouteTable;->http_routetable:Lcom/thinkware/sundo/inavi3d/liveroute/HttpUtil;

    move-object v1, p1

    move-object v2, p2

    move v3, p3

    move-object/from16 v4, p4

    move-object/from16 v5, p5

    move-object/from16 v6, p6

    move-object/from16 v7, p7

    invoke-virtual/range {v0 .. v7}, Lcom/thinkware/sundo/inavi3d/liveroute/HttpUtil;->connect(Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Lcom/thinkware/sundo/inavi3d/liveroute/ControlRouteTable;->result:I

    .line 286
    iget v0, p0, Lcom/thinkware/sundo/inavi3d/liveroute/ControlRouteTable;->result:I

    if-eqz v0, :cond_0

    iget v0, p0, Lcom/thinkware/sundo/inavi3d/liveroute/ControlRouteTable;->result:I

    .line 356
    :goto_0
    return v0

    .line 289
    :cond_0
    :try_start_0
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/liveroute/ControlRouteTable;->http_routetable:Lcom/thinkware/sundo/inavi3d/liveroute/HttpUtil;

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/liveroute/HttpUtil;->read()Ljava/lang/String;

    move-result-object v11

    .line 290
    .local v11, "strRetText":Ljava/lang/String;
    if-nez v11, :cond_1

    .line 292
    const/4 v0, -0x1

    goto :goto_0

    .line 296
    :cond_1
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0, v11}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/liveroute/ControlRouteTable;->jso:Lorg/json/JSONObject;

    .line 298
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/liveroute/ControlRouteTable;->jso:Lorg/json/JSONObject;

    const-string v1, "result"

    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_2

    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/liveroute/ControlRouteTable;->jso:Lorg/json/JSONObject;

    const-string v1, "result"

    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->getInt(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Lcom/thinkware/sundo/inavi3d/liveroute/ControlRouteTable;->result:I

    .line 299
    :cond_2
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/liveroute/ControlRouteTable;->jso:Lorg/json/JSONObject;

    const-string v1, "errormsg"

    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_3

    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/liveroute/ControlRouteTable;->jso:Lorg/json/JSONObject;

    const-string v1, "errormsg"

    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/liveroute/ControlRouteTable;->errormsg:Ljava/lang/String;

    .line 301
    :cond_3
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/liveroute/ControlRouteTable;->jso:Lorg/json/JSONObject;

    const-string v1, "retcode"

    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_4

    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/liveroute/ControlRouteTable;->jso:Lorg/json/JSONObject;

    const-string v1, "retcode"

    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->getInt(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Lcom/thinkware/sundo/inavi3d/liveroute/ControlRouteTable;->result:I

    .line 302
    :cond_4
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/liveroute/ControlRouteTable;->jso:Lorg/json/JSONObject;

    const-string v1, "retmsg"

    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_5

    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/liveroute/ControlRouteTable;->jso:Lorg/json/JSONObject;

    const-string v1, "retmsg"

    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/liveroute/ControlRouteTable;->errormsg:Ljava/lang/String;

    .line 304
    :cond_5
    const-string v9, ""

    .line 305
    .local v9, "localMrVersion":Ljava/lang/String;
    const-string v10, ""

    .line 306
    .local v10, "serverMrVersion":Ljava/lang/String;
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/liveroute/ControlRouteTable;->jso:Lorg/json/JSONObject;

    const-string v1, "version"

    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_6

    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/liveroute/ControlRouteTable;->jso:Lorg/json/JSONObject;

    const-string v1, "version"

    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    .line 315
    :cond_6
    iget v0, p0, Lcom/thinkware/sundo/inavi3d/liveroute/ControlRouteTable;->result:I

    if-nez v0, :cond_a

    .line 316
    invoke-direct {p0}, Lcom/thinkware/sundo/inavi3d/liveroute/ControlRouteTable;->getMrVersion()Ljava/lang/String;

    move-result-object v9

    .line 318
    const-string v0, "inavi3d_route"

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "receive_response :: serverMrVersion :: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " :: localMrVersion :: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 320
    invoke-virtual {v10, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_7

    .line 321
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v0

    invoke-virtual {v0, v10}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->AlramLiveSearchState(Ljava/lang/String;)V

    .line 322
    const/16 v0, 0x33

    goto/16 :goto_0

    .line 325
    :cond_7
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/liveroute/ControlRouteTable;->jso:Lorg/json/JSONObject;

    const-string v1, "rid"

    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_8

    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/liveroute/ControlRouteTable;->jso:Lorg/json/JSONObject;

    const-string v1, "rid"

    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/liveroute/ControlRouteTable;->rid:Ljava/lang/String;

    .line 328
    :cond_8
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/liveroute/ControlRouteTable;->jso:Lorg/json/JSONObject;

    const-string v1, "rdata"

    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_9

    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/liveroute/ControlRouteTable;->jso:Lorg/json/JSONObject;

    const-string v1, "rdata"

    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/liveroute/ControlRouteTable;->rdata:Ljava/lang/String;

    .line 333
    :cond_9
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/liveroute/ControlRouteTable;->http_routetable:Lcom/thinkware/sundo/inavi3d/liveroute/HttpUtil;

    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/liveroute/ControlRouteTable;->rdata:Ljava/lang/String;

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/inavi3d/liveroute/HttpUtil;->connectFile(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Lcom/thinkware/sundo/inavi3d/liveroute/ControlRouteTable;->result:I

    .line 336
    iget v0, p0, Lcom/thinkware/sundo/inavi3d/liveroute/ControlRouteTable;->result:I

    if-nez v0, :cond_a

    .line 337
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/liveroute/ControlRouteTable;->http_routetable:Lcom/thinkware/sundo/inavi3d/liveroute/HttpUtil;

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/liveroute/HttpUtil;->readFile()[B

    move-result-object v0

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/liveroute/ControlRouteTable;->byte_order_data:[B

    .line 338
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/liveroute/ControlRouteTable;->byte_order_data:[B

    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/liveroute/ControlRouteTable;->byte_order_data:[B

    array-length v1, v1

    invoke-virtual {p0, v0, v1}, Lcom/thinkware/sundo/inavi3d/liveroute/ControlRouteTable;->get_byte_order_data([BI)[B

    move-result-object v0

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/liveroute/ControlRouteTable;->route_data:[B

    .line 341
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/liveroute/ControlRouteTable;->route_data:[B

    if-nez v0, :cond_a

    .line 343
    const-string v0, "\uacbd\ub85c\ub370\uc774\ud130 \uccb4\ud06c\uc12c \uc2e4\ud328\uc785\ub2c8\ub2e4."

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/liveroute/ControlRouteTable;->errormsg:Ljava/lang/String;

    .line 344
    const/16 v0, 0x61

    iput v0, p0, Lcom/thinkware/sundo/inavi3d/liveroute/ControlRouteTable;->result:I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 356
    .end local v9    # "localMrVersion":Ljava/lang/String;
    .end local v10    # "serverMrVersion":Ljava/lang/String;
    .end local v11    # "strRetText":Ljava/lang/String;
    :cond_a
    :goto_1
    iget v0, p0, Lcom/thinkware/sundo/inavi3d/liveroute/ControlRouteTable;->result:I

    goto/16 :goto_0

    .line 351
    :catch_0
    move-exception v8

    .line 353
    .local v8, "e":Ljava/lang/Exception;
    sget-object v0, Ljava/lang/System;->out:Ljava/io/PrintStream;

    invoke-virtual {v8, v0}, Ljava/lang/Exception;->printStackTrace(Ljava/io/PrintStream;)V

    .line 354
    const/4 v0, -0x1

    iput v0, p0, Lcom/thinkware/sundo/inavi3d/liveroute/ControlRouteTable;->result:I

    goto :goto_1
.end method
