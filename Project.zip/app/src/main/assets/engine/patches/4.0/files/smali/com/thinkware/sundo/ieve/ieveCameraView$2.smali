.class Lcom/thinkware/sundo/ieve/ieveCameraView$2;
.super Ljava/lang/Object;
.source "ieveCameraView.java"

# interfaces
.implements Landroid/hardware/Camera$PreviewCallback;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/thinkware/sundo/ieve/ieveCameraView;->d()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/thinkware/sundo/ieve/ieveCameraView;

.field private b:I

.field private c:J

.field private d:J

.field private e:I

.field private f:[[B


# direct methods
.method constructor <init>(Lcom/thinkware/sundo/ieve/ieveCameraView;)V
    .locals 4

    .prologue
    const-wide/16 v2, 0x0

    const/4 v0, 0x0

    .line 1
    iput-object p1, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a:Lcom/thinkware/sundo/ieve/ieveCameraView;

    .line 498
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 499
    iput v0, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->b:I

    .line 500
    iput-wide v2, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->c:J

    .line 501
    iput-wide v2, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->d:J

    .line 503
    iput v0, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->e:I

    .line 504
    const/4 v0, 0x0

    iput-object v0, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->f:[[B

    return-void
.end method

.method static synthetic a(Lcom/thinkware/sundo/ieve/ieveCameraView$2;)Lcom/thinkware/sundo/ieve/ieveCameraView;
    .locals 1

    .prologue
    .line 498
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a:Lcom/thinkware/sundo/ieve/ieveCameraView;

    return-object v0
.end method

.method private a()V
    .locals 2

    .prologue
    .line 675
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;

    invoke-direct {v0, p0}, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;-><init>(Lcom/thinkware/sundo/ieve/ieveCameraView$2;)V

    const/4 v1, 0x0

    new-array v1, v1, [Ljava/lang/Void;

    .line 1074
    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/ieve/ieveCameraView$2$2;->execute([Ljava/lang/Object;)Landroid/os/AsyncTask;

    .line 1075
    return-void
.end method

.method private a([B)V
    .locals 2
    .param p1, "data"    # [B

    .prologue
    .line 590
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a:Lcom/thinkware/sundo/ieve/ieveCameraView;

    const/4 v1, 0x1

    invoke-static {v0, v1}, Lcom/thinkware/sundo/ieve/ieveCameraView;->b(Lcom/thinkware/sundo/ieve/ieveCameraView;Z)V

    .line 592
    new-instance v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2$1;

    invoke-direct {v0, p0, p1}, Lcom/thinkware/sundo/ieve/ieveCameraView$2$1;-><init>(Lcom/thinkware/sundo/ieve/ieveCameraView$2;[B)V

    const/4 v1, 0x0

    new-array v1, v1, [Ljava/lang/Void;

    .line 671
    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/ieve/ieveCameraView$2$1;->execute([Ljava/lang/Object;)Landroid/os/AsyncTask;

    .line 672
    return-void
.end method


# virtual methods
.method public declared-synchronized onPreviewFrame([BLandroid/hardware/Camera;)V
    .locals 16
    .param p1, "data"    # [B
    .param p2, "camera"    # Landroid/hardware/Camera;

    .prologue
    .line 521
    monitor-enter p0

    :try_start_0
    move-object/from16 v0, p0

    iget-object v10, v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->f:[[B

    if-nez v10, :cond_0

    const/4 v10, 0x5

    move-object/from16 v0, p0

    iget-object v11, v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a:Lcom/thinkware/sundo/ieve/ieveCameraView;

    invoke-static {v11}, Lcom/thinkware/sundo/ieve/ieveCameraView;->b(Lcom/thinkware/sundo/ieve/ieveCameraView;)I

    move-result v11

    filled-new-array {v10, v11}, [I

    move-result-object v10

    sget-object v11, Ljava/lang/Byte;->TYPE:Ljava/lang/Class;

    invoke-static {v11, v10}, Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class;[I)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, [[B

    move-object/from16 v0, p0

    iput-object v10, v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->f:[[B

    .line 523
    :cond_0
    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v6

    .line 524
    .local v6, "now":J
    move-object/from16 v0, p0

    iget-object v10, v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a:Lcom/thinkware/sundo/ieve/ieveCameraView;

    invoke-static {v10}, Lcom/thinkware/sundo/ieve/ieveCameraView;->a(Lcom/thinkware/sundo/ieve/ieveCameraView;)Landroid/os/Handler;

    move-result-object v10

    if-eqz v10, :cond_1

    move-object/from16 v0, p0

    iget-wide v10, v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->d:J

    sub-long v10, v6, v10

    long-to-double v10, v10

    move-object/from16 v0, p0

    iget-object v12, v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a:Lcom/thinkware/sundo/ieve/ieveCameraView;

    invoke-static {v12}, Lcom/thinkware/sundo/ieve/ieveCameraView;->c(Lcom/thinkware/sundo/ieve/ieveCameraView;)D

    move-result-wide v12

    const-wide v14, 0x412e848000000000L    # 1000000.0

    mul-double/2addr v12, v14

    cmpl-double v10, v10, v12

    if-lez v10, :cond_1

    .line 525
    move-object/from16 v0, p0

    iput-wide v6, v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->d:J

    .line 526
    const/4 v10, 0x0

    move-object/from16 v0, p0

    iget-object v11, v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->f:[[B

    move-object/from16 v0, p0

    iget v12, v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->e:I

    aget-object v11, v11, v12

    const/4 v12, 0x0

    move-object/from16 v0, p0

    iget-object v13, v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a:Lcom/thinkware/sundo/ieve/ieveCameraView;

    invoke-static {v13}, Lcom/thinkware/sundo/ieve/ieveCameraView;->b(Lcom/thinkware/sundo/ieve/ieveCameraView;)I

    move-result v13

    move-object/from16 v0, p1

    invoke-static {v0, v10, v11, v12, v13}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 527
    move-object/from16 v0, p0

    iget-object v10, v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a:Lcom/thinkware/sundo/ieve/ieveCameraView;

    invoke-static {v10}, Lcom/thinkware/sundo/ieve/ieveCameraView;->a(Lcom/thinkware/sundo/ieve/ieveCameraView;)Landroid/os/Handler;

    move-result-object v10

    const/16 v11, 0x3f2

    invoke-static {v10, v11}, Landroid/os/Message;->obtain(Landroid/os/Handler;I)Landroid/os/Message;

    move-result-object v4

    .line 528
    .local v4, "msg":Landroid/os/Message;
    move-object/from16 v0, p0

    iget-object v10, v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->f:[[B

    move-object/from16 v0, p0

    iget v11, v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->e:I

    aget-object v10, v10, v11

    iput-object v10, v4, Landroid/os/Message;->obj:Ljava/lang/Object;

    .line 529
    move-object/from16 v0, p0

    iget-object v10, v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a:Lcom/thinkware/sundo/ieve/ieveCameraView;

    invoke-static {v10}, Lcom/thinkware/sundo/ieve/ieveCameraView;->a(Lcom/thinkware/sundo/ieve/ieveCameraView;)Landroid/os/Handler;

    move-result-object v10

    invoke-virtual {v10, v4}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    .line 531
    .end local v4    # "msg":Landroid/os/Message;
    :cond_1
    move-object/from16 v0, p0

    iget-object v10, v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a:Lcom/thinkware/sundo/ieve/ieveCameraView;

    invoke-static {v10}, Lcom/thinkware/sundo/ieve/ieveCameraView;->d(Lcom/thinkware/sundo/ieve/ieveCameraView;)I

    move-result v10

    const/16 v11, 0xa

    if-lt v10, v11, :cond_4

    .line 533
    move-object/from16 v0, p0

    iget-object v10, v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a:Lcom/thinkware/sundo/ieve/ieveCameraView;

    invoke-static {v10}, Lcom/thinkware/sundo/ieve/ieveCameraView;->e(Lcom/thinkware/sundo/ieve/ieveCameraView;)Z

    move-result v10

    if-eqz v10, :cond_2

    move-object/from16 v0, p0

    iget-object v10, v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a:Lcom/thinkware/sundo/ieve/ieveCameraView;

    invoke-static {v10}, Lcom/thinkware/sundo/ieve/ieveCameraView;->f(Lcom/thinkware/sundo/ieve/ieveCameraView;)Z

    move-result v10

    if-nez v10, :cond_2

    .line 534
    move-object/from16 v0, p0

    iget-object v10, v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a:Lcom/thinkware/sundo/ieve/ieveCameraView;

    invoke-static {v10}, Lcom/thinkware/sundo/ieve/ieveCameraView;->b(Lcom/thinkware/sundo/ieve/ieveCameraView;)I

    move-result v10

    new-array v5, v10, [B

    .line 535
    .local v5, "previewbuffer":[B
    const/4 v10, 0x0

    const/4 v11, 0x0

    move-object/from16 v0, p0

    iget-object v12, v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a:Lcom/thinkware/sundo/ieve/ieveCameraView;

    invoke-static {v12}, Lcom/thinkware/sundo/ieve/ieveCameraView;->b(Lcom/thinkware/sundo/ieve/ieveCameraView;)I

    move-result v12

    move-object/from16 v0, p1

    invoke-static {v0, v10, v5, v11, v12}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 536
    move-object/from16 v0, p0

    invoke-direct {v0, v5}, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a([B)V

    .line 540
    .end local v5    # "previewbuffer":[B
    :cond_2
    move-object/from16 v0, p0

    iget-object v10, v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a:Lcom/thinkware/sundo/ieve/ieveCameraView;

    invoke-static {v10}, Lcom/thinkware/sundo/ieve/ieveCameraView;->g(Lcom/thinkware/sundo/ieve/ieveCameraView;)Z

    move-result v10

    if-eqz v10, :cond_4

    .line 541
    move-object/from16 v0, p0

    iget-object v10, v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a:Lcom/thinkware/sundo/ieve/ieveCameraView;

    invoke-static {v10}, Lcom/thinkware/sundo/ieve/ieveCameraView;->h(Lcom/thinkware/sundo/ieve/ieveCameraView;)Z

    move-result v10

    if-eqz v10, :cond_a

    .line 542
    move-object/from16 v0, p0

    iget-object v10, v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a:Lcom/thinkware/sundo/ieve/ieveCameraView;

    invoke-static {v10}, Lcom/thinkware/sundo/ieve/ieveCameraView;->i(Lcom/thinkware/sundo/ieve/ieveCameraView;)Z

    move-result v10

    if-nez v10, :cond_3

    .line 543
    move-object/from16 v0, p0

    iget-object v10, v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a:Lcom/thinkware/sundo/ieve/ieveCameraView;

    const/4 v11, 0x1

    invoke-static {v10, v11}, Lcom/thinkware/sundo/ieve/ieveCameraView;->a(Lcom/thinkware/sundo/ieve/ieveCameraView;Z)V

    .line 544
    invoke-direct/range {p0 .. p0}, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a()V

    .line 546
    :cond_3
    move-object/from16 v0, p0

    iget-object v10, v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a:Lcom/thinkware/sundo/ieve/ieveCameraView;

    invoke-static {v10}, Lcom/thinkware/sundo/ieve/ieveCameraView;->j(Lcom/thinkware/sundo/ieve/ieveCameraView;)Z

    move-result v10

    if-nez v10, :cond_4

    move-object/from16 v0, p0

    iget-object v10, v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a:Lcom/thinkware/sundo/ieve/ieveCameraView;

    invoke-static {v10}, Lcom/thinkware/sundo/ieve/ieveCameraView;->k(Lcom/thinkware/sundo/ieve/ieveCameraView;)Ljava/util/Vector;

    move-result-object v10

    if-eqz v10, :cond_4

    move-object/from16 v0, p0

    iget-object v10, v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a:Lcom/thinkware/sundo/ieve/ieveCameraView;

    invoke-static {v10}, Lcom/thinkware/sundo/ieve/ieveCameraView;->k(Lcom/thinkware/sundo/ieve/ieveCameraView;)Ljava/util/Vector;

    move-result-object v10

    invoke-virtual {v10}, Ljava/util/Vector;->size()I

    move-result v10

    move-object/from16 v0, p0

    iget-object v11, v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a:Lcom/thinkware/sundo/ieve/ieveCameraView;

    invoke-static {v11}, Lcom/thinkware/sundo/ieve/ieveCameraView;->l(Lcom/thinkware/sundo/ieve/ieveCameraView;)I

    move-result v11

    if-ge v10, v11, :cond_4

    .line 547
    move-object/from16 v0, p0

    iget-object v10, v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a:Lcom/thinkware/sundo/ieve/ieveCameraView;

    invoke-static {v10}, Lcom/thinkware/sundo/ieve/ieveCameraView;->b(Lcom/thinkware/sundo/ieve/ieveCameraView;)I

    move-result v10

    new-array v5, v10, [B

    .line 548
    .restart local v5    # "previewbuffer":[B
    const/4 v10, 0x0

    const/4 v11, 0x0

    move-object/from16 v0, p0

    iget-object v12, v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a:Lcom/thinkware/sundo/ieve/ieveCameraView;

    invoke-static {v12}, Lcom/thinkware/sundo/ieve/ieveCameraView;->b(Lcom/thinkware/sundo/ieve/ieveCameraView;)I

    move-result v12

    move-object/from16 v0, p1

    invoke-static {v0, v10, v5, v11, v12}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 549
    move-object/from16 v0, p0

    iget-object v10, v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a:Lcom/thinkware/sundo/ieve/ieveCameraView;

    invoke-static {v10}, Lcom/thinkware/sundo/ieve/ieveCameraView;->k(Lcom/thinkware/sundo/ieve/ieveCameraView;)Ljava/util/Vector;

    move-result-object v10

    invoke-virtual {v10, v5}, Ljava/util/Vector;->addElement(Ljava/lang/Object;)V

    .line 550
    move-object/from16 v0, p0

    iget-object v10, v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a:Lcom/thinkware/sundo/ieve/ieveCameraView;

    invoke-static {v10}, Lcom/thinkware/sundo/ieve/ieveCameraView;->k(Lcom/thinkware/sundo/ieve/ieveCameraView;)Ljava/util/Vector;

    move-result-object v10

    invoke-virtual {v10}, Ljava/util/Vector;->size()I

    move-result v10

    move-object/from16 v0, p0

    iget-object v11, v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a:Lcom/thinkware/sundo/ieve/ieveCameraView;

    invoke-static {v11}, Lcom/thinkware/sundo/ieve/ieveCameraView;->l(Lcom/thinkware/sundo/ieve/ieveCameraView;)I

    move-result v11

    if-ne v10, v11, :cond_4

    .line 551
    invoke-static {}, Lcom/thinkware/sundo/ieve/ieveCameraView;->a()Ljava/lang/String;

    move-result-object v10

    const-string v11, "PreviewCallback: mStreamBufferAfter.size(): %d"

    const/4 v12, 0x1

    new-array v12, v12, [Ljava/lang/Object;

    const/4 v13, 0x0

    move-object/from16 v0, p0

    iget-object v14, v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a:Lcom/thinkware/sundo/ieve/ieveCameraView;

    invoke-static {v14}, Lcom/thinkware/sundo/ieve/ieveCameraView;->k(Lcom/thinkware/sundo/ieve/ieveCameraView;)Ljava/util/Vector;

    move-result-object v14

    invoke-virtual {v14}, Ljava/util/Vector;->size()I

    move-result v14

    invoke-static {v14}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v14

    aput-object v14, v12, v13

    invoke-static {v11, v12}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v11

    invoke-static {v10, v11}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 571
    .end local v5    # "previewbuffer":[B
    :cond_4
    :goto_0
    move-object/from16 v0, p0

    iget-object v10, v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a:Lcom/thinkware/sundo/ieve/ieveCameraView;

    invoke-static {v10}, Lcom/thinkware/sundo/ieve/ieveCameraView;->o(Lcom/thinkware/sundo/ieve/ieveCameraView;)Z

    move-result v10

    if-eqz v10, :cond_5

    move-object/from16 v0, p2

    move-object/from16 v1, p1

    invoke-virtual {v0, v1}, Landroid/hardware/Camera;->addCallbackBuffer([B)V

    .line 572
    :cond_5
    move-object/from16 v0, p0

    iget-object v10, v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a:Lcom/thinkware/sundo/ieve/ieveCameraView;

    invoke-static {v10}, Lcom/thinkware/sundo/ieve/ieveCameraView;->d(Lcom/thinkware/sundo/ieve/ieveCameraView;)I

    move-result v10

    const/16 v11, 0xa

    if-ge v10, v11, :cond_6

    move-object/from16 v0, p0

    iget-object v10, v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a:Lcom/thinkware/sundo/ieve/ieveCameraView;

    invoke-static {v10}, Lcom/thinkware/sundo/ieve/ieveCameraView;->d(Lcom/thinkware/sundo/ieve/ieveCameraView;)I

    move-result v11

    add-int/lit8 v11, v11, 0x1

    invoke-static {v10, v11}, Lcom/thinkware/sundo/ieve/ieveCameraView;->a(Lcom/thinkware/sundo/ieve/ieveCameraView;I)V

    .line 574
    :cond_6
    move-object/from16 v0, p0

    iget v10, v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->e:I

    add-int/lit8 v10, v10, 0x1

    move-object/from16 v0, p0

    iput v10, v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->e:I

    .line 575
    move-object/from16 v0, p0

    iget v10, v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->e:I

    const/4 v11, 0x5

    if-lt v10, v11, :cond_7

    const/4 v10, 0x0

    move-object/from16 v0, p0

    iput v10, v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->e:I

    .line 577
    :cond_7
    move-object/from16 v0, p0

    iget v10, v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->b:I

    rem-int/lit8 v10, v10, 0x1e

    if-nez v10, :cond_9

    .line 578
    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v2

    .line 579
    .local v2, "_UptimeBase":J
    move-object/from16 v0, p0

    iget-wide v10, v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->c:J

    sub-long v8, v2, v10

    .line 580
    .local v8, "uptime_period":J
    const-wide/16 v10, 0x0

    cmp-long v10, v8, v10

    if-lez v10, :cond_8

    move-object/from16 v0, p0

    iget-object v10, v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a:Lcom/thinkware/sundo/ieve/ieveCameraView;

    move-object/from16 v0, p0

    iget v11, v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->b:I

    int-to-double v12, v11

    const-wide v14, 0x41cdcd6500000000L    # 1.0E9

    mul-double/2addr v12, v14

    long-to-double v14, v8

    div-double/2addr v12, v14

    invoke-static {v10, v12, v13}, Lcom/thinkware/sundo/ieve/ieveCameraView;->a(Lcom/thinkware/sundo/ieve/ieveCameraView;D)V

    .line 581
    :cond_8
    move-object/from16 v0, p0

    iput-wide v2, v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->c:J

    .line 582
    const/4 v10, 0x0

    move-object/from16 v0, p0

    iput v10, v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->b:I

    .line 585
    .end local v2    # "_UptimeBase":J
    .end local v8    # "uptime_period":J
    :cond_9
    move-object/from16 v0, p0

    iget v10, v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->b:I

    add-int/lit8 v10, v10, 0x1

    move-object/from16 v0, p0

    iput v10, v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->b:I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 586
    monitor-exit p0

    return-void

    .line 556
    :cond_a
    :try_start_1
    move-object/from16 v0, p0

    iget-object v10, v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a:Lcom/thinkware/sundo/ieve/ieveCameraView;

    invoke-static {v10}, Lcom/thinkware/sundo/ieve/ieveCameraView;->m(Lcom/thinkware/sundo/ieve/ieveCameraView;)Ljava/util/Vector;

    move-result-object v10

    if-eqz v10, :cond_4

    .line 557
    move-object/from16 v0, p0

    iget-object v10, v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a:Lcom/thinkware/sundo/ieve/ieveCameraView;

    invoke-static {v10}, Lcom/thinkware/sundo/ieve/ieveCameraView;->b(Lcom/thinkware/sundo/ieve/ieveCameraView;)I

    move-result v10

    new-array v5, v10, [B

    .line 558
    .restart local v5    # "previewbuffer":[B
    const/4 v10, 0x0

    const/4 v11, 0x0

    move-object/from16 v0, p0

    iget-object v12, v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a:Lcom/thinkware/sundo/ieve/ieveCameraView;

    invoke-static {v12}, Lcom/thinkware/sundo/ieve/ieveCameraView;->b(Lcom/thinkware/sundo/ieve/ieveCameraView;)I

    move-result v12

    move-object/from16 v0, p1

    invoke-static {v0, v10, v5, v11, v12}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 559
    move-object/from16 v0, p0

    iget-object v10, v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a:Lcom/thinkware/sundo/ieve/ieveCameraView;

    invoke-static {v10}, Lcom/thinkware/sundo/ieve/ieveCameraView;->m(Lcom/thinkware/sundo/ieve/ieveCameraView;)Ljava/util/Vector;

    move-result-object v10

    invoke-virtual {v10, v5}, Ljava/util/Vector;->addElement(Ljava/lang/Object;)V

    .line 560
    move-object/from16 v0, p0

    iget-object v10, v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a:Lcom/thinkware/sundo/ieve/ieveCameraView;

    invoke-static {v10}, Lcom/thinkware/sundo/ieve/ieveCameraView;->m(Lcom/thinkware/sundo/ieve/ieveCameraView;)Ljava/util/Vector;

    move-result-object v10

    invoke-virtual {v10}, Ljava/util/Vector;->size()I

    move-result v10

    move-object/from16 v0, p0

    iget-object v11, v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a:Lcom/thinkware/sundo/ieve/ieveCameraView;

    invoke-static {v11}, Lcom/thinkware/sundo/ieve/ieveCameraView;->n(Lcom/thinkware/sundo/ieve/ieveCameraView;)I

    move-result v11

    if-ne v10, v11, :cond_b

    .line 561
    invoke-static {}, Lcom/thinkware/sundo/ieve/ieveCameraView;->a()Ljava/lang/String;

    move-result-object v10

    const-string v11, "PreviewCallback: mStreamBufferBefore.size(): %d"

    const/4 v12, 0x1

    new-array v12, v12, [Ljava/lang/Object;

    const/4 v13, 0x0

    move-object/from16 v0, p0

    iget-object v14, v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a:Lcom/thinkware/sundo/ieve/ieveCameraView;

    invoke-static {v14}, Lcom/thinkware/sundo/ieve/ieveCameraView;->m(Lcom/thinkware/sundo/ieve/ieveCameraView;)Ljava/util/Vector;

    move-result-object v14

    invoke-virtual {v14}, Ljava/util/Vector;->size()I

    move-result v14

    invoke-static {v14}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v14

    aput-object v14, v12, v13

    invoke-static {v11, v12}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v11

    invoke-static {v10, v11}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 563
    :cond_b
    move-object/from16 v0, p0

    iget-object v10, v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a:Lcom/thinkware/sundo/ieve/ieveCameraView;

    invoke-static {v10}, Lcom/thinkware/sundo/ieve/ieveCameraView;->m(Lcom/thinkware/sundo/ieve/ieveCameraView;)Ljava/util/Vector;

    move-result-object v10

    invoke-virtual {v10}, Ljava/util/Vector;->size()I

    move-result v10

    move-object/from16 v0, p0

    iget-object v11, v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a:Lcom/thinkware/sundo/ieve/ieveCameraView;

    invoke-static {v11}, Lcom/thinkware/sundo/ieve/ieveCameraView;->n(Lcom/thinkware/sundo/ieve/ieveCameraView;)I

    move-result v11

    if-le v10, v11, :cond_4

    .line 564
    move-object/from16 v0, p0

    iget-object v10, v0, Lcom/thinkware/sundo/ieve/ieveCameraView$2;->a:Lcom/thinkware/sundo/ieve/ieveCameraView;

    invoke-static {v10}, Lcom/thinkware/sundo/ieve/ieveCameraView;->m(Lcom/thinkware/sundo/ieve/ieveCameraView;)Ljava/util/Vector;

    move-result-object v10

    const/4 v11, 0x0

    invoke-virtual {v10, v11}, Ljava/util/Vector;->remove(I)Ljava/lang/Object;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto/16 :goto_0

    .line 521
    .end local v5    # "previewbuffer":[B
    .end local v6    # "now":J
    :catchall_0
    move-exception v10

    monitor-exit p0

    throw v10
.end method
