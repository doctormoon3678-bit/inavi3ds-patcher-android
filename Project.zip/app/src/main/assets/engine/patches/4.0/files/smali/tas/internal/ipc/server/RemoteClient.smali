.class public abstract Ltas/internal/ipc/server/RemoteClient;
.super Ljava/lang/Object;
.source "RemoteClient.java"

# interfaces
.implements Landroid/os/Parcelable;


# static fields
.field private static s_id:I


# instance fields
.field public extra:Landroid/os/Bundle;

.field private id:J

.field private mRef:Ljava/util/concurrent/atomic/AtomicInteger;

.field public name:Ljava/lang/String;

.field private pid:I

.field public pkg:Ljava/lang/String;

.field public target:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .prologue
    .line 24
    const/4 v0, 0x0

    sput v0, Ltas/internal/ipc/server/RemoteClient;->s_id:I

    .line 15
    return-void
.end method

.method public constructor <init>()V
    .locals 3

    .prologue
    .line 27
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 28
    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result v0

    iput v0, p0, Ltas/internal/ipc/server/RemoteClient;->pid:I

    .line 29
    iget v0, p0, Ltas/internal/ipc/server/RemoteClient;->pid:I

    sget v1, Ltas/internal/ipc/server/RemoteClient;->s_id:I

    add-int/lit8 v2, v1, 0x1

    sput v2, Ltas/internal/ipc/server/RemoteClient;->s_id:I

    add-int/lit8 v1, v1, 0x2

    shl-int/2addr v0, v1

    int-to-long v0, v0

    iput-wide v0, p0, Ltas/internal/ipc/server/RemoteClient;->id:J

    .line 30
    new-instance v0, Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>(I)V

    iput-object v0, p0, Ltas/internal/ipc/server/RemoteClient;->mRef:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 27
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;)V
    .locals 0
    .param p1, "pkg"    # Ljava/lang/String;
    .param p2, "name"    # Ljava/lang/String;

    .prologue
    .line 34
    invoke-direct {p0}, Ltas/internal/ipc/server/RemoteClient;-><init>()V

    iput-object p1, p0, Ltas/internal/ipc/server/RemoteClient;->pkg:Ljava/lang/String;

    iput-object p2, p0, Ltas/internal/ipc/server/RemoteClient;->name:Ljava/lang/String;

    .line 33
    return-void
.end method

.method public constructor <init>(Ltas/internal/ipc/server/RemoteClient;)V
    .locals 0
    .param p1, "c"    # Ltas/internal/ipc/server/RemoteClient;

    .prologue
    .line 37
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 38
    invoke-virtual {p0, p1}, Ltas/internal/ipc/server/RemoteClient;->copyFrom(Ltas/internal/ipc/server/RemoteClient;)V

    .line 37
    return-void
.end method


# virtual methods
.method public buildString(Ljava/lang/StringBuilder;)Ljava/lang/StringBuilder;
    .locals 4
    .param p1, "sb"    # Ljava/lang/StringBuilder;

    .prologue
    .line 95
    invoke-virtual {p0}, Ltas/internal/ipc/server/RemoteClient;->getClass()Ljava/lang/Class;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 96
    const-string/jumbo v0, " { "

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v1, p0, Ltas/internal/ipc/server/RemoteClient;->name:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string/jumbo v1, " @ "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v1, p0, Ltas/internal/ipc/server/RemoteClient;->pkg:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string/jumbo v1, " }"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 97
    const-string/jumbo v0, " "

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-wide v2, p0, Ltas/internal/ipc/server/RemoteClient;->id:J

    invoke-virtual {v0, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 98
    return-object p1
.end method

.method public copyFrom(Ltas/internal/ipc/server/RemoteClient;)V
    .locals 2
    .param p1, "c"    # Ltas/internal/ipc/server/RemoteClient;

    .prologue
    .line 50
    iget v0, p1, Ltas/internal/ipc/server/RemoteClient;->pid:I

    iput v0, p0, Ltas/internal/ipc/server/RemoteClient;->pid:I

    iget-object v0, p1, Ltas/internal/ipc/server/RemoteClient;->pkg:Ljava/lang/String;

    iput-object v0, p0, Ltas/internal/ipc/server/RemoteClient;->pkg:Ljava/lang/String;

    iget-object v0, p1, Ltas/internal/ipc/server/RemoteClient;->name:Ljava/lang/String;

    iput-object v0, p0, Ltas/internal/ipc/server/RemoteClient;->name:Ljava/lang/String;

    .line 51
    iget-object v0, p1, Ltas/internal/ipc/server/RemoteClient;->extra:Landroid/os/Bundle;

    iput-object v0, p0, Ltas/internal/ipc/server/RemoteClient;->extra:Landroid/os/Bundle;

    .line 52
    iget-object v0, p1, Ltas/internal/ipc/server/RemoteClient;->target:Ljava/lang/String;

    iput-object v0, p0, Ltas/internal/ipc/server/RemoteClient;->target:Ljava/lang/String;

    .line 53
    iget-wide v0, p1, Ltas/internal/ipc/server/RemoteClient;->id:J

    iput-wide v0, p0, Ltas/internal/ipc/server/RemoteClient;->id:J

    .line 49
    return-void
.end method

.method public dec()I
    .locals 1

    .prologue
    .line 57
    iget-object v0, p0, Ltas/internal/ipc/server/RemoteClient;->mRef:Ljava/util/concurrent/atomic/AtomicInteger;

    if-eqz v0, :cond_0

    iget-object v0, p0, Ltas/internal/ipc/server/RemoteClient;->mRef:Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->decrementAndGet()I

    move-result v0

    :goto_0
    return v0

    :cond_0
    const/4 v0, 0x0

    goto :goto_0
.end method

.method public describeContents()I
    .locals 1

    .prologue
    .line 91
    const/4 v0, 0x0

    return v0
.end method

.method public getid()J
    .locals 2

    .prologue
    .line 46
    iget-wide v0, p0, Ltas/internal/ipc/server/RemoteClient;->id:J

    return-wide v0
.end method

.method public getpid()I
    .locals 1

    .prologue
    .line 42
    iget v0, p0, Ltas/internal/ipc/server/RemoteClient;->pid:I

    return v0
.end method

.method public inc()I
    .locals 1

    .prologue
    .line 56
    iget-object v0, p0, Ltas/internal/ipc/server/RemoteClient;->mRef:Ljava/util/concurrent/atomic/AtomicInteger;

    if-eqz v0, :cond_0

    iget-object v0, p0, Ltas/internal/ipc/server/RemoteClient;->mRef:Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->incrementAndGet()I

    move-result v0

    :goto_0
    return v0

    :cond_0
    const/4 v0, 0x0

    goto :goto_0
.end method

.method public readFromParcel(Landroid/os/Parcel;)V
    .locals 2
    .param p1, "source"    # Landroid/os/Parcel;

    .prologue
    .line 76
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    iput v0, p0, Ltas/internal/ipc/server/RemoteClient;->pid:I

    .line 77
    invoke-virtual {p1}, Landroid/os/Parcel;->readLong()J

    move-result-wide v0

    iput-wide v0, p0, Ltas/internal/ipc/server/RemoteClient;->id:J

    .line 78
    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Ltas/internal/ipc/server/RemoteClient;->pkg:Ljava/lang/String;

    .line 79
    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Ltas/internal/ipc/server/RemoteClient;->name:Ljava/lang/String;

    .line 80
    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Ltas/internal/ipc/server/RemoteClient;->target:Ljava/lang/String;

    .line 81
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    const/4 v1, 0x1

    if-ne v0, v1, :cond_0

    .line 82
    invoke-virtual {p1}, Landroid/os/Parcel;->readBundle()Landroid/os/Bundle;

    move-result-object v0

    iput-object v0, p0, Ltas/internal/ipc/server/RemoteClient;->extra:Landroid/os/Bundle;

    .line 84
    :cond_0
    iget-object v0, p0, Ltas/internal/ipc/server/RemoteClient;->mRef:Ljava/util/concurrent/atomic/AtomicInteger;

    if-eqz v0, :cond_1

    .line 85
    iget-object v0, p0, Ltas/internal/ipc/server/RemoteClient;->mRef:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Ljava/util/concurrent/atomic/AtomicInteger;->set(I)V

    .line 75
    :cond_1
    return-void
.end method

.method public ref()I
    .locals 1

    .prologue
    .line 58
    iget-object v0, p0, Ltas/internal/ipc/server/RemoteClient;->mRef:Ljava/util/concurrent/atomic/AtomicInteger;

    if-eqz v0, :cond_0

    iget-object v0, p0, Ltas/internal/ipc/server/RemoteClient;->mRef:Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    move-result v0

    :goto_0
    return v0

    :cond_0
    const/4 v0, 0x0

    goto :goto_0
.end method

.method public toString()Ljava/lang/String;
    .locals 1

    .prologue
    .line 103
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0, v0}, Ltas/internal/ipc/server/RemoteClient;->buildString(Ljava/lang/StringBuilder;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public writeToParcel(Landroid/os/Parcel;I)V
    .locals 2
    .param p1, "dest"    # Landroid/os/Parcel;
    .param p2, "flags"    # I

    .prologue
    .line 62
    iget v0, p0, Ltas/internal/ipc/server/RemoteClient;->pid:I

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->writeInt(I)V

    .line 63
    iget-wide v0, p0, Ltas/internal/ipc/server/RemoteClient;->id:J

    invoke-virtual {p1, v0, v1}, Landroid/os/Parcel;->writeLong(J)V

    .line 64
    iget-object v0, p0, Ltas/internal/ipc/server/RemoteClient;->pkg:Ljava/lang/String;

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    .line 65
    iget-object v0, p0, Ltas/internal/ipc/server/RemoteClient;->name:Ljava/lang/String;

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    .line 66
    iget-object v0, p0, Ltas/internal/ipc/server/RemoteClient;->target:Ljava/lang/String;

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    .line 67
    iget-object v0, p0, Ltas/internal/ipc/server/RemoteClient;->extra:Landroid/os/Bundle;

    if-eqz v0, :cond_0

    .line 68
    const/4 v0, 0x1

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->writeInt(I)V

    .line 69
    iget-object v0, p0, Ltas/internal/ipc/server/RemoteClient;->extra:Landroid/os/Bundle;

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->writeBundle(Landroid/os/Bundle;)V

    .line 61
    :goto_0
    return-void

    .line 71
    :cond_0
    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->writeInt(I)V

    goto :goto_0
.end method
