.class public Ltas/internal/camera/InputParams;
.super Ljava/lang/Object;
.source "InputParams.java"


# static fields
.field public static final ERR_ALREADY_OPENED:I = -0xe

.field public static final ERR_DENIED:I = -0x8

.field public static final ERR_GUARDIAN:I = -0x7

.field public static final ERR_HARDWARE:I = -0x4

.field public static final ERR_MEDIA_SERVER:I = -0x6

.field public static final ERR_NOT_PLUGGED:I = -0xc

.field public static final ERR_NOT_REQUESTED:I = -0xd

.field public static final ERR_NOT_SUPPORTED:I = -0x9

.field public static final ERR_NO_SUCH_CAMERA:I = -0x5

.field public static final ERR_OCCUPIED:I = -0x2

.field public static final ERR_UNKNOWN:I = -0x1

.field public static final ERR_UNKNOWN_OCCUPIED:I = -0x3

.field public static final OKAY:I = 0x0

.field public static final WHAT_CABLE_STATE:I = 0x1

.field public static final WHAT_CAMERA_MESSAGE:I = 0x3

.field public static final WHAT_CAMERA_STATE:I = 0x2

.field public static final WHAT_EXTRA_STATE:I = 0x4

.field public static final WHAT_INITIAL_STATE:I = 0x0

.field public static final WHAT_MEDIA_SERVER_STATE:I = 0x5


# instance fields
.field public cam:Ljava/lang/String;

.field public final cmd:Ltas/camera/CameraCommand;

.field public final msg:Ltas/camera/CameraMessage;

.field public pid:I

.field public proc:Ljava/lang/String;

.field public what:I


# direct methods
.method public constructor <init>()V
    .locals 1

    .prologue
    .line 70
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 67
    new-instance v0, Ltas/camera/CameraCommand;

    invoke-direct {v0}, Ltas/camera/CameraCommand;-><init>()V

    iput-object v0, p0, Ltas/internal/camera/InputParams;->cmd:Ltas/camera/CameraCommand;

    .line 68
    iget-object v0, p0, Ltas/internal/camera/InputParams;->cmd:Ltas/camera/CameraCommand;

    iput-object v0, p0, Ltas/internal/camera/InputParams;->msg:Ltas/camera/CameraMessage;

    .line 70
    return-void
.end method


# virtual methods
.method public clear()V
    .locals 2

    .prologue
    const/4 v1, 0x0

    const/4 v0, 0x0

    .line 82
    iput-object v1, p0, Ltas/internal/camera/InputParams;->cam:Ljava/lang/String;

    .line 83
    iput v0, p0, Ltas/internal/camera/InputParams;->pid:I

    .line 84
    iput v0, p0, Ltas/internal/camera/InputParams;->what:I

    .line 85
    iput-object v1, p0, Ltas/internal/camera/InputParams;->proc:Ljava/lang/String;

    .line 86
    iget-object v0, p0, Ltas/internal/camera/InputParams;->cmd:Ltas/camera/CameraCommand;

    invoke-virtual {v0}, Ltas/camera/CameraCommand;->clear()V

    .line 81
    return-void
.end method

.method public copy(Ltas/internal/camera/InputParams;)V
    .locals 2
    .param p1, "that"    # Ltas/internal/camera/InputParams;

    .prologue
    .line 74
    iget-object v0, p1, Ltas/internal/camera/InputParams;->cam:Ljava/lang/String;

    iput-object v0, p0, Ltas/internal/camera/InputParams;->cam:Ljava/lang/String;

    .line 75
    iget v0, p1, Ltas/internal/camera/InputParams;->pid:I

    iput v0, p0, Ltas/internal/camera/InputParams;->pid:I

    .line 76
    iget v0, p1, Ltas/internal/camera/InputParams;->what:I

    iput v0, p0, Ltas/internal/camera/InputParams;->what:I

    .line 77
    iget-object v0, p1, Ltas/internal/camera/InputParams;->proc:Ljava/lang/String;

    iput-object v0, p0, Ltas/internal/camera/InputParams;->proc:Ljava/lang/String;

    .line 78
    iget-object v0, p0, Ltas/internal/camera/InputParams;->cmd:Ltas/camera/CameraCommand;

    iget-object v1, p1, Ltas/internal/camera/InputParams;->cmd:Ltas/camera/CameraCommand;

    invoke-virtual {v0, v1}, Ltas/camera/CameraCommand;->copy(Ltas/camera/CameraMessage;)V

    .line 73
    return-void
.end method

.method public readFromParcel(Landroid/os/Parcel;)V
    .locals 1
    .param p1, "source"    # Landroid/os/Parcel;

    .prologue
    .line 98
    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Ltas/internal/camera/InputParams;->cam:Ljava/lang/String;

    .line 99
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    iput v0, p0, Ltas/internal/camera/InputParams;->pid:I

    .line 100
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    iput v0, p0, Ltas/internal/camera/InputParams;->what:I

    .line 101
    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Ltas/internal/camera/InputParams;->proc:Ljava/lang/String;

    .line 102
    iget-object v0, p0, Ltas/internal/camera/InputParams;->cmd:Ltas/camera/CameraCommand;

    invoke-virtual {v0, p1}, Ltas/camera/CameraCommand;->readFromParcel(Landroid/os/Parcel;)V

    .line 97
    return-void
.end method

.method public toString()Ljava/lang/String;
    .locals 2

    .prologue
    .line 106
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 107
    const-string/jumbo v1, "cam="

    .line 106
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 107
    iget-object v1, p0, Ltas/internal/camera/InputParams;->cam:Ljava/lang/String;

    .line 106
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 108
    const-string/jumbo v1, " pid="

    .line 106
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 108
    iget v1, p0, Ltas/internal/camera/InputParams;->pid:I

    .line 106
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 109
    const-string/jumbo v1, " what="

    .line 106
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 109
    iget v1, p0, Ltas/internal/camera/InputParams;->what:I

    .line 106
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 110
    const-string/jumbo v1, " cmd/msg="

    .line 106
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 110
    iget-object v1, p0, Ltas/internal/camera/InputParams;->cmd:Ltas/camera/CameraCommand;

    iget v1, v1, Ltas/camera/CameraCommand;->what:I

    .line 106
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 111
    const-string/jumbo v1, " arg1="

    .line 106
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 111
    iget-object v1, p0, Ltas/internal/camera/InputParams;->cmd:Ltas/camera/CameraCommand;

    iget v1, v1, Ltas/camera/CameraCommand;->arg1:I

    .line 106
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 112
    const-string/jumbo v1, " arg2="

    .line 106
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 112
    iget-object v1, p0, Ltas/internal/camera/InputParams;->cmd:Ltas/camera/CameraCommand;

    iget v1, v1, Ltas/camera/CameraCommand;->arg2:I

    .line 106
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 113
    const-string/jumbo v1, " str1="

    .line 106
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 113
    iget-object v1, p0, Ltas/internal/camera/InputParams;->cmd:Ltas/camera/CameraCommand;

    iget-object v1, v1, Ltas/camera/CameraCommand;->str1:Ljava/lang/String;

    .line 106
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public writeToParcel(Landroid/os/Parcel;)V
    .locals 1
    .param p1, "dest"    # Landroid/os/Parcel;

    .prologue
    .line 90
    iget-object v0, p0, Ltas/internal/camera/InputParams;->cam:Ljava/lang/String;

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    .line 91
    iget v0, p0, Ltas/internal/camera/InputParams;->pid:I

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->writeInt(I)V

    .line 92
    iget v0, p0, Ltas/internal/camera/InputParams;->what:I

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->writeInt(I)V

    .line 93
    iget-object v0, p0, Ltas/internal/camera/InputParams;->proc:Ljava/lang/String;

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    .line 94
    iget-object v0, p0, Ltas/internal/camera/InputParams;->cmd:Ltas/camera/CameraCommand;

    invoke-virtual {v0, p1}, Ltas/camera/CameraCommand;->writeToParcel(Landroid/os/Parcel;)V

    .line 89
    return-void
.end method
