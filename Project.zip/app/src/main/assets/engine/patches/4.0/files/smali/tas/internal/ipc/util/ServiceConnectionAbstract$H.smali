.class Ltas/internal/ipc/util/ServiceConnectionAbstract$H;
.super Landroid/os/Handler;
.source "ServiceConnectionAbstract.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltas/internal/ipc/util/ServiceConnectionAbstract;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "H"
.end annotation


# instance fields
.field private mM:Ljava/lang/ref/WeakReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference",
            "<",
            "Ltas/internal/ipc/util/ServiceConnectionAbstract;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Landroid/os/Looper;Ltas/internal/ipc/util/ServiceConnectionAbstract;)V
    .locals 1
    .param p1, "l"    # Landroid/os/Looper;
    .param p2, "m"    # Ltas/internal/ipc/util/ServiceConnectionAbstract;

    .prologue
    .line 323
    .local p0, "this":Ltas/internal/ipc/util/ServiceConnectionAbstract$H;, "Ltas/internal/ipc/util/ServiceConnectionAbstract<TT;>.H;"
    invoke-direct {p0, p1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    new-instance v0, Ljava/lang/ref/WeakReference;

    invoke-direct {v0, p2}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    iput-object v0, p0, Ltas/internal/ipc/util/ServiceConnectionAbstract$H;->mM:Ljava/lang/ref/WeakReference;

    .line 322
    return-void
.end method


# virtual methods
.method public handleMessage(Landroid/os/Message;)V
    .locals 3
    .param p1, "msg"    # Landroid/os/Message;

    .prologue
    .line 328
    .local p0, "this":Ltas/internal/ipc/util/ServiceConnectionAbstract$H;, "Ltas/internal/ipc/util/ServiceConnectionAbstract<TT;>.H;"
    iget-object v1, p0, Ltas/internal/ipc/util/ServiceConnectionAbstract$H;->mM:Ljava/lang/ref/WeakReference;

    invoke-virtual {v1}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/ipc/util/ServiceConnectionAbstract;

    .line 329
    .local v0, "m":Ltas/internal/ipc/util/ServiceConnectionAbstract;
    if-nez v0, :cond_0

    .line 330
    const-string/jumbo v1, "TasIPCUtil<ServiceConnection>"

    const-string/jumbo v2, "connection is lost."

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 331
    return-void

    .line 334
    :cond_0
    iget v1, p1, Landroid/os/Message;->what:I

    packed-switch v1, :pswitch_data_0

    .line 344
    invoke-static {v0, p1}, Ltas/internal/ipc/util/ServiceConnectionAbstract;->-wrap1(Ltas/internal/ipc/util/ServiceConnectionAbstract;Landroid/os/Message;)V

    .line 327
    :goto_0
    return-void

    .line 336
    :pswitch_0
    invoke-static {v0}, Ltas/internal/ipc/util/ServiceConnectionAbstract;->-wrap2(Ltas/internal/ipc/util/ServiceConnectionAbstract;)V

    goto :goto_0

    .line 340
    :pswitch_1
    invoke-static {v0}, Ltas/internal/ipc/util/ServiceConnectionAbstract;->-wrap0(Ltas/internal/ipc/util/ServiceConnectionAbstract;)V

    goto :goto_0

    .line 334
    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
        :pswitch_1
    .end packed-switch
.end method
