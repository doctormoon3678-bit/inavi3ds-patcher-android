.class final Ltas/internal/camera/server/RemoteMessage$1;
.super Ljava/lang/Object;
.source "RemoteMessage.java"

# interfaces
.implements Landroid/os/Parcelable$Creator;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltas/internal/camera/server/RemoteMessage;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Landroid/os/Parcelable$Creator",
        "<",
        "Ltas/internal/camera/server/RemoteMessage;",
        ">;"
    }
.end annotation


# direct methods
.method constructor <init>()V
    .locals 0

    .prologue
    .line 29
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public bridge synthetic createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;
    .locals 1
    .param p1, "source"    # Landroid/os/Parcel;

    .prologue
    .line 31
    invoke-virtual {p0, p1}, Ltas/internal/camera/server/RemoteMessage$1;->createFromParcel(Landroid/os/Parcel;)Ltas/internal/camera/server/RemoteMessage;

    move-result-object v0

    return-object v0
.end method

.method public createFromParcel(Landroid/os/Parcel;)Ltas/internal/camera/server/RemoteMessage;
    .locals 1
    .param p1, "source"    # Landroid/os/Parcel;

    .prologue
    .line 32
    invoke-static {}, Ltas/internal/camera/server/RemoteMessage;->obtain()Ltas/internal/camera/server/RemoteMessage;

    move-result-object v0

    .line 33
    .local v0, "r":Ltas/internal/camera/server/RemoteMessage;
    invoke-static {v0, p1}, Ltas/internal/camera/server/RemoteMessage;->-wrap0(Ltas/internal/camera/server/RemoteMessage;Landroid/os/Parcel;)V

    .line 34
    return-object v0
.end method

.method public bridge synthetic newArray(I)[Ljava/lang/Object;
    .locals 1
    .param p1, "size"    # I

    .prologue
    .line 37
    invoke-virtual {p0, p1}, Ltas/internal/camera/server/RemoteMessage$1;->newArray(I)[Ltas/internal/camera/server/RemoteMessage;

    move-result-object v0

    return-object v0
.end method

.method public newArray(I)[Ltas/internal/camera/server/RemoteMessage;
    .locals 1
    .param p1, "size"    # I

    .prologue
    .line 38
    new-array v0, p1, [Ltas/internal/camera/server/RemoteMessage;

    return-object v0
.end method
