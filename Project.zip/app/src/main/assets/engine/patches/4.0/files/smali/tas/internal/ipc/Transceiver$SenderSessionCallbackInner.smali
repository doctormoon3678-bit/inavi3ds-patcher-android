.class Ltas/internal/ipc/Transceiver$SenderSessionCallbackInner;
.super Ljava/lang/Object;
.source "Transceiver.java"

# interfaces
.implements Ltas/ipc/SenderSession$Callback;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltas/internal/ipc/Transceiver;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "SenderSessionCallbackInner"
.end annotation


# instance fields
.field private mS:Ltas/ipc/TransceiverSession;


# direct methods
.method private constructor <init>(Ltas/ipc/TransceiverSession;)V
    .locals 0
    .param p1, "s"    # Ltas/ipc/TransceiverSession;

    .prologue
    .line 189
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 190
    iput-object p1, p0, Ltas/internal/ipc/Transceiver$SenderSessionCallbackInner;->mS:Ltas/ipc/TransceiverSession;

    .line 189
    return-void
.end method

.method synthetic constructor <init>(Ltas/ipc/TransceiverSession;Ltas/internal/ipc/Transceiver$SenderSessionCallbackInner;)V
    .locals 0
    .param p1, "s"    # Ltas/ipc/TransceiverSession;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/ipc/Transceiver$SenderSessionCallbackInner;-><init>(Ltas/ipc/TransceiverSession;)V

    return-void
.end method


# virtual methods
.method public onReceiverOffline(Ltas/ipc/SenderSession;)V
    .locals 3
    .param p1, "session"    # Ltas/ipc/SenderSession;

    .prologue
    const/4 v2, 0x0

    .line 207
    iget-object v0, p0, Ltas/internal/ipc/Transceiver$SenderSessionCallbackInner;->mS:Ltas/ipc/TransceiverSession;

    iget-object v0, v0, Ltas/ipc/TransceiverSession;->cb:Ltas/ipc/TransceiverSession$Callback;

    if-eqz v0, :cond_0

    .line 208
    iget-object v0, p0, Ltas/internal/ipc/Transceiver$SenderSessionCallbackInner;->mS:Ltas/ipc/TransceiverSession;

    iget-object v0, v0, Ltas/ipc/TransceiverSession;->cb:Ltas/ipc/TransceiverSession$Callback;

    iget-object v1, p0, Ltas/internal/ipc/Transceiver$SenderSessionCallbackInner;->mS:Ltas/ipc/TransceiverSession;

    invoke-interface {v0, v1}, Ltas/ipc/TransceiverSession$Callback;->onReceiverOffline(Ltas/ipc/TransceiverSession;)V

    .line 210
    :cond_0
    iget-object v0, p0, Ltas/internal/ipc/Transceiver$SenderSessionCallbackInner;->mS:Ltas/ipc/TransceiverSession;

    iput-object v2, v0, Ltas/ipc/TransceiverSession;->s:Ltas/ipc/SenderSession;

    .line 206
    return-void
.end method

.method public onReceiverOnline(Ltas/ipc/SenderSession;)V
    .locals 2
    .param p1, "session"    # Ltas/ipc/SenderSession;

    .prologue
    .line 194
    iget-object v0, p0, Ltas/internal/ipc/Transceiver$SenderSessionCallbackInner;->mS:Ltas/ipc/TransceiverSession;

    iget-object v0, v0, Ltas/ipc/TransceiverSession;->pkg:Ljava/lang/String;

    if-nez v0, :cond_0

    .line 195
    iget-object v0, p0, Ltas/internal/ipc/Transceiver$SenderSessionCallbackInner;->mS:Ltas/ipc/TransceiverSession;

    iget-object v1, p1, Ltas/ipc/SenderSession;->pkg:Ljava/lang/String;

    iput-object v1, v0, Ltas/ipc/TransceiverSession;->pkg:Ljava/lang/String;

    .line 197
    :cond_0
    iget-object v0, p0, Ltas/internal/ipc/Transceiver$SenderSessionCallbackInner;->mS:Ltas/ipc/TransceiverSession;

    iget-object v0, v0, Ltas/ipc/TransceiverSession;->name:Ljava/lang/String;

    if-nez v0, :cond_1

    .line 198
    iget-object v0, p0, Ltas/internal/ipc/Transceiver$SenderSessionCallbackInner;->mS:Ltas/ipc/TransceiverSession;

    iget-object v1, p1, Ltas/ipc/SenderSession;->name:Ljava/lang/String;

    iput-object v1, v0, Ltas/ipc/TransceiverSession;->name:Ljava/lang/String;

    .line 200
    :cond_1
    iget-object v0, p0, Ltas/internal/ipc/Transceiver$SenderSessionCallbackInner;->mS:Ltas/ipc/TransceiverSession;

    iput-object p1, v0, Ltas/ipc/TransceiverSession;->s:Ltas/ipc/SenderSession;

    .line 201
    iget-object v0, p0, Ltas/internal/ipc/Transceiver$SenderSessionCallbackInner;->mS:Ltas/ipc/TransceiverSession;

    iget-object v0, v0, Ltas/ipc/TransceiverSession;->cb:Ltas/ipc/TransceiverSession$Callback;

    if-eqz v0, :cond_2

    .line 202
    iget-object v0, p0, Ltas/internal/ipc/Transceiver$SenderSessionCallbackInner;->mS:Ltas/ipc/TransceiverSession;

    iget-object v0, v0, Ltas/ipc/TransceiverSession;->cb:Ltas/ipc/TransceiverSession$Callback;

    iget-object v1, p0, Ltas/internal/ipc/Transceiver$SenderSessionCallbackInner;->mS:Ltas/ipc/TransceiverSession;

    invoke-interface {v0, v1}, Ltas/ipc/TransceiverSession$Callback;->onReceiverOnline(Ltas/ipc/TransceiverSession;)V

    .line 193
    :cond_2
    return-void
.end method

.method public onReceiverUpdate(Ltas/ipc/SenderSession;Landroid/os/Bundle;)V
    .locals 2
    .param p1, "session"    # Ltas/ipc/SenderSession;
    .param p2, "extra"    # Landroid/os/Bundle;

    .prologue
    .line 215
    iget-object v0, p0, Ltas/internal/ipc/Transceiver$SenderSessionCallbackInner;->mS:Ltas/ipc/TransceiverSession;

    iget-object v0, v0, Ltas/ipc/TransceiverSession;->cb:Ltas/ipc/TransceiverSession$Callback;

    if-eqz v0, :cond_0

    .line 216
    iget-object v0, p0, Ltas/internal/ipc/Transceiver$SenderSessionCallbackInner;->mS:Ltas/ipc/TransceiverSession;

    iget-object v0, v0, Ltas/ipc/TransceiverSession;->cb:Ltas/ipc/TransceiverSession$Callback;

    iget-object v1, p0, Ltas/internal/ipc/Transceiver$SenderSessionCallbackInner;->mS:Ltas/ipc/TransceiverSession;

    invoke-interface {v0, v1, p2}, Ltas/ipc/TransceiverSession$Callback;->onReceiverUpdate(Ltas/ipc/TransceiverSession;Landroid/os/Bundle;)V

    .line 214
    :cond_0
    return-void
.end method

.method public onReply(Ltas/ipc/SenderSession;ILtas/ipc/MsgData;)V
    .locals 2
    .param p1, "session"    # Ltas/ipc/SenderSession;
    .param p2, "what"    # I
    .param p3, "msg"    # Ltas/ipc/MsgData;

    .prologue
    .line 222
    iget-object v0, p0, Ltas/internal/ipc/Transceiver$SenderSessionCallbackInner;->mS:Ltas/ipc/TransceiverSession;

    iget-object v0, v0, Ltas/ipc/TransceiverSession;->cb:Ltas/ipc/TransceiverSession$Callback;

    if-eqz v0, :cond_0

    .line 223
    iget-object v0, p0, Ltas/internal/ipc/Transceiver$SenderSessionCallbackInner;->mS:Ltas/ipc/TransceiverSession;

    iget-object v0, v0, Ltas/ipc/TransceiverSession;->cb:Ltas/ipc/TransceiverSession$Callback;

    iget-object v1, p0, Ltas/internal/ipc/Transceiver$SenderSessionCallbackInner;->mS:Ltas/ipc/TransceiverSession;

    invoke-interface {v0, v1, p2, p3}, Ltas/ipc/TransceiverSession$Callback;->onReply(Ltas/ipc/TransceiverSession;ILtas/ipc/MsgData;)V

    .line 221
    :cond_0
    return-void
.end method
