.class public Ltas/internal/ipc/Transceiver;
.super Ljava/lang/Object;
.source "Transceiver.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ltas/internal/ipc/Transceiver$SenderSessionCallbackInner;,
        Ltas/internal/ipc/Transceiver$ReceiverSessionCallbackInner;
    }
.end annotation


# instance fields
.field private mContext:Landroid/content/Context;

.field private mExtra:Landroid/os/Bundle;

.field mReceiver:Ltas/internal/ipc/Receiver;

.field mSender:Ltas/internal/ipc/Sender;

.field public final name:Ljava/lang/String;

.field public final pkg:Ljava/lang/String;


# direct methods
.method public constructor <init>(Landroid/content/Context;Ljava/lang/String;Landroid/os/Looper;Ljava/lang/Class;)V
    .locals 4
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "name"    # Ljava/lang/String;
    .param p3, "looper"    # Landroid/os/Looper;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/lang/String;",
            "Landroid/os/Looper;",
            "Ljava/lang/Class",
            "<+",
            "Ltas/ipc/MsgReceiverService;",
            ">;)V"
        }
    .end annotation

    .prologue
    .local p4, "srvcls":Ljava/lang/Class;, "Ljava/lang/Class<+Ltas/ipc/MsgReceiverService;>;"
    const/4 v1, 0x0

    .line 33
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 35
    iput-object p1, p0, Ltas/internal/ipc/Transceiver;->mContext:Landroid/content/Context;

    .line 36
    new-instance v0, Ltas/internal/ipc/Sender;

    invoke-direct {v0, p1, p2, v1}, Ltas/internal/ipc/Sender;-><init>(Landroid/content/Context;Ljava/lang/String;Landroid/os/Looper;)V

    iput-object v0, p0, Ltas/internal/ipc/Transceiver;->mSender:Ltas/internal/ipc/Sender;

    .line 37
    new-instance v0, Ltas/internal/ipc/Receiver;

    invoke-direct {v0, p1, p2, v1, p4}, Ltas/internal/ipc/Receiver;-><init>(Landroid/content/Context;Ljava/lang/String;Landroid/os/Looper;Ljava/lang/Class;)V

    iput-object v0, p0, Ltas/internal/ipc/Transceiver;->mReceiver:Ltas/internal/ipc/Receiver;

    .line 38
    iget-object v0, p0, Ltas/internal/ipc/Transceiver;->mSender:Ltas/internal/ipc/Sender;

    .line 39
    new-instance v1, Ltas/internal/ipc/Dispatcher;

    iget-object v2, p0, Ltas/internal/ipc/Transceiver;->mSender:Ltas/internal/ipc/Sender;

    iget-object v3, p0, Ltas/internal/ipc/Transceiver;->mReceiver:Ltas/internal/ipc/Receiver;

    invoke-direct {v1, p3, v2, v3}, Ltas/internal/ipc/Dispatcher;-><init>(Landroid/os/Looper;Ltas/internal/ipc/Sender;Ltas/internal/ipc/Receiver;)V

    .line 38
    iget-object v2, p0, Ltas/internal/ipc/Transceiver;->mReceiver:Ltas/internal/ipc/Receiver;

    iput-object v1, v2, Ltas/internal/ipc/Receiver;->mDispatcher:Ltas/internal/ipc/Dispatcher;

    iput-object v1, v0, Ltas/internal/ipc/Sender;->mDispatcher:Ltas/internal/ipc/Dispatcher;

    .line 40
    iput-object p2, p0, Ltas/internal/ipc/Transceiver;->name:Ljava/lang/String;

    .line 41
    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Ltas/internal/ipc/Transceiver;->pkg:Ljava/lang/String;

    .line 42
    invoke-virtual {p0}, Ltas/internal/ipc/Transceiver;->initialize()V

    .line 34
    return-void
.end method


# virtual methods
.method public acceptAnonymousSession(Ltas/ipc/TransceiverSession$Callback;)V
    .locals 3
    .param p1, "cb"    # Ltas/ipc/TransceiverSession$Callback;

    .prologue
    .line 111
    new-instance v1, Ltas/ipc/TransceiverSession;

    invoke-direct {v1, p1}, Ltas/ipc/TransceiverSession;-><init>(Ltas/ipc/TransceiverSession$Callback;)V

    .line 113
    .local v1, "rs":Ltas/ipc/TransceiverSession;
    new-instance v0, Ltas/internal/ipc/Transceiver$ReceiverSessionCallbackInner;

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2}, Ltas/internal/ipc/Transceiver$ReceiverSessionCallbackInner;-><init>(Ltas/ipc/TransceiverSession;Ltas/internal/ipc/Transceiver$ReceiverSessionCallbackInner;)V

    .line 114
    .local v0, "rcb":Ltas/internal/ipc/Transceiver$ReceiverSessionCallbackInner;
    iget-object v2, p0, Ltas/internal/ipc/Transceiver;->mReceiver:Ltas/internal/ipc/Receiver;

    invoke-virtual {v2, v0}, Ltas/internal/ipc/Receiver;->acceptAnonymousSession(Ltas/ipc/ReceiverSession$Callback;)V

    .line 110
    return-void
.end method

.method public acceptSession(Ljava/lang/String;Ltas/ipc/TransceiverSession$Callback;)V
    .locals 3
    .param p1, "name"    # Ljava/lang/String;
    .param p2, "cb"    # Ltas/ipc/TransceiverSession$Callback;

    .prologue
    .line 71
    new-instance v1, Ltas/ipc/TransceiverSession;

    invoke-direct {v1, p2}, Ltas/ipc/TransceiverSession;-><init>(Ltas/ipc/TransceiverSession$Callback;)V

    .line 73
    .local v1, "rs":Ltas/ipc/TransceiverSession;
    new-instance v0, Ltas/internal/ipc/Transceiver$ReceiverSessionCallbackInner;

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2}, Ltas/internal/ipc/Transceiver$ReceiverSessionCallbackInner;-><init>(Ltas/ipc/TransceiverSession;Ltas/internal/ipc/Transceiver$ReceiverSessionCallbackInner;)V

    .line 74
    .local v0, "rcb":Ltas/internal/ipc/Transceiver$ReceiverSessionCallbackInner;
    iget-object v2, p0, Ltas/internal/ipc/Transceiver;->mReceiver:Ltas/internal/ipc/Receiver;

    invoke-virtual {v2, p1, v0}, Ltas/internal/ipc/Receiver;->acceptSession(Ljava/lang/String;Ltas/ipc/ReceiverSession$Callback;)V

    .line 70
    return-void
.end method

.method public getExtra()Landroid/os/Bundle;
    .locals 1

    .prologue
    .line 151
    iget-object v0, p0, Ltas/internal/ipc/Transceiver;->mExtra:Landroid/os/Bundle;

    if-nez v0, :cond_0

    .line 152
    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    iput-object v0, p0, Ltas/internal/ipc/Transceiver;->mExtra:Landroid/os/Bundle;

    .line 154
    :cond_0
    iget-object v0, p0, Ltas/internal/ipc/Transceiver;->mExtra:Landroid/os/Bundle;

    return-object v0
.end method

.method public initialize()V
    .locals 1

    .prologue
    .line 173
    iget-object v0, p0, Ltas/internal/ipc/Transceiver;->mSender:Ltas/internal/ipc/Sender;

    invoke-virtual {v0}, Ltas/internal/ipc/Sender;->initialize()V

    .line 174
    iget-object v0, p0, Ltas/internal/ipc/Transceiver;->mReceiver:Ltas/internal/ipc/Receiver;

    invoke-virtual {v0}, Ltas/internal/ipc/Receiver;->initialize()V

    .line 172
    return-void
.end method

.method public isInitialized()Z
    .locals 1

    .prologue
    .line 183
    iget-object v0, p0, Ltas/internal/ipc/Transceiver;->mSender:Ltas/internal/ipc/Sender;

    invoke-virtual {v0}, Ltas/internal/ipc/Sender;->isInitialized()Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Ltas/internal/ipc/Transceiver;->mReceiver:Ltas/internal/ipc/Receiver;

    invoke-virtual {v0}, Ltas/internal/ipc/Receiver;->isInitialized()Z

    move-result v0

    :goto_0
    return v0

    :cond_0
    const/4 v0, 0x0

    goto :goto_0
.end method

.method public isOnline()Z
    .locals 1

    .prologue
    .line 56
    iget-object v0, p0, Ltas/internal/ipc/Transceiver;->mSender:Ltas/internal/ipc/Sender;

    invoke-virtual {v0}, Ltas/internal/ipc/Sender;->isOnline()Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Ltas/internal/ipc/Transceiver;->mReceiver:Ltas/internal/ipc/Receiver;

    invoke-virtual {v0}, Ltas/internal/ipc/Receiver;->isOnline()Z

    move-result v0

    :goto_0
    return v0

    :cond_0
    const/4 v0, 0x0

    goto :goto_0
.end method

.method public isP2pMode()Z
    .locals 1

    .prologue
    .line 60
    iget-object v0, p0, Ltas/internal/ipc/Transceiver;->mReceiver:Ltas/internal/ipc/Receiver;

    invoke-virtual {v0}, Ltas/internal/ipc/Receiver;->isP2pMode()Z

    move-result v0

    return v0
.end method

.method public offline()V
    .locals 1

    .prologue
    .line 51
    iget-object v0, p0, Ltas/internal/ipc/Transceiver;->mSender:Ltas/internal/ipc/Sender;

    invoke-virtual {v0}, Ltas/internal/ipc/Sender;->offline()V

    .line 52
    iget-object v0, p0, Ltas/internal/ipc/Transceiver;->mReceiver:Ltas/internal/ipc/Receiver;

    invoke-virtual {v0}, Ltas/internal/ipc/Receiver;->offline()V

    .line 50
    return-void
.end method

.method public online()V
    .locals 1

    .prologue
    .line 46
    iget-object v0, p0, Ltas/internal/ipc/Transceiver;->mSender:Ltas/internal/ipc/Sender;

    invoke-virtual {v0}, Ltas/internal/ipc/Sender;->online()V

    .line 47
    iget-object v0, p0, Ltas/internal/ipc/Transceiver;->mReceiver:Ltas/internal/ipc/Receiver;

    invoke-virtual {v0}, Ltas/internal/ipc/Receiver;->online()V

    .line 45
    return-void
.end method

.method public peekExtra()Landroid/os/Bundle;
    .locals 1

    .prologue
    .line 158
    iget-object v0, p0, Ltas/internal/ipc/Transceiver;->mExtra:Landroid/os/Bundle;

    return-object v0
.end method

.method public release()V
    .locals 1

    .prologue
    .line 178
    iget-object v0, p0, Ltas/internal/ipc/Transceiver;->mSender:Ltas/internal/ipc/Sender;

    invoke-virtual {v0}, Ltas/internal/ipc/Sender;->release()V

    .line 179
    iget-object v0, p0, Ltas/internal/ipc/Transceiver;->mReceiver:Ltas/internal/ipc/Receiver;

    invoke-virtual {v0}, Ltas/internal/ipc/Receiver;->release()V

    .line 177
    return-void
.end method

.method public requestAnonymousSession(Ltas/ipc/TransceiverSession$Callback;)V
    .locals 3
    .param p1, "cb"    # Ltas/ipc/TransceiverSession$Callback;

    .prologue
    .line 88
    new-instance v0, Ltas/ipc/TransceiverSession;

    invoke-direct {v0, p1}, Ltas/ipc/TransceiverSession;-><init>(Ltas/ipc/TransceiverSession$Callback;)V

    .line 90
    .local v0, "rs":Ltas/ipc/TransceiverSession;
    new-instance v1, Ltas/internal/ipc/Transceiver$SenderSessionCallbackInner;

    const/4 v2, 0x0

    invoke-direct {v1, v0, v2}, Ltas/internal/ipc/Transceiver$SenderSessionCallbackInner;-><init>(Ltas/ipc/TransceiverSession;Ltas/internal/ipc/Transceiver$SenderSessionCallbackInner;)V

    .line 91
    .local v1, "scb":Ltas/internal/ipc/Transceiver$SenderSessionCallbackInner;
    iget-object v2, p0, Ltas/internal/ipc/Transceiver;->mSender:Ltas/internal/ipc/Sender;

    invoke-virtual {v2, v1}, Ltas/internal/ipc/Sender;->requestAnonymousSession(Ltas/ipc/SenderSession$Callback;)V

    .line 87
    return-void
.end method

.method public requestAnonymousSessionLazily(Ltas/ipc/TransceiverSession$Callback;)Ltas/ipc/TransceiverSession;
    .locals 6
    .param p1, "cb"    # Ltas/ipc/TransceiverSession$Callback;

    .prologue
    const/4 v5, 0x0

    .line 95
    const/4 v2, 0x0

    .line 96
    .local v2, "scb":Ltas/internal/ipc/Transceiver$SenderSessionCallbackInner;
    if-eqz p1, :cond_0

    .line 97
    new-instance v1, Ltas/ipc/TransceiverSession;

    invoke-direct {v1, p1}, Ltas/ipc/TransceiverSession;-><init>(Ltas/ipc/TransceiverSession$Callback;)V

    .line 98
    .local v1, "rs":Ltas/ipc/TransceiverSession;
    new-instance v2, Ltas/internal/ipc/Transceiver$SenderSessionCallbackInner;

    .end local v2    # "scb":Ltas/internal/ipc/Transceiver$SenderSessionCallbackInner;
    invoke-direct {v2, v1, v5}, Ltas/internal/ipc/Transceiver$SenderSessionCallbackInner;-><init>(Ltas/ipc/TransceiverSession;Ltas/internal/ipc/Transceiver$SenderSessionCallbackInner;)V

    .line 101
    .end local v1    # "rs":Ltas/ipc/TransceiverSession;
    :cond_0
    iget-object v4, p0, Ltas/internal/ipc/Transceiver;->mSender:Ltas/internal/ipc/Sender;

    invoke-virtual {v4, v2}, Ltas/internal/ipc/Sender;->requestAnonymousSessionLazily(Ltas/ipc/SenderSession$Callback;)Ltas/ipc/SenderSession;

    move-result-object v3

    .line 102
    .local v3, "ss":Ltas/ipc/SenderSession;
    if-eqz v3, :cond_1

    .line 103
    new-instance v0, Ltas/ipc/TransceiverSession;

    invoke-direct {v0, v5}, Ltas/ipc/TransceiverSession;-><init>(Ltas/ipc/TransceiverSession$Callback;)V

    .line 104
    .local v0, "lazy":Ltas/ipc/TransceiverSession;
    iput-object v3, v0, Ltas/ipc/TransceiverSession;->s:Ltas/ipc/SenderSession;

    .line 105
    return-object v0

    .line 107
    .end local v0    # "lazy":Ltas/ipc/TransceiverSession;
    :cond_1
    return-object v5
.end method

.method public requestOrAcceptAnonymousSession(Ltas/ipc/TransceiverSession$Callback;)V
    .locals 4
    .param p1, "cb"    # Ltas/ipc/TransceiverSession$Callback;

    .prologue
    const/4 v3, 0x0

    .line 118
    new-instance v1, Ltas/ipc/TransceiverSession;

    invoke-direct {v1, p1}, Ltas/ipc/TransceiverSession;-><init>(Ltas/ipc/TransceiverSession$Callback;)V

    .line 120
    .local v1, "rs":Ltas/ipc/TransceiverSession;
    new-instance v2, Ltas/internal/ipc/Transceiver$SenderSessionCallbackInner;

    invoke-direct {v2, v1, v3}, Ltas/internal/ipc/Transceiver$SenderSessionCallbackInner;-><init>(Ltas/ipc/TransceiverSession;Ltas/internal/ipc/Transceiver$SenderSessionCallbackInner;)V

    .line 122
    .local v2, "scb":Ltas/internal/ipc/Transceiver$SenderSessionCallbackInner;
    new-instance v0, Ltas/internal/ipc/Transceiver$ReceiverSessionCallbackInner;

    invoke-direct {v0, v1, v3}, Ltas/internal/ipc/Transceiver$ReceiverSessionCallbackInner;-><init>(Ltas/ipc/TransceiverSession;Ltas/internal/ipc/Transceiver$ReceiverSessionCallbackInner;)V

    .line 123
    .local v0, "rcb":Ltas/internal/ipc/Transceiver$ReceiverSessionCallbackInner;
    iget-object v3, p0, Ltas/internal/ipc/Transceiver;->mSender:Ltas/internal/ipc/Sender;

    invoke-virtual {v3, v2}, Ltas/internal/ipc/Sender;->requestAnonymousSession(Ltas/ipc/SenderSession$Callback;)V

    .line 124
    iget-object v3, p0, Ltas/internal/ipc/Transceiver;->mReceiver:Ltas/internal/ipc/Receiver;

    invoke-virtual {v3, v0}, Ltas/internal/ipc/Receiver;->acceptAnonymousSession(Ltas/ipc/ReceiverSession$Callback;)V

    .line 117
    return-void
.end method

.method public requestOrAcceptAnonymousSessionLazily(Ltas/ipc/TransceiverSession$Callback;)Ltas/ipc/TransceiverSession;
    .locals 7
    .param p1, "cb"    # Ltas/ipc/TransceiverSession$Callback;

    .prologue
    const/4 v6, 0x0

    .line 128
    const/4 v3, 0x0

    .line 129
    .local v3, "scb":Ltas/internal/ipc/Transceiver$SenderSessionCallbackInner;
    const/4 v1, 0x0

    .line 130
    .local v1, "rcb":Ltas/internal/ipc/Transceiver$ReceiverSessionCallbackInner;
    if-eqz p1, :cond_0

    .line 131
    new-instance v2, Ltas/ipc/TransceiverSession;

    invoke-direct {v2, p1}, Ltas/ipc/TransceiverSession;-><init>(Ltas/ipc/TransceiverSession$Callback;)V

    .line 132
    .local v2, "rs":Ltas/ipc/TransceiverSession;
    new-instance v3, Ltas/internal/ipc/Transceiver$SenderSessionCallbackInner;

    .end local v3    # "scb":Ltas/internal/ipc/Transceiver$SenderSessionCallbackInner;
    invoke-direct {v3, v2, v6}, Ltas/internal/ipc/Transceiver$SenderSessionCallbackInner;-><init>(Ltas/ipc/TransceiverSession;Ltas/internal/ipc/Transceiver$SenderSessionCallbackInner;)V

    .line 133
    .local v3, "scb":Ltas/internal/ipc/Transceiver$SenderSessionCallbackInner;
    new-instance v1, Ltas/internal/ipc/Transceiver$ReceiverSessionCallbackInner;

    .end local v1    # "rcb":Ltas/internal/ipc/Transceiver$ReceiverSessionCallbackInner;
    invoke-direct {v1, v2, v6}, Ltas/internal/ipc/Transceiver$ReceiverSessionCallbackInner;-><init>(Ltas/ipc/TransceiverSession;Ltas/internal/ipc/Transceiver$ReceiverSessionCallbackInner;)V

    .line 136
    .end local v2    # "rs":Ltas/ipc/TransceiverSession;
    .end local v3    # "scb":Ltas/internal/ipc/Transceiver$SenderSessionCallbackInner;
    :cond_0
    iget-object v5, p0, Ltas/internal/ipc/Transceiver;->mSender:Ltas/internal/ipc/Sender;

    invoke-virtual {v5, v3}, Ltas/internal/ipc/Sender;->requestAnonymousSessionLazily(Ltas/ipc/SenderSession$Callback;)Ltas/ipc/SenderSession;

    move-result-object v4

    .line 137
    .local v4, "ss":Ltas/ipc/SenderSession;
    if-nez v4, :cond_1

    .line 138
    return-object v6

    .line 141
    :cond_1
    if-eqz v1, :cond_2

    .line 142
    iget-object v5, p0, Ltas/internal/ipc/Transceiver;->mReceiver:Ltas/internal/ipc/Receiver;

    invoke-virtual {v5, v1}, Ltas/internal/ipc/Receiver;->acceptAnonymousSession(Ltas/ipc/ReceiverSession$Callback;)V

    .line 145
    :cond_2
    new-instance v0, Ltas/ipc/TransceiverSession;

    invoke-direct {v0, v6}, Ltas/ipc/TransceiverSession;-><init>(Ltas/ipc/TransceiverSession$Callback;)V

    .line 146
    .local v0, "lazy":Ltas/ipc/TransceiverSession;
    iput-object v4, v0, Ltas/ipc/TransceiverSession;->s:Ltas/ipc/SenderSession;

    .line 147
    return-object v0
.end method

.method public requestOrAcceptSession(Ljava/lang/String;Ltas/ipc/TransceiverSession$Callback;)V
    .locals 4
    .param p1, "name"    # Ljava/lang/String;
    .param p2, "cb"    # Ltas/ipc/TransceiverSession$Callback;

    .prologue
    const/4 v3, 0x0

    .line 78
    new-instance v1, Ltas/ipc/TransceiverSession;

    invoke-direct {v1, p2}, Ltas/ipc/TransceiverSession;-><init>(Ltas/ipc/TransceiverSession$Callback;)V

    .line 80
    .local v1, "rs":Ltas/ipc/TransceiverSession;
    new-instance v2, Ltas/internal/ipc/Transceiver$SenderSessionCallbackInner;

    invoke-direct {v2, v1, v3}, Ltas/internal/ipc/Transceiver$SenderSessionCallbackInner;-><init>(Ltas/ipc/TransceiverSession;Ltas/internal/ipc/Transceiver$SenderSessionCallbackInner;)V

    .line 82
    .local v2, "scb":Ltas/internal/ipc/Transceiver$SenderSessionCallbackInner;
    new-instance v0, Ltas/internal/ipc/Transceiver$ReceiverSessionCallbackInner;

    invoke-direct {v0, v1, v3}, Ltas/internal/ipc/Transceiver$ReceiverSessionCallbackInner;-><init>(Ltas/ipc/TransceiverSession;Ltas/internal/ipc/Transceiver$ReceiverSessionCallbackInner;)V

    .line 83
    .local v0, "rcb":Ltas/internal/ipc/Transceiver$ReceiverSessionCallbackInner;
    iget-object v3, p0, Ltas/internal/ipc/Transceiver;->mSender:Ltas/internal/ipc/Sender;

    invoke-virtual {v3, p1, v2}, Ltas/internal/ipc/Sender;->requestSession(Ljava/lang/String;Ltas/ipc/SenderSession$Callback;)V

    .line 84
    iget-object v3, p0, Ltas/internal/ipc/Transceiver;->mReceiver:Ltas/internal/ipc/Receiver;

    invoke-virtual {v3, p1, v0}, Ltas/internal/ipc/Receiver;->acceptSession(Ljava/lang/String;Ltas/ipc/ReceiverSession$Callback;)V

    .line 77
    return-void
.end method

.method public requestSession(Ljava/lang/String;Ltas/ipc/TransceiverSession$Callback;)V
    .locals 3
    .param p1, "name"    # Ljava/lang/String;
    .param p2, "cb"    # Ltas/ipc/TransceiverSession$Callback;

    .prologue
    .line 64
    new-instance v0, Ltas/ipc/TransceiverSession;

    invoke-direct {v0, p2}, Ltas/ipc/TransceiverSession;-><init>(Ltas/ipc/TransceiverSession$Callback;)V

    .line 66
    .local v0, "rs":Ltas/ipc/TransceiverSession;
    new-instance v1, Ltas/internal/ipc/Transceiver$SenderSessionCallbackInner;

    const/4 v2, 0x0

    invoke-direct {v1, v0, v2}, Ltas/internal/ipc/Transceiver$SenderSessionCallbackInner;-><init>(Ltas/ipc/TransceiverSession;Ltas/internal/ipc/Transceiver$SenderSessionCallbackInner;)V

    .line 67
    .local v1, "scb":Ltas/internal/ipc/Transceiver$SenderSessionCallbackInner;
    iget-object v2, p0, Ltas/internal/ipc/Transceiver;->mSender:Ltas/internal/ipc/Sender;

    invoke-virtual {v2, p1, v1}, Ltas/internal/ipc/Sender;->requestSession(Ljava/lang/String;Ltas/ipc/SenderSession$Callback;)V

    .line 63
    return-void
.end method

.method public setExtra(Landroid/os/Bundle;)V
    .locals 0
    .param p1, "extra"    # Landroid/os/Bundle;

    .prologue
    .line 162
    iput-object p1, p0, Ltas/internal/ipc/Transceiver;->mExtra:Landroid/os/Bundle;

    .line 161
    return-void
.end method

.method public update()V
    .locals 2

    .prologue
    .line 166
    iget-object v0, p0, Ltas/internal/ipc/Transceiver;->mSender:Ltas/internal/ipc/Sender;

    iget-object v1, p0, Ltas/internal/ipc/Transceiver;->mExtra:Landroid/os/Bundle;

    invoke-virtual {v0, v1}, Ltas/internal/ipc/Sender;->setExtra(Landroid/os/Bundle;)V

    .line 167
    iget-object v0, p0, Ltas/internal/ipc/Transceiver;->mReceiver:Ltas/internal/ipc/Receiver;

    iget-object v1, p0, Ltas/internal/ipc/Transceiver;->mExtra:Landroid/os/Bundle;

    invoke-virtual {v0, v1}, Ltas/internal/ipc/Receiver;->setExtra(Landroid/os/Bundle;)V

    .line 168
    iget-object v0, p0, Ltas/internal/ipc/Transceiver;->mSender:Ltas/internal/ipc/Sender;

    invoke-virtual {v0}, Ltas/internal/ipc/Sender;->update()V

    .line 169
    iget-object v0, p0, Ltas/internal/ipc/Transceiver;->mReceiver:Ltas/internal/ipc/Receiver;

    invoke-virtual {v0}, Ltas/internal/ipc/Receiver;->update()V

    .line 165
    return-void
.end method
