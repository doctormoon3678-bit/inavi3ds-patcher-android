.class Ltas/internal/camera/util/CameraMonitor$1$1;
.super Ljava/lang/Object;
.source "CameraMonitor.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ltas/internal/camera/util/CameraMonitor$1;->binderDied()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$1:Ltas/internal/camera/util/CameraMonitor$1;


# direct methods
.method constructor <init>(Ltas/internal/camera/util/CameraMonitor$1;)V
    .locals 0
    .param p1, "this$1"    # Ltas/internal/camera/util/CameraMonitor$1;

    .prologue
    .line 377
    iput-object p1, p0, Ltas/internal/camera/util/CameraMonitor$1$1;->this$1:Ltas/internal/camera/util/CameraMonitor$1;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 2

    .prologue
    .line 381
    iget-object v0, p0, Ltas/internal/camera/util/CameraMonitor$1$1;->this$1:Ltas/internal/camera/util/CameraMonitor$1;

    iget-object v0, v0, Ltas/internal/camera/util/CameraMonitor$1;->this$0:Ltas/internal/camera/util/CameraMonitor;

    invoke-static {v0}, Ltas/internal/camera/util/CameraMonitor;->-get1(Ltas/internal/camera/util/CameraMonitor;)Ltas/internal/camera/util/CameraMonitor$Callback;

    move-result-object v0

    iget-object v1, p0, Ltas/internal/camera/util/CameraMonitor$1$1;->this$1:Ltas/internal/camera/util/CameraMonitor$1;

    iget-object v1, v1, Ltas/internal/camera/util/CameraMonitor$1;->this$0:Ltas/internal/camera/util/CameraMonitor;

    invoke-interface {v0, v1}, Ltas/internal/camera/util/CameraMonitor$Callback;->onMonitorBinderDied(Ltas/internal/camera/util/CameraMonitor;)V

    .line 380
    return-void
.end method
