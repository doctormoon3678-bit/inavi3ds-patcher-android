.class Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide$8;
.super Ljava/lang/Object;
.source "DestArriveGuide.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;->SetData(Lcom/thinkware/sundo/inavi3d/Struct/DestInfo;Lcom/thinkware/sundo/inavi3d/OBD2/OBD2GoalInfo;Lcom/thinkware/sundo/inavi3d/INavi3DActivity;Z)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;


# direct methods
.method constructor <init>(Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;)V
    .locals 0

    .prologue
    .line 1167
    iput-object p1, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide$8;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 8

    .prologue
    const/4 v7, 0x1

    const/4 v6, 0x0

    .line 1172
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide$8;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;->DestInfoTitleLayout1:Landroid/widget/RelativeLayout;

    invoke-virtual {v3, v6}, Landroid/widget/RelativeLayout;->setVisibility(I)V

    .line 1173
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide$8;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;->DestInfoTitleLayout2:Landroid/widget/RelativeLayout;

    const/16 v4, 0x8

    invoke-virtual {v3, v4}, Landroid/widget/RelativeLayout;->setVisibility(I)V

    .line 1174
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide$8;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;

    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide$8;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;

    invoke-static {v4}, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;->access$500(Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;)Landroid/content/res/Resources;

    move-result-object v4

    const v5, 0x7f020342

    invoke-virtual {v4, v5}, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v4

    invoke-virtual {v3, v4}, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 1175
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide$8;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;->DestInfoDetail:Landroid/widget/Button;

    invoke-virtual {v3, v6}, Landroid/widget/Button;->setVisibility(I)V

    .line 1176
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide$8;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;->DestInfoAround:Landroid/widget/Button;

    invoke-virtual {v3, v6}, Landroid/widget/Button;->setVisibility(I)V

    .line 1177
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide$8;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;->DestInfoRoadview:Landroid/widget/Button;

    invoke-virtual {v3, v6}, Landroid/widget/Button;->setVisibility(I)V

    .line 1178
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide$8;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;->DestInfoFivepin:Landroid/widget/Button;

    invoke-virtual {v3, v6}, Landroid/widget/Button;->setVisibility(I)V

    .line 1180
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide$8;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;->DestInfoTitle:Landroid/widget/TextView;

    if-eqz v3, :cond_0

    .line 1181
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide$8;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;->DestInfoTitle:Landroid/widget/TextView;

    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide$8;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;

    invoke-static {v4}, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;->access$600(Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1182
    :cond_0
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide$8;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;->DestInfoDetail:Landroid/widget/Button;

    invoke-virtual {v3}, Landroid/widget/Button;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    .line 1183
    .local v0, "drawable":Landroid/graphics/drawable/Drawable;
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide$8;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;

    invoke-static {v3}, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;->access$700(Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;)I

    move-result v3

    if-nez v3, :cond_1

    .line 1185
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide$8;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;->DestInfoDetail:Landroid/widget/Button;

    invoke-virtual {v3, v6}, Landroid/widget/Button;->setEnabled(Z)V

    .line 1186
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide$8;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;->DestInfoDetail:Landroid/widget/Button;

    invoke-virtual {v3, v6}, Landroid/widget/Button;->setClickable(Z)V

    .line 1187
    const/16 v3, 0x4b

    invoke-virtual {v0, v3}, Landroid/graphics/drawable/Drawable;->setAlpha(I)V

    .line 1193
    :goto_0
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide$8;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;->DestInfoAround:Landroid/widget/Button;

    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide$8;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;

    invoke-static {v4}, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;->access$800(Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 1195
    new-instance v1, Landroid/widget/RelativeLayout$LayoutParams;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide$8;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;->DestInfoDetail:Landroid/widget/Button;

    invoke-virtual {v3}, Landroid/widget/Button;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v3

    invoke-direct {v1, v3}, Landroid/widget/RelativeLayout$LayoutParams;-><init>(Landroid/view/ViewGroup$LayoutParams;)V

    .line 1196
    .local v1, "params":Landroid/widget/RelativeLayout$LayoutParams;
    const/16 v3, 0x15d

    const/16 v4, 0x160

    invoke-virtual {v1, v3, v4, v6, v6}, Landroid/widget/RelativeLayout$LayoutParams;->setMargins(IIII)V

    .line 1197
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide$8;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;->DestInfoDetail:Landroid/widget/Button;

    invoke-virtual {v3, v1}, Landroid/widget/Button;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 1198
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide$8;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;->DestInfoDetail:Landroid/widget/Button;

    invoke-virtual {v3}, Landroid/widget/Button;->requestLayout()V

    .line 1200
    new-instance v2, Landroid/widget/RelativeLayout$LayoutParams;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide$8;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;->DestInfoAround:Landroid/widget/Button;

    invoke-virtual {v3}, Landroid/widget/Button;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v3

    invoke-direct {v2, v3}, Landroid/widget/RelativeLayout$LayoutParams;-><init>(Landroid/view/ViewGroup$LayoutParams;)V

    .line 1201
    .local v2, "params1":Landroid/widget/RelativeLayout$LayoutParams;
    const/16 v3, 0x11

    const/16 v4, 0x195

    invoke-virtual {v2, v3, v4, v6, v6}, Landroid/widget/RelativeLayout$LayoutParams;->setMargins(IIII)V

    .line 1202
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide$8;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;->DestInfoAround:Landroid/widget/Button;

    invoke-virtual {v3, v2}, Landroid/widget/Button;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 1203
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide$8;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;->DestInfoAround:Landroid/widget/Button;

    invoke-virtual {v3}, Landroid/widget/Button;->requestLayout()V

    .line 1204
    return-void

    .line 1189
    .end local v1    # "params":Landroid/widget/RelativeLayout$LayoutParams;
    .end local v2    # "params1":Landroid/widget/RelativeLayout$LayoutParams;
    :cond_1
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide$8;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;->DestInfoDetail:Landroid/widget/Button;

    invoke-virtual {v3, v7}, Landroid/widget/Button;->setEnabled(Z)V

    .line 1190
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide$8;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;->DestInfoDetail:Landroid/widget/Button;

    invoke-virtual {v3, v7}, Landroid/widget/Button;->setClickable(Z)V

    .line 1191
    const/16 v3, 0xff

    invoke-virtual {v0, v3}, Landroid/graphics/drawable/Drawable;->setAlpha(I)V

    goto :goto_0
.end method
