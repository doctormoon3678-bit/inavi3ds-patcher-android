.class public final Ltas/internal/iobrigade/connector/EventNodeHelper;
.super Ltas/internal/iobrigade/connector/EventNode;
.source "EventNodeHelper.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ltas/internal/iobrigade/connector/EventNode",
        "<TT;>;"
    }
.end annotation


# instance fields
.field private mNativeCtx:Ltas/internal/iobrigade/connector/Consumer$IoBrigadeConnectNativeContext;


# direct methods
.method protected constructor <init>(Ljava/lang/Class;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Class",
            "<TT;>;)V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/InstantiationException;,
            Ljava/lang/IllegalAccessException;
        }
    .end annotation

    .prologue
    .line 24
    .local p0, "this":Ltas/internal/iobrigade/connector/EventNodeHelper;, "Ltas/internal/iobrigade/connector/EventNodeHelper<TT;>;"
    .local p1, "clazz":Ljava/lang/Class;, "Ljava/lang/Class<TT;>;"
    invoke-virtual {p1}, Ljava/lang/Class;->newInstance()Ljava/lang/Object;

    move-result-object v0

    invoke-direct {p0, v0}, Ltas/internal/iobrigade/connector/EventNode;-><init>(Ljava/lang/Object;)V

    .line 23
    return-void
.end method

.method private newNativeContext(I)Ltas/internal/iobrigade/connector/Consumer$IoBrigadeConnectNativeContext;
    .locals 2
    .param p1, "attr"    # I

    .prologue
    .line 38
    .local p0, "this":Ltas/internal/iobrigade/connector/EventNodeHelper;, "Ltas/internal/iobrigade/connector/EventNodeHelper<TT;>;"
    new-instance v0, Ltas/internal/iobrigade/connector/Consumer$IoBrigadeConnectNativeContext;

    iget-object v1, p0, Ltas/internal/iobrigade/connector/EventNodeHelper;->mConsumer:Ltas/internal/iobrigade/connector/Consumer;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {v0, v1, p1}, Ltas/internal/iobrigade/connector/Consumer$IoBrigadeConnectNativeContext;-><init>(Ltas/internal/iobrigade/connector/Consumer;I)V

    return-object v0
.end method

.method public static newNode(Ljava/lang/Class;)Ltas/internal/iobrigade/connector/EventNode;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<I:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/lang/Class",
            "<TI;>;)",
            "Ltas/internal/iobrigade/connector/EventNode",
            "<TI;>;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/InstantiationException;,
            Ljava/lang/IllegalAccessException;
        }
    .end annotation

    .prologue
    .line 29
    .local p0, "cname":Ljava/lang/Class;, "Ljava/lang/Class<TI;>;"
    new-instance v0, Ltas/internal/iobrigade/connector/EventNodeHelper;

    invoke-direct {v0, p0}, Ltas/internal/iobrigade/connector/EventNodeHelper;-><init>(Ljava/lang/Class;)V

    return-object v0
.end method

.method private setupNativeContextLink(Landroid/os/Handler;)V
    .locals 1
    .param p1, "h"    # Landroid/os/Handler;

    .prologue
    .line 33
    .local p0, "this":Ltas/internal/iobrigade/connector/EventNodeHelper;, "Ltas/internal/iobrigade/connector/EventNodeHelper<TT;>;"
    iget v0, p0, Ltas/internal/iobrigade/connector/EventNodeHelper;->mAttributes:I

    invoke-direct {p0, v0}, Ltas/internal/iobrigade/connector/EventNodeHelper;->newNativeContext(I)Ltas/internal/iobrigade/connector/Consumer$IoBrigadeConnectNativeContext;

    move-result-object v0

    iput-object v0, p0, Ltas/internal/iobrigade/connector/EventNodeHelper;->mNativeCtx:Ltas/internal/iobrigade/connector/Consumer$IoBrigadeConnectNativeContext;

    .line 34
    iget-object v0, p0, Ltas/internal/iobrigade/connector/EventNodeHelper;->mNativeCtx:Ltas/internal/iobrigade/connector/Consumer$IoBrigadeConnectNativeContext;

    invoke-virtual {v0, p1}, Ltas/internal/iobrigade/connector/Consumer$IoBrigadeConnectNativeContext;->setHandler(Landroid/os/Handler;)V

    .line 32
    return-void
.end method


# virtual methods
.method public notifyConsumerReady()V
    .locals 2

    .prologue
    .line 60
    .local p0, "this":Ltas/internal/iobrigade/connector/EventNodeHelper;, "Ltas/internal/iobrigade/connector/EventNodeHelper<TT;>;"
    iget-object v0, p0, Ltas/internal/iobrigade/connector/EventNodeHelper;->mNativeCtx:Ltas/internal/iobrigade/connector/Consumer$IoBrigadeConnectNativeContext;

    iget-object v1, p0, Ltas/internal/iobrigade/connector/EventNodeHelper;->mConsumer:Ltas/internal/iobrigade/connector/Consumer;

    invoke-virtual {v1}, Ltas/internal/iobrigade/connector/Consumer;->getConnParamTypeName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ltas/internal/iobrigade/connector/Consumer$IoBrigadeConnectNativeContext;->nativeNotifyConsumerReady(Ljava/lang/String;)V

    .line 59
    return-void
.end method

.method public sendMessageWith(Ljava/lang/String;)V
    .locals 2
    .param p1, "msgString"    # Ljava/lang/String;

    .prologue
    .line 70
    .local p0, "this":Ltas/internal/iobrigade/connector/EventNodeHelper;, "Ltas/internal/iobrigade/connector/EventNodeHelper<TT;>;"
    iget-object v0, p0, Ltas/internal/iobrigade/connector/EventNodeHelper;->mNativeCtx:Ltas/internal/iobrigade/connector/Consumer$IoBrigadeConnectNativeContext;

    iget-object v1, p0, Ltas/internal/iobrigade/connector/EventNodeHelper;->mConsumer:Ltas/internal/iobrigade/connector/Consumer;

    invoke-virtual {v1}, Ltas/internal/iobrigade/connector/Consumer;->getConnParamTypeName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1, p1}, Ltas/internal/iobrigade/connector/Consumer$IoBrigadeConnectNativeContext;->nativeSendMsgTo(Ljava/lang/String;Ljava/lang/String;)V

    .line 69
    return-void
.end method

.method public setAttributes(I)V
    .locals 0
    .param p1, "attribute"    # I

    .prologue
    .line 65
    .local p0, "this":Ltas/internal/iobrigade/connector/EventNodeHelper;, "Ltas/internal/iobrigade/connector/EventNodeHelper<TT;>;"
    iput p1, p0, Ltas/internal/iobrigade/connector/EventNodeHelper;->mAttributes:I

    .line 64
    return-void
.end method

.method public setConsumer(Ltas/internal/iobrigade/connector/IRemoteIOEvent;)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ltas/internal/iobrigade/connector/IRemoteIOEvent",
            "<TT;>;)V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/NullPointerException;
        }
    .end annotation

    .prologue
    .local p0, "this":Ltas/internal/iobrigade/connector/EventNodeHelper;, "Ltas/internal/iobrigade/connector/EventNodeHelper<TT;>;"
    .local p1, "listener":Ltas/internal/iobrigade/connector/IRemoteIOEvent;, "Ltas/internal/iobrigade/connector/IRemoteIOEvent<TT;>;"
    const/4 v3, 0x0

    .line 44
    if-nez p1, :cond_0

    .line 45
    new-instance v1, Ljava/lang/NullPointerException;

    const-string/jumbo v2, "listener is null"

    invoke-direct {v1, v2}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    throw v1

    .line 47
    :cond_0
    new-instance v0, Ltas/internal/iobrigade/connector/EventNodeHelper$1;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v2

    const/4 v4, 0x1

    move-object v1, p0

    move-object v5, p1

    invoke-direct/range {v0 .. v5}, Ltas/internal/iobrigade/connector/EventNodeHelper$1;-><init>(Ltas/internal/iobrigade/connector/EventNodeHelper;Landroid/os/Looper;Landroid/os/Handler$Callback;ZLtas/internal/iobrigade/connector/IRemoteIOEvent;)V

    .line 55
    .local v0, "h":Landroid/os/Handler;
    invoke-direct {p0, v0}, Ltas/internal/iobrigade/connector/EventNodeHelper;->setupNativeContextLink(Landroid/os/Handler;)V

    .line 42
    return-void
.end method
