.class final Ltas/internal/ipc/server/RemoteReceiver$1;
.super Ljava/lang/Object;
.source "RemoteReceiver.java"

# interfaces
.implements Landroid/os/Parcelable$Creator;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltas/internal/ipc/server/RemoteReceiver;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Landroid/os/Parcelable$Creator",
        "<",
        "Ltas/internal/ipc/server/RemoteReceiver;",
        ">;"
    }
.end annotation


# direct methods
.method constructor <init>()V
    .locals 0

    .prologue
    .line 35
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public bridge synthetic createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;
    .locals 1
    .param p1, "source"    # Landroid/os/Parcel;

    .prologue
    .line 36
    invoke-virtual {p0, p1}, Ltas/internal/ipc/server/RemoteReceiver$1;->createFromParcel(Landroid/os/Parcel;)Ltas/internal/ipc/server/RemoteReceiver;

    move-result-object v0

    return-object v0
.end method

.method public createFromParcel(Landroid/os/Parcel;)Ltas/internal/ipc/server/RemoteReceiver;
    .locals 2
    .param p1, "source"    # Landroid/os/Parcel;

    .prologue
    const/4 v1, 0x0

    .line 38
    new-instance v0, Ltas/internal/ipc/server/RemoteReceiver;

    invoke-direct {v0, v1, v1}, Ltas/internal/ipc/server/RemoteReceiver;-><init>(Ltas/internal/ipc/server/RemoteReceiver;Ltas/internal/ipc/server/RemoteReceiver;)V

    .line 39
    .local v0, "r":Ltas/internal/ipc/server/RemoteReceiver;
    invoke-virtual {v0, p1}, Ltas/internal/ipc/server/RemoteReceiver;->readFromParcel(Landroid/os/Parcel;)V

    .line 40
    return-object v0
.end method

.method public bridge synthetic newArray(I)[Ljava/lang/Object;
    .locals 1
    .param p1, "size"    # I

    .prologue
    .line 43
    invoke-virtual {p0, p1}, Ltas/internal/ipc/server/RemoteReceiver$1;->newArray(I)[Ltas/internal/ipc/server/RemoteReceiver;

    move-result-object v0

    return-object v0
.end method

.method public newArray(I)[Ltas/internal/ipc/server/RemoteReceiver;
    .locals 1
    .param p1, "size"    # I

    .prologue
    .line 44
    new-array v0, p1, [Ltas/internal/ipc/server/RemoteReceiver;

    return-object v0
.end method
