.class public Ltas/ipc/MsgReceiver;
.super Ljava/lang/Object;
.source "MsgReceiver.java"


# instance fields
.field private IMPL:Ltas/internal/ipc/Receiver;


# direct methods
.method public constructor <init>(Landroid/content/Context;Ljava/lang/String;Landroid/os/Looper;)V
    .locals 1
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "name"    # Ljava/lang/String;
    .param p3, "looper"    # Landroid/os/Looper;

    .prologue
    .line 54
    const/4 v0, 0x0

    invoke-direct {p0, p1, p2, p3, v0}, Ltas/ipc/MsgReceiver;-><init>(Landroid/content/Context;Ljava/lang/String;Landroid/os/Looper;Ljava/lang/Class;)V

    .line 53
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Ljava/lang/String;Landroid/os/Looper;Ljava/lang/Class;)V
    .locals 1
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "name"    # Ljava/lang/String;
    .param p3, "looper"    # Landroid/os/Looper;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/lang/String;",
            "Landroid/os/Looper;",
            "Ljava/lang/Class",
            "<+",
            "Ltas/ipc/MsgReceiverService;",
            ">;)V"
        }
    .end annotation

    .prologue
    .line 63
    .local p4, "srvcls":Ljava/lang/Class;, "Ljava/lang/Class<+Ltas/ipc/MsgReceiverService;>;"
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 66
    new-instance v0, Ltas/internal/ipc/Receiver;

    invoke-direct {v0, p1, p2, p3, p4}, Ltas/internal/ipc/Receiver;-><init>(Landroid/content/Context;Ljava/lang/String;Landroid/os/Looper;Ljava/lang/Class;)V

    iput-object v0, p0, Ltas/ipc/MsgReceiver;->IMPL:Ltas/internal/ipc/Receiver;

    .line 65
    return-void
.end method


# virtual methods
.method public acceptAnonymousSession(Ltas/ipc/ReceiverSession$Callback;)V
    .locals 1
    .param p1, "cb"    # Ltas/ipc/ReceiverSession$Callback;

    .prologue
    .line 108
    iget-object v0, p0, Ltas/ipc/MsgReceiver;->IMPL:Ltas/internal/ipc/Receiver;

    invoke-virtual {v0, p1}, Ltas/internal/ipc/Receiver;->acceptAnonymousSession(Ltas/ipc/ReceiverSession$Callback;)V

    .line 107
    return-void
.end method

.method public acceptSession(Ljava/lang/String;Ltas/ipc/ReceiverSession$Callback;)V
    .locals 1
    .param p1, "name"    # Ljava/lang/String;
    .param p2, "cb"    # Ltas/ipc/ReceiverSession$Callback;

    .prologue
    .line 99
    if-eqz p1, :cond_0

    if-eqz p2, :cond_0

    iget-object v0, p0, Ltas/ipc/MsgReceiver;->IMPL:Ltas/internal/ipc/Receiver;

    invoke-virtual {v0, p1, p2}, Ltas/internal/ipc/Receiver;->acceptSession(Ljava/lang/String;Ltas/ipc/ReceiverSession$Callback;)V

    .line 98
    :cond_0
    return-void
.end method

.method public destroySession(I)V
    .locals 4
    .param p1, "id"    # I

    .prologue
    .line 115
    iget-object v0, p0, Ltas/ipc/MsgReceiver;->IMPL:Ltas/internal/ipc/Receiver;

    int-to-long v2, p1

    invoke-virtual {v0, v2, v3}, Ltas/internal/ipc/Receiver;->destroySession(J)V

    .line 114
    return-void
.end method

.method public getExtra()Landroid/os/Bundle;
    .locals 1

    .prologue
    .line 123
    iget-object v0, p0, Ltas/ipc/MsgReceiver;->IMPL:Ltas/internal/ipc/Receiver;

    invoke-virtual {v0}, Ltas/internal/ipc/Receiver;->getExtra()Landroid/os/Bundle;

    move-result-object v0

    return-object v0
.end method

.method public isOnline()Z
    .locals 1

    .prologue
    .line 89
    iget-object v0, p0, Ltas/ipc/MsgReceiver;->IMPL:Ltas/internal/ipc/Receiver;

    invoke-virtual {v0}, Ltas/internal/ipc/Receiver;->isOnline()Z

    move-result v0

    return v0
.end method

.method public isP2pMode()Z
    .locals 1

    .prologue
    .line 70
    iget-object v0, p0, Ltas/ipc/MsgReceiver;->IMPL:Ltas/internal/ipc/Receiver;

    invoke-virtual {v0}, Ltas/internal/ipc/Receiver;->isP2pMode()Z

    move-result v0

    return v0
.end method

.method public offline()V
    .locals 1

    .prologue
    .line 85
    iget-object v0, p0, Ltas/ipc/MsgReceiver;->IMPL:Ltas/internal/ipc/Receiver;

    invoke-virtual {v0}, Ltas/internal/ipc/Receiver;->offline()V

    .line 84
    return-void
.end method

.method public online()V
    .locals 1

    .prologue
    .line 78
    iget-object v0, p0, Ltas/ipc/MsgReceiver;->IMPL:Ltas/internal/ipc/Receiver;

    invoke-virtual {v0}, Ltas/internal/ipc/Receiver;->online()V

    .line 77
    return-void
.end method

.method public peekExtra()Landroid/os/Bundle;
    .locals 1

    .prologue
    .line 130
    iget-object v0, p0, Ltas/ipc/MsgReceiver;->IMPL:Ltas/internal/ipc/Receiver;

    invoke-virtual {v0}, Ltas/internal/ipc/Receiver;->peekExtra()Landroid/os/Bundle;

    move-result-object v0

    return-object v0
.end method

.method public release()V
    .locals 1

    .prologue
    .line 151
    iget-object v0, p0, Ltas/ipc/MsgReceiver;->IMPL:Ltas/internal/ipc/Receiver;

    invoke-virtual {v0}, Ltas/internal/ipc/Receiver;->release()V

    .line 150
    return-void
.end method

.method public setExtra(Landroid/os/Bundle;)V
    .locals 1
    .param p1, "extra"    # Landroid/os/Bundle;

    .prologue
    .line 138
    iget-object v0, p0, Ltas/ipc/MsgReceiver;->IMPL:Ltas/internal/ipc/Receiver;

    invoke-virtual {v0, p1}, Ltas/internal/ipc/Receiver;->setExtra(Landroid/os/Bundle;)V

    .line 137
    return-void
.end method

.method public update()V
    .locals 1

    .prologue
    .line 147
    iget-object v0, p0, Ltas/ipc/MsgReceiver;->IMPL:Ltas/internal/ipc/Receiver;

    invoke-virtual {v0}, Ltas/internal/ipc/Receiver;->update()V

    .line 146
    return-void
.end method
