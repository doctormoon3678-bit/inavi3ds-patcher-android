.class public Ltas/ipc/MsgData;
.super Ljava/lang/Object;
.source "MsgData.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ltas/ipc/MsgData$1;
    }
.end annotation


# static fields
.field private static final CALLBACK:Ltas/internal/ipc/util/SyncdPool$Callback;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ltas/internal/ipc/util/SyncdPool$Callback",
            "<",
            "Ltas/ipc/MsgData;",
            ">;"
        }
    .end annotation
.end field

.field private static final sPool:Ltas/internal/ipc/util/SyncdPool;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ltas/internal/ipc/util/SyncdPool",
            "<",
            "Ltas/ipc/MsgData;",
            ">;"
        }
    .end annotation
.end field

.field private static sPoolId:I

.field private static sStamp:I


# instance fields
.field public arg1:I

.field public arg2:I

.field public args:[I

.field public bundle:Landroid/os/Bundle;

.field public bytes:[B

.field private mAllocated:Z

.field private next:Ltas/ipc/MsgData;

.field private pool:I

.field public stamp:I

.field public str1:Ljava/lang/String;

.field public str2:Ljava/lang/String;

.field public what:I


# direct methods
.method static synthetic -get0(Ltas/ipc/MsgData;)Ltas/ipc/MsgData;
    .locals 1

    iget-object v0, p0, Ltas/ipc/MsgData;->next:Ltas/ipc/MsgData;

    return-object v0
.end method

.method static synthetic -get1()I
    .locals 1

    sget v0, Ltas/ipc/MsgData;->sPoolId:I

    return v0
.end method

.method static synthetic -set0(Ltas/ipc/MsgData;Ltas/ipc/MsgData;)Ltas/ipc/MsgData;
    .locals 0

    iput-object p1, p0, Ltas/ipc/MsgData;->next:Ltas/ipc/MsgData;

    return-object p1
.end method

.method static synthetic -set1(Ltas/ipc/MsgData;I)I
    .locals 0

    iput p1, p0, Ltas/ipc/MsgData;->pool:I

    return p1
.end method

.method static synthetic -set2(I)I
    .locals 0

    sput p0, Ltas/ipc/MsgData;->sPoolId:I

    return p0
.end method

.method static constructor <clinit>()V
    .locals 3

    .prologue
    const/4 v2, 0x0

    .line 181
    new-instance v0, Ltas/ipc/MsgData$1;

    invoke-direct {v0}, Ltas/ipc/MsgData$1;-><init>()V

    .line 180
    sput-object v0, Ltas/ipc/MsgData;->CALLBACK:Ltas/internal/ipc/util/SyncdPool$Callback;

    .line 198
    new-instance v0, Ltas/internal/ipc/util/SyncdPool;

    sget-object v1, Ltas/ipc/MsgData;->CALLBACK:Ltas/internal/ipc/util/SyncdPool$Callback;

    invoke-direct {v0, v1}, Ltas/internal/ipc/util/SyncdPool;-><init>(Ltas/internal/ipc/util/SyncdPool$Callback;)V

    .line 197
    sput-object v0, Ltas/ipc/MsgData;->sPool:Ltas/internal/ipc/util/SyncdPool;

    .line 199
    sput v2, Ltas/ipc/MsgData;->sStamp:I

    .line 200
    sput v2, Ltas/ipc/MsgData;->sPoolId:I

    .line 19
    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .prologue
    .line 161
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 62
    const/4 v0, -0x1

    iput v0, p0, Ltas/ipc/MsgData;->stamp:I

    .line 161
    return-void
.end method

.method public constructor <init>(Ltas/ipc/MsgData;)V
    .locals 1
    .param p1, "msg"    # Ltas/ipc/MsgData;

    .prologue
    .line 164
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 62
    const/4 v0, -0x1

    iput v0, p0, Ltas/ipc/MsgData;->stamp:I

    .line 165
    invoke-virtual {p0, p1}, Ltas/ipc/MsgData;->copyFrom(Ltas/ipc/MsgData;)V

    .line 164
    return-void
.end method

.method public static createFromParcel(Landroid/os/Parcel;)Ltas/ipc/MsgData;
    .locals 2
    .param p0, "source"    # Landroid/os/Parcel;

    .prologue
    .line 286
    sget-object v1, Ltas/ipc/MsgData;->sPool:Ltas/internal/ipc/util/SyncdPool;

    invoke-virtual {v1}, Ltas/internal/ipc/util/SyncdPool;->allocate()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/ipc/MsgData;

    .line 287
    .local v0, "msg":Ltas/ipc/MsgData;
    invoke-virtual {v0, p0}, Ltas/ipc/MsgData;->readFromParcel(Landroid/os/Parcel;)V

    .line 288
    const/4 v1, 0x1

    iput-boolean v1, v0, Ltas/ipc/MsgData;->mAllocated:Z

    .line 289
    return-object v0
.end method

.method public static obtain()Ltas/ipc/MsgData;
    .locals 3

    .prologue
    .line 151
    sget-object v1, Ltas/ipc/MsgData;->sPool:Ltas/internal/ipc/util/SyncdPool;

    invoke-virtual {v1}, Ltas/internal/ipc/util/SyncdPool;->allocate()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/ipc/MsgData;

    .line 152
    .local v0, "msg":Ltas/ipc/MsgData;
    sget v1, Ltas/ipc/MsgData;->sStamp:I

    add-int/lit8 v2, v1, 0x1

    sput v2, Ltas/ipc/MsgData;->sStamp:I

    iput v1, v0, Ltas/ipc/MsgData;->stamp:I

    .line 153
    const/4 v1, 0x1

    iput-boolean v1, v0, Ltas/ipc/MsgData;->mAllocated:Z

    .line 154
    return-object v0
.end method

.method public static obtain(I)Ltas/ipc/MsgData;
    .locals 1
    .param p0, "what"    # I

    .prologue
    .line 65
    invoke-static {}, Ltas/ipc/MsgData;->obtain()Ltas/ipc/MsgData;

    move-result-object v0

    .line 66
    .local v0, "msg":Ltas/ipc/MsgData;
    iput p0, v0, Ltas/ipc/MsgData;->what:I

    .line 67
    return-object v0
.end method

.method public static obtain(III)Ltas/ipc/MsgData;
    .locals 1
    .param p0, "what"    # I
    .param p1, "arg1"    # I
    .param p2, "arg2"    # I

    .prologue
    .line 71
    invoke-static {}, Ltas/ipc/MsgData;->obtain()Ltas/ipc/MsgData;

    move-result-object v0

    .line 72
    .local v0, "msg":Ltas/ipc/MsgData;
    iput p0, v0, Ltas/ipc/MsgData;->what:I

    .line 73
    iput p1, v0, Ltas/ipc/MsgData;->arg1:I

    .line 74
    iput p2, v0, Ltas/ipc/MsgData;->arg2:I

    .line 75
    return-object v0
.end method

.method public static varargs obtain(III[I)Ltas/ipc/MsgData;
    .locals 1
    .param p0, "what"    # I
    .param p1, "arg1"    # I
    .param p2, "arg2"    # I
    .param p3, "args"    # [I

    .prologue
    .line 80
    invoke-static {}, Ltas/ipc/MsgData;->obtain()Ltas/ipc/MsgData;

    move-result-object v0

    .line 81
    .local v0, "msg":Ltas/ipc/MsgData;
    iput p0, v0, Ltas/ipc/MsgData;->what:I

    .line 82
    iput p1, v0, Ltas/ipc/MsgData;->arg1:I

    .line 83
    iput p2, v0, Ltas/ipc/MsgData;->arg2:I

    .line 84
    iput-object p3, v0, Ltas/ipc/MsgData;->args:[I

    .line 85
    return-object v0
.end method

.method public static obtain(III[ILjava/lang/String;Ljava/lang/String;[BLandroid/os/Bundle;)Ltas/ipc/MsgData;
    .locals 1
    .param p0, "what"    # I
    .param p1, "arg1"    # I
    .param p2, "arg2"    # I
    .param p3, "args"    # [I
    .param p4, "str1"    # Ljava/lang/String;
    .param p5, "str2"    # Ljava/lang/String;
    .param p6, "bytes"    # [B
    .param p7, "bundle"    # Landroid/os/Bundle;

    .prologue
    .line 131
    invoke-static {}, Ltas/ipc/MsgData;->obtain()Ltas/ipc/MsgData;

    move-result-object v0

    .line 132
    .local v0, "msg":Ltas/ipc/MsgData;
    iput p0, v0, Ltas/ipc/MsgData;->what:I

    .line 133
    iput p1, v0, Ltas/ipc/MsgData;->arg1:I

    .line 134
    iput p2, v0, Ltas/ipc/MsgData;->arg2:I

    .line 135
    iput-object p3, v0, Ltas/ipc/MsgData;->args:[I

    .line 136
    iput-object p4, v0, Ltas/ipc/MsgData;->str1:Ljava/lang/String;

    .line 137
    iput-object p5, v0, Ltas/ipc/MsgData;->str2:Ljava/lang/String;

    .line 138
    iput-object p6, v0, Ltas/ipc/MsgData;->bytes:[B

    .line 139
    iput-object p7, v0, Ltas/ipc/MsgData;->bundle:Landroid/os/Bundle;

    .line 140
    return-object v0
.end method

.method public static obtain(ILandroid/os/Bundle;)Ltas/ipc/MsgData;
    .locals 1
    .param p0, "what"    # I
    .param p1, "bundle"    # Landroid/os/Bundle;

    .prologue
    .line 119
    invoke-static {}, Ltas/ipc/MsgData;->obtain()Ltas/ipc/MsgData;

    move-result-object v0

    .line 120
    .local v0, "msg":Ltas/ipc/MsgData;
    iput p0, v0, Ltas/ipc/MsgData;->what:I

    .line 121
    iput-object p1, v0, Ltas/ipc/MsgData;->bundle:Landroid/os/Bundle;

    .line 122
    return-object v0
.end method

.method public static obtain(ILjava/lang/String;)Ltas/ipc/MsgData;
    .locals 1
    .param p0, "what"    # I
    .param p1, "str1"    # Ljava/lang/String;

    .prologue
    .line 89
    invoke-static {}, Ltas/ipc/MsgData;->obtain()Ltas/ipc/MsgData;

    move-result-object v0

    .line 90
    .local v0, "msg":Ltas/ipc/MsgData;
    iput p0, v0, Ltas/ipc/MsgData;->what:I

    .line 91
    iput-object p1, v0, Ltas/ipc/MsgData;->str1:Ljava/lang/String;

    .line 92
    return-object v0
.end method

.method public static obtain(ILjava/lang/String;Ljava/lang/String;)Ltas/ipc/MsgData;
    .locals 1
    .param p0, "what"    # I
    .param p1, "str1"    # Ljava/lang/String;
    .param p2, "str2"    # Ljava/lang/String;

    .prologue
    .line 97
    invoke-static {}, Ltas/ipc/MsgData;->obtain()Ltas/ipc/MsgData;

    move-result-object v0

    .line 98
    .local v0, "msg":Ltas/ipc/MsgData;
    iput p0, v0, Ltas/ipc/MsgData;->what:I

    .line 99
    iput-object p1, v0, Ltas/ipc/MsgData;->str1:Ljava/lang/String;

    .line 100
    iput-object p2, v0, Ltas/ipc/MsgData;->str2:Ljava/lang/String;

    .line 101
    return-object v0
.end method

.method public static obtain(I[B)Ltas/ipc/MsgData;
    .locals 1
    .param p0, "what"    # I
    .param p1, "bytes"    # [B

    .prologue
    .line 112
    invoke-static {}, Ltas/ipc/MsgData;->obtain()Ltas/ipc/MsgData;

    move-result-object v0

    .line 113
    .local v0, "msg":Ltas/ipc/MsgData;
    iput p0, v0, Ltas/ipc/MsgData;->what:I

    .line 114
    iput-object p1, v0, Ltas/ipc/MsgData;->bytes:[B

    .line 115
    return-object v0
.end method

.method public static obtain(I[I)Ltas/ipc/MsgData;
    .locals 1
    .param p0, "what"    # I
    .param p1, "args"    # [I

    .prologue
    .line 105
    invoke-static {}, Ltas/ipc/MsgData;->obtain()Ltas/ipc/MsgData;

    move-result-object v0

    .line 106
    .local v0, "msg":Ltas/ipc/MsgData;
    iput p0, v0, Ltas/ipc/MsgData;->what:I

    .line 107
    iput-object p1, v0, Ltas/ipc/MsgData;->args:[I

    .line 108
    return-object v0
.end method

.method public static obtain(Ltas/ipc/MsgData;)Ltas/ipc/MsgData;
    .locals 2
    .param p0, "that"    # Ltas/ipc/MsgData;

    .prologue
    .line 144
    sget-object v1, Ltas/ipc/MsgData;->sPool:Ltas/internal/ipc/util/SyncdPool;

    invoke-virtual {v1}, Ltas/internal/ipc/util/SyncdPool;->allocate()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/ipc/MsgData;

    .line 145
    .local v0, "msg":Ltas/ipc/MsgData;
    invoke-virtual {v0, p0}, Ltas/ipc/MsgData;->copyFrom(Ltas/ipc/MsgData;)V

    .line 146
    const/4 v1, 0x1

    iput-boolean v1, v0, Ltas/ipc/MsgData;->mAllocated:Z

    .line 147
    return-object v0
.end method


# virtual methods
.method public clear()V
    .locals 2

    .prologue
    const/4 v1, 0x0

    const/4 v0, 0x0

    .line 206
    iput v1, p0, Ltas/ipc/MsgData;->what:I

    .line 207
    iput v1, p0, Ltas/ipc/MsgData;->arg1:I

    .line 208
    iput v1, p0, Ltas/ipc/MsgData;->arg2:I

    .line 209
    iput-object v0, p0, Ltas/ipc/MsgData;->str1:Ljava/lang/String;

    .line 210
    iput-object v0, p0, Ltas/ipc/MsgData;->str2:Ljava/lang/String;

    .line 211
    iput-object v0, p0, Ltas/ipc/MsgData;->args:[I

    .line 212
    iput-object v0, p0, Ltas/ipc/MsgData;->bytes:[B

    .line 213
    iput-object v0, p0, Ltas/ipc/MsgData;->bundle:Landroid/os/Bundle;

    .line 214
    const/4 v0, -0x1

    iput v0, p0, Ltas/ipc/MsgData;->stamp:I

    .line 205
    return-void
.end method

.method public bridge synthetic clone()Ljava/lang/Object;
    .locals 1
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/CloneNotSupportedException;
        }
    .end annotation

    .prologue
    .line 157
    invoke-virtual {p0}, Ltas/ipc/MsgData;->clone()Ltas/ipc/MsgData;

    move-result-object v0

    return-object v0
.end method

.method public clone()Ltas/ipc/MsgData;
    .locals 1

    .prologue
    .line 158
    new-instance v0, Ltas/ipc/MsgData;

    invoke-direct {v0, p0}, Ltas/ipc/MsgData;-><init>(Ltas/ipc/MsgData;)V

    return-object v0
.end method

.method public copyFrom(Ltas/ipc/MsgData;)V
    .locals 1
    .param p1, "that"    # Ltas/ipc/MsgData;

    .prologue
    .line 169
    iget v0, p1, Ltas/ipc/MsgData;->what:I

    iput v0, p0, Ltas/ipc/MsgData;->what:I

    .line 170
    iget v0, p1, Ltas/ipc/MsgData;->arg1:I

    iput v0, p0, Ltas/ipc/MsgData;->arg1:I

    .line 171
    iget v0, p1, Ltas/ipc/MsgData;->arg2:I

    iput v0, p0, Ltas/ipc/MsgData;->arg2:I

    .line 172
    iget-object v0, p1, Ltas/ipc/MsgData;->str1:Ljava/lang/String;

    iput-object v0, p0, Ltas/ipc/MsgData;->str1:Ljava/lang/String;

    .line 173
    iget-object v0, p1, Ltas/ipc/MsgData;->str2:Ljava/lang/String;

    iput-object v0, p0, Ltas/ipc/MsgData;->str2:Ljava/lang/String;

    .line 174
    iget-object v0, p1, Ltas/ipc/MsgData;->args:[I

    iput-object v0, p0, Ltas/ipc/MsgData;->args:[I

    .line 175
    iget-object v0, p1, Ltas/ipc/MsgData;->bytes:[B

    iput-object v0, p0, Ltas/ipc/MsgData;->bytes:[B

    .line 176
    iget-object v0, p1, Ltas/ipc/MsgData;->bundle:Landroid/os/Bundle;

    iput-object v0, p0, Ltas/ipc/MsgData;->bundle:Landroid/os/Bundle;

    .line 177
    iget v0, p1, Ltas/ipc/MsgData;->stamp:I

    iput v0, p0, Ltas/ipc/MsgData;->stamp:I

    .line 168
    return-void
.end method

.method public readFromParcel(Landroid/os/Parcel;)V
    .locals 4
    .param p1, "source"    # Landroid/os/Parcel;

    .prologue
    .line 253
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v2

    iput v2, p0, Ltas/ipc/MsgData;->what:I

    .line 254
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v2

    iput v2, p0, Ltas/ipc/MsgData;->arg1:I

    .line 255
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v2

    iput v2, p0, Ltas/ipc/MsgData;->arg2:I

    .line 256
    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v2

    iput-object v2, p0, Ltas/ipc/MsgData;->str1:Ljava/lang/String;

    .line 257
    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v2

    iput-object v2, p0, Ltas/ipc/MsgData;->str2:Ljava/lang/String;

    .line 258
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v2

    iput v2, p0, Ltas/ipc/MsgData;->stamp:I

    .line 262
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 263
    .local v1, "length":I
    if-lez v1, :cond_0

    .line 264
    new-array v2, v1, [I

    iput-object v2, p0, Ltas/ipc/MsgData;->args:[I

    .line 266
    :try_start_0
    iget-object v2, p0, Ltas/ipc/MsgData;->args:[I

    invoke-virtual {p1, v2}, Landroid/os/Parcel;->readIntArray([I)V
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    .line 271
    :cond_0
    :goto_0
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 272
    if-lez v1, :cond_1

    .line 273
    new-array v2, v1, [B

    iput-object v2, p0, Ltas/ipc/MsgData;->bytes:[B

    .line 275
    :try_start_1
    iget-object v2, p0, Ltas/ipc/MsgData;->bytes:[B

    invoke-virtual {p1, v2}, Landroid/os/Parcel;->readByteArray([B)V
    :try_end_1
    .catch Ljava/lang/RuntimeException; {:try_start_1 .. :try_end_1} :catch_1

    .line 280
    :cond_1
    :goto_1
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v2

    const/4 v3, 0x1

    if-ne v2, v3, :cond_2

    .line 281
    invoke-virtual {p1}, Landroid/os/Parcel;->readBundle()Landroid/os/Bundle;

    move-result-object v2

    iput-object v2, p0, Ltas/ipc/MsgData;->bundle:Landroid/os/Bundle;

    .line 252
    :cond_2
    return-void

    .line 267
    :catch_0
    move-exception v0

    .line 268
    .local v0, "e":Ljava/lang/RuntimeException;
    invoke-virtual {v0}, Ljava/lang/RuntimeException;->printStackTrace()V

    goto :goto_0

    .line 276
    .end local v0    # "e":Ljava/lang/RuntimeException;
    :catch_1
    move-exception v0

    .line 277
    .restart local v0    # "e":Ljava/lang/RuntimeException;
    invoke-virtual {v0}, Ljava/lang/RuntimeException;->printStackTrace()V

    goto :goto_1
.end method

.method public recycle()V
    .locals 1

    .prologue
    .line 218
    iget-boolean v0, p0, Ltas/ipc/MsgData;->mAllocated:Z

    if-eqz v0, :cond_0

    .line 219
    const/4 v0, 0x0

    iput-boolean v0, p0, Ltas/ipc/MsgData;->mAllocated:Z

    .line 220
    invoke-virtual {p0}, Ltas/ipc/MsgData;->clear()V

    .line 221
    sget-object v0, Ltas/ipc/MsgData;->sPool:Ltas/internal/ipc/util/SyncdPool;

    invoke-virtual {v0, p0}, Ltas/internal/ipc/util/SyncdPool;->recycle(Ljava/lang/Object;)V

    .line 217
    :cond_0
    return-void
.end method

.method public toString()Ljava/lang/String;
    .locals 2

    .prologue
    .line 294
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 295
    const-string/jumbo v1, "{ what="

    .line 294
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 295
    iget v1, p0, Ltas/ipc/MsgData;->what:I

    .line 294
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 296
    const-string/jumbo v1, " arg1="

    .line 294
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 296
    iget v1, p0, Ltas/ipc/MsgData;->arg1:I

    .line 294
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 297
    const-string/jumbo v1, " arg2="

    .line 294
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 297
    iget v1, p0, Ltas/ipc/MsgData;->arg2:I

    .line 294
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 298
    const-string/jumbo v1, " str1="

    .line 294
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 298
    iget-object v1, p0, Ltas/ipc/MsgData;->str1:Ljava/lang/String;

    .line 294
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 299
    const-string/jumbo v1, " str2="

    .line 294
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 299
    iget-object v1, p0, Ltas/ipc/MsgData;->str2:Ljava/lang/String;

    .line 294
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 300
    const-string/jumbo v1, " args="

    .line 294
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 300
    iget-object v1, p0, Ltas/ipc/MsgData;->args:[I

    .line 294
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 301
    const-string/jumbo v1, " bytes="

    .line 294
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 301
    iget-object v1, p0, Ltas/ipc/MsgData;->bytes:[B

    .line 294
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 302
    const-string/jumbo v1, " bundle="

    .line 294
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 302
    iget-object v1, p0, Ltas/ipc/MsgData;->bundle:Landroid/os/Bundle;

    .line 294
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 303
    const-string/jumbo v1, " stamp="

    .line 294
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 303
    iget v1, p0, Ltas/ipc/MsgData;->stamp:I

    .line 294
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 304
    const-string/jumbo v1, "."

    .line 294
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 304
    iget v1, p0, Ltas/ipc/MsgData;->pool:I

    .line 294
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 305
    const-string/jumbo v1, " }"

    .line 294
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public writeToParcel(Landroid/os/Parcel;I)V
    .locals 2
    .param p1, "dest"    # Landroid/os/Parcel;
    .param p2, "flags"    # I

    .prologue
    const/4 v1, 0x0

    .line 226
    iget v0, p0, Ltas/ipc/MsgData;->what:I

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->writeInt(I)V

    .line 227
    iget v0, p0, Ltas/ipc/MsgData;->arg1:I

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->writeInt(I)V

    .line 228
    iget v0, p0, Ltas/ipc/MsgData;->arg2:I

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->writeInt(I)V

    .line 229
    iget-object v0, p0, Ltas/ipc/MsgData;->str1:Ljava/lang/String;

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    .line 230
    iget-object v0, p0, Ltas/ipc/MsgData;->str2:Ljava/lang/String;

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    .line 231
    iget v0, p0, Ltas/ipc/MsgData;->stamp:I

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->writeInt(I)V

    .line 232
    iget-object v0, p0, Ltas/ipc/MsgData;->args:[I

    if-eqz v0, :cond_0

    .line 233
    iget-object v0, p0, Ltas/ipc/MsgData;->args:[I

    array-length v0, v0

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->writeInt(I)V

    .line 234
    iget-object v0, p0, Ltas/ipc/MsgData;->args:[I

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->writeIntArray([I)V

    .line 238
    :goto_0
    iget-object v0, p0, Ltas/ipc/MsgData;->bytes:[B

    if-eqz v0, :cond_1

    .line 239
    iget-object v0, p0, Ltas/ipc/MsgData;->bytes:[B

    array-length v0, v0

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->writeInt(I)V

    .line 240
    iget-object v0, p0, Ltas/ipc/MsgData;->bytes:[B

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->writeByteArray([B)V

    .line 244
    :goto_1
    iget-object v0, p0, Ltas/ipc/MsgData;->bundle:Landroid/os/Bundle;

    if-eqz v0, :cond_2

    .line 245
    const/4 v0, 0x1

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->writeInt(I)V

    .line 246
    iget-object v0, p0, Ltas/ipc/MsgData;->bundle:Landroid/os/Bundle;

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->writeBundle(Landroid/os/Bundle;)V

    .line 225
    :goto_2
    return-void

    .line 236
    :cond_0
    invoke-virtual {p1, v1}, Landroid/os/Parcel;->writeInt(I)V

    goto :goto_0

    .line 242
    :cond_1
    invoke-virtual {p1, v1}, Landroid/os/Parcel;->writeInt(I)V

    goto :goto_1

    .line 248
    :cond_2
    invoke-virtual {p1, v1}, Landroid/os/Parcel;->writeInt(I)V

    goto :goto_2
.end method
