.class Ltas/internal/ipc/Sender$AnonymousCallback;
.super Ljava/lang/Object;
.source "Sender.java"

# interfaces
.implements Ltas/ipc/SenderSession$Callback;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltas/internal/ipc/Sender;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "AnonymousCallback"
.end annotation


# instance fields
.field private mAnonymous:Ltas/internal/ipc/Sender$AnonymousSession;

.field private mCallback:Ltas/ipc/SenderSession$Callback;

.field private mSender:Ltas/internal/ipc/Sender;


# direct methods
.method static synthetic -get0(Ltas/internal/ipc/Sender$AnonymousCallback;)Ltas/internal/ipc/Sender$AnonymousSession;
    .locals 1

    iget-object v0, p0, Ltas/internal/ipc/Sender$AnonymousCallback;->mAnonymous:Ltas/internal/ipc/Sender$AnonymousSession;

    return-object v0
.end method

.method static synthetic -wrap0(Ltas/internal/ipc/Sender$AnonymousCallback;Ltas/ipc/SenderSession$Callback;)V
    .locals 0
    .param p1, "cb"    # Ltas/ipc/SenderSession$Callback;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/ipc/Sender$AnonymousCallback;->setCallback(Ltas/ipc/SenderSession$Callback;)V

    return-void
.end method

.method static synthetic -wrap1(Ltas/internal/ipc/Sender$AnonymousCallback;)V
    .locals 0

    invoke-direct {p0}, Ltas/internal/ipc/Sender$AnonymousCallback;->setLazyMode()V

    return-void
.end method

.method private constructor <init>(Ltas/internal/ipc/Sender;)V
    .locals 0
    .param p1, "sender"    # Ltas/internal/ipc/Sender;

    .prologue
    .line 251
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 252
    iput-object p1, p0, Ltas/internal/ipc/Sender$AnonymousCallback;->mSender:Ltas/internal/ipc/Sender;

    .line 251
    return-void
.end method

.method synthetic constructor <init>(Ltas/internal/ipc/Sender;Ltas/internal/ipc/Sender$AnonymousCallback;)V
    .locals 0
    .param p1, "sender"    # Ltas/internal/ipc/Sender;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/ipc/Sender$AnonymousCallback;-><init>(Ltas/internal/ipc/Sender;)V

    return-void
.end method

.method private setCallback(Ltas/ipc/SenderSession$Callback;)V
    .locals 1
    .param p1, "cb"    # Ltas/ipc/SenderSession$Callback;

    .prologue
    .line 256
    monitor-enter p0

    .line 257
    :try_start_0
    iput-object p1, p0, Ltas/internal/ipc/Sender$AnonymousCallback;->mCallback:Ltas/ipc/SenderSession$Callback;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit p0

    .line 255
    return-void

    .line 256
    :catchall_0
    move-exception v0

    monitor-exit p0

    throw v0
.end method

.method private setLazyMode()V
    .locals 3

    .prologue
    .line 262
    monitor-enter p0

    .line 263
    :try_start_0
    iget-object v0, p0, Ltas/internal/ipc/Sender$AnonymousCallback;->mAnonymous:Ltas/internal/ipc/Sender$AnonymousSession;

    if-nez v0, :cond_0

    .line 264
    new-instance v0, Ltas/internal/ipc/Sender$AnonymousSession;

    iget-object v1, p0, Ltas/internal/ipc/Sender$AnonymousCallback;->mSender:Ltas/internal/ipc/Sender;

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2}, Ltas/internal/ipc/Sender$AnonymousSession;-><init>(Ltas/internal/ipc/Sender;Ltas/internal/ipc/Sender$AnonymousSession;)V

    iput-object v0, p0, Ltas/internal/ipc/Sender$AnonymousCallback;->mAnonymous:Ltas/internal/ipc/Sender$AnonymousSession;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_0
    monitor-exit p0

    .line 261
    return-void

    .line 262
    :catchall_0
    move-exception v0

    monitor-exit p0

    throw v0
.end method


# virtual methods
.method public onReceiverOffline(Ltas/ipc/SenderSession;)V
    .locals 1
    .param p1, "session"    # Ltas/ipc/SenderSession;

    .prologue
    .line 283
    monitor-enter p0

    .line 284
    :try_start_0
    iget-object v0, p0, Ltas/internal/ipc/Sender$AnonymousCallback;->mCallback:Ltas/ipc/SenderSession$Callback;

    if-eqz v0, :cond_0

    .line 285
    iget-object v0, p0, Ltas/internal/ipc/Sender$AnonymousCallback;->mCallback:Ltas/ipc/SenderSession$Callback;

    invoke-interface {v0, p1}, Ltas/ipc/SenderSession$Callback;->onReceiverOffline(Ltas/ipc/SenderSession;)V

    .line 287
    :cond_0
    iget-object v0, p0, Ltas/internal/ipc/Sender$AnonymousCallback;->mAnonymous:Ltas/internal/ipc/Sender$AnonymousSession;

    if-eqz v0, :cond_1

    .line 288
    iget-object v0, p0, Ltas/internal/ipc/Sender$AnonymousCallback;->mAnonymous:Ltas/internal/ipc/Sender$AnonymousSession;

    invoke-static {v0, p1}, Ltas/internal/ipc/Sender$AnonymousSession;->-wrap1(Ltas/internal/ipc/Sender$AnonymousSession;Ltas/ipc/SenderSession;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_1
    monitor-exit p0

    .line 282
    return-void

    .line 283
    :catchall_0
    move-exception v0

    monitor-exit p0

    throw v0
.end method

.method public onReceiverOnline(Ltas/ipc/SenderSession;)V
    .locals 1
    .param p1, "session"    # Ltas/ipc/SenderSession;

    .prologue
    .line 271
    monitor-enter p0

    .line 272
    :try_start_0
    iget-object v0, p0, Ltas/internal/ipc/Sender$AnonymousCallback;->mCallback:Ltas/ipc/SenderSession$Callback;

    if-eqz v0, :cond_0

    .line 273
    iget-object v0, p0, Ltas/internal/ipc/Sender$AnonymousCallback;->mCallback:Ltas/ipc/SenderSession$Callback;

    invoke-interface {v0, p1}, Ltas/ipc/SenderSession$Callback;->onReceiverOnline(Ltas/ipc/SenderSession;)V

    .line 275
    :cond_0
    iget-object v0, p0, Ltas/internal/ipc/Sender$AnonymousCallback;->mAnonymous:Ltas/internal/ipc/Sender$AnonymousSession;

    if-eqz v0, :cond_1

    .line 276
    iget-object v0, p0, Ltas/internal/ipc/Sender$AnonymousCallback;->mAnonymous:Ltas/internal/ipc/Sender$AnonymousSession;

    invoke-static {v0, p1}, Ltas/internal/ipc/Sender$AnonymousSession;->-wrap0(Ltas/internal/ipc/Sender$AnonymousSession;Ltas/ipc/SenderSession;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_1
    monitor-exit p0

    .line 270
    return-void

    .line 271
    :catchall_0
    move-exception v0

    monitor-exit p0

    throw v0
.end method

.method public onReceiverUpdate(Ltas/ipc/SenderSession;Landroid/os/Bundle;)V
    .locals 1
    .param p1, "session"    # Ltas/ipc/SenderSession;
    .param p2, "extra"    # Landroid/os/Bundle;

    .prologue
    .line 295
    monitor-enter p0

    .line 296
    :try_start_0
    iget-object v0, p0, Ltas/internal/ipc/Sender$AnonymousCallback;->mCallback:Ltas/ipc/SenderSession$Callback;

    if-eqz v0, :cond_0

    .line 297
    iget-object v0, p0, Ltas/internal/ipc/Sender$AnonymousCallback;->mCallback:Ltas/ipc/SenderSession$Callback;

    invoke-interface {v0, p1, p2}, Ltas/ipc/SenderSession$Callback;->onReceiverUpdate(Ltas/ipc/SenderSession;Landroid/os/Bundle;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_0
    monitor-exit p0

    .line 294
    return-void

    .line 295
    :catchall_0
    move-exception v0

    monitor-exit p0

    throw v0
.end method

.method public onReply(Ltas/ipc/SenderSession;ILtas/ipc/MsgData;)V
    .locals 1
    .param p1, "session"    # Ltas/ipc/SenderSession;
    .param p2, "what"    # I
    .param p3, "msg"    # Ltas/ipc/MsgData;

    .prologue
    .line 304
    monitor-enter p0

    .line 305
    :try_start_0
    iget-object v0, p0, Ltas/internal/ipc/Sender$AnonymousCallback;->mCallback:Ltas/ipc/SenderSession$Callback;

    if-eqz v0, :cond_0

    .line 306
    iget-object v0, p0, Ltas/internal/ipc/Sender$AnonymousCallback;->mCallback:Ltas/ipc/SenderSession$Callback;

    invoke-interface {v0, p1, p2, p3}, Ltas/ipc/SenderSession$Callback;->onReply(Ltas/ipc/SenderSession;ILtas/ipc/MsgData;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_0
    monitor-exit p0

    .line 303
    return-void

    .line 304
    :catchall_0
    move-exception v0

    monitor-exit p0

    throw v0
.end method
