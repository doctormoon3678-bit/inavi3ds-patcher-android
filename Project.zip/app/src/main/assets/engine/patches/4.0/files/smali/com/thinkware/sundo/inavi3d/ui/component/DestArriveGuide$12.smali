.class Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide$12;
.super Ljava/lang/Object;
.source "DestArriveGuide.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;->changemode(Z)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;

.field final synthetic val$bOBD2:Z


# direct methods
.method constructor <init>(Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;Z)V
    .locals 0

    .prologue
    .line 1399
    iput-object p1, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide$12;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;

    iput-boolean p2, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide$12;->val$bOBD2:Z

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 7

    .prologue
    const/16 v6, 0x131

    const/4 v5, 0x1

    const/16 v4, 0x8

    const/4 v3, 0x0

    .line 1404
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide$12;->val$bOBD2:Z

    if-ne v0, v5, :cond_1

    .line 1405
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide$12;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;

    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide$12;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;

    invoke-static {v1}, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;->access$500(Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;)Landroid/content/res/Resources;

    move-result-object v1

    const v2, 0x7f020344

    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 1406
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide$12;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;->DestInfoTitle:Landroid/widget/TextView;

    if-eqz v0, :cond_0

    .line 1407
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide$12;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;->DestInfoTitle:Landroid/widget/TextView;

    const-string v1, "ECO \uc815\ubcf4"

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1409
    :cond_0
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide$12;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;->DestInfoDetail:Landroid/widget/Button;

    invoke-virtual {v0, v4}, Landroid/widget/Button;->setVisibility(I)V

    .line 1410
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide$12;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;->DestInfoAround:Landroid/widget/Button;

    invoke-virtual {v0, v4}, Landroid/widget/Button;->setVisibility(I)V

    .line 1411
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide$12;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;->DestInfoRoadview:Landroid/widget/Button;

    invoke-virtual {v0, v4}, Landroid/widget/Button;->setVisibility(I)V

    .line 1412
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide$12;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;->DestInfoFivepin:Landroid/widget/Button;

    invoke-virtual {v0, v4}, Landroid/widget/Button;->setVisibility(I)V

    .line 1413
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->getInstance()Lcom/thinkware/sundo/inavi3d/InaviConfig;

    move-result-object v0

    invoke-virtual {v0, v6, v5}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->CNaviConfigSet(II)Z

    .line 1426
    :goto_0
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->getInstance()Lcom/thinkware/sundo/inavi3d/InaviConfig;

    move-result-object v0

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->SetConfigSave()Z

    .line 1428
    return-void

    .line 1416
    :cond_1
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide$12;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;

    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide$12;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;

    invoke-static {v1}, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;->access$500(Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;)Landroid/content/res/Resources;

    move-result-object v1

    const v2, 0x7f020343

    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 1417
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide$12;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;->DestInfoTitle:Landroid/widget/TextView;

    if-eqz v0, :cond_2

    .line 1418
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide$12;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;->DestInfoTitle:Landroid/widget/TextView;

    const-string v1, "\ubaa9\uc801\uc9c0 \ub3c4\ucc29\uc548\ub0b4"

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1420
    :cond_2
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide$12;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;->DestInfoDetail:Landroid/widget/Button;

    invoke-virtual {v0, v3}, Landroid/widget/Button;->setVisibility(I)V

    .line 1421
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide$12;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;->DestInfoAround:Landroid/widget/Button;

    invoke-virtual {v0, v3}, Landroid/widget/Button;->setVisibility(I)V

    .line 1422
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide$12;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;->DestInfoRoadview:Landroid/widget/Button;

    invoke-virtual {v0, v3}, Landroid/widget/Button;->setVisibility(I)V

    .line 1423
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide$12;->this$0:Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/ui/component/DestArriveGuide;->DestInfoFivepin:Landroid/widget/Button;

    invoke-virtual {v0, v3}, Landroid/widget/Button;->setVisibility(I)V

    .line 1424
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->getInstance()Lcom/thinkware/sundo/inavi3d/InaviConfig;

    move-result-object v0

    invoke-virtual {v0, v6, v3}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->CNaviConfigSet(II)Z

    goto :goto_0
.end method
