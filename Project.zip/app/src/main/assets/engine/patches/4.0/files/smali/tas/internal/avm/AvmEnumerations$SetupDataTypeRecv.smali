.class public final enum Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;
.super Ljava/lang/Enum;
.source "AvmEnumerations.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltas/internal/avm/AvmEnumerations;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "SetupDataTypeRecv"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum",
        "<",
        "Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;

.field public static final enum BRIGHTNESS:Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;

.field public static final enum CONTRAST:Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;

.field public static final enum HEIGHT:Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;

.field public static final enum HUE:Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;

.field public static final enum MCU_VER_H:Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;

.field public static final enum MCU_VER_L:Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;

.field public static final enum SATURATION:Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;

.field public static final enum SOC_VER_H:Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;

.field public static final enum SOC_VER_L:Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;

.field public static final enum TYPE_UNKNOWN:Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;

.field public static final enum WIDTH:Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;


# instance fields
.field private type:I


# direct methods
.method static constructor <clinit>()V
    .locals 9

    .prologue
    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v4, 0x0

    .line 254
    new-instance v0, Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;

    const-string/jumbo v1, "SOC_VER_H"

    invoke-direct {v0, v1, v4, v4}, Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;-><init>(Ljava/lang/String;II)V

    sput-object v0, Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;->SOC_VER_H:Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;

    .line 255
    new-instance v0, Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;

    const-string/jumbo v1, "SOC_VER_L"

    invoke-direct {v0, v1, v5, v5}, Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;-><init>(Ljava/lang/String;II)V

    sput-object v0, Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;->SOC_VER_L:Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;

    .line 256
    new-instance v0, Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;

    const-string/jumbo v1, "MCU_VER_H"

    invoke-direct {v0, v1, v6, v6}, Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;-><init>(Ljava/lang/String;II)V

    sput-object v0, Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;->MCU_VER_H:Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;

    .line 257
    new-instance v0, Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;

    const-string/jumbo v1, "MCU_VER_L"

    invoke-direct {v0, v1, v7, v7}, Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;-><init>(Ljava/lang/String;II)V

    sput-object v0, Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;->MCU_VER_L:Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;

    .line 258
    new-instance v0, Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;

    const-string/jumbo v1, "BRIGHTNESS"

    invoke-direct {v0, v1, v8, v8}, Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;-><init>(Ljava/lang/String;II)V

    sput-object v0, Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;->BRIGHTNESS:Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;

    .line 259
    new-instance v0, Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;

    const-string/jumbo v1, "CONTRAST"

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-direct {v0, v1, v2, v3}, Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;-><init>(Ljava/lang/String;II)V

    sput-object v0, Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;->CONTRAST:Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;

    .line 260
    new-instance v0, Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;

    const-string/jumbo v1, "SATURATION"

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-direct {v0, v1, v2, v3}, Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;-><init>(Ljava/lang/String;II)V

    sput-object v0, Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;->SATURATION:Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;

    .line 261
    new-instance v0, Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;

    const-string/jumbo v1, "HUE"

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-direct {v0, v1, v2, v3}, Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;-><init>(Ljava/lang/String;II)V

    sput-object v0, Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;->HUE:Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;

    .line 262
    new-instance v0, Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;

    const-string/jumbo v1, "WIDTH"

    const/16 v2, 0x8

    const/16 v3, 0x8

    invoke-direct {v0, v1, v2, v3}, Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;-><init>(Ljava/lang/String;II)V

    sput-object v0, Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;->WIDTH:Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;

    .line 263
    new-instance v0, Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;

    const-string/jumbo v1, "HEIGHT"

    const/16 v2, 0x9

    const/16 v3, 0x9

    invoke-direct {v0, v1, v2, v3}, Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;-><init>(Ljava/lang/String;II)V

    sput-object v0, Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;->HEIGHT:Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;

    .line 264
    new-instance v0, Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;

    const-string/jumbo v1, "TYPE_UNKNOWN"

    const/16 v2, 0xa

    const/16 v3, 0xff

    invoke-direct {v0, v1, v2, v3}, Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;-><init>(Ljava/lang/String;II)V

    sput-object v0, Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;->TYPE_UNKNOWN:Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;

    .line 253
    const/16 v0, 0xb

    new-array v0, v0, [Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;

    sget-object v1, Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;->SOC_VER_H:Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;

    aput-object v1, v0, v4

    sget-object v1, Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;->SOC_VER_L:Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;

    aput-object v1, v0, v5

    sget-object v1, Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;->MCU_VER_H:Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;

    aput-object v1, v0, v6

    sget-object v1, Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;->MCU_VER_L:Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;

    aput-object v1, v0, v7

    sget-object v1, Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;->BRIGHTNESS:Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;

    aput-object v1, v0, v8

    sget-object v1, Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;->CONTRAST:Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;

    const/4 v2, 0x5

    aput-object v1, v0, v2

    sget-object v1, Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;->SATURATION:Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;

    const/4 v2, 0x6

    aput-object v1, v0, v2

    sget-object v1, Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;->HUE:Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;

    const/4 v2, 0x7

    aput-object v1, v0, v2

    sget-object v1, Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;->WIDTH:Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;

    const/16 v2, 0x8

    aput-object v1, v0, v2

    sget-object v1, Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;->HEIGHT:Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;

    const/16 v2, 0x9

    aput-object v1, v0, v2

    sget-object v1, Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;->TYPE_UNKNOWN:Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;

    const/16 v2, 0xa

    aput-object v1, v0, v2

    sput-object v0, Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;->$VALUES:[Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .locals 0
    .param p3, "type"    # I

    .prologue
    .line 267
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 268
    iput p3, p0, Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;->type:I

    .line 267
    return-void
.end method

.method public static createFromOrdinalNumber(I)Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;
    .locals 5
    .param p0, "number"    # I

    .prologue
    .line 285
    invoke-static {}, Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;->values()[Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;

    move-result-object v2

    const/4 v1, 0x0

    array-length v3, v2

    :goto_0
    if-ge v1, v3, :cond_1

    aget-object v0, v2, v1

    .line 286
    .local v0, "i":Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;
    invoke-virtual {v0}, Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;->ordinal()I

    move-result v4

    if-ne v4, p0, :cond_0

    .line 287
    return-object v0

    .line 285
    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    .line 290
    .end local v0    # "i":Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;
    :cond_1
    sget-object v1, Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;->TYPE_UNKNOWN:Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;

    return-object v1
.end method

.method public static createFromValue(I)Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;
    .locals 5
    .param p0, "type"    # I

    .prologue
    .line 276
    invoke-static {}, Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;->values()[Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;

    move-result-object v2

    const/4 v1, 0x0

    array-length v3, v2

    :goto_0
    if-ge v1, v3, :cond_1

    aget-object v0, v2, v1

    .line 277
    .local v0, "i":Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;
    invoke-virtual {v0}, Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;->toInteger()I

    move-result v4

    if-ne v4, p0, :cond_0

    .line 278
    return-object v0

    .line 276
    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    .line 281
    .end local v0    # "i":Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;
    :cond_1
    sget-object v1, Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;->TYPE_UNKNOWN:Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;

    return-object v1
.end method

.method public static valueOf(Ljava/lang/String;)Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;
    .locals 1
    .param p0, "name"    # Ljava/lang/String;

    .prologue
    .line 253
    const-class v0, Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object v0

    check-cast v0, Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;

    return-object v0
.end method

.method public static values()[Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;
    .locals 1

    .prologue
    .line 253
    sget-object v0, Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;->$VALUES:[Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;

    return-object v0
.end method


# virtual methods
.method public toInteger()I
    .locals 1

    .prologue
    .line 272
    iget v0, p0, Ltas/internal/avm/AvmEnumerations$SetupDataTypeRecv;->type:I

    return v0
.end method
