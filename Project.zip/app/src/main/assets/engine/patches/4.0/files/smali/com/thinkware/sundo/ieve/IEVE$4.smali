.class Lcom/thinkware/sundo/ieve/IEVE$4;
.super Ljava/lang/Object;
.source "IEVE.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/thinkware/sundo/ieve/IEVE;->k()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/thinkware/sundo/ieve/IEVE;


# direct methods
.method constructor <init>(Lcom/thinkware/sundo/ieve/IEVE;)V
    .locals 0

    .prologue
    .line 1
    iput-object p1, p0, Lcom/thinkware/sundo/ieve/IEVE$4;->a:Lcom/thinkware/sundo/ieve/IEVE;

    .line 2912
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 4

    .prologue
    .line 2915
    :try_start_0
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE$4;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v0}, Lcom/thinkware/sundo/ieve/IEVE;->a(Lcom/thinkware/sundo/ieve/IEVE;)Landroid/os/Handler;

    move-result-object v0

    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE$4;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v1}, Lcom/thinkware/sundo/ieve/IEVE;->a(Lcom/thinkware/sundo/ieve/IEVE;)Landroid/os/Handler;

    move-result-object v1

    const/16 v2, 0x7cf

    invoke-static {v1, v2}, Landroid/os/Message;->obtain(Landroid/os/Handler;I)Landroid/os/Message;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    .line 2916
    iget-object v0, p0, Lcom/thinkware/sundo/ieve/IEVE$4;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v0}, Lcom/thinkware/sundo/ieve/IEVE;->b(Lcom/thinkware/sundo/ieve/IEVE;)Lcom/thinkware/sundo/ieve/ieveTextView;

    move-result-object v0

    iget-object v1, p0, Lcom/thinkware/sundo/ieve/IEVE$4;->a:Lcom/thinkware/sundo/ieve/IEVE;

    invoke-static {v1}, Lcom/thinkware/sundo/ieve/IEVE;->J(Lcom/thinkware/sundo/ieve/IEVE;)Ljava/lang/Runnable;

    move-result-object v1

    const-wide/16 v2, 0x21

    invoke-virtual {v0, v1, v2, v3}, Lcom/thinkware/sundo/ieve/ieveTextView;->postDelayed(Ljava/lang/Runnable;J)Z
    :try_end_0
    .catch Ljava/lang/Throwable; {:try_start_0 .. :try_end_0} :catch_0

    .line 2920
    :goto_0
    return-void

    .line 2918
    :catch_0
    move-exception v0

    goto :goto_0
.end method
