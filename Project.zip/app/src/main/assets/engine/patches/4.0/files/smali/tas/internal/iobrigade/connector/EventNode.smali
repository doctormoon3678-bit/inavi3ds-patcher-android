.class public abstract Ltas/internal/iobrigade/connector/EventNode;
.super Ljava/lang/Object;
.source "EventNode.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation


# static fields
.field private static final TAG:Ljava/lang/String;


# instance fields
.field protected mAttributes:I

.field protected mConsumer:Ltas/internal/iobrigade/connector/Consumer;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ltas/internal/iobrigade/connector/Consumer",
            "<*>;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .prologue
    .line 10
    const-class v0, Ltas/internal/iobrigade/connector/EventNode;

    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Ltas/internal/iobrigade/connector/EventNode;->TAG:Ljava/lang/String;

    .line 8
    return-void
.end method

.method protected constructor <init>(Ljava/lang/Object;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    .prologue
    .line 15
    .local p0, "this":Ltas/internal/iobrigade/connector/EventNode;, "Ltas/internal/iobrigade/connector/EventNode<TT;>;"
    .local p1, "connector":Ljava/lang/Object;, "TT;"
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ltas/internal/iobrigade/connector/Consumer;

    invoke-direct {v0, p1}, Ltas/internal/iobrigade/connector/Consumer;-><init>(Ljava/lang/Object;)V

    iput-object v0, p0, Ltas/internal/iobrigade/connector/EventNode;->mConsumer:Ltas/internal/iobrigade/connector/Consumer;

    return-void
.end method


# virtual methods
.method public getAttributes()I
    .locals 1

    .prologue
    .line 17
    .local p0, "this":Ltas/internal/iobrigade/connector/EventNode;, "Ltas/internal/iobrigade/connector/EventNode<TT;>;"
    iget v0, p0, Ltas/internal/iobrigade/connector/EventNode;->mAttributes:I

    return v0
.end method

.method public abstract notifyConsumerReady()V
.end method

.method public abstract sendMessageWith(Ljava/lang/String;)V
.end method

.method public abstract setAttributes(I)V
.end method

.method public abstract setConsumer(Ltas/internal/iobrigade/connector/IRemoteIOEvent;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ltas/internal/iobrigade/connector/IRemoteIOEvent",
            "<TT;>;)V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/NullPointerException;
        }
    .end annotation
.end method
