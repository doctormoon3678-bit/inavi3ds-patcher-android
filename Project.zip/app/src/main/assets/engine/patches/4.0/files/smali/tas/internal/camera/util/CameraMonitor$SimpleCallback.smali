.class public Ltas/internal/camera/util/CameraMonitor$SimpleCallback;
.super Ljava/lang/Object;
.source "CameraMonitor.java"

# interfaces
.implements Ltas/internal/camera/util/CameraMonitor$Callback;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltas/internal/camera/util/CameraMonitor;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "SimpleCallback"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    .prologue
    .line 79
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onCameraOpen(Ltas/internal/camera/util/CameraMonitor;I)V
    .locals 0
    .param p1, "monitor"    # Ltas/internal/camera/util/CameraMonitor;
    .param p2, "camid"    # I

    .prologue
    .line 85
    return-void
.end method

.method public onCameraRelease(Ltas/internal/camera/util/CameraMonitor;I)V
    .locals 0
    .param p1, "monitor"    # Ltas/internal/camera/util/CameraMonitor;
    .param p2, "camid"    # I

    .prologue
    .line 86
    return-void
.end method

.method public onMonitorBinderDied(Ltas/internal/camera/util/CameraMonitor;)V
    .locals 0
    .param p1, "monitor"    # Ltas/internal/camera/util/CameraMonitor;

    .prologue
    .line 83
    return-void
.end method

.method public onMonitorConnected(Ltas/internal/camera/util/CameraMonitor;)V
    .locals 0
    .param p1, "monitor"    # Ltas/internal/camera/util/CameraMonitor;

    .prologue
    .line 80
    return-void
.end method

.method public onMonitorDisconnected(Ltas/internal/camera/util/CameraMonitor;)V
    .locals 0
    .param p1, "monitor"    # Ltas/internal/camera/util/CameraMonitor;

    .prologue
    .line 81
    return-void
.end method

.method public onMonitorError(Ltas/internal/camera/util/CameraMonitor;II)V
    .locals 0
    .param p1, "monitor"    # Ltas/internal/camera/util/CameraMonitor;
    .param p2, "what"    # I
    .param p3, "error"    # I

    .prologue
    .line 84
    return-void
.end method

.method public onMonitorReconnected(Ltas/internal/camera/util/CameraMonitor;)V
    .locals 0
    .param p1, "monitor"    # Ltas/internal/camera/util/CameraMonitor;

    .prologue
    .line 82
    return-void
.end method
