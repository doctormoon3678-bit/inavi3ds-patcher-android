.class Lcom/thinkware/sundo/inavi3d/INavi3DActivity$ClockTick;
.super Ljava/lang/Object;
.source "INavi3DActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;


# direct methods
.method constructor <init>(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)V
    .locals 0

    .prologue
    iput-object p1, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$ClockTick;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 1

    .prologue
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$ClockTick;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->UpdateInAppClock()V

    return-void
.end method
