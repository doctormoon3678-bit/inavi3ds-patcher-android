.class Ltas/internal/camera/InputSourceInner$InputQueue;
.super Ltas/internal/camera/QueueBase;
.source "InputSourceInner.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltas/internal/camera/InputSourceInner;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "InputQueue"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ltas/internal/camera/QueueBase",
        "<",
        "Ltas/internal/camera/InputSourceInner;",
        ">;"
    }
.end annotation


# instance fields
.field private mOwner:Ltas/internal/camera/InputSourceInner;


# direct methods
.method private constructor <init>(Ltas/internal/camera/InputSourceInner;)V
    .locals 0
    .param p1, "owner"    # Ltas/internal/camera/InputSourceInner;

    .prologue
    .line 498
    invoke-direct {p0}, Ltas/internal/camera/QueueBase;-><init>()V

    .line 499
    iput-object p1, p0, Ltas/internal/camera/InputSourceInner$InputQueue;->mOwner:Ltas/internal/camera/InputSourceInner;

    .line 498
    return-void
.end method

.method synthetic constructor <init>(Ltas/internal/camera/InputSourceInner;Ltas/internal/camera/InputSourceInner$InputQueue;)V
    .locals 0
    .param p1, "owner"    # Ltas/internal/camera/InputSourceInner;

    .prologue
    invoke-direct {p0, p1}, Ltas/internal/camera/InputSourceInner$InputQueue;-><init>(Ltas/internal/camera/InputSourceInner;)V

    return-void
.end method


# virtual methods
.method public bridge synthetic onAvailable(Ljava/lang/Object;)Z
    .locals 1
    .param p1, "input"    # Ljava/lang/Object;

    .prologue
    .line 517
    check-cast p1, Ltas/internal/camera/InputSourceInner;

    .end local p1    # "input":Ljava/lang/Object;
    invoke-virtual {p0, p1}, Ltas/internal/camera/InputSourceInner$InputQueue;->onAvailable(Ltas/internal/camera/InputSourceInner;)Z

    move-result v0

    return v0
.end method

.method public onAvailable(Ltas/internal/camera/InputSourceInner;)Z
    .locals 1
    .param p1, "input"    # Ltas/internal/camera/InputSourceInner;

    .prologue
    .line 518
    iget-object v0, p0, Ltas/internal/camera/InputSourceInner$InputQueue;->mOwner:Ltas/internal/camera/InputSourceInner;

    invoke-static {v0, p1}, Ltas/internal/camera/InputSourceInner;->-wrap0(Ltas/internal/camera/InputSourceInner;Ltas/internal/camera/InputSourceInner;)Z

    move-result v0

    return v0
.end method

.method public bridge synthetic onDequeue()Ljava/lang/Object;
    .locals 1

    .prologue
    .line 502
    invoke-virtual {p0}, Ltas/internal/camera/InputSourceInner$InputQueue;->onDequeue()Ltas/internal/camera/InputSourceInner;

    move-result-object v0

    return-object v0
.end method

.method public onDequeue()Ltas/internal/camera/InputSourceInner;
    .locals 1

    .prologue
    .line 514
    invoke-virtual {p0}, Ltas/internal/camera/InputSourceInner$InputQueue;->pollHead()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltas/internal/camera/InputSourceInner;

    return-object v0
.end method
