.class public final enum Ltas/internal/avm/AvmEnumerations$UpgradeMode;
.super Ljava/lang/Enum;
.source "AvmEnumerations.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltas/internal/avm/AvmEnumerations;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "UpgradeMode"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum",
        "<",
        "Ltas/internal/avm/AvmEnumerations$UpgradeMode;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Ltas/internal/avm/AvmEnumerations$UpgradeMode;

.field public static final enum UPGRADE_CALIBRATION:Ltas/internal/avm/AvmEnumerations$UpgradeMode;

.field public static final enum UPGRADE_END:Ltas/internal/avm/AvmEnumerations$UpgradeMode;

.field public static final enum UPGRADE_MCU:Ltas/internal/avm/AvmEnumerations$UpgradeMode;

.field public static final enum UPGRADE_SOC:Ltas/internal/avm/AvmEnumerations$UpgradeMode;

.field public static final enum UPGRADE_START:Ltas/internal/avm/AvmEnumerations$UpgradeMode;

.field public static final enum UPGRADE_UNKNOWN:Ltas/internal/avm/AvmEnumerations$UpgradeMode;


# instance fields
.field private mode:I


# direct methods
.method static constructor <clinit>()V
    .locals 9

    .prologue
    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v4, 0x1

    .line 136
    new-instance v0, Ltas/internal/avm/AvmEnumerations$UpgradeMode;

    const-string/jumbo v1, "UPGRADE_START"

    invoke-direct {v0, v1, v6, v4}, Ltas/internal/avm/AvmEnumerations$UpgradeMode;-><init>(Ljava/lang/String;II)V

    sput-object v0, Ltas/internal/avm/AvmEnumerations$UpgradeMode;->UPGRADE_START:Ltas/internal/avm/AvmEnumerations$UpgradeMode;

    .line 137
    new-instance v0, Ltas/internal/avm/AvmEnumerations$UpgradeMode;

    const-string/jumbo v1, "UPGRADE_END"

    invoke-direct {v0, v1, v4, v5}, Ltas/internal/avm/AvmEnumerations$UpgradeMode;-><init>(Ljava/lang/String;II)V

    sput-object v0, Ltas/internal/avm/AvmEnumerations$UpgradeMode;->UPGRADE_END:Ltas/internal/avm/AvmEnumerations$UpgradeMode;

    .line 138
    new-instance v0, Ltas/internal/avm/AvmEnumerations$UpgradeMode;

    const-string/jumbo v1, "UPGRADE_SOC"

    const/16 v2, 0x10

    invoke-direct {v0, v1, v5, v2}, Ltas/internal/avm/AvmEnumerations$UpgradeMode;-><init>(Ljava/lang/String;II)V

    sput-object v0, Ltas/internal/avm/AvmEnumerations$UpgradeMode;->UPGRADE_SOC:Ltas/internal/avm/AvmEnumerations$UpgradeMode;

    .line 139
    new-instance v0, Ltas/internal/avm/AvmEnumerations$UpgradeMode;

    const-string/jumbo v1, "UPGRADE_MCU"

    const/16 v2, 0x20

    invoke-direct {v0, v1, v7, v2}, Ltas/internal/avm/AvmEnumerations$UpgradeMode;-><init>(Ljava/lang/String;II)V

    sput-object v0, Ltas/internal/avm/AvmEnumerations$UpgradeMode;->UPGRADE_MCU:Ltas/internal/avm/AvmEnumerations$UpgradeMode;

    .line 140
    new-instance v0, Ltas/internal/avm/AvmEnumerations$UpgradeMode;

    const-string/jumbo v1, "UPGRADE_CALIBRATION"

    const/16 v2, 0x30

    invoke-direct {v0, v1, v8, v2}, Ltas/internal/avm/AvmEnumerations$UpgradeMode;-><init>(Ljava/lang/String;II)V

    sput-object v0, Ltas/internal/avm/AvmEnumerations$UpgradeMode;->UPGRADE_CALIBRATION:Ltas/internal/avm/AvmEnumerations$UpgradeMode;

    .line 141
    new-instance v0, Ltas/internal/avm/AvmEnumerations$UpgradeMode;

    const-string/jumbo v1, "UPGRADE_UNKNOWN"

    const/4 v2, 0x5

    const/4 v3, -0x1

    invoke-direct {v0, v1, v2, v3}, Ltas/internal/avm/AvmEnumerations$UpgradeMode;-><init>(Ljava/lang/String;II)V

    sput-object v0, Ltas/internal/avm/AvmEnumerations$UpgradeMode;->UPGRADE_UNKNOWN:Ltas/internal/avm/AvmEnumerations$UpgradeMode;

    .line 135
    const/4 v0, 0x6

    new-array v0, v0, [Ltas/internal/avm/AvmEnumerations$UpgradeMode;

    sget-object v1, Ltas/internal/avm/AvmEnumerations$UpgradeMode;->UPGRADE_START:Ltas/internal/avm/AvmEnumerations$UpgradeMode;

    aput-object v1, v0, v6

    sget-object v1, Ltas/internal/avm/AvmEnumerations$UpgradeMode;->UPGRADE_END:Ltas/internal/avm/AvmEnumerations$UpgradeMode;

    aput-object v1, v0, v4

    sget-object v1, Ltas/internal/avm/AvmEnumerations$UpgradeMode;->UPGRADE_SOC:Ltas/internal/avm/AvmEnumerations$UpgradeMode;

    aput-object v1, v0, v5

    sget-object v1, Ltas/internal/avm/AvmEnumerations$UpgradeMode;->UPGRADE_MCU:Ltas/internal/avm/AvmEnumerations$UpgradeMode;

    aput-object v1, v0, v7

    sget-object v1, Ltas/internal/avm/AvmEnumerations$UpgradeMode;->UPGRADE_CALIBRATION:Ltas/internal/avm/AvmEnumerations$UpgradeMode;

    aput-object v1, v0, v8

    sget-object v1, Ltas/internal/avm/AvmEnumerations$UpgradeMode;->UPGRADE_UNKNOWN:Ltas/internal/avm/AvmEnumerations$UpgradeMode;

    const/4 v2, 0x5

    aput-object v1, v0, v2

    sput-object v0, Ltas/internal/avm/AvmEnumerations$UpgradeMode;->$VALUES:[Ltas/internal/avm/AvmEnumerations$UpgradeMode;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .locals 0
    .param p3, "mode"    # I

    .prologue
    .line 144
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 145
    iput p3, p0, Ltas/internal/avm/AvmEnumerations$UpgradeMode;->mode:I

    .line 144
    return-void
.end method

.method public static createFromValue(I)Ltas/internal/avm/AvmEnumerations$UpgradeMode;
    .locals 5
    .param p0, "mode"    # I

    .prologue
    .line 153
    invoke-static {}, Ltas/internal/avm/AvmEnumerations$UpgradeMode;->values()[Ltas/internal/avm/AvmEnumerations$UpgradeMode;

    move-result-object v2

    const/4 v1, 0x0

    array-length v3, v2

    :goto_0
    if-ge v1, v3, :cond_1

    aget-object v0, v2, v1

    .line 154
    .local v0, "i":Ltas/internal/avm/AvmEnumerations$UpgradeMode;
    invoke-virtual {v0}, Ltas/internal/avm/AvmEnumerations$UpgradeMode;->toInteger()I

    move-result v4

    if-ne v4, p0, :cond_0

    .line 155
    return-object v0

    .line 153
    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    .line 158
    .end local v0    # "i":Ltas/internal/avm/AvmEnumerations$UpgradeMode;
    :cond_1
    sget-object v1, Ltas/internal/avm/AvmEnumerations$UpgradeMode;->UPGRADE_UNKNOWN:Ltas/internal/avm/AvmEnumerations$UpgradeMode;

    return-object v1
.end method

.method public static valueOf(Ljava/lang/String;)Ltas/internal/avm/AvmEnumerations$UpgradeMode;
    .locals 1
    .param p0, "name"    # Ljava/lang/String;

    .prologue
    .line 135
    const-class v0, Ltas/internal/avm/AvmEnumerations$UpgradeMode;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object v0

    check-cast v0, Ltas/internal/avm/AvmEnumerations$UpgradeMode;

    return-object v0
.end method

.method public static values()[Ltas/internal/avm/AvmEnumerations$UpgradeMode;
    .locals 1

    .prologue
    .line 135
    sget-object v0, Ltas/internal/avm/AvmEnumerations$UpgradeMode;->$VALUES:[Ltas/internal/avm/AvmEnumerations$UpgradeMode;

    return-object v0
.end method


# virtual methods
.method public toInteger()I
    .locals 1

    .prologue
    .line 149
    iget v0, p0, Ltas/internal/avm/AvmEnumerations$UpgradeMode;->mode:I

    return v0
.end method
