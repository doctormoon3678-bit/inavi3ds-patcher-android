.class public Ltas/internal/camera/server/ServerService;
.super Landroid/app/Service;
.source "ServerService.java"


# instance fields
.field public broadcast:Ltas/internal/camera/server/Broadcast;

.field public inputmgr:Ltas/internal/camera/InputManager;

.field public serverin:Ltas/internal/camera/server/ServerInComing;

.field public serverout:Ltas/internal/camera/server/ServerOutGoing;


# direct methods
.method public constructor <init>()V
    .locals 0

    .prologue
    .line 16
    invoke-direct {p0}, Landroid/app/Service;-><init>()V

    return-void
.end method


# virtual methods
.method public addInput(Ltas/internal/camera/InputSource;)V
    .locals 1
    .param p1, "root"    # Ltas/internal/camera/InputSource;

    .prologue
    .line 46
    iget-object v0, p0, Ltas/internal/camera/server/ServerService;->inputmgr:Ltas/internal/camera/InputManager;

    invoke-virtual {v0, p1}, Ltas/internal/camera/InputManager;->addInput(Ltas/internal/camera/InputSource;)V

    .line 45
    return-void
.end method

.method public addInput(Ltas/internal/camera/InputSource;ILtas/internal/camera/InputSource;)V
    .locals 1
    .param p1, "root"    # Ltas/internal/camera/InputSource;
    .param p2, "portnum"    # I
    .param p3, "input"    # Ltas/internal/camera/InputSource;

    .prologue
    .line 51
    invoke-virtual {p1, p2, p3}, Ltas/internal/camera/InputSource;->addInput(ILtas/internal/camera/InputSource;)V

    .line 52
    iget-object v0, p0, Ltas/internal/camera/server/ServerService;->inputmgr:Ltas/internal/camera/InputManager;

    invoke-virtual {v0, p1}, Ltas/internal/camera/InputManager;->addInput(Ltas/internal/camera/InputSource;)V

    .line 50
    return-void
.end method

.method public onBind(Landroid/content/Intent;)Landroid/os/IBinder;
    .locals 1
    .param p1, "intent"    # Landroid/content/Intent;

    .prologue
    .line 42
    iget-object v0, p0, Ltas/internal/camera/server/ServerService;->serverin:Ltas/internal/camera/server/ServerInComing;

    invoke-virtual {v0}, Ltas/internal/camera/server/ServerInComing;->getIBinder()Landroid/os/IBinder;

    move-result-object v0

    return-object v0
.end method

.method public onCreate()V
    .locals 2

    .prologue
    .line 25
    invoke-static {}, Ltas/internal/camera/BuildConfig;->printVersion()V

    .line 27
    new-instance v0, Ltas/internal/camera/server/ServerOutGoing;

    invoke-direct {v0, p0}, Ltas/internal/camera/server/ServerOutGoing;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Ltas/internal/camera/server/ServerService;->serverout:Ltas/internal/camera/server/ServerOutGoing;

    .line 28
    new-instance v0, Ltas/internal/camera/server/ServerInComing;

    iget-object v1, p0, Ltas/internal/camera/server/ServerService;->serverout:Ltas/internal/camera/server/ServerOutGoing;

    invoke-direct {v0, v1}, Ltas/internal/camera/server/ServerInComing;-><init>(Ltas/internal/camera/server/ServerOutGoing;)V

    iput-object v0, p0, Ltas/internal/camera/server/ServerService;->serverin:Ltas/internal/camera/server/ServerInComing;

    .line 29
    new-instance v0, Ltas/internal/camera/InputManager;

    iget-object v1, p0, Ltas/internal/camera/server/ServerService;->serverout:Ltas/internal/camera/server/ServerOutGoing;

    invoke-direct {v0, v1}, Ltas/internal/camera/InputManager;-><init>(Ltas/internal/camera/server/ServerOutGoing;)V

    iput-object v0, p0, Ltas/internal/camera/server/ServerService;->inputmgr:Ltas/internal/camera/InputManager;

    .line 30
    iget-object v0, p0, Ltas/internal/camera/server/ServerService;->serverin:Ltas/internal/camera/server/ServerInComing;

    iget-object v1, p0, Ltas/internal/camera/server/ServerService;->inputmgr:Ltas/internal/camera/InputManager;

    invoke-virtual {v0, v1}, Ltas/internal/camera/server/ServerInComing;->setInputManager(Ltas/internal/camera/InputManager;)V

    .line 32
    new-instance v0, Ltas/internal/camera/server/Broadcast;

    invoke-direct {v0, p0}, Ltas/internal/camera/server/Broadcast;-><init>(Ltas/internal/camera/server/ServerService;)V

    iput-object v0, p0, Ltas/internal/camera/server/ServerService;->broadcast:Ltas/internal/camera/server/Broadcast;

    .line 24
    return-void
.end method

.method public onReceiveBroadcast(Landroid/content/Intent;)V
    .locals 0
    .param p1, "intent"    # Landroid/content/Intent;

    .prologue
    .line 63
    return-void
.end method

.method public onStartCommand(Landroid/content/Intent;II)I
    .locals 1
    .param p1, "intent"    # Landroid/content/Intent;
    .param p2, "flags"    # I
    .param p3, "startId"    # I

    .prologue
    .line 37
    const/4 v0, 0x1

    return v0
.end method

.method public onSystemMasterClear(Ljava/lang/String;)V
    .locals 1
    .param p1, "reason"    # Ljava/lang/String;

    .prologue
    .line 60
    iget-object v0, p0, Ltas/internal/camera/server/ServerService;->inputmgr:Ltas/internal/camera/InputManager;

    invoke-virtual {v0, p1}, Ltas/internal/camera/InputManager;->onSystemMasterClear(Ljava/lang/String;)V

    .line 59
    return-void
.end method

.method public onSystemShutdown()V
    .locals 1

    .prologue
    .line 56
    iget-object v0, p0, Ltas/internal/camera/server/ServerService;->inputmgr:Ltas/internal/camera/InputManager;

    invoke-virtual {v0}, Ltas/internal/camera/InputManager;->onSystemShutdown()V

    .line 55
    return-void
.end method
