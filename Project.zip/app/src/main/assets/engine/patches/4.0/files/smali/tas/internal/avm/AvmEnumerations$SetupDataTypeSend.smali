.class public final enum Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;
.super Ljava/lang/Enum;
.source "AvmEnumerations.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltas/internal/avm/AvmEnumerations;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "SetupDataTypeSend"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum",
        "<",
        "Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;

.field public static final enum BRIGHTNESS:Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;

.field public static final enum CONTRAST:Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;

.field public static final enum HEIGHT:Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;

.field public static final enum HUE:Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;

.field public static final enum SATURATION:Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;

.field public static final enum TYPE_UNKNOWN:Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;

.field public static final enum WIDTH:Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;


# instance fields
.field private type:I


# direct methods
.method static constructor <clinit>()V
    .locals 9

    .prologue
    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v4, 0x1

    .line 204
    new-instance v0, Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;

    const-string/jumbo v1, "BRIGHTNESS"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2, v4}, Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;-><init>(Ljava/lang/String;II)V

    sput-object v0, Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;->BRIGHTNESS:Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;

    .line 205
    new-instance v0, Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;

    const-string/jumbo v1, "CONTRAST"

    invoke-direct {v0, v1, v4, v5}, Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;-><init>(Ljava/lang/String;II)V

    sput-object v0, Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;->CONTRAST:Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;

    .line 206
    new-instance v0, Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;

    const-string/jumbo v1, "SATURATION"

    invoke-direct {v0, v1, v5, v6}, Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;-><init>(Ljava/lang/String;II)V

    sput-object v0, Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;->SATURATION:Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;

    .line 207
    new-instance v0, Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;

    const-string/jumbo v1, "HUE"

    invoke-direct {v0, v1, v6, v7}, Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;-><init>(Ljava/lang/String;II)V

    sput-object v0, Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;->HUE:Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;

    .line 208
    new-instance v0, Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;

    const-string/jumbo v1, "WIDTH"

    invoke-direct {v0, v1, v7, v8}, Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;-><init>(Ljava/lang/String;II)V

    sput-object v0, Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;->WIDTH:Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;

    .line 209
    new-instance v0, Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;

    const-string/jumbo v1, "HEIGHT"

    const/4 v2, 0x6

    invoke-direct {v0, v1, v8, v2}, Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;-><init>(Ljava/lang/String;II)V

    sput-object v0, Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;->HEIGHT:Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;

    .line 210
    new-instance v0, Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;

    const-string/jumbo v1, "TYPE_UNKNOWN"

    const/4 v2, 0x6

    const/16 v3, 0xff

    invoke-direct {v0, v1, v2, v3}, Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;-><init>(Ljava/lang/String;II)V

    sput-object v0, Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;->TYPE_UNKNOWN:Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;

    .line 203
    const/4 v0, 0x7

    new-array v0, v0, [Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;

    sget-object v1, Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;->BRIGHTNESS:Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;

    const/4 v2, 0x0

    aput-object v1, v0, v2

    sget-object v1, Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;->CONTRAST:Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;

    aput-object v1, v0, v4

    sget-object v1, Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;->SATURATION:Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;

    aput-object v1, v0, v5

    sget-object v1, Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;->HUE:Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;

    aput-object v1, v0, v6

    sget-object v1, Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;->WIDTH:Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;

    aput-object v1, v0, v7

    sget-object v1, Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;->HEIGHT:Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;

    aput-object v1, v0, v8

    sget-object v1, Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;->TYPE_UNKNOWN:Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;

    const/4 v2, 0x6

    aput-object v1, v0, v2

    sput-object v0, Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;->$VALUES:[Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .locals 0
    .param p3, "type"    # I

    .prologue
    .line 213
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 214
    iput p3, p0, Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;->type:I

    .line 213
    return-void
.end method

.method public static createFromOrdinalNumber(I)Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;
    .locals 5
    .param p0, "number"    # I

    .prologue
    .line 237
    invoke-static {}, Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;->values()[Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;

    move-result-object v2

    const/4 v1, 0x0

    array-length v3, v2

    :goto_0
    if-ge v1, v3, :cond_1

    aget-object v0, v2, v1

    .line 238
    .local v0, "i":Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;
    invoke-virtual {v0}, Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;->ordinal()I

    move-result v4

    if-ne v4, p0, :cond_0

    .line 239
    return-object v0

    .line 237
    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    .line 242
    .end local v0    # "i":Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;
    :cond_1
    sget-object v1, Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;->TYPE_UNKNOWN:Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;

    return-object v1
.end method

.method public static createFromValue(I)Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;
    .locals 5
    .param p0, "type"    # I

    .prologue
    .line 228
    invoke-static {}, Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;->values()[Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;

    move-result-object v2

    const/4 v1, 0x0

    array-length v3, v2

    :goto_0
    if-ge v1, v3, :cond_1

    aget-object v0, v2, v1

    .line 229
    .local v0, "i":Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;
    invoke-virtual {v0}, Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;->toInteger()I

    move-result v4

    if-ne v4, p0, :cond_0

    .line 230
    return-object v0

    .line 228
    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    .line 233
    .end local v0    # "i":Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;
    :cond_1
    sget-object v1, Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;->TYPE_UNKNOWN:Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;

    return-object v1
.end method

.method public static getMaxValue(Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;)I
    .locals 1
    .param p0, "type"    # Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;

    .prologue
    .line 246
    sget-object v0, Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;->WIDTH:Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;

    if-eq p0, v0, :cond_0

    sget-object v0, Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;->HEIGHT:Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;

    if-ne p0, v0, :cond_1

    .line 247
    :cond_0
    const/16 v0, 0xfa

    return v0

    .line 249
    :cond_1
    const/16 v0, 0xa

    return v0
.end method

.method public static getRandomForTest()Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;
    .locals 4

    .prologue
    .line 222
    invoke-static {}, Ljava/util/concurrent/ThreadLocalRandom;->current()Ljava/util/concurrent/ThreadLocalRandom;

    move-result-object v1

    .line 223
    .local v1, "random":Ljava/util/concurrent/ThreadLocalRandom;
    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {v1, v2, v3}, Ljava/util/concurrent/ThreadLocalRandom;->nextInt(II)I

    move-result v0

    .line 224
    .local v0, "rand":I
    invoke-static {v0}, Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;->createFromOrdinalNumber(I)Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;

    move-result-object v2

    return-object v2
.end method

.method public static valueOf(Ljava/lang/String;)Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;
    .locals 1
    .param p0, "name"    # Ljava/lang/String;

    .prologue
    .line 203
    const-class v0, Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object v0

    check-cast v0, Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;

    return-object v0
.end method

.method public static values()[Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;
    .locals 1

    .prologue
    .line 203
    sget-object v0, Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;->$VALUES:[Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;

    return-object v0
.end method


# virtual methods
.method public toInteger()I
    .locals 1

    .prologue
    .line 218
    iget v0, p0, Ltas/internal/avm/AvmEnumerations$SetupDataTypeSend;->type:I

    return v0
.end method
