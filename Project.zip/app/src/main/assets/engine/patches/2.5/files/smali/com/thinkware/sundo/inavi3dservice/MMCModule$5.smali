.class Lcom/thinkware/sundo/inavi3dservice/MMCModule$5;
.super Ljava/lang/Object;
.source "MMCModule.java"

# interfaces
.implements Landroid/location/OnNmeaMessageListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/thinkware/sundo/inavi3dservice/MMCModule;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field private final mDelegate:Landroid/location/GpsStatus$NmeaListener;


# direct methods
.method public constructor <init>(Landroid/location/GpsStatus$NmeaListener;)V
    .locals 0
    .param p1, "delegate"    # Landroid/location/GpsStatus$NmeaListener;

    .prologue
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule$5;->mDelegate:Landroid/location/GpsStatus$NmeaListener;

    return-void
.end method


# virtual methods
.method public onNmeaMessage(Ljava/lang/String;J)V
    .locals 3
    .param p1, "message"    # Ljava/lang/String;
    .param p2, "timestamp"    # J

    .prologue
    :try_start_0
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule$5;->mDelegate:Landroid/location/GpsStatus$NmeaListener;

    invoke-interface {v0, p2, p3, p1}, Landroid/location/GpsStatus$NmeaListener;->onNmeaReceived(JLjava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :goto_0
    return-void

    :catch_0
    move-exception v0

    goto :goto_0
.end method
