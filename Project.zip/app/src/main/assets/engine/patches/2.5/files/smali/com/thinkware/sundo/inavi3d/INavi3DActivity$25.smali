.class Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;
.super Ljava/lang/Object;
.source "INavi3DActivity.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/thinkware/sundo/inavi3d/INavi3DActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25$splashhandler2;,
        Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25$splashhandler1;,
        Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25$splashhandler;
    }
.end annotation


# instance fields
.field final synthetic this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;


# direct methods
.method constructor <init>(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)V
    .locals 0

    .prologue
    .line 4354
    iput-object p1, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5007
    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 36
    .param p1, "v"    # Landroid/view/View;

    .prologue
    .line 4358
    sget-boolean v31, Lcom/thinkware/sundo/inavi3d/Inavi;->firstTBTGuide:Z

    if-eqz v31, :cond_1

    .line 4992
    .end local p1    # "v":Landroid/view/View;
    :cond_0
    :goto_0
    return-void

    .line 4363
    .restart local p1    # "v":Landroid/view/View;
    :cond_1
    sget v31, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_nPartitionMode:I

    const/16 v32, 0x7

    move/from16 v0, v31

    move/from16 v1, v32

    if-eq v0, v1, :cond_2

    sget v31, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_nPartitionMode:I

    const/16 v32, 0x8

    move/from16 v0, v31

    move/from16 v1, v32

    if-eq v0, v1, :cond_2

    sget v31, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_nPartitionMode:I

    const/16 v32, 0x6

    move/from16 v0, v31

    move/from16 v1, v32

    if-ne v0, v1, :cond_3

    .line 4366
    :cond_2
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    invoke-static/range {v31 .. v31}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$1300(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)Lcom/thinkware/sundo/inavi3d/Inavi;

    move-result-object v31

    const v32, 0x222e0

    const v33, 0x22337

    const/16 v34, 0x0

    const/16 v35, 0x0

    invoke-virtual/range {v31 .. v35}, Lcom/thinkware/sundo/inavi3d/Inavi;->PushMessage(IIII)V

    .line 4370
    :cond_3
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    invoke-virtual/range {v31 .. v31}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->isShownNIP()Z

    move-result v31

    if-eqz v31, :cond_4

    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Back:Landroid/widget/Button;

    move-object/from16 v31, v0

    move-object/from16 v0, p1

    move-object/from16 v1, v31

    if-eq v0, v1, :cond_4

    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Home:Landroid/widget/Button;

    move-object/from16 v31, v0

    move-object/from16 v0, p1

    move-object/from16 v1, v31

    if-eq v0, v1, :cond_4

    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Voice:Landroid/widget/Button;

    move-object/from16 v31, v0

    move-object/from16 v0, p1

    move-object/from16 v1, v31

    if-eq v0, v1, :cond_4

    .line 4372
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    invoke-virtual/range {v31 .. v31}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->hideNIP()V

    .line 4374
    :cond_4
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    invoke-virtual/range {v31 .. v31}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->isShowInaviDialog()Z

    move-result v31

    if-eqz v31, :cond_5

    .line 4375
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    invoke-virtual/range {v31 .. v31}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->DismissInaviDialog()V

    goto/16 :goto_0

    .line 4380
    :cond_5
    sget v31, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_nPartitionMode:I

    const/16 v32, 0x3

    move/from16 v0, v31

    move/from16 v1, v32

    if-eq v0, v1, :cond_6

    sget v31, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_nPartitionMode:I

    const/16 v32, 0x4

    move/from16 v0, v31

    move/from16 v1, v32

    if-eq v0, v1, :cond_6

    sget v31, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_nPartitionMode:I

    const/16 v32, 0x6

    move/from16 v0, v31

    move/from16 v1, v32

    if-eq v0, v1, :cond_6

    sget v31, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_nPartitionMode:I

    const/16 v32, 0x2

    move/from16 v0, v31

    move/from16 v1, v32

    if-ne v0, v1, :cond_7

    .line 4382
    :cond_6
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    invoke-static/range {v31 .. v31}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$1300(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)Lcom/thinkware/sundo/inavi3d/Inavi;

    move-result-object v31

    const/16 v32, 0x0

    const/16 v33, 0x0

    sget v34, Lcom/thinkware/sundo/inavi3d/Inavi;->MULTI_BUTTONUP:I

    invoke-virtual/range {v31 .. v34}, Lcom/thinkware/sundo/inavi3d/Inavi;->onSingleButton(FFI)V

    .line 4385
    :cond_7
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    invoke-virtual/range {v31 .. v31}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->onEnableStatusBar()V

    .line 4409
    invoke-virtual/range {p1 .. p1}, Landroid/view/View;->getVisibility()I

    move-result v31

    const/16 v32, 0x4

    move/from16 v0, v31

    move/from16 v1, v32

    if-eq v0, v1, :cond_0

    .line 4412
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-boolean v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->externalPositionMove:Z

    move/from16 v31, v0

    if-eqz v31, :cond_9

    .line 4413
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Current_off:Landroid/widget/Button;

    move-object/from16 v31, v0

    move-object/from16 v0, p1

    move-object/from16 v1, v31

    if-eq v0, v1, :cond_8

    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Home_off:Landroid/widget/Button;

    move-object/from16 v31, v0

    move-object/from16 v0, p1

    move-object/from16 v1, v31

    if-eq v0, v1, :cond_8

    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_RegistPointBtn:Landroid/widget/Button;

    move-object/from16 v31, v0

    move-object/from16 v0, p1

    move-object/from16 v1, v31

    if-eq v0, v1, :cond_8

    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_AroundSearchBtn:Landroid/widget/Button;

    move-object/from16 v31, v0

    move-object/from16 v0, p1

    move-object/from16 v1, v31

    if-eq v0, v1, :cond_8

    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_AroundSearchBtn:Landroid/widget/Button;

    move-object/from16 v31, v0

    move-object/from16 v0, p1

    move-object/from16 v1, v31

    if-ne v0, v1, :cond_9

    .line 4415
    :cond_8
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    const/16 v32, 0x0

    move/from16 v0, v32

    move-object/from16 v1, v31

    iput-boolean v0, v1, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->externalPositionMove:Z

    .line 4419
    :cond_9
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    move-result-object v31

    invoke-virtual/range {v31 .. v31}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->isRoadView()Z

    move-result v31

    const/16 v32, 0x1

    move/from16 v0, v31

    move/from16 v1, v32

    if-ne v0, v1, :cond_a

    .line 4420
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    invoke-static/range {v31 .. v31}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$3400(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)Landroid/view/View;

    move-result-object v31

    if-eqz v31, :cond_a

    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    invoke-static/range {v31 .. v31}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$3400(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)Landroid/view/View;

    move-result-object v31

    invoke-virtual/range {v31 .. v31}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v31

    move-object/from16 v0, v31

    instance-of v0, v0, Lcom/thinkware/sundo/inavi3d/ui/roadview/RoadViewActivity;

    if-eqz v0, :cond_a

    check-cast v31, Lcom/thinkware/sundo/inavi3d/ui/roadview/RoadViewActivity;

    invoke-virtual/range {v31 .. v31}, Lcom/thinkware/sundo/inavi3d/ui/roadview/RoadViewActivity;->isHiddenPipRoadView()Z

    move-result v31

    if-nez v31, :cond_a

    .line 4422
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    invoke-static/range {v31 .. v31}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$3400(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)Landroid/view/View;

    move-result-object v31

    invoke-virtual/range {v31 .. v31}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v31

    move-object/from16 v0, v31

    instance-of v0, v0, Lcom/thinkware/sundo/inavi3d/ui/roadview/RoadViewActivity;

    if-eqz v0, :cond_a

    check-cast v31, Lcom/thinkware/sundo/inavi3d/ui/roadview/RoadViewActivity;

    const/16 v32, 0x1

    invoke-virtual/range {v31 .. v32}, Lcom/thinkware/sundo/inavi3d/ui/roadview/RoadViewActivity;->setHiddenPipRoadView(Z)V

    .line 4426
    :cond_a
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_HighwayModeButton:Landroid/widget/ImageButton;

    move-object/from16 v31, v0

    move-object/from16 v0, p1

    move-object/from16 v1, v31

    if-ne v0, v1, :cond_b

    .line 4427
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    invoke-static/range {v31 .. v31}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$1300(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)Lcom/thinkware/sundo/inavi3d/Inavi;

    move-result-object v31

    const v32, 0x222e0

    const v33, 0x222e3

    const/16 v34, 0x0

    const/16 v35, 0x0

    invoke-virtual/range {v31 .. v35}, Lcom/thinkware/sundo/inavi3d/Inavi;->PushMessage(IIII)V

    goto/16 :goto_0

    .line 4428
    :cond_b
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_QuickSearch:Landroid/widget/ImageButton;

    move-object/from16 v31, v0

    move-object/from16 v0, p1

    move-object/from16 v1, v31

    if-ne v0, v1, :cond_c

    .line 4430
    new-instance v11, Landroid/content/Intent;

    invoke-direct {v11}, Landroid/content/Intent;-><init>()V

    .line 4431
    .local v11, "intent":Landroid/content/Intent;
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    invoke-virtual/range {v31 .. v31}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getApplication()Landroid/app/Application;

    move-result-object v31

    const-class v32, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;

    move-object/from16 v0, v31

    move-object/from16 v1, v32

    invoke-virtual {v11, v0, v1}, Landroid/content/Intent;->setClass(Landroid/content/Context;Ljava/lang/Class;)Landroid/content/Intent;

    .line 4432
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    invoke-virtual {v0, v11}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->startActivity(Landroid/content/Intent;)V

    goto/16 :goto_0

    .line 4440
    .end local v11    # "intent":Landroid/content/Intent;
    :cond_c
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_GPSButton:Lcom/thinkware/sundo/inavi3d/ui/component/GpsButton;

    move-object/from16 v31, v0

    move-object/from16 v0, p1

    move-object/from16 v1, v31

    if-eq v0, v1, :cond_d

    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_GPSButtonOff:Lcom/thinkware/sundo/inavi3d/ui/component/GpsButton;

    move-object/from16 v31, v0

    move-object/from16 v0, p1

    move-object/from16 v1, v31

    if-ne v0, v1, :cond_e

    .line 4441
    :cond_d
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    invoke-static/range {v31 .. v31}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$6200(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)V

    goto/16 :goto_0

    .line 4442
    :cond_e
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_VolumeButton:Landroid/widget/ImageButton;

    move-object/from16 v31, v0

    move-object/from16 v0, p1

    move-object/from16 v1, v31

    if-ne v0, v1, :cond_f

    .line 4443
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    invoke-static/range {v31 .. v31}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$6300(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)V

    goto/16 :goto_0

    .line 4444
    :cond_f
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_LevelBar:Landroid/widget/ImageButton;

    move-object/from16 v31, v0

    move-object/from16 v0, p1

    move-object/from16 v1, v31

    if-eq v0, v1, :cond_10

    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_LevelBarOff:Landroid/widget/ImageButton;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    move-object/from16 v1, p1

    if-ne v0, v1, :cond_11

    .line 4445
    :cond_10
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    invoke-static/range {v31 .. v31}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$6400(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)V

    goto/16 :goto_0

    .line 4446
    :cond_11
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_QuickMenuButton:Landroid/widget/ImageButton;

    move-object/from16 v31, v0

    move-object/from16 v0, p1

    move-object/from16 v1, v31

    if-ne v0, v1, :cond_12

    .line 4447
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_QuickMenuButton:Landroid/widget/ImageButton;

    move-object/from16 v31, v0

    const v32, 0x7f020097

    invoke-virtual/range {v31 .. v32}, Landroid/widget/ImageButton;->setImageResource(I)V

    .line 4448
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    invoke-static/range {v31 .. v31}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$6500(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)V

    goto/16 :goto_0

    .line 4449
    :cond_12
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_DualGPSButton:Lcom/thinkware/sundo/inavi3d/ui/component/GpsButton;

    move-object/from16 v31, v0

    move-object/from16 v0, p1

    move-object/from16 v1, v31

    if-eq v0, v1, :cond_13

    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_DualGPSButtonOff:Lcom/thinkware/sundo/inavi3d/ui/component/GpsButton;

    move-object/from16 v31, v0

    move-object/from16 v0, p1

    move-object/from16 v1, v31

    if-ne v0, v1, :cond_14

    .line 4450
    :cond_13
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    invoke-static/range {v31 .. v31}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$1300(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)Lcom/thinkware/sundo/inavi3d/Inavi;

    move-result-object v31

    const v32, 0x222e0

    const v33, 0x222f4

    const/16 v34, 0x0

    const/16 v35, 0x0

    invoke-virtual/range {v31 .. v35}, Lcom/thinkware/sundo/inavi3d/Inavi;->PushMessage(IIII)V

    goto/16 :goto_0

    .line 4452
    :cond_14
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_GPSButtonDetour:Lcom/thinkware/sundo/inavi3d/ui/component/GpsButton;

    move-object/from16 v31, v0

    move-object/from16 v0, p1

    move-object/from16 v1, v31

    if-eq v0, v1, :cond_15

    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_GPSButtonRouteTotal:Lcom/thinkware/sundo/inavi3d/ui/component/GpsButton;

    move-object/from16 v31, v0

    move-object/from16 v0, p1

    move-object/from16 v1, v31

    if-eq v0, v1, :cond_15

    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_GPSButtonNameSearch:Lcom/thinkware/sundo/inavi3d/ui/component/GpsButton;

    move-object/from16 v31, v0

    move-object/from16 v0, p1

    move-object/from16 v1, v31

    if-eq v0, v1, :cond_15

    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_GPSButtonRouteResult:Lcom/thinkware/sundo/inavi3d/ui/component/GpsButton;

    move-object/from16 v31, v0

    move-object/from16 v0, p1

    move-object/from16 v1, v31

    if-eq v0, v1, :cond_15

    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_GPSButtonRoutePoint:Lcom/thinkware/sundo/inavi3d/ui/component/GpsButton;

    move-object/from16 v31, v0

    move-object/from16 v0, p1

    move-object/from16 v1, v31

    if-ne v0, v1, :cond_26

    :cond_15
    move-object/from16 v31, p1

    .line 4453
    check-cast v31, Lcom/thinkware/sundo/inavi3d/ui/component/GpsButton;

    invoke-virtual/range {v31 .. v31}, Lcom/thinkware/sundo/inavi3d/ui/component/GpsButton;->getFlightMode()I

    move-result v16

    .line 4454
    .local v16, "mode":I
    add-int/lit8 v31, v16, 0x1

    rem-int/lit8 v29, v31, 0x2

    .line 4455
    .local v29, "toggleMode":I
    const/16 v22, 0x0

    .line 4457
    .local v22, "ret":Z
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_NameSearchLayout:Landroid/widget/RelativeLayout;

    move-object/from16 v31, v0

    invoke-virtual/range {v31 .. v31}, Landroid/widget/RelativeLayout;->getVisibility()I

    move-result v31

    if-nez v31, :cond_1f

    .line 4458
    invoke-static/range {v29 .. v29}, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->toggleViewMode(I)Z

    move-result v22

    .line 4459
    if-eqz v22, :cond_16

    .line 4460
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    move-result-object v31

    move-object/from16 v0, v31

    move/from16 v1, v29

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->setNameSearchViewModeValue(I)V

    .line 4465
    :cond_16
    :goto_1
    const/16 v31, 0x1

    move/from16 v0, v22

    move/from16 v1, v31

    if-ne v0, v1, :cond_1e

    .line 4466
    check-cast p1, Lcom/thinkware/sundo/inavi3d/ui/component/GpsButton;

    .end local p1    # "v":Landroid/view/View;
    move-object/from16 v0, p1

    move/from16 v1, v29

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/inavi3d/ui/component/GpsButton;->setFlightMode(I)V

    .line 4467
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    invoke-virtual/range {v31 .. v31}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getMaxAeroLevel()I

    .line 4469
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_RouteResultLayOut:Landroid/widget/LinearLayout;

    move-object/from16 v31, v0

    invoke-virtual/range {v31 .. v31}, Landroid/widget/LinearLayout;->getVisibility()I

    move-result v31

    if-eqz v31, :cond_17

    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_DetourLayOut:Landroid/widget/LinearLayout;

    move-object/from16 v31, v0

    invoke-virtual/range {v31 .. v31}, Landroid/widget/LinearLayout;->getVisibility()I

    move-result v31

    if-nez v31, :cond_19

    .line 4471
    :cond_17
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    move-result-object v31

    move-object/from16 v0, v31

    move/from16 v1, v29

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->setViewModeValue(I)V

    .line 4472
    sget v31, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_oldMapMode:I

    move/from16 v0, v31

    move/from16 v1, v29

    if-eq v0, v1, :cond_20

    if-nez v29, :cond_20

    sget v31, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_nMapLevel:I

    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v32, v0

    invoke-static/range {v32 .. v32}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$6600(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)I

    move-result v32

    move/from16 v0, v31

    move/from16 v1, v32

    if-ne v0, v1, :cond_20

    sget v31, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_nOldMapLevel:I

    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v32, v0

    invoke-static/range {v32 .. v32}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$6600(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)I

    move-result v32

    move/from16 v0, v31

    move/from16 v1, v32

    if-le v0, v1, :cond_20

    .line 4482
    :cond_18
    :goto_2
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    sget v32, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_nMapLevel:I

    move-object/from16 v0, v31

    move/from16 v1, v32

    move/from16 v2, v29

    invoke-static {v0, v1, v2}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$2900(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;II)V

    .line 4485
    :cond_19
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_RouteTotalLayout:Landroid/widget/RelativeLayout;

    move-object/from16 v31, v0

    invoke-virtual/range {v31 .. v31}, Landroid/widget/RelativeLayout;->getVisibility()I

    move-result v31

    if-nez v31, :cond_1b

    .line 4486
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    move-result-object v31

    move-object/from16 v0, v31

    move/from16 v1, v29

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->setEntireRouteViewModeValue(I)V

    .line 4488
    sget v31, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_oldMapMode:I

    move/from16 v0, v31

    move/from16 v1, v29

    if-eq v0, v1, :cond_22

    if-nez v29, :cond_22

    sget v31, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_nMapLevel:I

    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v32, v0

    invoke-static/range {v32 .. v32}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$6600(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)I

    move-result v32

    move/from16 v0, v31

    move/from16 v1, v32

    if-ne v0, v1, :cond_22

    sget v31, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_nOldMapLevel:I

    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v32, v0

    invoke-static/range {v32 .. v32}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$6600(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)I

    move-result v32

    move/from16 v0, v31

    move/from16 v1, v32

    if-le v0, v1, :cond_22

    .line 4498
    :cond_1a
    :goto_3
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    sget v32, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_nMapLevel:I

    move-object/from16 v0, v31

    move/from16 v1, v32

    move/from16 v2, v29

    invoke-static {v0, v1, v2}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$2900(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;II)V

    .line 4501
    :cond_1b
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_RoutePointLayout:Landroid/widget/RelativeLayout;

    move-object/from16 v31, v0

    invoke-virtual/range {v31 .. v31}, Landroid/widget/RelativeLayout;->getVisibility()I

    move-result v31

    if-nez v31, :cond_1d

    .line 4502
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    move-result-object v31

    move-object/from16 v0, v31

    move/from16 v1, v29

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->setRoutePointManageViewModeValue(I)V

    .line 4503
    sget v31, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_oldMapMode:I

    move/from16 v0, v31

    move/from16 v1, v29

    if-eq v0, v1, :cond_24

    if-nez v29, :cond_24

    sget v31, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_nMapLevel:I

    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v32, v0

    invoke-static/range {v32 .. v32}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$6600(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)I

    move-result v32

    move/from16 v0, v31

    move/from16 v1, v32

    if-ne v0, v1, :cond_24

    sget v31, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_nOldMapLevel:I

    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v32, v0

    invoke-static/range {v32 .. v32}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$6600(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)I

    move-result v32

    move/from16 v0, v31

    move/from16 v1, v32

    if-le v0, v1, :cond_24

    .line 4513
    :cond_1c
    :goto_4
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    sget v32, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_nMapLevel:I

    move-object/from16 v0, v31

    move/from16 v1, v32

    move/from16 v2, v29

    invoke-static {v0, v1, v2}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$2900(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;II)V

    .line 4518
    :cond_1d
    sput v29, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_oldMapMode:I

    .line 4521
    :cond_1e
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    invoke-static/range {v31 .. v31}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$2800(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)V

    goto/16 :goto_0

    .line 4463
    .restart local p1    # "v":Landroid/view/View;
    :cond_1f
    const/16 v31, 0x1

    move/from16 v0, v29

    move/from16 v1, v31

    invoke-static {v0, v1}, Lcom/thinkware/sundo/inavi3d/Inavi;->ToggleViewModeSafe(IZ)Z

    move-result v22

    goto/16 :goto_1

    .line 4476
    .end local p1    # "v":Landroid/view/View;
    :cond_20
    sget v31, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_oldMapMode:I

    move/from16 v0, v31

    move/from16 v1, v29

    if-eq v0, v1, :cond_21

    const/16 v31, 0x1

    move/from16 v0, v29

    move/from16 v1, v31

    if-ne v0, v1, :cond_21

    sget v31, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_nMapLevel:I

    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v32, v0

    invoke-static/range {v32 .. v32}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$6600(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)I

    move-result v32

    move/from16 v0, v31

    move/from16 v1, v32

    if-gt v0, v1, :cond_18

    .line 4480
    :cond_21
    sget v31, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_nMapLevel:I

    sput v31, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_nOldMapLevel:I

    goto/16 :goto_2

    .line 4492
    :cond_22
    sget v31, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_oldMapMode:I

    move/from16 v0, v31

    move/from16 v1, v29

    if-eq v0, v1, :cond_23

    const/16 v31, 0x1

    move/from16 v0, v29

    move/from16 v1, v31

    if-ne v0, v1, :cond_23

    sget v31, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_nMapLevel:I

    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v32, v0

    invoke-static/range {v32 .. v32}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$6600(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)I

    move-result v32

    move/from16 v0, v31

    move/from16 v1, v32

    if-gt v0, v1, :cond_1a

    .line 4496
    :cond_23
    sget v31, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_nMapLevel:I

    sput v31, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_nOldMapLevel:I

    goto/16 :goto_3

    .line 4507
    :cond_24
    sget v31, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_oldMapMode:I

    move/from16 v0, v31

    move/from16 v1, v29

    if-eq v0, v1, :cond_25

    const/16 v31, 0x1

    move/from16 v0, v29

    move/from16 v1, v31

    if-ne v0, v1, :cond_25

    sget v31, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_nMapLevel:I

    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v32, v0

    invoke-static/range {v32 .. v32}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$6600(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)I

    move-result v32

    move/from16 v0, v31

    move/from16 v1, v32

    if-gt v0, v1, :cond_1c

    .line 4511
    :cond_25
    sget v31, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_nMapLevel:I

    sput v31, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_nOldMapLevel:I

    goto/16 :goto_4

    .line 4522
    .end local v16    # "mode":I
    .end local v22    # "ret":Z
    .end local v29    # "toggleMode":I
    .restart local p1    # "v":Landroid/view/View;
    :cond_26
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_DriveCourseView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/DriveCourseView;

    move-object/from16 v31, v0

    move-object/from16 v0, p1

    move-object/from16 v1, v31

    if-ne v0, v1, :cond_27

    .line 4532
    new-instance v11, Landroid/content/Intent;

    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    const-class v32, Lcom/thinkware/sundo/inavi3d/MapPopup/RouteInfoMapPopup;

    move-object/from16 v0, v31

    move-object/from16 v1, v32

    invoke-direct {v11, v0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 4534
    .restart local v11    # "intent":Landroid/content/Intent;
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/Inavi;->getTbtguide()Lcom/thinkware/sundo/remoteTBT/TBTGuide;

    move-result-object v28

    .line 4535
    .local v28, "tbtguide":Lcom/thinkware/sundo/remoteTBT/TBTGuide;
    if-eqz v28, :cond_0

    .line 4538
    const-string v6, ""

    .line 4540
    .local v6, "RouteOption":Ljava/lang/String;
    :try_start_0
    new-instance v31, Ljava/lang/String;

    move-object/from16 v0, v28

    iget-object v0, v0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->routeoption:[B

    move-object/from16 v32, v0

    const-string v33, "EUC-KR"

    invoke-direct/range {v31 .. v33}, Ljava/lang/String;-><init>([BLjava/lang/String;)V

    invoke-virtual/range {v31 .. v31}, Ljava/lang/String;->trim()Ljava/lang/String;
    :try_end_0
    .catch Ljava/io/UnsupportedEncodingException; {:try_start_0 .. :try_end_0} :catch_0

    move-result-object v6

    .line 4545
    :goto_5
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    invoke-static/range {v31 .. v31}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$5900(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)[Lcom/thinkware/sundo/inavi3d/Struct/WeatherInfo;

    move-result-object v30

    .line 4551
    .local v30, "weatherinfo":[Lcom/thinkware/sundo/inavi3d/Struct/WeatherInfo;
    const-string v31, "weatherinfo"

    move-object/from16 v0, v31

    move-object/from16 v1, v30

    invoke-virtual {v11, v0, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;[Landroid/os/Parcelable;)Landroid/content/Intent;

    .line 4553
    const-string v31, "RouteOptionName"

    move-object/from16 v0, v31

    invoke-virtual {v11, v0, v6}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 4554
    const-string v31, "RouteOptionValue"

    move-object/from16 v0, v28

    iget v0, v0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->routeindex:I

    move/from16 v32, v0

    move-object/from16 v0, v31

    move/from16 v1, v32

    invoke-virtual {v11, v0, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 4556
    const-string v31, "bSimul"

    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v32, v0

    move-object/from16 v0, v32

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_simulatemode:Lcom/thinkware/sundo/inavi3d/ui/component/SimulateMode;

    move-object/from16 v32, v0

    invoke-virtual/range {v32 .. v32}, Lcom/thinkware/sundo/inavi3d/ui/component/SimulateMode;->isSimulate()Z

    move-result v32

    move-object/from16 v0, v31

    move/from16 v1, v32

    invoke-virtual {v11, v0, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    .line 4559
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    const/16 v32, 0x456

    move-object/from16 v0, v31

    move/from16 v1, v32

    invoke-virtual {v0, v11, v1}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->startActivityForResult(Landroid/content/Intent;I)V

    goto/16 :goto_0

    .line 4541
    .end local v30    # "weatherinfo":[Lcom/thinkware/sundo/inavi3d/Struct/WeatherInfo;
    :catch_0
    move-exception v7

    .line 4543
    .local v7, "e":Ljava/io/UnsupportedEncodingException;
    invoke-virtual {v7}, Ljava/io/UnsupportedEncodingException;->printStackTrace()V

    goto :goto_5

    .line 4560
    .end local v6    # "RouteOption":Ljava/lang/String;
    .end local v7    # "e":Ljava/io/UnsupportedEncodingException;
    .end local v11    # "intent":Landroid/content/Intent;
    .end local v28    # "tbtguide":Lcom/thinkware/sundo/remoteTBT/TBTGuide;
    :cond_27
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_LaneInfoview:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/LaneInfoView;

    move-object/from16 v31, v0

    move-object/from16 v0, p1

    move-object/from16 v1, v31

    if-ne v0, v1, :cond_2c

    .line 4562
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/Inavi;->getTbtguide()Lcom/thinkware/sundo/remoteTBT/TBTGuide;

    move-result-object v31

    move-object/from16 v0, v31

    iget v0, v0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->isroute:I

    move/from16 v31, v0

    if-eqz v31, :cond_2b

    .line 4563
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->getInstance()Lcom/thinkware/sundo/inavi3d/InaviConfig;

    move-result-object v31

    const/16 v32, 0x117

    const/16 v33, 0x1

    invoke-virtual/range {v31 .. v33}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->CNaviConfigSet(II)Z

    .line 4564
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->getInstance()Lcom/thinkware/sundo/inavi3d/InaviConfig;

    move-result-object v31

    invoke-virtual/range {v31 .. v31}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->SetConfigSave()Z

    .line 4565
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    invoke-static/range {v31 .. v31}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$1300(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)Lcom/thinkware/sundo/inavi3d/Inavi;

    move-result-object v31

    const v32, 0x222e0

    const v33, 0x223c6

    const/16 v34, 0x0

    const/16 v35, 0x0

    invoke-virtual/range {v31 .. v35}, Lcom/thinkware/sundo/inavi3d/Inavi;->PushMessage(IIII)V

    .line 4567
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_LaneAndTurnMode:Lcom/thinkware/sundo/inavi3d/ui/component/LaneAndTurnMode;

    move-object/from16 v31, v0

    if-eqz v31, :cond_28

    .line 4568
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_LaneAndTurnMode:Lcom/thinkware/sundo/inavi3d/ui/component/LaneAndTurnMode;

    move-object/from16 v31, v0

    invoke-virtual/range {v31 .. v31}, Lcom/thinkware/sundo/inavi3d/ui/component/LaneAndTurnMode;->setListPositionToFirst()V

    .line 4571
    :cond_28
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->getInstance()Lcom/thinkware/sundo/inavi3d/InaviConfig;

    move-result-object v31

    const/16 v32, 0x118

    invoke-virtual/range {v31 .. v32}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->CNaviConfigGet(I)I

    move-result v19

    .line 4572
    .local v19, "nMode":I
    sget-object v31, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->naviactivity:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_LaneAndTurnMode:Lcom/thinkware/sundo/inavi3d/ui/component/LaneAndTurnMode;

    move-object/from16 v31, v0

    if-eqz v19, :cond_29

    sget-object v31, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->naviactivity:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_LaneAndTurnMode:Lcom/thinkware/sundo/inavi3d/ui/component/LaneAndTurnMode;

    move-object/from16 v31, v0

    const/16 v31, 0x1

    move/from16 v0, v19

    move/from16 v1, v31

    if-ne v0, v1, :cond_2a

    .line 4574
    :cond_29
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    invoke-static/range {v31 .. v31}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$1300(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)Lcom/thinkware/sundo/inavi3d/Inavi;

    move-result-object v31

    const v32, 0x222e0

    const v33, 0x223c1

    const/16 v34, 0x0

    move-object/from16 v0, v31

    move/from16 v1, v32

    move/from16 v2, v33

    move/from16 v3, v19

    move/from16 v4, v34

    invoke-virtual {v0, v1, v2, v3, v4}, Lcom/thinkware/sundo/inavi3d/Inavi;->PushMessage(IIII)V

    .line 4575
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    invoke-static/range {v31 .. v31}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$1300(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)Lcom/thinkware/sundo/inavi3d/Inavi;

    move-result-object v31

    const v32, 0x222e0

    const v33, 0x223c2

    const/16 v34, 0x0

    const/16 v35, 0x0

    invoke-virtual/range {v31 .. v35}, Lcom/thinkware/sundo/inavi3d/Inavi;->PushMessage(IIII)V

    goto/16 :goto_0

    .line 4577
    :cond_2a
    sget-object v31, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->naviactivity:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_LaneAndTurnMode:Lcom/thinkware/sundo/inavi3d/ui/component/LaneAndTurnMode;

    move-object/from16 v31, v0

    const/16 v31, 0x2

    move/from16 v0, v19

    move/from16 v1, v31

    if-ne v0, v1, :cond_0

    .line 4579
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    invoke-static/range {v31 .. v31}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$1300(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)Lcom/thinkware/sundo/inavi3d/Inavi;

    move-result-object v31

    const v32, 0x222e0

    const v33, 0x223c1

    const/16 v34, 0x0

    move-object/from16 v0, v31

    move/from16 v1, v32

    move/from16 v2, v33

    move/from16 v3, v19

    move/from16 v4, v34

    invoke-virtual {v0, v1, v2, v3, v4}, Lcom/thinkware/sundo/inavi3d/Inavi;->PushMessage(IIII)V

    .line 4580
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    invoke-static/range {v31 .. v31}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$1300(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)Lcom/thinkware/sundo/inavi3d/Inavi;

    move-result-object v31

    const v32, 0x222e0

    const v33, 0x223c3

    const/16 v34, 0x0

    const/16 v35, 0x0

    invoke-virtual/range {v31 .. v35}, Lcom/thinkware/sundo/inavi3d/Inavi;->PushMessage(IIII)V

    goto/16 :goto_0

    .line 4584
    .end local v19    # "nMode":I
    :cond_2b
    const/16 v31, 0x30

    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v32, v0

    const-string v33, "\ud655\uc778"

    const-string v34, "\uc124\uc815\ub41c \uacbd\ub85c\uac00 \uc5c6\uc2b5\ub2c8\ub2e4."

    const/16 v35, 0x0

    invoke-static/range {v31 .. v35}, Lcom/thinkware/sundo/inavi3d/ui/popup/PopupManager;->ShowPopup(ILandroid/content/Context;Ljava/lang/String;Ljava/lang/String;I)Lcom/thinkware/sundo/inavi3d/ui/popup/InaviPopup;

    goto/16 :goto_0

    .line 4586
    :cond_2c
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_TrafficButton:Lcom/thinkware/sundo/inavi3d/ui/component/TrafficButton;

    move-object/from16 v31, v0

    move-object/from16 v0, p1

    move-object/from16 v1, v31

    if-ne v0, v1, :cond_32

    .line 4587
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/trafficinfo/TrafficInfo;->getInstance()Lcom/thinkware/sundo/inavi3d/trafficinfo/TrafficInfo;

    move-result-object v31

    invoke-virtual/range {v31 .. v31}, Lcom/thinkware/sundo/inavi3d/trafficinfo/TrafficInfo;->_GetCurrentTrafficServiceType()I

    move-result v18

    .line 4588
    .local v18, "nCurrentType":I
    const-string v26, ""

    .line 4590
    .local v26, "strTrafficType":Ljava/lang/String;
    const/16 v31, 0x2

    move/from16 v0, v18

    move/from16 v1, v31

    if-ne v0, v1, :cond_2e

    .line 4592
    const-string v26, "DMB TPEG\uc774"

    .line 4602
    :cond_2d
    :goto_6
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/trafficinfo/TrafficInfo;->getInstance()Lcom/thinkware/sundo/inavi3d/trafficinfo/TrafficInfo;

    move-result-object v31

    move-object/from16 v0, v31

    move/from16 v1, v18

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/inavi3d/trafficinfo/TrafficInfo;->_IsOnOffTrafficServiceType(I)I

    move-result v31

    if-nez v31, :cond_30

    .line 4604
    const/16 v31, 0x20

    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v32, v0

    const-string v33, ""

    new-instance v34, Ljava/lang/StringBuilder;

    invoke-direct/range {v34 .. v34}, Ljava/lang/StringBuilder;-><init>()V

    move-object/from16 v0, v34

    move-object/from16 v1, v26

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v34

    const-string v35, " OFF \uc0c1\ud0dc\uc785\ub2c8\ub2e4.\n ON \ud558\uc2dc\uaca0\uc2b5\ub2c8\uae4c?"

    invoke-virtual/range {v34 .. v35}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v34

    invoke-virtual/range {v34 .. v34}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v34

    const/16 v35, 0x0

    invoke-static/range {v31 .. v35}, Lcom/thinkware/sundo/inavi3d/ui/popup/PopupManager;->ShowPopup(ILandroid/content/Context;Ljava/lang/String;Ljava/lang/String;I)Lcom/thinkware/sundo/inavi3d/ui/popup/InaviPopup;

    move-result-object v20

    .line 4605
    .local v20, "popupme":Landroid/app/Dialog;
    new-instance v31, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25$1;

    move-object/from16 v0, v31

    move-object/from16 v1, p0

    move-object/from16 v2, v20

    invoke-direct {v0, v1, v2}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25$1;-><init>(Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;Landroid/app/Dialog;)V

    invoke-static/range {v31 .. v31}, Lcom/thinkware/sundo/inavi3d/ui/popup/PopupManager;->SetokListner(Landroid/view/View$OnClickListener;)Z

    goto/16 :goto_0

    .line 4594
    .end local v20    # "popupme":Landroid/app/Dialog;
    :cond_2e
    const/16 v31, 0x3

    move/from16 v0, v18

    move/from16 v1, v31

    if-ne v0, v1, :cond_2f

    .line 4596
    const-string v26, "TCON+\uac00"

    goto :goto_6

    .line 4598
    :cond_2f
    const/16 v31, 0x4

    move/from16 v0, v18

    move/from16 v1, v31

    if-ne v0, v1, :cond_2d

    .line 4600
    const-string v26, "\ud1b5\uacc4\uad50\ud1b5\uc774"

    goto :goto_6

    .line 4616
    :cond_30
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_TrafficButton:Lcom/thinkware/sundo/inavi3d/ui/component/TrafficButton;

    move-object/from16 v31, v0

    invoke-virtual/range {v31 .. v31}, Lcom/thinkware/sundo/inavi3d/ui/component/TrafficButton;->getAccidentControlStatus()Z

    move-result v31

    if-eqz v31, :cond_31

    .line 4617
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    invoke-static/range {v31 .. v31}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$1300(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)Lcom/thinkware/sundo/inavi3d/Inavi;

    move-result-object v31

    const v32, 0x222e0

    const v33, 0x223b3

    const/16 v34, 0x0

    const/16 v35, 0x0

    invoke-virtual/range {v31 .. v35}, Lcom/thinkware/sundo/inavi3d/Inavi;->PushMessage(IIII)V

    goto/16 :goto_0

    .line 4619
    :cond_31
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    invoke-static/range {v31 .. v31}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$6700(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)V

    goto/16 :goto_0

    .line 4622
    .end local v18    # "nCurrentType":I
    .end local v26    # "strTrafficType":Ljava/lang/String;
    :cond_32
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_RegPointBtn:Landroid/widget/Button;

    move-object/from16 v31, v0

    move-object/from16 v0, p1

    move-object/from16 v1, v31

    if-ne v0, v1, :cond_37

    .line 4624
    new-instance v13, Lcom/thinkware/sundo/inavi3d/provider/UserItem;

    invoke-direct {v13}, Lcom/thinkware/sundo/inavi3d/provider/UserItem;-><init>()V

    .line 4625
    .local v13, "item":Lcom/thinkware/sundo/inavi3d/provider/UserItem;
    invoke-virtual {v13}, Lcom/thinkware/sundo/inavi3d/provider/UserItem;->InitMembers()V

    .line 4626
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/Inavi;->GetStrRegSrchName()Ljava/lang/String;

    move-result-object v21

    .line 4629
    .local v21, "regSrchName":Ljava/lang/String;
    invoke-virtual/range {v21 .. v21}, Ljava/lang/String;->length()I

    move-result v31

    const/16 v32, 0xa

    move/from16 v0, v31

    move/from16 v1, v32

    if-le v0, v1, :cond_33

    .line 4631
    const/16 v31, 0x0

    const/16 v32, 0xa

    move-object/from16 v0, v21

    move/from16 v1, v31

    move/from16 v2, v32

    invoke-virtual {v0, v1, v2}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v21

    .line 4634
    :cond_33
    if-eqz v21, :cond_34

    invoke-virtual/range {v21 .. v21}, Ljava/lang/String;->length()I

    move-result v31

    const/16 v32, 0x1

    move/from16 v0, v31

    move/from16 v1, v32

    if-lt v0, v1, :cond_35

    :cond_34
    const-string v31, "\uc9d1"

    move-object/from16 v0, v21

    move-object/from16 v1, v31

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v31

    if-nez v31, :cond_35

    const-string v31, "\uc790\uc8fc\uac00\ub294\uacf3"

    move-object/from16 v0, v21

    move-object/from16 v1, v31

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v31

    if-nez v31, :cond_35

    invoke-virtual/range {v21 .. v21}, Ljava/lang/String;->length()I

    move-result v31

    const/16 v32, 0xa

    move/from16 v0, v31

    move/from16 v1, v32

    if-le v0, v1, :cond_36

    .line 4637
    :cond_35
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/MapPopup/RouteInfoMapPopup;->GetCommonAddrName()Ljava/lang/String;

    move-result-object v21

    .line 4640
    :cond_36
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/Inavi;->getMapCenterX()I

    move-result v31

    move/from16 v0, v31

    invoke-virtual {v13, v0}, Lcom/thinkware/sundo/inavi3d/provider/UserItem;->setX(I)V

    .line 4641
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/Inavi;->getMapCenterY()I

    move-result v31

    move/from16 v0, v31

    invoke-virtual {v13, v0}, Lcom/thinkware/sundo/inavi3d/provider/UserItem;->setY(I)V

    .line 4642
    move-object/from16 v0, v21

    invoke-virtual {v13, v0}, Lcom/thinkware/sundo/inavi3d/provider/UserItem;->setName(Ljava/lang/String;)V

    .line 4644
    new-instance v11, Landroid/content/Intent;

    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    const-class v32, Lcom/thinkware/sundo/inavi3d/ui/userdata/UserPointAddActivity;

    move-object/from16 v0, v31

    move-object/from16 v1, v32

    invoke-direct {v11, v0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 4646
    .restart local v11    # "intent":Landroid/content/Intent;
    const-string v31, "Mode"

    const/16 v32, 0x1

    move-object/from16 v0, v31

    move/from16 v1, v32

    invoke-virtual {v11, v0, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 4647
    const-string v31, "UserItem"

    move-object/from16 v0, v31

    invoke-virtual {v11, v0, v13}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/io/Serializable;)Landroid/content/Intent;

    .line 4649
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    const/16 v32, 0x7d2

    move-object/from16 v0, v31

    move/from16 v1, v32

    invoke-virtual {v0, v11, v1}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->startActivityForResult(Landroid/content/Intent;I)V

    goto/16 :goto_0

    .line 4652
    .end local v11    # "intent":Landroid/content/Intent;
    .end local v13    # "item":Lcom/thinkware/sundo/inavi3d/provider/UserItem;
    .end local v21    # "regSrchName":Ljava/lang/String;
    :cond_37
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StartPointBtn:Landroid/widget/Button;

    move-object/from16 v31, v0

    move-object/from16 v0, p1

    move-object/from16 v1, v31

    if-ne v0, v1, :cond_38

    .line 4653
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    invoke-static/range {v31 .. v31}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$1300(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)Lcom/thinkware/sundo/inavi3d/Inavi;

    move-result-object v31

    const v32, 0x222e0

    const v33, 0x222e9

    const/16 v34, 0x0

    const/16 v35, 0x0

    invoke-virtual/range {v31 .. v35}, Lcom/thinkware/sundo/inavi3d/Inavi;->PushMessage(IIII)V

    goto/16 :goto_0

    .line 4655
    :cond_38
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_EndPointBtn:Landroid/widget/Button;

    move-object/from16 v31, v0

    move-object/from16 v0, p1

    move-object/from16 v1, v31

    if-ne v0, v1, :cond_39

    .line 4658
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_EndPointBtn:Landroid/widget/Button;

    move-object/from16 v31, v0

    const/16 v32, 0x0

    invoke-virtual/range {v31 .. v32}, Landroid/widget/Button;->setEnabled(Z)V

    .line 4659
    new-instance v10, Landroid/os/Handler;

    invoke-direct {v10}, Landroid/os/Handler;-><init>()V

    .line 4660
    .local v10, "h":Landroid/os/Handler;
    new-instance v31, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25$splashhandler;

    move-object/from16 v0, v31

    move-object/from16 v1, p0

    invoke-direct {v0, v1}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25$splashhandler;-><init>(Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;)V

    const-wide/16 v32, 0x3e8

    move-object/from16 v0, v31

    move-wide/from16 v1, v32

    invoke-virtual {v10, v0, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 4662
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    invoke-static/range {v31 .. v31}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$1300(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)Lcom/thinkware/sundo/inavi3d/Inavi;

    move-result-object v31

    const v32, 0x222e0

    const v33, 0x222ea

    const/16 v34, 0x0

    const/16 v35, 0x0

    invoke-virtual/range {v31 .. v35}, Lcom/thinkware/sundo/inavi3d/Inavi;->PushMessage(IIII)V

    goto/16 :goto_0

    .line 4664
    .end local v10    # "h":Landroid/os/Handler;
    :cond_39
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StartPointCancleBtn:Landroid/widget/Button;

    move-object/from16 v31, v0

    move-object/from16 v0, p1

    move-object/from16 v1, v31

    if-eq v0, v1, :cond_3a

    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_EndPointCancleBtn:Landroid/widget/Button;

    move-object/from16 v31, v0

    move-object/from16 v0, p1

    move-object/from16 v1, v31

    if-ne v0, v1, :cond_3b

    .line 4665
    :cond_3a
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    invoke-static/range {v31 .. v31}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$1300(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)Lcom/thinkware/sundo/inavi3d/Inavi;

    move-result-object v31

    const v32, 0x222e0

    const v33, 0x222fe

    const/16 v34, 0x0

    const/16 v35, 0x0

    invoke-virtual/range {v31 .. v35}, Lcom/thinkware/sundo/inavi3d/Inavi;->PushMessage(IIII)V

    goto/16 :goto_0

    .line 4669
    :cond_3b
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_RotateMoveBtn:Landroid/widget/Button;

    move-object/from16 v31, v0

    move-object/from16 v0, p1

    move-object/from16 v1, v31

    if-ne v0, v1, :cond_3d

    .line 4671
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_RotateLayOut:Landroid/widget/RelativeLayout;

    move-object/from16 v31, v0

    invoke-virtual/range {v31 .. v31}, Landroid/widget/RelativeLayout;->getVisibility()I

    move-result v31

    const/16 v32, 0x8

    move/from16 v0, v31

    move/from16 v1, v32

    if-ne v0, v1, :cond_3c

    .line 4672
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    invoke-static/range {v31 .. v31}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$6800(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)V

    .line 4673
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v32, v0

    move-object/from16 v0, v32

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_RotateLayOut:Landroid/widget/RelativeLayout;

    move-object/from16 v32, v0

    const/16 v33, 0x0

    invoke-static/range {v31 .. v33}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$6900(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;Landroid/view/View;I)V

    .line 4674
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_RotateMoveBtn:Landroid/widget/Button;

    move-object/from16 v31, v0

    const v32, 0x7f020142

    invoke-virtual/range {v31 .. v32}, Landroid/widget/Button;->setBackgroundResource(I)V

    goto/16 :goto_0

    .line 4676
    :cond_3c
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v32, v0

    move-object/from16 v0, v32

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_RotateLayOut:Landroid/widget/RelativeLayout;

    move-object/from16 v32, v0

    const/16 v33, 0x8

    invoke-static/range {v31 .. v33}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$6900(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;Landroid/view/View;I)V

    .line 4677
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_RotateMoveBtn:Landroid/widget/Button;

    move-object/from16 v31, v0

    const v32, 0x7f02013f

    invoke-virtual/range {v31 .. v32}, Landroid/widget/Button;->setBackgroundResource(I)V

    goto/16 :goto_0

    .line 4679
    :cond_3d
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_AroundSearchBtn:Landroid/widget/Button;

    move-object/from16 v31, v0

    move-object/from16 v0, p1

    move-object/from16 v1, v31

    if-ne v0, v1, :cond_3e

    .line 4681
    new-instance v11, Landroid/content/Intent;

    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    invoke-virtual/range {v31 .. v31}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getApplicationContext()Landroid/content/Context;

    move-result-object v31

    const-class v32, Lcom/thinkware/sundo/inavi3d/ui/AroundSrchActivity;

    move-object/from16 v0, v31

    move-object/from16 v1, v32

    invoke-direct {v11, v0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 4683
    .restart local v11    # "intent":Landroid/content/Intent;
    const-string v31, "TABENABLE"

    const/16 v32, 0x0

    move-object/from16 v0, v31

    move/from16 v1, v32

    invoke-virtual {v11, v0, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    .line 4684
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    invoke-virtual {v0, v11}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->startActivity(Landroid/content/Intent;)V

    goto/16 :goto_0

    .line 4685
    .end local v11    # "intent":Landroid/content/Intent;
    :cond_3e
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Mainmenu:Landroid/widget/Button;

    move-object/from16 v31, v0

    move-object/from16 v0, p1

    move-object/from16 v1, v31

    if-ne v0, v1, :cond_3f

    .line 4694
    new-instance v11, Landroid/content/Intent;

    invoke-direct {v11}, Landroid/content/Intent;-><init>()V

    .line 4695
    .restart local v11    # "intent":Landroid/content/Intent;
    invoke-virtual/range {p1 .. p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v31

    const-class v32, Lcom/thinkware/sundo/inavi3d/ui/MainMenuActivity;

    move-object/from16 v0, v31

    move-object/from16 v1, v32

    invoke-virtual {v11, v0, v1}, Landroid/content/Intent;->setClass(Landroid/content/Context;Ljava/lang/Class;)Landroid/content/Intent;

    .line 4698
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    const/16 v32, 0x5

    move-object/from16 v0, v31

    move/from16 v1, v32

    invoke-virtual {v0, v11, v1}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->startActivityForResult(Landroid/content/Intent;I)V

    goto/16 :goto_0

    .line 4699
    .end local v11    # "intent":Landroid/content/Intent;
    :cond_3f
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_DualLevelMinus:Landroid/widget/Button;

    move-object/from16 v31, v0

    move-object/from16 v0, p1

    move-object/from16 v1, v31

    if-eq v0, v1, :cond_40

    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_DualLevelMinusOff:Landroid/widget/Button;

    move-object/from16 v31, v0

    move-object/from16 v0, p1

    move-object/from16 v1, v31

    if-ne v0, v1, :cond_41

    .line 4700
    :cond_40
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    invoke-static/range {v31 .. v31}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$1300(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)Lcom/thinkware/sundo/inavi3d/Inavi;

    move-result-object v31

    invoke-virtual/range {v31 .. v31}, Lcom/thinkware/sundo/inavi3d/Inavi;->DualMapZoomOut()Z

    goto/16 :goto_0

    .line 4701
    :cond_41
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_DualLevelPlus:Landroid/widget/Button;

    move-object/from16 v31, v0

    move-object/from16 v0, p1

    move-object/from16 v1, v31

    if-eq v0, v1, :cond_42

    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_DualLevelPlusOff:Landroid/widget/Button;

    move-object/from16 v31, v0

    move-object/from16 v0, p1

    move-object/from16 v1, v31

    if-ne v0, v1, :cond_43

    .line 4702
    :cond_42
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    invoke-static/range {v31 .. v31}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$1300(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)Lcom/thinkware/sundo/inavi3d/Inavi;

    move-result-object v31

    invoke-virtual/range {v31 .. v31}, Lcom/thinkware/sundo/inavi3d/Inavi;->DualMapZoomIn()Z

    goto/16 :goto_0

    .line 4703
    :cond_43
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_RegSafe:Landroid/widget/ImageButton;

    move-object/from16 v31, v0

    move-object/from16 v0, p1

    move-object/from16 v1, v31

    if-ne v0, v1, :cond_44

    .line 4704
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    invoke-static/range {v31 .. v31}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$1300(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)Lcom/thinkware/sundo/inavi3d/Inavi;

    move-result-object v31

    invoke-virtual/range {v31 .. v31}, Lcom/thinkware/sundo/inavi3d/Inavi;->UserSafeCamera()I

    goto/16 :goto_0

    .line 4705
    :cond_44
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_DirectrouteBtn:Landroid/widget/Button;

    move-object/from16 v31, v0

    move-object/from16 v0, p1

    move-object/from16 v1, v31

    if-ne v0, v1, :cond_45

    .line 4708
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_DirectrouteBtn:Landroid/widget/Button;

    move-object/from16 v31, v0

    const/16 v32, 0x0

    invoke-virtual/range {v31 .. v32}, Landroid/widget/Button;->setEnabled(Z)V

    .line 4709
    new-instance v10, Landroid/os/Handler;

    invoke-direct {v10}, Landroid/os/Handler;-><init>()V

    .line 4710
    .restart local v10    # "h":Landroid/os/Handler;
    new-instance v31, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25$splashhandler1;

    move-object/from16 v0, v31

    move-object/from16 v1, p0

    invoke-direct {v0, v1}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25$splashhandler1;-><init>(Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;)V

    const-wide/16 v32, 0x3e8

    move-object/from16 v0, v31

    move-wide/from16 v1, v32

    invoke-virtual {v10, v0, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 4712
    new-instance v31, Lcom/thinkware/sundo/inavi3d/INaviTask;

    new-instance v32, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25$2;

    move-object/from16 v0, v32

    move-object/from16 v1, p0

    invoke-direct {v0, v1}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25$2;-><init>(Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;)V

    const/16 v33, 0x0

    invoke-direct/range {v31 .. v33}, Lcom/thinkware/sundo/inavi3d/INaviTask;-><init>(Lcom/thinkware/sundo/inavi3d/INaviTask$iINaviTaskInterFace;Z)V

    const/16 v32, 0x1

    move/from16 v0, v32

    new-array v0, v0, [Ljava/lang/Object;

    move-object/from16 v32, v0

    const/16 v33, 0x0

    const/16 v34, 0x0

    invoke-static/range {v34 .. v34}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v34

    aput-object v34, v32, v33

    invoke-virtual/range {v31 .. v32}, Lcom/thinkware/sundo/inavi3d/INaviTask;->execute([Ljava/lang/Object;)Landroid/os/AsyncTask;

    goto/16 :goto_0

    .line 4743
    .end local v10    # "h":Landroid/os/Handler;
    :cond_45
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_SafeZoneView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;

    move-object/from16 v31, v0

    move-object/from16 v0, p1

    move-object/from16 v1, v31

    if-eq v0, v1, :cond_46

    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_SafeZoneView2:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;

    move-object/from16 v31, v0

    move-object/from16 v0, p1

    move-object/from16 v1, v31

    if-eq v0, v1, :cond_46

    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_SafeZoneView3:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;

    move-object/from16 v31, v0

    move-object/from16 v0, p1

    move-object/from16 v1, v31

    if-eq v0, v1, :cond_46

    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_SafeZoneView4:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;

    move-object/from16 v31, v0

    move-object/from16 v0, p1

    move-object/from16 v1, v31

    if-ne v0, v1, :cond_47

    .line 4744
    :cond_46
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    invoke-static/range {v31 .. v31}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$1300(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)Lcom/thinkware/sundo/inavi3d/Inavi;

    move-result-object v31

    const v32, 0x222e0

    const v33, 0x22301

    const/16 v34, 0x0

    const/16 v35, 0x0

    invoke-virtual/range {v31 .. v35}, Lcom/thinkware/sundo/inavi3d/Inavi;->PushMessage(IIII)V

    goto/16 :goto_0

    .line 4747
    :cond_47
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_TurnAreaView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;

    move-object/from16 v31, v0

    move-object/from16 v0, p1

    move-object/from16 v1, v31

    if-eq v0, v1, :cond_48

    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_TurnAreaView2:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;

    move-object/from16 v31, v0

    move-object/from16 v0, p1

    move-object/from16 v1, v31

    if-eq v0, v1, :cond_48

    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_TurnAreaView4:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;

    move-object/from16 v31, v0

    move-object/from16 v0, p1

    move-object/from16 v1, v31

    if-ne v0, v1, :cond_49

    .line 4748
    :cond_48
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    invoke-static/range {v31 .. v31}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$1300(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)Lcom/thinkware/sundo/inavi3d/Inavi;

    move-result-object v31

    const v32, 0x222e0

    const v33, 0x22306

    const/16 v34, 0x0

    const/16 v35, 0x0

    invoke-virtual/range {v31 .. v35}, Lcom/thinkware/sundo/inavi3d/Inavi;->PushMessage(IIII)V

    goto/16 :goto_0

    .line 4751
    :cond_49
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_CCTVlayout:Landroid/widget/RelativeLayout;

    move-object/from16 v31, v0

    move-object/from16 v0, p1

    move-object/from16 v1, v31

    if-ne v0, v1, :cond_4a

    .line 4752
    new-instance v11, Landroid/content/Intent;

    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    const-class v32, Lcom/thinkware/sundo/inavi3d/ui/TrafficInfoCCTVFullViewActivity;

    move-object/from16 v0, v31

    move-object/from16 v1, v32

    invoke-direct {v11, v0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 4753
    .restart local v11    # "intent":Landroid/content/Intent;
    const-string v31, "TitleAndTime"

    const-string v32, ""

    move-object/from16 v0, v31

    move-object/from16 v1, v32

    invoke-virtual {v11, v0, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 4754
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    invoke-virtual {v0, v11}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->startActivity(Landroid/content/Intent;)V

    .line 4755
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    invoke-static/range {v31 .. v31}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$1300(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)Lcom/thinkware/sundo/inavi3d/Inavi;

    move-result-object v31

    const v32, 0x222e0

    const v33, 0x2230a

    const/16 v34, 0x0

    const/16 v35, 0x0

    invoke-virtual/range {v31 .. v35}, Lcom/thinkware/sundo/inavi3d/Inavi;->PushMessage(IIII)V

    goto/16 :goto_0

    .line 4756
    .end local v11    # "intent":Landroid/content/Intent;
    :cond_4a
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Current:Landroid/widget/Button;

    move-object/from16 v31, v0

    move-object/from16 v0, p1

    move-object/from16 v1, v31

    if-eq v0, v1, :cond_4b

    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Current_off:Landroid/widget/Button;

    move-object/from16 v31, v0

    move-object/from16 v0, p1

    move-object/from16 v1, v31

    if-eq v0, v1, :cond_4b

    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Current_routeresult:Landroid/widget/Button;

    move-object/from16 v31, v0

    move-object/from16 v0, p1

    move-object/from16 v1, v31

    if-eq v0, v1, :cond_4b

    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Current_detour:Landroid/widget/Button;

    move-object/from16 v31, v0

    move-object/from16 v0, p1

    move-object/from16 v1, v31

    if-ne v0, v1, :cond_4c

    .line 4764
    :cond_4b
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    invoke-static/range {v31 .. v31}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$1300(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)Lcom/thinkware/sundo/inavi3d/Inavi;

    move-result-object v31

    const v32, 0x222e0

    const v33, 0x222e1

    const/16 v34, 0x0

    const/16 v35, 0x0

    invoke-virtual/range {v31 .. v35}, Lcom/thinkware/sundo/inavi3d/Inavi;->PushMessage(IIII)V

    goto/16 :goto_0

    .line 4768
    :cond_4c
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Back:Landroid/widget/Button;

    move-object/from16 v31, v0

    move-object/from16 v0, p1

    move-object/from16 v1, v31

    if-eq v0, v1, :cond_4d

    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Back_off:Landroid/widget/Button;

    move-object/from16 v31, v0

    move-object/from16 v0, p1

    move-object/from16 v1, v31

    if-eq v0, v1, :cond_4d

    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Back_routeresult:Landroid/widget/Button;

    move-object/from16 v31, v0

    move-object/from16 v0, p1

    move-object/from16 v1, v31

    if-eq v0, v1, :cond_4d

    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Back_detour:Landroid/widget/Button;

    move-object/from16 v31, v0

    move-object/from16 v0, p1

    move-object/from16 v1, v31

    if-ne v0, v1, :cond_52

    .line 4769
    :cond_4d
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    invoke-static/range {v31 .. v31}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$7000(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)Z

    move-result v31

    if-eqz v31, :cond_4e

    .line 4770
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    const/16 v32, 0x1

    invoke-virtual/range {v31 .. v32}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->CloseTuTorial(Z)V

    goto/16 :goto_0

    .line 4774
    :cond_4e
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-boolean v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->externalPositionMove:Z

    move/from16 v31, v0

    if-eqz v31, :cond_4f

    .line 4775
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    invoke-static/range {v31 .. v31}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$7100(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)V

    .line 4776
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    const/16 v32, 0x0

    move/from16 v0, v32

    move-object/from16 v1, v31

    iput-boolean v0, v1, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->externalPositionMove:Z

    goto/16 :goto_0

    .line 4780
    :cond_4f
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    move-result-object v31

    invoke-virtual/range {v31 .. v31}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->isRoadView()Z

    move-result v31

    const/16 v32, 0x1

    move/from16 v0, v31

    move/from16 v1, v32

    if-ne v0, v1, :cond_50

    .line 4785
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    invoke-static/range {v31 .. v31}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$3400(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)Landroid/view/View;

    move-result-object v31

    if-eqz v31, :cond_50

    .line 4786
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    invoke-static/range {v31 .. v31}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$3400(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)Landroid/view/View;

    move-result-object v31

    invoke-virtual/range {v31 .. v31}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v23

    check-cast v23, Lcom/thinkware/sundo/inavi3d/ui/roadview/RoadViewActivity;

    .line 4788
    .local v23, "roadViewActivity":Lcom/thinkware/sundo/inavi3d/ui/roadview/RoadViewActivity;
    invoke-virtual/range {v23 .. v23}, Lcom/thinkware/sundo/inavi3d/ui/roadview/RoadViewActivity;->isHiddenFullScreenRoadView()Z

    move-result v31

    if-nez v31, :cond_50

    .line 4789
    const/16 v31, 0x1

    move-object/from16 v0, v23

    move/from16 v1, v31

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/inavi3d/ui/roadview/RoadViewActivity;->setHiddenFullScreenRoadView(Z)V

    goto/16 :goto_0

    .line 4794
    .end local v23    # "roadViewActivity":Lcom/thinkware/sundo/inavi3d/ui/roadview/RoadViewActivity;
    :cond_50
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_DialogIsntanceForBackKey:Landroid/app/Dialog;

    move-object/from16 v31, v0

    if-eqz v31, :cond_51

    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_DialogIsntanceForBackKey:Landroid/app/Dialog;

    move-object/from16 v31, v0

    invoke-virtual/range {v31 .. v31}, Landroid/app/Dialog;->isShowing()Z

    move-result v31

    if-eqz v31, :cond_51

    .line 4795
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_DialogIsntanceForBackKey:Landroid/app/Dialog;

    move-object/from16 v31, v0

    invoke-virtual/range {v31 .. v31}, Landroid/app/Dialog;->dismiss()V

    goto/16 :goto_0

    .line 4798
    :cond_51
    new-instance v8, Landroid/view/KeyEvent;

    const/16 v31, 0x0

    const/16 v32, 0x4

    move/from16 v0, v31

    move/from16 v1, v32

    invoke-direct {v8, v0, v1}, Landroid/view/KeyEvent;-><init>(II)V

    .line 4799
    .local v8, "eventDown":Landroid/view/KeyEvent;
    new-instance v9, Landroid/view/KeyEvent;

    const/16 v31, 0x1

    const/16 v32, 0x4

    move/from16 v0, v31

    move/from16 v1, v32

    invoke-direct {v9, v0, v1}, Landroid/view/KeyEvent;-><init>(II)V

    .line 4800
    .local v9, "eventUp":Landroid/view/KeyEvent;
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    invoke-virtual {v0, v8}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->dispatchKeyEvent(Landroid/view/KeyEvent;)Z

    .line 4801
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    invoke-virtual {v0, v9}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->dispatchKeyEvent(Landroid/view/KeyEvent;)Z

    .line 4804
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Back:Landroid/widget/Button;

    move-object/from16 v31, v0

    move-object/from16 v0, p1

    move-object/from16 v1, v31

    if-ne v0, v1, :cond_0

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    move-result-object v31

    invoke-virtual/range {v31 .. v31}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->isCurrentFlag()Z

    move-result v31

    if-eqz v31, :cond_0

    .line 4805
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v31

    invoke-static/range {v31 .. v31}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->goLauncher(Landroid/content/Context;)V

    goto/16 :goto_0

    .line 4817
    .end local v8    # "eventDown":Landroid/view/KeyEvent;
    .end local v9    # "eventUp":Landroid/view/KeyEvent;
    :cond_52
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_NIP:Landroid/widget/Button;

    move-object/from16 v31, v0

    move-object/from16 v0, p1

    move-object/from16 v1, v31

    if-eq v0, v1, :cond_53

    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_NIP_off:Landroid/widget/Button;

    move-object/from16 v31, v0

    move-object/from16 v0, p1

    move-object/from16 v1, v31

    if-eq v0, v1, :cond_53

    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_NIP_detour:Landroid/widget/Button;

    move-object/from16 v31, v0

    move-object/from16 v0, p1

    move-object/from16 v1, v31

    if-eq v0, v1, :cond_53

    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_NIP_routeresult:Landroid/widget/Button;

    move-object/from16 v31, v0

    move-object/from16 v0, p1

    move-object/from16 v1, v31

    if-ne v0, v1, :cond_56

    .line 4819
    :cond_53
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    move-result-object v31

    invoke-virtual/range {v31 .. v31}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->isCurrentFlag()Z

    move-result v31

    if-eqz v31, :cond_54

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    move-result-object v31

    invoke-virtual/range {v31 .. v31}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getRootActivityStatus()I

    move-result v31

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    if-eqz v31, :cond_55

    .line 4821
    :cond_54
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    invoke-static/range {v31 .. v31}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$1300(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)Lcom/thinkware/sundo/inavi3d/Inavi;

    move-result-object v31

    const v32, 0x222e0

    const v33, 0x222e1

    const/16 v34, 0x0

    const/16 v35, 0x0

    invoke-virtual/range {v31 .. v35}, Lcom/thinkware/sundo/inavi3d/Inavi;->PushMessage(IIII)V

    .line 4826
    :cond_55
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    invoke-static/range {v31 .. v31}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$7200(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)I

    move-result v31

    const/16 v32, -0x1

    move/from16 v0, v31

    move/from16 v1, v32

    if-le v0, v1, :cond_0

    .line 4827
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v32, v0

    invoke-static/range {v32 .. v32}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$7200(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)I

    move-result v32

    const/16 v33, 0x1

    invoke-virtual/range {v31 .. v33}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->showNIP(IZ)Z

    .line 4828
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    const/16 v32, 0x3

    invoke-static/range {v31 .. v32}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$7202(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;I)I

    goto/16 :goto_0

    .line 4848
    :cond_56
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_LevelPlusRouteTotal:Landroid/widget/Button;

    move-object/from16 v31, v0

    move-object/from16 v0, p1

    move-object/from16 v1, v31

    if-ne v0, v1, :cond_57

    .line 4849
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    invoke-static/range {v31 .. v31}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$1300(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)Lcom/thinkware/sundo/inavi3d/Inavi;

    move-result-object v31

    invoke-virtual/range {v31 .. v31}, Lcom/thinkware/sundo/inavi3d/Inavi;->MapZoomIn()Z

    goto/16 :goto_0

    .line 4850
    :cond_57
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_LevelMinusRouteTotal:Landroid/widget/Button;

    move-object/from16 v31, v0

    move-object/from16 v0, p1

    move-object/from16 v1, v31

    if-ne v0, v1, :cond_58

    .line 4851
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    invoke-static/range {v31 .. v31}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$1300(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)Lcom/thinkware/sundo/inavi3d/Inavi;

    move-result-object v31

    invoke-virtual/range {v31 .. v31}, Lcom/thinkware/sundo/inavi3d/Inavi;->MapZoomOut()Z

    goto/16 :goto_0

    .line 4852
    :cond_58
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_LevelPlusNameSearch:Landroid/widget/Button;

    move-object/from16 v31, v0

    move-object/from16 v0, p1

    move-object/from16 v1, v31

    if-ne v0, v1, :cond_59

    .line 4853
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    invoke-static/range {v31 .. v31}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$1300(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)Lcom/thinkware/sundo/inavi3d/Inavi;

    move-result-object v31

    invoke-virtual/range {v31 .. v31}, Lcom/thinkware/sundo/inavi3d/Inavi;->MapZoomIn()Z

    .line 4854
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->setMapLevelPlus()V

    goto/16 :goto_0

    .line 4855
    :cond_59
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_LevelMinusNameSearch:Landroid/widget/Button;

    move-object/from16 v31, v0

    move-object/from16 v0, p1

    move-object/from16 v1, v31

    if-ne v0, v1, :cond_5a

    .line 4856
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    invoke-static/range {v31 .. v31}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$1300(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)Lcom/thinkware/sundo/inavi3d/Inavi;

    move-result-object v31

    invoke-virtual/range {v31 .. v31}, Lcom/thinkware/sundo/inavi3d/Inavi;->MapZoomOut()Z

    .line 4857
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->setMapLevelMinus()V

    goto/16 :goto_0

    .line 4861
    :cond_5a
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Home:Landroid/widget/Button;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    move-object/from16 v1, p1

    if-eq v0, v1, :cond_5b

    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Home_off:Landroid/widget/Button;

    move-object/from16 v31, v0

    move-object/from16 v0, p1

    move-object/from16 v1, v31

    if-eq v0, v1, :cond_5b

    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Home_routeresult:Landroid/widget/Button;

    move-object/from16 v31, v0

    move-object/from16 v0, p1

    move-object/from16 v1, v31

    if-eq v0, v1, :cond_5b

    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Home_detour:Landroid/widget/Button;

    move-object/from16 v31, v0

    move-object/from16 v0, p1

    move-object/from16 v1, v31

    if-ne v0, v1, :cond_5c

    .line 4862
    :cond_5b
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v31

    invoke-static/range {v31 .. v31}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->goLauncher(Landroid/content/Context;)V

    goto/16 :goto_0

    .line 4863
    :cond_5c
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_AddGoalBtn:Landroid/widget/Button;

    move-object/from16 v31, v0

    move-object/from16 v0, p1

    move-object/from16 v1, v31

    if-ne v0, v1, :cond_5d

    .line 4866
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    invoke-static/range {v31 .. v31}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$1300(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)Lcom/thinkware/sundo/inavi3d/Inavi;

    const v31, 0x22326

    const/16 v32, 0x0

    const/16 v33, 0x0

    invoke-static/range {v31 .. v33}, Lcom/thinkware/sundo/inavi3d/Inavi;->ProcessEventSlidingToolBar(III)Z

    move-result v22

    .line 4867
    .restart local v22    # "ret":Z
    if-eqz v22, :cond_0

    .line 4869
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    move-result-object v31

    const-class v32, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;

    invoke-virtual/range {v32 .. v32}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v32

    invoke-virtual/range {v31 .. v32}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->moveToInnerActivity(Ljava/lang/String;)V

    goto/16 :goto_0

    .line 4871
    .end local v22    # "ret":Z
    :cond_5d
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_EditGoalBtn:Landroid/widget/Button;

    move-object/from16 v31, v0

    move-object/from16 v0, p1

    move-object/from16 v1, v31

    if-eq v0, v1, :cond_5e

    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_EditStartBtn:Landroid/widget/Button;

    move-object/from16 v31, v0

    move-object/from16 v0, p1

    move-object/from16 v1, v31

    if-ne v0, v1, :cond_5f

    .line 4874
    :cond_5e
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    invoke-static/range {v31 .. v31}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$1300(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)Lcom/thinkware/sundo/inavi3d/Inavi;

    const v31, 0x22327

    const/16 v32, 0x0

    const/16 v33, 0x0

    invoke-static/range {v31 .. v33}, Lcom/thinkware/sundo/inavi3d/Inavi;->ProcessEventSlidingToolBar(III)Z

    move-result v22

    .line 4875
    .restart local v22    # "ret":Z
    if-eqz v22, :cond_0

    .line 4877
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    move-result-object v31

    const-class v32, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;

    invoke-virtual/range {v32 .. v32}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v32

    invoke-virtual/range {v31 .. v32}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->moveToInnerActivity(Ljava/lang/String;)V

    goto/16 :goto_0

    .line 4879
    .end local v22    # "ret":Z
    :cond_5f
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_VerifyBtn:Landroid/widget/Button;

    move-object/from16 v31, v0

    move-object/from16 v0, p1

    move-object/from16 v1, v31

    if-eq v0, v1, :cond_60

    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_VerifyStartBtn:Landroid/widget/Button;

    move-object/from16 v31, v0

    move-object/from16 v0, p1

    move-object/from16 v1, v31

    if-ne v0, v1, :cond_61

    .line 4880
    :cond_60
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    move-result-object v31

    invoke-virtual/range {v31 .. v31}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->backActivityFromMap()V

    goto/16 :goto_0

    .line 4881
    :cond_61
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_RegistBtn:Landroid/widget/Button;

    move-object/from16 v31, v0

    move-object/from16 v0, p1

    move-object/from16 v1, v31

    if-ne v0, v1, :cond_64

    .line 4882
    invoke-virtual/range {p1 .. p1}, Landroid/view/View;->getTag()Ljava/lang/Object;

    move-result-object v31

    check-cast v31, Ljava/lang/Integer;

    invoke-virtual/range {v31 .. v31}, Ljava/lang/Integer;->intValue()I

    move-result v17

    .line 4885
    .local v17, "msg":I
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/UserDataMgr;->getInstance()Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/UserDataMgr;

    move-result-object v31

    new-instance v32, Ljava/lang/StringBuilder;

    invoke-direct/range {v32 .. v32}, Ljava/lang/StringBuilder;-><init>()V

    sget-object v33, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->kInaviData:Ljava/lang/String;

    invoke-virtual/range {v32 .. v33}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v32

    const-string v33, "/"

    invoke-virtual/range {v32 .. v33}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v32

    invoke-virtual/range {v32 .. v32}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v32

    invoke-virtual/range {v31 .. v32}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/UserDataMgr;->InitUserDataModule(Ljava/lang/String;)I

    .line 4887
    const v31, 0x22324

    move/from16 v0, v17

    move/from16 v1, v31

    if-ne v0, v1, :cond_63

    .line 4890
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    invoke-static/range {v31 .. v31}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$1300(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)Lcom/thinkware/sundo/inavi3d/Inavi;

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/Inavi;->getMapCenterX()I

    move-result v31

    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v32, v0

    invoke-static/range {v32 .. v32}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$1300(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)Lcom/thinkware/sundo/inavi3d/Inavi;

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/Inavi;->getMapCenterY()I

    move-result v32

    invoke-static/range {v31 .. v32}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/UserDataMgr;->UPSetHomeData(II)Z

    .line 4892
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    const-string v32, "\uc9d1\uc744 \ub4f1\ub85d \ud558\uc600\uc2b5\ub2c8\ub2e4."

    const/16 v33, 0x0

    invoke-static/range {v31 .. v33}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v31

    invoke-virtual/range {v31 .. v31}, Landroid/widget/Toast;->show()V

    .line 4904
    :cond_62
    :goto_7
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    invoke-static/range {v31 .. v31}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$1300(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)Lcom/thinkware/sundo/inavi3d/Inavi;

    move-result-object v31

    const v32, 0x222e0

    const v33, 0x222e1

    const/16 v34, 0x0

    const/16 v35, 0x0

    invoke-virtual/range {v31 .. v35}, Lcom/thinkware/sundo/inavi3d/Inavi;->PushMessage(IIII)V

    goto/16 :goto_0

    .line 4896
    :cond_63
    const v31, 0x22325

    move/from16 v0, v17

    move/from16 v1, v31

    if-ne v0, v1, :cond_62

    .line 4899
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    invoke-static/range {v31 .. v31}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$1300(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)Lcom/thinkware/sundo/inavi3d/Inavi;

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/Inavi;->getMapCenterX()I

    move-result v31

    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v32, v0

    invoke-static/range {v32 .. v32}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$1300(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)Lcom/thinkware/sundo/inavi3d/Inavi;

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/Inavi;->getMapCenterY()I

    move-result v32

    invoke-static/range {v31 .. v32}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/UserDataMgr;->UPSetFreqData(II)Z

    .line 4901
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    const-string v32, "\uc790\uc8fc\uac00\ub294 \uacf3\uc744 \ub4f1\ub85d \ud558\uc600\uc2b5\ub2c8\ub2e4."

    const/16 v33, 0x0

    invoke-static/range {v31 .. v33}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v31

    invoke-virtual/range {v31 .. v31}, Landroid/widget/Toast;->show()V

    goto :goto_7

    .line 4908
    .end local v17    # "msg":I
    :cond_64
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_LocalName:Landroid/widget/Button;

    move-object/from16 v31, v0

    move-object/from16 v0, p1

    move-object/from16 v1, v31

    if-ne v0, v1, :cond_65

    .line 4910
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->getInstance()Lcom/thinkware/sundo/inavi3d/InaviConfig;

    move-result-object v31

    const/16 v32, 0x2a

    invoke-virtual/range {v31 .. v32}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->CNaviConfigGet(I)I

    move-result v14

    .line 4911
    .local v14, "local":I
    add-int/lit8 v31, v14, 0x2

    rem-int/lit8 v14, v31, 0x6

    .line 4912
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->getInstance()Lcom/thinkware/sundo/inavi3d/InaviConfig;

    move-result-object v31

    const/16 v32, 0x2a

    move-object/from16 v0, v31

    move/from16 v1, v32

    invoke-virtual {v0, v1, v14}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->CNaviConfigSet(II)Z

    goto/16 :goto_0

    .line 4915
    .end local v14    # "local":I
    :cond_65
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_weather_layout:Landroid/widget/RelativeLayout;

    move-object/from16 v31, v0

    move-object/from16 v0, p1

    move-object/from16 v1, v31

    if-eq v0, v1, :cond_66

    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_weather_layout_off:Landroid/widget/RelativeLayout;

    move-object/from16 v31, v0

    move-object/from16 v0, p1

    move-object/from16 v1, v31

    if-eq v0, v1, :cond_66

    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_weather_layout_routeresult:Landroid/widget/RelativeLayout;

    move-object/from16 v31, v0

    move-object/from16 v0, p1

    move-object/from16 v1, v31

    if-eq v0, v1, :cond_66

    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_StatusBar_weather_layout_detour:Landroid/widget/RelativeLayout;

    move-object/from16 v31, v0

    move-object/from16 v0, p1

    move-object/from16 v1, v31

    if-ne v0, v1, :cond_67

    .line 4918
    :cond_66
    new-instance v11, Landroid/content/Intent;

    invoke-direct {v11}, Landroid/content/Intent;-><init>()V

    .line 4919
    .restart local v11    # "intent":Landroid/content/Intent;
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/Inavi;->getTbtguide()Lcom/thinkware/sundo/remoteTBT/TBTGuide;

    move-result-object v27

    .line 4920
    .local v27, "tbtGuide":Lcom/thinkware/sundo/remoteTBT/TBTGuide;
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    invoke-static/range {v31 .. v31}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$5900(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)[Lcom/thinkware/sundo/inavi3d/Struct/WeatherInfo;

    move-result-object v30

    .line 4921
    .restart local v30    # "weatherinfo":[Lcom/thinkware/sundo/inavi3d/Struct/WeatherInfo;
    const-string v31, "weatherinfo"

    move-object/from16 v0, v31

    move-object/from16 v1, v30

    invoke-virtual {v11, v0, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;[Landroid/os/Parcelable;)Landroid/content/Intent;

    .line 4922
    const-string v31, "viacount"

    move-object/from16 v0, v27

    iget v0, v0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->viaCount:I

    move/from16 v32, v0

    move-object/from16 v0, v31

    move/from16 v1, v32

    invoke-virtual {v11, v0, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 4923
    const-string v31, "PassedGoalCnt"

    move-object/from16 v0, v27

    iget v0, v0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->PassedGoalCnt:I

    move/from16 v32, v0

    move-object/from16 v0, v31

    move/from16 v1, v32

    invoke-virtual {v11, v0, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 4924
    const-string v31, "livesearch"

    const/16 v32, 0x0

    move-object/from16 v0, v31

    move/from16 v1, v32

    invoke-virtual {v11, v0, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    .line 4925
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    invoke-virtual/range {v31 .. v31}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getApplication()Landroid/app/Application;

    move-result-object v31

    const-class v32, Lcom/thinkware/sundo/inavi3d/ui/WeatherInfoActivity;

    move-object/from16 v0, v31

    move-object/from16 v1, v32

    invoke-virtual {v11, v0, v1}, Landroid/content/Intent;->setClass(Landroid/content/Context;Ljava/lang/Class;)Landroid/content/Intent;

    .line 4926
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    invoke-virtual {v0, v11}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->startActivity(Landroid/content/Intent;)V

    goto/16 :goto_0

    .line 4927
    .end local v11    # "intent":Landroid/content/Intent;
    .end local v27    # "tbtGuide":Lcom/thinkware/sundo/remoteTBT/TBTGuide;
    .end local v30    # "weatherinfo":[Lcom/thinkware/sundo/inavi3d/Struct/WeatherInfo;
    :cond_67
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_DriveCourseViewRouteCancelButton:Landroid/widget/Button;

    move-object/from16 v31, v0

    move-object/from16 v0, p1

    move-object/from16 v1, v31

    if-ne v0, v1, :cond_68

    .line 4929
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_DriveCourseViewRouteCancelButton:Landroid/widget/Button;

    move-object/from16 v31, v0

    const/16 v32, 0x0

    invoke-virtual/range {v31 .. v32}, Landroid/widget/Button;->setEnabled(Z)V

    .line 4930
    new-instance v10, Landroid/os/Handler;

    invoke-direct {v10}, Landroid/os/Handler;-><init>()V

    .line 4931
    .restart local v10    # "h":Landroid/os/Handler;
    new-instance v31, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25$splashhandler2;

    move-object/from16 v0, v31

    move-object/from16 v1, p0

    invoke-direct {v0, v1}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25$splashhandler2;-><init>(Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;)V

    const-wide/16 v32, 0x1f4

    move-object/from16 v0, v31

    move-wide/from16 v1, v32

    invoke-virtual {v10, v0, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 4932
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    invoke-static/range {v31 .. v31}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$1300(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)Lcom/thinkware/sundo/inavi3d/Inavi;

    move-result-object v31

    const v32, 0x22538

    const v33, 0x2253a

    const/16 v34, 0x0

    const/16 v35, 0x0

    invoke-virtual/range {v31 .. v35}, Lcom/thinkware/sundo/inavi3d/Inavi;->PushMessage(IIII)V

    goto/16 :goto_0

    .line 4934
    .end local v10    # "h":Landroid/os/Handler;
    :cond_68
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Voice:Landroid/widget/Button;

    move-object/from16 v31, v0

    move-object/from16 v0, p1

    move-object/from16 v1, v31

    if-eq v0, v1, :cond_69

    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Voice_off:Landroid/widget/Button;

    move-object/from16 v31, v0

    move-object/from16 v0, p1

    move-object/from16 v1, v31

    if-eq v0, v1, :cond_69

    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Voice_routeresult:Landroid/widget/Button;

    move-object/from16 v31, v0

    move-object/from16 v0, p1

    move-object/from16 v1, v31

    if-eq v0, v1, :cond_69

    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_Button_StatusBar_Voice_detour:Landroid/widget/Button;

    move-object/from16 v31, v0

    move-object/from16 v0, p1

    move-object/from16 v1, v31

    if-ne v0, v1, :cond_6a

    .line 4937
    :cond_69
    new-instance v12, Landroid/content/Intent;

    invoke-direct {v12}, Landroid/content/Intent;-><init>()V

    .line 4938
    .local v12, "intentVoice":Landroid/content/Intent;
    const-string v31, "com.thinkware.aina.AINAService"

    move-object/from16 v0, v31

    invoke-virtual {v12, v0}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    .line 4940
    const/4 v15, 0x0

    .line 4941
    .local v15, "mActivityManager":Landroid/app/ActivityManager;
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    const-string v32, "activity"

    invoke-virtual/range {v31 .. v32}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v15

    .end local v15    # "mActivityManager":Landroid/app/ActivityManager;
    check-cast v15, Landroid/app/ActivityManager;

    .line 4942
    .restart local v15    # "mActivityManager":Landroid/app/ActivityManager;
    const/16 v31, 0x1

    move/from16 v0, v31

    invoke-virtual {v15, v0}, Landroid/app/ActivityManager;->getRunningTasks(I)Ljava/util/List;

    move-result-object v24

    .line 4943
    .local v24, "rt":Ljava/util/List;, "Ljava/util/List<Landroid/app/ActivityManager$RunningTaskInfo;>;"
    const/16 v31, 0x0

    move-object/from16 v0, v24

    move/from16 v1, v31

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v31

    check-cast v31, Landroid/app/ActivityManager$RunningTaskInfo;

    move-object/from16 v0, v31

    iget-object v0, v0, Landroid/app/ActivityManager$RunningTaskInfo;->topActivity:Landroid/content/ComponentName;

    move-object/from16 v31, v0

    invoke-virtual/range {v31 .. v31}, Landroid/content/ComponentName;->getClassName()Ljava/lang/String;

    move-result-object v25

    .line 4946
    .local v25, "strTopClassName":Ljava/lang/String;
    const-string v31, "packageName"

    move-object/from16 v0, v31

    move-object/from16 v1, v25

    invoke-virtual {v12, v0, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 4948
    const-string v31, "SERVICE_STATE"

    const-string v32, "START"

    move-object/from16 v0, v31

    move-object/from16 v1, v32

    invoke-virtual {v12, v0, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 4949
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    invoke-virtual {v0, v12}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;

    goto/16 :goto_0

    .line 4951
    .end local v12    # "intentVoice":Landroid/content/Intent;
    .end local v15    # "mActivityManager":Landroid/app/ActivityManager;
    .end local v24    # "rt":Ljava/util/List;, "Ljava/util/List<Landroid/app/ActivityManager$RunningTaskInfo;>;"
    .end local v25    # "strTopClassName":Ljava/lang/String;
    :cond_6a
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_DRButton:Landroid/widget/ImageButton;

    move-object/from16 v31, v0

    move-object/from16 v0, p1

    move-object/from16 v1, v31

    if-ne v0, v1, :cond_6b

    .line 4953
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v31

    invoke-virtual/range {v31 .. v31}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetUseDRConfig()Z

    move-result v31

    if-eqz v31, :cond_0

    .line 4955
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-boolean v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_bDRActivityVisible:Z

    move/from16 v31, v0

    if-nez v31, :cond_0

    .line 4958
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    const/16 v32, 0x1

    move/from16 v0, v32

    move-object/from16 v1, v31

    iput-boolean v0, v1, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_bDRActivityVisible:Z

    .line 4960
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    move-result-object v31

    invoke-virtual/range {v31 .. v31}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->hideStatusBar()Z

    .line 4962
    new-instance v11, Landroid/content/Intent;

    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    const-class v32, Lcom/thinkware/sundo/inavi3d/DR/DRServiceActivity;

    move-object/from16 v0, v31

    move-object/from16 v1, v32

    invoke-direct {v11, v0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 4963
    .restart local v11    # "intent":Landroid/content/Intent;
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    invoke-virtual {v0, v11}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->startActivity(Landroid/content/Intent;)V

    goto/16 :goto_0

    .line 4966
    .end local v11    # "intent":Landroid/content/Intent;
    :cond_6b
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_DRLogButton:Landroid/widget/ImageButton;

    move-object/from16 v31, v0

    move-object/from16 v0, p1

    move-object/from16 v1, v31

    if-ne v0, v1, :cond_6c

    .line 4968
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DR/DRManager;->getInstance()Lcom/thinkware/sundo/inavi3d/DR/DRManager;

    move-result-object v31

    const/16 v32, 0x1

    invoke-virtual/range {v31 .. v32}, Lcom/thinkware/sundo/inavi3d/DR/DRManager;->_DRSetLogMode(Z)V

    .line 4969
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DR/DRManager;->getInstance()Lcom/thinkware/sundo/inavi3d/DR/DRManager;

    move-result-object v31

    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v32, v0

    invoke-virtual/range {v31 .. v32}, Lcom/thinkware/sundo/inavi3d/DR/DRManager;->setDRLogContext(Landroid/content/Context;)V

    .line 4970
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    const/16 v32, 0x9

    invoke-static/range {v31 .. v32}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$2100(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;I)V

    .line 4971
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    invoke-static/range {v31 .. v31}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$1300(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)Lcom/thinkware/sundo/inavi3d/Inavi;

    move-result-object v31

    const v32, 0x1adb0

    const v33, 0x1adb2

    const/16 v34, -0x1

    const/16 v35, -0x1

    invoke-virtual/range {v31 .. v35}, Lcom/thinkware/sundo/inavi3d/Inavi;->PushMessage(IIII)V

    goto/16 :goto_0

    .line 4973
    :cond_6c
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_MMCOnOffButton:Landroid/widget/Button;

    move-object/from16 v31, v0

    move-object/from16 v0, p1

    move-object/from16 v1, v31

    if-ne v0, v1, :cond_0

    .line 4976
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-boolean v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_bMMCOnOff:Z

    move/from16 v31, v0

    if-eqz v31, :cond_6d

    .line 4978
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    const/16 v32, 0x0

    move/from16 v0, v32

    move-object/from16 v1, v31

    iput-boolean v0, v1, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_bMMCOnOff:Z

    .line 4979
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DR/DRManager;->getInstance()Lcom/thinkware/sundo/inavi3d/DR/DRManager;

    move-result-object v31

    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v32, v0

    move-object/from16 v0, v32

    iget-boolean v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_bMMCOnOff:Z

    move/from16 v32, v0

    invoke-virtual/range {v31 .. v32}, Lcom/thinkware/sundo/inavi3d/DR/DRManager;->SetDRMMCOnOff(Z)V

    .line 4980
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_MMCOnOffButton:Landroid/widget/Button;

    move-object/from16 v31, v0

    const-string v32, "MMC OFF"

    invoke-virtual/range {v31 .. v32}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 4981
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    const-string v32, "MMC OFF!!"

    const/16 v33, 0x0

    invoke-static/range {v31 .. v33}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v31

    invoke-virtual/range {v31 .. v31}, Landroid/widget/Toast;->show()V

    goto/16 :goto_0

    .line 4985
    :cond_6d
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    const/16 v32, 0x1

    move/from16 v0, v32

    move-object/from16 v1, v31

    iput-boolean v0, v1, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_bMMCOnOff:Z

    .line 4986
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DR/DRManager;->getInstance()Lcom/thinkware/sundo/inavi3d/DR/DRManager;

    move-result-object v31

    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v32, v0

    move-object/from16 v0, v32

    iget-boolean v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_bMMCOnOff:Z

    move/from16 v32, v0

    invoke-virtual/range {v31 .. v32}, Lcom/thinkware/sundo/inavi3d/DR/DRManager;->SetDRMMCOnOff(Z)V

    .line 4987
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_MMCOnOffButton:Landroid/widget/Button;

    move-object/from16 v31, v0

    const-string v32, "MMC ON"

    invoke-virtual/range {v31 .. v32}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 4988
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$25;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-object/from16 v31, v0

    const-string v32, "MMC ON!!"

    const/16 v33, 0x0

    invoke-static/range {v31 .. v33}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v31

    invoke-virtual/range {v31 .. v31}, Landroid/widget/Toast;->show()V

    goto/16 :goto_0
.end method
