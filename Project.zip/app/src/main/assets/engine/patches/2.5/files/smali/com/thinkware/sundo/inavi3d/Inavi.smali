.class public Lcom/thinkware/sundo/inavi3d/Inavi;
.super Ljava/lang/Object;
.source "Inavi.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/thinkware/sundo/inavi3d/Inavi$location;
    }
.end annotation


# static fields
.field static MULTI_BUTTONDOWN:I = 0x0

.field static MULTI_BUTTONMOVE:I = 0x0

.field static MULTI_BUTTONUP:I = 0x0

.field public static final NATIVE_CURRNET_ROUTE_FILE:I = 0x1f40

.field public static final NATIVE_INIT_END:I = 0x1b5f

.field public static final NATIVE_MSG_CHANGE_LINK:I = 0x1772

.field public static final NATIVE_MSG_CHECK_REROUTE:I = 0x138e

.field public static final NATIVE_MSG_DRM_AUTHORIZE:I = 0x138d

.field public static final NATIVE_MSG_DR_DATA_BUTTON_HIDE:I = 0x1776

.field public static final NATIVE_MSG_DR_DATA_BUTTON_SHOW:I = 0x1775

.field static final NATIVE_MSG_EXIT:I = 0x270f

.field public static final NATIVE_MSG_GPS_INIT:I = 0x1774

.field public static final NATIVE_MSG_HOME:I = 0x1b60

.field public static final NATIVE_MSG_LOGGING:I = 0x1773

.field public static final NATIVE_MSG_LOG_DRIVE:I = 0x1771

.field public static final NATIVE_MSG_MAP:I = 0x2328

.field static final NATIVE_MSG_MAP_CHANG_NOTI_RTM_MAPBTN:I = 0x2336

.field static final NATIVE_MSG_MAP_DESTINFO:I = 0x232c

.field static final NATIVE_MSG_MAP_DUALLEVELBAR:I = 0x232f

.field static final NATIVE_MSG_MAP_HIGHWAYMODE:I = 0x232a

.field static final NATIVE_MSG_MAP_HIGHWAYMODEBUTTON:I = 0x2333

.field static final NATIVE_MSG_MAP_LEVELBAR:I = 0x232e

.field static final NATIVE_MSG_MAP_LOCALGUIDE:I = 0x232b

.field static final NATIVE_MSG_MAP_NAVICURRENT:I = 0x2329

.field static final NATIVE_MSG_MAP_ROUTERESULT:I = 0x232d

.field static final NATIVE_MSG_MAP_STARTROUTE:I = 0x2335

.field static final NATIVE_MSG_MAP_TRAFFIC:I = 0x2331

.field static final NATIVE_MSG_MAP_TRAFFICINDICATOR:I = 0x2332

.field static final NATIVE_MSG_MAP_VIEWMODE:I = 0x2334

.field static final NATIVE_MSG_MAP_VOLUME:I = 0x2330

.field public static final NATIVE_MSG_MMC_DIRECTESCAPE:I = 0x1770

.field public static final NATIVE_MSG_NETWORK_NOT_CONNECT:I = 0x1b5d

.field public static final NATIVE_MSG_REROUTE_STATUS:I = 0x138c

.field public static final NATIVE_MSG_RUN_DMB:I = 0x1b59

.field public static final NATIVE_MSG_RUN_IEVE:I = 0x1b5a

.field public static final NATIVE_MSG_RUN_IEVE_CALB:I = 0x1b5b

.field public static final NATIVE_MSG_RUN_NETWORK:I = 0x1b5c

.field public static final NATIVE_MSG_SIMULATION:I = 0x138b

.field public static final NATIVE_MSG_TBT_ON_OFF:I = 0x1b5e

.field public static final NATIVE_MSG_WAIT_SYMBOL_SHOW:I = 0x1b58

.field public static final NATIVE_MSG_WALK:I = 0x138a

.field public static final NATIVE_ROUTE_SEARCHING_END:I = 0x1fbd4

.field public static final NATIVE_ROUTE_SEARCHING_FAIL:I = 0x1fbd5

.field public static final NATIVE_ROUTE_SEARCHING_START:I = 0x1fbd1

.field public static final NATIVE_ROUTE_STATUS:I = 0x1fbd0

.field public static final NATIVE_TCON_TERMS_CONFIRM_CHECK:I = 0x1d4c

.field public static final NAVTIVE_MSG_ROUTESEARCHING:I = 0x1388

.field public static final NOP:I = 0x138c

.field static TAG:Ljava/lang/String;

.field private static authDrm:Lcom/thinkware/sundo/inavi3d/AuthDRM;

.field public static backgroundMsgVec:Ljava/util/Vector;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Vector",
            "<",
            "Lcom/thinkware/sundo/inavi3d/Struct/MsgStructer;",
            ">;"
        }
    .end annotation
.end field

.field static btnLocalName:Landroid/widget/Button;

.field static courseView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/DriveCourseView;

.field static crossWayView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/CrossWayView;

.field static crossWayView2:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/CrossWayView;

.field static crossWayView3:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/CrossWayView;

.field static crossWayView4:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/CrossWayView;

.field static crossname:Landroid/widget/Button;

.field static driveLineView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/LaneInfoView;

.field private static existdBackgroundMessage:Z

.field public static firstTBTGuide:Z

.field private static mContext:Landroid/content/Context;

.field static mGPSInfo:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

.field public static mGPSViewMgr:Lcom/thinkware/sundo/inavi3d/GPSViewManager;

.field static mGSensor_Action:I

.field static mGSensor_Error:I

.field static mGSensor_Sensibility:I

.field static mGSensor_Use:I

.field private static mHandlerMain:Landroid/os/Handler;

.field static mMMCInfo:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

.field static mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

.field static mSATInfo:Lcom/tw/mapmatch/remote/mapmatch/SATInfo;

.field public static mSafeZoneAvr:Z

.field static mUIManager:Lcom/thinkware/sundo/inavi3d/UIManager;

.field static m_LaneTurnModeLayout:Landroid/widget/LinearLayout;

.field private static m_last_ihr_path:Ljava/lang/String;

.field private static m_nTrafficLevel:I

.field static safeZoneLayout:Landroid/widget/RelativeLayout;

.field static safeZoneLayout2:Landroid/widget/RelativeLayout;

.field static safeZoneLayout3:Landroid/widget/RelativeLayout;

.field static safeZoneLayout4:Landroid/widget/RelativeLayout;

.field static safeZoneView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;

.field static safeZoneView2:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;

.field static safeZoneView3:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;

.field static safeZoneView4:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;

.field static sectionView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;

.field static sectionView2:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;

.field static sectionView3:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;

.field static sectionView4:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;

.field static speedview:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SpeedView;

.field static speedview2:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SpeedView;

.field static speedview3:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SpeedView;

.field static speedview4:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SpeedView;

.field private static tbtguide:Lcom/thinkware/sundo/remoteTBT/TBTGuide;

.field private static timer:Ljava/util/Timer;

.field static turnAreaView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;

.field static turnAreaView2:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;

.field static turnAreaView4:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;

.field private static viaStatus:Z


# instance fields
.field public bMapPopup:Z

.field public force_exit:Z


# direct methods
.method static constructor <clinit>()V
    .locals 7

    .prologue
    const/4 v6, 0x0

    const/4 v4, -0x1

    const/4 v5, 0x0

    .line 54
    sput-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    .line 57
    const-string v3, "inavi3d_java"

    sput-object v3, Lcom/thinkware/sundo/inavi3d/Inavi;->TAG:Ljava/lang/String;

    .line 59
    new-instance v3, Lcom/thinkware/sundo/remoteTBT/TBTGuide;

    invoke-direct {v3}, Lcom/thinkware/sundo/remoteTBT/TBTGuide;-><init>()V

    sput-object v3, Lcom/thinkware/sundo/inavi3d/Inavi;->tbtguide:Lcom/thinkware/sundo/remoteTBT/TBTGuide;

    .line 60
    const/16 v3, 0x2713

    sput v3, Lcom/thinkware/sundo/inavi3d/Inavi;->MULTI_BUTTONDOWN:I

    .line 61
    const/16 v3, 0x2714

    sput v3, Lcom/thinkware/sundo/inavi3d/Inavi;->MULTI_BUTTONMOVE:I

    .line 62
    const/16 v3, 0x2715

    sput v3, Lcom/thinkware/sundo/inavi3d/Inavi;->MULTI_BUTTONUP:I

    .line 66
    sput-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->mContext:Landroid/content/Context;

    .line 68
    sput-boolean v6, Lcom/thinkware/sundo/inavi3d/Inavi;->viaStatus:Z

    .line 70
    sput-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->mMMCInfo:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    .line 71
    sput-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->mGPSInfo:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    .line 72
    sput-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->mSATInfo:Lcom/tw/mapmatch/remote/mapmatch/SATInfo;

    .line 74
    sput v4, Lcom/thinkware/sundo/inavi3d/Inavi;->mGSensor_Action:I

    .line 75
    sput v4, Lcom/thinkware/sundo/inavi3d/Inavi;->mGSensor_Error:I

    .line 76
    sput v4, Lcom/thinkware/sundo/inavi3d/Inavi;->mGSensor_Sensibility:I

    .line 77
    sput v4, Lcom/thinkware/sundo/inavi3d/Inavi;->mGSensor_Use:I

    .line 79
    sput-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->mUIManager:Lcom/thinkware/sundo/inavi3d/UIManager;

    .line 81
    sput-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->speedview:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SpeedView;

    .line 115
    sput-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->m_LaneTurnModeLayout:Landroid/widget/LinearLayout;

    .line 118
    sput-boolean v6, Lcom/thinkware/sundo/inavi3d/Inavi;->mSafeZoneAvr:Z

    .line 122
    new-instance v3, Lcom/thinkware/sundo/inavi3d/GPSViewManager;

    invoke-direct {v3}, Lcom/thinkware/sundo/inavi3d/GPSViewManager;-><init>()V

    sput-object v3, Lcom/thinkware/sundo/inavi3d/Inavi;->mGPSViewMgr:Lcom/thinkware/sundo/inavi3d/GPSViewManager;

    .line 131
    sput v6, Lcom/thinkware/sundo/inavi3d/Inavi;->m_nTrafficLevel:I

    .line 269
    const-string v0, "Inavi3D"

    .line 271
    .local v0, "LIB_NAME":Ljava/lang/String;
    :try_start_0
    const-string v3, "Inavi3D"

    invoke-static {v3}, Ljava/lang/System;->loadLibrary(Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/UnsatisfiedLinkError; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/SecurityException; {:try_start_0 .. :try_end_0} :catch_1

    .line 358
    :goto_0
    sput-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->authDrm:Lcom/thinkware/sundo/inavi3d/AuthDRM;

    .line 543
    const/4 v3, 0x1

    sput-boolean v3, Lcom/thinkware/sundo/inavi3d/Inavi;->firstTBTGuide:Z

    .line 1102
    sput-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->m_last_ihr_path:Ljava/lang/String;

    .line 1104
    new-instance v3, Ljava/util/Vector;

    invoke-direct {v3}, Ljava/util/Vector;-><init>()V

    sput-object v3, Lcom/thinkware/sundo/inavi3d/Inavi;->backgroundMsgVec:Ljava/util/Vector;

    .line 1106
    sput-boolean v6, Lcom/thinkware/sundo/inavi3d/Inavi;->existdBackgroundMessage:Z

    return-void

    .line 272
    :catch_0
    move-exception v2

    .line 273
    .local v2, "ule":Ljava/lang/UnsatisfiedLinkError;
    const-string v3, "twfail"

    const-string v4, "missing library so : Inavi3D"

    invoke-static {v3, v4}, Lcom/thinkware/sundo/inavi3d/LOGTW;->e(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_0

    .line 274
    .end local v2    # "ule":Ljava/lang/UnsatisfiedLinkError;
    :catch_1
    move-exception v1

    .line 275
    .local v1, "e":Ljava/lang/SecurityException;
    const-string v3, "twfail"

    const-string v4, "security library so : Inavi3D"

    invoke-static {v3, v4}, Lcom/thinkware/sundo/inavi3d/LOGTW;->e(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_0
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/os/Handler;)V
    .locals 2
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "MainHandler"    # Landroid/os/Handler;

    .prologue
    const/4 v0, 0x0

    .line 279
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 53
    iput-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/Inavi;->force_exit:Z

    .line 55
    iput-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/Inavi;->bMapPopup:Z

    .line 280
    sput-object p1, Lcom/thinkware/sundo/inavi3d/Inavi;->mContext:Landroid/content/Context;

    .line 281
    sput-object p2, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    .line 282
    sget-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->mGPSViewMgr:Lcom/thinkware/sundo/inavi3d/GPSViewManager;

    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mContext:Landroid/content/Context;

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/inavi3d/GPSViewManager;->setParentContext(Landroid/content/Context;)V

    .line 283
    return-void
.end method

.method static CheckAutoMenu()V
    .locals 4

    .prologue
    const/4 v3, 0x0

    .line 1033
    sget-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const v2, 0x24aba

    invoke-static {v1, v2, v3, v3}, Landroid/os/Message;->obtain(Landroid/os/Handler;III)Landroid/os/Message;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    .line 1034
    return-void
.end method

.method static EUC2UTF([B)Ljava/lang/String;
    .locals 4
    .param p0, "inBuf"    # [B

    .prologue
    .line 439
    const/4 v1, 0x0

    .line 441
    .local v1, "newString":Ljava/lang/String;
    :try_start_0
    new-instance v2, Ljava/lang/String;

    const-string v3, "EUC-KR"

    invoke-direct {v2, p0, v3}, Ljava/lang/String;-><init>([BLjava/lang/String;)V
    :try_end_0
    .catch Ljava/io/UnsupportedEncodingException; {:try_start_0 .. :try_end_0} :catch_0

    .end local v1    # "newString":Ljava/lang/String;
    .local v2, "newString":Ljava/lang/String;
    move-object v1, v2

    .line 446
    .end local v2    # "newString":Ljava/lang/String;
    .restart local v1    # "newString":Ljava/lang/String;
    :goto_0
    return-object v1

    .line 442
    :catch_0
    move-exception v0

    .line 444
    .local v0, "e":Ljava/io/UnsupportedEncodingException;
    invoke-virtual {v0}, Ljava/io/UnsupportedEncodingException;->printStackTrace()V

    goto :goto_0
.end method

.method public static native GetAddressVerInfo(I)Ljava/lang/String;
.end method

.method static GetDRMString(I)Ljava/lang/String;
    .locals 1
    .param p0, "i"    # I

    .prologue
    .line 432
    sget-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->authDrm:Lcom/thinkware/sundo/inavi3d/AuthDRM;

    if-eqz v0, :cond_0

    .line 433
    sget-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->authDrm:Lcom/thinkware/sundo/inavi3d/AuthDRM;

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/AuthDRM;->GetSDRM4MMC()Ljava/lang/String;

    move-result-object v0

    .line 435
    :goto_0
    return-object v0

    :cond_0
    const-string v0, "NOT_AUTHORIZED"

    goto :goto_0
.end method

.method public static native GetDosrch(I)Ljava/lang/String;
.end method

.method public static native GetGPSImageInfoData([I[I[Z)I
.end method

.method public static GetGPSInfo(I)Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;
    .locals 2
    .param p0, "i"    # I

    .prologue
    .line 997
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    if-nez v1, :cond_0

    .line 998
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mGPSInfo:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    .line 1006
    :goto_0
    return-object v1

    .line 1001
    :cond_0
    :try_start_0
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    invoke-interface {v1}, Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;->getGPSInfo()Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    move-result-object v1

    sput-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mGPSInfo:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    .line 1006
    :goto_1
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mGPSInfo:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    goto :goto_0

    .line 1002
    :catch_0
    move-exception v0

    .line 1004
    .local v0, "e":Landroid/os/RemoteException;
    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    goto :goto_1
.end method

.method public static native GetGPSInfoData(I)Ljava/lang/String;
.end method

.method static GetMMCInfo(I)Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;
    .locals 3
    .param p0, "i"    # I

    .prologue
    .line 981
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    if-nez v1, :cond_0

    .line 982
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mMMCInfo:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    .line 992
    :goto_0
    return-object v1

    .line 985
    :cond_0
    :try_start_0
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    invoke-interface {v1}, Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;->getMMCInfo()Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    move-result-object v1

    sput-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mMMCInfo:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    .line 986
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mMMCInfo:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    sget-object v2, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    invoke-interface {v2}, Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;->SimulationGetPos()I

    move-result v2

    iput v2, v1, Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;->nSimulation_pos:I
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    .line 992
    :goto_1
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mMMCInfo:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    goto :goto_0

    .line 988
    :catch_0
    move-exception v0

    .line 990
    .local v0, "e":Landroid/os/RemoteException;
    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    goto :goto_1
.end method

.method public static native GetMaxAeroImageLevel()I
.end method

.method public static native GetNRFCode(I)I
.end method

.method public static native GetProgramVerInfo(I)Ljava/lang/String;
.end method

.method static GetSATInfo(I)Lcom/tw/mapmatch/remote/mapmatch/SATInfo;
    .locals 2
    .param p0, "i"    # I

    .prologue
    .line 1011
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    if-nez v1, :cond_0

    .line 1012
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mSATInfo:Lcom/tw/mapmatch/remote/mapmatch/SATInfo;

    .line 1020
    :goto_0
    return-object v1

    .line 1015
    :cond_0
    :try_start_0
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    invoke-interface {v1}, Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;->getSATInfo()Lcom/tw/mapmatch/remote/mapmatch/SATInfo;

    move-result-object v1

    sput-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mSATInfo:Lcom/tw/mapmatch/remote/mapmatch/SATInfo;
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    .line 1020
    :goto_1
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mSATInfo:Lcom/tw/mapmatch/remote/mapmatch/SATInfo;

    goto :goto_0

    .line 1016
    :catch_0
    move-exception v0

    .line 1018
    .local v0, "e":Landroid/os/RemoteException;
    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    goto :goto_1
.end method

.method public static GetSensorActionStatus(I)I
    .locals 2
    .param p0, "i"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .prologue
    .line 470
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    if-nez v1, :cond_0

    .line 471
    sget v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mGSensor_Action:I

    .line 479
    :goto_0
    return v1

    .line 474
    :cond_0
    :try_start_0
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    invoke-interface {v1}, Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;->getSensorActionStatus()I

    move-result v1

    sput v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mGSensor_Action:I
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    .line 479
    :goto_1
    sget v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mGSensor_Action:I

    goto :goto_0

    .line 475
    :catch_0
    move-exception v0

    .line 477
    .local v0, "e":Landroid/os/RemoteException;
    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    goto :goto_1
.end method

.method public static GetSensorErrorStatus(I)I
    .locals 2
    .param p0, "i"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .prologue
    .line 484
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    if-nez v1, :cond_0

    .line 485
    sget v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mGSensor_Error:I

    .line 493
    :goto_0
    return v1

    .line 488
    :cond_0
    :try_start_0
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    invoke-interface {v1}, Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;->getSensorErrorStatus()I

    move-result v1

    sput v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mGSensor_Error:I
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    .line 493
    :goto_1
    sget v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mGSensor_Error:I

    goto :goto_0

    .line 489
    :catch_0
    move-exception v0

    .line 491
    .local v0, "e":Landroid/os/RemoteException;
    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    goto :goto_1
.end method

.method public static GetSensorSensiblityStatus(I)I
    .locals 2
    .param p0, "i"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .prologue
    .line 498
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    if-nez v1, :cond_0

    .line 499
    sget v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mGSensor_Sensibility:I

    .line 508
    :goto_0
    return v1

    .line 502
    :cond_0
    :try_start_0
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    invoke-interface {v1}, Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;->getSensorSensiblityStatus()I

    move-result v1

    sput v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mGSensor_Sensibility:I
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    .line 508
    :goto_1
    sget v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mGSensor_Sensibility:I

    goto :goto_0

    .line 504
    :catch_0
    move-exception v0

    .line 506
    .local v0, "e":Landroid/os/RemoteException;
    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    goto :goto_1
.end method

.method public static GetSensorUseStatus(I)I
    .locals 2
    .param p0, "i"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .prologue
    .line 513
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    if-nez v1, :cond_0

    .line 514
    sget v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mGSensor_Use:I

    .line 522
    :goto_0
    return v1

    .line 517
    :cond_0
    :try_start_0
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    invoke-interface {v1}, Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;->getSensorUseStatus()I

    move-result v1

    sput v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mGSensor_Use:I
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    .line 522
    :goto_1
    sget v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mGSensor_Use:I

    goto :goto_0

    .line 518
    :catch_0
    move-exception v0

    .line 520
    .local v0, "e":Landroid/os/RemoteException;
    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    goto :goto_1
.end method

.method public static native GetStrRegSrchName()Ljava/lang/String;
.end method

.method public static native GetTBTGuide(Lcom/thinkware/sundo/remoteTBT/TBTGuide;)Lcom/thinkware/sundo/remoteTBT/TBTGuide;
.end method

.method public static GetTrafficIndcatorLevel()I
    .locals 1

    .prologue
    .line 134
    sget v0, Lcom/thinkware/sundo/inavi3d/Inavi;->m_nTrafficLevel:I

    return v0
.end method

.method public static native GetViaPoint(II)D
.end method

.method public static native GetViaStatus()Z
.end method

.method public static native MapNameSearch(IIII)Z
.end method

.method public static native MapNameSearchNoButton(II)V
.end method

.method public static native MapNameSearchViewMode(III)Z
.end method

.method public static native MapRoutePoint()V
.end method

.method public static native MapTotalRoute()V
.end method

.method static OnEventProcess()I
    .locals 1

    .prologue
    .line 466
    const/4 v0, 0x0

    return v0
.end method

.method static OnShowMessage(Ljava/lang/String;II)I
    .locals 2
    .param p0, "msg"    # Ljava/lang/String;
    .param p1, "type"    # I
    .param p2, "duration"    # I

    .prologue
    .line 388
    sget-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->mContext:Landroid/content/Context;

    if-nez v0, :cond_0

    .line 389
    const/4 v0, -0x1

    .line 417
    :goto_0
    return v0

    .line 390
    :cond_0
    sget-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    new-instance v1, Lcom/thinkware/sundo/inavi3d/Inavi$1;

    invoke-direct {v1, p0}, Lcom/thinkware/sundo/inavi3d/Inavi$1;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 417
    const/4 v0, 0x0

    goto :goto_0
.end method

.method public static native ProcessEventSlidingToolBar(III)Z
.end method

.method public static ProcessMessage(IILjava/lang/String;)I
    .locals 23
    .param p0, "message"    # I
    .param p1, "intvalue"    # I
    .param p2, "strvalue"    # Ljava/lang/String;

    .prologue
    .line 1122
    const/16 v16, 0x1

    .line 1124
    .local v16, "ret":I
    sget-object v19, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    if-nez v19, :cond_0

    move/from16 v17, v16

    .line 1521
    .end local v16    # "ret":I
    .local v17, "ret":I
    :goto_0
    return v17

    .line 1127
    .end local v17    # "ret":I
    .restart local v16    # "ret":I
    :cond_0
    const/16 v19, 0x138c

    move/from16 v0, p0

    move/from16 v1, v19

    if-ne v0, v1, :cond_1

    .line 1128
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/Inavi;->_CheckData()I

    move-result v16

    move/from16 v17, v16

    .line 1129
    .end local v16    # "ret":I
    .restart local v17    # "ret":I
    goto :goto_0

    .line 1132
    .end local v17    # "ret":I
    .restart local v16    # "ret":I
    :cond_1
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    move-result-object v19

    invoke-virtual/range {v19 .. v19}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->isReadyDPMap()Z

    move-result v19

    if-nez v19, :cond_7

    .line 1133
    const v19, 0x1d4c2

    move/from16 v0, p0

    move/from16 v1, v19

    if-ne v0, v1, :cond_2

    .line 1134
    const-string v19, "inavi3d_java"

    const-string v20, "MSG_ID_COMMON_BEGIN_MAP_DP"

    invoke-static/range {v19 .. v20}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 1137
    const-wide/16 v20, 0x2

    sput-wide v20, Lcom/thinkware/sundo/inavi3d/DPView;->BackGroundRenderingStep:J

    .line 1139
    new-instance v19, Ljava/lang/Thread;

    new-instance v20, Lcom/thinkware/sundo/inavi3d/Inavi$9;

    invoke-direct/range {v20 .. v20}, Lcom/thinkware/sundo/inavi3d/Inavi$9;-><init>()V

    invoke-direct/range {v19 .. v20}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual/range {v19 .. v19}, Ljava/lang/Thread;->start()V

    .line 1146
    sget-object v19, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    new-instance v20, Lcom/thinkware/sundo/inavi3d/Inavi$10;

    invoke-direct/range {v20 .. v20}, Lcom/thinkware/sundo/inavi3d/Inavi$10;-><init>()V

    invoke-virtual/range {v19 .. v20}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    move/from16 v17, v16

    .line 1159
    .end local v16    # "ret":I
    .restart local v17    # "ret":I
    goto :goto_0

    .line 1163
    .end local v17    # "ret":I
    .restart local v16    # "ret":I
    :cond_2
    const v19, 0x1d4c8

    move/from16 v0, p0

    move/from16 v1, v19

    if-ne v0, v1, :cond_3

    .line 1164
    sget-object v19, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v20, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const v21, 0x1d4c8

    invoke-static/range {v20 .. v21}, Landroid/os/Message;->obtain(Landroid/os/Handler;I)Landroid/os/Message;

    move-result-object v20

    invoke-virtual/range {v19 .. v20}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    move/from16 v17, v16

    .line 1165
    .end local v16    # "ret":I
    .restart local v17    # "ret":I
    goto :goto_0

    .line 1168
    .end local v17    # "ret":I
    .restart local v16    # "ret":I
    :cond_3
    const/4 v8, 0x0

    .line 1169
    .local v8, "duplicateMsgFlag":Z
    const/4 v10, 0x0

    .local v10, "i":I
    :goto_1
    sget-object v19, Lcom/thinkware/sundo/inavi3d/Inavi;->backgroundMsgVec:Ljava/util/Vector;

    invoke-virtual/range {v19 .. v19}, Ljava/util/Vector;->size()I

    move-result v19

    move/from16 v0, v19

    if-ge v10, v0, :cond_4

    .line 1170
    sget-object v19, Lcom/thinkware/sundo/inavi3d/Inavi;->backgroundMsgVec:Ljava/util/Vector;

    move-object/from16 v0, v19

    invoke-virtual {v0, v10}, Ljava/util/Vector;->get(I)Ljava/lang/Object;

    move-result-object v19

    check-cast v19, Lcom/thinkware/sundo/inavi3d/Struct/MsgStructer;

    move-object/from16 v0, v19

    iget v0, v0, Lcom/thinkware/sundo/inavi3d/Struct/MsgStructer;->mag:I

    move/from16 v19, v0

    move/from16 v0, v19

    move/from16 v1, p0

    if-ne v0, v1, :cond_6

    .line 1171
    sget-object v19, Lcom/thinkware/sundo/inavi3d/Inavi;->backgroundMsgVec:Ljava/util/Vector;

    move-object/from16 v0, v19

    invoke-virtual {v0, v10}, Ljava/util/Vector;->get(I)Ljava/lang/Object;

    move-result-object v19

    check-cast v19, Lcom/thinkware/sundo/inavi3d/Struct/MsgStructer;

    move/from16 v0, p0

    move-object/from16 v1, v19

    iput v0, v1, Lcom/thinkware/sundo/inavi3d/Struct/MsgStructer;->mag:I

    .line 1172
    sget-object v19, Lcom/thinkware/sundo/inavi3d/Inavi;->backgroundMsgVec:Ljava/util/Vector;

    move-object/from16 v0, v19

    invoke-virtual {v0, v10}, Ljava/util/Vector;->get(I)Ljava/lang/Object;

    move-result-object v19

    check-cast v19, Lcom/thinkware/sundo/inavi3d/Struct/MsgStructer;

    move/from16 v0, p1

    move-object/from16 v1, v19

    iput v0, v1, Lcom/thinkware/sundo/inavi3d/Struct/MsgStructer;->intvalue:I

    .line 1173
    sget-object v19, Lcom/thinkware/sundo/inavi3d/Inavi;->backgroundMsgVec:Ljava/util/Vector;

    move-object/from16 v0, v19

    invoke-virtual {v0, v10}, Ljava/util/Vector;->get(I)Ljava/lang/Object;

    move-result-object v19

    check-cast v19, Lcom/thinkware/sundo/inavi3d/Struct/MsgStructer;

    move-object/from16 v0, p2

    move-object/from16 v1, v19

    iput-object v0, v1, Lcom/thinkware/sundo/inavi3d/Struct/MsgStructer;->strvalue:Ljava/lang/String;

    .line 1174
    const/4 v8, 0x1

    .line 1179
    :cond_4
    if-nez v8, :cond_5

    .line 1180
    new-instance v13, Lcom/thinkware/sundo/inavi3d/Struct/MsgStructer;

    move/from16 v0, p0

    move/from16 v1, p1

    move-object/from16 v2, p2

    invoke-direct {v13, v0, v1, v2}, Lcom/thinkware/sundo/inavi3d/Struct/MsgStructer;-><init>(IILjava/lang/String;)V

    .line 1181
    .local v13, "msg":Lcom/thinkware/sundo/inavi3d/Struct/MsgStructer;
    sget-object v19, Lcom/thinkware/sundo/inavi3d/Inavi;->backgroundMsgVec:Ljava/util/Vector;

    move-object/from16 v0, v19

    invoke-virtual {v0, v13}, Ljava/util/Vector;->add(Ljava/lang/Object;)Z

    .line 1182
    const/16 v19, 0x1

    sput-boolean v19, Lcom/thinkware/sundo/inavi3d/Inavi;->existdBackgroundMessage:Z

    .end local v13    # "msg":Lcom/thinkware/sundo/inavi3d/Struct/MsgStructer;
    :cond_5
    move/from16 v17, v16

    .line 1185
    .end local v16    # "ret":I
    .restart local v17    # "ret":I
    goto/16 :goto_0

    .line 1169
    .end local v17    # "ret":I
    .restart local v16    # "ret":I
    :cond_6
    add-int/lit8 v10, v10, 0x1

    goto :goto_1

    .line 1188
    .end local v8    # "duplicateMsgFlag":Z
    .end local v10    # "i":I
    :cond_7
    sget-boolean v19, Lcom/thinkware/sundo/inavi3d/Inavi;->existdBackgroundMessage:Z

    const/16 v20, 0x1

    move/from16 v0, v19

    move/from16 v1, v20

    if-ne v0, v1, :cond_8

    .line 1189
    const/16 v19, 0x0

    sput-boolean v19, Lcom/thinkware/sundo/inavi3d/Inavi;->existdBackgroundMessage:Z

    .line 1190
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/Inavi;->handleBackgroundMessage()V

    .line 1194
    :cond_8
    sparse-switch p0, :sswitch_data_0

    .line 1513
    :try_start_0
    sget-object v19, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v20, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const/16 v21, 0x0

    move-object/from16 v0, v20

    move/from16 v1, p0

    move/from16 v2, p1

    move/from16 v3, v21

    move-object/from16 v4, p2

    invoke-static {v0, v1, v2, v3, v4}, Landroid/os/Message;->obtain(Landroid/os/Handler;IIILjava/lang/Object;)Landroid/os/Message;

    move-result-object v20

    invoke-virtual/range {v19 .. v20}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    :cond_9
    :goto_2
    move/from16 v17, v16

    .line 1521
    .end local v16    # "ret":I
    .restart local v17    # "ret":I
    goto/16 :goto_0

    .line 1197
    .end local v17    # "ret":I
    .restart local v16    # "ret":I
    :sswitch_0
    const/16 v19, 0x1

    move/from16 v0, p1

    move/from16 v1, v19

    if-ne v0, v1, :cond_a

    .line 1198
    sget-object v19, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v20, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const/16 v21, 0x7d9

    invoke-static/range {v20 .. v21}, Landroid/os/Message;->obtain(Landroid/os/Handler;I)Landroid/os/Message;

    move-result-object v20

    invoke-virtual/range {v19 .. v20}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_2

    .line 1516
    :catch_0
    move-exception v9

    .line 1518
    .local v9, "e":Landroid/os/RemoteException;
    invoke-virtual {v9}, Landroid/os/RemoteException;->printStackTrace()V

    goto :goto_2

    .line 1200
    .end local v9    # "e":Landroid/os/RemoteException;
    :cond_a
    :try_start_1
    sget-object v19, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v20, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const/16 v21, 0x7da

    invoke-static/range {v20 .. v21}, Landroid/os/Message;->obtain(Landroid/os/Handler;I)Landroid/os/Message;

    move-result-object v20

    invoke-virtual/range {v19 .. v20}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto :goto_2

    .line 1204
    :sswitch_1
    sget-object v19, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    invoke-interface/range {v19 .. v19}, Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;->ChangeLink()V

    goto :goto_2

    .line 1209
    :sswitch_2
    sget-object v19, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    invoke-interface/range {v19 .. v19}, Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;->InitGPS()V

    goto :goto_2

    .line 1215
    :sswitch_3
    const-string v19, "hslee"

    new-instance v20, Ljava/lang/StringBuilder;

    invoke-direct/range {v20 .. v20}, Ljava/lang/StringBuilder;-><init>()V

    const-string v21, "NAVTIVE_MSG_ROUTESEARCHING : "

    invoke-virtual/range {v20 .. v21}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v20

    move-object/from16 v0, v20

    move/from16 v1, p1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v20

    const-string v21, " path : "

    invoke-virtual/range {v20 .. v21}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v20

    move-object/from16 v0, v20

    move-object/from16 v1, p2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v20

    invoke-virtual/range {v20 .. v20}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v20

    invoke-static/range {v19 .. v20}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 1225
    const-string v19, "cancelroute"

    move-object/from16 v0, p2

    move-object/from16 v1, v19

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v19

    if-eqz v19, :cond_b

    .line 1226
    const/16 v19, 0x0

    sput-object v19, Lcom/thinkware/sundo/inavi3d/Inavi;->m_last_ihr_path:Ljava/lang/String;

    .line 1230
    :goto_3
    sget-object v19, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    move-object/from16 v0, v19

    move-object/from16 v1, p2

    invoke-interface {v0, v1}, Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;->setRouteTbl(Ljava/lang/String;)Z

    goto :goto_2

    .line 1228
    :cond_b
    sput-object p2, Lcom/thinkware/sundo/inavi3d/Inavi;->m_last_ihr_path:Ljava/lang/String;

    goto :goto_3

    .line 1235
    :sswitch_4
    if-nez p1, :cond_c

    .line 1237
    sget-object v19, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    const/16 v20, 0x0

    invoke-interface/range {v19 .. v20}, Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;->setCurrent(Z)V

    .line 1238
    sget-object v19, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v20, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const v21, 0x222e2

    move-object/from16 v0, v20

    move/from16 v1, v21

    move-object/from16 v2, p2

    invoke-static {v0, v1, v2}, Landroid/os/Message;->obtain(Landroid/os/Handler;ILjava/lang/Object;)Landroid/os/Message;

    move-result-object v20

    invoke-virtual/range {v19 .. v20}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto/16 :goto_2

    .line 1239
    :cond_c
    const/16 v19, 0x64

    move/from16 v0, p1

    move/from16 v1, v19

    if-eq v0, v1, :cond_d

    const/16 v19, 0xc8

    move/from16 v0, p1

    move/from16 v1, v19

    if-eq v0, v1, :cond_d

    const/16 v19, 0x12c

    move/from16 v0, p1

    move/from16 v1, v19

    if-ne v0, v1, :cond_e

    .line 1241
    :cond_d
    sget-object v19, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    const/16 v20, 0x1

    invoke-interface/range {v19 .. v20}, Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;->setCurrent(Z)V

    .line 1242
    const-string v19, "inavi3d_sleeptime"

    const-string v20, "DeviceState.SLEEP_NORMAL"

    const/16 v21, 0x0

    move/from16 v0, v21

    new-array v0, v0, [Ljava/lang/Object;

    move-object/from16 v21, v0

    invoke-static/range {v20 .. v21}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v20

    invoke-static/range {v19 .. v20}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 1243
    sget-object v19, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v20, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const v21, 0x222e2

    const/16 v22, 0x0

    move-object/from16 v0, v20

    move/from16 v1, v21

    move/from16 v2, p1

    move/from16 v3, v22

    invoke-static {v0, v1, v2, v3}, Landroid/os/Message;->obtain(Landroid/os/Handler;III)Landroid/os/Message;

    move-result-object v20

    invoke-virtual/range {v19 .. v20}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto/16 :goto_2

    .line 1246
    :cond_e
    sget-object v19, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    const/16 v20, 0x1

    invoke-interface/range {v19 .. v20}, Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;->setCurrent(Z)V

    .line 1247
    const-string v19, "inavi3d_sleeptime"

    const-string v20, "DeviceState.SLEEP_NORMAL"

    const/16 v21, 0x0

    move/from16 v0, v21

    new-array v0, v0, [Ljava/lang/Object;

    move-object/from16 v21, v0

    invoke-static/range {v20 .. v21}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v20

    invoke-static/range {v19 .. v20}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 1248
    sget-object v19, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v20, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const v21, 0x222e1

    invoke-static/range {v20 .. v21}, Landroid/os/Message;->obtain(Landroid/os/Handler;I)Landroid/os/Message;

    move-result-object v20

    invoke-virtual/range {v19 .. v20}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto/16 :goto_2

    .line 1278
    :sswitch_5
    invoke-static/range {p2 .. p2}, Ljava/lang/Integer;->getInteger(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v12

    .line 1279
    .local v12, "mode":Ljava/lang/Integer;
    if-nez v12, :cond_f

    .line 1280
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/MapPopup/GPSMapPopup;->GetViewMode()I

    move-result v19

    invoke-static/range {v19 .. v19}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v12

    .line 1281
    :cond_f
    sget-object v19, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v20, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const v21, 0x222ed

    invoke-virtual {v12}, Ljava/lang/Integer;->intValue()I

    move-result v22

    move-object/from16 v0, v20

    move/from16 v1, v21

    move/from16 v2, p1

    move/from16 v3, v22

    invoke-static {v0, v1, v2, v3}, Landroid/os/Message;->obtain(Landroid/os/Handler;III)Landroid/os/Message;

    move-result-object v20

    invoke-virtual/range {v19 .. v20}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto/16 :goto_2

    .line 1284
    .end local v12    # "mode":Ljava/lang/Integer;
    :sswitch_6
    sget-object v19, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v20, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const v21, 0x222ee

    const/16 v22, 0x0

    move-object/from16 v0, v20

    move/from16 v1, v21

    move/from16 v2, p1

    move/from16 v3, v22

    invoke-static {v0, v1, v2, v3}, Landroid/os/Message;->obtain(Landroid/os/Handler;III)Landroid/os/Message;

    move-result-object v20

    invoke-virtual/range {v19 .. v20}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto/16 :goto_2

    .line 1287
    :sswitch_7
    const-string v19, "DUAL_ON"

    move-object/from16 v0, p2

    move-object/from16 v1, v19

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v19

    if-eqz v19, :cond_10

    .line 1288
    sget-object v19, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v20, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const v21, 0x222f1

    const/16 v22, 0x1

    move-object/from16 v0, v20

    move/from16 v1, v21

    move/from16 v2, p1

    move/from16 v3, v22

    invoke-static {v0, v1, v2, v3}, Landroid/os/Message;->obtain(Landroid/os/Handler;III)Landroid/os/Message;

    move-result-object v20

    invoke-virtual/range {v19 .. v20}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto/16 :goto_2

    .line 1290
    :cond_10
    sget-object v19, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v20, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const v21, 0x222f1

    const/16 v22, 0x0

    move-object/from16 v0, v20

    move/from16 v1, v21

    move/from16 v2, p1

    move/from16 v3, v22

    invoke-static {v0, v1, v2, v3}, Landroid/os/Message;->obtain(Landroid/os/Handler;III)Landroid/os/Message;

    move-result-object v20

    invoke-virtual/range {v19 .. v20}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto/16 :goto_2

    .line 1294
    :sswitch_8
    const-string v19, "normal"

    move-object/from16 v0, p2

    move-object/from16 v1, v19

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v19

    if-eqz v19, :cond_11

    .line 1295
    sget-object v19, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v20, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const v21, 0x22348

    const/16 v22, 0x0

    move-object/from16 v0, v20

    move/from16 v1, v21

    move/from16 v2, v22

    move/from16 v3, p1

    invoke-static {v0, v1, v2, v3}, Landroid/os/Message;->obtain(Landroid/os/Handler;III)Landroid/os/Message;

    move-result-object v20

    invoke-virtual/range {v19 .. v20}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto/16 :goto_2

    .line 1297
    :cond_11
    sget-object v19, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v20, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const v21, 0x22348

    const/16 v22, 0x1

    move-object/from16 v0, v20

    move/from16 v1, v21

    move/from16 v2, v22

    move/from16 v3, p1

    invoke-static {v0, v1, v2, v3}, Landroid/os/Message;->obtain(Landroid/os/Handler;III)Landroid/os/Message;

    move-result-object v20

    invoke-virtual/range {v19 .. v20}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto/16 :goto_2

    .line 1301
    :sswitch_9
    sget-object v19, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v20, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const/16 v21, 0x7dc

    const/16 v22, 0x0

    move-object/from16 v0, v20

    move/from16 v1, v21

    move/from16 v2, p1

    move/from16 v3, v22

    invoke-static {v0, v1, v2, v3}, Landroid/os/Message;->obtain(Landroid/os/Handler;III)Landroid/os/Message;

    move-result-object v20

    invoke-virtual/range {v19 .. v20}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto/16 :goto_2

    .line 1304
    :sswitch_a
    sget-object v19, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v20, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const/16 v21, 0x7db

    const/16 v22, 0x0

    move-object/from16 v0, v20

    move/from16 v1, v21

    move/from16 v2, p1

    move/from16 v3, v22

    invoke-static {v0, v1, v2, v3}, Landroid/os/Message;->obtain(Landroid/os/Handler;III)Landroid/os/Message;

    move-result-object v20

    invoke-virtual/range {v19 .. v20}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto/16 :goto_2

    .line 1307
    :sswitch_b
    const-string v19, "background"

    move-object/from16 v0, p2

    move-object/from16 v1, v19

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v19

    if-nez v19, :cond_13

    .line 1308
    sget-object v19, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v20, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const v21, 0x222ef

    const/16 v22, 0x0

    move-object/from16 v0, v20

    move/from16 v1, v21

    move/from16 v2, p1

    move/from16 v3, v22

    invoke-static {v0, v1, v2, v3}, Landroid/os/Message;->obtain(Landroid/os/Handler;III)Landroid/os/Message;

    move-result-object v20

    invoke-virtual/range {v19 .. v20}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    .line 1309
    sput p1, Lcom/thinkware/sundo/inavi3d/Inavi;->m_nTrafficLevel:I

    .line 1316
    :goto_4
    const/16 v19, -0x1

    move/from16 v0, p1

    move/from16 v1, v19

    if-eq v0, v1, :cond_12

    const/16 v19, 0x63

    move/from16 v0, p1

    move/from16 v1, v19

    if-eq v0, v1, :cond_12

    if-nez p1, :cond_14

    .line 1317
    :cond_12
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    move-result-object v19

    const/16 v20, 0x0

    invoke-virtual/range {v19 .. v20}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->setEnabledTrafficMap(Z)V

    goto/16 :goto_2

    .line 1313
    :cond_13
    sput p1, Lcom/thinkware/sundo/inavi3d/Inavi;->m_nTrafficLevel:I

    goto :goto_4

    .line 1319
    :cond_14
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    move-result-object v19

    const/16 v20, 0x1

    invoke-virtual/range {v19 .. v20}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->setEnabledTrafficMap(Z)V

    goto/16 :goto_2

    .line 1324
    :sswitch_c
    sget-object v19, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v20, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const v21, 0x222f0

    const/16 v22, 0x0

    move-object/from16 v0, v20

    move/from16 v1, v21

    move/from16 v2, p1

    move/from16 v3, v22

    invoke-static {v0, v1, v2, v3}, Landroid/os/Message;->obtain(Landroid/os/Handler;III)Landroid/os/Message;

    move-result-object v20

    invoke-virtual/range {v19 .. v20}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto/16 :goto_2

    .line 1327
    :sswitch_d
    sget-object v19, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v20, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const v21, 0x222f2

    const/16 v22, 0x0

    move-object/from16 v0, v20

    move/from16 v1, v21

    move/from16 v2, p1

    move/from16 v3, v22

    invoke-static {v0, v1, v2, v3}, Landroid/os/Message;->obtain(Landroid/os/Handler;III)Landroid/os/Message;

    move-result-object v20

    invoke-virtual/range {v19 .. v20}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto/16 :goto_2

    .line 1333
    :sswitch_e
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/trafficinfo/TrafficInfo;->getInstance()Lcom/thinkware/sundo/inavi3d/trafficinfo/TrafficInfo;

    move-result-object v11

    .line 1334
    .local v11, "m_TrafficInfo":Lcom/thinkware/sundo/inavi3d/trafficinfo/TrafficInfo;
    invoke-virtual {v11}, Lcom/thinkware/sundo/inavi3d/trafficinfo/TrafficInfo;->_GetExclusiveSawTotalRTMCountOnRoute()I

    move-result v14

    .line 1335
    .local v14, "nCnt":I
    const-string v19, "JHS"

    new-instance v20, Ljava/lang/StringBuilder;

    invoke-direct/range {v20 .. v20}, Ljava/lang/StringBuilder;-><init>()V

    const-string v21, "\uacbd\ub85c\ub0b4 \uc720\uace0 \uac2f\uc218 : "

    invoke-virtual/range {v20 .. v21}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v20

    move-object/from16 v0, v20

    invoke-virtual {v0, v14}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v20

    invoke-virtual/range {v20 .. v20}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v20

    invoke-static/range {v19 .. v20}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    goto/16 :goto_2

    .line 1341
    .end local v11    # "m_TrafficInfo":Lcom/thinkware/sundo/inavi3d/trafficinfo/TrafficInfo;
    .end local v14    # "nCnt":I
    :sswitch_f
    if-nez p1, :cond_15

    .line 1342
    sget-object v19, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    const/16 v20, 0x0

    invoke-interface/range {v19 .. v20}, Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;->setWalk(Z)V

    goto/16 :goto_2

    .line 1344
    :cond_15
    sget-object v19, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    const/16 v20, 0x1

    invoke-interface/range {v19 .. v20}, Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;->setWalk(Z)V

    goto/16 :goto_2

    .line 1349
    :sswitch_10
    const-string v19, "SIMULATION_EXIT"

    move-object/from16 v0, v19

    move-object/from16 v1, p2

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v19

    if-eqz v19, :cond_16

    .line 1350
    sget-object v19, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    invoke-interface/range {v19 .. v19}, Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;->SimulationExit()V

    .line 1351
    sget-object v19, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v20, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const v21, 0x249f3

    const/16 v22, 0x0

    move-object/from16 v0, v20

    move/from16 v1, v21

    move/from16 v2, p1

    move/from16 v3, v22

    invoke-static {v0, v1, v2, v3}, Landroid/os/Message;->obtain(Landroid/os/Handler;III)Landroid/os/Message;

    move-result-object v20

    invoke-virtual/range {v19 .. v20}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    .line 1352
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v19

    const/16 v20, 0x0

    invoke-virtual/range {v19 .. v20}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->setSimul(Z)V

    goto/16 :goto_2

    .line 1354
    :cond_16
    const-string v19, "SIMULATION_START"

    move-object/from16 v0, v19

    move-object/from16 v1, p2

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v19

    if-eqz v19, :cond_17

    .line 1355
    sget-object v19, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    invoke-interface/range {v19 .. v19}, Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;->SimulationStart()V

    .line 1356
    sget-object v19, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v20, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const v21, 0x249f1

    const/16 v22, 0x0

    move-object/from16 v0, v20

    move/from16 v1, v21

    move/from16 v2, p1

    move/from16 v3, v22

    invoke-static {v0, v1, v2, v3}, Landroid/os/Message;->obtain(Landroid/os/Handler;III)Landroid/os/Message;

    move-result-object v20

    invoke-virtual/range {v19 .. v20}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto/16 :goto_2

    .line 1358
    :cond_17
    const-string v19, "SIMULATION_PLAY_STOP"

    move-object/from16 v0, v19

    move-object/from16 v1, p2

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v19

    if-eqz v19, :cond_19

    .line 1359
    if-nez p1, :cond_18

    .line 1360
    sget-object v19, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    const/16 v20, 0x1

    invoke-interface/range {v19 .. v20}, Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;->SimulationPause(Z)V

    .line 1361
    sget-object v19, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v20, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const v21, 0x249f9

    const/16 v22, 0x0

    move-object/from16 v0, v20

    move/from16 v1, v21

    move/from16 v2, p1

    move/from16 v3, v22

    invoke-static {v0, v1, v2, v3}, Landroid/os/Message;->obtain(Landroid/os/Handler;III)Landroid/os/Message;

    move-result-object v20

    invoke-virtual/range {v19 .. v20}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto/16 :goto_2

    .line 1364
    :cond_18
    sget-object v19, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    const/16 v20, 0x0

    invoke-interface/range {v19 .. v20}, Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;->SimulationPause(Z)V

    .line 1365
    sget-object v19, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v20, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const v21, 0x249f8

    const/16 v22, 0x0

    move-object/from16 v0, v20

    move/from16 v1, v21

    move/from16 v2, p1

    move/from16 v3, v22

    invoke-static {v0, v1, v2, v3}, Landroid/os/Message;->obtain(Landroid/os/Handler;III)Landroid/os/Message;

    move-result-object v20

    invoke-virtual/range {v19 .. v20}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto/16 :goto_2

    .line 1367
    :cond_19
    const-string v19, "SIMULATION_SPEED"

    move-object/from16 v0, v19

    move-object/from16 v1, p2

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v19

    if-eqz v19, :cond_1a

    .line 1368
    sget-object v19, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    move-object/from16 v0, v19

    move/from16 v1, p1

    invoke-interface {v0, v1}, Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;->SimulationChangeSpeed(I)V

    .line 1369
    sget-object v19, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v20, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const v21, 0x249f6

    const/16 v22, 0x0

    move-object/from16 v0, v20

    move/from16 v1, v21

    move/from16 v2, p1

    move/from16 v3, v22

    invoke-static {v0, v1, v2, v3}, Landroid/os/Message;->obtain(Landroid/os/Handler;III)Landroid/os/Message;

    move-result-object v20

    invoke-virtual/range {v19 .. v20}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto/16 :goto_2

    .line 1372
    :cond_1a
    const-string v19, "SIMULATION_POS"

    move-object/from16 v0, v19

    move-object/from16 v1, p2

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v19

    if-eqz v19, :cond_1b

    .line 1373
    sget-object v19, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    move-object/from16 v0, v19

    move/from16 v1, p1

    invoke-interface {v0, v1}, Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;->SimulationSetPos(I)V

    goto/16 :goto_2

    .line 1375
    :cond_1b
    const-string v19, "SIMULATION_PROGRESS"

    move-object/from16 v0, v19

    move-object/from16 v1, p2

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v19

    if-eqz v19, :cond_9

    .line 1377
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v19

    const v20, 0x7f0b0571

    invoke-virtual/range {v19 .. v20}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->findViewById(I)Landroid/view/View;

    move-result-object v6

    check-cast v6, Landroid/widget/Button;

    .line 1378
    .local v6, "Pause":Landroid/widget/Button;
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v19

    const v20, 0x7f0b05d2

    invoke-virtual/range {v19 .. v20}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->findViewById(I)Landroid/view/View;

    move-result-object v15

    check-cast v15, Lcom/thinkware/sundo/inavi3d/ui/component/simulateprograss;

    .line 1379
    .local v15, "progress":Lcom/thinkware/sundo/inavi3d/ui/component/simulateprograss;
    invoke-virtual {v15}, Lcom/thinkware/sundo/inavi3d/ui/component/simulateprograss;->getTag()Ljava/lang/Object;

    move-result-object v18

    check-cast v18, Ljava/lang/String;

    .line 1380
    .local v18, "tag":Ljava/lang/String;
    invoke-virtual {v6}, Landroid/widget/Button;->getVisibility()I

    move-result v19

    if-nez v19, :cond_9

    .line 1381
    sget-object v19, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v20, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const v21, 0x249fa

    const/16 v22, 0x0

    move-object/from16 v0, v20

    move/from16 v1, v21

    move/from16 v2, p1

    move/from16 v3, v22

    invoke-static {v0, v1, v2, v3}, Landroid/os/Message;->obtain(Landroid/os/Handler;III)Landroid/os/Message;

    move-result-object v20

    invoke-virtual/range {v19 .. v20}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto/16 :goto_2

    .line 1387
    .end local v6    # "Pause":Landroid/widget/Button;
    .end local v15    # "progress":Lcom/thinkware/sundo/inavi3d/ui/component/simulateprograss;
    .end local v18    # "tag":Ljava/lang/String;
    :sswitch_11
    const-string v19, "hslee"

    const-string v20, "NATIVE_MSG_REROUTE_STATUS "

    invoke-static/range {v19 .. v20}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 1388
    sget-object v19, Lcom/thinkware/sundo/inavi3d/Inavi;->m_last_ihr_path:Ljava/lang/String;

    if-eqz v19, :cond_9

    .line 1389
    sget-object v19, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    sget-object v20, Lcom/thinkware/sundo/inavi3d/Inavi;->m_last_ihr_path:Ljava/lang/String;

    invoke-interface/range {v19 .. v20}, Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;->setRouteTbl(Ljava/lang/String;)Z

    goto/16 :goto_2

    .line 1418
    :sswitch_12
    invoke-virtual/range {p2 .. p2}, Ljava/lang/String;->length()I

    move-result v19

    if-nez v19, :cond_1c

    .line 1419
    new-instance v19, Ljava/lang/StringBuilder;

    invoke-direct/range {v19 .. v19}, Ljava/lang/StringBuilder;-><init>()V

    sget-object v20, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->kStorageRoot:Ljava/lang/String;

    invoke-virtual/range {v19 .. v20}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v19

    const-string v20, "/inavidata/GPSOnly.txt"

    invoke-virtual/range {v19 .. v20}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v19

    invoke-virtual/range {v19 .. v19}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    .line 1422
    :cond_1c
    sget-object v19, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    move-object/from16 v0, v19

    move-object/from16 v1, p2

    invoke-interface {v0, v1}, Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;->LogDrive(Ljava/lang/String;)I

    goto/16 :goto_2

    .line 1426
    :sswitch_13
    sget-object v19, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    if-eqz v19, :cond_9

    .line 1429
    if-nez p1, :cond_1d

    .line 1430
    sget-object v19, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    invoke-interface/range {v19 .. v19}, Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;->LoggingStop()I

    goto/16 :goto_2

    .line 1432
    :cond_1d
    sget-object v19, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    new-instance v20, Ljava/lang/StringBuilder;

    invoke-direct/range {v20 .. v20}, Ljava/lang/StringBuilder;-><init>()V

    sget-object v21, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->SD_EXT_STORAGE_PATH:Ljava/lang/String;

    invoke-virtual/range {v20 .. v21}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v20

    const-string v21, "/inavi3d/gpslog"

    invoke-virtual/range {v20 .. v21}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v20

    invoke-virtual/range {v20 .. v20}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v20

    invoke-interface/range {v19 .. v20}, Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;->LoggingStart(Ljava/lang/String;)I

    goto/16 :goto_2

    .line 1436
    :sswitch_14
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v19

    const/16 v20, 0x1

    invoke-virtual/range {v19 .. v20}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->SetDRSaveMode(Z)V

    goto/16 :goto_2

    .line 1440
    :sswitch_15
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v19

    const/16 v20, 0x0

    invoke-virtual/range {v19 .. v20}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->SetDRSaveMode(Z)V

    goto/16 :goto_2

    .line 1444
    :sswitch_16
    const/16 v19, 0x1

    move/from16 v0, p1

    move/from16 v1, v19

    if-ne v0, v1, :cond_1e

    .line 1445
    sget-object v19, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v20, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const/16 v21, 0x3e9

    invoke-static/range {v20 .. v21}, Landroid/os/Message;->obtain(Landroid/os/Handler;I)Landroid/os/Message;

    move-result-object v20

    invoke-virtual/range {v19 .. v20}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto/16 :goto_2

    .line 1447
    :cond_1e
    sget-object v19, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v20, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const/16 v21, 0x3ea

    invoke-static/range {v20 .. v21}, Landroid/os/Message;->obtain(Landroid/os/Handler;I)Landroid/os/Message;

    move-result-object v20

    invoke-virtual/range {v19 .. v20}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto/16 :goto_2

    .line 1451
    :sswitch_17
    const/16 v19, 0x1

    move/from16 v0, p1

    move/from16 v1, v19

    if-ne v0, v1, :cond_1f

    .line 1452
    sget-object v19, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v20, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const/16 v21, 0x7d2

    invoke-static/range {v20 .. v21}, Landroid/os/Message;->obtain(Landroid/os/Handler;I)Landroid/os/Message;

    move-result-object v20

    invoke-virtual/range {v19 .. v20}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto/16 :goto_2

    .line 1453
    :cond_1f
    const/16 v19, 0x2

    move/from16 v0, p1

    move/from16 v1, v19

    if-ne v0, v1, :cond_20

    .line 1454
    sget-object v19, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v20, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const/16 v21, 0x7d3

    invoke-static/range {v20 .. v21}, Landroid/os/Message;->obtain(Landroid/os/Handler;I)Landroid/os/Message;

    move-result-object v20

    invoke-virtual/range {v19 .. v20}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto/16 :goto_2

    .line 1455
    :cond_20
    const/16 v19, 0x3

    move/from16 v0, p1

    move/from16 v1, v19

    if-ne v0, v1, :cond_9

    .line 1456
    sget-object v19, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v20, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const/16 v21, 0x7d4

    invoke-static/range {v20 .. v21}, Landroid/os/Message;->obtain(Landroid/os/Handler;I)Landroid/os/Message;

    move-result-object v20

    invoke-virtual/range {v19 .. v20}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto/16 :goto_2

    .line 1460
    :sswitch_18
    const/16 v19, 0x1

    move/from16 v0, p1

    move/from16 v1, v19

    if-ne v0, v1, :cond_21

    .line 1461
    sget-object v19, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v20, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const/16 v21, 0x7d5

    invoke-static/range {v20 .. v21}, Landroid/os/Message;->obtain(Landroid/os/Handler;I)Landroid/os/Message;

    move-result-object v20

    invoke-virtual/range {v19 .. v20}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto/16 :goto_2

    .line 1463
    :cond_21
    sget-object v19, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v20, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const/16 v21, 0x7d6

    invoke-static/range {v20 .. v21}, Landroid/os/Message;->obtain(Landroid/os/Handler;I)Landroid/os/Message;

    move-result-object v20

    invoke-virtual/range {v19 .. v20}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto/16 :goto_2

    .line 1467
    :sswitch_19
    const/16 v19, 0x1

    move/from16 v0, p1

    move/from16 v1, v19

    if-ne v0, v1, :cond_22

    .line 1468
    sget-object v19, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v20, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const/16 v21, 0x7d0

    invoke-static/range {v20 .. v21}, Landroid/os/Message;->obtain(Landroid/os/Handler;I)Landroid/os/Message;

    move-result-object v20

    invoke-virtual/range {v19 .. v20}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto/16 :goto_2

    .line 1470
    :cond_22
    sget-object v19, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v20, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const/16 v21, 0x7d1

    invoke-static/range {v20 .. v21}, Landroid/os/Message;->obtain(Landroid/os/Handler;I)Landroid/os/Message;

    move-result-object v20

    invoke-virtual/range {v19 .. v20}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto/16 :goto_2

    .line 1475
    :sswitch_1a
    sget-object v19, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v20, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const/16 v21, 0x7d8

    invoke-static/range {v20 .. v21}, Landroid/os/Message;->obtain(Landroid/os/Handler;I)Landroid/os/Message;

    move-result-object v20

    invoke-virtual/range {v19 .. v20}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto/16 :goto_2

    .line 1479
    :sswitch_1b
    sget-object v19, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v20, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const/16 v21, 0x7d8

    invoke-static/range {v20 .. v21}, Landroid/os/Message;->obtain(Landroid/os/Handler;I)Landroid/os/Message;

    move-result-object v20

    invoke-virtual/range {v19 .. v20}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto/16 :goto_2

    .line 1482
    :sswitch_1c
    const v19, 0x1fbd5

    move/from16 v0, v19

    move/from16 v1, p1

    if-eq v0, v1, :cond_23

    const v19, 0x1fbd4

    move/from16 v0, v19

    move/from16 v1, p1

    if-eq v0, v1, :cond_23

    const v19, 0x1fbd1

    move/from16 v0, v19

    move/from16 v1, p1

    if-ne v0, v1, :cond_9

    .line 1483
    :cond_23
    sget-object v19, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v20, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    move-object/from16 v0, v20

    move/from16 v1, p1

    invoke-static {v0, v1}, Landroid/os/Message;->obtain(Landroid/os/Handler;I)Landroid/os/Message;

    move-result-object v20

    invoke-virtual/range {v19 .. v20}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto/16 :goto_2

    .line 1486
    :sswitch_1d
    new-instance v10, Landroid/content/Intent;

    invoke-direct {v10}, Landroid/content/Intent;-><init>()V

    .line 1487
    .local v10, "i":Landroid/content/Intent;
    const-string v19, "android.intent.action.MAIN"

    move-object/from16 v0, v19

    invoke-virtual {v10, v0}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    .line 1488
    const-string v19, "android.intent.category.HOME"

    move-object/from16 v0, v19

    invoke-virtual {v10, v0}, Landroid/content/Intent;->addCategory(Ljava/lang/String;)Landroid/content/Intent;

    .line 1489
    sget-object v19, Lcom/thinkware/sundo/inavi3d/Inavi;->mContext:Landroid/content/Context;

    move-object/from16 v0, v19

    invoke-virtual {v0, v10}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    .line 1490
    const-string v19, "twfail"

    new-instance v20, Ljava/lang/StringBuilder;

    invoke-direct/range {v20 .. v20}, Ljava/lang/StringBuilder;-><init>()V

    const-string v21, "not processed : "

    invoke-virtual/range {v20 .. v21}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v20

    move-object/from16 v0, v20

    move/from16 v1, p0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v20

    invoke-virtual/range {v20 .. v20}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v20

    invoke-static/range {v19 .. v20}, Lcom/thinkware/sundo/inavi3d/LOGTW;->d(Ljava/lang/String;Ljava/lang/String;)V

    goto/16 :goto_2

    .line 1494
    .end local v10    # "i":Landroid/content/Intent;
    :sswitch_1e
    const-string v19, "hslee_test"

    const-string v20, "check on server, terms & auth ok - start"

    invoke-static/range {v19 .. v20}, Lcom/thinkware/sundo/inavi3d/LOGTW;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 1495
    const/4 v7, 0x0

    .line 1496
    .local v7, "apiianvi":Lcom/thinkware/sundo/inavi3d/ApiInavi;
    new-instance v7, Lcom/thinkware/sundo/inavi3d/ApiInavi;

    .end local v7    # "apiianvi":Lcom/thinkware/sundo/inavi3d/ApiInavi;
    sget-object v19, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->kStorageRoot:Ljava/lang/String;

    move-object/from16 v0, v19

    invoke-direct {v7, v0}, Lcom/thinkware/sundo/inavi3d/ApiInavi;-><init>(Ljava/lang/String;)V

    .line 1498
    .restart local v7    # "apiianvi":Lcom/thinkware/sundo/inavi3d/ApiInavi;
    invoke-virtual {v7}, Lcom/thinkware/sundo/inavi3d/ApiInavi;->setUser()I

    move-result v16

    .line 1499
    const-string v19, "hslee_test"

    const-string v20, "check on server, terms & auth ok - end"

    invoke-static/range {v19 .. v20}, Lcom/thinkware/sundo/inavi3d/LOGTW;->d(Ljava/lang/String;Ljava/lang/String;)V

    move/from16 v17, v16

    .line 1500
    .end local v16    # "ret":I
    .restart local v17    # "ret":I
    goto/16 :goto_0

    .line 1502
    .end local v7    # "apiianvi":Lcom/thinkware/sundo/inavi3d/ApiInavi;
    .end local v17    # "ret":I
    .restart local v16    # "ret":I
    :sswitch_1f
    sget-object v19, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v20, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const/16 v21, 0x270f

    invoke-static/range {v20 .. v21}, Landroid/os/Message;->obtain(Landroid/os/Handler;I)Landroid/os/Message;

    move-result-object v20

    invoke-virtual/range {v19 .. v20}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto/16 :goto_2

    .line 1505
    :sswitch_20
    sget-object v19, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v20, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const v21, 0x1d4c2

    invoke-static/range {v20 .. v21}, Landroid/os/Message;->obtain(Landroid/os/Handler;I)Landroid/os/Message;

    move-result-object v20

    invoke-virtual/range {v19 .. v20}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto/16 :goto_2

    .line 1509
    :sswitch_21
    sget-object v19, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v20, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const v21, 0x1d4c5

    const/16 v22, 0x0

    move-object/from16 v0, v20

    move/from16 v1, v21

    move/from16 v2, p1

    move/from16 v3, v22

    invoke-static {v0, v1, v2, v3}, Landroid/os/Message;->obtain(Landroid/os/Handler;III)Landroid/os/Message;

    move-result-object v20

    invoke-virtual/range {v19 .. v20}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z
    :try_end_1
    .catch Landroid/os/RemoteException; {:try_start_1 .. :try_end_1} :catch_0

    goto/16 :goto_2

    .line 1194
    nop

    :sswitch_data_0
    .sparse-switch
        0x1388 -> :sswitch_3
        0x138a -> :sswitch_f
        0x138b -> :sswitch_10
        0x138c -> :sswitch_11
        0x1771 -> :sswitch_12
        0x1772 -> :sswitch_1
        0x1773 -> :sswitch_13
        0x1774 -> :sswitch_2
        0x1775 -> :sswitch_14
        0x1776 -> :sswitch_15
        0x1b58 -> :sswitch_16
        0x1b59 -> :sswitch_19
        0x1b5a -> :sswitch_17
        0x1b5b -> :sswitch_18
        0x1b5c -> :sswitch_1a
        0x1b5d -> :sswitch_1b
        0x1b5e -> :sswitch_0
        0x1b60 -> :sswitch_1d
        0x1d4c -> :sswitch_1e
        0x2329 -> :sswitch_4
        0x232e -> :sswitch_5
        0x232f -> :sswitch_6
        0x2330 -> :sswitch_9
        0x2331 -> :sswitch_a
        0x2332 -> :sswitch_b
        0x2333 -> :sswitch_c
        0x2334 -> :sswitch_7
        0x2335 -> :sswitch_d
        0x2336 -> :sswitch_e
        0x270f -> :sswitch_1f
        0x1d4c2 -> :sswitch_20
        0x1d4c5 -> :sswitch_21
        0x1fbd0 -> :sswitch_1c
        0x22348 -> :sswitch_8
    .end sparse-switch
.end method

.method static SetGPSData(IIIII)V
    .locals 6
    .param p0, "angle"    # I
    .param p1, "gpsscore"    # I
    .param p2, "viewtype"    # I
    .param p3, "viewtypeSecond"    # I
    .param p4, "dualview"    # I

    .prologue
    .line 1025
    sget-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->mUIManager:Lcom/thinkware/sundo/inavi3d/UIManager;

    if-eqz v0, :cond_0

    .line 1026
    sget-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->mUIManager:Lcom/thinkware/sundo/inavi3d/UIManager;

    move v1, p0

    move v2, p1

    move v3, p2

    move v4, p3

    move v5, p4

    invoke-virtual/range {v0 .. v5}, Lcom/thinkware/sundo/inavi3d/UIManager;->SetGPSData(IIIII)V

    .line 1029
    :cond_0
    return-void
.end method

.method static SetLastDpCoordinate(III)V
    .locals 3
    .param p0, "nX"    # I
    .param p1, "nY"    # I
    .param p2, "nCarAngle"    # I

    .prologue
    .line 533
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    if-eqz v1, :cond_0

    .line 535
    :try_start_0
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    invoke-interface {v1, p0, p1, p2}, Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;->SetLastDpCoordinate(III)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    .line 542
    :goto_0
    return-void

    .line 536
    :catch_0
    move-exception v0

    .line 537
    .local v0, "e":Landroid/os/RemoteException;
    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    goto :goto_0

    .line 540
    .end local v0    # "e":Landroid/os/RemoteException;
    :cond_0
    const-string v1, "inavi3d_hslee"

    const-string v2, "SetLastDpCoordinate, (JAVA) mRouteBinder is null"

    invoke-static {v1, v2}, Lcom/thinkware/sundo/inavi3d/LOGTW;->d(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_0
.end method

.method public static native SetMapScene()V
.end method

.method static SetTBTGuide()V
    .locals 29

    .prologue
    .line 545
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    if-nez v5, :cond_1

    .line 945
    .local v4, "bHideTurnAndDirInfoView":Z
    .local v12, "bRunningLaneAndTurn":Z
    .local v16, "guide":Lcom/thinkware/sundo/remoteTBT/TBTGuide;
    .local v20, "nLaneAndTurnMode":I
    :cond_0
    :goto_0
    return-void

    .line 548
    .end local v4    # "bHideTurnAndDirInfoView":Z
    .end local v12    # "bRunningLaneAndTurn":Z
    .end local v16    # "guide":Lcom/thinkware/sundo/remoteTBT/TBTGuide;
    .end local v20    # "nLaneAndTurnMode":I
    :cond_1
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    move-result-object v5

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->isReadyDPMap()Z

    move-result v5

    if-eqz v5, :cond_0

    .line 551
    sget-boolean v5, Lcom/thinkware/sundo/inavi3d/Inavi;->firstTBTGuide:Z

    if-eqz v5, :cond_2

    .line 553
    const-string v5, "inavi3d_java"

    const-string v6, "firstTBTGuide"

    invoke-static {v5, v6}, Lcom/thinkware/sundo/inavi3d/LOGTW;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 555
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v6, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const v7, 0x1d4c6

    invoke-static {v6, v7}, Landroid/os/Message;->obtain(Landroid/os/Handler;I)Landroid/os/Message;

    move-result-object v6

    invoke-virtual {v5, v6}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    .line 556
    const/4 v5, 0x0

    sput-boolean v5, Lcom/thinkware/sundo/inavi3d/Inavi;->firstTBTGuide:Z

    .line 559
    :cond_2
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/Inavi;->getTbtguide()Lcom/thinkware/sundo/remoteTBT/TBTGuide;

    move-result-object v5

    invoke-static {v5}, Lcom/thinkware/sundo/inavi3d/Inavi;->GetTBTGuide(Lcom/thinkware/sundo/remoteTBT/TBTGuide;)Lcom/thinkware/sundo/remoteTBT/TBTGuide;

    move-result-object v5

    invoke-static {v5}, Lcom/thinkware/sundo/inavi3d/Inavi;->setTbtguide(Lcom/thinkware/sundo/remoteTBT/TBTGuide;)V

    .line 560
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/Inavi;->GetViaStatus()Z

    move-result v5

    sput-boolean v5, Lcom/thinkware/sundo/inavi3d/Inavi;->viaStatus:Z

    .line 566
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v5

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->isSimulationMode()Z

    move-result v5

    if-eqz v5, :cond_1b

    .line 567
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v5

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/Inavi;->getTbtguide()Lcom/thinkware/sundo/remoteTBT/TBTGuide;

    move-result-object v6

    iget v6, v6, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->road_type:I

    invoke-virtual {v5, v6}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->IsHighwayRoadType(I)Z

    move-result v5

    if-eqz v5, :cond_1a

    .line 568
    sget v5, Lcom/thinkware/sundo/inavi3d/DeviceState;->SLEEP_NORMAL:I

    invoke-static {v5}, Lcom/thinkware/sundo/inavi3d/DeviceState;->setSleepTime(I)V

    .line 576
    :goto_1
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->speedview:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SpeedView;

    if-nez v5, :cond_3

    .line 577
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/Inavi;->setUI()V

    .line 579
    :cond_3
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    move-result-object v5

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->isCurrentFlag()Z

    move-result v5

    if-nez v5, :cond_4

    .line 581
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->btnLocalName:Landroid/widget/Button;

    if-eqz v5, :cond_4

    .line 583
    const/16 v25, 0x0

    .line 585
    .local v25, "strRoadName":Ljava/lang/String;
    :try_start_0
    new-instance v5, Ljava/lang/String;

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/Inavi;->getTbtguide()Lcom/thinkware/sundo/remoteTBT/TBTGuide;

    move-result-object v6

    iget-object v6, v6, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->roadNm:[B

    const-string v7, "EUC-KR"

    invoke-direct {v5, v6, v7}, Ljava/lang/String;-><init>([BLjava/lang/String;)V

    invoke-virtual {v5}, Ljava/lang/String;->trim()Ljava/lang/String;
    :try_end_0
    .catch Ljava/io/UnsupportedEncodingException; {:try_start_0 .. :try_end_0} :catch_1

    move-result-object v25

    .line 590
    :goto_2
    move-object/from16 v21, v25

    .line 591
    .local v21, "name":Ljava/lang/String;
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->btnLocalName:Landroid/widget/Button;

    new-instance v6, Lcom/thinkware/sundo/inavi3d/Inavi$2;

    move-object/from16 v0, v21

    invoke-direct {v6, v0}, Lcom/thinkware/sundo/inavi3d/Inavi$2;-><init>(Ljava/lang/String;)V

    invoke-virtual {v5, v6}, Landroid/widget/Button;->post(Ljava/lang/Runnable;)Z

    .line 601
    :cond_4
    const/4 v12, 0x0

    .line 602
    .restart local v12    # "bRunningLaneAndTurn":Z
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->m_LaneTurnModeLayout:Landroid/widget/LinearLayout;

    .end local v21    # "name":Ljava/lang/String;
    .end local v25    # "strRoadName":Ljava/lang/String;
    if-eqz v5, :cond_5

    .line 603
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->m_LaneTurnModeLayout:Landroid/widget/LinearLayout;

    invoke-virtual {v5}, Landroid/widget/LinearLayout;->getVisibility()I

    move-result v5

    if-nez v5, :cond_1c

    const/4 v12, 0x1

    .line 604
    :cond_5
    :goto_3
    const/16 v20, -0x1

    .line 605
    .restart local v20    # "nLaneAndTurnMode":I
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->getInstance()Lcom/thinkware/sundo/inavi3d/InaviConfig;

    move-result-object v5

    if-eqz v5, :cond_6

    .line 606
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->getInstance()Lcom/thinkware/sundo/inavi3d/InaviConfig;

    move-result-object v5

    const/16 v6, 0x118

    invoke-virtual {v5, v6}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->CNaviConfigGet(I)I

    move-result v20

    .line 608
    :cond_6
    if-eqz v12, :cond_1d

    const/4 v5, 0x2

    move/from16 v0, v20

    if-eq v0, v5, :cond_7

    if-nez v20, :cond_1d

    :cond_7
    const/4 v4, 0x1

    .line 610
    .restart local v4    # "bHideTurnAndDirInfoView":Z
    :goto_4
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/Inavi;->getTbtguide()Lcom/thinkware/sundo/remoteTBT/TBTGuide;

    move-result-object v5

    if-eqz v5, :cond_19

    .line 612
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->speedview:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SpeedView;

    if-eqz v5, :cond_8

    .line 613
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->speedview:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SpeedView;

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/Inavi;->getTbtguide()Lcom/thinkware/sundo/remoteTBT/TBTGuide;

    move-result-object v6

    invoke-virtual {v5, v6}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SpeedView;->setUpdate(Lcom/thinkware/sundo/remoteTBT/TBTGuide;)V

    .line 614
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->speedview:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SpeedView;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SpeedView;->postInvalidate()V

    .line 617
    :cond_8
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->courseView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/DriveCourseView;

    if-eqz v5, :cond_9

    .line 618
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->courseView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/DriveCourseView;

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/Inavi;->getTbtguide()Lcom/thinkware/sundo/remoteTBT/TBTGuide;

    move-result-object v6

    invoke-virtual {v5, v6}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/DriveCourseView;->setUpdate(Lcom/thinkware/sundo/remoteTBT/TBTGuide;)V

    .line 619
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->courseView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/DriveCourseView;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/DriveCourseView;->postInvalidate()V

    .line 622
    :cond_9
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->driveLineView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/LaneInfoView;

    if-eqz v5, :cond_a

    .line 623
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->driveLineView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/LaneInfoView;

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/Inavi;->getTbtguide()Lcom/thinkware/sundo/remoteTBT/TBTGuide;

    move-result-object v6

    invoke-virtual {v5, v6}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/LaneInfoView;->setUpdate(Lcom/thinkware/sundo/remoteTBT/TBTGuide;)V

    .line 624
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->driveLineView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/LaneInfoView;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/LaneInfoView;->postInvalidate()V

    .line 627
    :cond_a
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;

    if-eqz v5, :cond_b

    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneLayout:Landroid/widget/RelativeLayout;

    if-eqz v5, :cond_b

    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->sectionView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;

    if-eqz v5, :cond_b

    .line 628
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/Inavi;->getTbtguide()Lcom/thinkware/sundo/remoteTBT/TBTGuide;

    move-result-object v6

    invoke-virtual {v5, v6}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;->setUpdate(Lcom/thinkware/sundo/remoteTBT/TBTGuide;)Z

    move-result v5

    if-eqz v5, :cond_1f

    .line 629
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneLayout:Landroid/widget/RelativeLayout;

    const/4 v6, 0x0

    invoke-static {v5, v6}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    .line 630
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;

    const/4 v6, 0x1

    invoke-virtual {v5, v6}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;->setClickable(Z)V

    .line 631
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;->getSafeZone()Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZone;

    move-result-object v22

    .line 632
    .local v22, "sfZone":Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZone;
    invoke-virtual/range {v22 .. v22}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZone;->getSafeSection()Z

    move-result v5

    if-eqz v5, :cond_1e

    .line 633
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->sectionView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/Inavi;->getTbtguide()Lcom/thinkware/sundo/remoteTBT/TBTGuide;

    move-result-object v6

    move-object/from16 v0, v22

    invoke-virtual {v5, v0, v6}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;->SetSectionData(Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZone;Lcom/thinkware/sundo/remoteTBT/TBTGuide;)V

    .line 634
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->sectionView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;

    const/4 v6, 0x0

    invoke-static {v5, v6}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    .line 635
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->sectionView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;

    const/4 v6, 0x1

    invoke-virtual {v5, v6}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;->setClickable(Z)V

    .line 648
    .end local v22    # "sfZone":Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZone;
    :cond_b
    :goto_5
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->turnAreaView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;

    if-eqz v5, :cond_c

    .line 649
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->turnAreaView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;

    sget-boolean v6, Lcom/thinkware/sundo/inavi3d/Inavi;->viaStatus:Z

    invoke-virtual {v5, v6}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;->setViaStatus(Z)V

    .line 650
    sget-boolean v5, Lcom/thinkware/sundo/inavi3d/Inavi;->viaStatus:Z

    if-eqz v5, :cond_20

    .line 651
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->turnAreaView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/Inavi;->getTbtguide()Lcom/thinkware/sundo/remoteTBT/TBTGuide;

    move-result-object v6

    invoke-virtual {v5, v6}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;->SetViaJump(Lcom/thinkware/sundo/remoteTBT/TBTGuide;)V

    .line 652
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->turnAreaView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;

    const/4 v6, 0x0

    invoke-static {v5, v6}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    .line 653
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->turnAreaView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;

    const/4 v6, 0x1

    invoke-virtual {v5, v6}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;->setClickable(Z)V

    .line 665
    :cond_c
    :goto_6
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->getInstance()Lcom/thinkware/sundo/inavi3d/InaviConfig;

    move-result-object v5

    const/16 v6, 0x79

    invoke-virtual {v5, v6}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->CNaviConfigGet(I)I

    move-result v5

    if-nez v5, :cond_22

    .line 666
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->crossWayView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/CrossWayView;

    const/16 v6, 0x8

    invoke-static {v5, v6}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    .line 698
    :cond_d
    :goto_7
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->speedview2:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SpeedView;

    if-eqz v5, :cond_e

    .line 699
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->speedview2:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SpeedView;

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/Inavi;->getTbtguide()Lcom/thinkware/sundo/remoteTBT/TBTGuide;

    move-result-object v6

    invoke-virtual {v5, v6}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SpeedView;->setUpdate(Lcom/thinkware/sundo/remoteTBT/TBTGuide;)V

    .line 700
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->speedview2:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SpeedView;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SpeedView;->postInvalidate()V

    .line 703
    :cond_e
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneView2:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;

    if-eqz v5, :cond_f

    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneLayout2:Landroid/widget/RelativeLayout;

    if-eqz v5, :cond_f

    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->sectionView2:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;

    if-eqz v5, :cond_f

    .line 704
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneView2:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/Inavi;->getTbtguide()Lcom/thinkware/sundo/remoteTBT/TBTGuide;

    move-result-object v6

    invoke-virtual {v5, v6}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;->setUpdate(Lcom/thinkware/sundo/remoteTBT/TBTGuide;)Z

    move-result v5

    if-eqz v5, :cond_27

    .line 705
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneLayout2:Landroid/widget/RelativeLayout;

    const/4 v6, 0x0

    invoke-static {v5, v6}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    .line 706
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneView2:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;

    const/4 v6, 0x1

    invoke-virtual {v5, v6}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;->setClickable(Z)V

    .line 707
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneView2:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;->getSafeZone()Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZone;

    move-result-object v22

    .line 708
    .restart local v22    # "sfZone":Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZone;
    invoke-virtual/range {v22 .. v22}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZone;->getSafeSection()Z

    move-result v5

    if-eqz v5, :cond_26

    .line 709
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->sectionView2:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/Inavi;->getTbtguide()Lcom/thinkware/sundo/remoteTBT/TBTGuide;

    move-result-object v6

    move-object/from16 v0, v22

    invoke-virtual {v5, v0, v6}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;->SetSectionData(Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZone;Lcom/thinkware/sundo/remoteTBT/TBTGuide;)V

    .line 710
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->sectionView2:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;

    const/4 v6, 0x0

    invoke-static {v5, v6}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    .line 711
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->sectionView2:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;

    const/4 v6, 0x1

    invoke-virtual {v5, v6}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;->setClickable(Z)V

    .line 725
    .end local v22    # "sfZone":Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZone;
    :cond_f
    :goto_8
    const/4 v13, 0x0

    .line 727
    .local v13, "bTrunViewIsShwing":Z
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->turnAreaView2:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;

    if-eqz v5, :cond_10

    .line 728
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->turnAreaView2:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;

    sget-boolean v6, Lcom/thinkware/sundo/inavi3d/Inavi;->viaStatus:Z

    invoke-virtual {v5, v6}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;->setViaStatus(Z)V

    .line 729
    sget-boolean v5, Lcom/thinkware/sundo/inavi3d/Inavi;->viaStatus:Z

    if-eqz v5, :cond_28

    .line 730
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->turnAreaView2:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/Inavi;->getTbtguide()Lcom/thinkware/sundo/remoteTBT/TBTGuide;

    move-result-object v6

    invoke-virtual {v5, v6}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;->SetViaJump(Lcom/thinkware/sundo/remoteTBT/TBTGuide;)V

    .line 731
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->turnAreaView2:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;

    const/4 v6, 0x0

    invoke-static {v5, v6}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    .line 732
    const/4 v13, 0x1

    .line 733
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->turnAreaView2:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;

    const/4 v6, 0x1

    invoke-virtual {v5, v6}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;->setClickable(Z)V

    .line 747
    :cond_10
    :goto_9
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->getInstance()Lcom/thinkware/sundo/inavi3d/InaviConfig;

    move-result-object v5

    const/16 v6, 0x79

    invoke-virtual {v5, v6}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->CNaviConfigGet(I)I

    move-result v5

    if-nez v5, :cond_2a

    .line 748
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->crossWayView2:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/CrossWayView;

    const/16 v6, 0x8

    invoke-static {v5, v6}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    .line 771
    :cond_11
    :goto_a
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneView3:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;

    if-eqz v5, :cond_12

    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneLayout3:Landroid/widget/RelativeLayout;

    if-eqz v5, :cond_12

    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->sectionView3:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;

    if-eqz v5, :cond_12

    .line 772
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneView3:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/Inavi;->getTbtguide()Lcom/thinkware/sundo/remoteTBT/TBTGuide;

    move-result-object v6

    invoke-virtual {v5, v6}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;->setUpdate(Lcom/thinkware/sundo/remoteTBT/TBTGuide;)Z

    move-result v5

    if-eqz v5, :cond_2e

    .line 773
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneLayout3:Landroid/widget/RelativeLayout;

    const/4 v6, 0x0

    invoke-static {v5, v6}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    .line 774
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneView3:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;

    const/4 v6, 0x1

    invoke-virtual {v5, v6}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;->setClickable(Z)V

    .line 775
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneView3:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;->getSafeZone()Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZone;

    move-result-object v22

    .line 776
    .restart local v22    # "sfZone":Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZone;
    invoke-virtual/range {v22 .. v22}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZone;->getSafeSection()Z

    move-result v5

    if-eqz v5, :cond_2d

    .line 777
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->sectionView3:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/Inavi;->getTbtguide()Lcom/thinkware/sundo/remoteTBT/TBTGuide;

    move-result-object v6

    move-object/from16 v0, v22

    invoke-virtual {v5, v0, v6}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;->SetSectionData(Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZone;Lcom/thinkware/sundo/remoteTBT/TBTGuide;)V

    .line 778
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->sectionView3:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;

    const/4 v6, 0x0

    invoke-static {v5, v6}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    .line 779
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->sectionView3:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;

    const/4 v6, 0x1

    invoke-virtual {v5, v6}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;->setClickable(Z)V

    .line 792
    .end local v22    # "sfZone":Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZone;
    :cond_12
    :goto_b
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->speedview3:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SpeedView;

    if-eqz v5, :cond_13

    .line 793
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->speedview3:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SpeedView;

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/Inavi;->getTbtguide()Lcom/thinkware/sundo/remoteTBT/TBTGuide;

    move-result-object v6

    invoke-virtual {v5, v6}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SpeedView;->setUpdate(Lcom/thinkware/sundo/remoteTBT/TBTGuide;)V

    .line 794
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->speedview3:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SpeedView;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SpeedView;->postInvalidate()V

    .line 796
    :cond_13
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->getInstance()Lcom/thinkware/sundo/inavi3d/InaviConfig;

    move-result-object v5

    const/16 v6, 0x79

    invoke-virtual {v5, v6}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->CNaviConfigGet(I)I

    move-result v5

    if-nez v5, :cond_2f

    .line 797
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->crossWayView3:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/CrossWayView;

    const/16 v6, 0x8

    invoke-static {v5, v6}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    .line 808
    :cond_14
    :goto_c
    const-string v23, "\uad50\ucc28\ub85c\uba85"

    .line 809
    .local v23, "strCross":Ljava/lang/String;
    const/16 v28, 0x0

    .line 810
    .local v28, "textcolor":I
    const/16 v27, 0x16

    .line 811
    .local v27, "textSize":I
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->crossname:Landroid/widget/Button;

    if-eqz v5, :cond_34

    .line 815
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/Inavi;->getTbtguide()Lcom/thinkware/sundo/remoteTBT/TBTGuide;

    move-result-object v5

    iget-object v5, v5, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->crossDirNm:[B

    const/4 v6, 0x0

    aget-byte v5, v5, v6

    if-nez v5, :cond_31

    .line 816
    const/16 v5, 0x6e

    const/16 v6, 0x6e

    const/16 v7, 0x6e

    invoke-static {v5, v6, v7}, Landroid/graphics/Color;->rgb(III)I

    move-result v28

    .line 817
    move-object/from16 v0, v23

    move/from16 v1, v28

    move/from16 v2, v27

    invoke-static {v0, v1, v2}, Lcom/thinkware/sundo/inavi3d/Inavi;->setCrossNameInfo(Ljava/lang/String;II)V

    .line 862
    :goto_d
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->speedview4:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SpeedView;

    if-eqz v5, :cond_15

    .line 863
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->speedview4:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SpeedView;

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/Inavi;->getTbtguide()Lcom/thinkware/sundo/remoteTBT/TBTGuide;

    move-result-object v6

    invoke-virtual {v5, v6}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SpeedView;->setUpdate(Lcom/thinkware/sundo/remoteTBT/TBTGuide;)V

    .line 864
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->speedview4:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SpeedView;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SpeedView;->postInvalidate()V

    .line 867
    :cond_15
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneView4:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;

    if-eqz v5, :cond_16

    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneLayout4:Landroid/widget/RelativeLayout;

    if-eqz v5, :cond_16

    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->sectionView4:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;

    if-eqz v5, :cond_16

    .line 868
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneView4:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/Inavi;->getTbtguide()Lcom/thinkware/sundo/remoteTBT/TBTGuide;

    move-result-object v6

    invoke-virtual {v5, v6}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;->setUpdate(Lcom/thinkware/sundo/remoteTBT/TBTGuide;)Z

    move-result v5

    if-eqz v5, :cond_36

    .line 869
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneLayout4:Landroid/widget/RelativeLayout;

    const/4 v6, 0x0

    invoke-static {v5, v6}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    .line 870
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneView4:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;

    const/4 v6, 0x1

    invoke-virtual {v5, v6}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;->setClickable(Z)V

    .line 871
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneView4:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;->getSafeZone()Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZone;

    move-result-object v22

    .line 872
    .restart local v22    # "sfZone":Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZone;
    invoke-virtual/range {v22 .. v22}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZone;->getSafeSection()Z

    move-result v5

    if-eqz v5, :cond_35

    .line 873
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->sectionView4:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/Inavi;->getTbtguide()Lcom/thinkware/sundo/remoteTBT/TBTGuide;

    move-result-object v6

    move-object/from16 v0, v22

    invoke-virtual {v5, v0, v6}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;->SetSectionData(Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZone;Lcom/thinkware/sundo/remoteTBT/TBTGuide;)V

    .line 874
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->sectionView4:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;

    const/4 v6, 0x0

    invoke-static {v5, v6}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    .line 875
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->sectionView4:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;

    const/4 v6, 0x1

    invoke-virtual {v5, v6}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;->setClickable(Z)V

    .line 889
    .end local v22    # "sfZone":Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZone;
    :cond_16
    :goto_e
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->turnAreaView4:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;

    if-eqz v5, :cond_17

    .line 890
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->turnAreaView4:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;

    sget-boolean v6, Lcom/thinkware/sundo/inavi3d/Inavi;->viaStatus:Z

    invoke-virtual {v5, v6}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;->setViaStatus(Z)V

    .line 891
    sget-boolean v5, Lcom/thinkware/sundo/inavi3d/Inavi;->viaStatus:Z

    if-eqz v5, :cond_37

    .line 892
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->turnAreaView4:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/Inavi;->getTbtguide()Lcom/thinkware/sundo/remoteTBT/TBTGuide;

    move-result-object v6

    invoke-virtual {v5, v6}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;->SetViaJump(Lcom/thinkware/sundo/remoteTBT/TBTGuide;)V

    .line 893
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->turnAreaView4:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;

    const/4 v6, 0x0

    invoke-static {v5, v6}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    .line 894
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->turnAreaView4:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;

    const/4 v6, 0x1

    invoke-virtual {v5, v6}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;->setClickable(Z)V

    .line 906
    :cond_17
    :goto_f
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->getInstance()Lcom/thinkware/sundo/inavi3d/InaviConfig;

    move-result-object v5

    const/16 v6, 0x79

    invoke-virtual {v5, v6}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->CNaviConfigGet(I)I

    move-result v5

    if-nez v5, :cond_39

    .line 907
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->crossWayView4:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/CrossWayView;

    const/16 v6, 0x8

    invoke-static {v5, v6}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    .line 932
    :cond_18
    :goto_10
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->mGPSViewMgr:Lcom/thinkware/sundo/inavi3d/GPSViewManager;

    if-eqz v5, :cond_19

    .line 933
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->mGPSViewMgr:Lcom/thinkware/sundo/inavi3d/GPSViewManager;

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/Inavi;->getTbtguide()Lcom/thinkware/sundo/remoteTBT/TBTGuide;

    move-result-object v6

    sget-object v7, Lcom/thinkware/sundo/inavi3d/Inavi;->mMMCInfo:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    iget-short v7, v7, Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;->heading:S

    sget-object v8, Lcom/thinkware/sundo/inavi3d/Inavi;->mMMCInfo:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    iget v8, v8, Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;->lon:I

    int-to-long v8, v8

    sget-object v10, Lcom/thinkware/sundo/inavi3d/Inavi;->mMMCInfo:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    iget v10, v10, Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;->lat:I

    int-to-long v10, v10

    invoke-virtual/range {v5 .. v11}, Lcom/thinkware/sundo/inavi3d/GPSViewManager;->setUpdate(Lcom/thinkware/sundo/remoteTBT/TBTGuide;SJJ)V

    .line 936
    .end local v13    # "bTrunViewIsShwing":Z
    .end local v23    # "strCross":Ljava/lang/String;
    .end local v27    # "textSize":I
    .end local v28    # "textcolor":I
    :cond_19
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/Inavi;->getTbtguide()Lcom/thinkware/sundo/remoteTBT/TBTGuide;

    move-result-object v16

    .line 939
    .restart local v16    # "guide":Lcom/thinkware/sundo/remoteTBT/TBTGuide;
    :try_start_1
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    move-object/from16 v0, v16

    invoke-interface {v5, v0}, Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;->SetTBTGuide(Lcom/thinkware/sundo/remoteTBT/TBTGuide;)V
    :try_end_1
    .catch Landroid/os/RemoteException; {:try_start_1 .. :try_end_1} :catch_0

    goto/16 :goto_0

    .line 940
    :catch_0
    move-exception v15

    .line 942
    .local v15, "e":Landroid/os/RemoteException;
    invoke-virtual {v15}, Landroid/os/RemoteException;->printStackTrace()V

    goto/16 :goto_0

    .line 570
    .end local v4    # "bHideTurnAndDirInfoView":Z
    .end local v12    # "bRunningLaneAndTurn":Z
    .end local v15    # "e":Landroid/os/RemoteException;
    .end local v16    # "guide":Lcom/thinkware/sundo/remoteTBT/TBTGuide;
    .end local v20    # "nLaneAndTurnMode":I
    :cond_1a
    sget v5, Lcom/thinkware/sundo/inavi3d/DeviceState;->SLEEP_SHORT:I

    invoke-static {v5}, Lcom/thinkware/sundo/inavi3d/DeviceState;->setSleepTime(I)V

    goto/16 :goto_1

    .line 573
    :cond_1b
    sget v5, Lcom/thinkware/sundo/inavi3d/DeviceState;->SLEEP_NORMAL:I

    invoke-static {v5}, Lcom/thinkware/sundo/inavi3d/DeviceState;->setSleepTime(I)V

    goto/16 :goto_1

    .line 586
    .restart local v25    # "strRoadName":Ljava/lang/String;
    :catch_1
    move-exception v15

    .line 588
    .local v15, "e":Ljava/io/UnsupportedEncodingException;
    invoke-virtual {v15}, Ljava/io/UnsupportedEncodingException;->printStackTrace()V

    goto/16 :goto_2

    .line 603
    .end local v15    # "e":Ljava/io/UnsupportedEncodingException;
    .end local v25    # "strRoadName":Ljava/lang/String;
    .restart local v12    # "bRunningLaneAndTurn":Z
    :cond_1c
    const/4 v12, 0x0

    goto/16 :goto_3

    .line 608
    .restart local v20    # "nLaneAndTurnMode":I
    :cond_1d
    const/4 v4, 0x0

    goto/16 :goto_4

    .line 637
    .restart local v4    # "bHideTurnAndDirInfoView":Z
    .restart local v22    # "sfZone":Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZone;
    :cond_1e
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->sectionView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;

    const/4 v6, 0x4

    invoke-static {v5, v6}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    .line 638
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->sectionView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;

    const/4 v6, 0x0

    invoke-virtual {v5, v6}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;->setClickable(Z)V

    goto/16 :goto_5

    .line 642
    .end local v22    # "sfZone":Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZone;
    :cond_1f
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneLayout:Landroid/widget/RelativeLayout;

    const/4 v6, 0x4

    invoke-static {v5, v6}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    .line 643
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;

    const/4 v6, 0x0

    invoke-virtual {v5, v6}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;->setClickable(Z)V

    .line 644
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->sectionView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;

    const/4 v6, 0x0

    invoke-virtual {v5, v6}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;->setClickable(Z)V

    goto/16 :goto_5

    .line 656
    :cond_20
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->turnAreaView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/Inavi;->getTbtguide()Lcom/thinkware/sundo/remoteTBT/TBTGuide;

    move-result-object v6

    invoke-virtual {v5, v6}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;->setUpdate(Lcom/thinkware/sundo/remoteTBT/TBTGuide;)Z

    move-result v5

    if-eqz v5, :cond_21

    .line 657
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->turnAreaView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;

    const/4 v6, 0x0

    invoke-static {v5, v6}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    .line 658
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->turnAreaView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;

    const/4 v6, 0x1

    invoke-virtual {v5, v6}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;->setClickable(Z)V

    goto/16 :goto_6

    .line 660
    :cond_21
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->turnAreaView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;

    const/4 v6, 0x4

    invoke-static {v5, v6}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    .line 661
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->turnAreaView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;

    const/4 v6, 0x0

    invoke-virtual {v5, v6}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;->setClickable(Z)V

    goto/16 :goto_6

    .line 668
    :cond_22
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->crossWayView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/CrossWayView;

    if-eqz v5, :cond_d

    .line 669
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->crossWayView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/CrossWayView;

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/Inavi;->getTbtguide()Lcom/thinkware/sundo/remoteTBT/TBTGuide;

    move-result-object v6

    invoke-virtual {v5, v6}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/CrossWayView;->setUpdate(Lcom/thinkware/sundo/remoteTBT/TBTGuide;)Z

    move-result v5

    if-eqz v5, :cond_25

    .line 671
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->mContext:Landroid/content/Context;

    invoke-virtual {v5}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v5

    const v6, 0x7f090051

    invoke-virtual {v5, v6}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    move-result v26

    .line 672
    .local v26, "temp":I
    move/from16 v0, v26

    add-int/lit16 v0, v0, 0x87

    move/from16 v26, v0

    .line 673
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->turnAreaView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;->getVisibility()I

    move-result v5

    if-eqz v5, :cond_23

    sget-boolean v5, Lcom/thinkware/sundo/inavi3d/Inavi;->viaStatus:Z

    if-eqz v5, :cond_24

    .line 674
    :cond_23
    move/from16 v0, v26

    add-int/lit16 v0, v0, -0x87

    move/from16 v26, v0

    .line 678
    :cond_24
    move/from16 v14, v26

    .line 679
    .local v14, "crossWayWidth":I
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->crossWayView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/CrossWayView;

    new-instance v6, Lcom/thinkware/sundo/inavi3d/Inavi$3;

    invoke-direct {v6, v14}, Lcom/thinkware/sundo/inavi3d/Inavi$3;-><init>(I)V

    invoke-virtual {v5, v6}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/CrossWayView;->post(Ljava/lang/Runnable;)Z

    .line 689
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->crossWayView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/CrossWayView;

    const/4 v6, 0x0

    invoke-static {v5, v6}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    goto/16 :goto_7

    .line 692
    .end local v14    # "crossWayWidth":I
    .end local v26    # "temp":I
    :cond_25
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->crossWayView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/CrossWayView;

    const/16 v6, 0x8

    invoke-static {v5, v6}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    goto/16 :goto_7

    .line 713
    .restart local v22    # "sfZone":Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZone;
    :cond_26
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->sectionView2:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;

    const/4 v6, 0x4

    invoke-static {v5, v6}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    .line 714
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->sectionView2:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;

    const/4 v6, 0x0

    invoke-virtual {v5, v6}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;->setClickable(Z)V

    goto/16 :goto_8

    .line 718
    .end local v22    # "sfZone":Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZone;
    :cond_27
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneLayout2:Landroid/widget/RelativeLayout;

    const/4 v6, 0x4

    invoke-static {v5, v6}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    .line 719
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneView2:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;

    const/4 v6, 0x0

    invoke-virtual {v5, v6}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;->setClickable(Z)V

    .line 720
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->sectionView2:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;

    const/4 v6, 0x0

    invoke-virtual {v5, v6}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;->setClickable(Z)V

    goto/16 :goto_8

    .line 736
    .restart local v13    # "bTrunViewIsShwing":Z
    :cond_28
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->turnAreaView2:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/Inavi;->getTbtguide()Lcom/thinkware/sundo/remoteTBT/TBTGuide;

    move-result-object v6

    invoke-virtual {v5, v6}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;->setUpdate(Lcom/thinkware/sundo/remoteTBT/TBTGuide;)Z

    move-result v5

    if-eqz v5, :cond_29

    if-nez v4, :cond_29

    .line 737
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->turnAreaView2:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;

    const/4 v6, 0x0

    invoke-static {v5, v6}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    .line 738
    const/4 v13, 0x1

    .line 739
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->turnAreaView2:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;

    const/4 v6, 0x1

    invoke-virtual {v5, v6}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;->setClickable(Z)V

    goto/16 :goto_9

    .line 741
    :cond_29
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->turnAreaView2:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;

    const/4 v6, 0x4

    invoke-static {v5, v6}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    .line 742
    const/4 v13, 0x0

    .line 743
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->turnAreaView2:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;

    const/4 v6, 0x0

    invoke-virtual {v5, v6}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;->setClickable(Z)V

    goto/16 :goto_9

    .line 750
    :cond_2a
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->crossWayView2:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/CrossWayView;

    if-eqz v5, :cond_11

    .line 751
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->crossWayView2:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/CrossWayView;

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/Inavi;->getTbtguide()Lcom/thinkware/sundo/remoteTBT/TBTGuide;

    move-result-object v6

    invoke-virtual {v5, v6}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/CrossWayView;->setUpdate(Lcom/thinkware/sundo/remoteTBT/TBTGuide;)Z

    move-result v5

    if-eqz v5, :cond_2c

    if-nez v4, :cond_2c

    .line 752
    const/16 v26, 0x154

    .line 753
    .restart local v26    # "temp":I
    if-eqz v13, :cond_2b

    .line 754
    const/16 v26, 0xcc

    .line 755
    :cond_2b
    move/from16 v17, v26

    .line 756
    .local v17, "left":I
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->crossWayView2:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/CrossWayView;

    new-instance v6, Lcom/thinkware/sundo/inavi3d/Inavi$4;

    move/from16 v0, v17

    invoke-direct {v6, v0}, Lcom/thinkware/sundo/inavi3d/Inavi$4;-><init>(I)V

    invoke-virtual {v5, v6}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/CrossWayView;->post(Ljava/lang/Runnable;)Z

    .line 764
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->crossWayView2:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/CrossWayView;

    const/4 v6, 0x0

    invoke-static {v5, v6}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    goto/16 :goto_a

    .line 767
    .end local v17    # "left":I
    .end local v26    # "temp":I
    :cond_2c
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->crossWayView2:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/CrossWayView;

    const/16 v6, 0x8

    invoke-static {v5, v6}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    goto/16 :goto_a

    .line 781
    .restart local v22    # "sfZone":Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZone;
    :cond_2d
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->sectionView3:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;

    const/4 v6, 0x4

    invoke-static {v5, v6}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    .line 782
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->sectionView3:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;

    const/4 v6, 0x0

    invoke-virtual {v5, v6}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;->setClickable(Z)V

    goto/16 :goto_b

    .line 786
    .end local v22    # "sfZone":Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZone;
    :cond_2e
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneLayout3:Landroid/widget/RelativeLayout;

    const/4 v6, 0x4

    invoke-static {v5, v6}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    .line 787
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneView3:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;

    const/4 v6, 0x0

    invoke-virtual {v5, v6}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;->setClickable(Z)V

    .line 788
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->sectionView3:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;

    const/4 v6, 0x0

    invoke-virtual {v5, v6}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;->setClickable(Z)V

    goto/16 :goto_b

    .line 799
    :cond_2f
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->crossWayView3:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/CrossWayView;

    if-eqz v5, :cond_14

    .line 800
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->crossWayView3:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/CrossWayView;

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/Inavi;->getTbtguide()Lcom/thinkware/sundo/remoteTBT/TBTGuide;

    move-result-object v6

    invoke-virtual {v5, v6}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/CrossWayView;->setUpdate(Lcom/thinkware/sundo/remoteTBT/TBTGuide;)Z

    move-result v5

    if-eqz v5, :cond_30

    .line 801
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->crossWayView3:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/CrossWayView;

    const/4 v6, 0x0

    invoke-static {v5, v6}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    goto/16 :goto_c

    .line 803
    :cond_30
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->crossWayView3:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/CrossWayView;

    const/16 v6, 0x8

    invoke-static {v5, v6}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    goto/16 :goto_c

    .line 821
    .restart local v23    # "strCross":Ljava/lang/String;
    .restart local v27    # "textSize":I
    .restart local v28    # "textcolor":I
    :cond_31
    :try_start_2
    new-instance v24, Ljava/lang/String;

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/Inavi;->getTbtguide()Lcom/thinkware/sundo/remoteTBT/TBTGuide;

    move-result-object v5

    iget-object v5, v5, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->crossDirNm:[B

    const-string v6, "EUC-KR"

    move-object/from16 v0, v24

    invoke-direct {v0, v5, v6}, Ljava/lang/String;-><init>([BLjava/lang/String;)V
    :try_end_2
    .catch Ljava/io/UnsupportedEncodingException; {:try_start_2 .. :try_end_2} :catch_2

    .line 822
    .end local v23    # "strCross":Ljava/lang/String;
    .local v24, "strCross":Ljava/lang/String;
    const/16 v19, 0x0

    .line 831
    .local v19, "nEnd":I
    :try_start_3
    invoke-virtual/range {v24 .. v24}, Ljava/lang/String;->trim()Ljava/lang/String;
    :try_end_3
    .catch Ljava/io/UnsupportedEncodingException; {:try_start_3 .. :try_end_3} :catch_3

    move-result-object v23

    .line 840
    .end local v24    # "strCross":Ljava/lang/String;
    .restart local v23    # "strCross":Ljava/lang/String;
    :try_start_4
    invoke-virtual/range {v23 .. v23}, Ljava/lang/String;->length()I

    move-result v18

    .line 841
    .local v18, "len":I
    const/4 v5, 0x6

    move/from16 v0, v18

    if-gt v0, v5, :cond_32

    .line 842
    const/16 v27, 0x16

    .line 850
    :goto_11
    const/16 v5, 0x99

    const/16 v6, 0x91

    const/16 v7, 0x99

    invoke-static {v5, v6, v7}, Landroid/graphics/Color;->rgb(III)I
    :try_end_4
    .catch Ljava/io/UnsupportedEncodingException; {:try_start_4 .. :try_end_4} :catch_2

    move-result v28

    .line 856
    .end local v18    # "len":I
    .end local v19    # "nEnd":I
    :goto_12
    move-object/from16 v0, v23

    move/from16 v1, v28

    move/from16 v2, v27

    invoke-static {v0, v1, v2}, Lcom/thinkware/sundo/inavi3d/Inavi;->setCrossNameInfo(Ljava/lang/String;II)V

    goto/16 :goto_d

    .line 843
    .restart local v18    # "len":I
    .restart local v19    # "nEnd":I
    :cond_32
    const/4 v5, 0x7

    move/from16 v0, v18

    if-ne v0, v5, :cond_33

    .line 844
    const/16 v27, 0x14

    goto :goto_11

    .line 846
    :cond_33
    const/16 v27, 0x14

    .line 847
    :try_start_5
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x0

    const/4 v7, 0x5

    move-object/from16 v0, v23

    invoke-virtual {v0, v6, v7}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v6, "..."

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    :try_end_5
    .catch Ljava/io/UnsupportedEncodingException; {:try_start_5 .. :try_end_5} :catch_2

    move-result-object v23

    goto :goto_11

    .line 852
    .end local v18    # "len":I
    .end local v19    # "nEnd":I
    :catch_2
    move-exception v15

    .line 854
    .restart local v15    # "e":Ljava/io/UnsupportedEncodingException;
    :goto_13
    invoke-virtual {v15}, Ljava/io/UnsupportedEncodingException;->printStackTrace()V

    goto :goto_12

    .line 859
    .end local v15    # "e":Ljava/io/UnsupportedEncodingException;
    :cond_34
    move-object/from16 v0, v23

    move/from16 v1, v28

    move/from16 v2, v27

    invoke-static {v0, v1, v2}, Lcom/thinkware/sundo/inavi3d/Inavi;->setCrossNameInfo(Ljava/lang/String;II)V

    goto/16 :goto_d

    .line 877
    .restart local v22    # "sfZone":Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZone;
    :cond_35
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->sectionView4:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;

    const/4 v6, 0x4

    invoke-static {v5, v6}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    .line 878
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->sectionView4:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;

    const/4 v6, 0x0

    invoke-virtual {v5, v6}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;->setClickable(Z)V

    goto/16 :goto_e

    .line 882
    .end local v22    # "sfZone":Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZone;
    :cond_36
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneLayout4:Landroid/widget/RelativeLayout;

    const/4 v6, 0x4

    invoke-static {v5, v6}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    .line 883
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneView4:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;

    const/4 v6, 0x0

    invoke-virtual {v5, v6}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;->setClickable(Z)V

    .line 884
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->sectionView4:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;

    const/4 v6, 0x0

    invoke-virtual {v5, v6}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;->setClickable(Z)V

    goto/16 :goto_e

    .line 897
    :cond_37
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->turnAreaView4:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/Inavi;->getTbtguide()Lcom/thinkware/sundo/remoteTBT/TBTGuide;

    move-result-object v6

    invoke-virtual {v5, v6}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;->setUpdate(Lcom/thinkware/sundo/remoteTBT/TBTGuide;)Z

    move-result v5

    if-eqz v5, :cond_38

    .line 898
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->turnAreaView4:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;

    const/4 v6, 0x0

    invoke-static {v5, v6}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    .line 899
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->turnAreaView4:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;

    const/4 v6, 0x1

    invoke-virtual {v5, v6}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;->setClickable(Z)V

    goto/16 :goto_f

    .line 901
    :cond_38
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->turnAreaView4:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;

    const/4 v6, 0x4

    invoke-static {v5, v6}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    .line 902
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->turnAreaView4:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;

    const/4 v6, 0x0

    invoke-virtual {v5, v6}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;->setClickable(Z)V

    goto/16 :goto_f

    .line 909
    :cond_39
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->crossWayView4:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/CrossWayView;

    if-eqz v5, :cond_18

    .line 910
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->crossWayView4:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/CrossWayView;

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/Inavi;->getTbtguide()Lcom/thinkware/sundo/remoteTBT/TBTGuide;

    move-result-object v6

    invoke-virtual {v5, v6}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/CrossWayView;->setUpdate(Lcom/thinkware/sundo/remoteTBT/TBTGuide;)Z

    move-result v5

    if-eqz v5, :cond_3b

    .line 911
    const/16 v26, 0x134

    .line 912
    .restart local v26    # "temp":I
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->turnAreaView4:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;->getVisibility()I

    move-result v5

    if-nez v5, :cond_3a

    .line 913
    const/16 v26, 0xae

    .line 914
    :cond_3a
    move/from16 v17, v26

    .line 915
    .restart local v17    # "left":I
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->crossWayView4:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/CrossWayView;

    new-instance v6, Lcom/thinkware/sundo/inavi3d/Inavi$5;

    move/from16 v0, v17

    invoke-direct {v6, v0}, Lcom/thinkware/sundo/inavi3d/Inavi$5;-><init>(I)V

    invoke-virtual {v5, v6}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/CrossWayView;->post(Ljava/lang/Runnable;)Z

    .line 924
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->crossWayView4:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/CrossWayView;

    const/4 v6, 0x0

    invoke-static {v5, v6}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    goto/16 :goto_10

    .line 927
    .end local v17    # "left":I
    .end local v26    # "temp":I
    :cond_3b
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->crossWayView4:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/CrossWayView;

    const/16 v6, 0x8

    invoke-static {v5, v6}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    goto/16 :goto_10

    .line 852
    .end local v23    # "strCross":Ljava/lang/String;
    .restart local v19    # "nEnd":I
    .restart local v24    # "strCross":Ljava/lang/String;
    :catch_3
    move-exception v15

    move-object/from16 v23, v24

    .end local v24    # "strCross":Ljava/lang/String;
    .restart local v23    # "strCross":Ljava/lang/String;
    goto/16 :goto_13
.end method

.method private static SetVisible(Landroid/view/View;I)V
    .locals 1
    .param p0, "view"    # Landroid/view/View;
    .param p1, "Visibility"    # I

    .prologue
    .line 967
    new-instance v0, Lcom/thinkware/sundo/inavi3d/Inavi$7;

    invoke-direct {v0, p0, p1}, Lcom/thinkware/sundo/inavi3d/Inavi$7;-><init>(Landroid/view/View;I)V

    invoke-virtual {p0, v0}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    .line 978
    return-void
.end method

.method public static ShowPopup(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;I)V
    .locals 6
    .param p0, "type"    # I
    .param p1, "id"    # Ljava/lang/String;
    .param p2, "title"    # Ljava/lang/String;
    .param p3, "contents"    # Ljava/lang/String;
    .param p4, "time"    # I

    .prologue
    .line 527
    new-instance v0, Lcom/thinkware/sundo/inavi3d/Struct/PopupData;

    move v1, p0

    move-object v2, p1

    move-object v3, p2

    move-object v4, p3

    move v5, p4

    invoke-direct/range {v0 .. v5}, Lcom/thinkware/sundo/inavi3d/Struct/PopupData;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;I)V

    .line 528
    .local v0, "data":Lcom/thinkware/sundo/inavi3d/Struct/PopupData;
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v2, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const/16 v3, 0xfaa

    invoke-static {v2, v3, v0}, Landroid/os/Message;->obtain(Landroid/os/Handler;ILjava/lang/Object;)Landroid/os/Message;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    .line 529
    return-void
.end method

.method private static native ToggleViewMode(IZ)Z
.end method

.method public static ToggleViewModeSafe(IZ)Z
    .locals 1
    .param p0, "mode"    # I
    .param p1, "bResult"    # Z

    const/4 v0, 0x0

    invoke-static {v0, p1}, Lcom/thinkware/sundo/inavi3d/Inavi;->ToggleViewMode(IZ)Z

    move-result v0

    return v0
.end method

.method public static native UpdateDisConnectedTime()V
.end method

.method public static native UpdatePowerConnectedTime()V
.end method

.method private static _CheckData()I
    .locals 12

    .prologue
    .line 361
    new-instance v0, Lcom/thinkware/sundo/inavi3d/AuthDRM;

    invoke-direct {v0}, Lcom/thinkware/sundo/inavi3d/AuthDRM;-><init>()V

    sput-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->authDrm:Lcom/thinkware/sundo/inavi3d/AuthDRM;

    .line 362
    sget-object v1, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->kStorageRoot:Ljava/lang/String;

    .line 363
    .local v1, "strAppPath":Ljava/lang/String;
    sget-object v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->kMapdataPath:Ljava/lang/String;

    .line 364
    .local v2, "strMapPath":Ljava/lang/String;
    sget-object v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->kMapDataVersion:Ljava/lang/String;

    .line 365
    .local v3, "strMapVer":Ljava/lang/String;
    sget-object v4, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->kInaviVersionName:Ljava/lang/String;

    .line 367
    .local v4, "strAppV":Ljava/lang/String;
    const-string v5, "1417"

    .line 368
    .local v5, "strBuildV":Ljava/lang/String;
    sget-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->authDrm:Lcom/thinkware/sundo/inavi3d/AuthDRM;

    invoke-virtual/range {v0 .. v5}, Lcom/thinkware/sundo/inavi3d/AuthDRM;->Authorize(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v8

    .line 369
    .local v8, "ret":I
    if-nez v8, :cond_0

    .line 370
    sget-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->authDrm:Lcom/thinkware/sundo/inavi3d/AuthDRM;

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/AuthDRM;->GetSDRM4MMC()Ljava/lang/String;

    move-result-object v9

    .line 375
    .local v9, "sdrm4mmc":Ljava/lang/String;
    :try_start_0
    sget-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    invoke-interface {v0, v9}, Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;->SetDRMString(Ljava/lang/String;)Z

    move-result v7

    .line 376
    .local v7, "result":Z
    const-string v0, "hslee_test"

    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    const-string v11, "pass data4mmc. result : "

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10, v7}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v10

    invoke-static {v0, v10}, Lcom/thinkware/sundo/inavi3d/LOGTW;->d(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    .line 382
    .end local v7    # "result":Z
    .end local v9    # "sdrm4mmc":Ljava/lang/String;
    :cond_0
    :goto_0
    return v8

    .line 377
    .restart local v9    # "sdrm4mmc":Ljava/lang/String;
    :catch_0
    move-exception v6

    .line 379
    .local v6, "e":Landroid/os/RemoteException;
    invoke-virtual {v6}, Landroid/os/RemoteException;->printStackTrace()V

    goto :goto_0
.end method

.method public static native checkTimeLock(Ljava/lang/String;)Z
.end method

.method public static native clearToggleViewModeLevel()V
.end method

.method public static native finalMainInit()V
.end method

.method public static native getCurrentRouteOption()I
.end method

.method public static native getMapCenterX()I
.end method

.method public static native getMapCenterY()I
.end method

.method public static getTbtguide()Lcom/thinkware/sundo/remoteTBT/TBTGuide;
    .locals 1

    .prologue
    .line 1565
    sget-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->tbtguide:Lcom/thinkware/sundo/remoteTBT/TBTGuide;

    return-object v0
.end method

.method private static handleBackgroundMessage()V
    .locals 2

    .prologue
    .line 1109
    sget-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    new-instance v1, Lcom/thinkware/sundo/inavi3d/Inavi$8;

    invoke-direct {v1}, Lcom/thinkware/sundo/inavi3d/Inavi$8;-><init>()V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 1118
    return-void
.end method

.method public static isCurrentOnAndRootActivity()Z
    .locals 1

    .prologue
    .line 1037
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->isCurrentOnAndRootActivity()Z

    move-result v0

    if-eqz v0, :cond_0

    .line 1038
    const/4 v0, 0x1

    .line 1040
    :goto_0
    return v0

    :cond_0
    const/4 v0, 0x0

    goto :goto_0
.end method

.method public static native isNaviCurrentOn()Z
.end method

.method public static isValidRoute()Z
    .locals 1

    .prologue
    .line 125
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/Inavi;->getTbtguide()Lcom/thinkware/sundo/remoteTBT/TBTGuide;

    move-result-object v0

    iget v0, v0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->viaCount:I

    if-lez v0, :cond_0

    .line 126
    const/4 v0, 0x1

    .line 128
    :goto_0
    return v0

    :cond_0
    const/4 v0, 0x0

    goto :goto_0
.end method

.method public static native resetCustomView()V
.end method

.method private static setCrossNameInfo(Ljava/lang/String;II)V
    .locals 3
    .param p0, "str"    # Ljava/lang/String;
    .param p1, "color"    # I
    .param p2, "size"    # I

    .prologue
    .line 948
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mContext:Landroid/content/Context;

    check-cast v1, Landroid/app/Activity;

    const v2, 0x7f0b058a

    invoke-virtual {v1, v2}, Landroid/app/Activity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    .line 949
    .local v0, "CrossWayname":Landroid/widget/Button;
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->crossname:Landroid/widget/Button;

    if-eqz v1, :cond_0

    .line 950
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->crossname:Landroid/widget/Button;

    new-instance v2, Lcom/thinkware/sundo/inavi3d/Inavi$6;

    invoke-direct {v2, p0, p1, p2}, Lcom/thinkware/sundo/inavi3d/Inavi$6;-><init>(Ljava/lang/String;II)V

    invoke-virtual {v1, v2}, Landroid/widget/Button;->post(Ljava/lang/Runnable;)Z

    .line 963
    :cond_0
    return-void
.end method

.method public static setTbtguide(Lcom/thinkware/sundo/remoteTBT/TBTGuide;)V
    .locals 0
    .param p0, "tbtguide"    # Lcom/thinkware/sundo/remoteTBT/TBTGuide;

    .prologue
    .line 1569
    sput-object p0, Lcom/thinkware/sundo/inavi3d/Inavi;->tbtguide:Lcom/thinkware/sundo/remoteTBT/TBTGuide;

    .line 1570
    return-void
.end method

.method public static setUI()V
    .locals 2

    .prologue
    .line 1526
    sget-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->mContext:Landroid/content/Context;

    check-cast v0, Landroid/app/Activity;

    const v1, 0x7f0b0577

    invoke-virtual {v0, v1}, Landroid/app/Activity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SpeedView;

    sput-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->speedview:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SpeedView;

    .line 1528
    sget-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->mContext:Landroid/content/Context;

    check-cast v0, Landroid/app/Activity;

    const v1, 0x7f0b0573

    invoke-virtual {v0, v1}, Landroid/app/Activity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/DriveCourseView;

    sput-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->courseView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/DriveCourseView;

    .line 1529
    sget-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->mContext:Landroid/content/Context;

    check-cast v0, Landroid/app/Activity;

    const v1, 0x7f0b0575

    invoke-virtual {v0, v1}, Landroid/app/Activity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/LaneInfoView;

    sput-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->driveLineView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/LaneInfoView;

    .line 1530
    sget-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->mContext:Landroid/content/Context;

    check-cast v0, Landroid/app/Activity;

    const v1, 0x7f0b057c

    invoke-virtual {v0, v1}, Landroid/app/Activity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/CrossWayView;

    sput-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->crossWayView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/CrossWayView;

    .line 1532
    sget-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->mContext:Landroid/content/Context;

    check-cast v0, Landroid/app/Activity;

    const v1, 0x7f0b0578

    invoke-virtual {v0, v1}, Landroid/app/Activity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/RelativeLayout;

    sput-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneLayout:Landroid/widget/RelativeLayout;

    .line 1533
    sget-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->mContext:Landroid/content/Context;

    check-cast v0, Landroid/app/Activity;

    const v1, 0x7f0b057a

    invoke-virtual {v0, v1}, Landroid/app/Activity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;

    sput-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;

    .line 1534
    sget-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->mContext:Landroid/content/Context;

    check-cast v0, Landroid/app/Activity;

    const v1, 0x7f0b0579

    invoke-virtual {v0, v1}, Landroid/app/Activity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;

    sput-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->sectionView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;

    .line 1535
    sget-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->mContext:Landroid/content/Context;

    check-cast v0, Landroid/app/Activity;

    const v1, 0x7f0b057b

    invoke-virtual {v0, v1}, Landroid/app/Activity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;

    sput-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->turnAreaView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;

    .line 1537
    sget-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->mContext:Landroid/content/Context;

    check-cast v0, Landroid/app/Activity;

    const v1, 0x7f0b057e

    invoke-virtual {v0, v1}, Landroid/app/Activity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SpeedView;

    sput-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->speedview2:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SpeedView;

    .line 1538
    sget-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->mContext:Landroid/content/Context;

    check-cast v0, Landroid/app/Activity;

    const v1, 0x7f0b057f

    invoke-virtual {v0, v1}, Landroid/app/Activity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/RelativeLayout;

    sput-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneLayout2:Landroid/widget/RelativeLayout;

    .line 1539
    sget-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->mContext:Landroid/content/Context;

    check-cast v0, Landroid/app/Activity;

    const v1, 0x7f0b0580

    invoke-virtual {v0, v1}, Landroid/app/Activity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;

    sput-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneView2:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;

    .line 1540
    sget-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->mContext:Landroid/content/Context;

    check-cast v0, Landroid/app/Activity;

    const v1, 0x7f0b0581

    invoke-virtual {v0, v1}, Landroid/app/Activity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;

    sput-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->sectionView2:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;

    .line 1541
    sget-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->mContext:Landroid/content/Context;

    check-cast v0, Landroid/app/Activity;

    const v1, 0x7f0b0582

    invoke-virtual {v0, v1}, Landroid/app/Activity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;

    sput-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->turnAreaView2:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;

    .line 1542
    sget-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->mContext:Landroid/content/Context;

    check-cast v0, Landroid/app/Activity;

    const v1, 0x7f0b0583

    invoke-virtual {v0, v1}, Landroid/app/Activity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/CrossWayView;

    sput-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->crossWayView2:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/CrossWayView;

    .line 1544
    sget-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->mContext:Landroid/content/Context;

    check-cast v0, Landroid/app/Activity;

    const v1, 0x7f0b0586

    invoke-virtual {v0, v1}, Landroid/app/Activity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/RelativeLayout;

    sput-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneLayout3:Landroid/widget/RelativeLayout;

    .line 1545
    sget-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->mContext:Landroid/content/Context;

    check-cast v0, Landroid/app/Activity;

    const v1, 0x7f0b0587

    invoke-virtual {v0, v1}, Landroid/app/Activity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;

    sput-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneView3:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;

    .line 1546
    sget-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->mContext:Landroid/content/Context;

    check-cast v0, Landroid/app/Activity;

    const v1, 0x7f0b0588

    invoke-virtual {v0, v1}, Landroid/app/Activity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;

    sput-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->sectionView3:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;

    .line 1547
    sget-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->mContext:Landroid/content/Context;

    check-cast v0, Landroid/app/Activity;

    const v1, 0x7f0b0589

    invoke-virtual {v0, v1}, Landroid/app/Activity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/CrossWayView;

    sput-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->crossWayView3:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/CrossWayView;

    .line 1548
    sget-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->mContext:Landroid/content/Context;

    check-cast v0, Landroid/app/Activity;

    const v1, 0x7f0b0585

    invoke-virtual {v0, v1}, Landroid/app/Activity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SpeedView;

    sput-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->speedview3:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SpeedView;

    .line 1549
    sget-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->mContext:Landroid/content/Context;

    check-cast v0, Landroid/app/Activity;

    const v1, 0x7f0b058a

    invoke-virtual {v0, v1}, Landroid/app/Activity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    sput-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->crossname:Landroid/widget/Button;

    .line 1551
    sget-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->mContext:Landroid/content/Context;

    check-cast v0, Landroid/app/Activity;

    const v1, 0x7f0b058c

    invoke-virtual {v0, v1}, Landroid/app/Activity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SpeedView;

    sput-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->speedview4:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SpeedView;

    .line 1552
    sget-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->mContext:Landroid/content/Context;

    check-cast v0, Landroid/app/Activity;

    const v1, 0x7f0b058d

    invoke-virtual {v0, v1}, Landroid/app/Activity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/RelativeLayout;

    sput-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneLayout4:Landroid/widget/RelativeLayout;

    .line 1553
    sget-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->mContext:Landroid/content/Context;

    check-cast v0, Landroid/app/Activity;

    const v1, 0x7f0b058e

    invoke-virtual {v0, v1}, Landroid/app/Activity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;

    sput-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneView4:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;

    .line 1554
    sget-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->mContext:Landroid/content/Context;

    check-cast v0, Landroid/app/Activity;

    const v1, 0x7f0b058f

    invoke-virtual {v0, v1}, Landroid/app/Activity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;

    sput-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->sectionView4:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;

    .line 1555
    sget-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->mContext:Landroid/content/Context;

    check-cast v0, Landroid/app/Activity;

    const v1, 0x7f0b0590

    invoke-virtual {v0, v1}, Landroid/app/Activity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;

    sput-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->turnAreaView4:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;

    .line 1556
    sget-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->mContext:Landroid/content/Context;

    check-cast v0, Landroid/app/Activity;

    const v1, 0x7f0b0591

    invoke-virtual {v0, v1}, Landroid/app/Activity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/CrossWayView;

    sput-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->crossWayView4:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/CrossWayView;

    .line 1557
    sget-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->mContext:Landroid/content/Context;

    check-cast v0, Landroid/app/Activity;

    const v1, 0x7f0b055e

    invoke-virtual {v0, v1}, Landroid/app/Activity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    sput-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->btnLocalName:Landroid/widget/Button;

    .line 1561
    sget-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->mContext:Landroid/content/Context;

    check-cast v0, Landroid/app/Activity;

    const v1, 0x7f0b0221

    invoke-virtual {v0, v1}, Landroid/app/Activity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/LinearLayout;

    sput-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->m_LaneTurnModeLayout:Landroid/widget/LinearLayout;

    .line 1562
    return-void
.end method

.method public static toByteArray(Ljava/lang/Object;)[B
    .locals 4
    .param p0, "obj"    # Ljava/lang/Object;

    .prologue
    .line 450
    const/4 v1, 0x0

    .line 451
    .local v1, "bytes":[B
    new-instance v0, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v0}, Ljava/io/ByteArrayOutputStream;-><init>()V

    .line 453
    .local v0, "bos":Ljava/io/ByteArrayOutputStream;
    :try_start_0
    new-instance v2, Ljava/io/ObjectOutputStream;

    invoke-direct {v2, v0}, Ljava/io/ObjectOutputStream;-><init>(Ljava/io/OutputStream;)V

    .line 454
    .local v2, "oos":Ljava/io/ObjectOutputStream;
    invoke-virtual {v2, p0}, Ljava/io/ObjectOutputStream;->writeObject(Ljava/lang/Object;)V

    .line 455
    invoke-virtual {v2}, Ljava/io/ObjectOutputStream;->flush()V

    .line 456
    invoke-virtual {v2}, Ljava/io/ObjectOutputStream;->close()V

    .line 457
    invoke-virtual {v0}, Ljava/io/ByteArrayOutputStream;->close()V

    .line 458
    invoke-virtual {v0}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    move-result-object v1

    .line 462
    .end local v2    # "oos":Ljava/io/ObjectOutputStream;
    :goto_0
    return-object v1

    .line 459
    :catch_0
    move-exception v3

    goto :goto_0
.end method


# virtual methods
.method public native CNaviConfigGet(I)I
.end method

.method public native CNaviConfingGet(I)I
.end method

.method public native DirectRoute(ILcom/thinkware/sundo/inavi3d/Struct/InaviPoint;)V
.end method

.method public native DualMapZoomIn()Z
.end method

.method public native DualMapZoomOut()Z
.end method

.method public native GetTraficType()I
.end method

.method public native GetVolume()I
.end method

.method public native Initialize(Ljava/lang/String;II)Z
.end method

.method public native LocationRevision()Z
.end method

.method public native MapViewPopupClose()Z
.end method

.method public native MapZoomIn()Z
.end method

.method public native MapZoomOut()Z
.end method

.method public native MuteStatus(Z)V
.end method

.method public native PositionMove(ILcom/thinkware/sundo/inavi3d/Struct/InaviPoint;)V
.end method

.method public ProcessSolution(Landroid/content/Intent;)V
    .locals 10
    .param p1, "intent"    # Landroid/content/Intent;

    .prologue
    const/16 v9, 0x270f

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v6, -0x1

    .line 299
    invoke-virtual {p1}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v4

    if-nez v4, :cond_1

    .line 340
    :cond_0
    :goto_0
    return-void

    .line 302
    :cond_1
    invoke-virtual {p1}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v4

    const-string v5, "com.thinkware.sundo.inavi3d.action.RUN"

    invoke-virtual {v4, v5}, Ljava/lang/String;->compareTo(Ljava/lang/String;)I

    move-result v4

    if-eqz v4, :cond_0

    .line 305
    invoke-virtual {p1}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v4

    const-string v5, "com.thinkware.sundo.inavi3d.action.EXIT"

    invoke-virtual {v4, v5}, Ljava/lang/String;->compareTo(Ljava/lang/String;)I

    move-result v4

    if-nez v4, :cond_2

    .line 307
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/Inavi;->force_exit:Z

    .line 308
    invoke-virtual {p0, v9, v7}, Lcom/thinkware/sundo/inavi3d/Inavi;->onCommande(II)V

    goto :goto_0

    .line 310
    :cond_2
    invoke-virtual {p1}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v4

    const-string v5, "android.intent.action.ACTION_SHUTDOWN"

    invoke-virtual {v4, v5}, Ljava/lang/String;->compareTo(Ljava/lang/String;)I

    move-result v4

    if-nez v4, :cond_3

    .line 312
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/Inavi;->force_exit:Z

    .line 313
    invoke-virtual {p0, v9, v7}, Lcom/thinkware/sundo/inavi3d/Inavi;->onCommande(II)V

    goto :goto_0

    .line 315
    :cond_3
    invoke-virtual {p1}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v4

    const-string v5, "android.intent.action.MEDIA_EJECT"

    invoke-virtual {v4, v5}, Ljava/lang/String;->compareTo(Ljava/lang/String;)I

    move-result v4

    if-nez v4, :cond_4

    .line 317
    const-string v4, "inavi3d_java"

    const-string v5, "android.intent.action.MEDIA_EJECT2"

    invoke-static {v4, v5}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 318
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/Inavi;->force_exit:Z

    .line 319
    invoke-virtual {p0, v9, v7}, Lcom/thinkware/sundo/inavi3d/Inavi;->onCommande(II)V

    goto :goto_0

    .line 321
    :cond_4
    invoke-virtual {p1}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v4

    const-string v5, "com.thinkware.sundo.inavi3d.action.MAPMOVE"

    invoke-virtual {v4, v5}, Ljava/lang/String;->compareTo(Ljava/lang/String;)I

    move-result v4

    if-nez v4, :cond_5

    .line 325
    const-string v4, "name"

    invoke-virtual {p1, v4}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 326
    .local v2, "name":Ljava/lang/String;
    new-instance v3, Lcom/thinkware/sundo/inavi3d/Inavi$location;

    invoke-direct {v3, p0}, Lcom/thinkware/sundo/inavi3d/Inavi$location;-><init>(Lcom/thinkware/sundo/inavi3d/Inavi;)V

    .line 328
    .local v3, "wgs84":Lcom/thinkware/sundo/inavi3d/Inavi$location;
    const-string v4, "longitude"

    invoke-virtual {p1, v4, v6}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v4

    iput v4, v3, Lcom/thinkware/sundo/inavi3d/Inavi$location;->longitude:I

    .line 329
    const-string v4, "latitude"

    invoke-virtual {p1, v4, v6}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v4

    iput v4, v3, Lcom/thinkware/sundo/inavi3d/Inavi$location;->latitude:I

    .line 330
    const-string v4, "level"

    const/16 v5, 0xd

    invoke-virtual {p1, v4, v5}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v0

    .line 332
    .local v0, "level":I
    iget v4, v3, Lcom/thinkware/sundo/inavi3d/Inavi$location;->longitude:I

    iget v5, v3, Lcom/thinkware/sundo/inavi3d/Inavi$location;->latitude:I

    invoke-virtual {p0, v2, v4, v5, v0}, Lcom/thinkware/sundo/inavi3d/Inavi;->solutionMoveMap(Ljava/lang/String;III)V

    goto :goto_0

    .line 333
    .end local v0    # "level":I
    .end local v2    # "name":Ljava/lang/String;
    .end local v3    # "wgs84":Lcom/thinkware/sundo/inavi3d/Inavi$location;
    :cond_5
    invoke-virtual {p1}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v4

    const-string v5, "com.thinkware.sundo.inavi3d.action.SECRETKEY.BR.FG"

    invoke-virtual {v4, v5}, Ljava/lang/String;->compareTo(Ljava/lang/String;)I

    move-result v4

    if-nez v4, :cond_0

    .line 335
    const-string v4, "msg_id"

    invoke-virtual {p1, v4, v6}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v1

    .line 336
    .local v1, "msg_id":I
    const/16 v4, 0x7530

    invoke-virtual {p0, v4, v1, v6, v6}, Lcom/thinkware/sundo/inavi3d/Inavi;->PushMessage(IIII)V

    goto/16 :goto_0
.end method

.method public native PushMessage(IIII)V
.end method

.method public native ReRoute()Z
.end method

.method public native SetConfigSave()Z
.end method

.method public native SetMute(I)Z
.end method

.method public SetRouteBinder(Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;)V
    .locals 0
    .param p1, "binder"    # Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    .prologue
    .line 290
    sput-object p1, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    .line 291
    return-void
.end method

.method public native SetVolume(I)Z
.end method

.method public native TCONProcessStatus(IIIII)V
.end method

.method public native UpdateRoute()V
.end method

.method public native UserSafeCamera()I
.end method

.method public native birdviewtracking(I)V
.end method

.method public native destroy()V
.end method

.method public native executeRender(J)V
.end method

.method public native executeRender2(J)V
.end method

.method public native initCallBack()V
.end method

.method public native isExecuteAvoid()Z
.end method

.method public native isInitDone()Z
.end method

.method public native isMute()Z
.end method

.method public native nativeRouteCancle()Z
.end method

.method public native onButtonDown(II)V
.end method

.method public native onButtonUp(II)V
.end method

.method public native onCommande(II)V
.end method

.method public native onMultiButton(FFFFI)V
.end method

.method public native onSingleButton(FFI)V
.end method

.method public native playSoundStatus(Z)V
.end method

.method public native preinit(Ljava/lang/String;I)V
.end method

.method public native setDisplaySize(II)V
.end method

.method public native setTimerEvent(II)V
.end method

.method setUIManager(Lcom/thinkware/sundo/inavi3d/UIManager;)V
    .locals 0
    .param p1, "manager"    # Lcom/thinkware/sundo/inavi3d/UIManager;

    .prologue
    .line 286
    sput-object p1, Lcom/thinkware/sundo/inavi3d/Inavi;->mUIManager:Lcom/thinkware/sundo/inavi3d/UIManager;

    .line 287
    return-void
.end method

.method public native solutionMoveMap(Ljava/lang/String;III)V
.end method

.method public native volumerange(I)V
.end method
