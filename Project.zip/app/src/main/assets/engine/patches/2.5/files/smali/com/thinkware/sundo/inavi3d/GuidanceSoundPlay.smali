.class public Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;
.super Ljava/lang/Object;
.source "GuidanceSoundPlay.java"


# static fields
.field static final ASYNC_MODE:I = 0x0

.field static final REV_PLAY_NOSTOP:I = 0x1

.field public static final SAMPLE_22:I = 0x5622

.field public static final SAMPLE_44:I = 0xac44

.field static final SYNC_MODE:I = 0x1

.field static final WAVE_CLICK:I = 0x1

.field static bSoundCancel:Z

.field static bSoundEnd:Z

.field static bSoundMute:Z

.field static bSoundStart:Z

.field static bplayclickStart:Z

.field static fiNaviVolume:I

.field static inaviactivity:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

.field public static mAudioManager:Landroid/media/AudioManager;

.field private static m_iAppVolumeIndex:I

.field static m_mediaplayer:Landroid/media/MediaPlayer;

.field static m_mediaplayer_click:Landroid/media/MediaPlayer;

.field static m_mediaplayer_file:Landroid/media/MediaPlayer;

.field static soundthread:Ljava/lang/Thread;

.field static wave_src:[B


# instance fields
.field final FILE_DATA:I

.field final MEMORY_DATA:I

.field final PREV_PLAY_STOP:I


# direct methods
.method static constructor <clinit>()V
    .locals 3

    .prologue
    const/4 v2, 0x0

    const/4 v1, 0x0

    .line 21
    sput-object v2, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer_click:Landroid/media/MediaPlayer;

    .line 22
    sput-object v2, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer:Landroid/media/MediaPlayer;

    .line 23
    sput-object v2, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer_file:Landroid/media/MediaPlayer;

    .line 32
    sput v1, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->fiNaviVolume:I

    .line 33
    const/4 v0, 0x2

    sput v0, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_iAppVolumeIndex:I

    .line 36
    sput-boolean v1, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->bplayclickStart:Z

    .line 37
    sput-boolean v1, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->bSoundMute:Z

    .line 38
    const/4 v0, 0x1

    sput-boolean v0, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->bSoundEnd:Z

    .line 39
    sput-boolean v1, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->bSoundCancel:Z

    .line 40
    sput-boolean v1, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->bSoundStart:Z

    .line 43
    sput-object v2, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->wave_src:[B

    return-void
.end method

.method constructor <init>(Landroid/content/Context;)V
    .locals 2
    .param p1, "context"    # Landroid/content/Context;

    .prologue
    const/4 v1, 0x0

    .line 51
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 27
    iput v1, p0, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->FILE_DATA:I

    .line 28
    const/4 v0, 0x1

    iput v0, p0, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->MEMORY_DATA:I

    .line 29
    iput v1, p0, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->PREV_PLAY_STOP:I

    move-object v0, p1

    .line 52
    check-cast v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    sput-object v0, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->inaviactivity:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    .line 53
    invoke-virtual {p0, p1}, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->initSound(Landroid/content/Context;)V

    .line 54
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->initClickSound()V

    .line 55
    return-void
.end method

.method public static GetAndroidVolume()I
    .locals 2

    .prologue
    .line 60
    sget-object v0, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->mAudioManager:Landroid/media/AudioManager;

    sget v1, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->INAVI_STREAM_TYPE:I

    invoke-virtual {v0, v1}, Landroid/media/AudioManager;->getStreamVolume(I)I

    move-result v0

    return v0
.end method

.method public static GetInaviVolume()I
    .locals 2

    .prologue
    .line 75
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->getInstance()Lcom/thinkware/sundo/inavi3d/InaviConfig;

    move-result-object v0

    const/16 v1, 0x44

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->CNaviConfigGet(I)I

    move-result v0

    return v0
.end method

.method public static GetVolume()I
    .locals 1

    .prologue
    .line 85
    sget v0, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_iAppVolumeIndex:I

    return v0
.end method

.method public static SetAndroidVolume(IZ)V
    .locals 3
    .param p0, "vol"    # I
    .param p1, "playsound"    # Z

    .prologue
    .line 65
    const/4 v0, 0x4

    .line 67
    .local v0, "sFlag":I
    if-nez p1, :cond_0

    .line 68
    const/4 v0, 0x0

    .line 70
    :cond_0
    sget-object v1, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->mAudioManager:Landroid/media/AudioManager;

    sget v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->INAVI_STREAM_TYPE:I

    invoke-virtual {v1, v2, p0, v0}, Landroid/media/AudioManager;->setStreamVolume(III)V

    .line 71
    return-void
.end method

.method public static SetVolume(IZ)V
    .locals 3
    .param p0, "index"    # I
    .param p1, "playsound"    # Z

    .prologue
    .line 93
    if-gez p0, :cond_0

    .line 94
    const/4 p0, 0x0

    .line 95
    :cond_0
    const/4 v0, 0x4

    if-le p0, v0, :cond_1

    .line 96
    const/4 p0, 0x4

    .line 98
    :cond_1
    sput p0, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_iAppVolumeIndex:I

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->applyAppVolume()V

    .line 100
    sget v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->INAVI_STREAM_TYPE:I

    const/16 v1, 0xa

    if-ne v0, v1, :cond_2

    .line 101
    nop

    .line 106
    :goto_0
    return-void

    .line 103
    :cond_2
    goto :goto_0
.end method

.method static SoundPlay(I)V
    .locals 5
    .param p0, "index"    # I

    .prologue
    const/4 v4, 0x1

    .line 279
    sget-boolean v2, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->bplayclickStart:Z

    if-eq v4, v2, :cond_1

    .line 281
    const-string v2, "sound"

    const-string v3, " click start - 1 "

    invoke-static {v2, v3}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 282
    if-ne p0, v4, :cond_1

    .line 284
    sput-boolean v4, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->bplayclickStart:Z

    .line 287
    :try_start_0
    sget-object v2, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer:Landroid/media/MediaPlayer;

    if-eqz v2, :cond_0

    .line 288
    sget-object v2, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer:Landroid/media/MediaPlayer;

    invoke-virtual {v2}, Landroid/media/MediaPlayer;->isPlaying()Z

    move-result v2

    if-eqz v2, :cond_0

    .line 290
    sget-object v2, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer:Landroid/media/MediaPlayer;

    invoke-virtual {v2}, Landroid/media/MediaPlayer;->stop()V

    .line 291
    const/4 v2, 0x1

    sput-boolean v2, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->bSoundEnd:Z

    .line 292
    const/4 v2, 0x0

    sput-boolean v2, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->bSoundCancel:Z

    .line 293
    sget-object v2, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->inaviactivity:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    sget-boolean v3, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->bSoundEnd:Z

    invoke-virtual {v2, v3}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->PlaySoundStatus(Z)V

    .line 294
    sget-object v2, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->inaviactivity:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    invoke-virtual {v2}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->SendVolumeResume()V

    .line 298
    :cond_0
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->getSoundVolume()F

    move-result v1

    .line 299
    .local v1, "soundVolume":F
    sget-object v2, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer_click:Landroid/media/MediaPlayer;

    invoke-virtual {v2, v1, v1}, Landroid/media/MediaPlayer;->setVolume(FF)V

    .line 300
    sget-object v2, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer_click:Landroid/media/MediaPlayer;

    sget v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->INAVI_STREAM_TYPE:I

    invoke-virtual {v2, v3}, Landroid/media/MediaPlayer;->setAudioStreamType(I)V

    .line 301
    sget-object v2, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer_click:Landroid/media/MediaPlayer;

    invoke-virtual {v2}, Landroid/media/MediaPlayer;->start()V
    :try_end_0
    .catch Ljava/lang/IllegalStateException; {:try_start_0 .. :try_end_0} :catch_0

    .line 309
    .end local v1    # "soundVolume":F
    :cond_1
    :goto_0
    return-void

    .line 302
    :catch_0
    move-exception v0

    .line 303
    .local v0, "e":Ljava/lang/IllegalStateException;
    const-string v2, "sound"

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "Click IllegalStateException"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v0}, Ljava/lang/IllegalStateException;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 304
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->readyGuideSound()V

    .line 305
    invoke-virtual {v0}, Ljava/lang/IllegalStateException;->printStackTrace()V

    goto :goto_0
.end method

.method static SoundPlay(IZ)V
    .locals 5
    .param p0, "index"    # I
    .param p1, "bClickSound"    # Z

    .prologue
    const/4 v4, 0x1

    .line 314
    sget-boolean v2, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->bplayclickStart:Z

    if-ne v4, v2, :cond_0

    if-nez p1, :cond_2

    .line 316
    :cond_0
    const-string v2, "sound"

    const-string v3, " click start - 1 "

    invoke-static {v2, v3}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 317
    if-ne p0, v4, :cond_2

    .line 319
    sput-boolean v4, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->bplayclickStart:Z

    .line 322
    :try_start_0
    sget-object v2, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer:Landroid/media/MediaPlayer;

    if-eqz v2, :cond_1

    .line 323
    sget-object v2, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer:Landroid/media/MediaPlayer;

    invoke-virtual {v2}, Landroid/media/MediaPlayer;->isPlaying()Z

    move-result v2

    if-eqz v2, :cond_1

    .line 325
    sget-object v2, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer:Landroid/media/MediaPlayer;

    invoke-virtual {v2}, Landroid/media/MediaPlayer;->stop()V

    .line 326
    const/4 v2, 0x1

    sput-boolean v2, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->bSoundEnd:Z

    .line 327
    const/4 v2, 0x0

    sput-boolean v2, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->bSoundCancel:Z

    .line 328
    sget-object v2, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->inaviactivity:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    sget-boolean v3, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->bSoundEnd:Z

    invoke-virtual {v2, v3}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->PlaySoundStatus(Z)V

    .line 329
    sget-object v2, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->inaviactivity:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    invoke-virtual {v2}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->SendVolumeResume()V

    .line 333
    :cond_1
    if-eqz p1, :cond_2

    .line 334
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->getSoundVolume()F

    move-result v1

    .line 335
    .local v1, "soundVolume":F
    sget-object v2, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer_click:Landroid/media/MediaPlayer;

    invoke-virtual {v2, v1, v1}, Landroid/media/MediaPlayer;->setVolume(FF)V

    .line 336
    sget-object v2, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer_click:Landroid/media/MediaPlayer;

    sget v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->INAVI_STREAM_TYPE:I

    invoke-virtual {v2, v3}, Landroid/media/MediaPlayer;->setAudioStreamType(I)V

    .line 337
    sget-object v2, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer_click:Landroid/media/MediaPlayer;

    invoke-virtual {v2}, Landroid/media/MediaPlayer;->start()V
    :try_end_0
    .catch Ljava/lang/IllegalStateException; {:try_start_0 .. :try_end_0} :catch_0

    .line 347
    .end local v1    # "soundVolume":F
    :cond_2
    :goto_0
    return-void

    .line 340
    :catch_0
    move-exception v0

    .line 341
    .local v0, "e":Ljava/lang/IllegalStateException;
    const-string v2, "sound"

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "Click IllegalStateException"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v0}, Ljava/lang/IllegalStateException;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 342
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->readyGuideSound()V

    .line 343
    invoke-virtual {v0}, Ljava/lang/IllegalStateException;->printStackTrace()V

    goto :goto_0
.end method

.method static SoundPlay(Ljava/lang/String;II)V
    .locals 8
    .param p0, "wavefile"    # Ljava/lang/String;
    .param p1, "playmode"    # I
    .param p2, "prevplaycontrol"    # I

    .prologue
    const/4 v7, 0x1

    const/4 v6, 0x0

    .line 350
    const-string v3, "sound"

    const-string v4, " file start - start "

    invoke-static {v3, v4}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 352
    sget-object v3, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->inaviactivity:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    invoke-virtual {v3}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->SendVolumePause()V

    .line 353
    sget-boolean v3, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->bSoundEnd:Z

    if-ne v3, v7, :cond_1

    .line 355
    const-string v3, "sound"

    const-string v4, " file start - 2"

    invoke-static {v3, v4}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 356
    sput-boolean v6, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->bSoundEnd:Z

    .line 357
    sget-object v3, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->inaviactivity:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    sget-boolean v4, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->bSoundEnd:Z

    invoke-virtual {v3, v4}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->PlaySoundStatus(Z)V

    .line 360
    :try_start_0
    new-instance v1, Ljava/io/FileInputStream;

    invoke-direct {v1, p0}, Ljava/io/FileInputStream;-><init>(Ljava/lang/String;)V

    .line 362
    .local v1, "istr":Ljava/io/FileInputStream;
    sget-object v3, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer_file:Landroid/media/MediaPlayer;

    if-eqz v3, :cond_0

    .line 364
    sget-object v3, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer_file:Landroid/media/MediaPlayer;

    invoke-virtual {v3}, Landroid/media/MediaPlayer;->release()V

    .line 365
    const/4 v3, 0x0

    sput-object v3, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer_file:Landroid/media/MediaPlayer;

    .line 368
    :cond_0
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->getSoundVolume()F

    move-result v2

    .line 369
    .local v2, "soundVolume":F
    new-instance v3, Landroid/media/MediaPlayer;

    invoke-direct {v3}, Landroid/media/MediaPlayer;-><init>()V

    sput-object v3, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer_file:Landroid/media/MediaPlayer;

    .line 370
    sget-object v3, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer_file:Landroid/media/MediaPlayer;

    invoke-virtual {v3, v2, v2}, Landroid/media/MediaPlayer;->setVolume(FF)V

    .line 371
    sget-object v3, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer_file:Landroid/media/MediaPlayer;

    sget v4, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->INAVI_STREAM_TYPE:I

    invoke-virtual {v3, v4}, Landroid/media/MediaPlayer;->setAudioStreamType(I)V

    .line 372
    sget-object v3, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer_file:Landroid/media/MediaPlayer;

    invoke-virtual {v1}, Ljava/io/FileInputStream;->getFD()Ljava/io/FileDescriptor;

    move-result-object v4

    invoke-virtual {v3, v4}, Landroid/media/MediaPlayer;->setDataSource(Ljava/io/FileDescriptor;)V

    .line 373
    const-string v3, "sound"

    const-string v4, " file start - prepare"

    invoke-static {v3, v4}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 374
    sget-object v3, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer_file:Landroid/media/MediaPlayer;

    invoke-virtual {v3}, Landroid/media/MediaPlayer;->prepare()V

    .line 375
    sget-object v3, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer_file:Landroid/media/MediaPlayer;

    new-instance v4, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay$3;

    invoke-direct {v4}, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay$3;-><init>()V

    invoke-virtual {v3, v4}, Landroid/media/MediaPlayer;->setOnCompletionListener(Landroid/media/MediaPlayer$OnCompletionListener;)V

    .line 383
    sget-object v3, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer_file:Landroid/media/MediaPlayer;

    invoke-virtual {v3}, Landroid/media/MediaPlayer;->start()V

    .line 384
    const-string v3, "sound"

    const-string v4, " file start - play"

    invoke-static {v3, v4}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/IllegalStateException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_2

    .line 403
    .end local v1    # "istr":Ljava/io/FileInputStream;
    .end local v2    # "soundVolume":F
    :goto_0
    return-void

    .line 386
    :catch_0
    move-exception v0

    .line 387
    .local v0, "e":Ljava/lang/IllegalArgumentException;
    const-string v3, "sound"

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, " IllegalArgumentException"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v0}, Ljava/lang/IllegalArgumentException;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v3, v4}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 388
    invoke-virtual {v0}, Ljava/lang/IllegalArgumentException;->printStackTrace()V

    .line 396
    .end local v0    # "e":Ljava/lang/IllegalArgumentException;
    :goto_1
    sput-boolean v7, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->bSoundEnd:Z

    .line 397
    sput-boolean v6, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->bSoundCancel:Z

    .line 398
    sget-object v3, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->inaviactivity:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    sget-boolean v4, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->bSoundEnd:Z

    invoke-virtual {v3, v4}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->PlaySoundStatus(Z)V

    .line 399
    const-string v3, "sound"

    const-string v4, " file start - 4"

    invoke-static {v3, v4}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 401
    :cond_1
    sget-object v3, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->inaviactivity:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    invoke-virtual {v3}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->SendVolumeResume()V

    .line 402
    const-string v3, "sound"

    const-string v4, " file start - end "

    invoke-static {v3, v4}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_0

    .line 389
    :catch_1
    move-exception v0

    .line 390
    .local v0, "e":Ljava/lang/IllegalStateException;
    const-string v3, "sound"

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "IllegalStateException"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v0}, Ljava/lang/IllegalStateException;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v3, v4}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 391
    invoke-virtual {v0}, Ljava/lang/IllegalStateException;->printStackTrace()V

    goto :goto_1

    .line 392
    .end local v0    # "e":Ljava/lang/IllegalStateException;
    :catch_2
    move-exception v0

    .line 393
    .local v0, "e":Ljava/io/IOException;
    const-string v3, "sound"

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "IOException2"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v0}, Ljava/io/IOException;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v3, v4}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 394
    invoke-virtual {v0}, Ljava/io/IOException;->printStackTrace()V

    goto :goto_1
.end method

.method static SoundPlay([BII)Z
    .locals 1
    .param p0, "src"    # [B
    .param p1, "playmode"    # I
    .param p2, "prevplaycontrol"    # I

    .prologue
    .line 255
    const/4 v0, 0x0

    invoke-static {p0, v0}, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->playstream([BZ)Z

    move-result v0

    return v0
.end method

.method public static applyAppVolume()V
    .locals 2

    .prologue
    .line 200
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->getSoundVolume()F

    move-result v0

    .line 201
    sget-object v1, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer:Landroid/media/MediaPlayer;

    if-eqz v1, :cond_0

    invoke-virtual {v1, v0, v0}, Landroid/media/MediaPlayer;->setVolume(FF)V

    .line 202
    :cond_0
    sget-object v1, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer_click:Landroid/media/MediaPlayer;

    if-eqz v1, :cond_1

    invoke-virtual {v1, v0, v0}, Landroid/media/MediaPlayer;->setVolume(FF)V

    .line 203
    :cond_1
    sget-object v1, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer_file:Landroid/media/MediaPlayer;

    if-eqz v1, :cond_2

    invoke-virtual {v1, v0, v0}, Landroid/media/MediaPlayer;->setVolume(FF)V

    .line 204
    :cond_2
    return-void
.end method

.method static getSoundVolume()F
    .locals 2

    .prologue
    .line 152
    sget v0, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_iAppVolumeIndex:I

    .line 153
    .local v0, "inaviVolume":I
    packed-switch v0, :pswitch_data_0

    .line 172
    const/high16 v1, 0x3f800000    # 1.0f

    :goto_0
    return v1

    .line 167
    :pswitch_0
    const/4 v1, 0x0

    goto :goto_0

    :pswitch_1
    const v1, 0x3e800000    # 0.25f

    goto :goto_0

    :pswitch_2
    const v1, 0x3f000000    # 0.5f

    goto :goto_0

    :pswitch_3
    const v1, 0x3f400000    # 0.75f

    goto :goto_0

    :pswitch_4
    const/high16 v1, 0x3f800000    # 1.0f

    goto :goto_0

    .line 153
    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
        :pswitch_1
        :pswitch_2
        :pswitch_3
        :pswitch_4
    .end packed-switch
.end method

.method static iNavisysVolume(F)V
    .locals 0
    .param p0, "fVolume"    # F

    .prologue
    .line 149
    return-void
.end method

.method public static indexToVolume(I)I
    .locals 3
    .param p0, "index"    # I

    .prologue
    .line 412
    const/4 v0, 0x0

    .line 414
    .local v0, "retVol":I
    packed-switch p0, :pswitch_data_0

    .line 431
    sget-object v1, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->mAudioManager:Landroid/media/AudioManager;

    sget v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->INAVI_STREAM_TYPE:I

    invoke-virtual {v1, v2}, Landroid/media/AudioManager;->getStreamVolume(I)I

    move-result v0

    .line 434
    :goto_0
    return v0

    .line 416
    :pswitch_0
    const/4 v0, 0x0

    .line 417
    goto :goto_0

    .line 419
    :pswitch_1
    const/4 v0, 0x3

    .line 420
    goto :goto_0

    .line 422
    :pswitch_2
    const/4 v0, 0x7

    .line 423
    goto :goto_0

    .line 425
    :pswitch_3
    const/16 v0, 0xb

    .line 426
    goto :goto_0

    .line 428
    :pswitch_4
    const/16 v0, 0xf

    .line 429
    goto :goto_0

    .line 414
    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
        :pswitch_1
        :pswitch_2
        :pswitch_3
        :pswitch_4
    .end packed-switch
.end method

.method static initClickSound()V
    .locals 2

    .prologue
    .line 265
    const/4 v0, 0x0

    sput-object v0, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer_click:Landroid/media/MediaPlayer;

    .line 266
    new-instance v0, Landroid/media/MediaPlayer;

    invoke-direct {v0}, Landroid/media/MediaPlayer;-><init>()V

    sput-object v0, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer_click:Landroid/media/MediaPlayer;

    .line 267
    sget-object v0, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->inaviactivity:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    const/high16 v1, 0x7f050000

    invoke-static {v0, v1}, Landroid/media/MediaPlayer;->create(Landroid/content/Context;I)Landroid/media/MediaPlayer;

    move-result-object v0

    sput-object v0, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer_click:Landroid/media/MediaPlayer;

    .line 268
    sget-object v0, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer_click:Landroid/media/MediaPlayer;

    new-instance v1, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay$2;

    invoke-direct {v1}, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay$2;-><init>()V

    invoke-virtual {v0, v1}, Landroid/media/MediaPlayer;->setOnCompletionListener(Landroid/media/MediaPlayer$OnCompletionListener;)V

    .line 274
    return-void
.end method

.method static playstream([BZ)Z
    .locals 10
    .param p0, "src"    # [B
    .param p1, "samplePlay"    # Z

    .prologue
    const/4 v6, 0x1

    const/4 v7, 0x0

    .line 178
    sget-boolean v8, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->bSoundEnd:Z

    if-ne v8, v6, :cond_2

    .line 182
    const/4 v8, 0x0

    :try_start_0
    sput-boolean v8, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->bSoundEnd:Z

    .line 183
    sget-object v8, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->inaviactivity:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    sget-boolean v9, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->bSoundEnd:Z

    invoke-virtual {v8, v9}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->PlaySoundStatus(Z)V

    .line 184
    sget-object v8, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->inaviactivity:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    invoke-virtual {v8}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->SendVolumePause()V

    .line 187
    if-eqz p1, :cond_1

    .line 188
    new-instance v5, Ljava/lang/String;

    invoke-direct {v5, p0}, Ljava/lang/String;-><init>([B)V

    .line 200
    .local v5, "str_wave_path":Ljava/lang/String;
    :goto_0
    const-string v8, "wavewave"

    invoke-static {v8, v5}, Lcom/thinkware/sundo/inavi3d/LOGTW;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 204
    new-instance v3, Ljava/io/FileInputStream;

    invoke-direct {v3, v5}, Ljava/io/FileInputStream;-><init>(Ljava/lang/String;)V

    .line 206
    .local v3, "istr":Ljava/io/FileInputStream;
    sget-object v8, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer:Landroid/media/MediaPlayer;

    if-eqz v8, :cond_0

    .line 208
    sget-object v8, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer:Landroid/media/MediaPlayer;

    invoke-virtual {v8}, Landroid/media/MediaPlayer;->release()V

    .line 209
    const/4 v8, 0x0

    sput-object v8, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer:Landroid/media/MediaPlayer;

    .line 211
    :cond_0
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->getSoundVolume()F

    move-result v4

    .line 212
    .local v4, "soundVolume":F
    new-instance v8, Landroid/media/MediaPlayer;

    invoke-direct {v8}, Landroid/media/MediaPlayer;-><init>()V

    sput-object v8, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer:Landroid/media/MediaPlayer;

    .line 213
    sget-object v8, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer:Landroid/media/MediaPlayer;

    invoke-virtual {v8, v4, v4}, Landroid/media/MediaPlayer;->setVolume(FF)V

    .line 214
    sget-object v8, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer:Landroid/media/MediaPlayer;

    sget v9, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->INAVI_STREAM_TYPE:I

    invoke-virtual {v8, v9}, Landroid/media/MediaPlayer;->setAudioStreamType(I)V

    .line 215
    sget-object v8, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer:Landroid/media/MediaPlayer;

    invoke-virtual {v3}, Ljava/io/FileInputStream;->getFD()Ljava/io/FileDescriptor;

    move-result-object v9

    invoke-virtual {v8, v9}, Landroid/media/MediaPlayer;->setDataSource(Ljava/io/FileDescriptor;)V

    .line 216
    sget-object v8, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer:Landroid/media/MediaPlayer;

    invoke-virtual {v8}, Landroid/media/MediaPlayer;->prepare()V

    .line 217
    sget-object v8, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer:Landroid/media/MediaPlayer;

    new-instance v9, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay$1;

    invoke-direct {v9}, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay$1;-><init>()V

    invoke-virtual {v8, v9}, Landroid/media/MediaPlayer;->setOnCompletionListener(Landroid/media/MediaPlayer$OnCompletionListener;)V

    .line 226
    sget-object v8, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer:Landroid/media/MediaPlayer;

    invoke-virtual {v8}, Landroid/media/MediaPlayer;->start()V

    .line 241
    .end local v3    # "istr":Ljava/io/FileInputStream;
    .end local v4    # "soundVolume":F
    .end local v5    # "str_wave_path":Ljava/lang/String;
    :goto_1
    return v6

    .line 190
    :cond_1
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v8

    invoke-virtual {v8}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->IsThinkwareDevice()Z

    move-result v8

    if-ne v8, v6, :cond_3

    .line 191
    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    sget-object v9, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->DATA_DIRECTORY:Ljava/lang/String;

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    const-string v9, "/guidesound.wav"

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    .line 196
    .restart local v5    # "str_wave_path":Ljava/lang/String;
    :goto_2
    new-instance v0, Ljava/io/FileOutputStream;

    invoke-direct {v0, v5}, Ljava/io/FileOutputStream;-><init>(Ljava/lang/String;)V

    .line 198
    .local v0, "buf":Ljava/io/FileOutputStream;
    const/4 v8, 0x0

    array-length v9, p0

    invoke-virtual {v0, p0, v8, v9}, Ljava/io/FileOutputStream;->write([BII)V
    :try_end_0
    .catch Ljava/io/FileNotFoundException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_2
    .catch Ljava/lang/IllegalStateException; {:try_start_0 .. :try_end_0} :catch_3

    goto :goto_0

    .line 228
    .end local v0    # "buf":Ljava/io/FileOutputStream;
    .end local v5    # "str_wave_path":Ljava/lang/String;
    :catch_0
    move-exception v2

    .line 229
    .local v2, "e1":Ljava/io/FileNotFoundException;
    invoke-virtual {v2}, Ljava/io/FileNotFoundException;->printStackTrace()V

    .line 238
    .end local v2    # "e1":Ljava/io/FileNotFoundException;
    :goto_3
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->readyGuideSound()V

    :cond_2
    move v6, v7

    .line 241
    goto :goto_1

    .line 193
    :cond_3
    :try_start_1
    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    sget-object v9, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->kMapdataPath:Ljava/lang/String;

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    const-string v9, "/guidesound.wav"

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    :try_end_1
    .catch Ljava/io/FileNotFoundException; {:try_start_1 .. :try_end_1} :catch_0
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_1
    .catch Ljava/lang/IllegalArgumentException; {:try_start_1 .. :try_end_1} :catch_2
    .catch Ljava/lang/IllegalStateException; {:try_start_1 .. :try_end_1} :catch_3

    move-result-object v5

    .restart local v5    # "str_wave_path":Ljava/lang/String;
    goto :goto_2

    .line 230
    .end local v5    # "str_wave_path":Ljava/lang/String;
    :catch_1
    move-exception v1

    .line 231
    .local v1, "e":Ljava/io/IOException;
    invoke-virtual {v1}, Ljava/io/IOException;->printStackTrace()V

    goto :goto_3

    .line 232
    .end local v1    # "e":Ljava/io/IOException;
    :catch_2
    move-exception v1

    .line 233
    .local v1, "e":Ljava/lang/IllegalArgumentException;
    invoke-virtual {v1}, Ljava/lang/IllegalArgumentException;->printStackTrace()V

    goto :goto_3

    .line 234
    .end local v1    # "e":Ljava/lang/IllegalArgumentException;
    :catch_3
    move-exception v1

    .line 235
    .local v1, "e":Ljava/lang/IllegalStateException;
    invoke-virtual {v1}, Ljava/lang/IllegalStateException;->printStackTrace()V

    goto :goto_3
.end method

.method private static readyGuideSound()V
    .locals 2

    .prologue
    const/4 v1, 0x0

    .line 245
    sput-boolean v1, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->bplayclickStart:Z

    .line 246
    const/4 v0, 0x1

    sput-boolean v0, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->bSoundEnd:Z

    .line 247
    sput-boolean v1, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->bSoundCancel:Z

    .line 248
    sget-object v0, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->inaviactivity:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    sget-boolean v1, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->bSoundEnd:Z

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->PlaySoundStatus(Z)V

    .line 249
    sget-object v0, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->inaviactivity:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->SendVolumeResume()V

    .line 250
    sget-object v0, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer:Landroid/media/MediaPlayer;

    if-eqz v0, :cond_0

    .line 251
    sget-object v0, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer:Landroid/media/MediaPlayer;

    invoke-virtual {v0}, Landroid/media/MediaPlayer;->stop()V

    .line 252
    :cond_0
    return-void
.end method

.method public static releaseClickSound()V
    .locals 2

    .prologue
    .line 259
    const-string v0, "sound"

    const-string v1, " releaseClickSound "

    invoke-static {v0, v1}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 260
    sget-object v0, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->m_mediaplayer_click:Landroid/media/MediaPlayer;

    invoke-virtual {v0}, Landroid/media/MediaPlayer;->release()V

    .line 261
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->initClickSound()V

    .line 262
    return-void
.end method

.method public static volumeToIndex(I)I
    .locals 2
    .param p0, "vol"    # I

    .prologue
    .line 438
    const/4 v0, 0x0

    .line 440
    .local v0, "retIdx":I
    if-nez p0, :cond_1

    .line 441
    const/4 v0, 0x0

    .line 451
    :cond_0
    :goto_0
    return v0

    .line 442
    :cond_1
    const/4 v1, 0x1

    if-lt p0, v1, :cond_2

    const/4 v1, 0x3

    if-gt p0, v1, :cond_2

    .line 443
    const/4 v0, 0x1

    goto :goto_0

    .line 444
    :cond_2
    const/4 v1, 0x4

    if-lt p0, v1, :cond_3

    const/4 v1, 0x7

    if-gt p0, v1, :cond_3

    .line 445
    const/4 v0, 0x2

    goto :goto_0

    .line 446
    :cond_3
    const/16 v1, 0x8

    if-lt p0, v1, :cond_4

    const/16 v1, 0xb

    if-gt p0, v1, :cond_4

    .line 447
    const/4 v0, 0x3

    goto :goto_0

    .line 448
    :cond_4
    const/16 v1, 0xc

    if-lt p0, v1, :cond_0

    const/16 v1, 0x23

    if-gt p0, v1, :cond_0

    .line 449
    const/4 v0, 0x4

    goto :goto_0
.end method


# virtual methods
.method public SetInaviVolume(I)V
    .locals 2
    .param p1, "vol"    # I

    .prologue
    .line 79
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->getInstance()Lcom/thinkware/sundo/inavi3d/InaviConfig;

    move-result-object v0

    const/16 v1, 0x44

    invoke-virtual {v0, v1, p1}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->CNaviConfigSet(II)Z

    .line 80
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->getInstance()Lcom/thinkware/sundo/inavi3d/InaviConfig;

    move-result-object v0

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->SetConfigSave()Z

    .line 81
    return-void
.end method

.method initSound(Landroid/content/Context;)V
    .locals 1
    .param p1, "context"    # Landroid/content/Context;

    .prologue
    .line 407
    const-string v0, "audio"

    invoke-virtual {p1, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/media/AudioManager;

    sput-object v0, Lcom/thinkware/sundo/inavi3d/GuidanceSoundPlay;->mAudioManager:Landroid/media/AudioManager;

    .line 408
    return-void
.end method
