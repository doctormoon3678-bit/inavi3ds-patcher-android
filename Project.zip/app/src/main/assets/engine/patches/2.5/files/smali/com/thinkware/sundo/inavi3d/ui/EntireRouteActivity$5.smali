.class Lcom/thinkware/sundo/inavi3d/ui/EntireRouteActivity$5;
.super Ljava/lang/Object;
.source "EntireRouteActivity.java"

# interfaces
.implements Lcom/thinkware/sundo/inavi3d/INaviTask$iINaviTaskInterFace;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/thinkware/sundo/inavi3d/ui/EntireRouteActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/thinkware/sundo/inavi3d/ui/EntireRouteActivity;


# direct methods
.method constructor <init>(Lcom/thinkware/sundo/inavi3d/ui/EntireRouteActivity;)V
    .locals 0

    .prologue
    .line 384
    iput-object p1, p0, Lcom/thinkware/sundo/inavi3d/ui/EntireRouteActivity$5;->this$0:Lcom/thinkware/sundo/inavi3d/ui/EntireRouteActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public varargs doInBackground([Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3
    .param p1, "params"    # [Ljava/lang/Object;

    .prologue
    const/4 v2, 0x0

    .line 425
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/EntireRouteActivity$5;->this$0:Lcom/thinkware/sundo/inavi3d/ui/EntireRouteActivity;

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/ui/EntireRouteActivity;->initTabChild()V

    .line 427
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    move-result-object v0

    invoke-virtual {v0, v2}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->setEntireRouteViewModeValue(I)V

    .line 428
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v0

    const v1, 0x7f0b050a

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getView(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Lcom/thinkware/sundo/inavi3d/ui/component/GpsButton;

    invoke-virtual {v0, v2}, Lcom/thinkware/sundo/inavi3d/ui/component/GpsButton;->setFlightMode(I)V

    .line 429
    invoke-static {v2, v2}, Lcom/thinkware/sundo/inavi3d/Inavi;->ToggleViewModeSafe(IZ)Z

    .line 430
    const/4 v0, 0x0

    return-object v0
.end method

.method public onCanceled()V
    .locals 0

    .prologue
    .line 420
    return-void
.end method

.method public onPostExecute(Ljava/lang/Object;)V
    .locals 4
    .param p1, "result"    # Ljava/lang/Object;

    .prologue
    .line 395
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/EntireRouteActivity$5;->this$0:Lcom/thinkware/sundo/inavi3d/ui/EntireRouteActivity;

    const/4 v1, 0x1

    invoke-static {v0, v1}, Lcom/thinkware/sundo/inavi3d/ui/EntireRouteActivity;->access$800(Lcom/thinkware/sundo/inavi3d/ui/EntireRouteActivity;Z)V

    .line 396
    new-instance v0, Ljava/util/Timer;

    invoke-direct {v0}, Ljava/util/Timer;-><init>()V

    new-instance v1, Lcom/thinkware/sundo/inavi3d/ui/EntireRouteActivity$5$1;

    invoke-direct {v1, p0}, Lcom/thinkware/sundo/inavi3d/ui/EntireRouteActivity$5$1;-><init>(Lcom/thinkware/sundo/inavi3d/ui/EntireRouteActivity$5;)V

    const-wide/16 v2, 0x64

    invoke-virtual {v0, v1, v2, v3}, Ljava/util/Timer;->schedule(Ljava/util/TimerTask;J)V

    .line 414
    return-void
.end method

.method public onPreExecute()V
    .locals 1

    .prologue
    .line 389
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/EntireRouteActivity$5;->this$0:Lcom/thinkware/sundo/inavi3d/ui/EntireRouteActivity;

    invoke-static {v0}, Lcom/thinkware/sundo/inavi3d/ui/EntireRouteActivity;->access$700(Lcom/thinkware/sundo/inavi3d/ui/EntireRouteActivity;)V

    .line 390
    return-void
.end method
