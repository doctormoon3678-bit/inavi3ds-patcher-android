.class Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity$15;
.super Ljava/lang/Object;
.source "RoutePointManageActivity.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;


# direct methods
.method constructor <init>(Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;)V
    .locals 0

    .prologue
    .line 846
    iput-object p1, p0, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity$15;->this$0:Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 9
    .param p1, "v"    # Landroid/view/View;

    .prologue
    const/4 v5, 0x1

    const/4 v6, 0x0

    .line 851
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity$15;->this$0:Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;

    invoke-static {v4}, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;->access$900(Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;)V

    .line 852
    invoke-virtual {p1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v4

    check-cast v4, Landroid/view/View;

    invoke-virtual {v4}, Landroid/view/View;->getTag()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/Integer;

    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    move-result v0

    .line 853
    .local v0, "index":I
    move v3, v0

    .line 854
    .local v3, "rindex":I
    invoke-virtual {p1}, Landroid/view/View;->getId()I

    move-result v4

    packed-switch v4, :pswitch_data_0

    .line 911
    :goto_0
    return-void

    .line 858
    :pswitch_0
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity$15;->this$0:Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;

    invoke-static {v4}, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;->access$100(Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;)Lcom/thinkware/sundo/inavi3d/ui/component/DnDListView;

    move-result-object v7

    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity$15;->this$0:Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;

    invoke-static {v4}, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;->access$100(Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;)Lcom/thinkware/sundo/inavi3d/ui/component/DnDListView;

    move-result-object v4

    invoke-virtual {v4}, Lcom/thinkware/sundo/inavi3d/ui/component/DnDListView;->getDragMode()Z

    move-result v4

    if-nez v4, :cond_0

    move v4, v5

    :goto_1
    invoke-virtual {v7, v4}, Lcom/thinkware/sundo/inavi3d/ui/component/DnDListView;->setDragMode(Z)V

    .line 859
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity$15;->this$0:Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;

    iget-object v4, v4, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;->m_adapter:Lcom/thinkware/sundo/inavi3d/ui/adapter/RoutePointAdapter;

    iget-object v7, p0, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity$15;->this$0:Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;

    iget-object v7, v7, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;->m_adapter:Lcom/thinkware/sundo/inavi3d/ui/adapter/RoutePointAdapter;

    invoke-virtual {v7}, Lcom/thinkware/sundo/inavi3d/ui/adapter/RoutePointAdapter;->getDragMode()Z

    move-result v7

    if-nez v7, :cond_1

    :goto_2
    invoke-virtual {v4, v5}, Lcom/thinkware/sundo/inavi3d/ui/adapter/RoutePointAdapter;->setDragMode(Z)V

    .line 860
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity$15;->this$0:Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;

    iget-object v4, v4, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;->m_adapter:Lcom/thinkware/sundo/inavi3d/ui/adapter/RoutePointAdapter;

    invoke-virtual {v4}, Lcom/thinkware/sundo/inavi3d/ui/adapter/RoutePointAdapter;->notifyDataSetInvalidated()V

    .line 862
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity$15;->this$0:Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;

    invoke-static {v4}, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;->access$600(Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;)V

    goto :goto_0

    :cond_0
    move v4, v6

    .line 858
    goto :goto_1

    :cond_1
    move v5, v6

    .line 859
    goto :goto_2

    .line 867
    :pswitch_1
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity$15;->this$0:Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;

    iget-object v4, v4, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;->mManager:Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/RoutePointDataManager;

    const-string v4, "\uc9c0\uc810\uad00\ub9ac/\uc704\uce58\ubcf4\uae30"

    const-string v5, "\uc218\uc815"

    invoke-static {v4, v5, v3, v3, v6}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/RoutePointDataManager;->routePointManage(Ljava/lang/String;Ljava/lang/String;III)V

    .line 868
    new-instance v1, Landroid/content/Intent;

    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity$15;->this$0:Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;

    const-class v5, Lcom/thinkware/sundo/inavi3d/ui/GoalPointAddType;

    invoke-direct {v1, v4, v5}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 869
    .local v1, "intent":Landroid/content/Intent;
    if-nez v3, :cond_2

    .line 870
    const-string v4, "type"

    const/16 v5, 0xb

    invoke-virtual {v1, v4, v5}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 874
    :goto_3
    const-string v4, "index"

    invoke-virtual {v1, v4, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 875
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity$15;->this$0:Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;

    invoke-virtual {v4, v1}, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;->startActivity(Landroid/content/Intent;)V

    .line 876
    invoke-static {v6, v6}, Lcom/thinkware/sundo/inavi3d/Inavi;->ToggleViewModeSafe(IZ)Z

    .line 877
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity$15;->this$0:Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;

    invoke-static {v4}, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;->access$600(Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;)V

    goto :goto_0

    .line 872
    :cond_2
    const-string v4, "type"

    const/4 v5, 0x3

    invoke-virtual {v1, v4, v5}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    goto :goto_3

    .line 881
    .end local v1    # "intent":Landroid/content/Intent;
    :pswitch_2
    const/16 v4, 0x20

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v5

    const-string v7, ""

    const-string v8, "\uc120\ud0dd\ud55c \ubaa9\uc801\uc9c0\ub97c \uc0ad\uc81c\ud558\uc2dc\uaca0\uc2b5\ub2c8\uae4c?"

    invoke-static {v4, v5, v7, v8, v6}, Lcom/thinkware/sundo/inavi3d/ui/popup/PopupManager;->ShowPopup(ILandroid/content/Context;Ljava/lang/String;Ljava/lang/String;I)Lcom/thinkware/sundo/inavi3d/ui/popup/InaviPopup;

    .line 882
    new-instance v4, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity$15$1;

    invoke-direct {v4, p0, v3}, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity$15$1;-><init>(Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity$15;I)V

    invoke-static {v4}, Lcom/thinkware/sundo/inavi3d/ui/popup/PopupManager;->SetokListner(Landroid/view/View$OnClickListener;)Z

    goto/16 :goto_0

    .line 901
    :pswitch_3
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity$15;->this$0:Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;

    iget-object v4, v4, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;->mManager:Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/RoutePointDataManager;

    const v4, 0x22355

    invoke-static {v4, v3, v6}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/RoutePointDataManager;->routePointManage2(III)V

    .line 902
    new-instance v2, Landroid/content/Intent;

    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity$15;->this$0:Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;

    const-class v5, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    invoke-direct {v2, v4, v5}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 904
    .local v2, "msg":Landroid/content/Intent;
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    move-result-object v4

    iget-object v5, p0, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity$15;->this$0:Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;

    invoke-virtual {v4, v5, v2}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->startActivityToMap(Landroid/content/Context;Landroid/content/Intent;)V

    .line 905
    invoke-static {v6, v6}, Lcom/thinkware/sundo/inavi3d/Inavi;->ToggleViewModeSafe(IZ)Z

    .line 906
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity$15;->this$0:Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;

    iput-boolean v6, v4, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;->bRefresh:Z

    .line 908
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity$15;->this$0:Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;

    invoke-static {v4}, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;->access$600(Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;)V

    goto/16 :goto_0

    .line 854
    :pswitch_data_0
    .packed-switch 0x7f0b0227
        :pswitch_0
        :pswitch_1
        :pswitch_2
        :pswitch_3
    .end packed-switch
.end method
