.class public Lcom/thinkware/sundo/inavi3dservice/MMCModule;
.super Ljava/lang/Object;
.source "MMCModule.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/thinkware/sundo/inavi3dservice/MMCModule$GPSTYPE;,
        Lcom/thinkware/sundo/inavi3dservice/MMCModule$MSGTYPE;
    }
.end annotation


# static fields
.field protected static final MSG_GRAVITY:I = 0x3ea

.field protected static final MSG_MAPMATCH:I = 0x3e9

.field protected static final MSG_NMEA_LOGDRIVE:I = 0x3eb

.field protected static final MSG_SIMULATION:I = 0x3ec

.field private static final STATUS_GPSNOTFIX:I = 0x5

.field private static final STATUS_GRAVITY:I = 0x1

.field private static final STATUS_LOGGER:I = 0x4

.field private static final STATUS_MAPMATCH:I = 0x0

.field private static final STATUS_NMEA_LOGDRIVE:I = 0x2

.field public static final dummy_nmea:Ljava/lang/String; = "$GPGGA,000000.024,,,,,0,00,,,M,0.0,M,,0000*50\r\n$GPGSA,A,1,,,,,,,,,,,,,,,*1E\r\n$GPGSV,3,1,12,20,00,000,,10,00,000,35,31,00,000,,27,00,000,*7A\r\n$GPGSV,3,2,12,19,00,000,,07,00,000,,04,00,000,43,24,00,000,*71\r\n$GPGSV,3,3,12,16,00,000,,28,00,000,,26,00,000,,29,00,000,*78\r\n$GPRMC,000000.024,V,,,,,,,010407,,,N*49\r\n"

.field private static mm_mutex:Ljava/lang/Object;


# instance fields
.field private final DRGPSMODE:Ljava/lang/String;

.field private final INNERGPSMODE:Ljava/lang/String;

.field private LogThreadProc:Ljava/lang/Runnable;

.field private _gpsInfo:Lcom/tw/mapmatch/dataset/_GPSInfo;

.field private _mmcInfo:Lcom/tw/mapmatch/dataset/_MMCInfo;

.field private _satInfo:Lcom/tw/mapmatch/dataset/_SATInfo;

.field private bIsLogDrive:Z

.field private cmd01:Ljava/lang/String;

.field private cmd02:Ljava/lang/String;

.field private delay_tm:J

.field private delay_tm_for_DR:J

.field private fin:Ljava/io/FileInputStream;

.field private gravityModule:Lcom/thinkware/sundo/inavi3dservice/GravityModule;

.field private final locationListener:Landroid/location/LocationListener;

.field private location_timestamp:J

.field private m_LogThread:Ljava/lang/Thread;

.field private m_VirtualMMTM:J

.field private m_bIsCar:Z

.field private m_bIsGPSConfiguration:Z

.field private m_bIsGpsOkay:Z

.field private m_bIsRunning:[Z

.field private m_bIsSimulateStartStop:Z

.field private m_ctxtParent:Landroid/content/Context;

.field private m_delayTM_Nmea:J

.field private m_endTM_Location:J

.field private m_endTM_Nmea:J

.field private m_gi:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

.field private m_gi_dummy:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

.field private m_locManager:Landroid/location/LocationManager;

.field private m_mi:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

.field private m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

.field private m_mmcThread:Ljava/lang/Thread;

.field private m_nAccuracy:I

.field private m_nAltitude:I

.field private m_nCurrentMode:I

.field private m_nLatitude:I

.field private m_nLongitude:I

.field private m_nSpeedMode:I

.field private m_nUTC:[I

.field private m_nUTC_old:[I

.field private m_prevTime_getMMCInfo:J

.field private m_provider:Ljava/lang/String;

.field private m_sCourse:S

.field private m_sSpeed:S

.field private m_si:Lcom/tw/mapmatch/remote/mapmatch/SATInfo;

.field private m_si_dummy:Lcom/tw/mapmatch/remote/mapmatch/SATInfo;

.field private mmcHandler:Landroid/os/Handler;

.field private nmea0183Data:Ljava/lang/String;

.field private nmea0183Data_2:Ljava/lang/String;

.field private nmeaLength:I

.field private final nmeaListener:Landroid/location/GpsStatus$NmeaListener;

.field private nmea_timestamp:J

.field private obj:Ljava/lang/Object;

.field private reader:Ljava/io/BufferedReader;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .prologue
    .line 120
    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->mm_mutex:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .locals 10
    .param p1, "ctxt"    # Landroid/content/Context;

    .prologue
    const-wide/16 v8, 0x0

    const-wide/16 v6, -0x1

    const/4 v4, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x0

    .line 259
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 42
    iput-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    .line 43
    iput-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->gravityModule:Lcom/thinkware/sundo/inavi3dservice/GravityModule;

    .line 44
    iput-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_mmcInfo:Lcom/tw/mapmatch/dataset/_MMCInfo;

    .line 45
    iput-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_gpsInfo:Lcom/tw/mapmatch/dataset/_GPSInfo;

    .line 46
    iput-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_satInfo:Lcom/tw/mapmatch/dataset/_SATInfo;

    .line 48
    iput-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_gi:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    .line 49
    iput-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mi:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    .line 50
    iput-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_si:Lcom/tw/mapmatch/remote/mapmatch/SATInfo;

    .line 60
    iput v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->nmeaLength:I

    .line 65
    const/4 v0, 0x3

    new-array v0, v0, [I

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nUTC:[I

    .line 66
    const/4 v0, 0x3

    new-array v0, v0, [I

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nUTC_old:[I

    .line 67
    iput v4, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nSpeedMode:I

    .line 76
    iput-wide v8, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->delay_tm:J

    .line 77
    iput-wide v8, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->delay_tm_for_DR:J

    .line 80
    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v0

    iput-wide v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_VirtualMMTM:J

    .line 82
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    iput-wide v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_prevTime_getMMCInfo:J

    .line 84
    iput-wide v6, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_endTM_Location:J

    .line 85
    iput-wide v6, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_endTM_Nmea:J

    .line 86
    iput-wide v8, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_delayTM_Nmea:J

    .line 89
    const/4 v0, 0x6

    new-array v0, v0, [Z

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsRunning:[Z

    .line 91
    iput-boolean v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsGpsOkay:Z

    .line 92
    iput-boolean v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsSimulateStartStop:Z

    .line 93
    iput-boolean v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsGPSConfiguration:Z

    .line 96
    iput v4, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nCurrentMode:I

    .line 114
    iput-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_locManager:Landroid/location/LocationManager;

    .line 119
    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->obj:Ljava/lang/Object;

    .line 130
    const-string v0, "force_inavi_nmea_on"

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->cmd01:Ljava/lang/String;

    .line 131
    const-string v0, "force_inavi_nmea_off"

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->cmd02:Ljava/lang/String;

    .line 133
    const-string v0, "0"

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->INNERGPSMODE:Ljava/lang/String;

    .line 134
    const-string v0, "1"

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->DRGPSMODE:Ljava/lang/String;

    .line 255
    iput-boolean v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->bIsLogDrive:Z

    .line 984
    new-instance v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule$1;

    invoke-direct {v0, p0}, Lcom/thinkware/sundo/inavi3dservice/MMCModule$1;-><init>(Lcom/thinkware/sundo/inavi3dservice/MMCModule;)V

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->nmeaListener:Landroid/location/GpsStatus$NmeaListener;

    .line 1070
    new-instance v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule$2;

    invoke-direct {v0, p0}, Lcom/thinkware/sundo/inavi3dservice/MMCModule$2;-><init>(Lcom/thinkware/sundo/inavi3dservice/MMCModule;)V

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->locationListener:Landroid/location/LocationListener;

    .line 1096
    new-instance v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule$3;

    invoke-direct {v0, p0}, Lcom/thinkware/sundo/inavi3dservice/MMCModule$3;-><init>(Lcom/thinkware/sundo/inavi3dservice/MMCModule;)V

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->LogThreadProc:Ljava/lang/Runnable;

    .line 1435
    new-instance v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule$4;

    invoke-direct {v0, p0}, Lcom/thinkware/sundo/inavi3dservice/MMCModule$4;-><init>(Lcom/thinkware/sundo/inavi3dservice/MMCModule;)V

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->mmcHandler:Landroid/os/Handler;

    .line 260
    iput-object p1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_ctxtParent:Landroid/content/Context;

    .line 261
    new-instance v0, Lcom/tw/mapmatch/jni/Natives;

    invoke-direct {v0}, Lcom/tw/mapmatch/jni/Natives;-><init>()V

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    .line 263
    new-instance v0, Lcom/thinkware/sundo/inavi3dservice/GravityModule;

    iget-object v1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->mmcHandler:Landroid/os/Handler;

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    invoke-direct {v0, p1, v1, v2}, Lcom/thinkware/sundo/inavi3dservice/GravityModule;-><init>(Landroid/content/Context;Landroid/os/Handler;Lcom/tw/mapmatch/jni/Natives;)V

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->gravityModule:Lcom/thinkware/sundo/inavi3dservice/GravityModule;

    .line 265
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsRunning:[Z

    aput-boolean v3, v0, v3

    .line 266
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsRunning:[Z

    aput-boolean v3, v0, v4

    .line 267
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsRunning:[Z

    const/4 v1, 0x2

    aput-boolean v3, v0, v1

    .line 268
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsRunning:[Z

    const/4 v1, 0x4

    aput-boolean v3, v0, v1

    .line 269
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsRunning:[Z

    const/4 v1, 0x5

    aput-boolean v3, v0, v1

    .line 271
    iput-wide v6, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->nmea_timestamp:J

    .line 272
    iput-wide v6, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->location_timestamp:J

    .line 274
    new-instance v0, Lcom/tw/mapmatch/dataset/_MMCInfo;

    invoke-direct {v0}, Lcom/tw/mapmatch/dataset/_MMCInfo;-><init>()V

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_mmcInfo:Lcom/tw/mapmatch/dataset/_MMCInfo;

    .line 275
    new-instance v0, Lcom/tw/mapmatch/dataset/_GPSInfo;

    invoke-direct {v0}, Lcom/tw/mapmatch/dataset/_GPSInfo;-><init>()V

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_gpsInfo:Lcom/tw/mapmatch/dataset/_GPSInfo;

    .line 276
    new-instance v0, Lcom/tw/mapmatch/dataset/_SATInfo;

    invoke-direct {v0}, Lcom/tw/mapmatch/dataset/_SATInfo;-><init>()V

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_satInfo:Lcom/tw/mapmatch/dataset/_SATInfo;

    .line 278
    new-instance v0, Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    invoke-direct {v0}, Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;-><init>()V

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_gi:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    .line 279
    new-instance v0, Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    invoke-direct {v0}, Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;-><init>()V

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mi:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    .line 280
    new-instance v0, Lcom/tw/mapmatch/remote/mapmatch/SATInfo;

    invoke-direct {v0}, Lcom/tw/mapmatch/remote/mapmatch/SATInfo;-><init>()V

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_si:Lcom/tw/mapmatch/remote/mapmatch/SATInfo;

    .line 282
    new-instance v0, Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    invoke-direct {v0}, Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;-><init>()V

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_gi_dummy:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    .line 284
    new-instance v0, Lcom/tw/mapmatch/remote/mapmatch/SATInfo;

    invoke-direct {v0}, Lcom/tw/mapmatch/remote/mapmatch/SATInfo;-><init>()V

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_si_dummy:Lcom/tw/mapmatch/remote/mapmatch/SATInfo;

    .line 286
    iput-boolean v4, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsCar:Z

    .line 287
    return-void
.end method

.method static synthetic access$000(Lcom/thinkware/sundo/inavi3dservice/MMCModule;)[Z
    .locals 1
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3dservice/MMCModule;

    .prologue
    .line 40
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsRunning:[Z

    return-object v0
.end method

.method static synthetic access$1000(Lcom/thinkware/sundo/inavi3dservice/MMCModule;)Lcom/tw/mapmatch/jni/Natives;
    .locals 1
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3dservice/MMCModule;

    .prologue
    .line 40
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    return-object v0
.end method

.method static synthetic access$102(Lcom/thinkware/sundo/inavi3dservice/MMCModule;J)J
    .locals 1
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3dservice/MMCModule;
    .param p1, "x1"    # J

    .prologue
    .line 40
    iput-wide p1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->nmea_timestamp:J

    return-wide p1
.end method

.method static synthetic access$1100(Lcom/thinkware/sundo/inavi3dservice/MMCModule;SS)V
    .locals 0
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3dservice/MMCModule;
    .param p1, "x1"    # S
    .param p2, "x2"    # S

    .prologue
    .line 40
    invoke-direct {p0, p1, p2}, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->resetGps(SS)V

    return-void
.end method

.method static synthetic access$1200(Lcom/thinkware/sundo/inavi3dservice/MMCModule;)Z
    .locals 1
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3dservice/MMCModule;

    .prologue
    .line 40
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsCar:Z

    return v0
.end method

.method static synthetic access$1300(Lcom/thinkware/sundo/inavi3dservice/MMCModule;)Ljava/lang/Thread;
    .locals 1
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3dservice/MMCModule;

    .prologue
    .line 40
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_LogThread:Ljava/lang/Thread;

    return-object v0
.end method

.method static synthetic access$1302(Lcom/thinkware/sundo/inavi3dservice/MMCModule;Ljava/lang/Thread;)Ljava/lang/Thread;
    .locals 0
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3dservice/MMCModule;
    .param p1, "x1"    # Ljava/lang/Thread;

    .prologue
    .line 40
    iput-object p1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_LogThread:Ljava/lang/Thread;

    return-object p1
.end method

.method static synthetic access$1400(Lcom/thinkware/sundo/inavi3dservice/MMCModule;)Ljava/lang/Runnable;
    .locals 1
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3dservice/MMCModule;

    .prologue
    .line 40
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->LogThreadProc:Ljava/lang/Runnable;

    return-object v0
.end method

.method static synthetic access$200(Lcom/thinkware/sundo/inavi3dservice/MMCModule;)Ljava/lang/String;
    .locals 1
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3dservice/MMCModule;

    .prologue
    .line 40
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->nmea0183Data:Ljava/lang/String;

    return-object v0
.end method

.method static synthetic access$202(Lcom/thinkware/sundo/inavi3dservice/MMCModule;Ljava/lang/String;)Ljava/lang/String;
    .locals 0
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3dservice/MMCModule;
    .param p1, "x1"    # Ljava/lang/String;

    .prologue
    .line 40
    iput-object p1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->nmea0183Data:Ljava/lang/String;

    return-object p1
.end method

.method static synthetic access$300(Lcom/thinkware/sundo/inavi3dservice/MMCModule;)I
    .locals 1
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3dservice/MMCModule;

    .prologue
    .line 40
    iget v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->nmeaLength:I

    return v0
.end method

.method static synthetic access$302(Lcom/thinkware/sundo/inavi3dservice/MMCModule;I)I
    .locals 0
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3dservice/MMCModule;
    .param p1, "x1"    # I

    .prologue
    .line 40
    iput p1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->nmeaLength:I

    return p1
.end method

.method static synthetic access$400(Lcom/thinkware/sundo/inavi3dservice/MMCModule;)J
    .locals 2
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3dservice/MMCModule;

    .prologue
    .line 40
    iget-wide v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_delayTM_Nmea:J

    return-wide v0
.end method

.method static synthetic access$402(Lcom/thinkware/sundo/inavi3dservice/MMCModule;J)J
    .locals 1
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3dservice/MMCModule;
    .param p1, "x1"    # J

    .prologue
    .line 40
    iput-wide p1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_delayTM_Nmea:J

    return-wide p1
.end method

.method static synthetic access$414(Lcom/thinkware/sundo/inavi3dservice/MMCModule;J)J
    .locals 3
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3dservice/MMCModule;
    .param p1, "x1"    # J

    .prologue
    .line 40
    iget-wide v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_delayTM_Nmea:J

    add-long/2addr v0, p1

    iput-wide v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_delayTM_Nmea:J

    return-wide v0
.end method

.method static synthetic access$500(Lcom/thinkware/sundo/inavi3dservice/MMCModule;)J
    .locals 2
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3dservice/MMCModule;

    .prologue
    .line 40
    iget-wide v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_endTM_Nmea:J

    return-wide v0
.end method

.method static synthetic access$502(Lcom/thinkware/sundo/inavi3dservice/MMCModule;J)J
    .locals 1
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3dservice/MMCModule;
    .param p1, "x1"    # J

    .prologue
    .line 40
    iput-wide p1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_endTM_Nmea:J

    return-wide p1
.end method

.method static synthetic access$600()Ljava/lang/Object;
    .locals 1

    .prologue
    .line 40
    sget-object v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->mm_mutex:Ljava/lang/Object;

    return-object v0
.end method

.method static synthetic access$700(Lcom/thinkware/sundo/inavi3dservice/MMCModule;)Lcom/thinkware/sundo/inavi3dservice/GravityModule;
    .locals 1
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3dservice/MMCModule;

    .prologue
    .line 40
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->gravityModule:Lcom/thinkware/sundo/inavi3dservice/GravityModule;

    return-object v0
.end method

.method static synthetic access$800(Lcom/thinkware/sundo/inavi3dservice/MMCModule;I)V
    .locals 0
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3dservice/MMCModule;
    .param p1, "x1"    # I

    .prologue
    .line 40
    invoke-direct {p0, p1}, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->doRealMapMatch(I)V

    return-void
.end method

.method static synthetic access$900(Lcom/thinkware/sundo/inavi3dservice/MMCModule;)Ljava/lang/String;
    .locals 1
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3dservice/MMCModule;

    .prologue
    .line 40
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->nmea0183Data_2:Ljava/lang/String;

    return-object v0
.end method

.method static synthetic access$902(Lcom/thinkware/sundo/inavi3dservice/MMCModule;Ljava/lang/String;)Ljava/lang/String;
    .locals 0
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3dservice/MMCModule;
    .param p1, "x1"    # Ljava/lang/String;

    .prologue
    .line 40
    iput-object p1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->nmea0183Data_2:Ljava/lang/String;

    return-object p1
.end method

.method private createLocationManager()V
    .locals 7

    .prologue
    .line 291
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_locManager:Landroid/location/LocationManager;

    if-nez v0, :cond_1

    .line 292
    const-string v6, "location"

    .line 294
    .local v6, "context":Ljava/lang/String;
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_ctxtParent:Landroid/content/Context;

    invoke-virtual {v0, v6}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/location/LocationManager;

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_locManager:Landroid/location/LocationManager;

    .line 303
    const-string v0, "gps"

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_provider:Ljava/lang/String;

    .line 305
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v0

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->IsThinkwareDevice()Z

    move-result v0

    const/4 v1, 0x1

    if-ne v0, v1, :cond_0

    .line 309
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_locManager:Landroid/location/LocationManager;

    iget-object v1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_provider:Ljava/lang/String;

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->cmd01:Ljava/lang/String;

    const/4 v3, 0x0

    invoke-virtual {v0, v1, v2, v3}, Landroid/location/LocationManager;->sendExtraCommand(Ljava/lang/String;Ljava/lang/String;Landroid/os/Bundle;)Z

    .line 314
    :cond_0
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_locManager:Landroid/location/LocationManager;

    iget-object v1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->nmeaListener:Landroid/location/GpsStatus$NmeaListener;

    invoke-virtual {v0, v1}, Landroid/location/LocationManager;->addNmeaListener(Landroid/location/GpsStatus$NmeaListener;)Z

    .line 0
    :try_start_0
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_locManager:Landroid/location/LocationManager;

    new-instance v1, Lcom/thinkware/sundo/inavi3dservice/MMCModule$5;

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->nmeaListener:Landroid/location/GpsStatus$NmeaListener;

    invoke-direct {v1, v2}, Lcom/thinkware/sundo/inavi3dservice/MMCModule$5;-><init>(Landroid/location/GpsStatus$NmeaListener;)V

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/location/LocationManager;->addNmeaListener(Landroid/location/OnNmeaMessageListener;Landroid/os/Handler;)Z
    :try_end_0
    .catch Ljava/lang/Throwable; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception v0

    .line 315
    :goto_0
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_locManager:Landroid/location/LocationManager;

    iget-object v1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_provider:Ljava/lang/String;

    const-wide/16 v2, 0x3e8

    const/4 v4, 0x0

    iget-object v5, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->locationListener:Landroid/location/LocationListener;

    invoke-virtual/range {v0 .. v5}, Landroid/location/LocationManager;->requestLocationUpdates(Ljava/lang/String;JFLandroid/location/LocationListener;)V

    .line 317
    .end local v6    # "context":Ljava/lang/String;
    :cond_1
    return-void
.end method

.method private doRealMapMatch(I)V
    .locals 6
    .param p1, "nMode"    # I

    .prologue
    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v2, 0x0

    .line 605
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->gravityModule:Lcom/thinkware/sundo/inavi3dservice/GravityModule;

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3dservice/GravityModule;->getGPSInfo()Lcom/tw/mapmatch/dataset/_GPSInfo;

    move-result-object v0

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_gpsInfo:Lcom/tw/mapmatch/dataset/_GPSInfo;

    .line 613
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_gpsInfo:Lcom/tw/mapmatch/dataset/_GPSInfo;

    if-eqz v0, :cond_0

    .line 615
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nUTC:[I

    iget-object v1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_gpsInfo:Lcom/tw/mapmatch/dataset/_GPSInfo;

    iget-object v1, v1, Lcom/tw/mapmatch/dataset/_GPSInfo;->UTC:[B

    aget-byte v1, v1, v2

    aput v1, v0, v2

    .line 616
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nUTC:[I

    iget-object v1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_gpsInfo:Lcom/tw/mapmatch/dataset/_GPSInfo;

    iget-object v1, v1, Lcom/tw/mapmatch/dataset/_GPSInfo;->UTC:[B

    aget-byte v1, v1, v3

    aput v1, v0, v3

    .line 617
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nUTC:[I

    iget-object v1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_gpsInfo:Lcom/tw/mapmatch/dataset/_GPSInfo;

    iget-object v1, v1, Lcom/tw/mapmatch/dataset/_GPSInfo;->UTC:[B

    aget-byte v1, v1, v4

    aput v1, v0, v4

    .line 619
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_gpsInfo:Lcom/tw/mapmatch/dataset/_GPSInfo;

    iget-object v0, v0, Lcom/tw/mapmatch/dataset/_GPSInfo;->UTC:[B

    aget-byte v0, v0, v2

    if-nez v0, :cond_1

    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_gpsInfo:Lcom/tw/mapmatch/dataset/_GPSInfo;

    iget-object v0, v0, Lcom/tw/mapmatch/dataset/_GPSInfo;->UTC:[B

    aget-byte v0, v0, v3

    if-nez v0, :cond_1

    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_gpsInfo:Lcom/tw/mapmatch/dataset/_GPSInfo;

    iget-object v0, v0, Lcom/tw/mapmatch/dataset/_GPSInfo;->UTC:[B

    aget-byte v0, v0, v4

    if-nez v0, :cond_1

    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_gpsInfo:Lcom/tw/mapmatch/dataset/_GPSInfo;

    iget v0, v0, Lcom/tw/mapmatch/dataset/_GPSInfo;->Lon:I

    if-nez v0, :cond_1

    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_gpsInfo:Lcom/tw/mapmatch/dataset/_GPSInfo;

    iget v0, v0, Lcom/tw/mapmatch/dataset/_GPSInfo;->Lat:I

    if-nez v0, :cond_1

    .line 622
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsRunning:[Z

    aput-boolean v3, v0, v5

    .line 657
    :cond_0
    :goto_0
    return-void

    .line 624
    :cond_1
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nUTC:[I

    aget v0, v0, v2

    iget-object v1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nUTC_old:[I

    aget v1, v1, v2

    if-ne v0, v1, :cond_2

    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nUTC:[I

    aget v0, v0, v3

    iget-object v1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nUTC_old:[I

    aget v1, v1, v3

    if-ne v0, v1, :cond_2

    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nUTC:[I

    aget v0, v0, v4

    iget-object v1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nUTC_old:[I

    aget v1, v1, v4

    if-eq v0, v1, :cond_0

    .line 626
    :cond_2
    const-wide/16 v0, 0x0

    iput-wide v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->delay_tm_for_DR:J

    .line 627
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsRunning:[Z

    aput-boolean v2, v0, v5

    .line 629
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nUTC_old:[I

    iget-object v1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nUTC:[I

    aget v1, v1, v2

    aput v1, v0, v2

    .line 630
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nUTC_old:[I

    iget-object v1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nUTC:[I

    aget v1, v1, v3

    aput v1, v0, v3

    .line 631
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nUTC_old:[I

    iget-object v1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nUTC:[I

    aget v1, v1, v4

    aput v1, v0, v4

    .line 633
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->obj:Ljava/lang/Object;

    monitor-enter v1

    .line 638
    :try_start_0
    iput p1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nCurrentMode:I

    .line 640
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    const/4 v2, 0x0

    iget v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nCurrentMode:I

    invoke-virtual {v0, v2, v3}, Lcom/tw/mapmatch/jni/Natives;->nativeMapMatch(ZI)I

    .line 646
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    invoke-virtual {v0}, Lcom/tw/mapmatch/jni/Natives;->nativeGetMMCInfo()Lcom/tw/mapmatch/dataset/_MMCInfo;

    move-result-object v0

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_mmcInfo:Lcom/tw/mapmatch/dataset/_MMCInfo;

    .line 647
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_mmcInfo:Lcom/tw/mapmatch/dataset/_MMCInfo;

    invoke-direct {p0, v0}, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->setMMCInfo(Lcom/tw/mapmatch/dataset/_MMCInfo;)V

    .line 650
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_gpsInfo:Lcom/tw/mapmatch/dataset/_GPSInfo;

    invoke-direct {p0, v0}, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->setGPSInfo(Lcom/tw/mapmatch/dataset/_GPSInfo;)V

    .line 652
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    invoke-virtual {v0}, Lcom/tw/mapmatch/jni/Natives;->nativeGetSATInfo()Lcom/tw/mapmatch/dataset/_SATInfo;

    move-result-object v0

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_satInfo:Lcom/tw/mapmatch/dataset/_SATInfo;

    .line 653
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_satInfo:Lcom/tw/mapmatch/dataset/_SATInfo;

    invoke-direct {p0, v0}, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->setSATInfo(Lcom/tw/mapmatch/dataset/_SATInfo;)V

    .line 654
    monitor-exit v1

    goto :goto_0

    :catchall_0
    move-exception v0

    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw v0
.end method

.method private doVirtualMapMatch()V
    .locals 12

    .prologue
    const/4 v6, 0x1

    .line 682
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_ctxtParent:Landroid/content/Context;

    invoke-virtual {v3}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v3

    const-string v4, "gps"

    invoke-direct {p0, v3, v4}, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->isLocationProviderEnabled(Landroid/content/ContentResolver;Ljava/lang/String;)Z

    move-result v3

    iput-boolean v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsGPSConfiguration:Z

    .line 685
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    if-eqz v3, :cond_1

    .line 687
    const/4 v2, 0x0

    .line 689
    .local v2, "nRet":I
    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v0

    .line 690
    .local v0, "curTime":J
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->obj:Ljava/lang/Object;

    monitor-enter v4

    .line 692
    :try_start_0
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsRunning:[Z

    const/4 v5, 0x5

    aget-boolean v3, v3, v5

    if-ne v3, v6, :cond_3

    .line 694
    iget-wide v6, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_VirtualMMTM:J

    sub-long v6, v0, v6

    iput-wide v6, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->delay_tm:J

    .line 695
    iget-wide v6, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->delay_tm_for_DR:J

    iget-wide v8, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->delay_tm:J

    const-wide/32 v10, 0xf4240

    div-long/2addr v8, v10

    add-long/2addr v6, v8

    iput-wide v6, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->delay_tm_for_DR:J

    .line 697
    iget-wide v6, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->delay_tm_for_DR:J

    const-wide/16 v8, 0x384

    cmp-long v3, v6, v8

    if-lez v3, :cond_2

    .line 698
    const-wide/16 v6, 0x0

    iput-wide v6, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->delay_tm_for_DR:J

    .line 699
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    const/4 v5, 0x0

    iget v6, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nCurrentMode:I

    invoke-virtual {v3, v5, v6}, Lcom/tw/mapmatch/jni/Natives;->nativeMapMatch(ZI)I

    .line 702
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    invoke-virtual {v3}, Lcom/tw/mapmatch/jni/Natives;->nativeGetSATInfo()Lcom/tw/mapmatch/dataset/_SATInfo;

    move-result-object v3

    iput-object v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_satInfo:Lcom/tw/mapmatch/dataset/_SATInfo;

    .line 703
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_satInfo:Lcom/tw/mapmatch/dataset/_SATInfo;

    invoke-direct {p0, v3}, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->setSATInfo(Lcom/tw/mapmatch/dataset/_SATInfo;)V

    .line 714
    :cond_0
    :goto_0
    invoke-direct {p0}, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->getGpsStatus()I

    move-result v2

    .line 715
    if-nez v2, :cond_4

    .line 716
    const/4 v3, 0x0

    iput-boolean v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsGpsOkay:Z

    .line 722
    :goto_1
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    invoke-virtual {v3}, Lcom/tw/mapmatch/jni/Natives;->nativeGetMMCInfo()Lcom/tw/mapmatch/dataset/_MMCInfo;

    move-result-object v3

    iput-object v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_mmcInfo:Lcom/tw/mapmatch/dataset/_MMCInfo;

    .line 723
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_mmcInfo:Lcom/tw/mapmatch/dataset/_MMCInfo;

    invoke-direct {p0, v3}, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->setMMCInfo(Lcom/tw/mapmatch/dataset/_MMCInfo;)V

    .line 727
    monitor-exit v4
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 730
    iput-wide v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_VirtualMMTM:J

    .line 733
    .end local v0    # "curTime":J
    .end local v2    # "nRet":I
    :cond_1
    return-void

    .line 706
    .restart local v0    # "curTime":J
    .restart local v2    # "nRet":I
    :cond_2
    :try_start_1
    iget-boolean v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsSimulateStartStop:Z

    if-eqz v3, :cond_0

    .line 707
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    const/4 v5, 0x1

    iget v6, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nCurrentMode:I

    invoke-virtual {v3, v5, v6}, Lcom/tw/mapmatch/jni/Natives;->nativeMapMatch(ZI)I

    goto :goto_0

    .line 727
    :catchall_0
    move-exception v3

    monitor-exit v4
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw v3

    .line 711
    :cond_3
    :try_start_2
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    const/4 v5, 0x1

    iget v6, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nCurrentMode:I

    invoke-virtual {v3, v5, v6}, Lcom/tw/mapmatch/jni/Natives;->nativeMapMatch(ZI)I

    goto :goto_0

    .line 718
    :cond_4
    const/4 v3, 0x1

    iput-boolean v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsGpsOkay:Z
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    goto :goto_1
.end method

.method private getGpsMode()Ljava/lang/String;
    .locals 5

    .prologue
    .line 353
    const-string v2, ""

    .line 355
    .local v2, "line":Ljava/lang/String;
    :try_start_0
    invoke-static {}, Ljava/lang/Runtime;->getRuntime()Ljava/lang/Runtime;

    move-result-object v3

    const-string v4, "getprop persist.sys.drgps"

    invoke-virtual {v3, v4}, Ljava/lang/Runtime;->exec(Ljava/lang/String;)Ljava/lang/Process;

    move-result-object v1

    .line 356
    .local v1, "ifc":Ljava/lang/Process;
    new-instance v0, Ljava/io/BufferedReader;

    new-instance v3, Ljava/io/InputStreamReader;

    invoke-virtual {v1}, Ljava/lang/Process;->getInputStream()Ljava/io/InputStream;

    move-result-object v4

    invoke-direct {v3, v4}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;)V

    invoke-direct {v0, v3}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V

    .line 357
    .local v0, "bis":Ljava/io/BufferedReader;
    invoke-virtual {v0}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    move-result-object v2

    .line 358
    invoke-virtual {v1}, Ljava/lang/Process;->destroy()V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    .line 362
    .end local v0    # "bis":Ljava/io/BufferedReader;
    .end local v1    # "ifc":Ljava/lang/Process;
    :goto_0
    const-string v3, ""

    invoke-virtual {v2, v3}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_0

    const-string v2, "0"

    .line 363
    :cond_0
    return-object v2

    .line 359
    :catch_0
    move-exception v3

    goto :goto_0
.end method

.method private getGpsStatus()I
    .locals 10

    .prologue
    .line 1129
    const/4 v0, 0x0

    .line 1130
    .local v0, "bIsLocation":Z
    const/4 v1, 0x0

    .line 1132
    .local v1, "bIsNmea":Z
    const/4 v4, 0x0

    .line 1135
    .local v4, "nRet":I
    iget-wide v6, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_endTM_Location:J

    const-wide/16 v8, 0x0

    cmp-long v5, v6, v8

    if-gez v5, :cond_2

    .line 1137
    const/4 v0, 0x0

    .line 1151
    :goto_0
    iget-wide v6, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_endTM_Nmea:J

    const-wide/16 v8, 0x0

    cmp-long v5, v6, v8

    if-gez v5, :cond_4

    .line 1153
    const/4 v1, 0x0

    .line 1166
    :goto_1
    const/4 v5, 0x1

    if-ne v1, v5, :cond_6

    .line 1167
    const/4 v4, 0x2

    .line 1172
    :cond_0
    :goto_2
    iget-object v5, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_gi:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    iget-short v5, v5, Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;->UTC_hh:S

    if-nez v5, :cond_1

    iget-object v5, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_gi:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    iget-short v5, v5, Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;->UTC_mm:S

    if-nez v5, :cond_1

    iget-object v5, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_gi:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    iget-short v5, v5, Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;->UTC_ss:S

    if-nez v5, :cond_1

    .line 1173
    const/4 v4, 0x0

    .line 1175
    :cond_1
    return v4

    .line 1139
    :cond_2
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v6

    iget-wide v8, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_endTM_Location:J

    sub-long v2, v6, v8

    .line 1141
    .local v2, "delay_location":J
    const-wide/16 v6, 0xbb8

    cmp-long v5, v2, v6

    if-lez v5, :cond_3

    .line 1143
    const/4 v0, 0x0

    goto :goto_0

    .line 1146
    :cond_3
    const/4 v0, 0x1

    goto :goto_0

    .line 1155
    .end local v2    # "delay_location":J
    :cond_4
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v6

    iget-wide v8, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_endTM_Nmea:J

    sub-long v2, v6, v8

    .line 1157
    .restart local v2    # "delay_location":J
    const-wide/16 v6, 0xbb8

    cmp-long v5, v2, v6

    if-lez v5, :cond_5

    .line 1159
    const/4 v1, 0x0

    goto :goto_1

    .line 1162
    :cond_5
    const/4 v1, 0x1

    goto :goto_1

    .line 1168
    .end local v2    # "delay_location":J
    :cond_6
    const/4 v5, 0x1

    if-ne v0, v5, :cond_0

    .line 1169
    const/4 v4, 0x1

    goto :goto_2
.end method

.method private isLocationProviderEnabled(Landroid/content/ContentResolver;Ljava/lang/String;)Z
    .locals 4
    .param p1, "cr"    # Landroid/content/ContentResolver;
    .param p2, "provider"    # Ljava/lang/String;

    .prologue
    .line 1184
    const/4 v1, 0x0

    :try_start_0
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_ctxtParent:Landroid/content/Context;

    const-string v3, "location"

    invoke-virtual {v2, v3}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/location/LocationManager;

    invoke-virtual {v2, p2}, Landroid/location/LocationManager;->isProviderEnabled(Ljava/lang/String;)Z

    move-result v1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    .line 1187
    :catch_0
    move-exception v2

    .line 1188
    const/4 v1, 0x1

    .line 1192
    :goto_0
    return v1
.end method

.method private resetGps(SS)V
    .locals 8
    .param p1, "gpsType"    # S
    .param p2, "msgType"    # S

    .prologue
    const/4 v7, 0x0

    const/4 v6, 0x1

    .line 1348
    sget-object v5, Lcom/thinkware/sundo/inavi3dservice/MMCModule$GPSTYPE;->ANDROID_DEFAULT:Lcom/thinkware/sundo/inavi3dservice/MMCModule$GPSTYPE;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3dservice/MMCModule$GPSTYPE;->value()S

    move-result v5

    if-ne p1, v5, :cond_4

    .line 1349
    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    .line 1351
    .local v0, "extras":Landroid/os/Bundle;
    sget-object v5, Lcom/thinkware/sundo/inavi3dservice/MMCModule$MSGTYPE;->FACTORYRESET:Lcom/thinkware/sundo/inavi3dservice/MMCModule$MSGTYPE;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3dservice/MMCModule$MSGTYPE;->value()S

    move-result v5

    if-ne p2, v5, :cond_1

    .line 1352
    const-string v5, "all"

    invoke-virtual {v0, v5, v6}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 1353
    iget-object v5, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_locManager:Landroid/location/LocationManager;

    const-string v6, "gps"

    const-string v7, "delete_aiding_data"

    invoke-virtual {v5, v6, v7, v0}, Landroid/location/LocationManager;->sendExtraCommand(Ljava/lang/String;Ljava/lang/String;Landroid/os/Bundle;)Z

    .line 1434
    .end local v0    # "extras":Landroid/os/Bundle;
    :cond_0
    :goto_0
    return-void

    .line 1355
    .restart local v0    # "extras":Landroid/os/Bundle;
    :cond_1
    sget-object v5, Lcom/thinkware/sundo/inavi3dservice/MMCModule$MSGTYPE;->COLDSTART:Lcom/thinkware/sundo/inavi3dservice/MMCModule$MSGTYPE;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3dservice/MMCModule$MSGTYPE;->value()S

    move-result v5

    if-ne p2, v5, :cond_2

    .line 1356
    const-string v5, "almanac"

    invoke-virtual {v0, v5, v6}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 1357
    const-string v5, "ephemeris"

    invoke-virtual {v0, v5, v6}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 1358
    const-string v5, "position"

    invoke-virtual {v0, v5, v6}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 1359
    const-string v5, "time"

    invoke-virtual {v0, v5, v6}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 1361
    iget-object v5, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_locManager:Landroid/location/LocationManager;

    const-string v6, "gps"

    const-string v7, "delete_aiding_data"

    invoke-virtual {v5, v6, v7, v0}, Landroid/location/LocationManager;->sendExtraCommand(Ljava/lang/String;Ljava/lang/String;Landroid/os/Bundle;)Z

    goto :goto_0

    .line 1363
    :cond_2
    sget-object v5, Lcom/thinkware/sundo/inavi3dservice/MMCModule$MSGTYPE;->WARMSTART:Lcom/thinkware/sundo/inavi3dservice/MMCModule$MSGTYPE;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3dservice/MMCModule$MSGTYPE;->value()S

    move-result v5

    if-ne p2, v5, :cond_3

    .line 1365
    const-string v5, "ephemeris"

    invoke-virtual {v0, v5, v6}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 1366
    const-string v5, "position"

    invoke-virtual {v0, v5, v6}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 1367
    const-string v5, "time"

    invoke-virtual {v0, v5, v6}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 1369
    iget-object v5, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_locManager:Landroid/location/LocationManager;

    const-string v6, "gps"

    const-string v7, "delete_aiding_data"

    invoke-virtual {v5, v6, v7, v0}, Landroid/location/LocationManager;->sendExtraCommand(Ljava/lang/String;Ljava/lang/String;Landroid/os/Bundle;)Z

    goto :goto_0

    .line 1372
    :cond_3
    sget-object v5, Lcom/thinkware/sundo/inavi3dservice/MMCModule$MSGTYPE;->HOTSTART:Lcom/thinkware/sundo/inavi3dservice/MMCModule$MSGTYPE;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3dservice/MMCModule$MSGTYPE;->value()S

    move-result v5

    if-ne p2, v5, :cond_0

    .line 1375
    const-string v5, "position"

    invoke-virtual {v0, v5, v6}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 1376
    const-string v5, "time"

    invoke-virtual {v0, v5, v6}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 1378
    iget-object v5, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_locManager:Landroid/location/LocationManager;

    const-string v6, "gps"

    const-string v7, "delete_aiding_data"

    invoke-virtual {v5, v6, v7, v0}, Landroid/location/LocationManager;->sendExtraCommand(Ljava/lang/String;Ljava/lang/String;Landroid/os/Bundle;)Z

    goto :goto_0

    .line 1382
    .end local v0    # "extras":Landroid/os/Bundle;
    :cond_4
    sget-object v5, Lcom/thinkware/sundo/inavi3dservice/MMCModule$GPSTYPE;->OLD_ATHEROS:Lcom/thinkware/sundo/inavi3dservice/MMCModule$GPSTYPE;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3dservice/MMCModule$GPSTYPE;->value()S

    move-result v5

    if-ne p1, v5, :cond_8

    .line 1383
    sget-object v5, Lcom/thinkware/sundo/inavi3dservice/MMCModule$MSGTYPE;->FACTORYRESET:Lcom/thinkware/sundo/inavi3dservice/MMCModule$MSGTYPE;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3dservice/MMCModule$MSGTYPE;->value()S

    move-result v5

    if-ne p2, v5, :cond_5

    .line 1384
    const-string v2, "$PUNV,START,FACTORY*cc\r\n"

    .line 1385
    .local v2, "sMsgFactory":Ljava/lang/String;
    iget-object v5, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_locManager:Landroid/location/LocationManager;

    const-string v6, "gps"

    invoke-virtual {v5, v6, v2, v7}, Landroid/location/LocationManager;->sendExtraCommand(Ljava/lang/String;Ljava/lang/String;Landroid/os/Bundle;)Z

    goto :goto_0

    .line 1387
    .end local v2    # "sMsgFactory":Ljava/lang/String;
    :cond_5
    sget-object v5, Lcom/thinkware/sundo/inavi3dservice/MMCModule$MSGTYPE;->COLDSTART:Lcom/thinkware/sundo/inavi3dservice/MMCModule$MSGTYPE;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3dservice/MMCModule$MSGTYPE;->value()S

    move-result v5

    if-ne p2, v5, :cond_6

    .line 1388
    const-string v1, "$PUNV,START,COLD*59\r\n"

    .line 1389
    .local v1, "sMsgCold":Ljava/lang/String;
    iget-object v5, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_locManager:Landroid/location/LocationManager;

    const-string v6, "gps"

    invoke-virtual {v5, v6, v1, v7}, Landroid/location/LocationManager;->sendExtraCommand(Ljava/lang/String;Ljava/lang/String;Landroid/os/Bundle;)Z

    goto/16 :goto_0

    .line 1391
    .end local v1    # "sMsgCold":Ljava/lang/String;
    :cond_6
    sget-object v5, Lcom/thinkware/sundo/inavi3dservice/MMCModule$MSGTYPE;->WARMSTART:Lcom/thinkware/sundo/inavi3dservice/MMCModule$MSGTYPE;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3dservice/MMCModule$MSGTYPE;->value()S

    move-result v5

    if-ne p2, v5, :cond_7

    .line 1392
    const-string v4, "$PUNV,START,WARM*54\r\n"

    .line 1393
    .local v4, "sMsgWarm":Ljava/lang/String;
    iget-object v5, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_locManager:Landroid/location/LocationManager;

    const-string v6, "gps"

    invoke-virtual {v5, v6, v4, v7}, Landroid/location/LocationManager;->sendExtraCommand(Ljava/lang/String;Ljava/lang/String;Landroid/os/Bundle;)Z

    goto/16 :goto_0

    .line 1395
    .end local v4    # "sMsgWarm":Ljava/lang/String;
    :cond_7
    sget-object v5, Lcom/thinkware/sundo/inavi3dservice/MMCModule$MSGTYPE;->HOTSTART:Lcom/thinkware/sundo/inavi3dservice/MMCModule$MSGTYPE;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3dservice/MMCModule$MSGTYPE;->value()S

    move-result v5

    if-ne p2, v5, :cond_0

    .line 1396
    const-string v3, "$PUNV,START,HOT*0E\r\n"

    .line 1397
    .local v3, "sMsgHot":Ljava/lang/String;
    iget-object v5, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_locManager:Landroid/location/LocationManager;

    const-string v6, "gps"

    invoke-virtual {v5, v6, v3, v7}, Landroid/location/LocationManager;->sendExtraCommand(Ljava/lang/String;Ljava/lang/String;Landroid/os/Bundle;)Z

    goto/16 :goto_0

    .line 1401
    .end local v3    # "sMsgHot":Ljava/lang/String;
    :cond_8
    sget-object v5, Lcom/thinkware/sundo/inavi3dservice/MMCModule$GPSTYPE;->OLD_UBLOX:Lcom/thinkware/sundo/inavi3dservice/MMCModule$GPSTYPE;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3dservice/MMCModule$GPSTYPE;->value()S

    move-result v5

    if-ne p1, v5, :cond_0

    .line 1402
    sget-object v5, Lcom/thinkware/sundo/inavi3dservice/MMCModule$MSGTYPE;->FACTORYRESET:Lcom/thinkware/sundo/inavi3dservice/MMCModule$MSGTYPE;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3dservice/MMCModule$MSGTYPE;->value()S

    move-result v5

    if-eq p2, v5, :cond_0

    .line 1404
    sget-object v5, Lcom/thinkware/sundo/inavi3dservice/MMCModule$MSGTYPE;->COLDSTART:Lcom/thinkware/sundo/inavi3dservice/MMCModule$MSGTYPE;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3dservice/MMCModule$MSGTYPE;->value()S

    move-result v5

    if-eq p2, v5, :cond_0

    .line 1413
    sget-object v5, Lcom/thinkware/sundo/inavi3dservice/MMCModule$MSGTYPE;->WARMSTART:Lcom/thinkware/sundo/inavi3dservice/MMCModule$MSGTYPE;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3dservice/MMCModule$MSGTYPE;->value()S

    move-result v5

    if-eq p2, v5, :cond_0

    .line 1423
    sget-object v5, Lcom/thinkware/sundo/inavi3dservice/MMCModule$MSGTYPE;->HOTSTART:Lcom/thinkware/sundo/inavi3dservice/MMCModule$MSGTYPE;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3dservice/MMCModule$MSGTYPE;->value()S

    move-result v5

    if-ne p2, v5, :cond_0

    goto/16 :goto_0
.end method

.method private setGPSInfo(Lcom/tw/mapmatch/dataset/_GPSInfo;)V
    .locals 6
    .param p1, "_gpsInfo"    # Lcom/tw/mapmatch/dataset/_GPSInfo;

    .prologue
    const/4 v5, 0x0

    const/4 v4, 0x1

    .line 1197
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_gi:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    iget-short v1, p1, Lcom/tw/mapmatch/dataset/_GPSInfo;->UsedSatNo:S

    iput-short v1, v0, Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;->UsedSatNo:S

    .line 1198
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_gi:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    iget-short v1, p1, Lcom/tw/mapmatch/dataset/_GPSInfo;->Date_yy:S

    iput-short v1, v0, Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;->Date_yy:S

    .line 1199
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_gi:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    iget-short v1, p1, Lcom/tw/mapmatch/dataset/_GPSInfo;->Date_mm:S

    iput-short v1, v0, Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;->Date_mm:S

    .line 1200
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_gi:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    iget-short v1, p1, Lcom/tw/mapmatch/dataset/_GPSInfo;->Date_dd:S

    iput-short v1, v0, Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;->Date_dd:S

    .line 1201
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_gi:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    iget-short v1, p1, Lcom/tw/mapmatch/dataset/_GPSInfo;->UTC_hh:S

    iput-short v1, v0, Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;->UTC_hh:S

    .line 1202
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_gi:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    iget-short v1, p1, Lcom/tw/mapmatch/dataset/_GPSInfo;->UTC_mm:S

    iput-short v1, v0, Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;->UTC_mm:S

    .line 1203
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_gi:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    iget-short v1, p1, Lcom/tw/mapmatch/dataset/_GPSInfo;->UTC_ss:S

    iput-short v1, v0, Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;->UTC_ss:S

    .line 1204
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_gi:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    iget-short v1, p1, Lcom/tw/mapmatch/dataset/_GPSInfo;->Course:S

    iput-short v1, v0, Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;->Course:S

    .line 1205
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_gi:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    iget-short v1, p1, Lcom/tw/mapmatch/dataset/_GPSInfo;->SpeedK:S

    iput-short v1, v0, Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;->SpeedK:S

    .line 1206
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_gi:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    iget-char v1, p1, Lcom/tw/mapmatch/dataset/_GPSInfo;->Status:C

    iput-char v1, v0, Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;->Status:C

    .line 1207
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_gi:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    iget-char v1, p1, Lcom/tw/mapmatch/dataset/_GPSInfo;->Dimension:C

    int-to-byte v1, v1

    iput-byte v1, v0, Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;->Dimension:B

    .line 1209
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_gi:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    iget-object v1, p1, Lcom/tw/mapmatch/dataset/_GPSInfo;->Date:[B

    iput-object v1, v0, Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;->Date:[B

    .line 1210
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_gi:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    iget-object v1, p1, Lcom/tw/mapmatch/dataset/_GPSInfo;->UTC:[B

    iput-object v1, v0, Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;->UTC:[B

    .line 1213
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_gi:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    iget v1, p1, Lcom/tw/mapmatch/dataset/_GPSInfo;->Lon:I

    iput v1, v0, Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;->Lon:I

    .line 1214
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_gi:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    iget v1, p1, Lcom/tw/mapmatch/dataset/_GPSInfo;->Lat:I

    iput v1, v0, Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;->Lat:I

    .line 1215
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_gi:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    iget v1, p1, Lcom/tw/mapmatch/dataset/_GPSInfo;->Height:I

    iput v1, v0, Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;->Height:I

    .line 1216
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_gi:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    iget v1, p1, Lcom/tw/mapmatch/dataset/_GPSInfo;->nGpsQlty:I

    iput v1, v0, Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;->nGpsQlty:I

    .line 1217
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_gi:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    iget-wide v2, p1, Lcom/tw/mapmatch/dataset/_GPSInfo;->HDOP:D

    iput-wide v2, v0, Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;->HDOP:D

    .line 1220
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_gi:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    iget-boolean v1, p1, Lcom/tw/mapmatch/dataset/_GPSInfo;->bIsDR:Z

    iput-boolean v1, v0, Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;->bIsDR:Z

    .line 1221
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_gi:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    iget-boolean v1, p1, Lcom/tw/mapmatch/dataset/_GPSInfo;->bIsJump:Z

    iput-boolean v1, v0, Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;->bIsJump:Z

    .line 1223
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_gi:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    iget v1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nAccuracy:I

    iput v1, v0, Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;->nAccuracy:I

    .line 1225
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mi:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    iget v0, v0, Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;->gpsStatus:I

    if-nez v0, :cond_0

    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsGpsOkay:Z

    if-ne v0, v4, :cond_0

    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsGPSConfiguration:Z

    if-ne v0, v4, :cond_0

    .line 1226
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_gi:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    iput v4, v0, Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;->gpsStatus:I

    .line 1231
    :goto_0
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsGPSConfiguration:Z

    if-ne v0, v4, :cond_1

    .line 1232
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_gi:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    iput v4, v0, Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;->nSerial:I

    .line 1237
    :goto_1
    return-void

    .line 1228
    :cond_0
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_gi:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    iput v5, v0, Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;->gpsStatus:I

    goto :goto_0

    .line 1234
    :cond_1
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_gi:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    iput v5, v0, Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;->nSerial:I

    goto :goto_1
.end method

.method private setMMCInfo(Lcom/tw/mapmatch/dataset/_MMCInfo;)V
    .locals 4
    .param p1, "_mmcInfo"    # Lcom/tw/mapmatch/dataset/_MMCInfo;

    .prologue
    .line 1263
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mi:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    iget-short v1, p1, Lcom/tw/mapmatch/dataset/_MMCInfo;->reversed:S

    iput-short v1, v0, Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;->reversed:S

    .line 1264
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mi:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    iget-short v1, p1, Lcom/tw/mapmatch/dataset/_MMCInfo;->mapid:S

    iput-short v1, v0, Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;->mapid:S

    .line 1265
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mi:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    iget-short v1, p1, Lcom/tw/mapmatch/dataset/_MMCInfo;->linkid:S

    iput-short v1, v0, Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;->linkid:S

    .line 1266
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mi:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    iget-short v1, p1, Lcom/tw/mapmatch/dataset/_MMCInfo;->heading:S

    iput-short v1, v0, Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;->heading:S

    .line 1267
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mi:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    iget-short v1, p1, Lcom/tw/mapmatch/dataset/_MMCInfo;->segment:S

    iput-short v1, v0, Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;->segment:S

    .line 1268
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mi:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    iget-short v1, p1, Lcom/tw/mapmatch/dataset/_MMCInfo;->speed:S

    iput-short v1, v0, Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;->speed:S

    .line 1269
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mi:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    iget-short v1, p1, Lcom/tw/mapmatch/dataset/_MMCInfo;->status:S

    iput-short v1, v0, Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;->status:S

    .line 1272
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mi:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    iget v1, p1, Lcom/tw/mapmatch/dataset/_MMCInfo;->speed_kmh:I

    iput v1, v0, Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;->speed_kmh:I

    .line 1273
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mi:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    iget v1, p1, Lcom/tw/mapmatch/dataset/_MMCInfo;->lon:I

    iput v1, v0, Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;->lon:I

    .line 1274
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mi:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    iget v1, p1, Lcom/tw/mapmatch/dataset/_MMCInfo;->lat:I

    iput v1, v0, Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;->lat:I

    .line 1275
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mi:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    iget v1, p1, Lcom/tw/mapmatch/dataset/_MMCInfo;->distance:I

    iput v1, v0, Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;->distance:I

    .line 1276
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mi:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    iget v1, p1, Lcom/tw/mapmatch/dataset/_MMCInfo;->linkratio:I

    iput v1, v0, Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;->linkratio:I

    .line 1277
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mi:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    iget v1, p1, Lcom/tw/mapmatch/dataset/_MMCInfo;->nMMCStatus:I

    iput v1, v0, Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;->nMMCStatus:I

    .line 1278
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mi:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    iget v1, p1, Lcom/tw/mapmatch/dataset/_MMCInfo;->nRoadPassWay:I

    iput v1, v0, Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;->nRoadPassWay:I

    .line 1279
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mi:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    iget v1, p1, Lcom/tw/mapmatch/dataset/_MMCInfo;->nCurRoadMMState:I

    iput v1, v0, Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;->nCurRoadMMState:I

    .line 1281
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mi:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    iget v1, p1, Lcom/tw/mapmatch/dataset/_MMCInfo;->gpsscore:I

    iput v1, v0, Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;->gpsscore:I

    .line 1282
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mi:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    iget v1, p1, Lcom/tw/mapmatch/dataset/_MMCInfo;->gpsStatus:I

    iput v1, v0, Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;->gpsStatus:I

    .line 1283
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mi:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    iget v1, p1, Lcom/tw/mapmatch/dataset/_MMCInfo;->DRMValue:I

    iput v1, v0, Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;->DRMValue:I

    .line 1287
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mi:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    iget v1, p1, Lcom/tw/mapmatch/dataset/_MMCInfo;->ir:F

    iput v1, v0, Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;->ir:F

    .line 1288
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mi:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    iget v1, p1, Lcom/tw/mapmatch/dataset/_MMCInfo;->displacement:F

    iput v1, v0, Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;->displacement:F

    .line 1291
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mi:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    iget-wide v2, p1, Lcom/tw/mapmatch/dataset/_MMCInfo;->restlat:D

    iput-wide v2, v0, Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;->restlat:D

    .line 1292
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mi:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    iget-wide v2, p1, Lcom/tw/mapmatch/dataset/_MMCInfo;->restlon:D

    iput-wide v2, v0, Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;->restlon:D

    .line 1295
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mi:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    iget-char v1, p1, Lcom/tw/mapmatch/dataset/_MMCInfo;->sDirectEscape:C

    int-to-byte v1, v1

    iput-byte v1, v0, Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;->sDirectEscape:B

    .line 1296
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mi:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    iget-char v1, p1, Lcom/tw/mapmatch/dataset/_MMCInfo;->cHotStart:C

    int-to-byte v1, v1

    iput-byte v1, v0, Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;->cHotStart:B

    .line 1297
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mi:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    iget-char v1, p1, Lcom/tw/mapmatch/dataset/_MMCInfo;->nIsInBound:C

    int-to-byte v1, v1

    iput-byte v1, v0, Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;->nIsInBound:B

    .line 1298
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mi:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    iget-char v1, p1, Lcom/tw/mapmatch/dataset/_MMCInfo;->cPSaveInZone:C

    int-to-byte v1, v1

    iput-byte v1, v0, Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;->cPSaveInZone:B

    .line 1299
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mi:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    iget-char v1, p1, Lcom/tw/mapmatch/dataset/_MMCInfo;->cLinkInfo:C

    int-to-byte v1, v1

    iput-byte v1, v0, Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;->cLinkInfo:B

    .line 1300
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mi:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    iget-char v1, p1, Lcom/tw/mapmatch/dataset/_MMCInfo;->cReserved:C

    int-to-byte v1, v1

    iput-byte v1, v0, Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;->cReserved:B

    .line 1309
    return-void
.end method

.method private setSATInfo(Lcom/tw/mapmatch/dataset/_SATInfo;)V
    .locals 6
    .param p1, "satInfo"    # Lcom/tw/mapmatch/dataset/_SATInfo;

    .prologue
    .line 1240
    new-instance v1, Lcom/tw/mapmatch/remote/mapmatch/SATInfo;

    invoke-direct {v1}, Lcom/tw/mapmatch/remote/mapmatch/SATInfo;-><init>()V

    .line 1242
    .local v1, "tmpSat":Lcom/tw/mapmatch/remote/mapmatch/SATInfo;
    iget-short v2, p1, Lcom/tw/mapmatch/dataset/_SATInfo;->ViewSatNo:S

    iput-short v2, v1, Lcom/tw/mapmatch/remote/mapmatch/SATInfo;->ViewSatNo:S

    .line 1243
    iget-char v2, p1, Lcom/tw/mapmatch/dataset/_SATInfo;->Dimension:C

    int-to-byte v2, v2

    iput-byte v2, v1, Lcom/tw/mapmatch/remote/mapmatch/SATInfo;->Dimension:B

    .line 1250
    const/4 v0, 0x0

    .local v0, "i":I
    :goto_0
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_si:Lcom/tw/mapmatch/remote/mapmatch/SATInfo;

    iget-short v2, v2, Lcom/tw/mapmatch/remote/mapmatch/SATInfo;->ViewSatNo:S

    if-ge v0, v2, :cond_0

    .line 1252
    iget-object v2, v1, Lcom/tw/mapmatch/remote/mapmatch/SATInfo;->EAngle:[B

    iget-object v3, p1, Lcom/tw/mapmatch/dataset/_SATInfo;->EAngle:[B

    aget-byte v3, v3, v0

    aput-byte v3, v2, v0

    .line 1253
    iget-object v2, v1, Lcom/tw/mapmatch/remote/mapmatch/SATInfo;->IsUsed:[B

    iget-object v3, p1, Lcom/tw/mapmatch/dataset/_SATInfo;->IsUsed:[B

    aget-byte v3, v3, v0

    aput-byte v3, v2, v0

    .line 1254
    iget-object v2, v1, Lcom/tw/mapmatch/remote/mapmatch/SATInfo;->BAngle:[J

    iget-object v3, p1, Lcom/tw/mapmatch/dataset/_SATInfo;->BAngle:[S

    aget-short v3, v3, v0

    int-to-long v4, v3

    aput-wide v4, v2, v0

    .line 1255
    iget-object v2, v1, Lcom/tw/mapmatch/remote/mapmatch/SATInfo;->PRN:[B

    iget-object v3, p1, Lcom/tw/mapmatch/dataset/_SATInfo;->PRN:[B

    aget-byte v3, v3, v0

    aput-byte v3, v2, v0

    .line 1250
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    .line 1258
    :cond_0
    iput-object v1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_si:Lcom/tw/mapmatch/remote/mapmatch/SATInfo;

    .line 1259
    return-void
.end method

.method private updateWithNewLocation(Landroid/location/Location;)V
    .locals 37
    .param p1, "location"    # Landroid/location/Location;

    .prologue
    .line 459
    move-object/from16 v0, p0

    iget-object v6, v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsRunning:[Z

    const/4 v7, 0x2

    aget-boolean v6, v6, v7

    const/4 v7, 0x1

    if-ne v6, v7, :cond_0

    .line 598
    :goto_0
    return-void

    .line 463
    :cond_0
    if-eqz p1, :cond_7

    move-object/from16 v0, p0

    iget-wide v6, v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->nmea_timestamp:J

    const-wide/16 v8, 0x0

    cmp-long v6, v6, v8

    if-gez v6, :cond_7

    .line 466
    const/4 v6, 0x3

    new-array v0, v6, [I

    move-object/from16 v30, v0

    fill-array-data v30, :array_0

    .line 468
    .local v30, "nDate":[I
    invoke-virtual/range {p1 .. p1}, Landroid/location/Location;->getTime()J

    move-result-wide v6

    move-object/from16 v0, p0

    iput-wide v6, v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->location_timestamp:J

    .line 471
    const-string v6, "UTC"

    invoke-static {v6}, Ljava/util/TimeZone;->getTimeZone(Ljava/lang/String;)Ljava/util/TimeZone;

    move-result-object v6

    invoke-static {v6}, Ljava/util/TimeZone;->setDefault(Ljava/util/TimeZone;)V

    .line 473
    new-instance v32, Ljava/text/SimpleDateFormat;

    const-string v6, "dd:MM:yy:HH:mm:ss"

    move-object/from16 v0, v32

    invoke-direct {v0, v6}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;)V

    .line 474
    .local v32, "sdf":Ljava/text/SimpleDateFormat;
    new-instance v6, Ljava/util/Date;

    move-object/from16 v0, p0

    iget-wide v8, v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->location_timestamp:J

    invoke-direct {v6, v8, v9}, Ljava/util/Date;-><init>(J)V

    move-object/from16 v0, v32

    invoke-virtual {v0, v6}, Ljava/text/SimpleDateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v31

    .line 476
    .local v31, "prt":Ljava/lang/String;
    new-instance v36, Ljava/util/StringTokenizer;

    const-string v6, ":"

    move-object/from16 v0, v36

    move-object/from16 v1, v31

    invoke-direct {v0, v1, v6}, Ljava/util/StringTokenizer;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 478
    .local v36, "tok":Ljava/util/StringTokenizer;
    const/16 v21, 0x0

    .line 480
    .local v21, "i":I
    :goto_1
    invoke-virtual/range {v36 .. v36}, Ljava/util/StringTokenizer;->hasMoreElements()Z

    move-result v6

    if-eqz v6, :cond_2

    .line 482
    const/4 v6, 0x3

    move/from16 v0, v21

    if-ge v0, v6, :cond_1

    .line 483
    invoke-virtual/range {v36 .. v36}, Ljava/util/StringTokenizer;->nextToken()Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v6

    aput v6, v30, v21

    .line 487
    :goto_2
    add-int/lit8 v21, v21, 0x1

    goto :goto_1

    .line 485
    :cond_1
    move-object/from16 v0, p0

    iget-object v6, v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nUTC:[I

    add-int/lit8 v7, v21, -0x3

    invoke-virtual/range {v36 .. v36}, Ljava/util/StringTokenizer;->nextToken()Ljava/lang/String;

    move-result-object v8

    invoke-static {v8}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v8

    aput v8, v6, v7

    goto :goto_2

    .line 490
    :cond_2
    move-object/from16 v0, p0

    iget-object v6, v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nUTC:[I

    const/4 v7, 0x0

    aget v6, v6, v7

    move-object/from16 v0, p0

    iget-object v7, v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nUTC_old:[I

    const/4 v8, 0x0

    aget v7, v7, v8

    if-ne v6, v7, :cond_3

    move-object/from16 v0, p0

    iget-object v6, v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nUTC:[I

    const/4 v7, 0x1

    aget v6, v6, v7

    move-object/from16 v0, p0

    iget-object v7, v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nUTC_old:[I

    const/4 v8, 0x1

    aget v7, v7, v8

    if-ne v6, v7, :cond_3

    move-object/from16 v0, p0

    iget-object v6, v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nUTC:[I

    const/4 v7, 0x2

    aget v6, v6, v7

    move-object/from16 v0, p0

    iget-object v7, v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nUTC_old:[I

    const/4 v8, 0x2

    aget v7, v7, v8

    if-eq v6, v7, :cond_4

    .line 492
    :cond_3
    move-object/from16 v0, p0

    iget-object v6, v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nUTC_old:[I

    const/4 v7, 0x0

    move-object/from16 v0, p0

    iget-object v8, v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nUTC:[I

    const/4 v9, 0x0

    aget v8, v8, v9

    aput v8, v6, v7

    .line 493
    move-object/from16 v0, p0

    iget-object v6, v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nUTC_old:[I

    const/4 v7, 0x1

    move-object/from16 v0, p0

    iget-object v8, v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nUTC:[I

    const/4 v9, 0x1

    aget v8, v8, v9

    aput v8, v6, v7

    .line 494
    move-object/from16 v0, p0

    iget-object v6, v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nUTC_old:[I

    const/4 v7, 0x2

    move-object/from16 v0, p0

    iget-object v8, v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nUTC:[I

    const/4 v9, 0x2

    aget v8, v8, v9

    aput v8, v6, v7

    .line 497
    :cond_4
    invoke-virtual/range {p1 .. p1}, Landroid/location/Location;->getLatitude()D

    move-result-wide v26

    .line 498
    .local v26, "lat":D
    invoke-virtual/range {p1 .. p1}, Landroid/location/Location;->getLongitude()D

    move-result-wide v28

    .line 501
    .local v28, "lon":D
    invoke-static/range {v26 .. v27}, Ljava/lang/Math;->floor(D)D

    move-result-wide v6

    double-to-int v14, v6

    .line 502
    .local v14, "LatDD":I
    invoke-static/range {v28 .. v29}, Ljava/lang/Math;->floor(D)D

    move-result-wide v6

    double-to-int v15, v6

    .line 503
    .local v15, "LonDD":I
    const-string v34, ""

    .local v34, "strTmpLat":Ljava/lang/String;
    const-string v35, ""

    .line 505
    .local v35, "strTmpLon":Ljava/lang/String;
    int-to-double v6, v14

    sub-double v16, v26, v6

    .line 506
    .local v16, "LatMM":D
    int-to-double v6, v15

    sub-double v18, v28, v6

    .line 508
    .local v18, "LonMM":D
    const-wide/high16 v6, 0x404e000000000000L    # 60.0

    mul-double v16, v16, v6

    .line 509
    const-wide/high16 v6, 0x404e000000000000L    # 60.0

    mul-double v18, v18, v6

    .line 512
    const-wide/high16 v6, 0x4024000000000000L    # 10.0

    cmpg-double v6, v16, v6

    if-gez v6, :cond_5

    .line 513
    const-string v6, "0%.5f"

    const/4 v7, 0x1

    new-array v7, v7, [Ljava/lang/Object;

    const/4 v8, 0x0

    invoke-static/range {v16 .. v17}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v9

    aput-object v9, v7, v8

    invoke-static {v6, v7}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v34

    .line 518
    :goto_3
    const-wide/high16 v6, 0x4024000000000000L    # 10.0

    cmpg-double v6, v18, v6

    if-gez v6, :cond_6

    .line 519
    const-string v6, "0%.5f"

    const/4 v7, 0x1

    new-array v7, v7, [Ljava/lang/Object;

    const/4 v8, 0x0

    invoke-static/range {v18 .. v19}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v9

    aput-object v9, v7, v8

    invoke-static {v6, v7}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v35

    .line 524
    :goto_4
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "%d"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    move-object/from16 v0, v34

    invoke-virtual {v6, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    const/4 v7, 0x1

    new-array v7, v7, [Ljava/lang/Object;

    const/4 v8, 0x0

    invoke-static {v14}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    aput-object v9, v7, v8

    invoke-static {v6, v7}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/String;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    move-result-wide v16

    .line 525
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "%d"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    move-object/from16 v0, v35

    invoke-virtual {v6, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    const/4 v7, 0x1

    new-array v7, v7, [Ljava/lang/Object;

    const/4 v8, 0x0

    invoke-static {v15}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    aput-object v9, v7, v8

    invoke-static {v6, v7}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/String;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    move-result-wide v18

    .line 528
    const-wide/16 v24, 0x0

    .line 529
    .local v24, "bessel_lon":D
    const-wide/16 v22, 0x0

    .line 530
    .local v22, "bessel_lat":D
    const/16 v20, 0x0

    .line 532
    .local v20, "bessel_altitude":I
    invoke-static/range {v16 .. v17}, Lcom/tw/mapmatch/HelperFunctions;->TWSEC(D)D

    move-result-wide v22

    .line 533
    invoke-static/range {v18 .. v19}, Lcom/tw/mapmatch/HelperFunctions;->TWSEC(D)D

    move-result-wide v24

    .line 535
    invoke-virtual/range {p1 .. p1}, Landroid/location/Location;->getAltitude()D

    move-result-wide v6

    double-to-int v0, v6

    move/from16 v20, v0

    .line 538
    mul-int/lit8 v20, v20, 0xa

    .line 540
    move-wide/from16 v0, v24

    move-wide/from16 v2, v22

    move/from16 v4, v20

    invoke-static {v0, v1, v2, v3, v4}, Lcom/tw/mapmatch/HelperFunctions;->Moledensky(DDI)V

    .line 542
    sget-wide v24, Lcom/tw/mapmatch/HelperFunctions;->bessel_lon:D

    .line 543
    sget-wide v22, Lcom/tw/mapmatch/HelperFunctions;->bessel_lat:D

    .line 544
    sget v20, Lcom/tw/mapmatch/HelperFunctions;->bessel_altitude:I

    .line 546
    const-wide/high16 v6, 0x4024000000000000L    # 10.0

    div-double v6, v22, v6

    double-to-int v6, v6

    move-object/from16 v0, p0

    iput v6, v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nLatitude:I

    .line 547
    const-wide/high16 v6, 0x4024000000000000L    # 10.0

    div-double v6, v24, v6

    double-to-int v6, v6

    move-object/from16 v0, p0

    iput v6, v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nLongitude:I

    .line 548
    move/from16 v0, v20

    move-object/from16 v1, p0

    iput v0, v1, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nAltitude:I

    .line 549
    invoke-virtual/range {p1 .. p1}, Landroid/location/Location;->getBearing()F

    move-result v6

    float-to-int v6, v6

    int-to-short v6, v6

    move-object/from16 v0, p0

    iput-short v6, v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_sCourse:S

    .line 553
    invoke-virtual/range {p1 .. p1}, Landroid/location/Location;->getSpeed()F

    move-result v6

    const v7, 0x40666666    # 3.6f

    mul-float v33, v6, v7

    .line 554
    .local v33, "speed":F
    const/high16 v6, 0x41200000    # 10.0f

    mul-float v6, v6, v33

    float-to-int v6, v6

    int-to-short v6, v6

    move-object/from16 v0, p0

    iput-short v6, v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_sSpeed:S

    .line 557
    const/4 v6, 0x6

    new-array v13, v6, [B

    fill-array-data v13, :array_1

    .line 558
    .local v13, "bUTC":[B
    const/4 v6, 0x0

    move-object/from16 v0, p0

    iget-object v7, v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nUTC:[I

    const/4 v8, 0x0

    aget v7, v7, v8

    int-to-byte v7, v7

    aput-byte v7, v13, v6

    .line 559
    const/4 v6, 0x1

    move-object/from16 v0, p0

    iget-object v7, v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nUTC:[I

    const/4 v8, 0x1

    aget v7, v7, v8

    int-to-byte v7, v7

    aput-byte v7, v13, v6

    .line 560
    const/4 v6, 0x2

    move-object/from16 v0, p0

    iget-object v7, v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nUTC:[I

    const/4 v8, 0x2

    aget v7, v7, v8

    int-to-byte v7, v7

    aput-byte v7, v13, v6

    .line 561
    const/4 v6, 0x3

    const/4 v7, 0x0

    aget v7, v30, v7

    int-to-byte v7, v7

    aput-byte v7, v13, v6

    .line 562
    const/4 v6, 0x4

    const/4 v7, 0x1

    aget v7, v30, v7

    int-to-byte v7, v7

    aput-byte v7, v13, v6

    .line 563
    const/4 v6, 0x5

    const/4 v7, 0x2

    aget v7, v30, v7

    int-to-byte v7, v7

    aput-byte v7, v13, v6

    .line 566
    invoke-virtual/range {p1 .. p1}, Landroid/location/Location;->getAccuracy()F

    move-result v6

    const/high16 v7, 0x41200000    # 10.0f

    mul-float/2addr v6, v7

    float-to-int v6, v6

    move-object/from16 v0, p0

    iput v6, v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nAccuracy:I

    .line 568
    move-object/from16 v0, p0

    iget-object v6, v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    move-object/from16 v0, p0

    iget v7, v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nLatitude:I

    move-object/from16 v0, p0

    iget v8, v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nLongitude:I

    move-object/from16 v0, p0

    iget v9, v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nAltitude:I

    move-object/from16 v0, p0

    iget v10, v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nAccuracy:I

    move-object/from16 v0, p0

    iget-short v11, v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_sCourse:S

    move-object/from16 v0, p0

    iget-short v12, v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_sSpeed:S

    invoke-virtual/range {v6 .. v13}, Lcom/tw/mapmatch/jni/Natives;->nativeSetLocationData(IIIISS[B)I

    .line 570
    move-object/from16 v0, p0

    iget-object v7, v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->obj:Ljava/lang/Object;

    monitor-enter v7

    .line 576
    const/4 v6, 0x2

    :try_start_0
    move-object/from16 v0, p0

    iput v6, v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nCurrentMode:I

    .line 577
    move-object/from16 v0, p0

    iget-object v6, v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    const/4 v8, 0x0

    move-object/from16 v0, p0

    iget v9, v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nCurrentMode:I

    invoke-virtual {v6, v8, v9}, Lcom/tw/mapmatch/jni/Natives;->nativeMapMatch(ZI)I

    .line 582
    monitor-exit v7
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 584
    move-object/from16 v0, p0

    iget-object v6, v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    invoke-virtual {v6}, Lcom/tw/mapmatch/jni/Natives;->nativeGetMMCInfo()Lcom/tw/mapmatch/dataset/_MMCInfo;

    move-result-object v6

    move-object/from16 v0, p0

    iput-object v6, v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_mmcInfo:Lcom/tw/mapmatch/dataset/_MMCInfo;

    .line 585
    move-object/from16 v0, p0

    iget-object v6, v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_mmcInfo:Lcom/tw/mapmatch/dataset/_MMCInfo;

    move-object/from16 v0, p0

    invoke-direct {v0, v6}, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->setMMCInfo(Lcom/tw/mapmatch/dataset/_MMCInfo;)V

    .line 588
    move-object/from16 v0, p0

    iget-object v6, v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->gravityModule:Lcom/thinkware/sundo/inavi3dservice/GravityModule;

    invoke-virtual {v6}, Lcom/thinkware/sundo/inavi3dservice/GravityModule;->getGPSInfo()Lcom/tw/mapmatch/dataset/_GPSInfo;

    move-result-object v6

    move-object/from16 v0, p0

    iput-object v6, v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_gpsInfo:Lcom/tw/mapmatch/dataset/_GPSInfo;

    .line 590
    move-object/from16 v0, p0

    iget-object v6, v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->_gpsInfo:Lcom/tw/mapmatch/dataset/_GPSInfo;

    move-object/from16 v0, p0

    invoke-direct {v0, v6}, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->setGPSInfo(Lcom/tw/mapmatch/dataset/_GPSInfo;)V

    .line 591
    const-string v6, "Asia/Seoul"

    invoke-static {v6}, Ljava/util/TimeZone;->getTimeZone(Ljava/lang/String;)Ljava/util/TimeZone;

    move-result-object v6

    invoke-static {v6}, Ljava/util/TimeZone;->setDefault(Ljava/util/TimeZone;)V

    goto/16 :goto_0

    .line 515
    .end local v13    # "bUTC":[B
    .end local v20    # "bessel_altitude":I
    .end local v22    # "bessel_lat":D
    .end local v24    # "bessel_lon":D
    .end local v33    # "speed":F
    :cond_5
    const-string v6, "%.5f"

    const/4 v7, 0x1

    new-array v7, v7, [Ljava/lang/Object;

    const/4 v8, 0x0

    invoke-static/range {v16 .. v17}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v9

    aput-object v9, v7, v8

    invoke-static {v6, v7}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v34

    goto/16 :goto_3

    .line 521
    :cond_6
    const-string v6, "%.5f"

    const/4 v7, 0x1

    new-array v7, v7, [Ljava/lang/Object;

    const/4 v8, 0x0

    invoke-static/range {v18 .. v19}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v9

    aput-object v9, v7, v8

    invoke-static {v6, v7}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v35

    goto/16 :goto_4

    .line 582
    .restart local v13    # "bUTC":[B
    .restart local v20    # "bessel_altitude":I
    .restart local v22    # "bessel_lat":D
    .restart local v24    # "bessel_lon":D
    .restart local v33    # "speed":F
    :catchall_0
    move-exception v6

    :try_start_1
    monitor-exit v7
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw v6

    .line 595
    .end local v13    # "bUTC":[B
    .end local v14    # "LatDD":I
    .end local v15    # "LonDD":I
    .end local v16    # "LatMM":D
    .end local v18    # "LonMM":D
    .end local v20    # "bessel_altitude":I
    .end local v21    # "i":I
    .end local v22    # "bessel_lat":D
    .end local v24    # "bessel_lon":D
    .end local v26    # "lat":D
    .end local v28    # "lon":D
    .end local v30    # "nDate":[I
    .end local v31    # "prt":Ljava/lang/String;
    .end local v32    # "sdf":Ljava/text/SimpleDateFormat;
    .end local v33    # "speed":F
    .end local v34    # "strTmpLat":Ljava/lang/String;
    .end local v35    # "strTmpLon":Ljava/lang/String;
    .end local v36    # "tok":Ljava/util/StringTokenizer;
    :cond_7
    invoke-virtual/range {p1 .. p1}, Landroid/location/Location;->getAccuracy()F

    move-result v6

    const/high16 v7, 0x41200000    # 10.0f

    mul-float/2addr v6, v7

    float-to-int v6, v6

    move-object/from16 v0, p0

    iput v6, v0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nAccuracy:I

    goto/16 :goto_0

    .line 466
    nop

    :array_0
    .array-data 4
        0x0
        0x0
        0x0
    .end array-data

    .line 557
    :array_1
    .array-data 1
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
    .end array-data
.end method


# virtual methods
.method public ChangeLink()V
    .locals 4

    .prologue
    .line 797
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->mmcHandler:Landroid/os/Handler;

    const/16 v3, 0x3e9

    invoke-virtual {v2, v3}, Landroid/os/Handler;->obtainMessage(I)Landroid/os/Message;

    move-result-object v1

    .line 798
    .local v1, "msg":Landroid/os/Message;
    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    .line 799
    .local v0, "data":Landroid/os/Bundle;
    const-string v2, "MsgType"

    sget-object v3, Lcom/thinkware/sundo/inavi3dservice/MMCModule$MSGTYPE;->CHANGELINK:Lcom/thinkware/sundo/inavi3dservice/MMCModule$MSGTYPE;

    invoke-virtual {v3}, Lcom/thinkware/sundo/inavi3dservice/MMCModule$MSGTYPE;->value()S

    move-result v3

    invoke-virtual {v0, v2, v3}, Landroid/os/Bundle;->putShort(Ljava/lang/String;S)V

    .line 801
    invoke-virtual {v1, v0}, Landroid/os/Message;->setData(Landroid/os/Bundle;)V

    .line 802
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->mmcHandler:Landroid/os/Handler;

    invoke-virtual {v2, v1}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    .line 803
    return-void
.end method

.method public ClearRouteTbl()V
    .locals 1

    .prologue
    .line 839
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    invoke-virtual {v0}, Lcom/tw/mapmatch/jni/Natives;->nativeClearRouteTbl()V

    .line 840
    return-void
.end method

.method public GetGPSInfo()Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;
    .locals 3

    .prologue
    const/4 v2, 0x1

    .line 740
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsGPSConfiguration:Z

    if-ne v0, v2, :cond_0

    .line 741
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_gi:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    .line 752
    :goto_0
    return-object v0

    .line 742
    :cond_0
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsRunning:[Z

    const/4 v1, 0x2

    aget-boolean v0, v0, v1

    if-ne v0, v2, :cond_1

    .line 743
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_gi:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    goto :goto_0

    .line 746
    :cond_1
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_gi_dummy:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    const/4 v1, 0x0

    iput v1, v0, Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;->nSerial:I

    .line 752
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_gi_dummy:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    goto :goto_0
.end method

.method public GetMMCInfo()Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;
    .locals 7

    .prologue
    const/4 v6, 0x1

    .line 757
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    .line 759
    .local v0, "curTime":J
    iget-wide v4, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_prevTime_getMMCInfo:J

    sub-long v2, v0, v4

    .line 762
    .local v2, "timeGap_getMMCInfo":J
    const-wide/16 v4, 0x32

    cmp-long v4, v2, v4

    if-gez v4, :cond_0

    const-wide/16 v4, 0x0

    cmp-long v4, v2, v4

    if-gez v4, :cond_1

    .line 763
    :cond_0
    sget-object v5, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->mm_mutex:Ljava/lang/Object;

    monitor-enter v5

    .line 764
    :try_start_0
    invoke-direct {p0}, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->doVirtualMapMatch()V

    .line 765
    iput-wide v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_prevTime_getMMCInfo:J

    .line 766
    monitor-exit v5
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 769
    :cond_1
    iget-boolean v4, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsGPSConfiguration:Z

    if-eq v4, v6, :cond_2

    iget-object v4, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsRunning:[Z

    const/4 v5, 0x2

    aget-boolean v4, v4, v5

    if-ne v4, v6, :cond_3

    .line 776
    :cond_2
    :goto_0
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mi:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    return-object v4

    .line 766
    :catchall_0
    move-exception v4

    :try_start_1
    monitor-exit v5
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw v4

    .line 772
    :cond_3
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mi:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    const/4 v5, 0x0

    iput v5, v4, Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;->gpsscore:I

    .line 773
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mi:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    const/4 v5, -0x2

    iput v5, v4, Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;->gpsStatus:I

    goto :goto_0
.end method

.method public GetSATInfo()Lcom/tw/mapmatch/remote/mapmatch/SATInfo;
    .locals 3

    .prologue
    const/4 v2, 0x1

    .line 781
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsGPSConfiguration:Z

    if-ne v0, v2, :cond_0

    .line 782
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_si:Lcom/tw/mapmatch/remote/mapmatch/SATInfo;

    .line 787
    :goto_0
    return-object v0

    .line 783
    :cond_0
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsRunning:[Z

    const/4 v1, 0x2

    aget-boolean v0, v0, v1

    if-ne v0, v2, :cond_1

    .line 784
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_si:Lcom/tw/mapmatch/remote/mapmatch/SATInfo;

    goto :goto_0

    .line 787
    :cond_1
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_si_dummy:Lcom/tw/mapmatch/remote/mapmatch/SATInfo;

    goto :goto_0
.end method

.method public GetStringNmea()Ljava/lang/String;
    .locals 1

    .prologue
    .line 791
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->nmea0183Data_2:Ljava/lang/String;

    return-object v0
.end method

.method public InitGPS()V
    .locals 4

    .prologue
    .line 805
    const-string v2, "inavi3d_hslee"

    const-string v3, "InitGPS() is called"

    invoke-static {v2, v3}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 806
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->mmcHandler:Landroid/os/Handler;

    const/16 v3, 0x3e9

    invoke-virtual {v2, v3}, Landroid/os/Handler;->obtainMessage(I)Landroid/os/Message;

    move-result-object v1

    .line 807
    .local v1, "msg":Landroid/os/Message;
    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    .line 809
    .local v0, "data":Landroid/os/Bundle;
    const-string v2, "MsgType"

    sget-object v3, Lcom/thinkware/sundo/inavi3dservice/MMCModule$MSGTYPE;->COLDSTART:Lcom/thinkware/sundo/inavi3dservice/MMCModule$MSGTYPE;

    invoke-virtual {v3}, Lcom/thinkware/sundo/inavi3dservice/MMCModule$MSGTYPE;->value()S

    move-result v3

    invoke-virtual {v0, v2, v3}, Landroid/os/Bundle;->putShort(Ljava/lang/String;S)V

    .line 811
    sget-object v2, Landroid/os/Build;->DEVICE:Ljava/lang/String;

    const-string v3, "dixon"

    invoke-virtual {v2, v3}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v2

    if-nez v2, :cond_0

    sget-object v2, Landroid/os/Build;->MODEL:Ljava/lang/String;

    const-string v3, "K11"

    invoke-virtual {v2, v3}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v2

    if-nez v2, :cond_0

    sget-object v2, Landroid/os/Build;->DEVICE:Ljava/lang/String;

    const-string v3, "dixie"

    invoke-virtual {v2, v3}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v2

    if-nez v2, :cond_0

    sget-object v2, Landroid/os/Build;->MODEL:Ljava/lang/String;

    const-string v3, "R11"

    invoke-virtual {v2, v3}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v2

    if-nez v2, :cond_0

    sget-object v2, Landroid/os/Build;->DEVICE:Ljava/lang/String;

    const-string v3, "drone"

    invoke-virtual {v2, v3}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v2

    if-nez v2, :cond_0

    sget-object v2, Landroid/os/Build;->MODEL:Ljava/lang/String;

    const-string v3, "R11S"

    invoke-virtual {v2, v3}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1

    .line 815
    :cond_0
    const-string v2, "GpsType"

    sget-object v3, Lcom/thinkware/sundo/inavi3dservice/MMCModule$GPSTYPE;->ANDROID_DEFAULT:Lcom/thinkware/sundo/inavi3dservice/MMCModule$GPSTYPE;

    invoke-virtual {v3}, Lcom/thinkware/sundo/inavi3dservice/MMCModule$GPSTYPE;->value()S

    move-result v3

    invoke-virtual {v0, v2, v3}, Landroid/os/Bundle;->putShort(Ljava/lang/String;S)V

    .line 833
    :goto_0
    invoke-virtual {v1, v0}, Landroid/os/Message;->setData(Landroid/os/Bundle;)V

    .line 834
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->mmcHandler:Landroid/os/Handler;

    invoke-virtual {v2, v1}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    .line 835
    return-void

    .line 819
    :cond_1
    const-string v2, "GpsType"

    sget-object v3, Lcom/thinkware/sundo/inavi3dservice/MMCModule$GPSTYPE;->OLD_ATHEROS:Lcom/thinkware/sundo/inavi3dservice/MMCModule$GPSTYPE;

    invoke-virtual {v3}, Lcom/thinkware/sundo/inavi3dservice/MMCModule$GPSTYPE;->value()S

    move-result v3

    invoke-virtual {v0, v2, v3}, Landroid/os/Bundle;->putShort(Ljava/lang/String;S)V

    goto :goto_0
.end method

.method public SetLastDpCoordinate(III)V
    .locals 1
    .param p1, "nX"    # I
    .param p2, "nY"    # I
    .param p3, "nCarAngle"    # I

    .prologue
    .line 863
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    invoke-virtual {v0, p1, p2, p3}, Lcom/tw/mapmatch/jni/Natives;->nativeSetLastDpCoordinate(III)V

    .line 864
    return-void
.end method

.method public SetSpeedMode(I)V
    .locals 0
    .param p1, "nSpeedMode"    # I

    .prologue
    .line 1179
    iput p1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_nSpeedMode:I

    .line 1180
    return-void
.end method

.method public StartMapMatch()V
    .locals 6

    .prologue
    const/4 v5, 0x0

    const/4 v4, 0x1

    .line 322
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_ctxtParent:Landroid/content/Context;

    invoke-virtual {v1}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v1

    const-string v2, "gps"

    invoke-direct {p0, v1, v2}, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->isLocationProviderEnabled(Landroid/content/ContentResolver;Ljava/lang/String;)Z

    move-result v1

    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsGPSConfiguration:Z

    .line 324
    invoke-direct {p0}, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->createLocationManager()V

    .line 328
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    sget-object v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->kStorageRoot:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "/mapdata/"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/tw/mapmatch/jni/Natives;->nativeInitMap(Ljava/lang/String;)I

    .line 332
    invoke-direct {p0}, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->getGpsMode()Ljava/lang/String;

    move-result-object v0

    .line 333
    .local v0, "gpsMode":Ljava/lang/String;
    const-string v1, "1"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_0

    .line 334
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    invoke-virtual {v1, v4}, Lcom/tw/mapmatch/jni/Natives;->nativeSetUseDRSolution(Z)V

    .line 339
    :goto_0
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    invoke-virtual {v1, v4}, Lcom/tw/mapmatch/jni/Natives;->nativeSetUseCNModule(Z)V

    .line 341
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    const/4 v2, 0x2

    invoke-virtual {v1, v2}, Lcom/tw/mapmatch/jni/Natives;->nativeSetUseVDrive(I)V

    .line 344
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsRunning:[Z

    aput-boolean v4, v1, v5

    .line 345
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsRunning:[Z

    aput-boolean v4, v1, v4

    .line 350
    return-void

    .line 336
    :cond_0
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    invoke-virtual {v1, v5}, Lcom/tw/mapmatch/jni/Natives;->nativeSetUseDRSolution(Z)V

    goto :goto_0
.end method

.method public StopMapMatch()V
    .locals 10

    .prologue
    const/16 v9, 0x7d0

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v5, 0x0

    .line 377
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->gravityModule:Lcom/thinkware/sundo/inavi3dservice/GravityModule;

    if-eqz v2, :cond_0

    .line 379
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->gravityModule:Lcom/thinkware/sundo/inavi3dservice/GravityModule;

    invoke-virtual {v2}, Lcom/thinkware/sundo/inavi3dservice/GravityModule;->endGravity()V

    .line 381
    :cond_0
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_locManager:Landroid/location/LocationManager;

    if-eqz v2, :cond_2

    .line 383
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v2

    invoke-virtual {v2}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->IsThinkwareDevice()Z

    move-result v2

    if-ne v2, v7, :cond_1

    .line 384
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_locManager:Landroid/location/LocationManager;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_provider:Ljava/lang/String;

    iget-object v4, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->cmd02:Ljava/lang/String;

    invoke-virtual {v2, v3, v4, v5}, Landroid/location/LocationManager;->sendExtraCommand(Ljava/lang/String;Ljava/lang/String;Landroid/os/Bundle;)Z

    .line 386
    :cond_1
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_locManager:Landroid/location/LocationManager;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->locationListener:Landroid/location/LocationListener;

    invoke-virtual {v2, v3}, Landroid/location/LocationManager;->removeUpdates(Landroid/location/LocationListener;)V

    .line 387
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_locManager:Landroid/location/LocationManager;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->nmeaListener:Landroid/location/GpsStatus$NmeaListener;

    invoke-virtual {v2, v3}, Landroid/location/LocationManager;->removeNmeaListener(Landroid/location/GpsStatus$NmeaListener;)V

    .line 390
    iput-object v5, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_locManager:Landroid/location/LocationManager;

    .line 393
    :cond_2
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsRunning:[Z

    aget-boolean v2, v2, v8

    if-ne v2, v7, :cond_3

    .line 394
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsRunning:[Z

    aput-boolean v6, v2, v8

    .line 397
    const-wide/16 v2, 0xfa

    :try_start_0
    invoke-static {v2, v3}, Ljava/lang/Thread;->sleep(J)V

    .line 398
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_LogThread:Ljava/lang/Thread;

    invoke-virtual {v2}, Ljava/lang/Thread;->interrupt()V

    .line 399
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_LogThread:Ljava/lang/Thread;

    invoke-virtual {v2}, Ljava/lang/Thread;->join()V
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0

    .line 403
    :goto_0
    iput-object v5, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_LogThread:Ljava/lang/Thread;

    .line 407
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->gravityModule:Lcom/thinkware/sundo/inavi3dservice/GravityModule;

    const-string v3, "GPS_SENSOR"

    const-string v4, "dummy"

    invoke-virtual {v2, v3, v4}, Lcom/thinkware/sundo/inavi3dservice/GravityModule;->initializeGravity(Ljava/lang/String;Ljava/lang/String;)I

    .line 411
    :cond_3
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsRunning:[Z

    aput-boolean v6, v2, v6

    .line 412
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsRunning:[Z

    aput-boolean v6, v2, v7

    .line 414
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmcThread:Ljava/lang/Thread;

    if-eqz v2, :cond_4

    .line 418
    const-wide/16 v2, 0xfa

    :try_start_1
    invoke-static {v2, v3}, Ljava/lang/Thread;->sleep(J)V

    .line 419
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmcThread:Ljava/lang/Thread;

    invoke-virtual {v2}, Ljava/lang/Thread;->interrupt()V

    .line 420
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmcThread:Ljava/lang/Thread;

    invoke-virtual {v2}, Ljava/lang/Thread;->join()V
    :try_end_1
    .catch Ljava/lang/InterruptedException; {:try_start_1 .. :try_end_1} :catch_1

    .line 426
    :goto_1
    iput-object v5, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmcThread:Ljava/lang/Thread;

    .line 431
    :cond_4
    :try_start_2
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->reader:Ljava/io/BufferedReader;

    if-eqz v2, :cond_5

    .line 432
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->reader:Ljava/io/BufferedReader;

    invoke-virtual {v2}, Ljava/io/BufferedReader;->close()V

    .line 433
    :cond_5
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->fin:Ljava/io/FileInputStream;

    if-eqz v2, :cond_6

    .line 434
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->fin:Ljava/io/FileInputStream;

    invoke-virtual {v2}, Ljava/io/FileInputStream;->close()V

    .line 436
    :cond_6
    const/4 v2, 0x0

    iput-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->reader:Ljava/io/BufferedReader;

    .line 437
    const/4 v2, 0x0

    iput-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->fin:Ljava/io/FileInputStream;
    :try_end_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_2

    .line 448
    :goto_2
    return-void

    .line 400
    :catch_0
    move-exception v1

    .line 401
    .local v1, "ie":Ljava/lang/InterruptedException;
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_ctxtParent:Landroid/content/Context;

    const-string v3, "InterruptedException m_LogThread"

    invoke-static {v2, v3, v9}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v2

    invoke-virtual {v2}, Landroid/widget/Toast;->show()V

    goto :goto_0

    .line 421
    .end local v1    # "ie":Ljava/lang/InterruptedException;
    :catch_1
    move-exception v1

    .line 422
    .restart local v1    # "ie":Ljava/lang/InterruptedException;
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_ctxtParent:Landroid/content/Context;

    const-string v3, "InterruptedException m_mmcThread"

    invoke-static {v2, v3, v9}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v2

    invoke-virtual {v2}, Landroid/widget/Toast;->show()V

    goto :goto_1

    .line 440
    .end local v1    # "ie":Ljava/lang/InterruptedException;
    :catch_2
    move-exception v0

    .line 442
    .local v0, "ex":Ljava/io/IOException;
    iput-object v5, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->reader:Ljava/io/BufferedReader;

    .line 443
    iput-object v5, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->fin:Ljava/io/FileInputStream;

    goto :goto_2
.end method

.method public getGPSUpdateTime()I
    .locals 2

    .prologue
    .line 960
    const/4 v0, 0x0

    .line 961
    .local v0, "nRet":I
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    if-eqz v1, :cond_0

    .line 962
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    invoke-virtual {v1}, Lcom/tw/mapmatch/jni/Natives;->nativeGetGPSUpdateTime()I

    move-result v0

    .line 964
    :cond_0
    return v0
.end method

.method public getIsEscapeLinkNowFlag()Z
    .locals 2

    .prologue
    .line 951
    const/4 v0, 0x0

    .line 952
    .local v0, "bRet":Z
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    if-eqz v1, :cond_0

    .line 953
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    invoke-virtual {v1}, Lcom/tw/mapmatch/jni/Natives;->nativeGetIsEscapeLinkNowFlag()Z

    move-result v0

    .line 955
    :cond_0
    return v0
.end method

.method public getSensorActionStatus()I
    .locals 1

    .prologue
    .line 969
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->gravityModule:Lcom/thinkware/sundo/inavi3dservice/GravityModule;

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3dservice/GravityModule;->getSensorActionStatus()I

    move-result v0

    return v0
.end method

.method public getSensorErrorStatus()I
    .locals 1

    .prologue
    .line 973
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->gravityModule:Lcom/thinkware/sundo/inavi3dservice/GravityModule;

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3dservice/GravityModule;->getSensorErrorStatus()I

    move-result v0

    return v0
.end method

.method public getSensorSensiblityStatus()I
    .locals 1

    .prologue
    .line 981
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->gravityModule:Lcom/thinkware/sundo/inavi3dservice/GravityModule;

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3dservice/GravityModule;->getSensorSensiblityStatus()I

    move-result v0

    return v0
.end method

.method public getSensorUseStatus()I
    .locals 1

    .prologue
    .line 977
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->gravityModule:Lcom/thinkware/sundo/inavi3dservice/GravityModule;

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3dservice/GravityModule;->getSensorUseStatus()I

    move-result v0

    return v0
.end method

.method public getSimulatePause()Z
    .locals 2

    .prologue
    .line 876
    const/4 v0, 0x0

    .line 878
    .local v0, "bRet":Z
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    if-eqz v1, :cond_0

    .line 879
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    invoke-virtual {v1}, Lcom/tw/mapmatch/jni/Natives;->nativeGetSimulatePause()Z

    move-result v0

    .line 882
    :cond_0
    return v0
.end method

.method public getSimulatePos()I
    .locals 2

    .prologue
    .line 867
    const/4 v0, 0x0

    .line 869
    .local v0, "nRet":I
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    if-eqz v1, :cond_0

    .line 870
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    invoke-virtual {v1}, Lcom/tw/mapmatch/jni/Natives;->nativeGetSimulatePos()I

    move-result v0

    .line 873
    :cond_0
    return v0
.end method

.method public isLogDrive()Z
    .locals 1

    .prologue
    .line 253
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->bIsLogDrive:Z

    return v0
.end method

.method public setCRoadSkipMode(Z)V
    .locals 4
    .param p1, "bCRSkipMode"    # Z

    .prologue
    .line 926
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->mmcHandler:Landroid/os/Handler;

    const/16 v3, 0x3ec

    invoke-virtual {v2, v3}, Landroid/os/Handler;->obtainMessage(I)Landroid/os/Message;

    move-result-object v1

    .line 927
    .local v1, "msg":Landroid/os/Message;
    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    .line 928
    .local v0, "data":Landroid/os/Bundle;
    const-string v2, "setCRoadSkipMode"

    const/4 v3, 0x1

    invoke-virtual {v0, v2, v3}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 929
    const-string v2, "bCRSkipMode"

    invoke-virtual {v0, v2, p1}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 930
    invoke-virtual {v1, v0}, Landroid/os/Message;->setData(Landroid/os/Bundle;)V

    .line 931
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->mmcHandler:Landroid/os/Handler;

    invoke-virtual {v2, v1}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    .line 932
    return-void
.end method

.method public setDRMString(Ljava/lang/String;)Z
    .locals 2
    .param p1, "SDRM4MMC"    # Ljava/lang/String;

    .prologue
    .line 369
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    invoke-virtual {v1, p1}, Lcom/tw/mapmatch/jni/Natives;->nativeSetDRMString(Ljava/lang/String;)Z

    move-result v0

    .line 372
    .local v0, "bRet":Z
    return v0
.end method

.method public setIsEscapeLinkNowFlag(Z)V
    .locals 1
    .param p1, "bEscape"    # Z

    .prologue
    .line 944
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    if-eqz v0, :cond_0

    .line 945
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    invoke-virtual {v0, p1}, Lcom/tw/mapmatch/jni/Natives;->nativeSetIsEscapeLinkNowFlag(Z)V

    .line 947
    :cond_0
    return-void
.end method

.method public setLastPosSavedInZone(Z)V
    .locals 1
    .param p1, "bSaved"    # Z

    .prologue
    .line 937
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    if-eqz v0, :cond_0

    .line 938
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    invoke-virtual {v0, p1}, Lcom/tw/mapmatch/jni/Natives;->nativeSetLastPosSavedInZone(Z)V

    .line 940
    :cond_0
    return-void
.end method

.method public setLogDrive(ZLjava/lang/String;)V
    .locals 9
    .param p1, "val"    # Z
    .param p2, "strPath"    # Ljava/lang/String;

    .prologue
    const/16 v8, 0x3eb

    const/4 v7, 0x0

    const/4 v4, 0x2

    const/4 v6, 0x1

    .line 192
    if-ne p1, v6, :cond_2

    .line 193
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsRunning:[Z

    aget-boolean v3, v3, v4

    if-ne v3, v6, :cond_1

    .line 249
    :cond_0
    :goto_0
    return-void

    .line 196
    :cond_1
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsRunning:[Z

    aput-boolean v6, v3, v4

    .line 199
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->gravityModule:Lcom/thinkware/sundo/inavi3dservice/GravityModule;

    invoke-virtual {v3}, Lcom/thinkware/sundo/inavi3dservice/GravityModule;->endGravity()V

    .line 201
    const-wide/16 v4, 0x1f4

    :try_start_0
    invoke-static {v4, v5}, Ljava/lang/Thread;->sleep(J)V
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_1

    .line 209
    :goto_1
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->mmcHandler:Landroid/os/Handler;

    invoke-virtual {v3, v8}, Landroid/os/Handler;->obtainMessage(I)Landroid/os/Message;

    move-result-object v2

    .line 210
    .local v2, "msg":Landroid/os/Message;
    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    .line 211
    .local v0, "data":Landroid/os/Bundle;
    const-string v3, "startGravity"

    invoke-virtual {v0, v3, v6}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 212
    const-string v3, "strPath"

    invoke-virtual {v0, v3, p2}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 213
    invoke-virtual {v2, v0}, Landroid/os/Message;->setData(Landroid/os/Bundle;)V

    .line 214
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->mmcHandler:Landroid/os/Handler;

    invoke-virtual {v3, v2}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    .line 248
    :goto_2
    iput-boolean p1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->bIsLogDrive:Z

    goto :goto_0

    .line 217
    .end local v0    # "data":Landroid/os/Bundle;
    .end local v2    # "msg":Landroid/os/Message;
    :cond_2
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsRunning:[Z

    aget-boolean v3, v3, v4

    if-eqz v3, :cond_0

    .line 220
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsRunning:[Z

    aput-boolean v7, v3, v4

    .line 224
    const-wide/16 v4, 0xfa

    :try_start_1
    invoke-static {v4, v5}, Ljava/lang/Thread;->sleep(J)V

    .line 225
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_LogThread:Ljava/lang/Thread;

    invoke-virtual {v3}, Ljava/lang/Thread;->interrupt()V

    .line 226
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_LogThread:Ljava/lang/Thread;

    invoke-virtual {v3}, Ljava/lang/Thread;->join()V
    :try_end_1
    .catch Ljava/lang/InterruptedException; {:try_start_1 .. :try_end_1} :catch_0

    .line 230
    :goto_3
    const/4 v3, 0x0

    iput-object v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_LogThread:Ljava/lang/Thread;

    .line 236
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->mmcHandler:Landroid/os/Handler;

    invoke-virtual {v3, v8}, Landroid/os/Handler;->obtainMessage(I)Landroid/os/Message;

    move-result-object v2

    .line 237
    .restart local v2    # "msg":Landroid/os/Message;
    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    .line 238
    .restart local v0    # "data":Landroid/os/Bundle;
    const-string v3, "startGravity"

    invoke-virtual {v0, v3, v7}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 239
    invoke-virtual {v2, v0}, Landroid/os/Message;->setData(Landroid/os/Bundle;)V

    .line 240
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->mmcHandler:Landroid/os/Handler;

    invoke-virtual {v3, v2}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto :goto_2

    .line 227
    .end local v0    # "data":Landroid/os/Bundle;
    .end local v2    # "msg":Landroid/os/Message;
    :catch_0
    move-exception v1

    .line 228
    .local v1, "ie":Ljava/lang/InterruptedException;
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_ctxtParent:Landroid/content/Context;

    const-string v4, "InterruptedException m_LogThread"

    const/16 v5, 0x7d0

    invoke-static {v3, v4, v5}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v3

    invoke-virtual {v3}, Landroid/widget/Toast;->show()V

    goto :goto_3

    .line 202
    .end local v1    # "ie":Ljava/lang/InterruptedException;
    :catch_1
    move-exception v3

    goto :goto_1
.end method

.method public setMapMatchWalk(Z)V
    .locals 6
    .param p1, "val"    # Z

    .prologue
    const/4 v5, 0x0

    const/4 v4, 0x1

    .line 165
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->mmcHandler:Landroid/os/Handler;

    const/16 v3, 0x3ea

    invoke-virtual {v2, v3}, Landroid/os/Handler;->obtainMessage(I)Landroid/os/Message;

    move-result-object v1

    .line 166
    .local v1, "msg":Landroid/os/Message;
    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    .line 167
    .local v0, "data":Landroid/os/Bundle;
    const-string v2, "bIsSensor"

    invoke-virtual {v0, v2, v4}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 168
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->getSensorUseStatus()I

    move-result v2

    if-nez v2, :cond_0

    .line 169
    const-string v2, "bIsSensor"

    invoke-virtual {v0, v2, v5}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 172
    :cond_0
    if-ne p1, v4, :cond_1

    .line 173
    iput-boolean v5, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsCar:Z

    .line 178
    :goto_0
    invoke-virtual {v1, v0}, Landroid/os/Message;->setData(Landroid/os/Bundle;)V

    .line 179
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->mmcHandler:Landroid/os/Handler;

    invoke-virtual {v2, v1}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    .line 188
    return-void

    .line 175
    :cond_1
    iput-boolean v4, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_bIsCar:Z

    goto :goto_0
.end method

.method public setRouteTable([BI)V
    .locals 5
    .param p1, "buffer"    # [B
    .param p2, "nLength"    # I

    .prologue
    .line 845
    sget-object v2, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->mm_mutex:Ljava/lang/Object;

    monitor-enter v2

    .line 848
    :try_start_0
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    array-length v3, p1

    invoke-virtual {v1, p1, v3}, Lcom/tw/mapmatch/jni/Natives;->nativeSetRouteTable([BI)I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 854
    :goto_0
    :try_start_1
    monitor-exit v2

    .line 855
    return-void

    .line 850
    :catch_0
    move-exception v0

    .line 852
    .local v0, "ex":Ljava/lang/Exception;
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_ctxtParent:Landroid/content/Context;

    const-string v3, "IOException route table"

    const/16 v4, 0x7d0

    invoke-static {v1, v3, v4}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v1

    invoke-virtual {v1}, Landroid/widget/Toast;->show()V

    goto :goto_0

    .line 854
    .end local v0    # "ex":Ljava/lang/Exception;
    :catchall_0
    move-exception v1

    monitor-exit v2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw v1
.end method

.method public setRouteTableInDirect(Ljava/lang/String;)V
    .locals 1
    .param p1, "fileName"    # Ljava/lang/String;

    .prologue
    .line 858
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    invoke-virtual {v0, p1}, Lcom/tw/mapmatch/jni/Natives;->nativeSetRouteTableInDirect(Ljava/lang/String;)I

    .line 859
    return-void
.end method

.method public setSimulatePause(Z)V
    .locals 4
    .param p1, "bPause"    # Z

    .prologue
    .line 894
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->mmcHandler:Landroid/os/Handler;

    const/16 v3, 0x3ec

    invoke-virtual {v2, v3}, Landroid/os/Handler;->obtainMessage(I)Landroid/os/Message;

    move-result-object v1

    .line 895
    .local v1, "msg":Landroid/os/Message;
    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    .line 896
    .local v0, "data":Landroid/os/Bundle;
    const-string v2, "setSimulatePause"

    const/4 v3, 0x1

    invoke-virtual {v0, v2, v3}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 897
    const-string v2, "bPause"

    invoke-virtual {v0, v2, p1}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 898
    invoke-virtual {v1, v0}, Landroid/os/Message;->setData(Landroid/os/Bundle;)V

    .line 899
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->mmcHandler:Landroid/os/Handler;

    invoke-virtual {v2, v1}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    .line 900
    return-void
.end method

.method public setSimulatePercentage(I)V
    .locals 4
    .param p1, "nPercentage"    # I

    .prologue
    .line 918
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->mmcHandler:Landroid/os/Handler;

    const/16 v3, 0x3ec

    invoke-virtual {v2, v3}, Landroid/os/Handler;->obtainMessage(I)Landroid/os/Message;

    move-result-object v1

    .line 919
    .local v1, "msg":Landroid/os/Message;
    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    .line 920
    .local v0, "data":Landroid/os/Bundle;
    const-string v2, "setSimulatePercentage"

    const/4 v3, 0x1

    invoke-virtual {v0, v2, v3}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 921
    const-string v2, "nPercentage"

    invoke-virtual {v0, v2, p1}, Landroid/os/Bundle;->putInt(Ljava/lang/String;I)V

    .line 922
    invoke-virtual {v1, v0}, Landroid/os/Message;->setData(Landroid/os/Bundle;)V

    .line 923
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->mmcHandler:Landroid/os/Handler;

    invoke-virtual {v2, v1}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    .line 924
    return-void
.end method

.method public setSimulatePos(I)V
    .locals 4
    .param p1, "nPos"    # I

    .prologue
    .line 886
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->mmcHandler:Landroid/os/Handler;

    const/16 v3, 0x3ec

    invoke-virtual {v2, v3}, Landroid/os/Handler;->obtainMessage(I)Landroid/os/Message;

    move-result-object v1

    .line 887
    .local v1, "msg":Landroid/os/Message;
    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    .line 888
    .local v0, "data":Landroid/os/Bundle;
    const-string v2, "setSimulatePos"

    const/4 v3, 0x1

    invoke-virtual {v0, v2, v3}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 889
    const-string v2, "nPos"

    invoke-virtual {v0, v2, p1}, Landroid/os/Bundle;->putInt(Ljava/lang/String;I)V

    .line 890
    invoke-virtual {v1, v0}, Landroid/os/Message;->setData(Landroid/os/Bundle;)V

    .line 891
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->mmcHandler:Landroid/os/Handler;

    invoke-virtual {v2, v1}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    .line 892
    return-void
.end method

.method public setSimulateSpeed(I)V
    .locals 4
    .param p1, "nSpeed"    # I

    .prologue
    .line 910
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->mmcHandler:Landroid/os/Handler;

    const/16 v3, 0x3ec

    invoke-virtual {v2, v3}, Landroid/os/Handler;->obtainMessage(I)Landroid/os/Message;

    move-result-object v1

    .line 911
    .local v1, "msg":Landroid/os/Message;
    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    .line 912
    .local v0, "data":Landroid/os/Bundle;
    const-string v2, "setSimulateSpeed"

    const/4 v3, 0x1

    invoke-virtual {v0, v2, v3}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 913
    const-string v2, "nSpeed"

    invoke-virtual {v0, v2, p1}, Landroid/os/Bundle;->putInt(Ljava/lang/String;I)V

    .line 914
    invoke-virtual {v1, v0}, Landroid/os/Message;->setData(Landroid/os/Bundle;)V

    .line 915
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->mmcHandler:Landroid/os/Handler;

    invoke-virtual {v2, v1}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    .line 916
    return-void
.end method

.method public setSimulateStartStop(Z)V
    .locals 4
    .param p1, "bStart"    # Z

    .prologue
    .line 902
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->mmcHandler:Landroid/os/Handler;

    const/16 v3, 0x3ec

    invoke-virtual {v2, v3}, Landroid/os/Handler;->obtainMessage(I)Landroid/os/Message;

    move-result-object v1

    .line 903
    .local v1, "msg":Landroid/os/Message;
    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    .line 904
    .local v0, "data":Landroid/os/Bundle;
    const-string v2, "setSimulateStartStop"

    const/4 v3, 0x1

    invoke-virtual {v0, v2, v3}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 905
    const-string v2, "bStart"

    invoke-virtual {v0, v2, p1}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 906
    invoke-virtual {v1, v0}, Landroid/os/Message;->setData(Landroid/os/Bundle;)V

    .line 907
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->mmcHandler:Landroid/os/Handler;

    invoke-virtual {v2, v1}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    .line 908
    return-void
.end method

.method public startLogging(Ljava/lang/String;)I
    .locals 7
    .param p1, "fileName"    # Ljava/lang/String;

    .prologue
    .line 1313
    const-wide/16 v4, 0x0

    .line 1324
    .local v4, "timestamp":J
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v4

    .line 1326
    const-string v3, "Asia/Seoul"

    invoke-static {v3}, Ljava/util/TimeZone;->getTimeZone(Ljava/lang/String;)Ljava/util/TimeZone;

    move-result-object v3

    invoke-static {v3}, Ljava/util/TimeZone;->setDefault(Ljava/util/TimeZone;)V

    .line 1327
    new-instance v2, Ljava/text/SimpleDateFormat;

    const-string v3, "yyyyMMdd-HHmmss"

    invoke-direct {v2, v3}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;)V

    .line 1329
    .local v2, "sdf":Ljava/text/SimpleDateFormat;
    new-instance v1, Ljava/util/Date;

    invoke-direct {v1, v4, v5}, Ljava/util/Date;-><init>(J)V

    .line 1333
    .local v1, "now":Ljava/util/Date;
    if-eqz p1, :cond_0

    .line 1334
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v6, "/SENSORLOG-"

    invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v2, v1}, Ljava/text/SimpleDateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v6, ".txt"

    invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 1339
    .local v0, "logFileName":Ljava/lang/String;
    :goto_0
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    invoke-virtual {v3, v0}, Lcom/tw/mapmatch/jni/Natives;->nativeSetLogFileName(Ljava/lang/String;)I

    move-result v3

    return v3

    .line 1336
    .end local v0    # "logFileName":Ljava/lang/String;
    :cond_0
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    sget-object v6, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->kStorageRoot:Ljava/lang/String;

    invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v6, "/SENSORLOG-"

    invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v2, v1}, Ljava/text/SimpleDateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v6, ".txt"

    invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .restart local v0    # "logFileName":Ljava/lang/String;
    goto :goto_0
.end method

.method public stopLogging()I
    .locals 1

    .prologue
    .line 1344
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->m_mmNatives:Lcom/tw/mapmatch/jni/Natives;

    invoke-virtual {v0}, Lcom/tw/mapmatch/jni/Natives;->nativeStopLogging()I

    move-result v0

    return v0
.end method
