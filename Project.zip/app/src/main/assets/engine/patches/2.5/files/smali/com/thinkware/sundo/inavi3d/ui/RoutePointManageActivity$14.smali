.class Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity$14;
.super Ljava/lang/Object;
.source "RoutePointManageActivity.java"

# interfaces
.implements Landroid/widget/AdapterView$OnItemClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;


# direct methods
.method constructor <init>(Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;)V
    .locals 0

    .prologue
    .line 801
    iput-object p1, p0, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity$14;->this$0:Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onItemClick(Landroid/widget/AdapterView;Landroid/view/View;IJ)V
    .locals 7
    .param p2, "arg1"    # Landroid/view/View;
    .param p3, "arg2"    # I
    .param p4, "arg3"    # J
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/AdapterView",
            "<*>;",
            "Landroid/view/View;",
            "IJ)V"
        }
    .end annotation

    .prologue
    .local p1, "arg0":Landroid/widget/AdapterView;, "Landroid/widget/AdapterView<*>;"
    const/4 v6, 0x0

    const/4 v5, -0x1

    .line 807
    move v2, p3

    .line 808
    .local v2, "pos":I
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity$14;->this$0:Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;->m_adapter:Lcom/thinkware/sundo/inavi3d/ui/adapter/RoutePointAdapter;

    invoke-virtual {v3, v2}, Lcom/thinkware/sundo/inavi3d/ui/adapter/RoutePointAdapter;->getItem(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/thinkware/sundo/inavi3d/Struct/POINTMgr_DATA;

    .line 809
    .local v0, "data":Lcom/thinkware/sundo/inavi3d/Struct/POINTMgr_DATA;
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity$14;->this$0:Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;->m_adapter:Lcom/thinkware/sundo/inavi3d/ui/adapter/RoutePointAdapter;

    invoke-virtual {v3, v0}, Lcom/thinkware/sundo/inavi3d/ui/adapter/RoutePointAdapter;->isEmptyItem(Lcom/thinkware/sundo/inavi3d/Struct/POINTMgr_DATA;)Z

    move-result v3

    if-eqz v3, :cond_1

    .line 810
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity$14;->this$0:Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;->m_adapter:Lcom/thinkware/sundo/inavi3d/ui/adapter/RoutePointAdapter;

    invoke-virtual {v3}, Lcom/thinkware/sundo/inavi3d/ui/adapter/RoutePointAdapter;->getDragMode()Z

    move-result v3

    if-nez v3, :cond_0

    .line 812
    new-instance v1, Landroid/content/Intent;

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity$14;->this$0:Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;

    const-class v4, Lcom/thinkware/sundo/inavi3d/ui/GoalPointAddType;

    invoke-direct {v1, v3, v4}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 813
    .local v1, "intent":Landroid/content/Intent;
    const-string v3, "type"

    const/4 v4, 0x4

    invoke-virtual {v1, v3, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 814
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity$14;->this$0:Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;

    invoke-virtual {v3, v1}, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;->startActivity(Landroid/content/Intent;)V

    .line 815
    invoke-static {v6, v6}, Lcom/thinkware/sundo/inavi3d/Inavi;->ToggleViewModeSafe(IZ)Z

    .line 817
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity$14;->this$0:Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;

    invoke-static {v3}, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;->access$600(Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;)V

    .line 831
    .end local v1    # "intent":Landroid/content/Intent;
    :cond_0
    :goto_0
    return-void

    .line 820
    :cond_1
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity$14;->this$0:Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;->m_adapter:Lcom/thinkware/sundo/inavi3d/ui/adapter/RoutePointAdapter;

    invoke-virtual {v3}, Lcom/thinkware/sundo/inavi3d/ui/adapter/RoutePointAdapter;->getDragMode()Z

    move-result v3

    if-nez v3, :cond_2

    .line 821
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity$14;->this$0:Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;

    invoke-static {v3, p3}, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;->access$700(Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;I)V

    .line 822
    :cond_2
    sget v3, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;->mIndex:I

    if-ne v3, p3, :cond_3

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity$14;->this$0:Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;

    invoke-static {v3}, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;->access$800(Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;)Landroid/widget/LinearLayout;

    move-result-object v3

    invoke-virtual {v3}, Landroid/widget/LinearLayout;->getVisibility()I

    move-result v3

    const/16 v4, 0x8

    if-ne v3, v4, :cond_3

    .line 823
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity$14;->this$0:Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;->m_adapter:Lcom/thinkware/sundo/inavi3d/ui/adapter/RoutePointAdapter;

    iput v5, v3, Lcom/thinkware/sundo/inavi3d/ui/adapter/RoutePointAdapter;->mSelIndex:I

    .line 824
    sput v5, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;->mIndex:I

    .line 829
    :goto_1
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity$14;->this$0:Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;->m_adapter:Lcom/thinkware/sundo/inavi3d/ui/adapter/RoutePointAdapter;

    invoke-virtual {v3}, Lcom/thinkware/sundo/inavi3d/ui/adapter/RoutePointAdapter;->notifyDataSetInvalidated()V

    goto :goto_0

    .line 826
    :cond_3
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity$14;->this$0:Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;

    iget-object v3, v3, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;->m_adapter:Lcom/thinkware/sundo/inavi3d/ui/adapter/RoutePointAdapter;

    iput p3, v3, Lcom/thinkware/sundo/inavi3d/ui/adapter/RoutePointAdapter;->mSelIndex:I

    .line 827
    sput p3, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;->mIndex:I

    goto :goto_1
.end method
