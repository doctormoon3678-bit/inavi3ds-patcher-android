.class public Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;
.super Lcom/thinkware/sundo/inavi3d/MainActivity;
.source "NameSearchActivity.java"

# interfaces
.implements Landroid/view/View$OnClickListener;
.implements Landroid/widget/ExpandableListView$OnGroupClickListener;
.implements Landroid/widget/ExpandableListView$OnChildClickListener;
.implements Lcom/thinkware/sundo/inavi3d/ui/SIPMiniLayout$SIPMiniLayoutListener;
.implements Landroid/view/View$OnFocusChangeListener;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity$SimplerExpandableListAdapter;
    }
.end annotation


# static fields
.field private static mPointInfo:Lcom/thinkware/sundo/inavi3d/ui/component/CustumDefine$GUISearchPointData;

.field public static mSearchOption:Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;

.field private static mSip:Lcom/thinkware/sundo/inavi3d/ui/SIPMiniLayout;

.field private static mode:I


# instance fields
.field public addHomeClickListener:Landroid/view/View$OnClickListener;

.field public addPointClickListener:Landroid/view/View$OnClickListener;

.field public addRoutePointClickListener:Landroid/view/View$OnClickListener;

.field bFirst:Z

.field btnTabAddr:Landroid/widget/Button;

.field btnTabAround:Landroid/widget/Button;

.field btnTabICode:Landroid/widget/Button;

.field btnTabName:Landroid/widget/Button;

.field btnTabUnited:Landroid/widget/Button;

.field public editClickListener:Landroid/view/View$OnClickListener;

.field public iInfoClickListener:Landroid/view/View$OnClickListener;

.field mAdapter:Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity$SimplerExpandableListAdapter;

.field mBtnErase:Landroid/widget/Button;

.field mBtnMiddleNameSrch:Landroid/widget/Button;

.field mBtnNoResultSetRegion:Landroid/widget/Button;

.field mBtnSetRegion:Landroid/widget/Button;

.field mChangeRegion:Z

.field mEditInput:Landroid/widget/EditText;

.field mExpandList:Landroid/widget/ExpandableListView;

.field mHandler:Landroid/os/Handler;

.field mImgHelp:Landroid/widget/ImageView;

.field mImgNoResult:Landroid/widget/ImageView;

.field public mQuery:Ljava/lang/String;

.field public mSearchQuery:Ljava/lang/String;

.field mSrchBreak:Z

.field private mTask:Lcom/thinkware/sundo/inavi3d/INaviTask;

.field private mTaskInterface:Lcom/thinkware/sundo/inavi3d/INaviTask$iINaviTaskInterFace;

.field mTextHelpMain:Landroid/widget/TextView;

.field mTextHelpSub:Landroid/widget/TextView;

.field mTextNoResultMain:Landroid/widget/TextView;

.field mTextNoResultSub:Landroid/widget/TextView;

.field mTextResultCount:Landroid/widget/TextView;

.field mWatcher:Landroid/text/TextWatcher;

.field m_StringColorIndex:Lcom/thinkware/sundo/inavi3d/ui/component/SrchResultColorIndex;

.field private m_bAddMode:Z

.field m_bSelectedInGroup:Z

.field m_btnAddHome:Landroid/widget/Button;

.field m_btnAddPoint:Landroid/widget/Button;

.field m_btnAddRoutePoint:Landroid/widget/Button;

.field m_btnEdit:Landroid/widget/Button;

.field m_btnSearchRoute:Landroid/widget/Button;

.field m_btniInfo:Landroid/widget/Button;

.field public m_nResultCnt:I

.field public m_nSelectedItemPosition:I

.field public m_nSelectedSubItemPosition:I

.field public serachRouteClickListener:Landroid/view/View$OnClickListener;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .prologue
    .line 131
    const/4 v0, 0x0

    sput v0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mode:I

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    .prologue
    const/4 v0, -0x1

    const/4 v1, 0x0

    .line 68
    invoke-direct {p0}, Lcom/thinkware/sundo/inavi3d/MainActivity;-><init>()V

    .line 88
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->m_bSelectedInGroup:Z

    .line 90
    iput v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->m_nSelectedItemPosition:I

    .line 91
    iput v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->m_nSelectedSubItemPosition:I

    .line 93
    const-string v0, ""

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mQuery:Ljava/lang/String;

    .line 94
    const-string v0, ""

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mSearchQuery:Ljava/lang/String;

    .line 111
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mSrchBreak:Z

    .line 112
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mChangeRegion:Z

    .line 126
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->bFirst:Z

    .line 128
    iput v1, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->m_nResultCnt:I

    .line 132
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->m_bAddMode:Z

    .line 135
    const/4 v0, 0x0

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mTask:Lcom/thinkware/sundo/inavi3d/INaviTask;

    .line 227
    new-instance v0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity$1;

    invoke-direct {v0, p0}, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity$1;-><init>(Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;)V

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mHandler:Landroid/os/Handler;

    .line 257
    new-instance v0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity$2;

    invoke-direct {v0, p0}, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity$2;-><init>(Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;)V

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mWatcher:Landroid/text/TextWatcher;

    .line 1024
    new-instance v0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity$4;

    invoke-direct {v0, p0}, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity$4;-><init>(Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;)V

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->iInfoClickListener:Landroid/view/View$OnClickListener;

    .line 1047
    new-instance v0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity$5;

    invoke-direct {v0, p0}, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity$5;-><init>(Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;)V

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->addPointClickListener:Landroid/view/View$OnClickListener;

    .line 1089
    new-instance v0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity$6;

    invoke-direct {v0, p0}, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity$6;-><init>(Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;)V

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->serachRouteClickListener:Landroid/view/View$OnClickListener;

    .line 1149
    new-instance v0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity$7;

    invoke-direct {v0, p0}, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity$7;-><init>(Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;)V

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->addRoutePointClickListener:Landroid/view/View$OnClickListener;

    .line 1170
    new-instance v0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity$8;

    invoke-direct {v0, p0}, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity$8;-><init>(Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;)V

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->addHomeClickListener:Landroid/view/View$OnClickListener;

    .line 1194
    new-instance v0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity$9;

    invoke-direct {v0, p0}, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity$9;-><init>(Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;)V

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->editClickListener:Landroid/view/View$OnClickListener;

    .line 1391
    new-instance v0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity$11;

    invoke-direct {v0, p0}, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity$11;-><init>(Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;)V

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mTaskInterface:Lcom/thinkware/sundo/inavi3d/INaviTask$iINaviTaskInterFace;

    return-void
.end method

.method public static SaveOption()V
    .locals 1

    .prologue
    .line 375
    sget-object v0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mSearchOption:Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;

    invoke-static {v0}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->NSSetSearchOption(Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;)V

    .line 376
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->NSSaveSrchOption()V

    .line 378
    return-void
.end method

.method static synthetic access$000()Lcom/thinkware/sundo/inavi3d/ui/component/CustumDefine$GUISearchPointData;
    .locals 1

    .prologue
    .line 68
    sget-object v0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mPointInfo:Lcom/thinkware/sundo/inavi3d/ui/component/CustumDefine$GUISearchPointData;

    return-object v0
.end method

.method static synthetic access$100()I
    .locals 1

    .prologue
    .line 68
    sget v0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mode:I

    return v0
.end method

.method static synthetic access$200()Lcom/thinkware/sundo/inavi3d/ui/SIPMiniLayout;
    .locals 1

    .prologue
    .line 68
    sget-object v0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mSip:Lcom/thinkware/sundo/inavi3d/ui/SIPMiniLayout;

    return-object v0
.end method

.method static synthetic access$202(Lcom/thinkware/sundo/inavi3d/ui/SIPMiniLayout;)Lcom/thinkware/sundo/inavi3d/ui/SIPMiniLayout;
    .locals 0
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3d/ui/SIPMiniLayout;

    .prologue
    .line 68
    sput-object p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mSip:Lcom/thinkware/sundo/inavi3d/ui/SIPMiniLayout;

    return-object p0
.end method

.method static synthetic access$300(Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;)V
    .locals 0
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;

    .prologue
    .line 68
    invoke-direct {p0}, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->tabButtonEnable()V

    return-void
.end method

.method static synthetic access$400(Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;)V
    .locals 0
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;

    .prologue
    .line 68
    invoke-direct {p0}, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->initAsyncUi()V

    return-void
.end method

.method public static getIntentMode()I
    .locals 1

    .prologue
    .line 1242
    sget v0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mode:I

    return v0
.end method

.method private initAsyncUi()V
    .locals 11

    .prologue
    const/16 v10, 0xc

    const/4 v9, 0x1

    const/4 v3, -0x1

    const/4 v2, 0x0

    const/4 v8, 0x0

    .line 1324
    invoke-direct {p0}, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->initUi()V

    .line 1327
    const v0, 0x7f0b03d8

    invoke-virtual {p0, v0}, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mTextResultCount:Landroid/widget/TextView;

    .line 1329
    new-instance v0, Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;

    invoke-direct {v0}, Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;-><init>()V

    sput-object v0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mSearchOption:Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;

    .line 1330
    new-instance v0, Lcom/thinkware/sundo/inavi3d/ui/component/CustumDefine$GUISearchPointData;

    invoke-direct {v0}, Lcom/thinkware/sundo/inavi3d/ui/component/CustumDefine$GUISearchPointData;-><init>()V

    sput-object v0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mPointInfo:Lcom/thinkware/sundo/inavi3d/ui/component/CustumDefine$GUISearchPointData;

    .line 1333
    new-instance v0, Landroid/widget/ExpandableListView;

    invoke-direct {v0, p0}, Landroid/widget/ExpandableListView;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mExpandList:Landroid/widget/ExpandableListView;

    .line 1334
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mExpandList:Landroid/widget/ExpandableListView;

    new-instance v1, Landroid/view/ViewGroup$LayoutParams;

    invoke-direct {v1, v3, v3}, Landroid/view/ViewGroup$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v1}, Landroid/widget/ExpandableListView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 1335
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mExpandList:Landroid/widget/ExpandableListView;

    invoke-virtual {v0, v2}, Landroid/widget/ExpandableListView;->setGroupIndicator(Landroid/graphics/drawable/Drawable;)V

    .line 1336
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mExpandList:Landroid/widget/ExpandableListView;

    invoke-virtual {v0, v2}, Landroid/widget/ExpandableListView;->setChildIndicator(Landroid/graphics/drawable/Drawable;)V

    .line 1337
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mExpandList:Landroid/widget/ExpandableListView;

    invoke-virtual {v0, v8}, Landroid/widget/ExpandableListView;->setSelection(I)V

    .line 1338
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mExpandList:Landroid/widget/ExpandableListView;

    invoke-virtual {v0}, Landroid/widget/ExpandableListView;->clearFocus()V

    .line 1339
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mExpandList:Landroid/widget/ExpandableListView;

    const v1, 0x7f020a24

    invoke-virtual {v0, v1}, Landroid/widget/ExpandableListView;->setBackgroundResource(I)V

    .line 1340
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mExpandList:Landroid/widget/ExpandableListView;

    invoke-virtual {v0, v8}, Landroid/widget/ExpandableListView;->setCacheColorHint(I)V

    .line 1341
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mExpandList:Landroid/widget/ExpandableListView;

    invoke-virtual {v0, v2}, Landroid/widget/ExpandableListView;->setDivider(Landroid/graphics/drawable/Drawable;)V

    .line 1342
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mExpandList:Landroid/widget/ExpandableListView;

    invoke-virtual {v0, v8}, Landroid/widget/ExpandableListView;->setDividerHeight(I)V

    .line 1345
    const v0, 0x7f0b03e0

    invoke-virtual {p0, v0}, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageView;

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mImgNoResult:Landroid/widget/ImageView;

    .line 1346
    const v0, 0x7f0b03e1

    invoke-virtual {p0, v0}, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mTextNoResultMain:Landroid/widget/TextView;

    .line 1347
    const v0, 0x7f0b03e2

    invoke-virtual {p0, v0}, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mTextNoResultSub:Landroid/widget/TextView;

    .line 1349
    new-instance v0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity$SimplerExpandableListAdapter;

    const v3, 0x7f030070

    const v4, 0x7f030079

    iget-object v5, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mExpandList:Landroid/widget/ExpandableListView;

    move-object v1, p0

    move-object v2, p0

    invoke-direct/range {v0 .. v5}, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity$SimplerExpandableListAdapter;-><init>(Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;Landroid/content/Context;IILandroid/widget/ExpandableListView;)V

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mAdapter:Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity$SimplerExpandableListAdapter;

    .line 1350
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mAdapter:Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity$SimplerExpandableListAdapter;

    invoke-virtual {v0, v8}, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity$SimplerExpandableListAdapter;->setGroupCount(I)V

    .line 1354
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->NSPrepareNameSearch()V

    .line 1357
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    move-result-object v0

    invoke-virtual {v0, v10}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->setNameSearchMapLevel(I)V

    .line 1358
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    move-result-object v0

    invoke-virtual {v0, v8}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->setNameSearchViewModeValue(I)V

    .line 1359
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v0

    const v1, 0x7f0b04e3

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getView(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Lcom/thinkware/sundo/inavi3d/ui/component/GpsButton;

    invoke-virtual {v0, v8}, Lcom/thinkware/sundo/inavi3d/ui/component/GpsButton;->setFlightMode(I)V

    .line 1360
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/Inavi;->clearToggleViewModeLevel()V

    .line 1361
    invoke-static {v8, v8}, Lcom/thinkware/sundo/inavi3d/Inavi;->ToggleViewModeSafe(IZ)Z

    .line 1363
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/Inavi;->getMapCenterX()I

    move-result v6

    .line 1364
    .local v6, "pointX":I
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/Inavi;->getMapCenterY()I

    move-result v7

    .line 1365
    .local v7, "pointY":I
    invoke-static {v6, v7}, Lcom/thinkware/sundo/inavi3d/Inavi;->MapNameSearchNoButton(II)V

    .line 1368
    sget-object v0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mSearchOption:Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;

    invoke-static {v0}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->NSGetSearchOption(Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;)V

    .line 1370
    sget-object v0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mSearchOption:Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;

    iget v0, v0, Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;->m_nOption:I

    if-nez v0, :cond_0

    .line 1372
    sget-object v0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mSearchOption:Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;

    iget v0, v0, Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;->m_nAdminCode:I

    if-nez v0, :cond_3

    .line 1373
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mBtnSetRegion:Landroid/widget/Button;

    const-string v1, "\uc804\uad6d"

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 1379
    :cond_0
    :goto_0
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->getIntent()Landroid/content/Intent;

    move-result-object v0

    const-string v1, "mode"

    invoke-virtual {v0, v1, v8}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v0

    sput v0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mode:I

    .line 1380
    sget v0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mode:I

    if-eq v0, v9, :cond_1

    sget v0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mode:I

    const/4 v1, 0x2

    if-eq v0, v1, :cond_1

    sget v0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mode:I

    if-eq v0, v10, :cond_1

    sget v0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mode:I

    const/16 v1, 0xd

    if-eq v0, v1, :cond_1

    sget v0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mode:I

    const/4 v1, 0x4

    if-eq v0, v1, :cond_1

    sget v0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mode:I

    const/4 v1, 0x3

    if-eq v0, v1, :cond_1

    sget v0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mode:I

    const/16 v1, 0xb

    if-ne v0, v1, :cond_2

    .line 1382
    :cond_1
    iput-boolean v9, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->m_bAddMode:Z

    .line 1386
    :cond_2
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/ui/component/SrchResultColorIndex;->getInstance()Lcom/thinkware/sundo/inavi3d/ui/component/SrchResultColorIndex;

    move-result-object v0

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->m_StringColorIndex:Lcom/thinkware/sundo/inavi3d/ui/component/SrchResultColorIndex;

    .line 1387
    return-void

    .line 1374
    :cond_3
    sget-object v0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mSearchOption:Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;->m_strOption:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    if-lez v0, :cond_0

    .line 1375
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mBtnSetRegion:Landroid/widget/Button;

    sget-object v1, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mSearchOption:Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;

    iget-object v1, v1, Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;->m_strOption:Ljava/lang/String;

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    goto :goto_0
.end method

.method private initUi()V
    .locals 2

    .prologue
    .line 1251
    const v0, 0x7f0b004c

    invoke-virtual {p0, v0}, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->btnTabUnited:Landroid/widget/Button;

    .line 1252
    const v0, 0x7f0b004e

    invoke-virtual {p0, v0}, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->btnTabAddr:Landroid/widget/Button;

    .line 1253
    const v0, 0x7f0b004f

    invoke-virtual {p0, v0}, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->btnTabAround:Landroid/widget/Button;

    .line 1254
    const v0, 0x7f0b0050

    invoke-virtual {p0, v0}, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->btnTabICode:Landroid/widget/Button;

    .line 1259
    invoke-direct {p0}, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->tabButtonDesable()V

    .line 1269
    const v0, 0x7f0b03d7

    invoke-virtual {p0, v0}, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/EditText;

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mEditInput:Landroid/widget/EditText;

    .line 1270
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mEditInput:Landroid/widget/EditText;

    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mWatcher:Landroid/text/TextWatcher;

    invoke-virtual {v0, v1}, Landroid/widget/EditText;->addTextChangedListener(Landroid/text/TextWatcher;)V

    .line 1271
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mEditInput:Landroid/widget/EditText;

    invoke-virtual {v0, p0}, Landroid/widget/EditText;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 1272
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mEditInput:Landroid/widget/EditText;

    invoke-virtual {v0, p0}, Landroid/widget/EditText;->setOnFocusChangeListener(Landroid/view/View$OnFocusChangeListener;)V

    .line 1275
    const v0, 0x7f0b03d6

    invoke-virtual {p0, v0}, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mBtnSetRegion:Landroid/widget/Button;

    .line 1276
    const v0, 0x7f0b03d9

    invoke-virtual {p0, v0}, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mBtnErase:Landroid/widget/Button;

    .line 1277
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mBtnSetRegion:Landroid/widget/Button;

    invoke-virtual {v0, p0}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 1278
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mBtnErase:Landroid/widget/Button;

    invoke-virtual {v0, p0}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 1283
    const v0, 0x7f0b03dd

    invoke-virtual {p0, v0}, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageView;

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mImgHelp:Landroid/widget/ImageView;

    .line 1284
    const v0, 0x7f0b03de

    invoke-virtual {p0, v0}, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mTextHelpMain:Landroid/widget/TextView;

    .line 1285
    const v0, 0x7f0b03df

    invoke-virtual {p0, v0}, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mTextHelpSub:Landroid/widget/TextView;

    .line 1287
    const v0, 0x7f0b03e3

    invoke-virtual {p0, v0}, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mBtnNoResultSetRegion:Landroid/widget/Button;

    .line 1288
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mBtnNoResultSetRegion:Landroid/widget/Button;

    invoke-virtual {v0, p0}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 1290
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mEditInput:Landroid/widget/EditText;

    new-instance v1, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity$10;

    invoke-direct {v1, p0}, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity$10;-><init>(Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/EditText;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    .line 1306
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v0

    const v1, 0x7f0b04e7

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getView(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->m_btniInfo:Landroid/widget/Button;

    .line 1307
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v0

    const v1, 0x7f0b04e8

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getView(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->m_btnAddPoint:Landroid/widget/Button;

    .line 1308
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v0

    const v1, 0x7f0b04e9

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getView(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->m_btnSearchRoute:Landroid/widget/Button;

    .line 1310
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v0

    const v1, 0x7f0b04ea

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getView(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->m_btnAddRoutePoint:Landroid/widget/Button;

    .line 1311
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v0

    const v1, 0x7f0b04eb

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getView(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->m_btnAddHome:Landroid/widget/Button;

    .line 1312
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v0

    const v1, 0x7f0b04ec

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getView(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->m_btnEdit:Landroid/widget/Button;

    .line 1315
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->m_btniInfo:Landroid/widget/Button;

    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->iInfoClickListener:Landroid/view/View$OnClickListener;

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 1316
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->m_btnAddPoint:Landroid/widget/Button;

    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->addPointClickListener:Landroid/view/View$OnClickListener;

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 1317
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->m_btnSearchRoute:Landroid/widget/Button;

    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->serachRouteClickListener:Landroid/view/View$OnClickListener;

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 1318
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->m_btnAddRoutePoint:Landroid/widget/Button;

    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->addRoutePointClickListener:Landroid/view/View$OnClickListener;

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 1319
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->m_btnAddHome:Landroid/widget/Button;

    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->addHomeClickListener:Landroid/view/View$OnClickListener;

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 1320
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->m_btnEdit:Landroid/widget/Button;

    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->editClickListener:Landroid/view/View$OnClickListener;

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 1321
    return-void
.end method

.method public static setMapLevelMinus()V
    .locals 3

    .prologue
    .line 184
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    move-result-object v2

    invoke-virtual {v2}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getNameSearchMapLevel()I

    move-result v0

    .line 185
    .local v0, "level":I
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    move-result-object v2

    invoke-virtual {v2}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getNameSearchViewModeValue()I

    move-result v1

    .line 189
    .local v1, "mode":I
    add-int/lit8 v0, v0, -0x1

    .line 190
    const/4 v2, 0x1

    if-ge v0, v2, :cond_0

    .line 191
    const/4 v0, 0x1

    .line 193
    :cond_0
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    move-result-object v2

    invoke-virtual {v2, v0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->setNameSearchMapLevel(I)V

    .line 194
    return-void
.end method

.method public static setMapLevelPlus()V
    .locals 4

    .prologue
    .line 167
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    move-result-object v3

    invoke-virtual {v3}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getNameSearchMapLevel()I

    move-result v0

    .line 168
    .local v0, "level":I
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    move-result-object v3

    invoke-virtual {v3}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getNameSearchViewModeValue()I

    move-result v2

    .line 169
    .local v2, "mode":I
    add-int/lit8 v0, v0, 0x1

    .line 170
    if-nez v2, :cond_1

    .line 171
    const/16 v3, 0xe

    if-le v0, v3, :cond_0

    .line 172
    const/16 v0, 0xe

    .line 180
    :cond_0
    :goto_0
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    move-result-object v3

    invoke-virtual {v3, v0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->setNameSearchMapLevel(I)V

    .line 181
    return-void

    .line 175
    :cond_1
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v3

    invoke-virtual {v3}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getMaxAeroLevel()I

    move-result v1

    .line 176
    .local v1, "maxAeroLevel":I
    if-le v0, v1, :cond_0

    .line 177
    move v0, v1

    goto :goto_0
.end method

.method public static setSIPMiniLayout(I)V
    .locals 1
    .param p0, "visibility"    # I

    .prologue
    .line 138
    sget-object v0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mSip:Lcom/thinkware/sundo/inavi3d/ui/SIPMiniLayout;

    if-eqz v0, :cond_0

    .line 156
    sget-object v0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mSip:Lcom/thinkware/sundo/inavi3d/ui/SIPMiniLayout;

    invoke-virtual {v0, p0}, Lcom/thinkware/sundo/inavi3d/ui/SIPMiniLayout;->setVisibility(I)V

    .line 158
    :cond_0
    return-void
.end method

.method private tabButtonDesable()V
    .locals 3

    .prologue
    const/4 v2, 0x0

    const/4 v1, 0x0

    .line 381
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->btnTabUnited:Landroid/widget/Button;

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setClickable(Z)V

    .line 382
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->btnTabName:Landroid/widget/Button;

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setClickable(Z)V

    .line 383
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->btnTabAddr:Landroid/widget/Button;

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setClickable(Z)V

    .line 384
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->btnTabAround:Landroid/widget/Button;

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setClickable(Z)V

    .line 385
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->btnTabICode:Landroid/widget/Button;

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setClickable(Z)V

    .line 386
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->btnTabUnited:Landroid/widget/Button;

    invoke-virtual {v0, v2}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 387
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->btnTabName:Landroid/widget/Button;

    invoke-virtual {v0, v2}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 388
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->btnTabAddr:Landroid/widget/Button;

    invoke-virtual {v0, v2}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 389
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->btnTabAround:Landroid/widget/Button;

    invoke-virtual {v0, v2}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 390
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->btnTabICode:Landroid/widget/Button;

    invoke-virtual {v0, v2}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 391
    return-void
.end method

.method private tabButtonEnable()V
    .locals 2

    .prologue
    const/4 v1, 0x1

    .line 394
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->btnTabUnited:Landroid/widget/Button;

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setClickable(Z)V

    .line 395
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->btnTabName:Landroid/widget/Button;

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setClickable(Z)V

    .line 396
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->btnTabAddr:Landroid/widget/Button;

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setClickable(Z)V

    .line 397
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->btnTabAround:Landroid/widget/Button;

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setClickable(Z)V

    .line 398
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->btnTabICode:Landroid/widget/Button;

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setClickable(Z)V

    .line 399
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->btnTabUnited:Landroid/widget/Button;

    invoke-virtual {v0, p0}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 400
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->btnTabName:Landroid/widget/Button;

    invoke-virtual {v0, p0}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 401
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->btnTabAddr:Landroid/widget/Button;

    invoke-virtual {v0, p0}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 402
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->btnTabAround:Landroid/widget/Button;

    invoke-virtual {v0, p0}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 403
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->btnTabICode:Landroid/widget/Button;

    invoke-virtual {v0, p0}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 404
    return-void
.end method

.method public static toggleViewMode(I)Z
    .locals 3
    .param p0, "viewMode"    # I

    .prologue
    .line 161
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    move-result-object v1

    invoke-virtual {v1}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getNameSearchMapLevel()I

    move-result v0

    .line 162
    .local v0, "level":I
    sget-object v1, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mPointInfo:Lcom/thinkware/sundo/inavi3d/ui/component/CustumDefine$GUISearchPointData;

    iget v1, v1, Lcom/thinkware/sundo/inavi3d/ui/component/CustumDefine$GUISearchPointData;->m_nPointX:I

    sget-object v2, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mPointInfo:Lcom/thinkware/sundo/inavi3d/ui/component/CustumDefine$GUISearchPointData;

    iget v2, v2, Lcom/thinkware/sundo/inavi3d/ui/component/CustumDefine$GUISearchPointData;->m_nPointY:I

    invoke-static {v1, v2, p0, v0}, Lcom/thinkware/sundo/inavi3d/Inavi;->MapNameSearch(IIII)Z

    move-result v1

    return v1
.end method


# virtual methods
.method public RunNameSearch()V
    .locals 4

    .prologue
    const/4 v3, 0x0

    .line 198
    sget-object v0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mPointInfo:Lcom/thinkware/sundo/inavi3d/ui/component/CustumDefine$GUISearchPointData;

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/ui/component/CustumDefine$GUISearchPointData;->InitMembers()V

    .line 199
    const-string v0, "HYO"

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "NSS RunNameSearch Start: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mSearchQuery:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/thinkware/sundo/inavi3d/LOGTW;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 202
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mSearchQuery:Ljava/lang/String;

    invoke-static {v0}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->NSSetQuery(Ljava/lang/String;)V

    .line 205
    sget-object v0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mSearchOption:Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;

    invoke-static {v0}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->NSSetSearchOption(Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;)V

    .line 207
    iput v3, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->m_nResultCnt:I

    .line 208
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->NSRunNameSearch()I

    move-result v0

    if-lez v0, :cond_0

    .line 209
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->NSGetResultCount()I

    move-result v0

    iput v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->m_nResultCnt:I

    .line 211
    :cond_0
    iget v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->m_nResultCnt:I

    if-nez v0, :cond_1

    .line 214
    sget-object v0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mPointInfo:Lcom/thinkware/sundo/inavi3d/ui/component/CustumDefine$GUISearchPointData;

    iput v3, v0, Lcom/thinkware/sundo/inavi3d/ui/component/CustumDefine$GUISearchPointData;->m_nPointX:I

    .line 215
    sget-object v0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mPointInfo:Lcom/thinkware/sundo/inavi3d/ui/component/CustumDefine$GUISearchPointData;

    iput v3, v0, Lcom/thinkware/sundo/inavi3d/ui/component/CustumDefine$GUISearchPointData;->m_nPointY:I

    .line 216
    sget-object v0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mPointInfo:Lcom/thinkware/sundo/inavi3d/ui/component/CustumDefine$GUISearchPointData;

    const-string v1, ""

    iput-object v1, v0, Lcom/thinkware/sundo/inavi3d/ui/component/CustumDefine$GUISearchPointData;->m_strPoiName:Ljava/lang/String;

    .line 218
    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->SetNoResultPage(Z)V

    .line 223
    :goto_0
    const-string v0, "HYO"

    const-string v1, "NSS RunNameSearch End"

    invoke-static {v0, v1}, Lcom/thinkware/sundo/inavi3d/LOGTW;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 224
    return-void

    .line 221
    :cond_1
    invoke-virtual {p0, v3}, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->SetNoResultPage(Z)V

    goto :goto_0
.end method

.method public SetNoResultPage(Z)V
    .locals 5
    .param p1, "bVal"    # Z

    .prologue
    const/4 v4, 0x0

    const/4 v3, 0x4

    .line 630
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mAdapter:Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity$SimplerExpandableListAdapter;

    iget v1, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->m_nResultCnt:I

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity$SimplerExpandableListAdapter;->setGroupCount(I)V

    .line 631
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mAdapter:Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity$SimplerExpandableListAdapter;

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity$SimplerExpandableListAdapter;->notifyDataSetChanged()V

    .line 634
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mTextResultCount:Landroid/widget/TextView;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "("

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget v2, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->m_nResultCnt:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ")"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 636
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mQuery:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    if-nez v0, :cond_1

    .line 638
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mImgHelp:Landroid/widget/ImageView;

    invoke-virtual {v0, v4}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 639
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mTextHelpMain:Landroid/widget/TextView;

    invoke-virtual {v0, v4}, Landroid/widget/TextView;->setVisibility(I)V

    .line 640
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mTextHelpSub:Landroid/widget/TextView;

    invoke-virtual {v0, v4}, Landroid/widget/TextView;->setVisibility(I)V

    .line 642
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mImgNoResult:Landroid/widget/ImageView;

    invoke-virtual {v0, v3}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 643
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mTextNoResultMain:Landroid/widget/TextView;

    invoke-virtual {v0, v3}, Landroid/widget/TextView;->setVisibility(I)V

    .line 644
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mTextNoResultSub:Landroid/widget/TextView;

    invoke-virtual {v0, v3}, Landroid/widget/TextView;->setVisibility(I)V

    .line 645
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mBtnNoResultSetRegion:Landroid/widget/Button;

    invoke-virtual {v0, v3}, Landroid/widget/Button;->setVisibility(I)V

    .line 686
    :cond_0
    :goto_0
    return-void

    .line 650
    :cond_1
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mImgHelp:Landroid/widget/ImageView;

    invoke-virtual {v0, v3}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 651
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mTextHelpMain:Landroid/widget/TextView;

    invoke-virtual {v0, v3}, Landroid/widget/TextView;->setVisibility(I)V

    .line 652
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mTextHelpSub:Landroid/widget/TextView;

    invoke-virtual {v0, v3}, Landroid/widget/TextView;->setVisibility(I)V

    .line 654
    if-eqz p1, :cond_3

    .line 656
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mImgNoResult:Landroid/widget/ImageView;

    invoke-virtual {v0, v4}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 657
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mTextNoResultMain:Landroid/widget/TextView;

    invoke-virtual {v0, v4}, Landroid/widget/TextView;->setVisibility(I)V

    .line 658
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mTextNoResultSub:Landroid/widget/TextView;

    invoke-virtual {v0, v4}, Landroid/widget/TextView;->setVisibility(I)V

    .line 660
    sget-object v0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mSearchOption:Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;

    iget v0, v0, Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;->m_nAdminCode:I

    if-lez v0, :cond_2

    .line 661
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mBtnNoResultSetRegion:Landroid/widget/Button;

    invoke-virtual {v0, v4}, Landroid/widget/Button;->setVisibility(I)V

    .line 666
    :goto_1
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->setNameSearchVisible()V

    .line 667
    invoke-static {v4}, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->setSIPMiniLayout(I)V

    goto :goto_0

    .line 663
    :cond_2
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mBtnNoResultSetRegion:Landroid/widget/Button;

    invoke-virtual {v0, v3}, Landroid/widget/Button;->setVisibility(I)V

    goto :goto_1

    .line 672
    :cond_3
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mImgNoResult:Landroid/widget/ImageView;

    invoke-virtual {v0, v3}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 673
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mTextNoResultMain:Landroid/widget/TextView;

    invoke-virtual {v0, v3}, Landroid/widget/TextView;->setVisibility(I)V

    .line 674
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mTextNoResultSub:Landroid/widget/TextView;

    invoke-virtual {v0, v3}, Landroid/widget/TextView;->setVisibility(I)V

    .line 675
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mBtnNoResultSetRegion:Landroid/widget/Button;

    invoke-virtual {v0, v3}, Landroid/widget/Button;->setVisibility(I)V

    .line 678
    const/4 v0, -0x1

    iput v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->m_nSelectedItemPosition:I

    .line 680
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mExpandList:Landroid/widget/ExpandableListView;

    if-eqz v0, :cond_0

    .line 681
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mExpandList:Landroid/widget/ExpandableListView;

    invoke-virtual {v0, v4}, Landroid/widget/ExpandableListView;->setSelection(I)V

    .line 682
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mExpandList:Landroid/widget/ExpandableListView;

    invoke-virtual {v0}, Landroid/widget/ExpandableListView;->clearFocus()V

    goto :goto_0
.end method

.method public dummyClick(Landroid/view/View;)V
    .locals 0
    .param p1, "target"    # Landroid/view/View;

    .prologue
    .line 1234
    return-void
.end method

.method protected getContentViewId()I
    .locals 1

    .prologue
    .line 1020
    const v0, 0x7f0b03d5

    return v0
.end method

.method protected onActivityResult(IILandroid/content/Intent;)V
    .locals 3
    .param p1, "requestCode"    # I
    .param p2, "resultCode"    # I
    .param p3, "data"    # Landroid/content/Intent;

    .prologue
    const/4 v2, 0x0

    .line 580
    invoke-super {p0, p1, p2, p3}, Lcom/thinkware/sundo/inavi3d/MainActivity;->onActivityResult(IILandroid/content/Intent;)V

    .line 582
    sparse-switch p1, :sswitch_data_0

    .line 625
    :goto_0
    return-void

    .line 585
    :sswitch_0
    const/4 v1, -0x1

    if-ne p2, v1, :cond_0

    .line 588
    const-string v1, "SearchData"

    invoke-virtual {p3, v1}, Landroid/content/Intent;->getSerializableExtra(Ljava/lang/String;)Ljava/io/Serializable;

    move-result-object v1

    check-cast v1, Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;

    sput-object v1, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mSearchOption:Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;

    .line 591
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->RunNameSearch()V

    .line 594
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->setRegionName()V

    .line 596
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->setNameSearchVisible()V

    .line 597
    invoke-static {v2}, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->setSIPMiniLayout(I)V

    .line 599
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mEditInput:Landroid/widget/EditText;

    invoke-virtual {v1}, Landroid/widget/EditText;->getSelectionEnd()I

    move-result v0

    .line 600
    .local v0, "nEdIdx":I
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mEditInput:Landroid/widget/EditText;

    invoke-virtual {v1, v0}, Landroid/widget/EditText;->setSelection(I)V

    goto :goto_0

    .line 605
    .end local v0    # "nEdIdx":I
    :cond_0
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    move-result-object v1

    const/4 v2, 0x1

    invoke-virtual {v1, v2}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->setInitFlag(Z)V

    goto :goto_0

    .line 609
    :sswitch_1
    packed-switch p2, :pswitch_data_0

    goto :goto_0

    .line 619
    :pswitch_0
    const-string v1, "\uc0ac\uc6a9\uc790 \uc9c0\uc810\uc744 \ub4f1\ub85d\ud558\uc600\uc2b5\ub2c8\ub2e4."

    invoke-static {p0, v1, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v1

    invoke-virtual {v1}, Landroid/widget/Toast;->show()V

    goto :goto_0

    .line 611
    :pswitch_1
    const-string v1, "\uc9d1\uc744 \ub4f1\ub85d \ud558\uc600\uc2b5\ub2c8\ub2e4."

    invoke-static {p0, v1, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v1

    invoke-virtual {v1}, Landroid/widget/Toast;->show()V

    goto :goto_0

    .line 615
    :pswitch_2
    const-string v1, "\uc790\uc8fc\uac00\ub294 \uacf3\uc744 \ub4f1\ub85d \ud558\uc600\uc2b5\ub2c8\ub2e4."

    invoke-static {p0, v1, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v1

    invoke-virtual {v1}, Landroid/widget/Toast;->show()V

    goto :goto_0

    .line 582
    :sswitch_data_0
    .sparse-switch
        0x3e9 -> :sswitch_0
        0x7d2 -> :sswitch_1
    .end sparse-switch

    .line 609
    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_0
        :pswitch_1
        :pswitch_2
    .end packed-switch
.end method

.method public onChildClick(Landroid/widget/ExpandableListView;Landroid/view/View;IIJ)Z
    .locals 6
    .param p1, "parent"    # Landroid/widget/ExpandableListView;
    .param p2, "v"    # Landroid/view/View;
    .param p3, "groupPosition"    # I
    .param p4, "childPosition"    # I
    .param p5, "id"    # J

    .prologue
    const/4 v5, 0x0

    .line 691
    iput p4, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->m_nSelectedSubItemPosition:I

    .line 692
    iput-boolean v5, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->m_bSelectedInGroup:Z

    .line 695
    sget v1, Lcom/thinkware/sundo/inavi3d/ui/component/CustumDefine;->MAP_MOVE:I

    iget v2, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->m_nSelectedItemPosition:I

    iget v3, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->m_nSelectedSubItemPosition:I

    sget-object v4, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mPointInfo:Lcom/thinkware/sundo/inavi3d/ui/component/CustumDefine$GUISearchPointData;

    invoke-static {v1, v2, v3, v4}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->USProcessDirectRouteOrMapMoveSub(IIILcom/thinkware/sundo/inavi3d/ui/component/CustumDefine$GUISearchPointData;)Z

    .line 696
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    move-result-object v1

    invoke-virtual {v1}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getNameSearchViewModeValue()I

    move-result v0

    .line 697
    .local v0, "viewMode":I
    sget-object v1, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mPointInfo:Lcom/thinkware/sundo/inavi3d/ui/component/CustumDefine$GUISearchPointData;

    iget v1, v1, Lcom/thinkware/sundo/inavi3d/ui/component/CustumDefine$GUISearchPointData;->m_nPointX:I

    sget-object v2, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mPointInfo:Lcom/thinkware/sundo/inavi3d/ui/component/CustumDefine$GUISearchPointData;

    iget v2, v2, Lcom/thinkware/sundo/inavi3d/ui/component/CustumDefine$GUISearchPointData;->m_nPointY:I

    invoke-static {v1, v2, v0}, Lcom/thinkware/sundo/inavi3d/Inavi;->MapNameSearchViewMode(III)Z

    .line 699
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->m_btniInfo:Landroid/widget/Button;

    invoke-virtual {v1, v5}, Landroid/widget/Button;->setEnabled(Z)V

    .line 703
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mAdapter:Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity$SimplerExpandableListAdapter;

    invoke-virtual {v1}, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity$SimplerExpandableListAdapter;->notifyDataSetChanged()V

    .line 705
    const/4 v1, 0x1

    return v1
.end method

.method public onClick(Landroid/view/View;)V
    .locals 7
    .param p1, "v"    # Landroid/view/View;

    .prologue
    const/4 v6, -0x1

    const/high16 v5, 0x41f00000    # 30.0f

    const/high16 v2, 0x41d00000    # 26.0f

    const/4 v3, 0x1

    const/4 v4, 0x0

    .line 410
    invoke-virtual {p1}, Landroid/view/View;->getId()I

    move-result v1

    sparse-switch v1, :sswitch_data_0

    .line 539
    :goto_0
    return-void

    .line 413
    :sswitch_0
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->SaveOption()V

    .line 414
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->btnTabName:Landroid/widget/Button;

    invoke-virtual {v1, v4}, Landroid/widget/Button;->setSelected(Z)V

    .line 415
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->btnTabName:Landroid/widget/Button;

    invoke-virtual {v1, v4, v2}, Landroid/widget/Button;->setTextSize(IF)V

    .line 416
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->btnTabUnited:Landroid/widget/Button;

    invoke-virtual {v1, v3}, Landroid/widget/Button;->setSelected(Z)V

    .line 417
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->btnTabUnited:Landroid/widget/Button;

    invoke-virtual {v1, v4, v5}, Landroid/widget/Button;->setTextSize(IF)V

    .line 418
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->btnTabUnited:Landroid/widget/Button;

    invoke-virtual {v1}, Landroid/widget/Button;->postInvalidate()V

    .line 419
    invoke-direct {p0}, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->tabButtonDesable()V

    .line 421
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    move-result-object v1

    invoke-virtual {v1, v3}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->backActivityFromMap(Z)V

    .line 422
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 424
    .local v0, "intent":Landroid/content/Intent;
    const-string v1, "mode"

    sget v2, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mode:I

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 426
    invoke-virtual {p0, v0}, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->startActivity(Landroid/content/Intent;)V

    goto :goto_0

    .line 430
    .end local v0    # "intent":Landroid/content/Intent;
    :sswitch_1
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->SaveOption()V

    .line 431
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->btnTabName:Landroid/widget/Button;

    invoke-virtual {v1, v4}, Landroid/widget/Button;->setSelected(Z)V

    .line 432
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->btnTabName:Landroid/widget/Button;

    invoke-virtual {v1, v4, v2}, Landroid/widget/Button;->setTextSize(IF)V

    .line 433
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->btnTabAddr:Landroid/widget/Button;

    invoke-virtual {v1, v3}, Landroid/widget/Button;->setSelected(Z)V

    .line 434
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->btnTabAddr:Landroid/widget/Button;

    invoke-virtual {v1, v4, v5}, Landroid/widget/Button;->setTextSize(IF)V

    .line 435
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->btnTabAddr:Landroid/widget/Button;

    invoke-virtual {v1}, Landroid/widget/Button;->postInvalidate()V

    .line 436
    invoke-direct {p0}, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->tabButtonDesable()V

    .line 438
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    move-result-object v1

    invoke-virtual {v1, v3}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->backActivityFromMap(Z)V

    .line 439
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcom/thinkware/sundo/inavi3d/ui/AddressSearch;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 441
    .restart local v0    # "intent":Landroid/content/Intent;
    const-string v1, "mode"

    sget v2, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mode:I

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 443
    invoke-virtual {p0, v0}, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->startActivity(Landroid/content/Intent;)V

    goto :goto_0

    .line 447
    .end local v0    # "intent":Landroid/content/Intent;
    :sswitch_2
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->SaveOption()V

    .line 448
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->btnTabName:Landroid/widget/Button;

    invoke-virtual {v1, v4}, Landroid/widget/Button;->setSelected(Z)V

    .line 449
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->btnTabName:Landroid/widget/Button;

    invoke-virtual {v1, v4, v2}, Landroid/widget/Button;->setTextSize(IF)V

    .line 450
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->btnTabAround:Landroid/widget/Button;

    invoke-virtual {v1, v3}, Landroid/widget/Button;->setSelected(Z)V

    .line 451
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->btnTabAround:Landroid/widget/Button;

    invoke-virtual {v1, v4, v5}, Landroid/widget/Button;->setTextSize(IF)V

    .line 452
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->btnTabAround:Landroid/widget/Button;

    invoke-virtual {v1}, Landroid/widget/Button;->postInvalidate()V

    .line 453
    invoke-direct {p0}, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->tabButtonDesable()V

    .line 455
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    move-result-object v1

    invoke-virtual {v1, v3}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->backActivityFromMap(Z)V

    .line 456
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcom/thinkware/sundo/inavi3d/ui/AroundSrchActivity;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 458
    .restart local v0    # "intent":Landroid/content/Intent;
    const-string v1, "mode"

    sget v2, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mode:I

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 460
    invoke-virtual {p0, v0}, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->startActivity(Landroid/content/Intent;)V

    goto/16 :goto_0

    .line 464
    .end local v0    # "intent":Landroid/content/Intent;
    :sswitch_3
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->SaveOption()V

    .line 465
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->btnTabName:Landroid/widget/Button;

    invoke-virtual {v1, v4}, Landroid/widget/Button;->setSelected(Z)V

    .line 466
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->btnTabName:Landroid/widget/Button;

    invoke-virtual {v1, v4, v2}, Landroid/widget/Button;->setTextSize(IF)V

    .line 467
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->btnTabICode:Landroid/widget/Button;

    invoke-virtual {v1, v3}, Landroid/widget/Button;->setSelected(Z)V

    .line 468
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->btnTabICode:Landroid/widget/Button;

    invoke-virtual {v1, v4, v5}, Landroid/widget/Button;->setTextSize(IF)V

    .line 469
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->btnTabICode:Landroid/widget/Button;

    invoke-virtual {v1}, Landroid/widget/Button;->postInvalidate()V

    .line 470
    invoke-direct {p0}, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->tabButtonDesable()V

    .line 472
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    move-result-object v1

    invoke-virtual {v1, v3}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->backActivityFromMap(Z)V

    .line 473
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcom/thinkware/sundo/inavi3d/ui/ICodeSearchActivity;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 475
    .restart local v0    # "intent":Landroid/content/Intent;
    const-string v1, "mode"

    sget v2, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mode:I

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 477
    invoke-virtual {p0, v0}, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->startActivity(Landroid/content/Intent;)V

    goto/16 :goto_0

    .line 482
    .end local v0    # "intent":Landroid/content/Intent;
    :sswitch_4
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mEditInput:Landroid/widget/EditText;

    const-string v2, ""

    invoke-virtual {v1, v2}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    .line 483
    sget-object v1, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mSip:Lcom/thinkware/sundo/inavi3d/ui/SIPMiniLayout;

    invoke-virtual {v1}, Lcom/thinkware/sundo/inavi3d/ui/SIPMiniLayout;->clearText()V

    .line 484
    const-string v1, ""

    iput-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mQuery:Ljava/lang/String;

    .line 485
    sget-object v1, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mSip:Lcom/thinkware/sundo/inavi3d/ui/SIPMiniLayout;

    const-string v2, ""

    invoke-virtual {v1, v2}, Lcom/thinkware/sundo/inavi3d/ui/SIPMiniLayout;->setText(Ljava/lang/CharSequence;)V

    .line 487
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mBtnErase:Landroid/widget/Button;

    const/4 v2, 0x4

    invoke-virtual {v1, v2}, Landroid/widget/Button;->setVisibility(I)V

    .line 489
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mTextResultCount:Landroid/widget/TextView;

    const-string v2, "(0)"

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 491
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mAdapter:Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity$SimplerExpandableListAdapter;

    invoke-virtual {v1, v4}, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity$SimplerExpandableListAdapter;->setGroupCount(I)V

    .line 492
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mAdapter:Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity$SimplerExpandableListAdapter;

    invoke-virtual {v1}, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity$SimplerExpandableListAdapter;->notifyDataSetChanged()V

    .line 494
    iput v6, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->m_nSelectedItemPosition:I

    .line 495
    iput v6, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->m_nSelectedSubItemPosition:I

    .line 497
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->setNameSearchVisible()V

    .line 498
    invoke-static {v4}, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->setSIPMiniLayout(I)V

    goto/16 :goto_0

    .line 503
    :sswitch_5
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcom/thinkware/sundo/inavi3d/ui/SetRegionRadiusActivity;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 504
    .restart local v0    # "intent":Landroid/content/Intent;
    const-string v1, "SearchData"

    sget-object v2, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mSearchOption:Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/io/Serializable;)Landroid/content/Intent;

    .line 505
    const/16 v1, 0x3e9

    invoke-virtual {p0, v0, v1}, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->startActivityForResult(Landroid/content/Intent;I)V

    goto/16 :goto_0

    .line 510
    .end local v0    # "intent":Landroid/content/Intent;
    :sswitch_6
    sget-object v1, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mSearchOption:Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;

    invoke-virtual {v1}, Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;->InitMembers()V

    .line 511
    sget-object v1, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mSearchOption:Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;

    iput v4, v1, Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;->m_nOption:I

    .line 512
    sget-object v1, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mSearchOption:Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;

    const-string v2, "\uc804\uad6d"

    iput-object v2, v1, Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;->m_strOption:Ljava/lang/String;

    .line 513
    sget-object v1, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mSearchOption:Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;

    iput v4, v1, Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;->m_nAdminCode:I

    .line 516
    iget-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mSrchBreak:Z

    if-nez v1, :cond_0

    .line 517
    iput-boolean v3, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mSrchBreak:Z

    .line 520
    :cond_0
    iput-boolean v3, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mChangeRegion:Z

    .line 523
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mBtnSetRegion:Landroid/widget/Button;

    const-string v2, "\uc804\uad6d"

    invoke-virtual {v1, v2}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 526
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mHandler:Landroid/os/Handler;

    const-wide/16 v2, 0x64

    invoke-virtual {v1, v4, v2, v3}, Landroid/os/Handler;->sendEmptyMessageDelayed(IJ)Z

    goto/16 :goto_0

    .line 531
    :sswitch_7
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->setNameSearchVisible()V

    .line 532
    invoke-static {v4}, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->setSIPMiniLayout(I)V

    goto/16 :goto_0

    .line 410
    nop

    :sswitch_data_0
    .sparse-switch
        0x7f0b004c -> :sswitch_0
        0x7f0b004e -> :sswitch_1
        0x7f0b004f -> :sswitch_2
        0x7f0b0050 -> :sswitch_3
        0x7f0b03d6 -> :sswitch_5
        0x7f0b03d7 -> :sswitch_7
        0x7f0b03d9 -> :sswitch_4
        0x7f0b03e3 -> :sswitch_6
    .end sparse-switch
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 4
    .param p1, "savedInstanceState"    # Landroid/os/Bundle;

    .prologue
    const/4 v2, 0x1

    const/4 v3, 0x0

    .line 328
    invoke-super {p0, p1}, Lcom/thinkware/sundo/inavi3d/MainActivity;->onCreate(Landroid/os/Bundle;)V

    .line 329
    const v0, 0x7f030087

    invoke-virtual {p0, v0}, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->setContentView(I)V

    .line 332
    const v0, 0x7f0b004d

    invoke-virtual {p0, v0}, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->btnTabName:Landroid/widget/Button;

    .line 333
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->btnTabName:Landroid/widget/Button;

    invoke-virtual {v0, v2}, Landroid/widget/Button;->setSelected(Z)V

    .line 334
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->btnTabName:Landroid/widget/Button;

    invoke-virtual {v0, v3}, Landroid/widget/Button;->setClickable(Z)V

    .line 335
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->btnTabName:Landroid/widget/Button;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 337
    new-instance v0, Lcom/thinkware/sundo/inavi3d/INaviTask;

    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mTaskInterface:Lcom/thinkware/sundo/inavi3d/INaviTask$iINaviTaskInterFace;

    invoke-direct {v0, v1, v3}, Lcom/thinkware/sundo/inavi3d/INaviTask;-><init>(Lcom/thinkware/sundo/inavi3d/INaviTask$iINaviTaskInterFace;Z)V

    new-array v1, v2, [Ljava/lang/Object;

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    aput-object v2, v1, v3

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/inavi3d/INaviTask;->execute([Ljava/lang/Object;)Landroid/os/AsyncTask;

    move-result-object v0

    check-cast v0, Lcom/thinkware/sundo/inavi3d/INaviTask;

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mTask:Lcom/thinkware/sundo/inavi3d/INaviTask;

    .line 339
    return-void
.end method

.method protected onDestroy()V
    .locals 0

    .prologue
    .line 368
    invoke-super {p0}, Lcom/thinkware/sundo/inavi3d/MainActivity;->onDestroy()V

    .line 370
    return-void
.end method

.method public onFocusChange(Landroid/view/View;Z)V
    .locals 3
    .param p1, "v"    # Landroid/view/View;
    .param p2, "hasFocus"    # Z

    .prologue
    const/4 v2, 0x0

    .line 1451
    invoke-virtual {p1}, Landroid/view/View;->getId()I

    move-result v0

    packed-switch v0, :pswitch_data_0

    .line 1460
    :goto_0
    return-void

    .line 1453
    :pswitch_0
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mEditInput:Landroid/widget/EditText;

    const v1, 0x7f02096c

    invoke-virtual {v0, v1}, Landroid/widget/EditText;->setBackgroundResource(I)V

    .line 1454
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mEditInput:Landroid/widget/EditText;

    const/16 v1, 0x10

    invoke-virtual {v0, v1, v2, v2, v2}, Landroid/widget/EditText;->setPadding(IIII)V

    goto :goto_0

    .line 1451
    nop

    :pswitch_data_0
    .packed-switch 0x7f0b03d7
        :pswitch_0
    .end packed-switch
.end method

.method public onGroupClick(Landroid/widget/ExpandableListView;Landroid/view/View;IJ)Z
    .locals 5
    .param p1, "parent"    # Landroid/widget/ExpandableListView;
    .param p2, "v"    # Landroid/view/View;
    .param p3, "groupPosition"    # I
    .param p4, "id"    # J

    .prologue
    const/4 v4, 0x0

    .line 718
    iput p3, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->m_nSelectedItemPosition:I

    .line 719
    const/4 v1, -0x1

    iput v1, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->m_nSelectedSubItemPosition:I

    .line 720
    const/4 v1, 0x1

    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->m_bSelectedInGroup:Z

    .line 722
    sget v1, Lcom/thinkware/sundo/inavi3d/ui/component/CustumDefine;->MAP_MOVE:I

    iget v2, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->m_nSelectedItemPosition:I

    sget-object v3, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mPointInfo:Lcom/thinkware/sundo/inavi3d/ui/component/CustumDefine$GUISearchPointData;

    invoke-static {v1, v2, v4, v3}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->USProcessDirectRouteOrMapMove(IIZLcom/thinkware/sundo/inavi3d/ui/component/CustumDefine$GUISearchPointData;)Z

    .line 724
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    move-result-object v1

    invoke-virtual {v1}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getNameSearchViewModeValue()I

    move-result v0

    .line 725
    .local v0, "viewMode":I
    sget-object v1, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mPointInfo:Lcom/thinkware/sundo/inavi3d/ui/component/CustumDefine$GUISearchPointData;

    iget v1, v1, Lcom/thinkware/sundo/inavi3d/ui/component/CustumDefine$GUISearchPointData;->m_nPointX:I

    sget-object v2, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mPointInfo:Lcom/thinkware/sundo/inavi3d/ui/component/CustumDefine$GUISearchPointData;

    iget v2, v2, Lcom/thinkware/sundo/inavi3d/ui/component/CustumDefine$GUISearchPointData;->m_nPointY:I

    invoke-static {v1, v2, v0}, Lcom/thinkware/sundo/inavi3d/Inavi;->MapNameSearchViewMode(III)Z

    .line 728
    new-instance v1, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity$3;

    invoke-direct {v1, p0, p3}, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity$3;-><init>(Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;I)V

    invoke-virtual {p0, v1}, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->runOnUiThread(Ljava/lang/Runnable;)V

    .line 749
    return v4
.end method

.method protected onPause()V
    .locals 4

    .prologue
    const/4 v3, 0x0

    .line 343
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mEditInput:Landroid/widget/EditText;

    invoke-virtual {v1}, Landroid/widget/EditText;->getInputType()I

    move-result v0

    .line 344
    .local v0, "inputType":I
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mEditInput:Landroid/widget/EditText;

    invoke-virtual {v1, v3}, Landroid/widget/EditText;->setInputType(I)V

    .line 346
    invoke-super {p0}, Lcom/thinkware/sundo/inavi3d/MainActivity;->onPause()V

    .line 348
    sget-object v1, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mSip:Lcom/thinkware/sundo/inavi3d/ui/SIPMiniLayout;

    invoke-virtual {v1}, Lcom/thinkware/sundo/inavi3d/ui/SIPMiniLayout;->getVisibility()I

    move-result v1

    const/16 v2, 0x8

    if-ne v1, v2, :cond_0

    .line 349
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->setNameSearchVisible()V

    .line 350
    invoke-static {v3}, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->setSIPMiniLayout(I)V

    .line 351
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/Inavi;->resetCustomView()V

    .line 353
    :cond_0
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mEditInput:Landroid/widget/EditText;

    invoke-virtual {v1, v0}, Landroid/widget/EditText;->setInputType(I)V

    .line 355
    const/4 v1, 0x1

    invoke-static {v1}, Lcom/thinkware/sundo/inavi3d/oilprice/OilPriceOnRoute;->SetVisibleOilPrice(Z)V

    .line 356
    return-void
.end method

.method protected onResume()V
    .locals 5

    .prologue
    const/4 v4, 0x0

    .line 295
    invoke-virtual {p0, v4, v4}, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->overridePendingTransition(II)V

    .line 296
    invoke-super {p0}, Lcom/thinkware/sundo/inavi3d/MainActivity;->onResume()V

    .line 298
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mEditInput:Landroid/widget/EditText;

    if-eqz v2, :cond_0

    .line 299
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mEditInput:Landroid/widget/EditText;

    const v3, 0x7f02096e

    invoke-virtual {v2, v3}, Landroid/widget/EditText;->setBackgroundResource(I)V

    .line 300
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mEditInput:Landroid/widget/EditText;

    const/16 v3, 0x10

    invoke-virtual {v2, v3, v4, v4, v4}, Landroid/widget/EditText;->setPadding(IIII)V

    .line 304
    :cond_0
    sget-object v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->inavi_reference:Lcom/thinkware/sundo/inavi3d/Inavi;

    const v3, 0x27103

    invoke-virtual {v2, v3, v4}, Lcom/thinkware/sundo/inavi3d/Inavi;->setTimerEvent(II)V

    .line 306
    iget-boolean v2, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->bFirst:Z

    if-nez v2, :cond_2

    .line 309
    iget v2, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->m_nResultCnt:I

    if-lez v2, :cond_1

    sget-object v2, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mPointInfo:Lcom/thinkware/sundo/inavi3d/ui/component/CustumDefine$GUISearchPointData;

    iget v2, v2, Lcom/thinkware/sundo/inavi3d/ui/component/CustumDefine$GUISearchPointData;->m_nPointX:I

    if-lez v2, :cond_1

    sget-object v2, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mPointInfo:Lcom/thinkware/sundo/inavi3d/ui/component/CustumDefine$GUISearchPointData;

    iget v2, v2, Lcom/thinkware/sundo/inavi3d/ui/component/CustumDefine$GUISearchPointData;->m_nPointY:I

    if-lez v2, :cond_1

    .line 311
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    move-result-object v2

    invoke-virtual {v2}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getNameSearchViewModeValue()I

    move-result v1

    .line 312
    .local v1, "viewMode":I
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    move-result-object v2

    invoke-virtual {v2}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getNameSearchMapLevel()I

    move-result v0

    .line 313
    .local v0, "level":I
    sget-object v2, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mPointInfo:Lcom/thinkware/sundo/inavi3d/ui/component/CustumDefine$GUISearchPointData;

    iget v2, v2, Lcom/thinkware/sundo/inavi3d/ui/component/CustumDefine$GUISearchPointData;->m_nPointX:I

    sget-object v3, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mPointInfo:Lcom/thinkware/sundo/inavi3d/ui/component/CustumDefine$GUISearchPointData;

    iget v3, v3, Lcom/thinkware/sundo/inavi3d/ui/component/CustumDefine$GUISearchPointData;->m_nPointY:I

    invoke-static {v2, v3, v1, v0}, Lcom/thinkware/sundo/inavi3d/Inavi;->MapNameSearch(IIII)Z

    .line 316
    .end local v0    # "level":I
    .end local v1    # "viewMode":I
    :cond_1
    iget v2, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->m_nResultCnt:I

    if-nez v2, :cond_2

    .line 318
    invoke-static {v4}, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->setSIPMiniLayout(I)V

    .line 321
    :cond_2
    iput-boolean v4, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->bFirst:Z

    .line 323
    invoke-static {v4}, Lcom/thinkware/sundo/inavi3d/oilprice/OilPriceOnRoute;->SetVisibleOilPrice(Z)V

    .line 324
    return-void
.end method

.method protected onStop()V
    .locals 0

    .prologue
    .line 361
    invoke-super {p0}, Lcom/thinkware/sundo/inavi3d/MainActivity;->onStop()V

    .line 362
    return-void
.end method

.method public setRegionName()V
    .locals 4

    .prologue
    .line 544
    sget-object v1, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mSearchOption:Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;

    iget v1, v1, Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;->m_nOption:I

    if-nez v1, :cond_2

    .line 546
    sget-object v1, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mSearchOption:Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;

    iget v1, v1, Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;->m_nAdminCode:I

    if-nez v1, :cond_1

    .line 547
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mBtnSetRegion:Landroid/widget/Button;

    const-string v2, "\uc804\uad6d"

    invoke-virtual {v1, v2}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 576
    :cond_0
    :goto_0
    return-void

    .line 548
    :cond_1
    sget-object v1, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mSearchOption:Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;

    iget-object v1, v1, Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;->m_strOption:Ljava/lang/String;

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v1

    if-lez v1, :cond_0

    .line 549
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mBtnSetRegion:Landroid/widget/Button;

    sget-object v2, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mSearchOption:Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;->m_strOption:Ljava/lang/String;

    invoke-virtual {v1, v2}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    goto :goto_0

    .line 553
    :cond_2
    const/4 v0, 0x0

    .line 554
    .local v0, "nRadiusKM":I
    sget-object v1, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mSearchOption:Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;

    iget v1, v1, Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;->m_nRadiusBoundary:I

    packed-switch v1, :pswitch_data_0

    .line 573
    :goto_1
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;->mBtnSetRegion:Landroid/widget/Button;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " km"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    goto :goto_0

    .line 556
    :pswitch_0
    const/4 v0, 0x1

    .line 557
    goto :goto_1

    .line 559
    :pswitch_1
    const/4 v0, 0x2

    .line 560
    goto :goto_1

    .line 562
    :pswitch_2
    const/4 v0, 0x5

    .line 563
    goto :goto_1

    .line 565
    :pswitch_3
    const/16 v0, 0x8

    .line 566
    goto :goto_1

    .line 568
    :pswitch_4
    const/16 v0, 0xa

    .line 569
    goto :goto_1

    .line 554
    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
        :pswitch_1
        :pswitch_2
        :pswitch_3
        :pswitch_4
    .end packed-switch
.end method

.method public showMaxLengthPopup()V
    .locals 4

    .prologue
    .line 1238
    const/16 v0, 0x30

    const-string v1, "\uc54c\ub9bc"

    const-string v2, "\ub354 \uc774\uc0c1 \uc785\ub825\ud560 \uc218 \uc5c6\uc2b5\ub2c8\ub2e4."

    const/4 v3, 0x0

    invoke-static {v0, p0, v1, v2, v3}, Lcom/thinkware/sundo/inavi3d/ui/popup/PopupManager;->ShowPopup(ILandroid/content/Context;Ljava/lang/String;Ljava/lang/String;I)Lcom/thinkware/sundo/inavi3d/ui/popup/InaviPopup;

    .line 1239
    return-void
.end method
