.class Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity$16;
.super Ljava/lang/Object;
.source "RoutePointManageActivity.java"

# interfaces
.implements Lcom/thinkware/sundo/inavi3d/INaviTask$iINaviTaskInterFace;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;


# direct methods
.method constructor <init>(Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;)V
    .locals 0

    .prologue
    .line 956
    iput-object p1, p0, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity$16;->this$0:Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public varargs doInBackground([Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2
    .param p1, "params"    # [Ljava/lang/Object;

    .prologue
    .line 1016
    const/4 v0, 0x0

    .line 1017
    .local v0, "reload":Z
    if-eqz p1, :cond_0

    .line 1018
    const/4 v1, 0x0

    aget-object v1, p1, v1

    check-cast v1, Ljava/lang/Boolean;

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    .line 1021
    :cond_0
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity$16;->this$0:Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;

    invoke-virtual {v1}, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;->initTabChild()V

    .line 1023
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v1

    return-object v1
.end method

.method public onCanceled()V
    .locals 0

    .prologue
    .line 1011
    return-void
.end method

.method public onPostExecute(Ljava/lang/Object;)V
    .locals 6
    .param p1, "result"    # Ljava/lang/Object;

    .prologue
    const/4 v4, 0x1

    const/4 v3, 0x0

    .line 973
    const/4 v0, 0x0

    .line 974
    .local v0, "reload":Z
    if-eqz p1, :cond_0

    .line 975
    check-cast p1, Ljava/lang/Boolean;

    .end local p1    # "result":Ljava/lang/Object;
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    .line 977
    :cond_0
    if-ne v0, v4, :cond_1

    .line 979
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity$16;->this$0:Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;

    iget-object v1, v1, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;->mManager:Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/RoutePointDataManager;

    const v1, 0x2234f

    invoke-static {v1, v3, v3}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/RoutePointDataManager;->routePointManage2(III)V

    .line 988
    :goto_0
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/ui/MainMenuActivity;->isExistRoute()Z

    move-result v1

    if-eqz v1, :cond_2

    .line 989
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity$16;->this$0:Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;

    invoke-static {v1, v4}, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;->access$1100(Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;Z)V

    .line 993
    :goto_1
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity$16;->this$0:Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;

    invoke-static {v1}, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;->access$1400(Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;)Landroid/widget/Button;

    move-result-object v1

    new-instance v2, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity$16$1;

    invoke-direct {v2, p0}, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity$16$1;-><init>(Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity$16;)V

    const-wide/16 v4, 0x64

    invoke-virtual {v1, v2, v4, v5}, Landroid/widget/Button;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 1005
    return-void

    .line 982
    :cond_1
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    move-result-object v1

    invoke-virtual {v1, v3}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->setRoutePointManageViewModeValue(I)V

    .line 983
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v1

    const v2, 0x7f0b04ee

    invoke-virtual {v1, v2}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getView(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Lcom/thinkware/sundo/inavi3d/ui/component/GpsButton;

    invoke-virtual {v1, v3}, Lcom/thinkware/sundo/inavi3d/ui/component/GpsButton;->setFlightMode(I)V

    .line 984
    invoke-static {v3, v3}, Lcom/thinkware/sundo/inavi3d/Inavi;->ToggleViewModeSafe(IZ)Z

    .line 986
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity$16;->this$0:Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;

    iget-object v1, v1, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;->mManager:Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/RoutePointDataManager;

    const v1, 0x2234e

    invoke-static {v1, v3, v3}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/RoutePointDataManager;->routePointManage2(III)V

    goto :goto_0

    .line 991
    :cond_2
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity$16;->this$0:Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;

    invoke-static {v1, v3}, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;->access$1100(Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;Z)V

    goto :goto_1
.end method

.method public onPreExecute()V
    .locals 2

    .prologue
    .line 961
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity$16;->this$0:Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/RoutePointDataManager;->getInstance()Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/RoutePointDataManager;

    move-result-object v1

    iput-object v1, v0, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;->mManager:Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/RoutePointDataManager;

    .line 962
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity$16;->this$0:Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;->mManager:Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/RoutePointDataManager;

    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity$16;->this$0:Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;

    iget-object v1, v1, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;->mManagerCallback:Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/RoutePointDataManager$icallback;

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/RoutePointDataManager;->setCallback(Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/RoutePointDataManager$icallback;)V

    .line 964
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity$16;->this$0:Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, v0, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;->m_vBuf:Ljava/util/ArrayList;

    .line 965
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity$16;->this$0:Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;

    invoke-static {v0}, Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;->access$1000(Lcom/thinkware/sundo/inavi3d/ui/RoutePointManageActivity;)V

    .line 966
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v0

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->bringtoFrontDPView()V

    .line 968
    return-void
.end method
