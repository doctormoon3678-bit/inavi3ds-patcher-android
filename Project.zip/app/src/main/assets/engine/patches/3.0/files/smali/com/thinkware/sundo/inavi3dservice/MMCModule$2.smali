.class Lcom/thinkware/sundo/inavi3dservice/MMCModule$2;
.super Ljava/lang/Object;
.source "MMCModule.java"

# interfaces
.implements Landroid/location/OnNmeaMessageListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/thinkware/sundo/inavi3dservice/MMCModule;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/thinkware/sundo/inavi3dservice/MMCModule;


# direct methods
.method constructor <init>(Lcom/thinkware/sundo/inavi3dservice/MMCModule;)V
    .locals 0

    .prologue
    .line 1364
    iput-object p1, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule$2;->this$0:Lcom/thinkware/sundo/inavi3dservice/MMCModule;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onNmeaMessage(Ljava/lang/String;J)V
    .locals 5
    .param p1, "message"    # Ljava/lang/String;
    .param p2, "timestamp"    # J

    .prologue
    .line 1366
    const-string v2, "DebugLOG"

    const-string v3, "access$000"

    invoke-static {v2, v3}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule$2;->this$0:Lcom/thinkware/sundo/inavi3dservice/MMCModule;

    invoke-static {v3}, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->access$000(Lcom/thinkware/sundo/inavi3dservice/MMCModule;)Z

    move-result v3

    if-nez v3, :cond_1

    .line 1377
    :cond_0
    :goto_0
    return-void

    .line 1368
    :cond_1
    const-string v2, "DebugLOG"

    const-string v3, "access$200"

    invoke-static {v2, v3}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule$2;->this$0:Lcom/thinkware/sundo/inavi3dservice/MMCModule;

    invoke-static {v3}, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->access$200(Lcom/thinkware/sundo/inavi3dservice/MMCModule;)[Z

    move-result-object v3

    const/4 v4, 0x2

    aget-boolean v3, v3, v4

    if-nez v3, :cond_0

    .line 1370
    const/16 v3, 0x800

    new-array v0, v3, [B

    .line 1371
    .local v0, "buffer":[B
    invoke-virtual {p1}, Ljava/lang/String;->toCharArray()[C

    move-result-object v1

    .line 1373
    .local v1, "cArray":[C
    const/4 v2, 0x0

    .local v2, "i":I
    :goto_1
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v3

    if-ge v2, v3, :cond_2

    .line 1374
    aget-char v3, v1, v2

    int-to-byte v3, v3

    aput-byte v3, v0, v2

    .line 1373
    add-int/lit8 v2, v2, 0x1

    goto :goto_1

    .line 1376
    :cond_2
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3dservice/MMCModule$2;->this$0:Lcom/thinkware/sundo/inavi3dservice/MMCModule;

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v4

    invoke-static {v3, p2, p3, v0, v4}, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->access$300(Lcom/thinkware/sundo/inavi3dservice/MMCModule;J[BI)V

    const-string v2, "DebugLOG"

    const-string v3, "access$300"

    invoke-static {v2, v3}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0
.end method
