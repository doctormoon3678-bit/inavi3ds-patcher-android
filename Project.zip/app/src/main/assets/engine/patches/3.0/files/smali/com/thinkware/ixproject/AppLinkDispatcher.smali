.class public Lcom/thinkware/ixproject/AppLinkDispatcher;
.super Landroid/app/IntentService;
.source "AppLinkDispatcher.java"


# direct methods
.method public constructor <init>()V
    .locals 2

    .prologue
    .line 18
    const-class v0, Lcom/thinkware/ixproject/AppLinkDispatcher;

    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Landroid/app/IntentService;-><init>(Ljava/lang/String;)V

    .line 19
    const-string v0, "linklink"

    const-string v1, "AppLinkDispatcher"

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 20
    invoke-static {p0}, Lcom/thinkware/sundo/inavi3d/util/TWLogger;->df(Landroid/content/Context;)V

    .line 21
    return-void
.end method

.method private DeleteRouteFile(Landroid/content/Intent;)V
    .locals 7
    .param p1, "intent"    # Landroid/content/Intent;

    .prologue
    .line 57
    :try_start_0
    const-string v0, "/storage/emulated/0/inavi3d/inavidata/"

    .line 59
    .local v0, "SD_EXT_STORAGE_PATH":Ljava/lang/String;
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string v5, "routeoption"

    invoke-virtual {p1, v5}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    .line 60
    .local v3, "filePath":Ljava/lang/String;
    const-string v4, "IvisionTAG"

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "filePath : "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-static {v4, v5}, Lcom/thinkware/sundo/inavi3d/LOGTW;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 61
    new-instance v2, Ljava/io/File;

    invoke-direct {v2, v3}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 62
    .local v2, "file":Ljava/io/File;
    invoke-virtual {v2}, Ljava/io/File;->isFile()Z

    move-result v4

    const/4 v5, 0x1

    if-ne v4, v5, :cond_0

    .line 63
    invoke-virtual {v2}, Ljava/io/File;->delete()Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 68
    .end local v0    # "SD_EXT_STORAGE_PATH":Ljava/lang/String;
    .end local v2    # "file":Ljava/io/File;
    .end local v3    # "filePath":Ljava/lang/String;
    :cond_0
    :goto_0
    return-void

    .line 65
    :catch_0
    move-exception v1

    .line 66
    .local v1, "e":Ljava/lang/Exception;
    invoke-virtual {v1}, Ljava/lang/Exception;->printStackTrace()V

    goto :goto_0
.end method

.method private KillSelf()V
    .locals 2

    .prologue
    .line 51
    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result v0

    const/16 v1, 0x9

    invoke-static {v0, v1}, Landroid/os/Process;->sendSignal(II)V

    .line 52
    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result v0

    invoke-static {v0}, Landroid/os/Process;->killProcess(I)V

    .line 53
    return-void
.end method


# virtual methods
.method protected onHandleIntent(Landroid/content/Intent;)V
    .locals 4
    .param p1, "intent"    # Landroid/content/Intent;

    .prologue
    const/4 v3, 0x1

    .line 26
    const-string v1, "linklink"

    const-string v2, "onHandleIntent"

    invoke-static {v1, v2}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 27
    invoke-static {p0}, Lcom/thinkware/sundo/inavi3d/util/TWLogger;->df(Landroid/content/Context;)V

    .line 28
    invoke-virtual {p1}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v0

    .line 29
    .local v0, "strAction":Ljava/lang/String;
    if-eqz p1, :cond_0

    .line 30
    if-eqz v0, :cond_0

    .line 31
    const-string v1, "com.thinkware.sundo.inavi3d.action.EXIT"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-ne v1, v3, :cond_3

    .line 32
    sget-object v1, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->inavi_reference:Lcom/thinkware/sundo/inavi3d/Inavi;

    if-eqz v1, :cond_2

    .line 33
    sget-object v1, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->inavi_reference:Lcom/thinkware/sundo/inavi3d/Inavi;

    invoke-virtual {v1}, Lcom/thinkware/sundo/inavi3d/Inavi;->isInitDone()Z

    move-result v1

    if-ne v1, v3, :cond_1

    .line 34
    const-string v1, "linklink"

    const-string v2, "processIX - 1"

    invoke-static {v1, v2}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 35
    sget-object v1, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->inavi_reference:Lcom/thinkware/sundo/inavi3d/Inavi;

    invoke-virtual {v1, p1}, Lcom/thinkware/sundo/inavi3d/Inavi;->processIX(Landroid/content/Intent;)V

    .line 49
    :cond_0
    :goto_0
    return-void

    .line 37
    :cond_1
    const-string v1, "linklink"

    const-string v2, "KillSelf - 1"

    invoke-static {v1, v2}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 38
    invoke-direct {p0}, Lcom/thinkware/ixproject/AppLinkDispatcher;->KillSelf()V

    goto :goto_0

    .line 41
    :cond_2
    const-string v1, "linklink"

    const-string v2, "KillSelf - 2"

    invoke-static {v1, v2}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 42
    invoke-direct {p0}, Lcom/thinkware/ixproject/AppLinkDispatcher;->KillSelf()V

    goto :goto_0

    .line 44
    :cond_3
    const-string v1, "com.thinkware.ivision.action.ROUTEDEL"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-ne v1, v3, :cond_0

    .line 45
    invoke-direct {p0, p1}, Lcom/thinkware/ixproject/AppLinkDispatcher;->DeleteRouteFile(Landroid/content/Intent;)V

    goto :goto_0
.end method
