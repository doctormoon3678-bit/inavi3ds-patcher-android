.class public interface abstract Lcom/thinkware/os/winker/IWinkerStateListener;
.super Ljava/lang/Object;
.source "IWinkerStateListener.java"


# virtual methods
.method public abstract onStateValue(II)V
.end method
