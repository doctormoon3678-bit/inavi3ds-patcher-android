.class public Lcom/thinkware/sundo/inavi3d/DeviceInfo;
.super Ljava/lang/Object;
.source "DeviceInfo.java"


# static fields
.field public static final A3D_MODEL_OTHERS:I = 0x15

.field public static final A3D_MODEL_TW_CUBE2:I = 0x4

.field public static final A3D_MODEL_TW_CUBE_FL:I = 0x8

.field public static final A3D_MODEL_TW_CUBE_LITE:I = 0x7

.field public static final A3D_MODEL_TW_DIXIE:I = 0x1

.field public static final A3D_MODEL_TW_DIXON:I = 0x0

.field public static final A3D_MODEL_TW_GIANT:I = 0xf

.field public static final A3D_MODEL_TW_IX:I = 0xe

.field public static final A3D_MODEL_TW_LEO:I = 0x3

.field public static final A3D_MODEL_TW_LUCY_A:I = 0xa

.field public static final A3D_MODEL_TW_LUCY_B:I = 0xc

.field public static final A3D_MODEL_TW_LUCY_M:I = 0xb

.field public static final A3D_MODEL_TW_MAN:I = 0x13

.field public static final A3D_MODEL_TW_MAPLE_M:I = 0x14

.field public static final A3D_MODEL_TW_MOWGLI:I = 0x9

.field public static final A3D_MODEL_TW_MX:I = 0x6

.field public static final A3D_MODEL_TW_MX_T:I = 0xd

.field public static final A3D_MODEL_TW_NEO_A:I = 0x10

.field public static final A3D_MODEL_TW_NEO_M:I = 0x11

.field public static final A3D_MODEL_TW_RUNA:I = 0x5

.field public static final A3D_MODEL_TW_RUNA_A:I = 0x12

.field public static final A3D_MODEL_TW_TAURUS:I = 0x2

.field public static final COUNT_OF_DEVICE:I = 0x15

.field private static final instance:Lcom/thinkware/sundo/inavi3d/DeviceInfo;

.field static phone_type:I


# instance fields
.field private final DRGPSMODE:Ljava/lang/String;

.field private final INNERGPSMODE:Ljava/lang/String;

.field final SOUND_TEMP_PATH:Ljava/lang/String;

.field private isElectrostatic:Z

.field private isIVison:Z

.field public is_inner_storage:Z

.field public kEndingNaviWave:Ljava/lang/String;

.field public kInaviData:Ljava/lang/String;

.field public kInaviResPath:Ljava/lang/String;

.field public kLastBluetoothFile:Ljava/lang/String;

.field public kLogDriveFile:Ljava/lang/String;

.field public kMapdataPath:Ljava/lang/String;

.field public kStartNaviWave:Ljava/lang/String;

.field public kStorageRoot:Ljava/lang/String;

.field public kTpeg_data_path:Ljava/lang/String;

.field private m_Support_Deivce:Z

.field private m_deviceOEM:Ljava/lang/String;

.field private m_deviceUUID:Ljava/lang/String;

.field private m_device_model:I

.field private m_installred_Trip:Z

.field private m_supportAINA:Z

.field private m_supportDualRoute:Z

.field private m_supportEXPSearch:Z

.field private m_supportMyRoute:Z

.field private m_supportRSearch:Z

.field private m_supportRecommendedWord:Z

.field private m_support_DMB:Z

.field private m_support_ExternaGPS:Z

.field private m_support_ExternaGPS_PowerOn:Z

.field private m_support_Manager:Z

.field private m_support_Remote:Z

.field private m_support_TBT:Z

.field private m_support_TPEG:Z

.field private m_support_air_mode:Z

.field private m_support_scale:Z

.field private m_support_scaletype:I

.field private m_support_supercap_poweroff:Z

.field private m_support_widedisplay:I

.field private m_use_drgps:Z


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .prologue
    .line 29
    const/4 v0, 0x0

    sput v0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->phone_type:I

    .line 231
    new-instance v0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    invoke-direct {v0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;-><init>()V

    sput-object v0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->instance:Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    return-void
.end method

.method private constructor <init>()V
    .locals 4

    .prologue
    const/4 v3, 0x1

    const/4 v2, -0x1

    const/4 v0, 0x0

    const/4 v1, 0x0

    .line 20
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 32
    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->kStorageRoot:Ljava/lang/String;

    .line 33
    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->kMapdataPath:Ljava/lang/String;

    .line 34
    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->kInaviData:Ljava/lang/String;

    .line 35
    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->kInaviResPath:Ljava/lang/String;

    .line 36
    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->kTpeg_data_path:Ljava/lang/String;

    .line 37
    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->kStartNaviWave:Ljava/lang/String;

    .line 38
    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->kEndingNaviWave:Ljava/lang/String;

    .line 39
    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->kLastBluetoothFile:Ljava/lang/String;

    .line 40
    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->kLogDriveFile:Ljava/lang/String;

    .line 41
    const-string v0, "/TWRamdisk"

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->SOUND_TEMP_PATH:Ljava/lang/String;

    .line 43
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->is_inner_storage:Z

    .line 51
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->isIVison:Z

    .line 203
    const/16 v0, 0x15

    iput v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    .line 204
    const-string v0, ""

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_deviceOEM:Ljava/lang/String;

    .line 205
    const-string v0, ""

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_deviceUUID:Ljava/lang/String;

    .line 207
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_scale:Z

    .line 208
    iput v2, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_scaletype:I

    .line 209
    iput v2, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_widedisplay:I

    .line 211
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_Support_Deivce:Z

    .line 213
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_DMB:Z

    .line 214
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_TBT:Z

    .line 215
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_TPEG:Z

    .line 216
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_Remote:Z

    .line 218
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_ExternaGPS:Z

    .line 219
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_ExternaGPS_PowerOn:Z

    .line 220
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_Manager:Z

    .line 221
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_installred_Trip:Z

    .line 223
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportRSearch:Z

    .line 224
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportEXPSearch:Z

    .line 225
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportRecommendedWord:Z

    .line 227
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportDualRoute:Z

    .line 229
    iput-boolean v3, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportMyRoute:Z

    .line 233
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_use_drgps:Z

    .line 234
    const-string v0, "0"

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->INNERGPSMODE:Ljava/lang/String;

    .line 235
    const-string v0, "1"

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->DRGPSMODE:Ljava/lang/String;

    .line 237
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportAINA:Z

    .line 239
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_air_mode:Z

    .line 244
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_supercap_poweroff:Z

    .line 252
    iput-boolean v3, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->isElectrostatic:Z

    .line 21
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->Initialize()V

    .line 22
    return-void
.end method

.method public static GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;
    .locals 1

    .prologue
    .line 130
    sget-object v0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->instance:Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    return-object v0
.end method

.method private _InitDeviceAttribute()I
    .locals 11

    .prologue
    const/16 v10, 0xa

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v7, 0x1

    .line 259
    const-string v3, ""

    .line 261
    .local v3, "line":Ljava/lang/String;
    :try_start_0
    invoke-static {}, Ljava/lang/Runtime;->getRuntime()Ljava/lang/Runtime;

    move-result-object v4

    const-string v5, "getprop ro.product.devicecode"

    invoke-virtual {v4, v5}, Ljava/lang/Runtime;->exec(Ljava/lang/String;)Ljava/lang/Process;

    move-result-object v2

    .line 262
    .local v2, "ifc":Ljava/lang/Process;
    new-instance v0, Ljava/io/BufferedReader;

    new-instance v4, Ljava/io/InputStreamReader;

    invoke-virtual {v2}, Ljava/lang/Process;->getInputStream()Ljava/io/InputStream;

    move-result-object v5

    invoke-direct {v4, v5}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;)V

    invoke-direct {v0, v4}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V

    .line 263
    .local v0, "bis":Ljava/io/BufferedReader;
    invoke-virtual {v0}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    move-result-object v3

    .line 264
    iput-object v3, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_deviceOEM:Ljava/lang/String;

    .line 265
    invoke-virtual {v2}, Ljava/lang/Process;->destroy()V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_3

    .line 271
    .end local v0    # "bis":Ljava/io/BufferedReader;
    .end local v2    # "ifc":Ljava/lang/Process;
    :goto_0
    :try_start_1
    const-class v4, Landroid/os/Build;

    const-string v5, "SERIAL"

    invoke-virtual {v4, v5}, Ljava/lang/Class;->getField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v4

    const/4 v5, 0x0

    invoke-virtual {v4, v5}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    iput-object v4, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_deviceUUID:Ljava/lang/String;
    :try_end_1
    .catch Ljava/lang/IllegalAccessException; {:try_start_1 .. :try_end_1} :catch_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_1 .. :try_end_1} :catch_1
    .catch Ljava/lang/NoSuchFieldException; {:try_start_1 .. :try_end_1} :catch_2

    .line 283
    :goto_1
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportMyRoute:Z

    .line 289
    iget-boolean v4, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->isIVison:Z

    if-ne v4, v7, :cond_0

    .line 290
    const-string v4, "IXB"

    iput-object v4, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_deviceOEM:Ljava/lang/String;

    .line 294
    :cond_0
    const-string v4, "oemname"

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, ""

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    iget-object v6, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_deviceOEM:Ljava/lang/String;

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-static {v4, v5}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 295
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_deviceOEM:Ljava/lang/String;

    const-string v5, "D7A"

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_1

    .line 297
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_Support_Deivce:Z

    .line 298
    iput v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    .line 299
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_DMB:Z

    .line 300
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_TBT:Z

    .line 301
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_TPEG:Z

    .line 302
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_Remote:Z

    .line 303
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_ExternaGPS:Z

    .line 304
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_ExternaGPS_PowerOn:Z

    .line 305
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_Manager:Z

    .line 306
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportRSearch:Z

    .line 307
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportEXPSearch:Z

    .line 308
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportRecommendedWord:Z

    .line 309
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportAINA:Z

    .line 310
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_scale:Z

    .line 311
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_air_mode:Z

    .line 314
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_supercap_poweroff:Z

    .line 919
    :goto_2
    iget v4, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    return v4

    .line 272
    :catch_0
    move-exception v1

    .line 274
    .local v1, "e":Ljava/lang/IllegalAccessException;
    invoke-virtual {v1}, Ljava/lang/IllegalAccessException;->printStackTrace()V

    goto :goto_1

    .line 275
    .end local v1    # "e":Ljava/lang/IllegalAccessException;
    :catch_1
    move-exception v1

    .line 277
    .local v1, "e":Ljava/lang/IllegalArgumentException;
    invoke-virtual {v1}, Ljava/lang/IllegalArgumentException;->printStackTrace()V

    goto :goto_1

    .line 278
    .end local v1    # "e":Ljava/lang/IllegalArgumentException;
    :catch_2
    move-exception v1

    .line 280
    .local v1, "e":Ljava/lang/NoSuchFieldException;
    invoke-virtual {v1}, Ljava/lang/NoSuchFieldException;->printStackTrace()V

    goto :goto_1

    .line 317
    .end local v1    # "e":Ljava/lang/NoSuchFieldException;
    :cond_1
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_deviceOEM:Ljava/lang/String;

    const-string v5, "D9A"

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_2

    .line 319
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_Support_Deivce:Z

    .line 320
    iput v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    .line 321
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_DMB:Z

    .line 322
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_TBT:Z

    .line 323
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_TPEG:Z

    .line 324
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_Remote:Z

    .line 325
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_ExternaGPS:Z

    .line 326
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_ExternaGPS_PowerOn:Z

    .line 327
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_Manager:Z

    .line 328
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportRSearch:Z

    .line 329
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportEXPSearch:Z

    .line 330
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportRecommendedWord:Z

    .line 331
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportAINA:Z

    .line 332
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_scale:Z

    .line 333
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->SetUseDRConfig()Z

    .line 334
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_air_mode:Z

    .line 337
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_supercap_poweroff:Z

    goto :goto_2

    .line 341
    :cond_2
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_deviceOEM:Ljava/lang/String;

    const-string v5, "TAU"

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_3

    .line 343
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_Support_Deivce:Z

    .line 344
    iput v9, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    .line 345
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_DMB:Z

    .line 346
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_TBT:Z

    .line 347
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_TPEG:Z

    .line 348
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_Remote:Z

    .line 349
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_ExternaGPS:Z

    .line 350
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_ExternaGPS_PowerOn:Z

    .line 351
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_Manager:Z

    .line 352
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportRSearch:Z

    .line 353
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportEXPSearch:Z

    .line 354
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportRecommendedWord:Z

    .line 355
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportDualRoute:Z

    .line 356
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportAINA:Z

    .line 357
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_scale:Z

    .line 358
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->SetUseDRConfig()Z

    .line 359
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_air_mode:Z

    .line 362
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_supercap_poweroff:Z

    goto :goto_2

    .line 370
    :cond_3
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_deviceOEM:Ljava/lang/String;

    const-string v5, "LEO"

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_4

    .line 372
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_Support_Deivce:Z

    .line 373
    const/4 v4, 0x3

    iput v4, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    .line 374
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_DMB:Z

    .line 375
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_TBT:Z

    .line 376
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_TPEG:Z

    .line 377
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_Remote:Z

    .line 378
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_ExternaGPS:Z

    .line 379
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_ExternaGPS_PowerOn:Z

    .line 380
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_Manager:Z

    .line 381
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportRSearch:Z

    .line 382
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportEXPSearch:Z

    .line 383
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportRecommendedWord:Z

    .line 384
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportDualRoute:Z

    .line 385
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportAINA:Z

    .line 386
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_scale:Z

    .line 387
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->SetUseDRConfig()Z

    .line 388
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_air_mode:Z

    .line 391
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_supercap_poweroff:Z

    goto/16 :goto_2

    .line 398
    :cond_4
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_deviceOEM:Ljava/lang/String;

    const-string v5, "CU2"

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_5

    .line 400
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_Support_Deivce:Z

    .line 401
    const/4 v4, 0x4

    iput v4, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    .line 402
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_DMB:Z

    .line 403
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_TBT:Z

    .line 404
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_TPEG:Z

    .line 405
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_Remote:Z

    .line 406
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_ExternaGPS:Z

    .line 407
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_ExternaGPS_PowerOn:Z

    .line 408
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_Manager:Z

    .line 409
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportRSearch:Z

    .line 410
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportEXPSearch:Z

    .line 411
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportRecommendedWord:Z

    .line 412
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportDualRoute:Z

    .line 413
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportAINA:Z

    .line 414
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_scale:Z

    .line 415
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_air_mode:Z

    .line 418
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_supercap_poweroff:Z

    .line 420
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->isElectrostatic:Z

    goto/16 :goto_2

    .line 423
    :cond_5
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_deviceOEM:Ljava/lang/String;

    const-string v5, "RNA"

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_6

    .line 425
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_Support_Deivce:Z

    .line 426
    const/4 v4, 0x5

    iput v4, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    .line 427
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_DMB:Z

    .line 428
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_TBT:Z

    .line 429
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_TPEG:Z

    .line 430
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_Remote:Z

    .line 431
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_ExternaGPS:Z

    .line 432
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_ExternaGPS_PowerOn:Z

    .line 433
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_Manager:Z

    .line 434
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportRSearch:Z

    .line 435
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportEXPSearch:Z

    .line 436
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportRecommendedWord:Z

    .line 437
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportDualRoute:Z

    .line 438
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportAINA:Z

    .line 439
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_scale:Z

    .line 440
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_air_mode:Z

    .line 443
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_supercap_poweroff:Z

    .line 445
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->isElectrostatic:Z

    goto/16 :goto_2

    .line 447
    :cond_6
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_deviceOEM:Ljava/lang/String;

    const-string v5, "WLF"

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_7

    .line 449
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_Support_Deivce:Z

    .line 450
    const/16 v4, 0x12

    iput v4, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    .line 451
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_DMB:Z

    .line 452
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_TBT:Z

    .line 453
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_TPEG:Z

    .line 454
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_Remote:Z

    .line 455
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_ExternaGPS:Z

    .line 456
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_ExternaGPS_PowerOn:Z

    .line 457
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_Manager:Z

    .line 458
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportRSearch:Z

    .line 459
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportEXPSearch:Z

    .line 460
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportRecommendedWord:Z

    .line 461
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportDualRoute:Z

    .line 462
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportAINA:Z

    .line 463
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_scale:Z

    .line 464
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_air_mode:Z

    .line 467
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_supercap_poweroff:Z

    .line 469
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->isElectrostatic:Z

    goto/16 :goto_2

    .line 471
    :cond_7
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_deviceOEM:Ljava/lang/String;

    const-string v5, "MXB"

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_8

    .line 473
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_Support_Deivce:Z

    .line 474
    const/4 v4, 0x6

    iput v4, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    .line 475
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_DMB:Z

    .line 476
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_TBT:Z

    .line 477
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_TPEG:Z

    .line 478
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_Remote:Z

    .line 479
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_ExternaGPS:Z

    .line 480
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_ExternaGPS_PowerOn:Z

    .line 481
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_Manager:Z

    .line 482
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportRSearch:Z

    .line 483
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportEXPSearch:Z

    .line 484
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportRecommendedWord:Z

    .line 485
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportDualRoute:Z

    .line 486
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportAINA:Z

    .line 487
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_scale:Z

    .line 488
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_air_mode:Z

    .line 491
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_supercap_poweroff:Z

    .line 497
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->isElectrostatic:Z

    .line 499
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportMyRoute:Z

    goto/16 :goto_2

    .line 501
    :cond_8
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_deviceOEM:Ljava/lang/String;

    const-string v5, "CUL"

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_9

    .line 503
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_Support_Deivce:Z

    .line 504
    const/4 v4, 0x7

    iput v4, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    .line 505
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_DMB:Z

    .line 506
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_TBT:Z

    .line 507
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_TPEG:Z

    .line 508
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_Remote:Z

    .line 509
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_ExternaGPS:Z

    .line 510
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_ExternaGPS_PowerOn:Z

    .line 511
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_Manager:Z

    .line 512
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportRSearch:Z

    .line 513
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportEXPSearch:Z

    .line 514
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportRecommendedWord:Z

    .line 515
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportDualRoute:Z

    .line 516
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportAINA:Z

    .line 517
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_scale:Z

    .line 518
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_air_mode:Z

    .line 521
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_supercap_poweroff:Z

    .line 523
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->isElectrostatic:Z

    goto/16 :goto_2

    .line 525
    :cond_9
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_deviceOEM:Ljava/lang/String;

    const-string v5, "CUF"

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_a

    .line 527
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_Support_Deivce:Z

    .line 528
    const/16 v4, 0x8

    iput v4, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    .line 529
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_DMB:Z

    .line 530
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_TBT:Z

    .line 531
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_TPEG:Z

    .line 532
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_Remote:Z

    .line 533
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_ExternaGPS:Z

    .line 534
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_ExternaGPS_PowerOn:Z

    .line 535
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_Manager:Z

    .line 536
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportRSearch:Z

    .line 537
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportEXPSearch:Z

    .line 538
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportRecommendedWord:Z

    .line 539
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportDualRoute:Z

    .line 540
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportAINA:Z

    .line 541
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_scale:Z

    .line 542
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_air_mode:Z

    .line 545
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_supercap_poweroff:Z

    .line 547
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->isElectrostatic:Z

    goto/16 :goto_2

    .line 549
    :cond_a
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_deviceOEM:Ljava/lang/String;

    const-string v5, "MOW"

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_b

    .line 551
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_Support_Deivce:Z

    .line 552
    const/16 v4, 0x9

    iput v4, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    .line 553
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_DMB:Z

    .line 554
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_TBT:Z

    .line 555
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_TPEG:Z

    .line 556
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_Remote:Z

    .line 557
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_ExternaGPS:Z

    .line 558
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_ExternaGPS_PowerOn:Z

    .line 559
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_Manager:Z

    .line 560
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportRSearch:Z

    .line 561
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportEXPSearch:Z

    .line 562
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportRecommendedWord:Z

    .line 563
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportDualRoute:Z

    .line 564
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportAINA:Z

    .line 565
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_scale:Z

    .line 566
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_air_mode:Z

    .line 569
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_supercap_poweroff:Z

    .line 571
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->isElectrostatic:Z

    goto/16 :goto_2

    .line 574
    :cond_b
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_deviceOEM:Ljava/lang/String;

    const-string v5, "GNT"

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_c

    .line 576
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_Support_Deivce:Z

    .line 577
    const/16 v4, 0xf

    iput v4, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    .line 578
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_DMB:Z

    .line 579
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_TBT:Z

    .line 580
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_TPEG:Z

    .line 581
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_Remote:Z

    .line 582
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_ExternaGPS:Z

    .line 583
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_ExternaGPS_PowerOn:Z

    .line 584
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_Manager:Z

    .line 585
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportRSearch:Z

    .line 586
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportEXPSearch:Z

    .line 587
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportRecommendedWord:Z

    .line 588
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportDualRoute:Z

    .line 589
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportAINA:Z

    .line 590
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_scale:Z

    .line 591
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_air_mode:Z

    .line 594
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_supercap_poweroff:Z

    .line 596
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->isElectrostatic:Z

    goto/16 :goto_2

    .line 599
    :cond_c
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_deviceOEM:Ljava/lang/String;

    const-string v5, "X1P"

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_d

    .line 601
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_Support_Deivce:Z

    .line 602
    iput v9, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    .line 603
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_DMB:Z

    .line 604
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_TBT:Z

    .line 605
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_TPEG:Z

    .line 606
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_Remote:Z

    .line 607
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_ExternaGPS:Z

    .line 608
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_ExternaGPS_PowerOn:Z

    .line 609
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_Manager:Z

    .line 610
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportRSearch:Z

    .line 611
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportEXPSearch:Z

    .line 612
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportRecommendedWord:Z

    .line 613
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportDualRoute:Z

    .line 614
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportAINA:Z

    .line 615
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_scale:Z

    .line 616
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->SetUseDRConfig()Z

    .line 617
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_air_mode:Z

    .line 620
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_supercap_poweroff:Z

    goto/16 :goto_2

    .line 628
    :cond_d
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_deviceOEM:Ljava/lang/String;

    const-string v5, "LCA"

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_e

    .line 630
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_Support_Deivce:Z

    .line 631
    iput v10, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    .line 632
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_DMB:Z

    .line 633
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_TBT:Z

    .line 634
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_TPEG:Z

    .line 635
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_Remote:Z

    .line 636
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_ExternaGPS:Z

    .line 637
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_ExternaGPS_PowerOn:Z

    .line 638
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_Manager:Z

    .line 639
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportRSearch:Z

    .line 640
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportEXPSearch:Z

    .line 641
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportRecommendedWord:Z

    .line 642
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportDualRoute:Z

    .line 643
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportAINA:Z

    .line 644
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_scale:Z

    .line 645
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_air_mode:Z

    .line 648
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_supercap_poweroff:Z

    .line 650
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->isElectrostatic:Z

    goto/16 :goto_2

    .line 653
    :cond_e
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_deviceOEM:Ljava/lang/String;

    const-string v5, "NEA"

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_f

    .line 655
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_Support_Deivce:Z

    .line 656
    const/16 v4, 0x10

    iput v4, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    .line 657
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_DMB:Z

    .line 658
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_TBT:Z

    .line 659
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_TPEG:Z

    .line 660
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_Remote:Z

    .line 661
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_ExternaGPS:Z

    .line 662
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_ExternaGPS_PowerOn:Z

    .line 663
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_Manager:Z

    .line 664
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportRSearch:Z

    .line 665
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportEXPSearch:Z

    .line 666
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportRecommendedWord:Z

    .line 667
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportDualRoute:Z

    .line 668
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportAINA:Z

    .line 669
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_scale:Z

    .line 670
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_air_mode:Z

    .line 673
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_supercap_poweroff:Z

    .line 675
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->isElectrostatic:Z

    goto/16 :goto_2

    .line 678
    :cond_f
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_deviceOEM:Ljava/lang/String;

    const-string v5, "LBK"

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_10

    .line 680
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_Support_Deivce:Z

    .line 681
    iput v10, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    .line 682
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_DMB:Z

    .line 683
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_TBT:Z

    .line 684
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_TPEG:Z

    .line 685
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_Remote:Z

    .line 686
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_ExternaGPS:Z

    .line 687
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_ExternaGPS_PowerOn:Z

    .line 688
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_Manager:Z

    .line 689
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportRSearch:Z

    .line 690
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportEXPSearch:Z

    .line 691
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportRecommendedWord:Z

    .line 692
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportDualRoute:Z

    .line 693
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportAINA:Z

    .line 694
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_scale:Z

    .line 695
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_air_mode:Z

    .line 698
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_supercap_poweroff:Z

    .line 700
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->isElectrostatic:Z

    goto/16 :goto_2

    .line 703
    :cond_10
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_deviceOEM:Ljava/lang/String;

    const-string v5, "LCM"

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_11

    .line 705
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_Support_Deivce:Z

    .line 706
    const/16 v4, 0xb

    iput v4, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    .line 707
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_DMB:Z

    .line 708
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_TBT:Z

    .line 709
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_TPEG:Z

    .line 710
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_Remote:Z

    .line 711
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_ExternaGPS:Z

    .line 712
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_ExternaGPS_PowerOn:Z

    .line 713
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_Manager:Z

    .line 714
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportRSearch:Z

    .line 715
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportEXPSearch:Z

    .line 716
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportRecommendedWord:Z

    .line 717
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportDualRoute:Z

    .line 718
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportAINA:Z

    .line 719
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_scale:Z

    .line 720
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_air_mode:Z

    .line 723
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_supercap_poweroff:Z

    .line 725
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->isElectrostatic:Z

    goto/16 :goto_2

    .line 728
    :cond_11
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_deviceOEM:Ljava/lang/String;

    const-string v5, "NEM"

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_12

    .line 730
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_Support_Deivce:Z

    .line 731
    const/16 v4, 0x11

    iput v4, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    .line 732
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_DMB:Z

    .line 733
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_TBT:Z

    .line 734
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_TPEG:Z

    .line 735
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_Remote:Z

    .line 736
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_ExternaGPS:Z

    .line 737
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_ExternaGPS_PowerOn:Z

    .line 738
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_Manager:Z

    .line 739
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportRSearch:Z

    .line 740
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportEXPSearch:Z

    .line 741
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportRecommendedWord:Z

    .line 742
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportDualRoute:Z

    .line 743
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportAINA:Z

    .line 744
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_scale:Z

    .line 745
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_air_mode:Z

    .line 748
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_supercap_poweroff:Z

    .line 750
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->isElectrostatic:Z

    goto/16 :goto_2

    .line 753
    :cond_12
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_deviceOEM:Ljava/lang/String;

    const-string v5, "LCB"

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_13

    .line 755
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_Support_Deivce:Z

    .line 756
    const/16 v4, 0xc

    iput v4, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    .line 757
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_DMB:Z

    .line 758
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_TBT:Z

    .line 759
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_TPEG:Z

    .line 760
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_Remote:Z

    .line 761
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_ExternaGPS:Z

    .line 762
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_ExternaGPS_PowerOn:Z

    .line 763
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_Manager:Z

    .line 764
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportRSearch:Z

    .line 765
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportEXPSearch:Z

    .line 766
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportRecommendedWord:Z

    .line 767
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportDualRoute:Z

    .line 768
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportAINA:Z

    .line 769
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_scale:Z

    .line 770
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_air_mode:Z

    .line 773
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_supercap_poweroff:Z

    .line 779
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->isElectrostatic:Z

    .line 781
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportMyRoute:Z

    goto/16 :goto_2

    .line 784
    :cond_13
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_deviceOEM:Ljava/lang/String;

    const-string v5, "MXT"

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_14

    .line 786
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_Support_Deivce:Z

    .line 787
    const/16 v4, 0xd

    iput v4, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    .line 788
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_DMB:Z

    .line 789
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_TBT:Z

    .line 790
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_TPEG:Z

    .line 791
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_Remote:Z

    .line 792
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_ExternaGPS:Z

    .line 793
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_ExternaGPS_PowerOn:Z

    .line 794
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_Manager:Z

    .line 795
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportRSearch:Z

    .line 796
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportEXPSearch:Z

    .line 797
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportRecommendedWord:Z

    .line 798
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportDualRoute:Z

    .line 799
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportAINA:Z

    .line 800
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_scale:Z

    .line 801
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_air_mode:Z

    .line 804
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_supercap_poweroff:Z

    .line 810
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->isElectrostatic:Z

    .line 812
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportMyRoute:Z

    goto/16 :goto_2

    .line 814
    :cond_14
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_deviceOEM:Ljava/lang/String;

    const-string v5, "IXB"

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_15

    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_deviceOEM:Ljava/lang/String;

    const-string v5, "IXP"

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_16

    .line 817
    :cond_15
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_Support_Deivce:Z

    .line 818
    const/16 v4, 0xe

    iput v4, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    .line 819
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_DMB:Z

    .line 820
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_TBT:Z

    .line 821
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_TPEG:Z

    .line 822
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_Remote:Z

    .line 823
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_ExternaGPS:Z

    .line 824
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_ExternaGPS_PowerOn:Z

    .line 825
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_Manager:Z

    .line 826
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportRSearch:Z

    .line 827
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportEXPSearch:Z

    .line 828
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportRecommendedWord:Z

    .line 829
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportDualRoute:Z

    .line 830
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportAINA:Z

    .line 831
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_scale:Z

    .line 832
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->SetUseDRConfig()Z

    .line 833
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_air_mode:Z

    .line 836
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_supercap_poweroff:Z

    goto/16 :goto_2

    .line 844
    :cond_16
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_deviceOEM:Ljava/lang/String;

    const-string v5, "MAN"

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_17

    .line 846
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_Support_Deivce:Z

    .line 847
    const/16 v4, 0x13

    iput v4, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    .line 848
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_DMB:Z

    .line 849
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_TBT:Z

    .line 850
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_TPEG:Z

    .line 851
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_Remote:Z

    .line 852
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_ExternaGPS:Z

    .line 853
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_ExternaGPS_PowerOn:Z

    .line 854
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_Manager:Z

    .line 855
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportRSearch:Z

    .line 856
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportEXPSearch:Z

    .line 857
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportRecommendedWord:Z

    .line 858
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportDualRoute:Z

    .line 859
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportAINA:Z

    .line 860
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_scale:Z

    .line 861
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_air_mode:Z

    .line 864
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_supercap_poweroff:Z

    .line 870
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->isElectrostatic:Z

    .line 872
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportMyRoute:Z

    goto/16 :goto_2

    .line 874
    :cond_17
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_deviceOEM:Ljava/lang/String;

    const-string v5, "MPL"

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_18

    .line 876
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_Support_Deivce:Z

    .line 877
    const/16 v4, 0x14

    iput v4, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    .line 878
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_DMB:Z

    .line 879
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_TBT:Z

    .line 880
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_TPEG:Z

    .line 881
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_Remote:Z

    .line 882
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_ExternaGPS:Z

    .line 883
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_ExternaGPS_PowerOn:Z

    .line 884
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_Manager:Z

    .line 885
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportRSearch:Z

    .line 886
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportEXPSearch:Z

    .line 887
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportRecommendedWord:Z

    .line 888
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportDualRoute:Z

    .line 889
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportAINA:Z

    .line 890
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_scale:Z

    .line 891
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_air_mode:Z

    .line 894
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_supercap_poweroff:Z

    .line 896
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->isElectrostatic:Z

    goto/16 :goto_2

    .line 901
    :cond_18
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_Support_Deivce:Z

    .line 902
    const/16 v4, 0x15

    iput v4, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    .line 903
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_DMB:Z

    .line 904
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_TBT:Z

    .line 905
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_TPEG:Z

    .line 906
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_Remote:Z

    .line 908
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_ExternaGPS:Z

    .line 909
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_ExternaGPS_PowerOn:Z

    .line 910
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_Manager:Z

    .line 911
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportAINA:Z

    .line 914
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->isElectrostatic:Z

    goto/16 :goto_2

    .line 266
    :catch_3
    move-exception v4

    goto/16 :goto_0
.end method

.method private _InitStoragePath()I
    .locals 15

    .prologue
    const/16 v9, 0xc9

    const/4 v14, 0x1

    const/4 v10, 0x0

    .line 60
    sget-object v1, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->SD_EXT_STORAGE_PATH:Ljava/lang/String;

    .line 61
    .local v1, "SD_EXT_STORAGE_PATH":Ljava/lang/String;
    const/4 v11, 0x3

    new-array v3, v11, [Ljava/lang/String;

    const-string v11, "inavi3d"

    aput-object v11, v3, v10

    const-string v11, "sd/inavi3d"

    aput-object v11, v3, v14

    const/4 v11, 0x2

    const-string v12, "external_sd/inavi3d"

    aput-object v12, v3, v11

    .line 62
    .local v3, "Storage_Candidate":[Ljava/lang/String;
    const-string v0, "mapdata/mrdata"

    .line 64
    .local v0, "CheckDirectory":Ljava/lang/String;
    const/4 v7, 0x0

    .local v7, "i":I
    :goto_0
    array-length v11, v3

    if-ge v7, v11, :cond_0

    .line 65
    new-instance v11, Ljava/io/File;

    new-instance v12, Ljava/lang/StringBuilder;

    invoke-direct {v12}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v12, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    const-string v13, "/"

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    aget-object v13, v3, v7

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    const-string v13, "/"

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    const-string v13, "mapdata/mrdata"

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    invoke-virtual {v12}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v12

    invoke-direct {v11, v12}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    invoke-virtual {v11}, Ljava/io/File;->isDirectory()Z

    move-result v11

    if-eqz v11, :cond_1

    .line 66
    new-instance v11, Ljava/lang/StringBuilder;

    invoke-direct {v11}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v11, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    const-string v12, "/"

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    aget-object v12, v3, v7

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v11

    iput-object v11, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->kStorageRoot:Ljava/lang/String;

    .line 77
    :cond_0
    :goto_1
    iget-object v11, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->kStorageRoot:Ljava/lang/String;

    if-nez v11, :cond_4

    .line 78
    const-string v11, "inavi3d_java"

    const-string v12, "kStorageRoot: (null)"

    invoke-static {v11, v12}, Lcom/thinkware/sundo/inavi3d/LOGTW;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 81
    :goto_2
    iget-object v11, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->kStorageRoot:Ljava/lang/String;

    if-nez v11, :cond_5

    .line 126
    :goto_3
    return v9

    .line 68
    :cond_1
    new-instance v11, Ljava/io/File;

    new-instance v12, Ljava/lang/StringBuilder;

    invoke-direct {v12}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v12, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    const-string v13, "2/"

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    aget-object v13, v3, v7

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    const-string v13, "/"

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    const-string v13, "mapdata/mrdata"

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    invoke-virtual {v12}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v12

    invoke-direct {v11, v12}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    invoke-virtual {v11}, Ljava/io/File;->isDirectory()Z

    move-result v11

    if-eqz v11, :cond_2

    .line 69
    new-instance v11, Ljava/lang/StringBuilder;

    invoke-direct {v11}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v11, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    const-string v12, "2/"

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    aget-object v12, v3, v7

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v11

    iput-object v11, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->kStorageRoot:Ljava/lang/String;

    goto :goto_1

    .line 71
    :cond_2
    new-instance v11, Ljava/io/File;

    const-string v12, "extSdCard/inavi3d/mapdata/mrdata"

    invoke-direct {v11, v12}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    invoke-virtual {v11}, Ljava/io/File;->isDirectory()Z

    move-result v11

    if-eqz v11, :cond_3

    .line 72
    const-string v11, "extSdCard/inavi3d"

    iput-object v11, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->kStorageRoot:Ljava/lang/String;

    goto :goto_1

    .line 64
    :cond_3
    add-int/lit8 v7, v7, 0x1

    goto/16 :goto_0

    .line 80
    :cond_4
    const-string v11, "inavi3d_java"

    new-instance v12, Ljava/lang/StringBuilder;

    invoke-direct {v12}, Ljava/lang/StringBuilder;-><init>()V

    const-string v13, "kStorageRoot: "

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    iget-object v13, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->kStorageRoot:Ljava/lang/String;

    invoke-virtual {v13}, Ljava/lang/String;->toString()Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    invoke-virtual {v12}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v12

    invoke-static {v11, v12}, Lcom/thinkware/sundo/inavi3d/LOGTW;->d(Ljava/lang/String;Ljava/lang/String;)V

    goto/16 :goto_2

    .line 85
    :cond_5
    iput-boolean v10, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->is_inner_storage:Z

    .line 86
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->IsThinkwareDevice()Z

    move-result v11

    if-nez v11, :cond_6

    .line 87
    iget-object v11, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->kStorageRoot:Ljava/lang/String;

    new-instance v12, Ljava/lang/StringBuilder;

    invoke-direct {v12}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v12, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    const-string v13, "/inavi3d"

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    invoke-virtual {v12}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v11, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v11

    if-eqz v11, :cond_6

    .line 88
    iput-boolean v14, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->is_inner_storage:Z

    .line 91
    :cond_6
    const-string v11, "inavi3d_java"

    new-instance v12, Ljava/lang/StringBuilder;

    invoke-direct {v12}, Ljava/lang/StringBuilder;-><init>()V

    const-string v13, "is_inner_storage: "

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    iget-boolean v13, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->is_inner_storage:Z

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v12

    invoke-virtual {v12}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v12

    invoke-static {v11, v12}, Lcom/thinkware/sundo/inavi3d/LOGTW;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 94
    new-instance v11, Ljava/lang/StringBuilder;

    invoke-direct {v11}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v12, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->kStorageRoot:Ljava/lang/String;

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    const-string v12, "/mapdata"

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v11

    iput-object v11, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->kMapdataPath:Ljava/lang/String;

    .line 95
    new-instance v11, Ljava/lang/StringBuilder;

    invoke-direct {v11}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v12, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->kStorageRoot:Ljava/lang/String;

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    const-string v12, "/iNaviData"

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v11

    iput-object v11, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->kInaviData:Ljava/lang/String;

    .line 96
    new-instance v11, Ljava/lang/StringBuilder;

    invoke-direct {v11}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v12, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->kStorageRoot:Ljava/lang/String;

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    const-string v12, "/res"

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v11

    iput-object v11, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->kInaviResPath:Ljava/lang/String;

    .line 97
    new-instance v5, Ljava/io/File;

    iget-object v11, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->kInaviData:Ljava/lang/String;

    invoke-direct {v5, v11}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 98
    .local v5, "file":Ljava/io/File;
    invoke-virtual {v5}, Ljava/io/File;->isDirectory()Z

    move-result v11

    if-nez v11, :cond_7

    .line 99
    invoke-virtual {v5}, Ljava/io/File;->mkdir()Z

    .line 101
    :cond_7
    new-instance v11, Ljava/lang/StringBuilder;

    invoke-direct {v11}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v12, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->kStorageRoot:Ljava/lang/String;

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    const-string v12, "/"

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    const-string v12, "temp"

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v11

    iput-object v11, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->kTpeg_data_path:Ljava/lang/String;

    .line 102
    new-instance v6, Ljava/io/File;

    iget-object v11, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->kTpeg_data_path:Ljava/lang/String;

    invoke-direct {v6, v11}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 103
    .local v6, "file_tpeg_auto":Ljava/io/File;
    new-instance v11, Ljava/io/File;

    iget-object v12, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->kTpeg_data_path:Ljava/lang/String;

    invoke-direct {v11, v12}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    invoke-virtual {v11}, Ljava/io/File;->isDirectory()Z

    move-result v11

    if-nez v11, :cond_8

    .line 104
    invoke-virtual {v6}, Ljava/io/File;->mkdir()Z

    .line 106
    :cond_8
    new-instance v11, Ljava/lang/StringBuilder;

    invoke-direct {v11}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v12, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->kMapdataPath:Ljava/lang/String;

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    const-string v12, "/wave/msgsound/startnavi.wav"

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v11

    iput-object v11, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->kStartNaviWave:Ljava/lang/String;

    .line 107
    new-instance v11, Ljava/lang/StringBuilder;

    invoke-direct {v11}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v12, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->kMapdataPath:Ljava/lang/String;

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    const-string v12, "/wave/msgsound/endnavi.wav"

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v11

    iput-object v11, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->kEndingNaviWave:Ljava/lang/String;

    .line 110
    :try_start_0
    new-instance v8, Ljava/io/FileInputStream;

    iget-object v11, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->kStartNaviWave:Ljava/lang/String;

    invoke-direct {v8, v11}, Ljava/io/FileInputStream;-><init>(Ljava/lang/String;)V

    .line 111
    .local v8, "istr":Ljava/io/FileInputStream;
    invoke-virtual {v8}, Ljava/io/FileInputStream;->close()V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    .line 117
    new-instance v2, Ljava/io/File;

    const-string v9, "/TWRamdisk"

    invoke-direct {v2, v9}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 118
    .local v2, "SoundDirectory":Ljava/io/File;
    invoke-virtual {v2}, Ljava/io/File;->isDirectory()Z

    move-result v9

    if-nez v9, :cond_9

    .line 119
    invoke-virtual {v2}, Ljava/io/File;->mkdir()Z

    .line 122
    :cond_9
    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v11, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->kInaviData:Ljava/lang/String;

    invoke-virtual {v9, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    const-string v11, "/bsarddr.bin"

    invoke-virtual {v9, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    iput-object v9, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->kLastBluetoothFile:Ljava/lang/String;

    .line 124
    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v11, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->kInaviData:Ljava/lang/String;

    invoke-virtual {v9, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    const-string v11, "/GPSOnly.txt"

    invoke-virtual {v9, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    iput-object v9, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->kLogDriveFile:Ljava/lang/String;

    move v9, v10

    .line 126
    goto/16 :goto_3

    .line 112
    .end local v2    # "SoundDirectory":Ljava/io/File;
    .end local v8    # "istr":Ljava/io/FileInputStream;
    :catch_0
    move-exception v4

    .line 113
    .local v4, "e":Ljava/io/IOException;
    invoke-virtual {v4}, Ljava/io/IOException;->printStackTrace()V

    goto/16 :goto_3
.end method


# virtual methods
.method public GetDeviceModelType()I
    .locals 1

    .prologue
    .line 142
    iget v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    return v0
.end method

.method public GetDeviceOEM()Ljava/lang/String;
    .locals 1

    .prologue
    .line 133
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_deviceOEM:Ljava/lang/String;

    return-object v0
.end method

.method public GetDeviceUUID()Ljava/lang/String;
    .locals 1

    .prologue
    .line 136
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_deviceUUID:Ljava/lang/String;

    return-object v0
.end method

.method public GetUseDRConfig()Z
    .locals 1

    .prologue
    .line 976
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_use_drgps:Z

    return v0
.end method

.method public InitStoragePath()I
    .locals 1

    .prologue
    .line 54
    invoke-direct {p0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->_InitStoragePath()I

    move-result v0

    return v0
.end method

.method public Initialize()V
    .locals 0

    .prologue
    .line 25
    invoke-direct {p0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->_InitDeviceAttribute()I

    .line 27
    return-void
.end method

.method public IsElectrostatic()Z
    .locals 1

    .prologue
    .line 1224
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->isElectrostatic:Z

    return v0
.end method

.method public IsIntalledTripApp()Z
    .locals 1

    .prologue
    .line 1014
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_installred_Trip:Z

    return v0
.end method

.method public IsMoreKitKat()Z
    .locals 2

    .prologue
    .line 1020
    iget v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    const/4 v1, 0x2

    if-eq v0, v1, :cond_0

    iget v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    const/4 v1, 0x3

    if-eq v0, v1, :cond_0

    iget v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    const/4 v1, 0x4

    if-eq v0, v1, :cond_0

    iget v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    const/4 v1, 0x5

    if-eq v0, v1, :cond_0

    iget v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    const/16 v1, 0x12

    if-eq v0, v1, :cond_0

    iget v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    const/4 v1, 0x6

    if-eq v0, v1, :cond_0

    iget v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    const/4 v1, 0x7

    if-eq v0, v1, :cond_0

    iget v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    const/16 v1, 0x8

    if-eq v0, v1, :cond_0

    iget v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    const/16 v1, 0x9

    if-eq v0, v1, :cond_0

    iget v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    const/16 v1, 0xa

    if-eq v0, v1, :cond_0

    iget v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    const/16 v1, 0xb

    if-eq v0, v1, :cond_0

    iget v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    const/16 v1, 0xc

    if-eq v0, v1, :cond_0

    iget v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    const/16 v1, 0xf

    if-eq v0, v1, :cond_0

    iget v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    const/16 v1, 0x10

    if-eq v0, v1, :cond_0

    iget v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    const/16 v1, 0x11

    if-eq v0, v1, :cond_0

    iget v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    const/16 v1, 0xd

    if-eq v0, v1, :cond_0

    iget v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    const/16 v1, 0xe

    if-eq v0, v1, :cond_0

    iget v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    const/16 v1, 0x13

    if-eq v0, v1, :cond_0

    iget v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    const/16 v1, 0x14

    if-ne v0, v1, :cond_1

    .line 1040
    :cond_0
    const/4 v0, 0x1

    .line 1041
    :goto_0
    return v0

    :cond_1
    const/4 v0, 0x0

    goto :goto_0
.end method

.method public IsThinkwareDevice()Z
    .locals 1

    .prologue
    .line 1010
    const/4 v0, 0x1

    return v0
.end method

.method public SetUseDRConfig()Z
    .locals 8

    .prologue
    const/4 v4, 0x1

    const/4 v5, 0x0

    .line 954
    const-string v3, ""

    .line 956
    .local v3, "line":Ljava/lang/String;
    :try_start_0
    invoke-static {}, Ljava/lang/Runtime;->getRuntime()Ljava/lang/Runtime;

    move-result-object v6

    const-string v7, "getprop persist.sys.drgps"

    invoke-virtual {v6, v7}, Ljava/lang/Runtime;->exec(Ljava/lang/String;)Ljava/lang/Process;

    move-result-object v2

    .line 957
    .local v2, "ifc":Ljava/lang/Process;
    new-instance v0, Ljava/io/BufferedReader;

    new-instance v6, Ljava/io/InputStreamReader;

    invoke-virtual {v2}, Ljava/lang/Process;->getInputStream()Ljava/io/InputStream;

    move-result-object v7

    invoke-direct {v6, v7}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;)V

    invoke-direct {v0, v6}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V

    .line 958
    .local v0, "bis":Ljava/io/BufferedReader;
    invoke-virtual {v0}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    move-result-object v3

    .line 959
    invoke-virtual {v2}, Ljava/lang/Process;->destroy()V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    .line 963
    const-string v6, ""

    invoke-virtual {v3, v6}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v6

    if-eqz v6, :cond_0

    const-string v3, "0"

    .line 965
    :cond_0
    const-string v6, "1"

    invoke-virtual {v3, v6}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v6

    if-eqz v6, :cond_1

    .line 966
    iput-boolean v4, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_use_drgps:Z

    .line 971
    .end local v0    # "bis":Ljava/io/BufferedReader;
    .end local v2    # "ifc":Ljava/lang/Process;
    :goto_0
    return v4

    .line 960
    :catch_0
    move-exception v1

    .local v1, "e":Ljava/io/IOException;
    move v4, v5

    .line 961
    goto :goto_0

    .line 968
    .end local v1    # "e":Ljava/io/IOException;
    .restart local v0    # "bis":Ljava/io/BufferedReader;
    .restart local v2    # "ifc":Ljava/lang/Process;
    :cond_1
    iput-boolean v5, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_use_drgps:Z

    goto :goto_0
.end method

.method public checkTrip(Landroid/content/Context;)V
    .locals 6
    .param p1, "context"    # Landroid/content/Context;

    .prologue
    .line 1094
    if-eqz p1, :cond_2

    .line 1095
    const/4 v0, 0x0

    .line 1096
    .local v0, "bHasTrip":Z
    invoke-virtual {p1}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v4

    const/16 v5, 0x2000

    invoke-virtual {v4, v5}, Landroid/content/pm/PackageManager;->getInstalledApplications(I)Ljava/util/List;

    move-result-object v3

    .line 1097
    .local v3, "pkgList":Ljava/util/List;, "Ljava/util/List<Landroid/content/pm/ApplicationInfo;>;"
    invoke-interface {v3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    .local v1, "i$":Ljava/util/Iterator;
    :cond_0
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_1

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/content/pm/ApplicationInfo;

    .line 1098
    .local v2, "info":Landroid/content/pm/ApplicationInfo;
    iget-object v4, v2, Landroid/content/pm/ApplicationInfo;->packageName:Ljava/lang/String;

    const-string v5, "com.thinkware.trip.main"

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_0

    .line 1099
    const/4 v0, 0x1

    goto :goto_0

    .line 1102
    .end local v2    # "info":Landroid/content/pm/ApplicationInfo;
    :cond_1
    iput-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_installred_Trip:Z

    .line 1104
    .end local v0    # "bHasTrip":Z
    .end local v1    # "i$":Ljava/util/Iterator;
    .end local v3    # "pkgList":Ljava/util/List;, "Ljava/util/List<Landroid/content/pm/ApplicationInfo;>;"
    :cond_2
    return-void
.end method

.method public getDefaultVolume()I
    .locals 2

    .prologue
    .line 1216
    iget v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    const/16 v1, 0x13

    if-ne v0, v1, :cond_0

    .line 1217
    const/4 v0, 0x2

    .line 1219
    :goto_0
    return v0

    :cond_0
    const/4 v0, 0x3

    goto :goto_0
.end method

.method public getDeviceAppName()Ljava/lang/String;
    .locals 1

    .prologue
    .line 1343
    iget v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    packed-switch v0, :pswitch_data_0

    .line 1383
    const-string v0, "taurus"

    :goto_0
    return-object v0

    .line 1345
    :pswitch_0
    const-string v0, "taurus"

    goto :goto_0

    .line 1347
    :pswitch_1
    const-string v0, "leo"

    goto :goto_0

    .line 1349
    :pswitch_2
    const-string v0, "cube2"

    goto :goto_0

    .line 1351
    :pswitch_3
    const-string v0, "runa"

    goto :goto_0

    .line 1353
    :pswitch_4
    const-string v0, "wlf"

    goto :goto_0

    .line 1355
    :pswitch_5
    const-string v0, "mx"

    goto :goto_0

    .line 1357
    :pswitch_6
    const-string v0, "cube_lite"

    goto :goto_0

    .line 1359
    :pswitch_7
    const-string v0, "cube_fl"

    goto :goto_0

    .line 1361
    :pswitch_8
    const-string v0, "mowgli"

    goto :goto_0

    .line 1363
    :pswitch_9
    const-string v0, "lucy_a"

    goto :goto_0

    .line 1365
    :pswitch_a
    const-string v0, "lucy_m"

    goto :goto_0

    .line 1367
    :pswitch_b
    const-string v0, "lucy_b"

    goto :goto_0

    .line 1369
    :pswitch_c
    const-string v0, "mx_t"

    goto :goto_0

    .line 1371
    :pswitch_d
    const-string v0, "ix"

    goto :goto_0

    .line 1373
    :pswitch_e
    const-string v0, "giant"

    goto :goto_0

    .line 1375
    :pswitch_f
    const-string v0, "neo_a"

    goto :goto_0

    .line 1377
    :pswitch_10
    const-string v0, "neo_m"

    goto :goto_0

    .line 1379
    :pswitch_11
    const-string v0, "man"

    goto :goto_0

    .line 1381
    :pswitch_12
    const-string v0, "maple"

    goto :goto_0

    .line 1343
    nop

    :pswitch_data_0
    .packed-switch 0x2
        :pswitch_0
        :pswitch_1
        :pswitch_2
        :pswitch_3
        :pswitch_5
        :pswitch_6
        :pswitch_7
        :pswitch_8
        :pswitch_9
        :pswitch_a
        :pswitch_b
        :pswitch_c
        :pswitch_d
        :pswitch_e
        :pswitch_f
        :pswitch_10
        :pswitch_4
        :pswitch_11
        :pswitch_12
    .end packed-switch
.end method

.method public getScaleType()I
    .locals 2

    .prologue
    .line 1128
    iget v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_scaletype:I

    const/4 v1, -0x1

    if-ne v0, v1, :cond_0

    .line 1129
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INaviScaleManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INaviScaleManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/INaviScaleManager;->getScaleType()I

    move-result v0

    iput v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_scaletype:I

    .line 1132
    :cond_0
    iget v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_scaletype:I

    return v0
.end method

.method public isBackGroundRun()Z
    .locals 2

    .prologue
    .line 1300
    iget v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    const/16 v1, 0xe

    if-ne v0, v1, :cond_0

    .line 1301
    const/4 v0, 0x0

    .line 1303
    :goto_0
    return v0

    :cond_0
    const/4 v0, 0x1

    goto :goto_0
.end method

.method public isLowMemory()Z
    .locals 2

    .prologue
    .line 1321
    iget v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    const/4 v1, 0x2

    if-eq v0, v1, :cond_0

    iget v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    const/4 v1, 0x6

    if-eq v0, v1, :cond_0

    iget v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    const/4 v1, 0x4

    if-eq v0, v1, :cond_0

    iget v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    const/16 v1, 0xd

    if-eq v0, v1, :cond_0

    iget v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    const/16 v1, 0x13

    if-ne v0, v1, :cond_1

    .line 1327
    :cond_0
    const/4 v0, 0x0

    .line 1338
    :goto_0
    return v0

    :cond_1
    const/4 v0, 0x1

    goto :goto_0
.end method

.method public isNoSupportAR()Z
    .locals 3

    .prologue
    const/16 v2, 0xb

    .line 1149
    iget v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    const/4 v1, 0x7

    if-eq v0, v1, :cond_0

    iget v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    const/16 v1, 0x9

    if-eq v0, v1, :cond_0

    iget v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    const/16 v1, 0xa

    if-eq v0, v1, :cond_0

    iget v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    if-eq v0, v2, :cond_0

    iget v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    const/16 v1, 0xc

    if-eq v0, v1, :cond_0

    iget v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    const/16 v1, 0xf

    if-eq v0, v1, :cond_0

    iget v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    const/16 v1, 0x10

    if-eq v0, v1, :cond_0

    iget v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    const/16 v1, 0x11

    if-eq v0, v1, :cond_0

    iget v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    if-eq v0, v2, :cond_0

    iget v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    const/16 v1, 0x13

    if-eq v0, v1, :cond_0

    iget v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    const/16 v1, 0x14

    if-ne v0, v1, :cond_1

    .line 1160
    :cond_0
    const/4 v0, 0x1

    .line 1161
    :goto_0
    return v0

    :cond_1
    const/4 v0, 0x0

    goto :goto_0
.end method

.method public isSupport800x480()Z
    .locals 3

    .prologue
    const/4 v0, 0x1

    .line 1254
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetDeviceModelType()I

    move-result v1

    const/4 v2, 0x4

    if-eq v1, v2, :cond_0

    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetDeviceModelType()I

    move-result v1

    const/4 v2, 0x5

    if-eq v1, v2, :cond_0

    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetDeviceModelType()I

    move-result v1

    const/16 v2, 0x12

    if-eq v1, v2, :cond_0

    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetDeviceModelType()I

    move-result v1

    const/4 v2, 0x7

    if-eq v1, v2, :cond_0

    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetDeviceModelType()I

    move-result v1

    const/16 v2, 0x8

    if-eq v1, v2, :cond_0

    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetDeviceModelType()I

    move-result v1

    const/16 v2, 0x9

    if-eq v1, v2, :cond_0

    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetDeviceModelType()I

    move-result v1

    const/16 v2, 0xa

    if-eq v1, v2, :cond_0

    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetDeviceModelType()I

    move-result v1

    const/16 v2, 0xb

    if-eq v1, v2, :cond_0

    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetDeviceModelType()I

    move-result v1

    const/16 v2, 0xf

    if-eq v1, v2, :cond_0

    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetDeviceModelType()I

    move-result v1

    const/16 v2, 0x10

    if-eq v1, v2, :cond_0

    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetDeviceModelType()I

    move-result v1

    const/16 v2, 0x11

    if-eq v1, v2, :cond_0

    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetDeviceModelType()I

    move-result v1

    const/16 v2, 0x14

    if-eq v1, v2, :cond_0

    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->isSupportB2BRentalCar()Z

    move-result v1

    if-eq v1, v0, :cond_0

    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->isSupportB2BTaxi()Z

    move-result v1

    if-eq v1, v0, :cond_0

    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->isSupportB2BTruck()Z

    move-result v1

    if-ne v1, v0, :cond_1

    .line 1271
    :cond_0
    :goto_0
    return v0

    :cond_1
    const/4 v0, 0x0

    goto :goto_0
.end method

.method public isSupportAirMode()Z
    .locals 1

    .prologue
    .line 1111
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_air_mode:Z

    return v0
.end method

.method public isSupportB2BRentalCar()Z
    .locals 2

    .prologue
    .line 1293
    iget v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    const/16 v1, 0xc

    if-ne v0, v1, :cond_0

    .line 1294
    const/4 v0, 0x1

    .line 1296
    :goto_0
    return v0

    :cond_0
    const/4 v0, 0x0

    goto :goto_0
.end method

.method public isSupportB2BTaxi()Z
    .locals 2

    .prologue
    .line 1276
    iget v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    const/4 v1, 0x6

    if-ne v0, v1, :cond_0

    .line 1277
    const/4 v0, 0x1

    .line 1279
    :goto_0
    return v0

    :cond_0
    const/4 v0, 0x0

    goto :goto_0
.end method

.method public isSupportB2BTruck()Z
    .locals 2

    .prologue
    .line 1284
    iget v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    const/16 v1, 0xd

    if-eq v0, v1, :cond_0

    iget v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    const/16 v1, 0x13

    if-ne v0, v1, :cond_1

    .line 1286
    :cond_0
    const/4 v0, 0x1

    .line 1288
    :goto_0
    return v0

    :cond_1
    const/4 v0, 0x0

    goto :goto_0
.end method

.method public isSupportIVision()Z
    .locals 2

    .prologue
    .line 1307
    iget v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    const/16 v1, 0xe

    if-ne v0, v1, :cond_0

    .line 1308
    const/4 v0, 0x1

    .line 1310
    :goto_0
    return v0

    :cond_0
    const/4 v0, 0x0

    goto :goto_0
.end method

.method public isSupportLiveService()Z
    .locals 2

    .prologue
    const/4 v0, 0x1

    .line 1183
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->isSupportB2BTaxi()Z

    move-result v1

    if-eq v1, v0, :cond_0

    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->isSupportB2BTruck()Z

    move-result v1

    if-ne v1, v0, :cond_1

    .line 1185
    :cond_0
    const/4 v0, 0x0

    .line 1187
    :cond_1
    return v0
.end method

.method public isSupportNipMode()Z
    .locals 2

    .prologue
    .line 1209
    iget v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    const/16 v1, 0x13

    if-ne v0, v1, :cond_0

    .line 1210
    const/4 v0, 0x0

    .line 1212
    :goto_0
    return v0

    :cond_0
    const/4 v0, 0x1

    goto :goto_0
.end method

.method public isSupportPLog()Z
    .locals 3

    .prologue
    const/4 v0, 0x1

    .line 1389
    iget v1, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    if-eq v1, v0, :cond_0

    iget v1, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    if-eqz v1, :cond_0

    iget v1, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    const/4 v2, 0x6

    if-eq v1, v2, :cond_0

    iget v1, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    const/16 v2, 0xc

    if-eq v1, v2, :cond_0

    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->isTruckDevice()Z

    move-result v1

    if-ne v1, v0, :cond_1

    .line 1394
    :cond_0
    const/4 v0, 0x0

    .line 1396
    :cond_1
    return v0
.end method

.method public isSupportRoadView()Z
    .locals 2

    .prologue
    .line 1430
    iget v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    const/16 v1, 0x13

    if-ne v0, v1, :cond_0

    .line 1431
    const/4 v0, 0x0

    .line 1433
    :goto_0
    return v0

    :cond_0
    const/4 v0, 0x1

    goto :goto_0
.end method

.method public isSupportRouteOptionTruck()Z
    .locals 1

    .prologue
    .line 1178
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->isTruckDevice()Z

    move-result v0

    return v0
.end method

.method public isSupportSuperCapPowerOff()Z
    .locals 1

    .prologue
    .line 1145
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_supercap_poweroff:Z

    return v0
.end method

.method public isSupportTLink()Z
    .locals 3

    .prologue
    const/4 v2, 0x1

    .line 1202
    iget v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    const/16 v1, 0x13

    if-ne v0, v1, :cond_0

    .line 1205
    :cond_0
    return v2
.end method

.method public isSupportVer3_0()Z
    .locals 2

    .prologue
    .line 1232
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v0

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetDeviceModelType()I

    move-result v0

    const/4 v1, 0x2

    if-eq v0, v1, :cond_0

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v0

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetDeviceModelType()I

    move-result v0

    const/4 v1, 0x3

    if-eq v0, v1, :cond_0

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v0

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetDeviceModelType()I

    move-result v0

    const/4 v1, 0x4

    if-eq v0, v1, :cond_0

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v0

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetDeviceModelType()I

    move-result v0

    const/4 v1, 0x5

    if-eq v0, v1, :cond_0

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v0

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetDeviceModelType()I

    move-result v0

    const/16 v1, 0x12

    if-eq v0, v1, :cond_0

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v0

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetDeviceModelType()I

    move-result v0

    const/4 v1, 0x7

    if-eq v0, v1, :cond_0

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v0

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetDeviceModelType()I

    move-result v0

    const/16 v1, 0x8

    if-eq v0, v1, :cond_0

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v0

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetDeviceModelType()I

    move-result v0

    const/16 v1, 0x9

    if-eq v0, v1, :cond_0

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v0

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetDeviceModelType()I

    move-result v0

    const/16 v1, 0xa

    if-eq v0, v1, :cond_0

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v0

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetDeviceModelType()I

    move-result v0

    const/16 v1, 0xb

    if-eq v0, v1, :cond_0

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v0

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetDeviceModelType()I

    move-result v0

    const/16 v1, 0xf

    if-eq v0, v1, :cond_0

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v0

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetDeviceModelType()I

    move-result v0

    const/16 v1, 0x10

    if-eq v0, v1, :cond_0

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v0

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetDeviceModelType()I

    move-result v0

    const/16 v1, 0x11

    if-eq v0, v1, :cond_0

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v0

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetDeviceModelType()I

    move-result v0

    const/16 v1, 0x14

    if-eq v0, v1, :cond_0

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v0

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetDeviceModelType()I

    move-result v0

    const/16 v1, 0xe

    if-ne v0, v1, :cond_1

    .line 1247
    :cond_0
    const/4 v0, 0x1

    .line 1249
    :goto_0
    return v0

    :cond_1
    const/4 v0, 0x0

    goto :goto_0
.end method

.method public isSupport_TLinkAuto_Off()Z
    .locals 2

    .prologue
    const/4 v0, 0x1

    .line 1192
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->isSupportB2BTaxi()Z

    move-result v1

    if-eq v1, v0, :cond_0

    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->isSupportB2BTruck()Z

    move-result v1

    if-ne v1, v0, :cond_1

    .line 1196
    :cond_0
    :goto_0
    return v0

    :cond_1
    const/4 v0, 0x0

    goto :goto_0
.end method

.method public isTpegDevice()Z
    .locals 2

    .prologue
    .line 1314
    iget v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    const/16 v1, 0xe

    if-ne v0, v1, :cond_0

    .line 1315
    const/4 v0, 0x0

    .line 1317
    :goto_0
    return v0

    :cond_0
    const/4 v0, 0x1

    goto :goto_0
.end method

.method public isTruckDevice()Z
    .locals 2

    .prologue
    .line 1167
    iget v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    const/16 v1, 0xd

    if-eq v0, v1, :cond_0

    iget v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    const/16 v1, 0x13

    if-ne v0, v1, :cond_1

    .line 1169
    :cond_0
    const/4 v0, 0x1

    .line 1171
    :goto_0
    return v0

    :cond_1
    const/4 v0, 0x0

    goto :goto_0
.end method

.method public isWideDisplay()Z
    .locals 4

    .prologue
    const/4 v2, 0x0

    const/4 v1, 0x1

    .line 1136
    iget v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_widedisplay:I

    const/4 v3, -0x1

    if-ne v0, v3, :cond_0

    .line 1137
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INaviScaleManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INaviScaleManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/INaviScaleManager;->getWideDisplay()Z

    move-result v0

    if-eqz v0, :cond_1

    move v0, v1

    :goto_0
    iput v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_widedisplay:I

    .line 1139
    :cond_0
    iget v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_widedisplay:I

    if-ne v0, v1, :cond_2

    :goto_1
    return v1

    :cond_1
    move v0, v2

    .line 1137
    goto :goto_0

    :cond_2
    move v1, v2

    .line 1139
    goto :goto_1
.end method

.method public isYtnDevice()Z
    .locals 2

    .prologue
    .line 1401
    iget v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    const/4 v1, 0x2

    if-eq v0, v1, :cond_0

    iget v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    const/4 v1, 0x3

    if-eq v0, v1, :cond_0

    iget v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    const/4 v1, 0x4

    if-eq v0, v1, :cond_0

    iget v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    const/4 v1, 0x5

    if-eq v0, v1, :cond_0

    iget v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    const/4 v1, 0x6

    if-eq v0, v1, :cond_0

    iget v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    const/4 v1, 0x7

    if-eq v0, v1, :cond_0

    iget v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    const/16 v1, 0x8

    if-eq v0, v1, :cond_0

    iget v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    const/16 v1, 0x9

    if-eq v0, v1, :cond_0

    iget v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    const/16 v1, 0xa

    if-eq v0, v1, :cond_0

    iget v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    const/16 v1, 0xb

    if-eq v0, v1, :cond_0

    iget v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    const/16 v1, 0xc

    if-eq v0, v1, :cond_0

    iget v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    const/16 v1, 0xd

    if-eq v0, v1, :cond_0

    iget v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    const/16 v1, 0xe

    if-eq v0, v1, :cond_0

    iget v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    const/16 v1, 0xf

    if-eq v0, v1, :cond_0

    iget v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    const/16 v1, 0x10

    if-eq v0, v1, :cond_0

    iget v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    const/16 v1, 0x11

    if-eq v0, v1, :cond_0

    iget v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    const/16 v1, 0x12

    if-eq v0, v1, :cond_0

    iget v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    const/16 v1, 0x13

    if-eq v0, v1, :cond_0

    iget v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    const/16 v1, 0x14

    if-eq v0, v1, :cond_0

    iget v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    const/16 v1, 0x15

    if-ne v0, v1, :cond_1

    .line 1422
    :cond_0
    const/4 v0, 0x1

    .line 1424
    :goto_0
    return v0

    :cond_1
    const/4 v0, 0x0

    goto :goto_0
.end method

.method public is_SupportDevice()Z
    .locals 1

    .prologue
    .line 139
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_Support_Deivce:Z

    return v0
.end method

.method public is_support_DMB()Z
    .locals 1

    .prologue
    .line 146
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_DMB:Z

    return v0
.end method

.method public is_support_ExternaGPS()Z
    .locals 1

    .prologue
    .line 162
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_ExternaGPS:Z

    return v0
.end method

.method public is_support_ExternaGPS_PowerOn()Z
    .locals 1

    .prologue
    .line 166
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_ExternaGPS_PowerOn:Z

    return v0
.end method

.method public is_support_Manager()Z
    .locals 1

    .prologue
    .line 170
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_Manager:Z

    return v0
.end method

.method public is_support_Remote()Z
    .locals 1

    .prologue
    .line 158
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_Remote:Z

    return v0
.end method

.method public is_support_SystemUIService()Z
    .locals 2

    .prologue
    .line 1044
    const/4 v0, 0x0

    .line 1045
    .local v0, "bRet":Z
    iget v1, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_device_model:I

    packed-switch v1, :pswitch_data_0

    .line 1070
    const/4 v0, 0x0

    .line 1074
    :goto_0
    return v0

    .line 1067
    :pswitch_0
    const/4 v0, 0x1

    .line 1068
    goto :goto_0

    .line 1045
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
    .end packed-switch
.end method

.method public is_support_TBT()Z
    .locals 1

    .prologue
    .line 150
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_TBT:Z

    return v0
.end method

.method public is_support_TPEG()Z
    .locals 1

    .prologue
    .line 154
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_TPEG:Z

    return v0
.end method

.method public is_support_builtin_statusbar()Z
    .locals 1

    .prologue
    .line 1124
    const/4 v0, 0x0

    return v0
.end method

.method public is_support_myroute()Z
    .locals 1

    .prologue
    .line 174
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportMyRoute:Z

    return v0
.end method

.method public is_support_scale()Z
    .locals 1

    .prologue
    .line 1120
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_scale:Z

    return v0
.end method

.method public setSupportAirMode(Z)V
    .locals 0
    .param p1, "isAirMode"    # Z

    .prologue
    .line 1115
    iput-boolean p1, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_support_air_mode:Z

    .line 1116
    return-void
.end method

.method public supportAINA()Z
    .locals 1

    .prologue
    .line 1107
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportAINA:Z

    return v0
.end method

.method public supportDualRoute()Z
    .locals 1

    .prologue
    .line 1090
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportDualRoute:Z

    return v0
.end method

.method public supportEXPSearch()Z
    .locals 1

    .prologue
    .line 1082
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportEXPSearch:Z

    return v0
.end method

.method public supportRSearch()Z
    .locals 1

    .prologue
    .line 1077
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportRSearch:Z

    return v0
.end method

.method public supportRecommendedWord()Z
    .locals 1

    .prologue
    .line 1087
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->m_supportRecommendedWord:Z

    return v0
.end method
