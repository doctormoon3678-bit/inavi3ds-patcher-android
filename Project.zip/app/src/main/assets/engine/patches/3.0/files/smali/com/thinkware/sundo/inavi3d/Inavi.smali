.class public Lcom/thinkware/sundo/inavi3d/Inavi;
.super Ljava/lang/Object;
.source "Inavi.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/thinkware/sundo/inavi3d/Inavi$location;
    }
.end annotation


# static fields
.field private static Dualsearch:Lcom/thinkware/sundo/inavi3d/Struct/DualSearchInfo; = null

.field static MULTI_BUTTONDOWN:I = 0x0

.field static MULTI_BUTTONMOVE:I = 0x0

.field static MULTI_BUTTONUP:I = 0x0

.field public static final MY_ROUTE_OPTION:Ljava/lang/String; = "\ub0b4\uacbd\ub85c"

.field public static final NATIVE_CURRNET_ROUTE_FILE:I = 0x1f40

.field public static final NATIVE_INIT_END:I = 0x1b5f

.field static final NATIVE_MSG_AR:I = 0x2710

.field static final NATIVE_MSG_AR_CONFIG_EXCUTE:I = 0x2711

.field public static final NATIVE_MSG_CHANGE_LINK:I = 0x1772

.field public static final NATIVE_MSG_CHECK_REROUTE:I = 0x138e

.field public static final NATIVE_MSG_DRM_AUTHORIZE:I = 0x138d

.field public static final NATIVE_MSG_DR_DATA_BUTTON_HIDE:I = 0x1776

.field public static final NATIVE_MSG_DR_DATA_BUTTON_SHOW:I = 0x1775

.field public static final NATIVE_MSG_EXIT:I = 0x270f

.field public static final NATIVE_MSG_GPS_INIT:I = 0x1774

.field public static final NATIVE_MSG_HOME:I = 0x1b60

.field static final NATIVE_MSG_IEVE_CAR_ANGLE_DIR:I = 0x1d56

.field static final NATIVE_MSG_IEVE_CAR_ANGLE_VRT:I = 0x1d57

.field static final NATIVE_MSG_IEVE_CAR_POS_X:I = 0x1d60

.field static final NATIVE_MSG_IEVE_CAR_POS_Y:I = 0x1d61

.field static final NATIVE_MSG_IEVE_CAR_POS_Z:I = 0x1d62

.field static final NATIVE_MSG_IEVE_CAR_SPEED:I = 0x1d6a

.field static final NATIVE_MSG_IEVE_ROAD_ATTRIB_NUMLANE:I = 0x1dbc

.field static final NATIVE_MSG_IEVE_ROAD_ATTRIB_ROTARY:I = 0x1dbe

.field static final NATIVE_MSG_IEVE_ROAD_ATTRIB_SPEC:I = 0x1dbb

.field static final NATIVE_MSG_IEVE_ROAD_ATTRIB_TOLLGATE:I = 0x1dbd

.field static final NATIVE_MSG_IEVE_ROAD_ATTRIB_TYPE:I = 0x1dba

.field static final NATIVE_MSG_IEVE_SAFE_CAMERA_ANGLE:I = 0x1dd1

.field static final NATIVE_MSG_IEVE_SAFE_CAMERA_DIST:I = 0x1dd2

.field static final NATIVE_MSG_IEVE_SAFE_CAMERA_KIND:I = 0x1dce

.field static final NATIVE_MSG_IEVE_SAFE_CAMERA_LIMIT:I = 0x1dd3

.field static final NATIVE_MSG_IEVE_SAFE_CAMERA_RX:I = 0x1dcf

.field static final NATIVE_MSG_IEVE_SAFE_CAMERA_RY:I = 0x1dd0

.field static final NATIVE_MSG_IEVE_SAFE_GUIDE_KIND:I = 0x1dc4

.field static final NATIVE_MSG_IEVE_SAFE_GUIDE_POS_RX:I = 0x1dc5

.field static final NATIVE_MSG_IEVE_SAFE_GUIDE_POS_RY:I = 0x1dc6

.field static final NATIVE_MSG_IEVE_TURNPOINT_DIST:I = 0x1ddb

.field static final NATIVE_MSG_IEVE_TURNPOINT_KIND:I = 0x1dd8

.field static final NATIVE_MSG_IEVE_TURNPOINT_PASSNLANE:I = 0x1ddc

.field static final NATIVE_MSG_IEVE_TURNPOINT_POS_X:I = 0x1dd9

.field static final NATIVE_MSG_IEVE_TURNPOINT_POS_Y:I = 0x1dda

.field public static final NATIVE_MSG_LOGGING:I = 0x1773

.field public static final NATIVE_MSG_LOG_DRIVE:I = 0x1771

.field public static final NATIVE_MSG_MAP:I = 0x2328

.field static final NATIVE_MSG_MAP_CHANG_NOTI_RTM_MAPBTN:I = 0x2336

.field static final NATIVE_MSG_MAP_DESTINFO:I = 0x232c

.field static final NATIVE_MSG_MAP_DUALLEVELBAR:I = 0x232f

.field static final NATIVE_MSG_MAP_HIGHWAYMODE:I = 0x232a

.field static final NATIVE_MSG_MAP_HIGHWAYMODEBUTTON:I = 0x2333

.field static final NATIVE_MSG_MAP_LEVELBAR:I = 0x232e

.field static final NATIVE_MSG_MAP_LOCALGUIDE:I = 0x232b

.field static final NATIVE_MSG_MAP_NAVICURRENT:I = 0x2329

.field static final NATIVE_MSG_MAP_ROUTERESULT:I = 0x232d

.field static final NATIVE_MSG_MAP_STARTROUTE:I = 0x2335

.field static final NATIVE_MSG_MAP_TRAFFIC:I = 0x2331

.field static final NATIVE_MSG_MAP_TRAFFICINDICATOR:I = 0x2332

.field static final NATIVE_MSG_MAP_VIEWMODE:I = 0x2334

.field static final NATIVE_MSG_MAP_VOLUME:I = 0x2330

.field public static final NATIVE_MSG_MMC_DIRECTESCAPE:I = 0x1770

.field static final NATIVE_MSG_MY_ROUTE_MAP:I = 0x238c

.field static final NATIVE_MSG_MY_ROUTE_MAP_EDIT_ERROR:I = 0x2391

.field static final NATIVE_MSG_MY_ROUTE_MAP_ERROR:I = 0x238e

.field static final NATIVE_MSG_MY_ROUTE_MAP_IMAGE_PATH:I = 0x238d

.field static final NATIVE_MSG_MY_ROUTE_MAP_MANUAL:I = 0x2390

.field static final NATIVE_MSG_MY_ROUTE_MAP_POPUP_SHOW:I = 0x238f

.field static final NATIVE_MSG_MY_ROUTE_MAP_SAVE_INFO:I = 0x2392

.field public static final NATIVE_MSG_NETWORK_NOT_CONNECT:I = 0x1b5d

.field public static final NATIVE_MSG_REROUTE_STATUS:I = 0x138c

.field public static final NATIVE_MSG_RESTART:I = 0x270e

.field static final NATIVE_MSG_ROUTE_RESULT_ERROR_TRUCK:I = 0x23f1

.field public static final NATIVE_MSG_RUN_DMB:I = 0x1b59

.field public static final NATIVE_MSG_RUN_IEVE:I = 0x1b5a

.field public static final NATIVE_MSG_RUN_IEVE_CALB:I = 0x1b5b

.field public static final NATIVE_MSG_RUN_NETWORK:I = 0x1b5c

.field public static final NATIVE_MSG_SIMULATION:I = 0x138b

.field public static final NATIVE_MSG_TBT_ON_OFF:I = 0x1b5e

.field static final NATIVE_MSG_TRUCK:I = 0x23f0

.field static final NATIVE_MSG_TUNNEL:I = 0x2454

.field public static final NATIVE_MSG_WAIT_SYMBOL_SHOW:I = 0x1b58

.field public static final NATIVE_MSG_WALK:I = 0x138a

.field public static final NATIVE_ROUTE_SEARCHING_END:I = 0x1fbd4

.field public static final NATIVE_ROUTE_SEARCHING_FAIL:I = 0x1fbd5

.field public static final NATIVE_ROUTE_SEARCHING_START:I = 0x1fbd1

.field public static final NATIVE_ROUTE_STATUS:I = 0x1fbd0

.field public static final NATIVE_TCON_TERMS_CONFIRM_CHECK:I = 0x1d4c

.field public static final NAVTIVE_MSG_ROUTESEARCHING:I = 0x1388

.field public static final ROUTE_RESULT_ERROR_TYPE_TRUCK_HEIGHT:I = 0x1

.field public static final ROUTE_RESULT_ERROR_TYPE_TRUCK_WEIGHT:I = 0x0

.field public static final ROUTE_RESULT_ERROR_TYPE_TRUCK_WEIGHT_HEIGHT:I = 0x2

.field static TAG:Ljava/lang/String;

.field private static TrafficRouteTableInfo:Lcom/thinkware/sundo/inavi3d/ROUTE_TABLE_RENEW_INFO;

.field private static authDrm:Lcom/thinkware/sundo/inavi3d/AuthDRM;

.field static bUISetting:Z

.field public static backgroundMsgVec:Ljava/util/Vector;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Vector",
            "<",
            "Lcom/thinkware/sundo/inavi3d/Struct/MsgStructer;",
            ">;"
        }
    .end annotation
.end field

.field static btnLocalName:Landroid/widget/Button;

.field static courseRightViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/DriveCourseCurrentViewAR;

.field static courseView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/DriveCourseView;

.field static courseViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/DriveCourseViewAR;

.field static crossWayView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/CrossWayView;

.field static crossWayView2:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/CrossWayView;

.field static crossWayView3:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/CrossWayView;

.field static crossWayView4:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/CrossWayView;

.field static crossname:Landroid/widget/Button;

.field static cswsViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/CSWSViewAR;

.field static currentOnLayOutAR:Landroid/widget/RelativeLayout;

.field static currentOnLayOutNormal:Landroid/widget/RelativeLayout;

.field static driveCourseViewRouteCancelButtonAR:Landroid/widget/Button;

.field static driveLineView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/LaneInfoView;

.field static driveLineViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/LaneInfoViewAR;

.field private static existdBackgroundMessage:Z

.field public static firstTBTGuide:Z

.field static hightwayTurnAreaViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/HighwayTurnAreaViewAR;

.field private static hudguide:Lcom/thinkware/sundo/remoteHUD/HUDGuide;

.field static isDoingLeftRightAnimation:Z

.field static isDoingUpDownAnimation:Z

.field static mAtmosphereGraph:Lcom/thinkware/sundo/inavi3d/DR/AtmosphereGraph;

.field public static mCarAngleDir:F

.field public static mCarAngleVrt:F

.field public static mCarPosX:F

.field public static mCarPosY:F

.field public static mCarPosZ:F

.field public static mCarSpeed:I

.field private static mContext:Landroid/content/Context;

.field static mDRDataLayout:Landroid/widget/RelativeLayout;

.field static mDRIcon:Landroid/view/View;

.field static mDRIndicator:Landroid/view/View;

.field static mDRLeftRightRotationView:Lcom/thinkware/sundo/inavi3d/DR/LeftRightRotationView;

.field static mDRLeftRightRotationView2:Landroid/widget/ImageView;

.field static mDRUpDownRotationView:Lcom/thinkware/sundo/inavi3d/DR/UpDownRotationView;

.field static mDRUpDownRotationView2:Landroid/widget/ImageView;

.field static mGPSInfo:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

.field public static mGPSViewMgr:Lcom/thinkware/sundo/inavi3d/GPSViewManager;

.field static mGSensor_Action:I

.field static mGSensor_Error:I

.field static mGSensor_Sensibility:I

.field static mGSensor_Use:I

.field private static mHandlerMain:Landroid/os/Handler;

.field public static mInermediate_dist:I

.field public static mInermediate_kind:I

.field private static mIsDrSpeed:Z

.field public static mIsTunnel:Z

.field public static mLoadWebp:Lcom/thinkware/sundo/inavi3d/loadWebp;

.field static mLogCountDown:I

.field static mLogLiveLogging:I

.field static mMMCInfo:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

.field public static mRoadAttribNumLane:I

.field public static mRoadAttribRotary:I

.field public static mRoadAttribSpec:I

.field public static mRoadAttribTollGate:I

.field public static mRoadAttribType:I

.field static mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

.field static mSATInfo:Lcom/tw/mapmatch/remote/mapmatch/SATInfo;

.field public static mSafeCameraAngle:I

.field public static mSafeCameraDist:I

.field public static mSafeCameraKind:I

.field public static mSafeCameraLimit:I

.field public static mSafeCameraPosrX:I

.field public static mSafeCameraPosrY:I

.field public static mSafeGuideKind:I

.field public static mSafeGuidePosrX:I

.field public static mSafeGuidePosrY:I

.field public static mSafeZoneAvr:Z

.field public static mSafecamera_leader:I

.field public static mTurnPointDist:I

.field public static mTurnPointKind:I

.field public static mTurnPointPassedNumLane:I

.field public static mTurnPointX:I

.field public static mTurnPointY:I

.field static mUIManager:Lcom/thinkware/sundo/inavi3d/UIManager;

.field static m_LaneTurnModeLayout:Landroid/widget/LinearLayout;

.field private static m_last_ihr_path:Ljava/lang/String;

.field static m_nLeftRightPreRate:F

.field private static m_nTrafficLevel:I

.field static m_nUpDownPreRate:F

.field public static mbTestNewEscapeReroute:Z

.field private static mbUserClickShowDRLayout:Z

.field private static nfguide:Lcom/thinkware/sundo/inavi3d/TUNNEL_SUCCEED_GUIDE;

.field static obd2ViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/OBD2ViewAR;

.field static progressBar:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TrafficProgressBar;

.field static progressBarAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TrafficProgressBar;

.field static progressBarLayout:Landroid/widget/RelativeLayout;

.field static progressBarLayoutAR:Landroid/widget/RelativeLayout;

.field static safePassedView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZonePassedView;

.field static safePassedView2:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZonePassedView;

.field static safePassedView3:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZonePassedView;

.field static safePassedView4:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZonePassedView;

.field static safeZoneDistanceViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneDistanceViewAR;

.field static safeZoneLayout:Landroid/widget/RelativeLayout;

.field static safeZoneLayout2:Landroid/widget/RelativeLayout;

.field static safeZoneLayout3:Landroid/widget/RelativeLayout;

.field static safeZoneLayout4:Landroid/widget/RelativeLayout;

.field static safeZoneLimitSpeedViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneLimitSpeedViewAR;

.field static safeZoneMiniViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneMiniViewAR;

.field static safeZoneTypeViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneTypeViewAR;

.field static safeZoneView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;

.field static safeZoneView2:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;

.field static safeZoneView3:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;

.field static safeZoneView4:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;

.field static safeZoneViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneViewAR;

.field static sectionView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;

.field static sectionView2:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;

.field static sectionView3:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;

.field static sectionView4:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;

.field static speedview:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SpeedView;

.field static speedview2:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SpeedView;

.field static speedview3:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SpeedView;

.field static speedview4:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SpeedView;

.field static speedviewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SpeedViewAR;

.field private static tbtguide:Lcom/thinkware/sundo/remoteTBT/TBTGuide;

.field private static timer:Ljava/util/Timer;

.field static turnAreaView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;

.field static turnAreaView2:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;

.field static turnAreaView3:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;

.field static turnAreaView4:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;

.field static turnAreaViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaViewAR;

.field static ulogEstData:Lcom/thinkware/sundo/inavi3d/ULogEstimateData;

.field static ulogLocData:Lcom/thinkware/sundo/inavi3d/ULogLocationData;

.field private static viaStatus:Z


# instance fields
.field public bMapPopup:Z

.field public force_exit:Z


# direct methods
.method static constructor <clinit>()V
    .locals 9

    .prologue
    const/4 v8, 0x1

    const/4 v4, -0x1

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v5, 0x0

    .line 96
    sput-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    .line 99
    const-string v3, "inavi3d_java"

    sput-object v3, Lcom/thinkware/sundo/inavi3d/Inavi;->TAG:Ljava/lang/String;

    .line 101
    new-instance v3, Lcom/thinkware/sundo/remoteTBT/TBTGuide;

    invoke-direct {v3}, Lcom/thinkware/sundo/remoteTBT/TBTGuide;-><init>()V

    sput-object v3, Lcom/thinkware/sundo/inavi3d/Inavi;->tbtguide:Lcom/thinkware/sundo/remoteTBT/TBTGuide;

    .line 102
    new-instance v3, Lcom/thinkware/sundo/remoteHUD/HUDGuide;

    invoke-direct {v3}, Lcom/thinkware/sundo/remoteHUD/HUDGuide;-><init>()V

    sput-object v3, Lcom/thinkware/sundo/inavi3d/Inavi;->hudguide:Lcom/thinkware/sundo/remoteHUD/HUDGuide;

    .line 103
    const/16 v3, 0x2713

    sput v3, Lcom/thinkware/sundo/inavi3d/Inavi;->MULTI_BUTTONDOWN:I

    .line 104
    const/16 v3, 0x2714

    sput v3, Lcom/thinkware/sundo/inavi3d/Inavi;->MULTI_BUTTONMOVE:I

    .line 105
    const/16 v3, 0x2715

    sput v3, Lcom/thinkware/sundo/inavi3d/Inavi;->MULTI_BUTTONUP:I

    .line 116
    sput-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->mContext:Landroid/content/Context;

    .line 118
    sput-boolean v6, Lcom/thinkware/sundo/inavi3d/Inavi;->viaStatus:Z

    .line 120
    sput-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->mMMCInfo:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    .line 121
    sput-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->mGPSInfo:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    .line 122
    sput-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->mSATInfo:Lcom/tw/mapmatch/remote/mapmatch/SATInfo;

    .line 124
    sput v4, Lcom/thinkware/sundo/inavi3d/Inavi;->mGSensor_Action:I

    .line 125
    sput v4, Lcom/thinkware/sundo/inavi3d/Inavi;->mGSensor_Error:I

    .line 126
    sput v4, Lcom/thinkware/sundo/inavi3d/Inavi;->mGSensor_Sensibility:I

    .line 127
    sput v4, Lcom/thinkware/sundo/inavi3d/Inavi;->mGSensor_Use:I

    .line 129
    sput v4, Lcom/thinkware/sundo/inavi3d/Inavi;->mLogLiveLogging:I

    .line 130
    sput v4, Lcom/thinkware/sundo/inavi3d/Inavi;->mLogCountDown:I

    .line 132
    sput-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->mUIManager:Lcom/thinkware/sundo/inavi3d/UIManager;

    .line 136
    sput-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->currentOnLayOutNormal:Landroid/widget/RelativeLayout;

    .line 137
    sput-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->currentOnLayOutAR:Landroid/widget/RelativeLayout;

    .line 138
    sput-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->courseRightViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/DriveCourseCurrentViewAR;

    .line 139
    sput-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->courseViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/DriveCourseViewAR;

    .line 140
    sput-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->speedviewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SpeedViewAR;

    .line 142
    sput-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->turnAreaViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaViewAR;

    .line 145
    sput-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->hightwayTurnAreaViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/HighwayTurnAreaViewAR;

    .line 150
    sput-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->driveCourseViewRouteCancelButtonAR:Landroid/widget/Button;

    .line 152
    sput-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->driveLineViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/LaneInfoViewAR;

    .line 155
    sput-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneViewAR;

    .line 156
    sput-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneMiniViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneMiniViewAR;

    .line 163
    sput-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->progressBarLayoutAR:Landroid/widget/RelativeLayout;

    .line 164
    sput-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->progressBarAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TrafficProgressBar;

    .line 167
    sput-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneTypeViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneTypeViewAR;

    .line 168
    sput-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneLimitSpeedViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneLimitSpeedViewAR;

    .line 169
    sput-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneDistanceViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneDistanceViewAR;

    .line 171
    sput-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->obd2ViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/OBD2ViewAR;

    .line 173
    sput-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->cswsViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/CSWSViewAR;

    .line 179
    sput-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->speedview:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SpeedView;

    .line 193
    sput-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->progressBarLayout:Landroid/widget/RelativeLayout;

    .line 194
    sput-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->progressBar:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TrafficProgressBar;

    .line 223
    sput-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->mDRDataLayout:Landroid/widget/RelativeLayout;

    .line 224
    sput-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->mDRUpDownRotationView:Lcom/thinkware/sundo/inavi3d/DR/UpDownRotationView;

    .line 225
    sput-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->mDRUpDownRotationView2:Landroid/widget/ImageView;

    .line 226
    sput-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->mDRLeftRightRotationView:Lcom/thinkware/sundo/inavi3d/DR/LeftRightRotationView;

    .line 227
    sput-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->mDRLeftRightRotationView2:Landroid/widget/ImageView;

    .line 228
    sput-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->mAtmosphereGraph:Lcom/thinkware/sundo/inavi3d/DR/AtmosphereGraph;

    .line 229
    sput-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->mDRIndicator:Landroid/view/View;

    .line 230
    sput-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->mDRIcon:Landroid/view/View;

    .line 237
    new-instance v3, Lcom/thinkware/sundo/inavi3d/Struct/DualSearchInfo;

    invoke-direct {v3}, Lcom/thinkware/sundo/inavi3d/Struct/DualSearchInfo;-><init>()V

    sput-object v3, Lcom/thinkware/sundo/inavi3d/Inavi;->Dualsearch:Lcom/thinkware/sundo/inavi3d/Struct/DualSearchInfo;

    .line 243
    new-instance v3, Lcom/thinkware/sundo/inavi3d/TUNNEL_SUCCEED_GUIDE;

    invoke-direct {v3}, Lcom/thinkware/sundo/inavi3d/TUNNEL_SUCCEED_GUIDE;-><init>()V

    sput-object v3, Lcom/thinkware/sundo/inavi3d/Inavi;->nfguide:Lcom/thinkware/sundo/inavi3d/TUNNEL_SUCCEED_GUIDE;

    .line 249
    new-instance v3, Lcom/thinkware/sundo/inavi3d/ROUTE_TABLE_RENEW_INFO;

    invoke-direct {v3}, Lcom/thinkware/sundo/inavi3d/ROUTE_TABLE_RENEW_INFO;-><init>()V

    sput-object v3, Lcom/thinkware/sundo/inavi3d/Inavi;->TrafficRouteTableInfo:Lcom/thinkware/sundo/inavi3d/ROUTE_TABLE_RENEW_INFO;

    .line 254
    sput-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->m_LaneTurnModeLayout:Landroid/widget/LinearLayout;

    .line 256
    sput-boolean v6, Lcom/thinkware/sundo/inavi3d/Inavi;->bUISetting:Z

    .line 260
    sput v7, Lcom/thinkware/sundo/inavi3d/Inavi;->mCarAngleDir:F

    .line 261
    sput v7, Lcom/thinkware/sundo/inavi3d/Inavi;->mCarAngleVrt:F

    .line 262
    sput v7, Lcom/thinkware/sundo/inavi3d/Inavi;->mCarPosX:F

    .line 263
    sput v7, Lcom/thinkware/sundo/inavi3d/Inavi;->mCarPosY:F

    .line 264
    sput v7, Lcom/thinkware/sundo/inavi3d/Inavi;->mCarPosZ:F

    .line 265
    sput v6, Lcom/thinkware/sundo/inavi3d/Inavi;->mCarSpeed:I

    .line 267
    sput v6, Lcom/thinkware/sundo/inavi3d/Inavi;->mRoadAttribType:I

    .line 268
    sput v6, Lcom/thinkware/sundo/inavi3d/Inavi;->mRoadAttribSpec:I

    .line 269
    sput v6, Lcom/thinkware/sundo/inavi3d/Inavi;->mRoadAttribNumLane:I

    .line 270
    sput v6, Lcom/thinkware/sundo/inavi3d/Inavi;->mRoadAttribTollGate:I

    .line 271
    sput v6, Lcom/thinkware/sundo/inavi3d/Inavi;->mRoadAttribRotary:I

    .line 273
    sput v6, Lcom/thinkware/sundo/inavi3d/Inavi;->mSafeGuideKind:I

    .line 274
    sput v6, Lcom/thinkware/sundo/inavi3d/Inavi;->mSafeGuidePosrX:I

    .line 275
    sput v6, Lcom/thinkware/sundo/inavi3d/Inavi;->mSafeGuidePosrY:I

    .line 277
    sput v6, Lcom/thinkware/sundo/inavi3d/Inavi;->mSafeCameraKind:I

    .line 278
    sput v6, Lcom/thinkware/sundo/inavi3d/Inavi;->mSafeCameraPosrX:I

    .line 279
    sput v6, Lcom/thinkware/sundo/inavi3d/Inavi;->mSafeCameraPosrY:I

    .line 280
    sput v6, Lcom/thinkware/sundo/inavi3d/Inavi;->mSafeCameraAngle:I

    .line 281
    sput v6, Lcom/thinkware/sundo/inavi3d/Inavi;->mSafeCameraDist:I

    .line 282
    sput v6, Lcom/thinkware/sundo/inavi3d/Inavi;->mSafeCameraLimit:I

    .line 284
    sput v6, Lcom/thinkware/sundo/inavi3d/Inavi;->mTurnPointX:I

    .line 285
    sput v6, Lcom/thinkware/sundo/inavi3d/Inavi;->mTurnPointY:I

    .line 286
    sput v6, Lcom/thinkware/sundo/inavi3d/Inavi;->mTurnPointKind:I

    .line 287
    sput v6, Lcom/thinkware/sundo/inavi3d/Inavi;->mTurnPointDist:I

    .line 288
    sput v6, Lcom/thinkware/sundo/inavi3d/Inavi;->mTurnPointPassedNumLane:I

    .line 291
    sput v6, Lcom/thinkware/sundo/inavi3d/Inavi;->mInermediate_kind:I

    .line 292
    sput v6, Lcom/thinkware/sundo/inavi3d/Inavi;->mInermediate_dist:I

    .line 293
    sput v8, Lcom/thinkware/sundo/inavi3d/Inavi;->mSafecamera_leader:I

    .line 295
    sput-boolean v8, Lcom/thinkware/sundo/inavi3d/Inavi;->mSafeZoneAvr:Z

    .line 299
    new-instance v3, Lcom/thinkware/sundo/inavi3d/GPSViewManager;

    invoke-direct {v3}, Lcom/thinkware/sundo/inavi3d/GPSViewManager;-><init>()V

    sput-object v3, Lcom/thinkware/sundo/inavi3d/Inavi;->mGPSViewMgr:Lcom/thinkware/sundo/inavi3d/GPSViewManager;

    .line 301
    sput-boolean v6, Lcom/thinkware/sundo/inavi3d/Inavi;->mIsTunnel:Z

    .line 310
    sput v6, Lcom/thinkware/sundo/inavi3d/Inavi;->m_nTrafficLevel:I

    .line 604
    sput-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->mLoadWebp:Lcom/thinkware/sundo/inavi3d/loadWebp;

    .line 608
    const-string v0, "Inavi3D"

    .line 610
    .local v0, "LIB_NAME":Ljava/lang/String;
    :try_start_0
    const-string v3, "Inavi3D"

    invoke-static {v3}, Ljava/lang/System;->loadLibrary(Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/UnsatisfiedLinkError; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/SecurityException; {:try_start_0 .. :try_end_0} :catch_1

    .line 621
    :goto_0
    :try_start_1
    new-instance v3, Lcom/thinkware/sundo/inavi3d/loadWebp;

    invoke-direct {v3}, Lcom/thinkware/sundo/inavi3d/loadWebp;-><init>()V

    sput-object v3, Lcom/thinkware/sundo/inavi3d/Inavi;->mLoadWebp:Lcom/thinkware/sundo/inavi3d/loadWebp;
    :try_end_1
    .catch Ljava/lang/UnsatisfiedLinkError; {:try_start_1 .. :try_end_1} :catch_2
    .catch Ljava/lang/SecurityException; {:try_start_1 .. :try_end_1} :catch_3

    .line 712
    :goto_1
    sput-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->authDrm:Lcom/thinkware/sundo/inavi3d/AuthDRM;

    .line 992
    new-instance v3, Lcom/thinkware/sundo/inavi3d/ULogEstimateData;

    invoke-direct {v3}, Lcom/thinkware/sundo/inavi3d/ULogEstimateData;-><init>()V

    sput-object v3, Lcom/thinkware/sundo/inavi3d/Inavi;->ulogEstData:Lcom/thinkware/sundo/inavi3d/ULogEstimateData;

    .line 993
    new-instance v3, Lcom/thinkware/sundo/inavi3d/ULogLocationData;

    invoke-direct {v3}, Lcom/thinkware/sundo/inavi3d/ULogLocationData;-><init>()V

    sput-object v3, Lcom/thinkware/sundo/inavi3d/Inavi;->ulogLocData:Lcom/thinkware/sundo/inavi3d/ULogLocationData;

    .line 1116
    sput-boolean v8, Lcom/thinkware/sundo/inavi3d/Inavi;->firstTBTGuide:Z

    .line 2099
    sput v7, Lcom/thinkware/sundo/inavi3d/Inavi;->m_nLeftRightPreRate:F

    .line 2100
    sput-boolean v6, Lcom/thinkware/sundo/inavi3d/Inavi;->isDoingLeftRightAnimation:Z

    .line 2101
    sput v7, Lcom/thinkware/sundo/inavi3d/Inavi;->m_nUpDownPreRate:F

    .line 2102
    sput-boolean v6, Lcom/thinkware/sundo/inavi3d/Inavi;->isDoingUpDownAnimation:Z

    .line 2145
    sput-boolean v6, Lcom/thinkware/sundo/inavi3d/Inavi;->mIsDrSpeed:Z

    .line 2146
    sput-boolean v6, Lcom/thinkware/sundo/inavi3d/Inavi;->mbUserClickShowDRLayout:Z

    .line 2510
    sput-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->m_last_ihr_path:Ljava/lang/String;

    .line 2512
    new-instance v3, Ljava/util/Vector;

    invoke-direct {v3}, Ljava/util/Vector;-><init>()V

    sput-object v3, Lcom/thinkware/sundo/inavi3d/Inavi;->backgroundMsgVec:Ljava/util/Vector;

    .line 2514
    sput-boolean v6, Lcom/thinkware/sundo/inavi3d/Inavi;->existdBackgroundMessage:Z

    .line 3527
    sput-boolean v6, Lcom/thinkware/sundo/inavi3d/Inavi;->mbTestNewEscapeReroute:Z

    return-void

    .line 611
    :catch_0
    move-exception v2

    .line 612
    .local v2, "ule":Ljava/lang/UnsatisfiedLinkError;
    const-string v3, "twfail"

    const-string v4, "missing library so : Inavi3D"

    invoke-static {v3, v4}, Lcom/thinkware/sundo/inavi3d/LOGTW;->e(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_0

    .line 613
    .end local v2    # "ule":Ljava/lang/UnsatisfiedLinkError;
    :catch_1
    move-exception v1

    .line 614
    .local v1, "e":Ljava/lang/SecurityException;
    const-string v3, "twfail"

    const-string v4, "security library so : Inavi3D"

    invoke-static {v3, v4}, Lcom/thinkware/sundo/inavi3d/LOGTW;->e(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_0

    .line 624
    .end local v1    # "e":Ljava/lang/SecurityException;
    :catch_2
    move-exception v2

    .line 625
    .restart local v2    # "ule":Ljava/lang/UnsatisfiedLinkError;
    const-string v3, "twfail"

    const-string v4, "missing webp library so : "

    invoke-static {v3, v4}, Lcom/thinkware/sundo/inavi3d/LOGTW;->e(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_1

    .line 626
    .end local v2    # "ule":Ljava/lang/UnsatisfiedLinkError;
    :catch_3
    move-exception v3

    goto :goto_1
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/os/Handler;)V
    .locals 2
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "MainHandler"    # Landroid/os/Handler;

    .prologue
    const/4 v0, 0x0

    .line 633
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 95
    iput-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/Inavi;->force_exit:Z

    .line 97
    iput-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/Inavi;->bMapPopup:Z

    .line 634
    sput-object p1, Lcom/thinkware/sundo/inavi3d/Inavi;->mContext:Landroid/content/Context;

    .line 635
    sput-object p2, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    .line 636
    sget-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->mGPSViewMgr:Lcom/thinkware/sundo/inavi3d/GPSViewManager;

    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mContext:Landroid/content/Context;

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/inavi3d/GPSViewManager;->setParentContext(Landroid/content/Context;)V

    .line 637
    return-void
.end method

.method public static native AddGoalPointForSoulution(II)V
.end method

.method public static native Applynewsafeguidedatamerge()Z
.end method

.method static CheckAutoMenu()V
    .locals 4

    .prologue
    const/4 v3, 0x0

    .line 2386
    sget-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const v2, 0x24aba

    invoke-static {v1, v2, v3, v3}, Landroid/os/Message;->obtain(Landroid/os/Handler;III)Landroid/os/Message;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    .line 2387
    return-void
.end method

.method public static native CheckLiveRoute()V
.end method

.method public static native CheckMyRouteData()I
.end method

.method public static native CheckMyrouteFileExist()Z
.end method

.method public static native CheckSimpleMapRect(FF)Z
.end method

.method public static native CreateMyRouteData()V
.end method

.method public static native CreateMyRouteDataIndex(II)V
.end method

.method private static DRLeftRightAnimation(FI)V
    .locals 2
    .param p0, "yaw_rate"    # F
    .param p1, "gyro_calibrated"    # I

    .prologue
    .line 2281
    sget-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    new-instance v1, Lcom/thinkware/sundo/inavi3d/Inavi$12;

    invoke-direct {v1, p0, p1}, Lcom/thinkware/sundo/inavi3d/Inavi$12;-><init>(FI)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 2322
    return-void
.end method

.method private static DRUpDownAnimation(FI)V
    .locals 2
    .param p0, "pitch_angle"    # F
    .param p1, "gyro_calibrated"    # I

    .prologue
    .line 2237
    sget-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    new-instance v1, Lcom/thinkware/sundo/inavi3d/Inavi$11;

    invoke-direct {v1, p0, p1}, Lcom/thinkware/sundo/inavi3d/Inavi$11;-><init>(FI)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 2278
    return-void
.end method

.method public static native DeleteMyRouteBitmapAll()V
.end method

.method public static native DeleteMyRouteDataAll()V
.end method

.method public static native DualSearchForCheck()Z
.end method

.method public static EUC2UTF([B)Ljava/lang/String;
    .locals 4
    .param p0, "inBuf"    # [B

    .prologue
    .line 813
    const/4 v1, 0x0

    .line 815
    .local v1, "newString":Ljava/lang/String;
    :try_start_0
    new-instance v2, Ljava/lang/String;

    const-string v3, "EUC-KR"

    invoke-direct {v2, p0, v3}, Ljava/lang/String;-><init>([BLjava/lang/String;)V
    :try_end_0
    .catch Ljava/io/UnsupportedEncodingException; {:try_start_0 .. :try_end_0} :catch_0

    .end local v1    # "newString":Ljava/lang/String;
    .local v2, "newString":Ljava/lang/String;
    move-object v1, v2

    .line 820
    .end local v2    # "newString":Ljava/lang/String;
    .restart local v1    # "newString":Ljava/lang/String;
    :goto_0
    return-object v1

    .line 816
    :catch_0
    move-exception v0

    .line 818
    .local v0, "e":Ljava/io/UnsupportedEncodingException;
    invoke-virtual {v0}, Ljava/io/UnsupportedEncodingException;->printStackTrace()V

    goto :goto_0
.end method

.method public static native EditMyrouteDeleteEeachFile(ILjava/lang/String;)V
.end method

.method public static native EditMyrouteFileDeleteAMPM(I)V
.end method

.method public static native GetAddressVerInfo(I)Ljava/lang/String;
.end method

.method static GetDRMString(I)Ljava/lang/String;
    .locals 1
    .param p0, "i"    # I

    .prologue
    .line 806
    sget-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->authDrm:Lcom/thinkware/sundo/inavi3d/AuthDRM;

    if-eqz v0, :cond_0

    .line 807
    sget-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->authDrm:Lcom/thinkware/sundo/inavi3d/AuthDRM;

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/AuthDRM;->GetSDRM4MMC()Ljava/lang/String;

    move-result-object v0

    .line 809
    :goto_0
    return-object v0

    :cond_0
    const-string v0, "NOT_AUTHORIZED"

    goto :goto_0
.end method

.method public static native GetDestPosition(Lcom/thinkware/sundo/inavi3d/GPSViewManager$DestPos;)V
.end method

.method public static native GetDosrch(I)Ljava/lang/String;
.end method

.method public static native GetGPSImageInfoData([I[I[Z)I
.end method

.method public static GetGPSInfo(I)Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;
    .locals 2
    .param p0, "i"    # I

    .prologue
    .line 2350
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    if-nez v1, :cond_0

    .line 2351
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mGPSInfo:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    .line 2359
    :goto_0
    return-object v1

    .line 2354
    :cond_0
    :try_start_0
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    invoke-interface {v1}, Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;->getGPSInfo()Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    move-result-object v1

    sput-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mGPSInfo:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    .line 2359
    :goto_1
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mGPSInfo:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    goto :goto_0

    .line 2355
    :catch_0
    move-exception v0

    .line 2357
    .local v0, "e":Landroid/os/RemoteException;
    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    goto :goto_1
.end method

.method public static native GetGPSInfoData(I)Ljava/lang/String;
.end method

.method public static GetLogCountDown()I
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .prologue
    .line 954
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    if-nez v1, :cond_0

    .line 955
    const/4 v1, -0x1

    .line 964
    .local v0, "e":Landroid/os/RemoteException;
    :goto_0
    return v1

    .line 958
    .end local v0    # "e":Landroid/os/RemoteException;
    :cond_0
    :try_start_0
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    invoke-interface {v1}, Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;->getLogCountDown()I

    move-result v1

    sput v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mLogCountDown:I

    .line 959
    const-string v1, "UserLog"

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "MMC getLogCountDown return "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    sget v3, Lcom/thinkware/sundo/inavi3d/Inavi;->mLogCountDown:I

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Lcom/thinkware/sundo/inavi3d/LOGTW;->d(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    .line 964
    .restart local v0    # "e":Landroid/os/RemoteException;
    :goto_1
    sget v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mLogCountDown:I

    goto :goto_0

    .line 960
    .end local v0    # "e":Landroid/os/RemoteException;
    :catch_0
    move-exception v0

    .line 962
    .restart local v0    # "e":Landroid/os/RemoteException;
    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    goto :goto_1
.end method

.method static GetMISENInfo()Lcom/tw/mapmatch/dataset/_MISENData;
    .locals 8

    .prologue
    const/4 v4, 0x0

    .line 2105
    const-string v5, "Hoit"

    const-string v6, "GetMISENInfo"

    invoke-static {v5, v6}, Lcom/thinkware/sundo/inavi3d/LOGTW;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 2108
    :try_start_0
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    if-eqz v5, :cond_4

    .line 2109
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    invoke-interface {v5}, Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;->getMISENData()Lcom/tw/mapmatch/dataset/_MISENData;

    move-result-object v0

    .line 2110
    .local v0, "data":Lcom/tw/mapmatch/dataset/_MISENData;
    if-nez v0, :cond_1

    move-object v0, v4

    .line 2143
    .end local v0    # "data":Lcom/tw/mapmatch/dataset/_MISENData;
    :cond_0
    :goto_0
    return-object v0

    .line 2113
    .restart local v0    # "data":Lcom/tw/mapmatch/dataset/_MISENData;
    :cond_1
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->mDRDataLayout:Landroid/widget/RelativeLayout;

    if-eqz v5, :cond_3

    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->mDRDataLayout:Landroid/widget/RelativeLayout;

    invoke-virtual {v5}, Landroid/widget/RelativeLayout;->getVisibility()I

    move-result v5

    if-nez v5, :cond_3

    .line 2114
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->mDRUpDownRotationView:Lcom/thinkware/sundo/inavi3d/DR/UpDownRotationView;

    if-eqz v5, :cond_3

    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->mDRUpDownRotationView2:Landroid/widget/ImageView;

    if-eqz v5, :cond_3

    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->mDRLeftRightRotationView:Lcom/thinkware/sundo/inavi3d/DR/LeftRightRotationView;

    if-eqz v5, :cond_3

    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->mDRLeftRightRotationView2:Landroid/widget/ImageView;

    if-eqz v5, :cond_3

    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->mAtmosphereGraph:Lcom/thinkware/sundo/inavi3d/DR/AtmosphereGraph;

    if-eqz v5, :cond_3

    .line 2116
    const/4 v3, 0x0

    .line 2117
    .local v3, "nSpeed":I
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->tbtguide:Lcom/thinkware/sundo/remoteTBT/TBTGuide;

    if-eqz v5, :cond_2

    .line 2118
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->tbtguide:Lcom/thinkware/sundo/remoteTBT/TBTGuide;

    iget v3, v5, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->mCurrentSpeed:I

    .line 2120
    :cond_2
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->mAtmosphereGraph:Lcom/thinkware/sundo/inavi3d/DR/AtmosphereGraph;

    iget v6, v0, Lcom/tw/mapmatch/dataset/_MISENData;->pressure:F

    invoke-virtual {v5, v6, v3}, Lcom/thinkware/sundo/inavi3d/DR/AtmosphereGraph;->setData(FI)V

    .line 2121
    iget v5, v0, Lcom/tw/mapmatch/dataset/_MISENData;->pitch_angle:F

    iget-byte v6, v0, Lcom/tw/mapmatch/dataset/_MISENData;->gyro_calibrated:B

    invoke-static {v5, v6}, Lcom/thinkware/sundo/inavi3d/Inavi;->DRUpDownAnimation(FI)V

    .line 2122
    iget v5, v0, Lcom/tw/mapmatch/dataset/_MISENData;->yaw_rate:F

    iget-byte v6, v0, Lcom/tw/mapmatch/dataset/_MISENData;->gyro_calibrated:B

    invoke-static {v5, v6}, Lcom/thinkware/sundo/inavi3d/Inavi;->DRLeftRightAnimation(FI)V

    .line 2130
    .end local v3    # "nSpeed":I
    :cond_3
    const-string v5, "MISENDATA"

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "data.pressure == "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    iget v7, v0, Lcom/tw/mapmatch/dataset/_MISENData;->pressure:F

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v5, v6}, Lcom/thinkware/sundo/inavi3d/LOGTW;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 2132
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    move-result-object v5

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getMISENShowFlag()Z

    move-result v5

    const/4 v6, 0x1

    if-ne v5, v6, :cond_0

    .line 2133
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    move-result-object v5

    sget-object v6, Lcom/thinkware/sundo/inavi3d/Inavi;->mContext:Landroid/content/Context;

    invoke-virtual {v5, v6}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getMISENLogView(Landroid/content/Context;)Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$MISENLogView;

    move-result-object v2

    .line 2134
    .local v2, "misenLogView":Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$MISENLogView;
    invoke-virtual {v2, v0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$MISENLogView;->SetData(Lcom/tw/mapmatch/dataset/_MISENData;)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    .line 2138
    .end local v2    # "misenLogView":Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager$MISENLogView;
    :catch_0
    move-exception v1

    .line 2140
    .local v1, "e1":Landroid/os/RemoteException;
    invoke-virtual {v1}, Landroid/os/RemoteException;->printStackTrace()V

    :cond_4
    move-object v0, v4

    .line 2143
    goto :goto_0
.end method

.method static GetMMCInfo(I)Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;
    .locals 3
    .param p0, "i"    # I

    .prologue
    .line 2334
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    if-nez v1, :cond_0

    .line 2335
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mMMCInfo:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    .line 2345
    :goto_0
    return-object v1

    .line 2338
    :cond_0
    :try_start_0
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    invoke-interface {v1}, Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;->getMMCInfo()Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    move-result-object v1

    sput-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mMMCInfo:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    .line 2339
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mMMCInfo:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    sget-object v2, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    invoke-interface {v2}, Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;->SimulationGetPos()I

    move-result v2

    iput v2, v1, Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;->nSimulation_pos:I
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    .line 2345
    :goto_1
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mMMCInfo:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    goto :goto_0

    .line 2341
    :catch_0
    move-exception v0

    .line 2343
    .local v0, "e":Landroid/os/RemoteException;
    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    goto :goto_1
.end method

.method public static native GetMaxAeroImageLevel()I
.end method

.method public static native GetMyRouteLinkSetByFileName(ILjava/lang/String;)I
.end method

.method public static native GetNFGuideData(Lcom/thinkware/sundo/inavi3d/TUNNEL_SUCCEED_GUIDE;)V
.end method

.method public static native GetNRFCode(I)I
.end method

.method public static native GetOilOnRouteCount()I
.end method

.method public static native GetPreReRoutePassDist()I
.end method

.method public static native GetProgramVerInfo(I)Ljava/lang/String;
.end method

.method public static native GetRouteRemainDist()I
.end method

.method public static native GetRouteTotalDist()I
.end method

.method static GetSATInfo(I)Lcom/tw/mapmatch/remote/mapmatch/SATInfo;
    .locals 2
    .param p0, "i"    # I

    .prologue
    .line 2364
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    if-nez v1, :cond_0

    .line 2365
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mSATInfo:Lcom/tw/mapmatch/remote/mapmatch/SATInfo;

    .line 2373
    :goto_0
    return-object v1

    .line 2368
    :cond_0
    :try_start_0
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    invoke-interface {v1}, Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;->getSATInfo()Lcom/tw/mapmatch/remote/mapmatch/SATInfo;

    move-result-object v1

    sput-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mSATInfo:Lcom/tw/mapmatch/remote/mapmatch/SATInfo;
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    .line 2373
    :goto_1
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mSATInfo:Lcom/tw/mapmatch/remote/mapmatch/SATInfo;

    goto :goto_0

    .line 2369
    :catch_0
    move-exception v0

    .line 2371
    .local v0, "e":Landroid/os/RemoteException;
    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    goto :goto_1
.end method

.method public static GetSensorActionStatus(I)I
    .locals 2
    .param p0, "i"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .prologue
    .line 844
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    if-nez v1, :cond_0

    .line 845
    sget v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mGSensor_Action:I

    .line 853
    :goto_0
    return v1

    .line 848
    :cond_0
    :try_start_0
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    invoke-interface {v1}, Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;->getSensorActionStatus()I

    move-result v1

    sput v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mGSensor_Action:I
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    .line 853
    :goto_1
    sget v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mGSensor_Action:I

    goto :goto_0

    .line 849
    :catch_0
    move-exception v0

    .line 851
    .local v0, "e":Landroid/os/RemoteException;
    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    goto :goto_1
.end method

.method public static GetSensorErrorStatus(I)I
    .locals 2
    .param p0, "i"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .prologue
    .line 858
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    if-nez v1, :cond_0

    .line 859
    sget v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mGSensor_Error:I

    .line 867
    :goto_0
    return v1

    .line 862
    :cond_0
    :try_start_0
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    invoke-interface {v1}, Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;->getSensorErrorStatus()I

    move-result v1

    sput v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mGSensor_Error:I
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    .line 867
    :goto_1
    sget v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mGSensor_Error:I

    goto :goto_0

    .line 863
    :catch_0
    move-exception v0

    .line 865
    .local v0, "e":Landroid/os/RemoteException;
    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    goto :goto_1
.end method

.method public static GetSensorSensiblityStatus(I)I
    .locals 2
    .param p0, "i"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .prologue
    .line 872
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    if-nez v1, :cond_0

    .line 873
    sget v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mGSensor_Sensibility:I

    .line 882
    :goto_0
    return v1

    .line 876
    :cond_0
    :try_start_0
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    invoke-interface {v1}, Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;->getSensorSensiblityStatus()I

    move-result v1

    sput v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mGSensor_Sensibility:I
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    .line 882
    :goto_1
    sget v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mGSensor_Sensibility:I

    goto :goto_0

    .line 878
    :catch_0
    move-exception v0

    .line 880
    .local v0, "e":Landroid/os/RemoteException;
    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    goto :goto_1
.end method

.method public static GetSensorUseStatus(I)I
    .locals 2
    .param p0, "i"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .prologue
    .line 887
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    if-nez v1, :cond_0

    .line 888
    sget v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mGSensor_Use:I

    .line 896
    :goto_0
    return v1

    .line 891
    :cond_0
    :try_start_0
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    invoke-interface {v1}, Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;->getSensorUseStatus()I

    move-result v1

    sput v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mGSensor_Use:I
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    .line 896
    :goto_1
    sget v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mGSensor_Use:I

    goto :goto_0

    .line 892
    :catch_0
    move-exception v0

    .line 894
    .local v0, "e":Landroid/os/RemoteException;
    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    goto :goto_1
.end method

.method public static native GetStrRegSrchName()Ljava/lang/String;
.end method

.method public static native GetSubFacilityInfo(ILcom/thinkware/sundo/inavi3d/ui/component/CustumDefine$GUISearchPointData;)Z
.end method

.method public static native GetTBTGuide(Lcom/thinkware/sundo/remoteTBT/TBTGuide;)Lcom/thinkware/sundo/remoteTBT/TBTGuide;
.end method

.method public static native GetTblRenewInfo(Lcom/thinkware/sundo/inavi3d/ROUTE_TABLE_RENEW_INFO;)V
.end method

.method public static native GetTestERerouteDis()I
.end method

.method public static native GetTestERerouteDis2()I
.end method

.method public static native GetTestSpeed()I
.end method

.method public static GetTrafficIndcatorLevel()I
    .locals 1

    .prologue
    .line 313
    sget v0, Lcom/thinkware/sundo/inavi3d/Inavi;->m_nTrafficLevel:I

    return v0
.end method

.method public static native GetTrafficJamInfo()Ljava/lang/String;
.end method

.method public static native GetViaPoint(II)D
.end method

.method public static native GetViaStatus()Z
.end method

.method static GetVirtualMMPosition(IIIII)Lcom/tw/mapmatch/dataset/MMPosition;
    .locals 7
    .param p0, "x"    # I
    .param p1, "y"    # I
    .param p2, "nMapID"    # I
    .param p3, "nLinkID"    # I
    .param p4, "direction"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .prologue
    .line 2328
    sget-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    move v1, p0

    move v2, p1

    move v3, p2

    move v4, p3

    move v5, p4

    invoke-interface/range {v0 .. v5}, Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;->getVirtualRoutePos(IIIII)Lcom/tw/mapmatch/dataset/MMPosition;

    move-result-object v6

    .line 2330
    .local v6, "pos":Lcom/tw/mapmatch/dataset/MMPosition;
    return-object v6
.end method

.method public static native IsMyRouteDefaultMapBitmapCreate()Z
.end method

.method public static native IsSimpleMapZoom()Z
.end method

.method public static native MapNameSearch(IIII)Z
.end method

.method public static native MapNameSearchNoButton(II)V
.end method

.method public static native MapNameSearchViewMode(III)Z
.end method

.method public static native MapRoutePoint()V
.end method

.method public static native MapTotalRoute()V
.end method

.method public static native MoveToBirdView(Ljava/lang/String;)V
.end method

.method public static native MyRouteMergeThread()I
.end method

.method public static native NonePopupRunRouteForSolution(II[I[I)V
.end method

.method static OnEventProcess()I
    .locals 1

    .prologue
    .line 840
    const/4 v0, 0x0

    return v0
.end method

.method static OnShowMessage(Ljava/lang/String;II)I
    .locals 2
    .param p0, "msg"    # Ljava/lang/String;
    .param p1, "type"    # I
    .param p2, "duration"    # I

    .prologue
    .line 742
    sget-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->mContext:Landroid/content/Context;

    if-nez v0, :cond_0

    .line 743
    const/4 v0, -0x1

    .line 791
    :goto_0
    return v0

    .line 744
    :cond_0
    sget-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    new-instance v1, Lcom/thinkware/sundo/inavi3d/Inavi$1;

    invoke-direct {v1, p0}, Lcom/thinkware/sundo/inavi3d/Inavi$1;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 791
    const/4 v0, 0x0

    goto :goto_0
.end method

.method public static native ProcessEventSlidingToolBar(III)Z
.end method

.method public static native ProcessEventSlidingToolBarForPoint(IIIIILjava/lang/String;)Z
.end method

.method public static ProcessMessage(IILjava/lang/String;)I
    .locals 26
    .param p0, "message"    # I
    .param p1, "intvalue"    # I
    .param p2, "strvalue"    # Ljava/lang/String;

    .prologue
    .line 2530
    const/16 v17, 0x1

    .line 2532
    .local v17, "ret":I
    sget-object v21, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    if-nez v21, :cond_0

    if-eqz v21, :cond_0

    move/from16 v18, v17

    .line 3150
    .end local v17    # "ret":I
    .local v18, "ret":I
    :goto_0
    return v18

    .line 2535
    .end local v18    # "ret":I
    .restart local v17    # "ret":I
    const/16 v21, 0x138d

    move/from16 v0, p0

    move/from16 v1, v21

    if-ne v0, v1, :cond_0

    .line 2536
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/Inavi;->_CheckData()I

    move-result v17

    move/from16 v18, v17

    .line 2537
    .end local v17    # "ret":I
    .restart local v18    # "ret":I
    goto :goto_0

    .line 2541
    .end local v18    # "ret":I
    .restart local v17    # "ret":I
    :cond_0
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    move-result-object v21

    invoke-virtual/range {v21 .. v21}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->isReadyDPMap()Z

    move-result v21

    if-eqz v21, :cond_1

    sget-boolean v21, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->initComponentCompleted:Z

    if-nez v21, :cond_7

    .line 2542
    :cond_1
    const v21, 0x1d4c2

    move/from16 v0, p0

    move/from16 v1, v21

    if-ne v0, v1, :cond_2

    .line 2543
    const-string v21, "inavi3d_java"

    const-string v22, "MSG_ID_COMMON_BEGIN_MAP_DP"

    invoke-static/range {v21 .. v22}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 2546
    const-wide/16 v22, 0x2

    sput-wide v22, Lcom/thinkware/sundo/inavi3d/DPView;->BackGroundRenderingStep:J

    .line 2548
    new-instance v21, Ljava/lang/Thread;

    new-instance v22, Lcom/thinkware/sundo/inavi3d/Inavi$14;

    invoke-direct/range {v22 .. v22}, Lcom/thinkware/sundo/inavi3d/Inavi$14;-><init>()V

    invoke-direct/range {v21 .. v22}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual/range {v21 .. v21}, Ljava/lang/Thread;->start()V

    .line 2559
    sget-object v21, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    new-instance v22, Lcom/thinkware/sundo/inavi3d/Inavi$15;

    invoke-direct/range {v22 .. v22}, Lcom/thinkware/sundo/inavi3d/Inavi$15;-><init>()V

    invoke-virtual/range {v21 .. v22}, Landroid/os/Handler;->postAtFrontOfQueue(Ljava/lang/Runnable;)Z

    move/from16 v18, v17

    .line 2572
    .end local v17    # "ret":I
    .restart local v18    # "ret":I
    goto :goto_0

    .line 2576
    .end local v18    # "ret":I
    .restart local v17    # "ret":I
    :cond_2
    const v21, 0x1d4c8

    move/from16 v0, p0

    move/from16 v1, v21

    if-ne v0, v1, :cond_3

    .line 2577
    sget-object v21, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v22, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const v23, 0x1d4c9

    invoke-static/range {v22 .. v23}, Landroid/os/Message;->obtain(Landroid/os/Handler;I)Landroid/os/Message;

    move-result-object v22

    invoke-virtual/range {v21 .. v22}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    .line 2578
    sget-object v21, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v22, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const v23, 0x1d4c8

    invoke-static/range {v22 .. v23}, Landroid/os/Message;->obtain(Landroid/os/Handler;I)Landroid/os/Message;

    move-result-object v22

    invoke-virtual/range {v21 .. v22}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    move/from16 v18, v17

    .line 2579
    .end local v17    # "ret":I
    .restart local v18    # "ret":I
    goto :goto_0

    .line 2582
    .end local v18    # "ret":I
    .restart local v17    # "ret":I
    :cond_3
    const/4 v9, 0x0

    .line 2583
    .local v9, "duplicateMsgFlag":Z
    const/4 v11, 0x0

    .local v11, "i":I
    :goto_1
    sget-object v21, Lcom/thinkware/sundo/inavi3d/Inavi;->backgroundMsgVec:Ljava/util/Vector;

    invoke-virtual/range {v21 .. v21}, Ljava/util/Vector;->size()I

    move-result v21

    move/from16 v0, v21

    if-ge v11, v0, :cond_4

    .line 2584
    sget-object v21, Lcom/thinkware/sundo/inavi3d/Inavi;->backgroundMsgVec:Ljava/util/Vector;

    move-object/from16 v0, v21

    invoke-virtual {v0, v11}, Ljava/util/Vector;->get(I)Ljava/lang/Object;

    move-result-object v21

    check-cast v21, Lcom/thinkware/sundo/inavi3d/Struct/MsgStructer;

    move-object/from16 v0, v21

    iget v0, v0, Lcom/thinkware/sundo/inavi3d/Struct/MsgStructer;->mag:I

    move/from16 v21, v0

    move/from16 v0, v21

    move/from16 v1, p0

    if-ne v0, v1, :cond_6

    .line 2585
    sget-object v21, Lcom/thinkware/sundo/inavi3d/Inavi;->backgroundMsgVec:Ljava/util/Vector;

    move-object/from16 v0, v21

    invoke-virtual {v0, v11}, Ljava/util/Vector;->get(I)Ljava/lang/Object;

    move-result-object v21

    check-cast v21, Lcom/thinkware/sundo/inavi3d/Struct/MsgStructer;

    move/from16 v0, p0

    move-object/from16 v1, v21

    iput v0, v1, Lcom/thinkware/sundo/inavi3d/Struct/MsgStructer;->mag:I

    .line 2586
    sget-object v21, Lcom/thinkware/sundo/inavi3d/Inavi;->backgroundMsgVec:Ljava/util/Vector;

    move-object/from16 v0, v21

    invoke-virtual {v0, v11}, Ljava/util/Vector;->get(I)Ljava/lang/Object;

    move-result-object v21

    check-cast v21, Lcom/thinkware/sundo/inavi3d/Struct/MsgStructer;

    move/from16 v0, p1

    move-object/from16 v1, v21

    iput v0, v1, Lcom/thinkware/sundo/inavi3d/Struct/MsgStructer;->intvalue:I

    .line 2587
    sget-object v21, Lcom/thinkware/sundo/inavi3d/Inavi;->backgroundMsgVec:Ljava/util/Vector;

    move-object/from16 v0, v21

    invoke-virtual {v0, v11}, Ljava/util/Vector;->get(I)Ljava/lang/Object;

    move-result-object v21

    check-cast v21, Lcom/thinkware/sundo/inavi3d/Struct/MsgStructer;

    move-object/from16 v0, p2

    move-object/from16 v1, v21

    iput-object v0, v1, Lcom/thinkware/sundo/inavi3d/Struct/MsgStructer;->strvalue:Ljava/lang/String;

    .line 2588
    const/4 v9, 0x1

    .line 2593
    :cond_4
    if-nez v9, :cond_5

    .line 2594
    new-instance v14, Lcom/thinkware/sundo/inavi3d/Struct/MsgStructer;

    move/from16 v0, p0

    move/from16 v1, p1

    move-object/from16 v2, p2

    invoke-direct {v14, v0, v1, v2}, Lcom/thinkware/sundo/inavi3d/Struct/MsgStructer;-><init>(IILjava/lang/String;)V

    .line 2595
    .local v14, "msg":Lcom/thinkware/sundo/inavi3d/Struct/MsgStructer;
    sget-object v21, Lcom/thinkware/sundo/inavi3d/Inavi;->backgroundMsgVec:Ljava/util/Vector;

    move-object/from16 v0, v21

    invoke-virtual {v0, v14}, Ljava/util/Vector;->add(Ljava/lang/Object;)Z

    .line 2596
    const/16 v21, 0x1

    sput-boolean v21, Lcom/thinkware/sundo/inavi3d/Inavi;->existdBackgroundMessage:Z

    .end local v14    # "msg":Lcom/thinkware/sundo/inavi3d/Struct/MsgStructer;
    :cond_5
    move/from16 v18, v17

    .line 2599
    .end local v17    # "ret":I
    .restart local v18    # "ret":I
    goto/16 :goto_0

    .line 2583
    .end local v18    # "ret":I
    .restart local v17    # "ret":I
    :cond_6
    add-int/lit8 v11, v11, 0x1

    goto :goto_1

    .line 2602
    .end local v9    # "duplicateMsgFlag":Z
    .end local v11    # "i":I
    :cond_7
    sget-boolean v21, Lcom/thinkware/sundo/inavi3d/Inavi;->existdBackgroundMessage:Z

    const/16 v22, 0x1

    move/from16 v0, v21

    move/from16 v1, v22

    if-ne v0, v1, :cond_8

    .line 2603
    const/16 v21, 0x0

    sput-boolean v21, Lcom/thinkware/sundo/inavi3d/Inavi;->existdBackgroundMessage:Z

    .line 2604
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/Inavi;->handleBackgroundMessage()V

    .line 2608
    :cond_8
    sparse-switch p0, :sswitch_data_0

    .line 3142
    :try_start_0
    sget-object v21, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v22, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const/16 v23, 0x0

    move-object/from16 v0, v22

    move/from16 v1, p0

    move/from16 v2, p1

    move/from16 v3, v23

    move-object/from16 v4, p2

    invoke-static {v0, v1, v2, v3, v4}, Landroid/os/Message;->obtain(Landroid/os/Handler;IIILjava/lang/Object;)Landroid/os/Message;

    move-result-object v22

    invoke-virtual/range {v21 .. v22}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    :cond_9
    :goto_2
    move/from16 v18, v17

    .line 3150
    .end local v17    # "ret":I
    .restart local v18    # "ret":I
    goto/16 :goto_0

    .line 2611
    .end local v18    # "ret":I
    .restart local v17    # "ret":I
    :sswitch_0
    const/16 v21, 0x1

    move/from16 v0, p1

    move/from16 v1, v21

    if-ne v0, v1, :cond_a

    .line 2612
    sget-object v21, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v22, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const/16 v23, 0x7d9

    invoke-static/range {v22 .. v23}, Landroid/os/Message;->obtain(Landroid/os/Handler;I)Landroid/os/Message;

    move-result-object v22

    invoke-virtual/range {v21 .. v22}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_2

    .line 3145
    :catch_0
    move-exception v10

    .line 3147
    .local v10, "e":Landroid/os/RemoteException;
    invoke-virtual {v10}, Landroid/os/RemoteException;->printStackTrace()V

    goto :goto_2

    .line 2614
    .end local v10    # "e":Landroid/os/RemoteException;
    :cond_a
    :try_start_1
    sget-object v21, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v22, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const/16 v23, 0x7da

    invoke-static/range {v22 .. v23}, Landroid/os/Message;->obtain(Landroid/os/Handler;I)Landroid/os/Message;

    move-result-object v22

    invoke-virtual/range {v21 .. v22}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto :goto_2

    .line 2618
    :sswitch_1
    sget-object v21, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    invoke-interface/range {v21 .. v21}, Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;->ChangeLink()V

    goto :goto_2

    .line 2623
    :sswitch_2
    sget-object v21, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    invoke-interface/range {v21 .. v21}, Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;->InitGPS()V

    goto :goto_2

    .line 2629
    :sswitch_3
    const-string v21, "hslee"

    new-instance v22, Ljava/lang/StringBuilder;

    invoke-direct/range {v22 .. v22}, Ljava/lang/StringBuilder;-><init>()V

    const-string v23, "NAVTIVE_MSG_ROUTESEARCHING : "

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    move-object/from16 v0, v22

    move/from16 v1, p1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v22

    const-string v23, " path : "

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    move-object/from16 v0, v22

    move-object/from16 v1, p2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    invoke-virtual/range {v22 .. v22}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v22

    invoke-static/range {v21 .. v22}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 2639
    const-string v21, "cancelroute"

    move-object/from16 v0, p2

    move-object/from16 v1, v21

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v21

    if-eqz v21, :cond_b

    .line 2640
    const/16 v21, 0x0

    sput-object v21, Lcom/thinkware/sundo/inavi3d/Inavi;->m_last_ihr_path:Ljava/lang/String;

    .line 2644
    :goto_3
    sget-object v21, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    move-object/from16 v0, v21

    move-object/from16 v1, p2

    invoke-interface {v0, v1}, Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;->setRouteTbl(Ljava/lang/String;)Z

    goto :goto_2

    .line 2642
    :cond_b
    sput-object p2, Lcom/thinkware/sundo/inavi3d/Inavi;->m_last_ihr_path:Ljava/lang/String;

    goto :goto_3

    .line 2649
    :sswitch_4
    if-nez p1, :cond_c

    .line 2651
    sget-object v21, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    const/16 v22, 0x0

    invoke-interface/range {v21 .. v22}, Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;->setCurrent(Z)V

    .line 2652
    sget-object v21, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v22, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const v23, 0x222e2

    move-object/from16 v0, v22

    move/from16 v1, v23

    move-object/from16 v2, p2

    invoke-static {v0, v1, v2}, Landroid/os/Message;->obtain(Landroid/os/Handler;ILjava/lang/Object;)Landroid/os/Message;

    move-result-object v22

    invoke-virtual/range {v21 .. v22}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto/16 :goto_2

    .line 2653
    :cond_c
    const/16 v21, 0x64

    move/from16 v0, p1

    move/from16 v1, v21

    if-eq v0, v1, :cond_d

    const/16 v21, 0xc8

    move/from16 v0, p1

    move/from16 v1, v21

    if-eq v0, v1, :cond_d

    const/16 v21, 0x12c

    move/from16 v0, p1

    move/from16 v1, v21

    if-ne v0, v1, :cond_e

    .line 2655
    :cond_d
    sget-object v21, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    const/16 v22, 0x1

    invoke-interface/range {v21 .. v22}, Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;->setCurrent(Z)V

    .line 2656
    const-string v21, "inavi3d_sleeptime"

    const-string v22, "DeviceState.SLEEP_NORMAL"

    const/16 v23, 0x0

    move/from16 v0, v23

    new-array v0, v0, [Ljava/lang/Object;

    move-object/from16 v23, v0

    invoke-static/range {v22 .. v23}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v22

    invoke-static/range {v21 .. v22}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 2657
    sget-object v21, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v22, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const v23, 0x222e2

    const/16 v24, 0x0

    move-object/from16 v0, v22

    move/from16 v1, v23

    move/from16 v2, p1

    move/from16 v3, v24

    invoke-static {v0, v1, v2, v3}, Landroid/os/Message;->obtain(Landroid/os/Handler;III)Landroid/os/Message;

    move-result-object v22

    invoke-virtual/range {v21 .. v22}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto/16 :goto_2

    .line 2660
    :cond_e
    sget-object v21, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    const/16 v22, 0x1

    invoke-interface/range {v21 .. v22}, Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;->setCurrent(Z)V

    .line 2661
    const-string v21, "inavi3d_sleeptime"

    const-string v22, "DeviceState.SLEEP_NORMAL"

    const/16 v23, 0x0

    move/from16 v0, v23

    new-array v0, v0, [Ljava/lang/Object;

    move-object/from16 v23, v0

    invoke-static/range {v22 .. v23}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v22

    invoke-static/range {v21 .. v22}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 2662
    sget-object v21, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v22, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const v23, 0x222e1

    invoke-static/range {p1 .. p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v24

    invoke-static/range {v22 .. v24}, Landroid/os/Message;->obtain(Landroid/os/Handler;ILjava/lang/Object;)Landroid/os/Message;

    move-result-object v22

    invoke-virtual/range {v21 .. v22}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto/16 :goto_2

    .line 2692
    :sswitch_5
    invoke-static/range {p2 .. p2}, Ljava/lang/Integer;->getInteger(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v13

    .line 2693
    .local v13, "mode":Ljava/lang/Integer;
    if-nez v13, :cond_f

    .line 2694
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/MapPopup/GPSMapPopup;->GetViewMode()I

    move-result v21

    invoke-static/range {v21 .. v21}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v13

    .line 2695
    :cond_f
    sget-object v21, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v22, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const v23, 0x222ed

    invoke-virtual {v13}, Ljava/lang/Integer;->intValue()I

    move-result v24

    move-object/from16 v0, v22

    move/from16 v1, v23

    move/from16 v2, p1

    move/from16 v3, v24

    invoke-static {v0, v1, v2, v3}, Landroid/os/Message;->obtain(Landroid/os/Handler;III)Landroid/os/Message;

    move-result-object v22

    invoke-virtual/range {v21 .. v22}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto/16 :goto_2

    .line 2698
    .end local v13    # "mode":Ljava/lang/Integer;
    :sswitch_6
    sget-object v21, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v22, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const v23, 0x222ee

    const/16 v24, 0x0

    move-object/from16 v0, v22

    move/from16 v1, v23

    move/from16 v2, p1

    move/from16 v3, v24

    invoke-static {v0, v1, v2, v3}, Landroid/os/Message;->obtain(Landroid/os/Handler;III)Landroid/os/Message;

    move-result-object v22

    invoke-virtual/range {v21 .. v22}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto/16 :goto_2

    .line 2701
    :sswitch_7
    const-string v21, "DUAL_ON"

    move-object/from16 v0, p2

    move-object/from16 v1, v21

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v21

    if-eqz v21, :cond_10

    .line 2702
    sget-object v21, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v22, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const v23, 0x222f1

    const/16 v24, 0x1

    move-object/from16 v0, v22

    move/from16 v1, v23

    move/from16 v2, p1

    move/from16 v3, v24

    invoke-static {v0, v1, v2, v3}, Landroid/os/Message;->obtain(Landroid/os/Handler;III)Landroid/os/Message;

    move-result-object v22

    invoke-virtual/range {v21 .. v22}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto/16 :goto_2

    .line 2703
    :cond_10
    const-string v21, "COMPACTAR_ON"

    move-object/from16 v0, p2

    move-object/from16 v1, v21

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v21

    if-eqz v21, :cond_11

    .line 2704
    sget-object v21, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v22, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const v23, 0x222f1

    const/16 v24, 0x9

    move-object/from16 v0, v22

    move/from16 v1, v23

    move/from16 v2, p1

    move/from16 v3, v24

    invoke-static {v0, v1, v2, v3}, Landroid/os/Message;->obtain(Landroid/os/Handler;III)Landroid/os/Message;

    move-result-object v22

    invoke-virtual/range {v21 .. v22}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    .line 2705
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v21

    invoke-virtual/range {v21 .. v21}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->setNandFromARData()V

    goto/16 :goto_2

    .line 2707
    :cond_11
    sget-object v21, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v22, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const v23, 0x222f1

    const/16 v24, 0x0

    move-object/from16 v0, v22

    move/from16 v1, v23

    move/from16 v2, p1

    move/from16 v3, v24

    invoke-static {v0, v1, v2, v3}, Landroid/os/Message;->obtain(Landroid/os/Handler;III)Landroid/os/Message;

    move-result-object v22

    invoke-virtual/range {v21 .. v22}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto/16 :goto_2

    .line 2712
    :sswitch_8
    const-string v21, "normal"

    move-object/from16 v0, p2

    move-object/from16 v1, v21

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v21

    if-eqz v21, :cond_12

    .line 2713
    sget-object v21, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v22, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const v23, 0x22348

    const/16 v24, 0x0

    move-object/from16 v0, v22

    move/from16 v1, v23

    move/from16 v2, v24

    move/from16 v3, p1

    invoke-static {v0, v1, v2, v3}, Landroid/os/Message;->obtain(Landroid/os/Handler;III)Landroid/os/Message;

    move-result-object v22

    invoke-virtual/range {v21 .. v22}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto/16 :goto_2

    .line 2715
    :cond_12
    sget-object v21, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v22, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const v23, 0x22348

    const/16 v24, 0x1

    move-object/from16 v0, v22

    move/from16 v1, v23

    move/from16 v2, v24

    move/from16 v3, p1

    invoke-static {v0, v1, v2, v3}, Landroid/os/Message;->obtain(Landroid/os/Handler;III)Landroid/os/Message;

    move-result-object v22

    invoke-virtual/range {v21 .. v22}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto/16 :goto_2

    .line 2719
    :sswitch_9
    sget-object v21, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v22, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const/16 v23, 0x7dc

    const/16 v24, 0x0

    move-object/from16 v0, v22

    move/from16 v1, v23

    move/from16 v2, p1

    move/from16 v3, v24

    invoke-static {v0, v1, v2, v3}, Landroid/os/Message;->obtain(Landroid/os/Handler;III)Landroid/os/Message;

    move-result-object v22

    invoke-virtual/range {v21 .. v22}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto/16 :goto_2

    .line 2722
    :sswitch_a
    sget-object v21, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v22, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const/16 v23, 0x7db

    const/16 v24, 0x0

    move-object/from16 v0, v22

    move/from16 v1, v23

    move/from16 v2, p1

    move/from16 v3, v24

    invoke-static {v0, v1, v2, v3}, Landroid/os/Message;->obtain(Landroid/os/Handler;III)Landroid/os/Message;

    move-result-object v22

    invoke-virtual/range {v21 .. v22}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto/16 :goto_2

    .line 2725
    :sswitch_b
    const-string v21, "background"

    move-object/from16 v0, p2

    move-object/from16 v1, v21

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v21

    if-nez v21, :cond_14

    .line 2726
    sget-object v21, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v22, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const v23, 0x222ef

    const/16 v24, 0x0

    move-object/from16 v0, v22

    move/from16 v1, v23

    move/from16 v2, p1

    move/from16 v3, v24

    invoke-static {v0, v1, v2, v3}, Landroid/os/Message;->obtain(Landroid/os/Handler;III)Landroid/os/Message;

    move-result-object v22

    invoke-virtual/range {v21 .. v22}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    .line 2727
    sput p1, Lcom/thinkware/sundo/inavi3d/Inavi;->m_nTrafficLevel:I

    .line 2734
    :goto_4
    const/16 v21, -0x1

    move/from16 v0, p1

    move/from16 v1, v21

    if-eq v0, v1, :cond_13

    const/16 v21, 0x63

    move/from16 v0, p1

    move/from16 v1, v21

    if-eq v0, v1, :cond_13

    if-nez p1, :cond_15

    .line 2735
    :cond_13
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    move-result-object v21

    const/16 v22, 0x0

    invoke-virtual/range {v21 .. v22}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->setEnabledTrafficMap(Z)V

    goto/16 :goto_2

    .line 2731
    :cond_14
    sput p1, Lcom/thinkware/sundo/inavi3d/Inavi;->m_nTrafficLevel:I

    goto :goto_4

    .line 2737
    :cond_15
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    move-result-object v21

    const/16 v22, 0x1

    invoke-virtual/range {v21 .. v22}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->setEnabledTrafficMap(Z)V

    goto/16 :goto_2

    .line 2742
    :sswitch_c
    sget-object v21, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v22, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const v23, 0x222f0

    const/16 v24, 0x0

    move-object/from16 v0, v22

    move/from16 v1, v23

    move/from16 v2, p1

    move/from16 v3, v24

    invoke-static {v0, v1, v2, v3}, Landroid/os/Message;->obtain(Landroid/os/Handler;III)Landroid/os/Message;

    move-result-object v22

    invoke-virtual/range {v21 .. v22}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto/16 :goto_2

    .line 2745
    :sswitch_d
    sget-object v21, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v22, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const v23, 0x222f2

    const/16 v24, 0x0

    move-object/from16 v0, v22

    move/from16 v1, v23

    move/from16 v2, p1

    move/from16 v3, v24

    invoke-static {v0, v1, v2, v3}, Landroid/os/Message;->obtain(Landroid/os/Handler;III)Landroid/os/Message;

    move-result-object v22

    invoke-virtual/range {v21 .. v22}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto/16 :goto_2

    .line 2751
    :sswitch_e
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/trafficinfo/TrafficInfo;->getInstance()Lcom/thinkware/sundo/inavi3d/trafficinfo/TrafficInfo;

    move-result-object v12

    .line 2752
    .local v12, "m_TrafficInfo":Lcom/thinkware/sundo/inavi3d/trafficinfo/TrafficInfo;
    invoke-virtual {v12}, Lcom/thinkware/sundo/inavi3d/trafficinfo/TrafficInfo;->_GetExclusiveSawTotalRTMCountOnRoute()I

    move-result v15

    .line 2753
    .local v15, "nCnt":I
    const-string v21, "JHS"

    new-instance v22, Ljava/lang/StringBuilder;

    invoke-direct/range {v22 .. v22}, Ljava/lang/StringBuilder;-><init>()V

    const-string v23, "\uacbd\ub85c\ub0b4 \uc720\uace0 \uac2f\uc218 : "

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    move-object/from16 v0, v22

    invoke-virtual {v0, v15}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v22

    invoke-virtual/range {v22 .. v22}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v22

    invoke-static/range {v21 .. v22}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    goto/16 :goto_2

    .line 2759
    .end local v12    # "m_TrafficInfo":Lcom/thinkware/sundo/inavi3d/trafficinfo/TrafficInfo;
    .end local v15    # "nCnt":I
    :sswitch_f
    if-nez p1, :cond_16

    .line 2760
    sget-object v21, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    const/16 v22, 0x0

    invoke-interface/range {v21 .. v22}, Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;->setWalk(Z)V

    goto/16 :goto_2

    .line 2762
    :cond_16
    sget-object v21, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    const/16 v22, 0x1

    invoke-interface/range {v21 .. v22}, Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;->setWalk(Z)V

    goto/16 :goto_2

    .line 2767
    :sswitch_10
    const-string v21, "SIMULATION_EXIT"

    move-object/from16 v0, v21

    move-object/from16 v1, p2

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v21

    if-eqz v21, :cond_17

    .line 2768
    sget-object v21, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    invoke-interface/range {v21 .. v21}, Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;->SimulationExit()V

    .line 2769
    sget-object v21, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v22, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const v23, 0x249f3

    const/16 v24, 0x0

    move-object/from16 v0, v22

    move/from16 v1, v23

    move/from16 v2, p1

    move/from16 v3, v24

    invoke-static {v0, v1, v2, v3}, Landroid/os/Message;->obtain(Landroid/os/Handler;III)Landroid/os/Message;

    move-result-object v22

    invoke-virtual/range {v21 .. v22}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    .line 2770
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v21

    const/16 v22, 0x0

    invoke-virtual/range {v21 .. v22}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->setSimul(Z)V

    goto/16 :goto_2

    .line 2772
    :cond_17
    const-string v21, "SIMULATION_START"

    move-object/from16 v0, v21

    move-object/from16 v1, p2

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v21

    if-eqz v21, :cond_18

    .line 2773
    sget-object v21, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    invoke-interface/range {v21 .. v21}, Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;->SimulationStart()V

    .line 2774
    sget-object v21, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v22, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const v23, 0x249f1

    const/16 v24, 0x0

    move-object/from16 v0, v22

    move/from16 v1, v23

    move/from16 v2, p1

    move/from16 v3, v24

    invoke-static {v0, v1, v2, v3}, Landroid/os/Message;->obtain(Landroid/os/Handler;III)Landroid/os/Message;

    move-result-object v22

    invoke-virtual/range {v21 .. v22}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto/16 :goto_2

    .line 2776
    :cond_18
    const-string v21, "SIMULATION_PLAY_STOP"

    move-object/from16 v0, v21

    move-object/from16 v1, p2

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v21

    if-eqz v21, :cond_1a

    .line 2777
    if-nez p1, :cond_19

    .line 2778
    sget-object v21, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    move-object/from16 v0, v21

    move/from16 v1, p1

    invoke-interface {v0, v1}, Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;->SimulationChangeSpeed(I)V

    .line 2779
    sget-object v21, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    const/16 v22, 0x1

    invoke-interface/range {v21 .. v22}, Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;->SimulationPause(Z)V

    .line 2780
    sget-object v21, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v22, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const v23, 0x249f9

    const/16 v24, 0x0

    move-object/from16 v0, v22

    move/from16 v1, v23

    move/from16 v2, p1

    move/from16 v3, v24

    invoke-static {v0, v1, v2, v3}, Landroid/os/Message;->obtain(Landroid/os/Handler;III)Landroid/os/Message;

    move-result-object v22

    invoke-virtual/range {v21 .. v22}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto/16 :goto_2

    .line 2783
    :cond_19
    sget-object v21, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    move-object/from16 v0, v21

    move/from16 v1, p1

    invoke-interface {v0, v1}, Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;->SimulationChangeSpeed(I)V

    .line 2784
    sget-object v21, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    const/16 v22, 0x0

    invoke-interface/range {v21 .. v22}, Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;->SimulationPause(Z)V

    .line 2785
    sget-object v21, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v22, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const v23, 0x249f8

    const/16 v24, 0x0

    move-object/from16 v0, v22

    move/from16 v1, v23

    move/from16 v2, p1

    move/from16 v3, v24

    invoke-static {v0, v1, v2, v3}, Landroid/os/Message;->obtain(Landroid/os/Handler;III)Landroid/os/Message;

    move-result-object v22

    invoke-virtual/range {v21 .. v22}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto/16 :goto_2

    .line 2787
    :cond_1a
    const-string v21, "SIMULATION_SPEED"

    move-object/from16 v0, v21

    move-object/from16 v1, p2

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v21

    if-eqz v21, :cond_1b

    .line 2788
    sget-object v21, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    move-object/from16 v0, v21

    move/from16 v1, p1

    invoke-interface {v0, v1}, Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;->SimulationChangeSpeed(I)V

    .line 2789
    sget-object v21, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v22, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const v23, 0x249f6

    const/16 v24, 0x0

    move-object/from16 v0, v22

    move/from16 v1, v23

    move/from16 v2, p1

    move/from16 v3, v24

    invoke-static {v0, v1, v2, v3}, Landroid/os/Message;->obtain(Landroid/os/Handler;III)Landroid/os/Message;

    move-result-object v22

    invoke-virtual/range {v21 .. v22}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto/16 :goto_2

    .line 2792
    :cond_1b
    const-string v21, "SIMULATION_POS"

    move-object/from16 v0, v21

    move-object/from16 v1, p2

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v21

    if-eqz v21, :cond_1c

    .line 2793
    sget-object v21, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    move-object/from16 v0, v21

    move/from16 v1, p1

    invoke-interface {v0, v1}, Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;->SimulationSetPos(I)V

    goto/16 :goto_2

    .line 2795
    :cond_1c
    const-string v21, "SIMULATION_PROGRESS"

    move-object/from16 v0, v21

    move-object/from16 v1, p2

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v21

    if-eqz v21, :cond_9

    .line 2797
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v21

    const v22, 0x7f0a0814

    invoke-virtual/range {v21 .. v22}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->findViewById(I)Landroid/view/View;

    move-result-object v6

    check-cast v6, Landroid/widget/Button;

    .line 2798
    .local v6, "Pause":Landroid/widget/Button;
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v21

    const v22, 0x7f0a08e3

    invoke-virtual/range {v21 .. v22}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->findViewById(I)Landroid/view/View;

    move-result-object v16

    check-cast v16, Lcom/thinkware/sundo/inavi3d/ui/component/simulateprograss;

    .line 2799
    .local v16, "progress":Lcom/thinkware/sundo/inavi3d/ui/component/simulateprograss;
    invoke-virtual/range {v16 .. v16}, Lcom/thinkware/sundo/inavi3d/ui/component/simulateprograss;->getTag()Ljava/lang/Object;

    move-result-object v19

    check-cast v19, Ljava/lang/String;

    .line 2800
    .local v19, "tag":Ljava/lang/String;
    invoke-virtual {v6}, Landroid/widget/Button;->getVisibility()I

    move-result v21

    if-nez v21, :cond_9

    .line 2801
    sget-object v21, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v22, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const v23, 0x249fa

    const/16 v24, 0x0

    move-object/from16 v0, v22

    move/from16 v1, v23

    move/from16 v2, p1

    move/from16 v3, v24

    invoke-static {v0, v1, v2, v3}, Landroid/os/Message;->obtain(Landroid/os/Handler;III)Landroid/os/Message;

    move-result-object v22

    invoke-virtual/range {v21 .. v22}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto/16 :goto_2

    .line 2807
    .end local v6    # "Pause":Landroid/widget/Button;
    .end local v16    # "progress":Lcom/thinkware/sundo/inavi3d/ui/component/simulateprograss;
    .end local v19    # "tag":Ljava/lang/String;
    :sswitch_11
    const-string v21, "hslee"

    const-string v22, "NATIVE_MSG_REROUTE_STATUS "

    invoke-static/range {v21 .. v22}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 2808
    sget-object v21, Lcom/thinkware/sundo/inavi3d/Inavi;->m_last_ihr_path:Ljava/lang/String;

    if-eqz v21, :cond_9

    .line 2809
    sget-object v21, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    sget-object v22, Lcom/thinkware/sundo/inavi3d/Inavi;->m_last_ihr_path:Ljava/lang/String;

    invoke-interface/range {v21 .. v22}, Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;->setRouteTbl(Ljava/lang/String;)Z

    goto/16 :goto_2

    .line 2838
    :sswitch_12
    invoke-virtual/range {p2 .. p2}, Ljava/lang/String;->length()I

    move-result v21

    if-nez v21, :cond_1d

    .line 2839
    new-instance v21, Ljava/lang/StringBuilder;

    invoke-direct/range {v21 .. v21}, Ljava/lang/StringBuilder;-><init>()V

    sget-object v22, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->kStorageRoot:Ljava/lang/String;

    invoke-virtual/range {v21 .. v22}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v21

    const-string v22, "/inavidata/GPSOnly.txt"

    invoke-virtual/range {v21 .. v22}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v21

    invoke-virtual/range {v21 .. v21}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    .line 2842
    :cond_1d
    sget-object v21, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    move-object/from16 v0, v21

    move-object/from16 v1, p2

    invoke-interface {v0, v1}, Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;->LogDrive(Ljava/lang/String;)I

    .line 2846
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/RouteCompareManager;->getInstance()Lcom/thinkware/sundo/inavi3d/RouteCompareManager;

    move-result-object v21

    invoke-virtual/range {v21 .. v21}, Lcom/thinkware/sundo/inavi3d/RouteCompareManager;->setLogDrv()V

    goto/16 :goto_2

    .line 2851
    :sswitch_13
    sget-object v21, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    if-eqz v21, :cond_9

    .line 2854
    if-nez p1, :cond_1e

    .line 2855
    sget-object v21, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    invoke-interface/range {v21 .. v21}, Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;->LoggingStop()I

    goto/16 :goto_2

    .line 2857
    :cond_1e
    sget-object v21, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    new-instance v22, Ljava/lang/StringBuilder;

    invoke-direct/range {v22 .. v22}, Ljava/lang/StringBuilder;-><init>()V

    sget-object v23, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->SD_EXT_STORAGE_PATH:Ljava/lang/String;

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    const-string v23, "/inavi3d/gpslog"

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    invoke-virtual/range {v22 .. v22}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v22

    invoke-interface/range {v21 .. v22}, Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;->LoggingStart(Ljava/lang/String;)I

    goto/16 :goto_2

    .line 2861
    :sswitch_14
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v21

    const/16 v22, 0x1

    invoke-virtual/range {v21 .. v22}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->SetDRSaveMode(Z)V

    goto/16 :goto_2

    .line 2865
    :sswitch_15
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v21

    const/16 v22, 0x0

    invoke-virtual/range {v21 .. v22}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->SetDRSaveMode(Z)V

    goto/16 :goto_2

    .line 2869
    :sswitch_16
    const/16 v21, 0x1

    move/from16 v0, p1

    move/from16 v1, v21

    if-ne v0, v1, :cond_1f

    .line 2870
    sget-object v21, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v22, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const/16 v23, 0x3e9

    const/16 v24, 0x0

    move-object/from16 v0, v22

    move/from16 v1, v23

    move/from16 v2, p1

    move/from16 v3, v24

    move-object/from16 v4, p2

    invoke-static {v0, v1, v2, v3, v4}, Landroid/os/Message;->obtain(Landroid/os/Handler;IIILjava/lang/Object;)Landroid/os/Message;

    move-result-object v22

    invoke-virtual/range {v21 .. v22}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto/16 :goto_2

    .line 2872
    :cond_1f
    const-string v21, "musthide"

    move-object/from16 v0, p2

    move-object/from16 v1, v21

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v21

    const/16 v22, 0x1

    move/from16 v0, v21

    move/from16 v1, v22

    if-ne v0, v1, :cond_20

    .line 2873
    const/16 v21, 0x0

    sput-boolean v21, Lcom/thinkware/sundo/inavi3d/ui/popup/PopupManager;->mRouteSearchWaitCursor:Z

    .line 2875
    :cond_20
    sget-object v21, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v22, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const/16 v23, 0x3ea

    invoke-static/range {v22 .. v23}, Landroid/os/Message;->obtain(Landroid/os/Handler;I)Landroid/os/Message;

    move-result-object v22

    invoke-virtual/range {v21 .. v22}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto/16 :goto_2

    .line 2880
    :sswitch_17
    const/16 v21, 0x1

    move/from16 v0, p1

    move/from16 v1, v21

    if-ne v0, v1, :cond_21

    .line 2881
    sget-object v21, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v22, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const/16 v23, 0x7d2

    invoke-static/range {v22 .. v23}, Landroid/os/Message;->obtain(Landroid/os/Handler;I)Landroid/os/Message;

    move-result-object v22

    invoke-virtual/range {v21 .. v22}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto/16 :goto_2

    .line 2882
    :cond_21
    const/16 v21, 0x2

    move/from16 v0, p1

    move/from16 v1, v21

    if-ne v0, v1, :cond_22

    .line 2883
    sget-object v21, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v22, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const/16 v23, 0x7d3

    invoke-static/range {v22 .. v23}, Landroid/os/Message;->obtain(Landroid/os/Handler;I)Landroid/os/Message;

    move-result-object v22

    invoke-virtual/range {v21 .. v22}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto/16 :goto_2

    .line 2884
    :cond_22
    const/16 v21, 0x3

    move/from16 v0, p1

    move/from16 v1, v21

    if-ne v0, v1, :cond_9

    .line 2885
    sget-object v21, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v22, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const/16 v23, 0x7d4

    invoke-static/range {v22 .. v23}, Landroid/os/Message;->obtain(Landroid/os/Handler;I)Landroid/os/Message;

    move-result-object v22

    invoke-virtual/range {v21 .. v22}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto/16 :goto_2

    .line 2889
    :sswitch_18
    const/16 v21, 0x1

    move/from16 v0, p1

    move/from16 v1, v21

    if-ne v0, v1, :cond_23

    .line 2890
    sget-object v21, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v22, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const/16 v23, 0x7d5

    invoke-static/range {v22 .. v23}, Landroid/os/Message;->obtain(Landroid/os/Handler;I)Landroid/os/Message;

    move-result-object v22

    invoke-virtual/range {v21 .. v22}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto/16 :goto_2

    .line 2892
    :cond_23
    sget-object v21, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v22, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const/16 v23, 0x7d6

    invoke-static/range {v22 .. v23}, Landroid/os/Message;->obtain(Landroid/os/Handler;I)Landroid/os/Message;

    move-result-object v22

    invoke-virtual/range {v21 .. v22}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto/16 :goto_2

    .line 2896
    :sswitch_19
    const/16 v21, 0x1

    move/from16 v0, p1

    move/from16 v1, v21

    if-ne v0, v1, :cond_24

    .line 2897
    sget-object v21, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v22, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const/16 v23, 0x7d0

    invoke-static/range {v22 .. v23}, Landroid/os/Message;->obtain(Landroid/os/Handler;I)Landroid/os/Message;

    move-result-object v22

    invoke-virtual/range {v21 .. v22}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto/16 :goto_2

    .line 2899
    :cond_24
    sget-object v21, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v22, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const/16 v23, 0x7d1

    invoke-static/range {v22 .. v23}, Landroid/os/Message;->obtain(Landroid/os/Handler;I)Landroid/os/Message;

    move-result-object v22

    invoke-virtual/range {v21 .. v22}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto/16 :goto_2

    .line 2904
    :sswitch_1a
    sget-object v21, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v22, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const/16 v23, 0x7d8

    invoke-static/range {v22 .. v23}, Landroid/os/Message;->obtain(Landroid/os/Handler;I)Landroid/os/Message;

    move-result-object v22

    invoke-virtual/range {v21 .. v22}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto/16 :goto_2

    .line 2908
    :sswitch_1b
    sget-object v21, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v22, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const/16 v23, 0x7d8

    invoke-static/range {v22 .. v23}, Landroid/os/Message;->obtain(Landroid/os/Handler;I)Landroid/os/Message;

    move-result-object v22

    invoke-virtual/range {v21 .. v22}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto/16 :goto_2

    .line 2911
    :sswitch_1c
    const v21, 0x1fbd5

    move/from16 v0, v21

    move/from16 v1, p1

    if-eq v0, v1, :cond_25

    const v21, 0x1fbd4

    move/from16 v0, v21

    move/from16 v1, p1

    if-eq v0, v1, :cond_25

    const v21, 0x1fbd1

    move/from16 v0, v21

    move/from16 v1, p1

    if-ne v0, v1, :cond_9

    .line 2912
    :cond_25
    sget-object v21, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v22, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    move-object/from16 v0, v22

    move/from16 v1, p1

    invoke-static {v0, v1}, Landroid/os/Message;->obtain(Landroid/os/Handler;I)Landroid/os/Message;

    move-result-object v22

    invoke-virtual/range {v21 .. v22}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto/16 :goto_2

    .line 2915
    :sswitch_1d
    new-instance v11, Landroid/content/Intent;

    invoke-direct {v11}, Landroid/content/Intent;-><init>()V

    .line 2916
    .local v11, "i":Landroid/content/Intent;
    const-string v21, "android.intent.action.MAIN"

    move-object/from16 v0, v21

    invoke-virtual {v11, v0}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    .line 2917
    const-string v21, "android.intent.category.HOME"

    move-object/from16 v0, v21

    invoke-virtual {v11, v0}, Landroid/content/Intent;->addCategory(Ljava/lang/String;)Landroid/content/Intent;

    .line 2918
    sget-object v21, Lcom/thinkware/sundo/inavi3d/Inavi;->mContext:Landroid/content/Context;

    move-object/from16 v0, v21

    invoke-virtual {v0, v11}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    .line 2919
    const-string v21, "twfail"

    new-instance v22, Ljava/lang/StringBuilder;

    invoke-direct/range {v22 .. v22}, Ljava/lang/StringBuilder;-><init>()V

    const-string v23, "not processed : "

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    move-object/from16 v0, v22

    move/from16 v1, p0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v22

    invoke-virtual/range {v22 .. v22}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v22

    invoke-static/range {v21 .. v22}, Lcom/thinkware/sundo/inavi3d/LOGTW;->d(Ljava/lang/String;Ljava/lang/String;)V

    goto/16 :goto_2

    .line 2923
    .end local v11    # "i":Landroid/content/Intent;
    :sswitch_1e
    const-string v21, "hslee_test"

    const-string v22, "check on server, terms & auth ok - start"

    invoke-static/range {v21 .. v22}, Lcom/thinkware/sundo/inavi3d/LOGTW;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 2924
    const/4 v7, 0x0

    .line 2925
    .local v7, "apiianvi":Lcom/thinkware/sundo/inavi3d/ApiInavi;
    new-instance v7, Lcom/thinkware/sundo/inavi3d/ApiInavi;

    .end local v7    # "apiianvi":Lcom/thinkware/sundo/inavi3d/ApiInavi;
    sget-object v21, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->kStorageRoot:Ljava/lang/String;

    move-object/from16 v0, v21

    invoke-direct {v7, v0}, Lcom/thinkware/sundo/inavi3d/ApiInavi;-><init>(Ljava/lang/String;)V

    .line 2927
    .restart local v7    # "apiianvi":Lcom/thinkware/sundo/inavi3d/ApiInavi;
    invoke-virtual {v7}, Lcom/thinkware/sundo/inavi3d/ApiInavi;->setUser()I

    move-result v17

    .line 2928
    const-string v21, "hslee_test"

    const-string v22, "check on server, terms & auth ok - end"

    invoke-static/range {v21 .. v22}, Lcom/thinkware/sundo/inavi3d/LOGTW;->d(Ljava/lang/String;Ljava/lang/String;)V

    move/from16 v18, v17

    .line 2929
    .end local v17    # "ret":I
    .restart local v18    # "ret":I
    goto/16 :goto_0

    .line 2931
    .end local v7    # "apiianvi":Lcom/thinkware/sundo/inavi3d/ApiInavi;
    .end local v18    # "ret":I
    .restart local v17    # "ret":I
    :sswitch_1f
    sget-object v21, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v22, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const/16 v23, 0x270f

    invoke-static/range {v22 .. v23}, Landroid/os/Message;->obtain(Landroid/os/Handler;I)Landroid/os/Message;

    move-result-object v22

    invoke-virtual/range {v21 .. v22}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto/16 :goto_2

    .line 2934
    :sswitch_20
    const-string v21, "inavirestart"

    const-string v22, "NATIVE_MSG_RESTART"

    invoke-static/range {v21 .. v22}, Lcom/thinkware/sundo/inavi3d/LOGTW;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 2935
    sget-object v21, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v22, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const/16 v23, 0x270e

    invoke-static/range {v22 .. v23}, Landroid/os/Message;->obtain(Landroid/os/Handler;I)Landroid/os/Message;

    move-result-object v22

    move/from16 v0, p1

    int-to-long v0, v0

    move-wide/from16 v24, v0

    move-object/from16 v0, v21

    move-object/from16 v1, v22

    move-wide/from16 v2, v24

    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->sendMessageDelayed(Landroid/os/Message;J)Z

    goto/16 :goto_2

    .line 2938
    :sswitch_21
    sget-object v21, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v22, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const v23, 0x1d4c2

    invoke-static/range {v22 .. v23}, Landroid/os/Message;->obtain(Landroid/os/Handler;I)Landroid/os/Message;

    move-result-object v22

    invoke-virtual/range {v21 .. v22}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto/16 :goto_2

    .line 2942
    :sswitch_22
    sget-object v21, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v22, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const v23, 0x1d4c5

    const/16 v24, 0x0

    move-object/from16 v0, v22

    move/from16 v1, v23

    move/from16 v2, p1

    move/from16 v3, v24

    invoke-static {v0, v1, v2, v3}, Landroid/os/Message;->obtain(Landroid/os/Handler;III)Landroid/os/Message;

    move-result-object v22

    invoke-virtual/range {v21 .. v22}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto/16 :goto_2

    .line 2949
    :sswitch_23
    move/from16 v0, p1

    int-to-float v0, v0

    move/from16 v21, v0

    sput v21, Lcom/thinkware/sundo/inavi3d/Inavi;->mCarAngleDir:F

    goto/16 :goto_2

    .line 2952
    :sswitch_24
    move/from16 v0, p1

    int-to-float v0, v0

    move/from16 v21, v0

    const/high16 v22, 0x42c80000    # 100.0f

    div-float v21, v21, v22

    sput v21, Lcom/thinkware/sundo/inavi3d/Inavi;->mCarAngleVrt:F

    goto/16 :goto_2

    .line 2955
    :sswitch_25
    move/from16 v0, p1

    int-to-float v0, v0

    move/from16 v21, v0

    const/high16 v22, 0x42c80000    # 100.0f

    div-float v21, v21, v22

    sput v21, Lcom/thinkware/sundo/inavi3d/Inavi;->mCarPosX:F

    goto/16 :goto_2

    .line 2958
    :sswitch_26
    move/from16 v0, p1

    int-to-float v0, v0

    move/from16 v21, v0

    const/high16 v22, 0x42c80000    # 100.0f

    div-float v21, v21, v22

    sput v21, Lcom/thinkware/sundo/inavi3d/Inavi;->mCarPosY:F

    goto/16 :goto_2

    .line 2961
    :sswitch_27
    move/from16 v0, p1

    int-to-float v0, v0

    move/from16 v21, v0

    const/high16 v22, 0x42c80000    # 100.0f

    div-float v21, v21, v22

    sput v21, Lcom/thinkware/sundo/inavi3d/Inavi;->mCarPosZ:F

    goto/16 :goto_2

    .line 2964
    :sswitch_28
    sput p1, Lcom/thinkware/sundo/inavi3d/Inavi;->mCarSpeed:I

    goto/16 :goto_2

    .line 2968
    :sswitch_29
    sput p1, Lcom/thinkware/sundo/inavi3d/Inavi;->mRoadAttribType:I

    goto/16 :goto_2

    .line 2971
    :sswitch_2a
    sput p1, Lcom/thinkware/sundo/inavi3d/Inavi;->mRoadAttribSpec:I

    goto/16 :goto_2

    .line 2974
    :sswitch_2b
    sput p1, Lcom/thinkware/sundo/inavi3d/Inavi;->mRoadAttribNumLane:I

    goto/16 :goto_2

    .line 2977
    :sswitch_2c
    sput p1, Lcom/thinkware/sundo/inavi3d/Inavi;->mRoadAttribTollGate:I

    goto/16 :goto_2

    .line 2980
    :sswitch_2d
    sput p1, Lcom/thinkware/sundo/inavi3d/Inavi;->mRoadAttribRotary:I

    goto/16 :goto_2

    .line 2984
    :sswitch_2e
    sput p1, Lcom/thinkware/sundo/inavi3d/Inavi;->mSafeGuideKind:I

    goto/16 :goto_2

    .line 2987
    :sswitch_2f
    sput p1, Lcom/thinkware/sundo/inavi3d/Inavi;->mSafeGuidePosrX:I

    goto/16 :goto_2

    .line 2990
    :sswitch_30
    sput p1, Lcom/thinkware/sundo/inavi3d/Inavi;->mSafeGuidePosrY:I

    goto/16 :goto_2

    .line 2994
    :sswitch_31
    sput p1, Lcom/thinkware/sundo/inavi3d/Inavi;->mSafeCameraKind:I

    goto/16 :goto_2

    .line 2997
    :sswitch_32
    sput p1, Lcom/thinkware/sundo/inavi3d/Inavi;->mSafeCameraPosrX:I

    goto/16 :goto_2

    .line 3000
    :sswitch_33
    sput p1, Lcom/thinkware/sundo/inavi3d/Inavi;->mSafeCameraPosrY:I

    goto/16 :goto_2

    .line 3003
    :sswitch_34
    sput p1, Lcom/thinkware/sundo/inavi3d/Inavi;->mSafeCameraAngle:I

    goto/16 :goto_2

    .line 3006
    :sswitch_35
    sput p1, Lcom/thinkware/sundo/inavi3d/Inavi;->mSafeCameraDist:I

    goto/16 :goto_2

    .line 3009
    :sswitch_36
    sput p1, Lcom/thinkware/sundo/inavi3d/Inavi;->mSafeCameraLimit:I

    goto/16 :goto_2

    .line 3013
    :sswitch_37
    sput p1, Lcom/thinkware/sundo/inavi3d/Inavi;->mTurnPointX:I

    goto/16 :goto_2

    .line 3016
    :sswitch_38
    sput p1, Lcom/thinkware/sundo/inavi3d/Inavi;->mTurnPointY:I

    goto/16 :goto_2

    .line 3019
    :sswitch_39
    sput p1, Lcom/thinkware/sundo/inavi3d/Inavi;->mTurnPointKind:I

    goto/16 :goto_2

    .line 3022
    :sswitch_3a
    sput p1, Lcom/thinkware/sundo/inavi3d/Inavi;->mTurnPointDist:I

    goto/16 :goto_2

    .line 3025
    :sswitch_3b
    sput p1, Lcom/thinkware/sundo/inavi3d/Inavi;->mTurnPointPassedNumLane:I

    goto/16 :goto_2

    .line 3029
    :sswitch_3c
    sget-object v21, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v22, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const v23, 0x2259d

    invoke-static/range {v22 .. v23}, Landroid/os/Message;->obtain(Landroid/os/Handler;I)Landroid/os/Message;

    move-result-object v22

    invoke-virtual/range {v21 .. v22}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto/16 :goto_2

    .line 3034
    :sswitch_3d
    sget-object v21, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v22, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const v23, 0x2628d

    invoke-static/range {v22 .. v23}, Landroid/os/Message;->obtain(Landroid/os/Handler;I)Landroid/os/Message;

    move-result-object v22

    invoke-virtual/range {v21 .. v22}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto/16 :goto_2

    .line 3037
    :sswitch_3e
    sget-object v21, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v22, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const v23, 0x2628e

    invoke-static/range {v22 .. v23}, Landroid/os/Message;->obtain(Landroid/os/Handler;I)Landroid/os/Message;

    move-result-object v22

    invoke-virtual/range {v21 .. v22}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto/16 :goto_2

    .line 3041
    :sswitch_3f
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/Inavi;->getMapCenterX()I

    move-result v21

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/Inavi;->getMapCenterY()I

    move-result v22

    invoke-static/range {v21 .. v22}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/UserDataMgr;->UPSetHomeData(II)Z

    .line 3045
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/RouteCompareManager;->getInstance()Lcom/thinkware/sundo/inavi3d/RouteCompareManager;

    move-result-object v21

    invoke-virtual/range {v21 .. v21}, Lcom/thinkware/sundo/inavi3d/RouteCompareManager;->setMyRouteFileDelete()V

    goto/16 :goto_2

    .line 3049
    :sswitch_40
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/Inavi;->getMapCenterX()I

    move-result v21

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/Inavi;->getMapCenterY()I

    move-result v22

    invoke-static/range {v21 .. v22}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/UserDataMgr;->UPSetFreqData(II)Z

    .line 3053
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/RouteCompareManager;->getInstance()Lcom/thinkware/sundo/inavi3d/RouteCompareManager;

    move-result-object v21

    invoke-virtual/range {v21 .. v21}, Lcom/thinkware/sundo/inavi3d/RouteCompareManager;->setMyRouteFileDelete()V

    goto/16 :goto_2

    .line 3060
    :sswitch_41
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/RouteCompareManager;->getInstance()Lcom/thinkware/sundo/inavi3d/RouteCompareManager;

    move-result-object v21

    const/16 v22, 0x0

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/RouteCompareManager;->getInstance()Lcom/thinkware/sundo/inavi3d/RouteCompareManager;

    move-result-object v23

    const/16 v24, 0x0

    invoke-virtual/range {v23 .. v24}, Lcom/thinkware/sundo/inavi3d/RouteCompareManager;->getIndexColor(I)I

    move-result v23

    const/16 v24, 0x1

    invoke-virtual/range {v21 .. v24}, Lcom/thinkware/sundo/inavi3d/RouteCompareManager;->setReLoadMapImage(IIZ)V

    .line 3061
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/RouteCompareManager;->getInstance()Lcom/thinkware/sundo/inavi3d/RouteCompareManager;

    move-result-object v21

    const/16 v22, 0x0

    move-object/from16 v0, v21

    move/from16 v1, v22

    move/from16 v2, p1

    move-object/from16 v3, p2

    invoke-virtual {v0, v1, v2, v3}, Lcom/thinkware/sundo/inavi3d/RouteCompareManager;->SetUserLogDriviingTime(IILjava/lang/String;)V

    goto/16 :goto_2

    .line 3064
    :sswitch_42
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/RouteCompareManager;->getInstance()Lcom/thinkware/sundo/inavi3d/RouteCompareManager;

    move-result-object v21

    const/16 v22, 0x1

    move-object/from16 v0, v21

    move/from16 v1, v22

    move/from16 v2, p1

    move-object/from16 v3, p2

    invoke-virtual {v0, v1, v2, v3}, Lcom/thinkware/sundo/inavi3d/RouteCompareManager;->SetUserLogDriviingTime(IILjava/lang/String;)V

    goto/16 :goto_2

    .line 3067
    :sswitch_43
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/RouteCompareManager;->getInstance()Lcom/thinkware/sundo/inavi3d/RouteCompareManager;

    move-result-object v21

    const/16 v22, 0x2

    move-object/from16 v0, v21

    move/from16 v1, v22

    move/from16 v2, p1

    move-object/from16 v3, p2

    invoke-virtual {v0, v1, v2, v3}, Lcom/thinkware/sundo/inavi3d/RouteCompareManager;->SetUserLogDriviingTime(IILjava/lang/String;)V

    goto/16 :goto_2

    .line 3070
    :sswitch_44
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/RouteCompareManager;->getInstance()Lcom/thinkware/sundo/inavi3d/RouteCompareManager;

    move-result-object v21

    const/16 v22, 0x3

    move-object/from16 v0, v21

    move/from16 v1, v22

    move/from16 v2, p1

    move-object/from16 v3, p2

    invoke-virtual {v0, v1, v2, v3}, Lcom/thinkware/sundo/inavi3d/RouteCompareManager;->SetUserLogDriviingTime(IILjava/lang/String;)V

    goto/16 :goto_2

    .line 3076
    :sswitch_45
    const-string v21, "JUNE"

    new-instance v22, Ljava/lang/StringBuilder;

    invoke-direct/range {v22 .. v22}, Ljava/lang/StringBuilder;-><init>()V

    const-string v23, "NATIVE_UIMESSAGE_USERLOGDRIVING_TITLE : strvalue :: "

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    move-object/from16 v0, v22

    move-object/from16 v1, p2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    invoke-virtual/range {v22 .. v22}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v22

    invoke-static/range {v21 .. v22}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 3077
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/RouteCompareManager;->getInstance()Lcom/thinkware/sundo/inavi3d/RouteCompareManager;

    move-result-object v21

    move-object/from16 v0, v21

    move-object/from16 v1, p2

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/inavi3d/RouteCompareManager;->setRouteCompareUserOptionName(Ljava/lang/String;)V

    goto/16 :goto_2

    .line 3081
    :sswitch_46
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/RouteCompareManager;->getInstance()Lcom/thinkware/sundo/inavi3d/RouteCompareManager;

    move-result-object v21

    move-object/from16 v0, v21

    move-object/from16 v1, p2

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/inavi3d/RouteCompareManager;->setMyRouteEditMainRoad(Ljava/lang/String;)V

    goto/16 :goto_2

    .line 3085
    :sswitch_47
    const-string v21, "JUNE"

    new-instance v22, Ljava/lang/StringBuilder;

    invoke-direct/range {v22 .. v22}, Ljava/lang/StringBuilder;-><init>()V

    const-string v23, "NATIVE_MSG_MY_ROUTE_MAP_IMAGE_PATH :: strvalue : "

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    move-object/from16 v0, v22

    move-object/from16 v1, p2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    invoke-virtual/range {v22 .. v22}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v22

    invoke-static/range {v21 .. v22}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 3086
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v21

    move-object/from16 v0, v21

    move-object/from16 v1, p2

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->SetRouteCmpImagPath(Ljava/lang/String;)V

    goto/16 :goto_2

    .line 3089
    :sswitch_48
    const-string v21, "JUNE"

    new-instance v22, Ljava/lang/StringBuilder;

    invoke-direct/range {v22 .. v22}, Ljava/lang/StringBuilder;-><init>()V

    const-string v23, "NATIVE_MSG_MY_ROUTE_MAP_ERROR :: intvalue : "

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    move-object/from16 v0, v22

    move/from16 v1, p1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v22

    invoke-virtual/range {v22 .. v22}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v22

    invoke-static/range {v21 .. v22}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 3090
    if-lez p1, :cond_26

    .line 3091
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/RouteCompareManager;->getInstance()Lcom/thinkware/sundo/inavi3d/RouteCompareManager;

    move-result-object v21

    invoke-virtual/range {v21 .. v21}, Lcom/thinkware/sundo/inavi3d/RouteCompareManager;->setCompareRoutePopupCheckRestart()V

    goto/16 :goto_2

    .line 3093
    :cond_26
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/RouteCompareManager;->getInstance()Lcom/thinkware/sundo/inavi3d/RouteCompareManager;

    move-result-object v21

    invoke-virtual/range {v21 .. v21}, Lcom/thinkware/sundo/inavi3d/RouteCompareManager;->setCompareRoutePopupCheckEnd()V

    .line 3094
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/RouteCompareManager;->getInstance()Lcom/thinkware/sundo/inavi3d/RouteCompareManager;

    move-result-object v21

    invoke-virtual/range {v21 .. v21}, Lcom/thinkware/sundo/inavi3d/RouteCompareManager;->setErrorPopupClose()V

    goto/16 :goto_2

    .line 3099
    :sswitch_49
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/RouteCompareManager;->getInstance()Lcom/thinkware/sundo/inavi3d/RouteCompareManager;

    move-result-object v21

    invoke-virtual/range {v21 .. v21}, Lcom/thinkware/sundo/inavi3d/RouteCompareManager;->getMyRouteEditType()I

    move-result v20

    .line 3100
    .local v20, "type":I
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/RouteCompareManager;->getInstance()Lcom/thinkware/sundo/inavi3d/RouteCompareManager;

    move-result-object v21

    move-object/from16 v0, v21

    move/from16 v1, v20

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/inavi3d/RouteCompareManager;->setMyRouteEditError(I)V

    goto/16 :goto_2

    .line 3104
    .end local v20    # "type":I
    :sswitch_4a
    const-string v21, "JUNE"

    new-instance v22, Ljava/lang/StringBuilder;

    invoke-direct/range {v22 .. v22}, Ljava/lang/StringBuilder;-><init>()V

    const-string v23, "NATIVE_MSG_MY_ROUTE_MAP_POPUP_SHOW :: intvalue : "

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    move-object/from16 v0, v22

    move/from16 v1, p1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v22

    invoke-virtual/range {v22 .. v22}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v22

    invoke-static/range {v21 .. v22}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 3105
    const-string v21, "JUNE"

    new-instance v22, Ljava/lang/StringBuilder;

    invoke-direct/range {v22 .. v22}, Ljava/lang/StringBuilder;-><init>()V

    const-string v23, "NATIVE_MSG_MY_ROUTE_MAP_POPUP_SHOW :: strvalue : "

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    move-object/from16 v0, v22

    move-object/from16 v1, p2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    invoke-virtual/range {v22 .. v22}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v22

    invoke-static/range {v21 .. v22}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 3106
    invoke-static/range {p2 .. p2}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v8

    .line 3107
    .local v8, "dataCount":I
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/RouteCompareManager;->getInstance()Lcom/thinkware/sundo/inavi3d/RouteCompareManager;

    move-result-object v21

    move-object/from16 v0, v21

    move/from16 v1, p1

    invoke-virtual {v0, v1, v8}, Lcom/thinkware/sundo/inavi3d/RouteCompareManager;->showMyRoutePopup(II)V

    goto/16 :goto_2

    .line 3111
    .end local v8    # "dataCount":I
    :sswitch_4b
    const-string v21, "JUNE"

    new-instance v22, Ljava/lang/StringBuilder;

    invoke-direct/range {v22 .. v22}, Ljava/lang/StringBuilder;-><init>()V

    const-string v23, "NATIVE_MSG_MY_ROUTE_MAP_MANUAL :: intvalue : "

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    move-object/from16 v0, v22

    move/from16 v1, p1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v22

    invoke-virtual/range {v22 .. v22}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v22

    invoke-static/range {v21 .. v22}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 3112
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/RouteCompareManager;->getInstance()Lcom/thinkware/sundo/inavi3d/RouteCompareManager;

    move-result-object v21

    move-object/from16 v0, v21

    move/from16 v1, p1

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/inavi3d/RouteCompareManager;->startManualMyRoute(I)V

    goto/16 :goto_2

    .line 3116
    :sswitch_4c
    const-string v21, "JUNE"

    new-instance v22, Ljava/lang/StringBuilder;

    invoke-direct/range {v22 .. v22}, Ljava/lang/StringBuilder;-><init>()V

    const-string v23, "NATIVE_MSG_MY_ROUTE_MAP_SAVE_INFO :: intvalue : "

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    move-object/from16 v0, v22

    move/from16 v1, p1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v22

    invoke-virtual/range {v22 .. v22}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v22

    invoke-static/range {v21 .. v22}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 3117
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/RouteCompareManager;->getInstance()Lcom/thinkware/sundo/inavi3d/RouteCompareManager;

    move-result-object v21

    move-object/from16 v0, v21

    move/from16 v1, p1

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/inavi3d/RouteCompareManager;->setMyRouteSaveSelectedIndex(I)V

    goto/16 :goto_2

    .line 3124
    :sswitch_4d
    const-string v21, "wooks"

    new-instance v22, Ljava/lang/StringBuilder;

    invoke-direct/range {v22 .. v22}, Ljava/lang/StringBuilder;-><init>()V

    const-string v23, "NATIVE_MSG_ROUTE_RESULT_ERROR_TRUCK :: intvalue : "

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    move-object/from16 v0, v22

    move/from16 v1, p1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v22

    invoke-virtual/range {v22 .. v22}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v22

    invoke-static/range {v21 .. v22}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 3127
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v21

    move-object/from16 v0, v21

    move/from16 v1, p1

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->showRouteResultErrorForTruckPopup(I)V

    goto/16 :goto_2

    .line 3133
    :sswitch_4e
    const-string v21, "isTunnel"

    new-instance v22, Ljava/lang/StringBuilder;

    invoke-direct/range {v22 .. v22}, Ljava/lang/StringBuilder;-><init>()V

    const-string v23, "set Tunnel "

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v22

    move-object/from16 v0, v22

    move/from16 v1, p1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v22

    invoke-virtual/range {v22 .. v22}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v22

    invoke-static/range {v21 .. v22}, Lcom/thinkware/sundo/inavi3d/LOGTW;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 3134
    const/16 v21, 0x2

    move/from16 v0, p1

    move/from16 v1, v21

    if-eq v0, v1, :cond_27

    const/16 v21, 0x3

    move/from16 v0, p1

    move/from16 v1, v21

    if-ne v0, v1, :cond_28

    .line 3135
    :cond_27
    const/16 v21, 0x1

    sput-boolean v21, Lcom/thinkware/sundo/inavi3d/Inavi;->mIsTunnel:Z

    goto/16 :goto_2

    .line 3137
    :cond_28
    const/16 v21, 0x0

    sput-boolean v21, Lcom/thinkware/sundo/inavi3d/Inavi;->mIsTunnel:Z
    :try_end_1
    .catch Landroid/os/RemoteException; {:try_start_1 .. :try_end_1} :catch_0

    goto/16 :goto_2

    .line 2608
    nop

    :sswitch_data_0
    .sparse-switch
        0x1388 -> :sswitch_3
        0x138a -> :sswitch_f
        0x138b -> :sswitch_10
        0x138c -> :sswitch_11
        0x1771 -> :sswitch_12
        0x1772 -> :sswitch_1
        0x1773 -> :sswitch_13
        0x1774 -> :sswitch_2
        0x1775 -> :sswitch_14
        0x1776 -> :sswitch_15
        0x1b58 -> :sswitch_16
        0x1b59 -> :sswitch_19
        0x1b5a -> :sswitch_17
        0x1b5b -> :sswitch_18
        0x1b5c -> :sswitch_1a
        0x1b5d -> :sswitch_1b
        0x1b5e -> :sswitch_0
        0x1b60 -> :sswitch_1d
        0x1d4c -> :sswitch_1e
        0x1d56 -> :sswitch_23
        0x1d57 -> :sswitch_24
        0x1d60 -> :sswitch_25
        0x1d61 -> :sswitch_26
        0x1d62 -> :sswitch_27
        0x1d6a -> :sswitch_28
        0x1dba -> :sswitch_29
        0x1dbb -> :sswitch_2a
        0x1dbc -> :sswitch_2b
        0x1dbd -> :sswitch_2c
        0x1dbe -> :sswitch_2d
        0x1dc4 -> :sswitch_2e
        0x1dc5 -> :sswitch_2f
        0x1dc6 -> :sswitch_30
        0x1dce -> :sswitch_31
        0x1dcf -> :sswitch_32
        0x1dd0 -> :sswitch_33
        0x1dd1 -> :sswitch_34
        0x1dd2 -> :sswitch_35
        0x1dd3 -> :sswitch_36
        0x1dd8 -> :sswitch_39
        0x1dd9 -> :sswitch_37
        0x1dda -> :sswitch_38
        0x1ddb -> :sswitch_3a
        0x1ddc -> :sswitch_3b
        0x2329 -> :sswitch_4
        0x232e -> :sswitch_5
        0x232f -> :sswitch_6
        0x2330 -> :sswitch_9
        0x2331 -> :sswitch_a
        0x2332 -> :sswitch_b
        0x2333 -> :sswitch_c
        0x2334 -> :sswitch_7
        0x2335 -> :sswitch_d
        0x2336 -> :sswitch_e
        0x238d -> :sswitch_47
        0x238e -> :sswitch_48
        0x238f -> :sswitch_4a
        0x2390 -> :sswitch_4b
        0x2391 -> :sswitch_49
        0x2392 -> :sswitch_4c
        0x23f1 -> :sswitch_4d
        0x2454 -> :sswitch_4e
        0x270e -> :sswitch_20
        0x270f -> :sswitch_1f
        0x2711 -> :sswitch_3c
        0x1d4c2 -> :sswitch_21
        0x1d4c5 -> :sswitch_22
        0x1fbd0 -> :sswitch_1c
        0x22348 -> :sswitch_8
        0x22600 -> :sswitch_41
        0x22601 -> :sswitch_42
        0x22602 -> :sswitch_43
        0x22603 -> :sswitch_44
        0x22605 -> :sswitch_46
        0x22666 -> :sswitch_45
        0x2628d -> :sswitch_3d
        0x2628e -> :sswitch_3e
        0x262f0 -> :sswitch_3f
        0x262f1 -> :sswitch_40
    .end sparse-switch
.end method

.method public static native ReadDrivingLogFileCompareMerge()I
.end method

.method public static native RequestMapMoveCCTV(II)V
.end method

.method public static SetDoingReRoute()V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .prologue
    .line 930
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    if-eqz v1, :cond_0

    .line 932
    :try_start_0
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    invoke-interface {v1}, Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;->setDoingReRoute()V

    .line 933
    const-string v1, "UserLog"

    const-string v2, "MMC setDoingReRoute"

    invoke-static {v1, v2}, Lcom/thinkware/sundo/inavi3d/LOGTW;->d(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    .line 939
    .local v0, "e":Landroid/os/RemoteException;
    :cond_0
    :goto_0
    return-void

    .line 934
    .end local v0    # "e":Landroid/os/RemoteException;
    :catch_0
    move-exception v0

    .line 936
    .restart local v0    # "e":Landroid/os/RemoteException;
    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    goto :goto_0
.end method

.method public static SetDoingRoute()V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .prologue
    .line 942
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    if-eqz v1, :cond_0

    .line 944
    :try_start_0
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    invoke-interface {v1}, Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;->setDoingRoute()V

    .line 945
    const-string v1, "UserLog"

    const-string v2, "MMC setDoingRoute"

    invoke-static {v1, v2}, Lcom/thinkware/sundo/inavi3d/LOGTW;->d(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    .line 951
    .local v0, "e":Landroid/os/RemoteException;
    :cond_0
    :goto_0
    return-void

    .line 946
    .end local v0    # "e":Landroid/os/RemoteException;
    :catch_0
    move-exception v0

    .line 948
    .restart local v0    # "e":Landroid/os/RemoteException;
    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    goto :goto_0
.end method

.method public static native SetFinishPositionForSolution(II)V
.end method

.method static SetGPSData(IIIII)V
    .locals 6
    .param p0, "angle"    # I
    .param p1, "gpsscore"    # I
    .param p2, "viewtype"    # I
    .param p3, "viewtypeSecond"    # I
    .param p4, "dualview"    # I

    .prologue
    .line 2378
    sget-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->mUIManager:Lcom/thinkware/sundo/inavi3d/UIManager;

    if-eqz v0, :cond_0

    .line 2379
    sget-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->mUIManager:Lcom/thinkware/sundo/inavi3d/UIManager;

    move v1, p0

    move v2, p1

    move v3, p2

    move v4, p3

    move v5, p4

    invoke-virtual/range {v0 .. v5}, Lcom/thinkware/sundo/inavi3d/UIManager;->SetGPSData(IIIII)V

    .line 2382
    :cond_0
    return-void
.end method

.method static SetGuideCode(II)V
    .locals 2
    .param p0, "nGuideCode"    # I
    .param p1, "nDistance"    # I

    .prologue
    .line 2031
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    if-eqz v1, :cond_0

    .line 2033
    :try_start_0
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    invoke-interface {v1, p0, p1}, Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;->setGuideCode(II)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    .line 2039
    :cond_0
    :goto_0
    return-void

    .line 2034
    :catch_0
    move-exception v0

    .line 2036
    .local v0, "e":Landroid/os/RemoteException;
    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    goto :goto_0
.end method

.method static SetLastDpCoordinate(III)V
    .locals 3
    .param p0, "nX"    # I
    .param p1, "nY"    # I
    .param p2, "nCarAngle"    # I

    .prologue
    .line 1106
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    if-eqz v1, :cond_0

    .line 1108
    :try_start_0
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    invoke-interface {v1, p0, p1, p2}, Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;->SetLastDpCoordinate(III)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    .line 1115
    :goto_0
    return-void

    .line 1109
    :catch_0
    move-exception v0

    .line 1110
    .local v0, "e":Landroid/os/RemoteException;
    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    goto :goto_0

    .line 1113
    .end local v0    # "e":Landroid/os/RemoteException;
    :cond_0
    const-string v1, "inavi3d_hslee"

    const-string v2, "SetLastDpCoordinate, (JAVA) mRouteBinder is null"

    invoke-static {v1, v2}, Lcom/thinkware/sundo/inavi3d/LOGTW;->d(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_0
.end method

.method public static native SetLiveRouteChange(I)V
.end method

.method public static SetLogCountDown()V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .prologue
    .line 969
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    if-eqz v1, :cond_0

    .line 971
    :try_start_0
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    invoke-interface {v1}, Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;->setLogCountDown()V

    .line 972
    const-string v1, "UserLog"

    const-string v2, "MMC setLogCountDown"

    invoke-static {v1, v2}, Lcom/thinkware/sundo/inavi3d/LOGTW;->d(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    .line 978
    .local v0, "e":Landroid/os/RemoteException;
    :cond_0
    :goto_0
    return-void

    .line 973
    .end local v0    # "e":Landroid/os/RemoteException;
    :catch_0
    move-exception v0

    .line 975
    .restart local v0    # "e":Landroid/os/RemoteException;
    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    goto :goto_0
.end method

.method public static native SetLogDriveModeStatus(Z)V
.end method

.method public static native SetMapScene()V
.end method

.method public static native SetMyRouteDefaultMapBitmap(I)V
.end method

.method public static native SetMyRouteLinkSetByFileName(ILjava/lang/String;)V
.end method

.method public static native SetMyRouteMajorRoadName(ILjava/lang/String;Ljava/lang/String;)V
.end method

.method public static native SetMyRoutePopupRouteDataEdit(ILjava/lang/String;)V
.end method

.method public static native SetMyRouteSaveData(II)V
.end method

.method public static SetPartitionModeMisenGUI(I)V
    .locals 2
    .param p0, "rightMargin"    # I

    .prologue
    .line 2151
    sget-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->mDRDataLayout:Landroid/widget/RelativeLayout;

    if-eqz v0, :cond_0

    .line 2153
    sget-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    new-instance v1, Lcom/thinkware/sundo/inavi3d/Inavi$8;

    invoke-direct {v1, p0}, Lcom/thinkware/sundo/inavi3d/Inavi$8;-><init>(I)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 2170
    :cond_0
    return-void
.end method

.method public static SetStopMMCAllThread()V
    .locals 3

    .prologue
    .line 981
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    if-eqz v1, :cond_0

    .line 983
    :try_start_0
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    invoke-interface {v1}, Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;->stopAllThread()V

    .line 984
    const-string v1, "UserLog"

    const-string v2, "MMC SetStopMMCAllThread"

    invoke-static {v1, v2}, Lcom/thinkware/sundo/inavi3d/LOGTW;->d(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    .line 990
    .local v0, "e":Landroid/os/RemoteException;
    :cond_0
    :goto_0
    return-void

    .line 985
    .end local v0    # "e":Landroid/os/RemoteException;
    :catch_0
    move-exception v0

    .line 987
    .restart local v0    # "e":Landroid/os/RemoteException;
    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    goto :goto_0
.end method

.method static SetTBTGuide()V
    .locals 43

    .prologue
    .line 1118
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v29

    .line 1120
    .local v29, "iNavi3DActivity":Lcom/thinkware/sundo/inavi3d/INavi3DActivity;
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    if-eqz v5, :cond_0

    sget-boolean v5, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->initComponentCompleted:Z

    if-eqz v5, :cond_0

    if-nez v29, :cond_1

    .line 2029
    :cond_0
    :goto_0
    return-void

    .line 1126
    :cond_1
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    move-result-object v5

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->isReadyDPMap()Z

    move-result v5

    if-eqz v5, :cond_0

    .line 1130
    sget-boolean v5, Lcom/thinkware/sundo/inavi3d/Inavi;->firstTBTGuide:Z

    if-eqz v5, :cond_2

    .line 1132
    const-string v5, "inavi3d_java"

    const-string v9, "firstTBTGuide"

    invoke-static {v5, v9}, Lcom/thinkware/sundo/inavi3d/LOGTW;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 1134
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v9, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const v11, 0x1d4c6

    invoke-static {v9, v11}, Landroid/os/Message;->obtain(Landroid/os/Handler;I)Landroid/os/Message;

    move-result-object v9

    invoke-virtual {v5, v9}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    .line 1147
    new-instance v4, Ljava/util/Timer;

    const-string v5, "rerouteTimer"

    invoke-direct {v4, v5}, Ljava/util/Timer;-><init>(Ljava/lang/String;)V

    .line 1148
    .local v4, "temp":Ljava/util/Timer;
    new-instance v5, Lcom/thinkware/sundo/inavi3d/Inavi$2;

    invoke-direct {v5}, Lcom/thinkware/sundo/inavi3d/Inavi$2;-><init>()V

    const-wide/16 v6, 0x7530

    const-wide/16 v8, 0x7530

    invoke-virtual/range {v4 .. v9}, Ljava/util/Timer;->schedule(Ljava/util/TimerTask;JJ)V

    .line 1155
    const/4 v5, 0x0

    sput-boolean v5, Lcom/thinkware/sundo/inavi3d/Inavi;->firstTBTGuide:Z

    .line 1158
    .end local v4    # "temp":Ljava/util/Timer;
    :cond_2
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/Inavi;->getTbtguide()Lcom/thinkware/sundo/remoteTBT/TBTGuide;

    move-result-object v5

    invoke-static {v5}, Lcom/thinkware/sundo/inavi3d/Inavi;->GetTBTGuide(Lcom/thinkware/sundo/remoteTBT/TBTGuide;)Lcom/thinkware/sundo/remoteTBT/TBTGuide;

    move-result-object v5

    invoke-static {v5}, Lcom/thinkware/sundo/inavi3d/Inavi;->setTbtguide(Lcom/thinkware/sundo/remoteTBT/TBTGuide;)V

    .line 1159
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/Inavi;->getTbtguide()Lcom/thinkware/sundo/remoteTBT/TBTGuide;

    move-result-object v5

    invoke-static {v5}, Lcom/thinkware/sundo/inavi3d/Inavi;->setHudguide(Lcom/thinkware/sundo/remoteTBT/TBTGuide;)V

    .line 1161
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/Inavi;->GetViaStatus()Z

    move-result v5

    sput-boolean v5, Lcom/thinkware/sundo/inavi3d/Inavi;->viaStatus:Z

    .line 1164
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    move-result-object v5

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->checkOBD2Overspeed()V

    .line 1168
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v5

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->isSimulationMode()Z

    move-result v5

    if-eqz v5, :cond_4

    .line 1169
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v5

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/Inavi;->getTbtguide()Lcom/thinkware/sundo/remoteTBT/TBTGuide;

    move-result-object v9

    iget v9, v9, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->road_type:I

    invoke-virtual {v5, v9}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->IsHighwayRoadType(I)Z

    move-result v5

    if-eqz v5, :cond_3

    .line 1170
    sget v5, Lcom/thinkware/sundo/inavi3d/DeviceState;->SLEEP_NORMAL:I

    invoke-static {v5}, Lcom/thinkware/sundo/inavi3d/DeviceState;->setSleepTime(I)V

    .line 1186
    :goto_1
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->m_LaneTurnModeLayout:Landroid/widget/LinearLayout;

    if-nez v5, :cond_7

    .line 1187
    sget-boolean v5, Lcom/thinkware/sundo/inavi3d/Inavi;->bUISetting:Z

    if-nez v5, :cond_0

    .line 1188
    const/4 v5, 0x1

    sput-boolean v5, Lcom/thinkware/sundo/inavi3d/Inavi;->bUISetting:Z

    .line 1189
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/Inavi;->setUI()V

    goto/16 :goto_0

    .line 1172
    :cond_3
    sget v5, Lcom/thinkware/sundo/inavi3d/DeviceState;->SLEEP_SHORT:I

    invoke-static {v5}, Lcom/thinkware/sundo/inavi3d/DeviceState;->setSleepTime(I)V

    goto :goto_1

    .line 1175
    :cond_4
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v5

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->isSupportIVision()Z

    move-result v5

    if-eqz v5, :cond_5

    .line 1176
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    move-result-object v5

    sget-boolean v9, Lcom/thinkware/sundo/inavi3d/Inavi;->mIsTunnel:Z

    invoke-virtual {v5, v9}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->sendBroadcastCommonGuide(Z)V

    .line 1179
    :cond_5
    invoke-virtual/range {v29 .. v29}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->isCurrentOffScene()Z

    move-result v5

    const/4 v9, 0x1

    if-ne v5, v9, :cond_6

    .line 1180
    sget v5, Lcom/thinkware/sundo/inavi3d/DeviceState;->SLEEP_SHORT:I

    invoke-static {v5}, Lcom/thinkware/sundo/inavi3d/DeviceState;->setSleepTime(I)V

    goto :goto_1

    .line 1182
    :cond_6
    sget v5, Lcom/thinkware/sundo/inavi3d/DeviceState;->SLEEP_NORMAL:I

    invoke-static {v5}, Lcom/thinkware/sundo/inavi3d/DeviceState;->setSleepTime(I)V

    goto :goto_1

    .line 1193
    :cond_7
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    move-result-object v5

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->isCurrentFlag()Z

    move-result v5

    if-nez v5, :cond_8

    .line 1195
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->btnLocalName:Landroid/widget/Button;

    if-eqz v5, :cond_8

    .line 1197
    const/16 v38, 0x0

    .line 1199
    .local v38, "strRoadName":Ljava/lang/String;
    :try_start_0
    new-instance v5, Ljava/lang/String;

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/Inavi;->getTbtguide()Lcom/thinkware/sundo/remoteTBT/TBTGuide;

    move-result-object v9

    iget-object v9, v9, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->roadNm:[B

    const-string v11, "EUC-KR"

    invoke-direct {v5, v9, v11}, Ljava/lang/String;-><init>([BLjava/lang/String;)V

    invoke-virtual {v5}, Ljava/lang/String;->trim()Ljava/lang/String;
    :try_end_0
    .catch Ljava/io/UnsupportedEncodingException; {:try_start_0 .. :try_end_0} :catch_0

    move-result-object v38

    .line 1204
    :goto_2
    move-object/from16 v35, v38

    .line 1205
    .local v35, "name":Ljava/lang/String;
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->btnLocalName:Landroid/widget/Button;

    new-instance v9, Lcom/thinkware/sundo/inavi3d/Inavi$3;

    move-object/from16 v0, v35

    invoke-direct {v9, v0}, Lcom/thinkware/sundo/inavi3d/Inavi$3;-><init>(Ljava/lang/String;)V

    invoke-virtual {v5, v9}, Landroid/widget/Button;->post(Ljava/lang/Runnable;)Z

    .line 1215
    .end local v35    # "name":Ljava/lang/String;
    .end local v38    # "strRoadName":Ljava/lang/String;
    :cond_8
    const/16 v23, 0x0

    .line 1216
    .local v23, "bRunningLaneAndTurn":Z
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->m_LaneTurnModeLayout:Landroid/widget/LinearLayout;

    if-eqz v5, :cond_9

    .line 1217
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->m_LaneTurnModeLayout:Landroid/widget/LinearLayout;

    invoke-virtual {v5}, Landroid/widget/LinearLayout;->getVisibility()I

    move-result v5

    if-nez v5, :cond_32

    const/16 v23, 0x1

    .line 1218
    :cond_9
    :goto_3
    const/16 v33, -0x1

    .line 1219
    .local v33, "nLaneAndTurnMode":I
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->getInstance()Lcom/thinkware/sundo/inavi3d/InaviConfig;

    move-result-object v5

    if-eqz v5, :cond_a

    .line 1220
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->getInstance()Lcom/thinkware/sundo/inavi3d/InaviConfig;

    move-result-object v5

    const/16 v9, 0x118

    invoke-virtual {v5, v9}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->CNaviConfigGet(I)I

    move-result v33

    .line 1222
    :cond_a
    if-eqz v23, :cond_33

    const/4 v5, 0x2

    move/from16 v0, v33

    if-eq v0, v5, :cond_b

    if-nez v33, :cond_33

    :cond_b
    const/16 v22, 0x1

    .line 1223
    .local v22, "bHideTurnAndDirInfoView":Z
    :goto_4
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/Inavi;->getTbtguide()Lcom/thinkware/sundo/remoteTBT/TBTGuide;

    move-result-object v16

    .line 1224
    .local v16, "tbtGuide":Lcom/thinkware/sundo/remoteTBT/TBTGuide;
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/Inavi;->getHudguide()Lcom/thinkware/sundo/remoteHUD/HUDGuide;

    move-result-object v28

    .line 1226
    .local v28, "hudGuide":Lcom/thinkware/sundo/remoteHUD/HUDGuide;
    const/16 v26, 0x0

    .line 1228
    .local v26, "currentSpeed":I
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->tbtguide:Lcom/thinkware/sundo/remoteTBT/TBTGuide;

    if-eqz v5, :cond_c

    .line 1229
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->tbtguide:Lcom/thinkware/sundo/remoteTBT/TBTGuide;

    iget v0, v5, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->mCurrentSpeed:I

    move/from16 v26, v0

    .line 1232
    :cond_c
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v5

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->GetOBD2Connect()Z

    move-result v5

    const/4 v9, 0x1

    if-ne v5, v9, :cond_d

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v5

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->isSpeedUpdate()Z

    move-result v5

    const/4 v9, 0x1

    if-ne v5, v9, :cond_d

    if-gtz v26, :cond_d

    .line 1233
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v5

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getOBD2CurrentSpeed()F

    move-result v5

    float-to-int v0, v5

    move/from16 v26, v0

    .line 1236
    :cond_d
    if-eqz v16, :cond_31

    .line 1240
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->currentOnLayOutAR:Landroid/widget/RelativeLayout;

    if-eqz v5, :cond_18

    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->currentOnLayOutAR:Landroid/widget/RelativeLayout;

    invoke-virtual {v5}, Landroid/widget/RelativeLayout;->getVisibility()I

    move-result v5

    if-nez v5, :cond_18

    .line 1241
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->courseRightViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/DriveCourseCurrentViewAR;

    if-eqz v5, :cond_e

    .line 1242
    move-object/from16 v0, v16

    iget v5, v0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->isroute:I

    if-eqz v5, :cond_34

    .line 1244
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->courseRightViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/DriveCourseCurrentViewAR;

    move-object/from16 v0, v16

    invoke-virtual {v5, v0}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/DriveCourseCurrentViewAR;->setUpdate(Lcom/thinkware/sundo/remoteTBT/TBTGuide;)V

    .line 1245
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->courseRightViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/DriveCourseCurrentViewAR;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/DriveCourseCurrentViewAR;->postInvalidate()V

    .line 1253
    :cond_e
    :goto_5
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->courseViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/DriveCourseViewAR;

    if-eqz v5, :cond_f

    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->driveCourseViewRouteCancelButtonAR:Landroid/widget/Button;

    if-eqz v5, :cond_f

    .line 1254
    move-object/from16 v0, v16

    iget v5, v0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->isroute:I

    if-eqz v5, :cond_35

    .line 1255
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->courseViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/DriveCourseViewAR;

    const/4 v9, 0x0

    invoke-static {v5, v9}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    .line 1256
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->driveCourseViewRouteCancelButtonAR:Landroid/widget/Button;

    const/4 v9, 0x0

    invoke-static {v5, v9}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    .line 1257
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->courseViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/DriveCourseViewAR;

    move-object/from16 v0, v16

    invoke-virtual {v5, v0}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/DriveCourseViewAR;->setUpdate(Lcom/thinkware/sundo/remoteTBT/TBTGuide;)V

    .line 1258
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->courseViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/DriveCourseViewAR;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/DriveCourseViewAR;->postInvalidate()V

    .line 1272
    :cond_f
    :goto_6
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->speedviewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SpeedViewAR;

    if-eqz v5, :cond_10

    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->currentOnLayOutAR:Landroid/widget/RelativeLayout;

    invoke-virtual {v5}, Landroid/widget/RelativeLayout;->getVisibility()I

    move-result v5

    if-nez v5, :cond_10

    .line 1273
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->speedviewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SpeedViewAR;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SpeedViewAR;->postInvalidate()V

    .line 1274
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->speedviewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SpeedViewAR;

    new-instance v9, Lcom/thinkware/sundo/inavi3d/Inavi$4;

    invoke-direct {v9}, Lcom/thinkware/sundo/inavi3d/Inavi$4;-><init>()V

    invoke-virtual {v5, v9}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SpeedViewAR;->post(Ljava/lang/Runnable;)Z

    .line 1298
    :cond_10
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->turnAreaViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaViewAR;

    if-eqz v5, :cond_11

    .line 1299
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v5

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->GetIEVE()Lcom/thinkware/sundo/ieve/IEVE;

    move-result-object v30

    .line 1300
    .local v30, "ieve":Lcom/thinkware/sundo/ieve/IEVE;
    if-eqz v30, :cond_36

    invoke-virtual/range {v30 .. v30}, Lcom/thinkware/sundo/ieve/IEVE;->isFullMode()Z

    move-result v5

    if-nez v5, :cond_36

    .line 1301
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->turnAreaViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaViewAR;

    const/4 v9, 0x4

    invoke-static {v5, v9}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    .line 1322
    .end local v30    # "ieve":Lcom/thinkware/sundo/ieve/IEVE;
    :cond_11
    :goto_7
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v5

    move-object/from16 v0, v16

    invoke-virtual {v5, v0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->checkSimpleMapZoomDest(Lcom/thinkware/sundo/remoteTBT/TBTGuide;)V

    .line 1323
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v5

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->checkRerouteSimpleMapZoom()V

    .line 1339
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->obd2ViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/OBD2ViewAR;

    if-eqz v5, :cond_12

    .line 1340
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->obd2ViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/OBD2ViewAR;

    move-object/from16 v0, v16

    invoke-virtual {v5, v0}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/OBD2ViewAR;->setUpdate(Lcom/thinkware/sundo/remoteTBT/TBTGuide;)Z

    .line 1375
    :cond_12
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->driveLineViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/LaneInfoViewAR;

    if-eqz v5, :cond_13

    .line 1376
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->driveLineViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/LaneInfoViewAR;

    move-object/from16 v0, v16

    invoke-virtual {v5, v0}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/LaneInfoViewAR;->setUpdate(Lcom/thinkware/sundo/remoteTBT/TBTGuide;)V

    .line 1377
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->driveLineViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/LaneInfoViewAR;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/LaneInfoViewAR;->postInvalidate()V

    .line 1380
    :cond_13
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->cswsViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/CSWSViewAR;

    if-eqz v5, :cond_14

    .line 1381
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v5

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->GetIEVE()Lcom/thinkware/sundo/ieve/IEVE;

    move-result-object v30

    .line 1382
    .restart local v30    # "ieve":Lcom/thinkware/sundo/ieve/IEVE;
    if-eqz v30, :cond_14

    .line 1383
    invoke-virtual/range {v30 .. v30}, Lcom/thinkware/sundo/ieve/IEVE;->getRecogResultCSWS()I

    move-result v25

    .line 1384
    .local v25, "cswsStatus":I
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->cswsViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/CSWSViewAR;

    move/from16 v0, v25

    invoke-virtual {v5, v0}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/CSWSViewAR;->setUpdatCSWS(I)V

    .line 1385
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->cswsViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/CSWSViewAR;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/CSWSViewAR;->postInvalidate()V

    .line 1388
    .end local v25    # "cswsStatus":I
    .end local v30    # "ieve":Lcom/thinkware/sundo/ieve/IEVE;
    :cond_14
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneViewAR;

    if-eqz v5, :cond_17

    .line 1389
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneViewAR;

    move-object/from16 v0, v16

    invoke-virtual {v5, v0}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneViewAR;->setUpdate(Lcom/thinkware/sundo/remoteTBT/TBTGuide;)Z

    move-result v5

    if-eqz v5, :cond_3d

    .line 1390
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneViewAR;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneViewAR;->getSafeType()I

    move-result v7

    .line 1391
    .local v7, "safeZoneType":I
    move-object/from16 v0, v16

    iget v8, v0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->speedlimit:I

    .line 1392
    .local v8, "speedlimit":I
    if-ltz v7, :cond_3b

    .line 1393
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneTypeViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneTypeViewAR;

    invoke-virtual {v5, v7}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneTypeViewAR;->updateData(I)V

    .line 1394
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneTypeViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneTypeViewAR;

    const/4 v9, 0x0

    invoke-static {v5, v9}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    .line 1395
    if-lez v8, :cond_38

    .line 1396
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneLimitSpeedViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneLimitSpeedViewAR;

    invoke-virtual {v5, v8}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneLimitSpeedViewAR;->updateData(I)V

    .line 1397
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneLimitSpeedViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneLimitSpeedViewAR;

    const/4 v9, 0x0

    invoke-static {v5, v9}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    .line 1401
    :goto_8
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneDistanceViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneDistanceViewAR;

    sget-object v9, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneViewAR;

    invoke-virtual {v9}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneViewAR;->getSafeZone()Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneAR;

    move-result-object v9

    invoke-virtual {v5, v9}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneDistanceViewAR;->updateData(Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneAR;)V

    .line 1402
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneDistanceViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneDistanceViewAR;

    const/4 v9, 0x0

    invoke-static {v5, v9}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    .line 1404
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneViewAR;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneViewAR;->getSafeZone()Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneAR;

    move-result-object v5

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneAR;->GetDistance()I

    move-result v34

    .line 1405
    .local v34, "nRemaindist":I
    const/4 v6, 0x0

    .line 1406
    .local v6, "nDrawType":I
    if-ltz v34, :cond_16

    .line 1407
    const/4 v5, 0x2

    if-eq v7, v5, :cond_15

    const/4 v5, 0x5

    if-ne v7, v5, :cond_39

    :cond_15
    move-object/from16 v0, v16

    iget v5, v0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->pair_avrspeed:I

    if-lez v5, :cond_39

    const/16 v5, 0x136

    move/from16 v0, v34

    if-le v0, v5, :cond_39

    .line 1408
    const/4 v6, 0x2

    .line 1414
    :cond_16
    :goto_9
    if-lez v6, :cond_3a

    .line 1415
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v5

    const/4 v9, 0x1

    invoke-virtual {v5, v9}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->changeStatusHalfPointView(Z)V

    .line 1416
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneViewAR;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneViewAR;->getSafeZone()Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneAR;

    move-result-object v5

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneAR;->getSafeZoneDistUnit()Ljava/lang/String;

    move-result-object v39

    .line 1417
    .local v39, "strdistUnit":Ljava/lang/String;
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneMiniViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneMiniViewAR;

    sget-object v9, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneViewAR;

    invoke-virtual {v9}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneViewAR;->getSafeZone()Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneAR;

    move-result-object v9

    move-object/from16 v0, v16

    iget v10, v0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->pair_avrspeed:I

    move-object/from16 v0, v16

    iget v11, v0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->mSafeAreaRemainRatio:I

    invoke-virtual/range {v5 .. v11}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneMiniViewAR;->setData(IIILcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneAR;II)V

    .line 1419
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneMiniViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneMiniViewAR;

    const/4 v9, 0x0

    invoke-static {v5, v9}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    .line 1482
    .end local v6    # "nDrawType":I
    .end local v7    # "safeZoneType":I
    .end local v8    # "speedlimit":I
    .end local v34    # "nRemaindist":I
    .end local v39    # "strdistUnit":Ljava/lang/String;
    :cond_17
    :goto_a
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v5

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->getScaleType()I

    move-result v5

    const/4 v9, 0x3

    if-ne v5, v9, :cond_18

    .line 1483
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->progressBarAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TrafficProgressBar;

    if-eqz v5, :cond_18

    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->progressBarLayoutAR:Landroid/widget/RelativeLayout;

    if-eqz v5, :cond_18

    .line 1484
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->progressBarAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TrafficProgressBar;

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/Inavi;->getTbtguide()Lcom/thinkware/sundo/remoteTBT/TBTGuide;

    move-result-object v9

    invoke-virtual {v5, v9}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TrafficProgressBar;->setUpdate(Lcom/thinkware/sundo/remoteTBT/TBTGuide;)Z

    move-result v5

    if-eqz v5, :cond_3e

    .line 1485
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->progressBarLayoutAR:Landroid/widget/RelativeLayout;

    const/4 v9, 0x0

    invoke-static {v5, v9}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    .line 1486
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->progressBarAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TrafficProgressBar;

    const/4 v9, 0x0

    invoke-static {v5, v9}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    .line 1488
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->progressBarAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TrafficProgressBar;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TrafficProgressBar;->postInvalidate()V

    .line 1495
    :goto_b
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->progressBarAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TrafficProgressBar;

    const/4 v9, 0x0

    invoke-virtual {v5, v9}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TrafficProgressBar;->setClickable(Z)V

    .line 1496
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->progressBarAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TrafficProgressBar;

    const/4 v9, 0x0

    invoke-virtual {v5, v9}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TrafficProgressBar;->setClickable(Z)V

    .line 1515
    :cond_18
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->currentOnLayOutNormal:Landroid/widget/RelativeLayout;

    if-eqz v5, :cond_2d

    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->currentOnLayOutNormal:Landroid/widget/RelativeLayout;

    invoke-virtual {v5}, Landroid/widget/RelativeLayout;->getVisibility()I

    move-result v5

    if-nez v5, :cond_2d

    .line 1517
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->speedview:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SpeedView;

    if-eqz v5, :cond_19

    .line 1518
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->speedview:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SpeedView;

    sget-boolean v9, Lcom/thinkware/sundo/inavi3d/Inavi;->mIsDrSpeed:Z

    invoke-virtual {v5, v9}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SpeedView;->setDRSpeed(Z)V

    .line 1519
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->speedview:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SpeedView;

    move-object/from16 v0, v16

    move/from16 v1, v26

    invoke-virtual {v5, v0, v1}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SpeedView;->setUpdate(Lcom/thinkware/sundo/remoteTBT/TBTGuide;I)V

    .line 1520
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->speedview:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SpeedView;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SpeedView;->postInvalidate()V

    .line 1525
    :cond_19
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->progressBar:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TrafficProgressBar;

    if-eqz v5, :cond_1a

    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->progressBarLayout:Landroid/widget/RelativeLayout;

    if-eqz v5, :cond_1a

    .line 1526
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->progressBar:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TrafficProgressBar;

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/Inavi;->getTbtguide()Lcom/thinkware/sundo/remoteTBT/TBTGuide;

    move-result-object v9

    invoke-virtual {v5, v9}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TrafficProgressBar;->setUpdate(Lcom/thinkware/sundo/remoteTBT/TBTGuide;)Z

    move-result v5

    if-eqz v5, :cond_3f

    .line 1527
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->progressBarLayout:Landroid/widget/RelativeLayout;

    const/4 v9, 0x0

    invoke-static {v5, v9}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    .line 1528
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->progressBar:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TrafficProgressBar;

    const/4 v9, 0x0

    invoke-static {v5, v9}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    .line 1529
    const/4 v5, 0x1

    invoke-static {v5}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetViewMargin(Z)V

    .line 1530
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->progressBar:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TrafficProgressBar;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TrafficProgressBar;->postInvalidate()V

    .line 1537
    :goto_c
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->progressBar:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TrafficProgressBar;

    const/4 v9, 0x0

    invoke-virtual {v5, v9}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TrafficProgressBar;->setClickable(Z)V

    .line 1538
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->progressBar:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TrafficProgressBar;

    const/4 v9, 0x0

    invoke-virtual {v5, v9}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TrafficProgressBar;->setClickable(Z)V

    .line 1542
    :cond_1a
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->courseView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/DriveCourseView;

    if-eqz v5, :cond_1c

    .line 1543
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->courseView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/DriveCourseView;

    move-object/from16 v0, v16

    invoke-virtual {v5, v0}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/DriveCourseView;->setUpdate(Lcom/thinkware/sundo/remoteTBT/TBTGuide;)V

    .line 1545
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->TrafficRouteTableInfo:Lcom/thinkware/sundo/inavi3d/ROUTE_TABLE_RENEW_INFO;

    if-eqz v5, :cond_1b

    .line 1547
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->TrafficRouteTableInfo:Lcom/thinkware/sundo/inavi3d/ROUTE_TABLE_RENEW_INFO;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3d/ROUTE_TABLE_RENEW_INFO;->init()V

    .line 1548
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->TrafficRouteTableInfo:Lcom/thinkware/sundo/inavi3d/ROUTE_TABLE_RENEW_INFO;

    invoke-static {v5}, Lcom/thinkware/sundo/inavi3d/Inavi;->GetTblRenewInfo(Lcom/thinkware/sundo/inavi3d/ROUTE_TABLE_RENEW_INFO;)V

    .line 1549
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->TrafficRouteTableInfo:Lcom/thinkware/sundo/inavi3d/ROUTE_TABLE_RENEW_INFO;

    iget v5, v5, Lcom/thinkware/sundo/inavi3d/ROUTE_TABLE_RENEW_INFO;->m_nDiffTime:I

    if-lez v5, :cond_1b

    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->TrafficRouteTableInfo:Lcom/thinkware/sundo/inavi3d/ROUTE_TABLE_RENEW_INFO;

    iget v5, v5, Lcom/thinkware/sundo/inavi3d/ROUTE_TABLE_RENEW_INFO;->m_nDiffLength:I

    if-lez v5, :cond_1b

    .line 1551
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->courseView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/DriveCourseView;

    sget-object v9, Lcom/thinkware/sundo/inavi3d/Inavi;->TrafficRouteTableInfo:Lcom/thinkware/sundo/inavi3d/ROUTE_TABLE_RENEW_INFO;

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v11

    iget-boolean v11, v11, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_bShowReRouteInfoDownBar:Z

    invoke-virtual {v5, v9, v11}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/DriveCourseView;->setReRouteInfo(Lcom/thinkware/sundo/inavi3d/ROUTE_TABLE_RENEW_INFO;Z)V

    .line 1555
    :cond_1b
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->courseView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/DriveCourseView;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/DriveCourseView;->postInvalidate()V

    .line 1558
    :cond_1c
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->driveLineView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/LaneInfoView;

    if-eqz v5, :cond_1d

    .line 1559
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->driveLineView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/LaneInfoView;

    move-object/from16 v0, v16

    invoke-virtual {v5, v0}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/LaneInfoView;->setUpdate(Lcom/thinkware/sundo/remoteTBT/TBTGuide;)V

    .line 1560
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->driveLineView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/LaneInfoView;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/LaneInfoView;->postInvalidate()V

    .line 1563
    :cond_1d
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;

    if-eqz v5, :cond_1f

    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneLayout:Landroid/widget/RelativeLayout;

    if-eqz v5, :cond_1f

    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->sectionView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;

    if-eqz v5, :cond_1f

    .line 1564
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;

    move-object/from16 v0, v16

    invoke-virtual {v5, v0}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;->setUpdate(Lcom/thinkware/sundo/remoteTBT/TBTGuide;)Z

    move-result v5

    if-eqz v5, :cond_42

    .line 1565
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneLayout:Landroid/widget/RelativeLayout;

    const/4 v9, 0x0

    invoke-static {v5, v9}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    .line 1566
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;

    const/4 v9, 0x1

    invoke-virtual {v5, v9}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;->setClickable(Z)V

    .line 1569
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v5

    move-object/from16 v0, v16

    invoke-virtual {v5, v0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->startAutoArMode(Lcom/thinkware/sundo/remoteTBT/TBTGuide;)V

    .line 1571
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;->getSafeZone()Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZone;

    move-result-object v10

    .line 1572
    .local v10, "sfZone":Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZone;
    if-eqz v10, :cond_1e

    .line 1574
    invoke-virtual {v10}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZone;->getSafeSectionNoRoute()Z

    move-result v5

    if-eqz v5, :cond_40

    .line 1575
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->sectionView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;

    move-object/from16 v0, v16

    invoke-virtual {v5, v10, v0}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;->SetSectionData(Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZone;Lcom/thinkware/sundo/remoteTBT/TBTGuide;)V

    .line 1576
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->sectionView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;

    const/4 v9, 0x0

    invoke-static {v5, v9}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    .line 1577
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->sectionView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;

    const/4 v9, 0x1

    invoke-virtual {v5, v9}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;->setClickable(Z)V

    .line 1602
    .end local v10    # "sfZone":Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZone;
    :cond_1e
    :goto_d
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v9, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const/16 v11, 0xfc8

    invoke-static {v9, v11}, Landroid/os/Message;->obtain(Landroid/os/Handler;I)Landroid/os/Message;

    move-result-object v9

    invoke-virtual {v5, v9}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    .line 1605
    :cond_1f
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->turnAreaView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;

    if-eqz v5, :cond_20

    .line 1606
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->turnAreaView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;

    sget-boolean v9, Lcom/thinkware/sundo/inavi3d/Inavi;->viaStatus:Z

    invoke-virtual {v5, v9}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;->setViaStatus(Z)V

    .line 1607
    sget-boolean v5, Lcom/thinkware/sundo/inavi3d/Inavi;->viaStatus:Z

    if-eqz v5, :cond_43

    .line 1608
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->turnAreaView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;

    move-object/from16 v0, v16

    invoke-virtual {v5, v0}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;->SetViaJump(Lcom/thinkware/sundo/remoteTBT/TBTGuide;)V

    .line 1609
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->turnAreaView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;

    const/4 v9, 0x0

    invoke-static {v5, v9}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    .line 1610
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->turnAreaView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;

    const/4 v9, 0x1

    invoke-virtual {v5, v9}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;->setClickable(Z)V

    .line 1623
    :cond_20
    :goto_e
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->getInstance()Lcom/thinkware/sundo/inavi3d/InaviConfig;

    move-result-object v5

    const/16 v9, 0x79

    invoke-virtual {v5, v9}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->CNaviConfigGet(I)I

    move-result v5

    if-nez v5, :cond_45

    .line 1624
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->crossWayView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/CrossWayView;

    const/4 v9, 0x4

    invoke-static {v5, v9}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    .line 1651
    :cond_21
    :goto_f
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->speedview2:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SpeedView;

    if-eqz v5, :cond_22

    .line 1652
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->speedview2:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SpeedView;

    sget-boolean v9, Lcom/thinkware/sundo/inavi3d/Inavi;->mIsDrSpeed:Z

    invoke-virtual {v5, v9}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SpeedView;->setDRSpeed(Z)V

    .line 1653
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->speedview2:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SpeedView;

    move-object/from16 v0, v16

    move/from16 v1, v26

    invoke-virtual {v5, v0, v1}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SpeedView;->setUpdate(Lcom/thinkware/sundo/remoteTBT/TBTGuide;I)V

    .line 1654
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->speedview2:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SpeedView;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SpeedView;->postInvalidate()V

    .line 1657
    :cond_22
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneView2:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;

    if-eqz v5, :cond_23

    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneLayout2:Landroid/widget/RelativeLayout;

    if-eqz v5, :cond_23

    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->sectionView2:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;

    if-eqz v5, :cond_23

    .line 1658
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneView2:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;

    move-object/from16 v0, v16

    invoke-virtual {v5, v0}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;->setUpdate(Lcom/thinkware/sundo/remoteTBT/TBTGuide;)Z

    move-result v5

    if-eqz v5, :cond_49

    .line 1659
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneLayout2:Landroid/widget/RelativeLayout;

    const/4 v9, 0x0

    invoke-static {v5, v9}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    .line 1660
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneView2:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;

    const/4 v9, 0x1

    invoke-virtual {v5, v9}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;->setClickable(Z)V

    .line 1663
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v5

    move-object/from16 v0, v16

    invoke-virtual {v5, v0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->startAutoArMode(Lcom/thinkware/sundo/remoteTBT/TBTGuide;)V

    .line 1665
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneView2:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;->getSafeZone()Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZone;

    move-result-object v10

    .line 1666
    .restart local v10    # "sfZone":Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZone;
    if-eqz v10, :cond_23

    .line 1667
    invoke-virtual {v10}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZone;->getSafeSectionNoRoute()Z

    move-result v5

    if-eqz v5, :cond_47

    .line 1668
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->sectionView2:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;

    move-object/from16 v0, v16

    invoke-virtual {v5, v10, v0}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;->SetSectionData(Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZone;Lcom/thinkware/sundo/remoteTBT/TBTGuide;)V

    .line 1669
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->sectionView2:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;

    const/4 v9, 0x0

    invoke-static {v5, v9}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    .line 1670
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->sectionView2:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;

    const/4 v9, 0x1

    invoke-virtual {v5, v9}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;->setClickable(Z)V

    .line 1698
    .end local v10    # "sfZone":Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZone;
    :cond_23
    :goto_10
    const/16 v24, 0x0

    .line 1700
    .local v24, "bTurnViewIsShwing":Z
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->turnAreaView2:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;

    if-eqz v5, :cond_24

    .line 1701
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->turnAreaView2:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;

    sget-boolean v9, Lcom/thinkware/sundo/inavi3d/Inavi;->viaStatus:Z

    invoke-virtual {v5, v9}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;->setViaStatus(Z)V

    .line 1702
    sget-boolean v5, Lcom/thinkware/sundo/inavi3d/Inavi;->viaStatus:Z

    if-eqz v5, :cond_4a

    .line 1703
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->turnAreaView2:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;

    move-object/from16 v0, v16

    invoke-virtual {v5, v0}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;->SetViaJump(Lcom/thinkware/sundo/remoteTBT/TBTGuide;)V

    .line 1704
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->turnAreaView2:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;

    const/4 v9, 0x0

    invoke-static {v5, v9}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    .line 1705
    const/16 v24, 0x1

    .line 1706
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->turnAreaView2:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;

    const/4 v9, 0x1

    invoke-virtual {v5, v9}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;->setClickable(Z)V

    .line 1720
    :cond_24
    :goto_11
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->getInstance()Lcom/thinkware/sundo/inavi3d/InaviConfig;

    move-result-object v5

    const/16 v9, 0x79

    invoke-virtual {v5, v9}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->CNaviConfigGet(I)I

    move-result v5

    if-nez v5, :cond_4c

    .line 1721
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->crossWayView2:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/CrossWayView;

    const/16 v9, 0x8

    invoke-static {v5, v9}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    .line 1747
    :cond_25
    :goto_12
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneView3:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;

    if-eqz v5, :cond_26

    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneLayout3:Landroid/widget/RelativeLayout;

    if-eqz v5, :cond_26

    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->sectionView3:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;

    if-eqz v5, :cond_26

    .line 1748
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneView3:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;

    move-object/from16 v0, v16

    invoke-virtual {v5, v0}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;->setUpdate(Lcom/thinkware/sundo/remoteTBT/TBTGuide;)Z

    move-result v5

    if-eqz v5, :cond_4f

    .line 1749
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneLayout3:Landroid/widget/RelativeLayout;

    const/4 v9, 0x0

    invoke-static {v5, v9}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    .line 1750
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneView3:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;

    const/4 v9, 0x1

    invoke-virtual {v5, v9}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;->setClickable(Z)V

    .line 1753
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v5

    move-object/from16 v0, v16

    invoke-virtual {v5, v0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->startAutoArMode(Lcom/thinkware/sundo/remoteTBT/TBTGuide;)V

    .line 1755
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneView3:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;->getSafeZone()Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZone;

    move-result-object v10

    .line 1756
    .restart local v10    # "sfZone":Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZone;
    if-eqz v10, :cond_26

    .line 1757
    invoke-virtual {v10}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZone;->getSafeSectionNoRoute()Z

    move-result v5

    if-eqz v5, :cond_4d

    .line 1758
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->sectionView3:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;

    move-object/from16 v0, v16

    invoke-virtual {v5, v10, v0}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;->SetSectionData(Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZone;Lcom/thinkware/sundo/remoteTBT/TBTGuide;)V

    .line 1759
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->sectionView3:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;

    const/4 v9, 0x0

    invoke-static {v5, v9}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    .line 1760
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->sectionView3:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;

    const/4 v9, 0x1

    invoke-virtual {v5, v9}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;->setClickable(Z)V

    .line 1787
    .end local v10    # "sfZone":Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZone;
    :cond_26
    :goto_13
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->speedview3:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SpeedView;

    if-eqz v5, :cond_27

    .line 1788
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->speedview3:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SpeedView;

    sget-boolean v9, Lcom/thinkware/sundo/inavi3d/Inavi;->mIsDrSpeed:Z

    invoke-virtual {v5, v9}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SpeedView;->setDRSpeed(Z)V

    .line 1789
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->speedview3:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SpeedView;

    move-object/from16 v0, v16

    move/from16 v1, v26

    invoke-virtual {v5, v0, v1}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SpeedView;->setUpdate(Lcom/thinkware/sundo/remoteTBT/TBTGuide;I)V

    .line 1790
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->speedview3:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SpeedView;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SpeedView;->postInvalidate()V

    .line 1793
    :cond_27
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->turnAreaView3:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;

    if-eqz v5, :cond_28

    .line 1794
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->turnAreaView3:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;

    sget-boolean v9, Lcom/thinkware/sundo/inavi3d/Inavi;->viaStatus:Z

    invoke-virtual {v5, v9}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;->setViaStatus(Z)V

    .line 1795
    sget-boolean v5, Lcom/thinkware/sundo/inavi3d/Inavi;->viaStatus:Z

    if-eqz v5, :cond_50

    .line 1796
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->turnAreaView3:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;

    move-object/from16 v0, v16

    invoke-virtual {v5, v0}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;->SetViaJump(Lcom/thinkware/sundo/remoteTBT/TBTGuide;)V

    .line 1797
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->turnAreaView3:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;

    const/4 v9, 0x0

    invoke-static {v5, v9}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    .line 1798
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->turnAreaView3:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;

    const/4 v9, 0x1

    invoke-virtual {v5, v9}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;->setClickable(Z)V

    .line 1811
    :cond_28
    :goto_14
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->getInstance()Lcom/thinkware/sundo/inavi3d/InaviConfig;

    move-result-object v5

    const/16 v9, 0x79

    invoke-virtual {v5, v9}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->CNaviConfigGet(I)I

    move-result v5

    if-nez v5, :cond_52

    .line 1812
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->crossWayView3:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/CrossWayView;

    const/16 v9, 0x8

    invoke-static {v5, v9}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    .line 1825
    :cond_29
    :goto_15
    const-string v36, "\uad50\ucc28\ub85c\uba85"

    .line 1826
    .local v36, "strCross":Ljava/lang/String;
    const/16 v41, 0x0

    .line 1827
    .local v41, "textcolor":I
    const/16 v40, 0x16

    .line 1828
    .local v40, "textSize":I
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->crossname:Landroid/widget/Button;

    if-eqz v5, :cond_57

    .line 1832
    move-object/from16 v0, v16

    iget-object v5, v0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->crossDirNm:[B

    const/4 v9, 0x0

    aget-byte v5, v5, v9

    if-nez v5, :cond_54

    .line 1833
    const/16 v5, 0x6e

    const/16 v9, 0x6e

    const/16 v11, 0x6e

    invoke-static {v5, v9, v11}, Landroid/graphics/Color;->rgb(III)I

    move-result v41

    .line 1834
    move-object/from16 v0, v36

    move/from16 v1, v41

    move/from16 v2, v40

    invoke-static {v0, v1, v2}, Lcom/thinkware/sundo/inavi3d/Inavi;->setCrossNameInfo(Ljava/lang/String;II)V

    .line 1879
    :goto_16
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->speedview4:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SpeedView;

    if-eqz v5, :cond_2a

    .line 1880
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->speedview4:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SpeedView;

    sget-boolean v9, Lcom/thinkware/sundo/inavi3d/Inavi;->mIsDrSpeed:Z

    invoke-virtual {v5, v9}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SpeedView;->setDRSpeed(Z)V

    .line 1881
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->speedview4:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SpeedView;

    move-object/from16 v0, v16

    move/from16 v1, v26

    invoke-virtual {v5, v0, v1}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SpeedView;->setUpdate(Lcom/thinkware/sundo/remoteTBT/TBTGuide;I)V

    .line 1882
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->speedview4:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SpeedView;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SpeedView;->postInvalidate()V

    .line 1885
    :cond_2a
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneView4:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;

    if-eqz v5, :cond_2b

    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneLayout4:Landroid/widget/RelativeLayout;

    if-eqz v5, :cond_2b

    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->sectionView4:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;

    if-eqz v5, :cond_2b

    .line 1886
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneView4:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;

    move-object/from16 v0, v16

    invoke-virtual {v5, v0}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;->setUpdate(Lcom/thinkware/sundo/remoteTBT/TBTGuide;)Z

    move-result v5

    if-eqz v5, :cond_5a

    .line 1887
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneLayout4:Landroid/widget/RelativeLayout;

    const/4 v9, 0x0

    invoke-static {v5, v9}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    .line 1888
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneView4:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;

    const/4 v9, 0x1

    invoke-virtual {v5, v9}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;->setClickable(Z)V

    .line 1891
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v5

    move-object/from16 v0, v16

    invoke-virtual {v5, v0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->startAutoArMode(Lcom/thinkware/sundo/remoteTBT/TBTGuide;)V

    .line 1893
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneView4:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;->getSafeZone()Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZone;

    move-result-object v10

    .line 1894
    .restart local v10    # "sfZone":Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZone;
    if-eqz v10, :cond_2b

    .line 1895
    invoke-virtual {v10}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZone;->getSafeSectionNoRoute()Z

    move-result v5

    if-eqz v5, :cond_58

    .line 1896
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->sectionView4:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;

    move-object/from16 v0, v16

    invoke-virtual {v5, v10, v0}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;->SetSectionData(Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZone;Lcom/thinkware/sundo/remoteTBT/TBTGuide;)V

    .line 1897
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->sectionView4:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;

    const/4 v9, 0x0

    invoke-static {v5, v9}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    .line 1898
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->sectionView4:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;

    const/4 v9, 0x1

    invoke-virtual {v5, v9}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;->setClickable(Z)V

    .line 1926
    .end local v10    # "sfZone":Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZone;
    :cond_2b
    :goto_17
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->turnAreaView4:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;

    if-eqz v5, :cond_2c

    .line 1927
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->turnAreaView4:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;

    sget-boolean v9, Lcom/thinkware/sundo/inavi3d/Inavi;->viaStatus:Z

    invoke-virtual {v5, v9}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;->setViaStatus(Z)V

    .line 1928
    sget-boolean v5, Lcom/thinkware/sundo/inavi3d/Inavi;->viaStatus:Z

    if-eqz v5, :cond_5b

    .line 1929
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->turnAreaView4:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;

    move-object/from16 v0, v16

    invoke-virtual {v5, v0}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;->SetViaJump(Lcom/thinkware/sundo/remoteTBT/TBTGuide;)V

    .line 1930
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->turnAreaView4:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;

    const/4 v9, 0x0

    invoke-static {v5, v9}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    .line 1931
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->turnAreaView4:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;

    const/4 v9, 0x1

    invoke-virtual {v5, v9}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;->setClickable(Z)V

    .line 1943
    :cond_2c
    :goto_18
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->getInstance()Lcom/thinkware/sundo/inavi3d/InaviConfig;

    move-result-object v5

    const/16 v9, 0x79

    invoke-virtual {v5, v9}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->CNaviConfigGet(I)I

    move-result v5

    if-nez v5, :cond_5d

    .line 1944
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->crossWayView4:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/CrossWayView;

    const/4 v9, 0x4

    invoke-static {v5, v9}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    .line 1971
    .end local v24    # "bTurnViewIsShwing":Z
    .end local v36    # "strCross":Ljava/lang/String;
    .end local v40    # "textSize":I
    .end local v41    # "textcolor":I
    :cond_2d
    :goto_19
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->mGPSViewMgr:Lcom/thinkware/sundo/inavi3d/GPSViewManager;

    if-eqz v5, :cond_2e

    .line 1972
    sget-object v15, Lcom/thinkware/sundo/inavi3d/Inavi;->mGPSViewMgr:Lcom/thinkware/sundo/inavi3d/GPSViewManager;

    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->mMMCInfo:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    iget-short v0, v5, Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;->heading:S

    move/from16 v17, v0

    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->mMMCInfo:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    iget v5, v5, Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;->lon:I

    int-to-long v0, v5

    move-wide/from16 v18, v0

    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->mMMCInfo:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    iget v5, v5, Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;->lat:I

    int-to-long v0, v5

    move-wide/from16 v20, v0

    invoke-virtual/range {v15 .. v21}, Lcom/thinkware/sundo/inavi3d/GPSViewManager;->setUpdate(Lcom/thinkware/sundo/remoteTBT/TBTGuide;SJJ)V

    .line 1976
    :cond_2e
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v5

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->is_support_myroute()Z

    move-result v5

    const/4 v9, 0x1

    if-ne v5, v9, :cond_31

    .line 1977
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/RouteCompareManager;->getInstance()Lcom/thinkware/sundo/inavi3d/RouteCompareManager;

    move-result-object v5

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3d/RouteCompareManager;->isCheckRun()Z

    move-result v5

    const/4 v9, 0x1

    if-ne v5, v9, :cond_5f

    .line 1978
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/RouteCompareManager;->getInstance()Lcom/thinkware/sundo/inavi3d/RouteCompareManager;

    move-result-object v5

    move-object/from16 v0, v16

    iget v9, v0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->mCurrentSpeed:I

    invoke-virtual {v5, v9}, Lcom/thinkware/sundo/inavi3d/RouteCompareManager;->setSpeed(I)V

    .line 1981
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->mMMCInfo:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    if-eqz v5, :cond_2f

    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->mMMCInfo:Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;

    iget-short v5, v5, Lcom/tw/mapmatch/remote/mapmatch/MMCInfo;->status:S

    const/4 v9, 0x1

    if-ne v5, v9, :cond_2f

    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->mGPSInfo:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    if-eqz v5, :cond_2f

    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->mGPSInfo:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    iget-char v5, v5, Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;->Status:C

    const/16 v9, 0x41

    if-ne v5, v9, :cond_2f

    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->mGPSInfo:Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;

    iget-byte v5, v5, Lcom/tw/mapmatch/remote/mapmatch/GPSInfo;->Dimension:B

    const/16 v9, 0x33

    if-ne v5, v9, :cond_2f

    .line 1983
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/RouteCompareManager;->getInstance()Lcom/thinkware/sundo/inavi3d/RouteCompareManager;

    move-result-object v5

    const/4 v9, 0x1

    invoke-virtual {v5, v9}, Lcom/thinkware/sundo/inavi3d/RouteCompareManager;->setGpsFix(Z)V

    .line 1986
    :cond_2f
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/RouteCompareManager;->getInstance()Lcom/thinkware/sundo/inavi3d/RouteCompareManager;

    move-result-object v5

    const/4 v9, 0x0

    invoke-virtual {v5, v9}, Lcom/thinkware/sundo/inavi3d/RouteCompareManager;->checkTrafficFix(Z)V

    .line 1988
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/RouteCompareManager;->getInstance()Lcom/thinkware/sundo/inavi3d/RouteCompareManager;

    move-result-object v5

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3d/RouteCompareManager;->checkRouteComparePopupShow()V

    .line 1996
    :cond_30
    :goto_1a
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/RouteCompareManager;->getInstance()Lcom/thinkware/sundo/inavi3d/RouteCompareManager;

    move-result-object v5

    move-object/from16 v0, v16

    iget v9, v0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->mCurrentSpeed:I

    invoke-virtual {v5, v9}, Lcom/thinkware/sundo/inavi3d/RouteCompareManager;->setSpeedMerge(I)V

    .line 2000
    :cond_31
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v5

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->isTruckDevice()Z

    move-result v5

    const/4 v9, 0x1

    if-ne v5, v9, :cond_61

    .line 2001
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->getInstance()Lcom/thinkware/sundo/inavi3d/InaviConfig;

    move-result-object v5

    const/16 v9, 0x2a

    invoke-virtual {v5, v9}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->CNaviConfigGet(I)I

    move-result v5

    const/4 v9, 0x3

    if-ne v5, v9, :cond_60

    .line 2002
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->tbtguide:Lcom/thinkware/sundo/remoteTBT/TBTGuide;

    const/4 v9, 0x1

    iput-boolean v9, v5, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->isDoroJibunShake:Z

    .line 2010
    :goto_1b
    :try_start_1
    move/from16 v0, v26

    move-object/from16 v1, v16

    iput v0, v1, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->mCurrentSpeed:I

    .line 2011
    move/from16 v0, v26

    move-object/from16 v1, v28

    iput v0, v1, Lcom/thinkware/sundo/remoteHUD/HUDGuide;->mCurrentSpeed:I

    .line 2013
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    move-object/from16 v0, v16

    invoke-interface {v5, v0}, Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;->SetTBTGuide(Lcom/thinkware/sundo/remoteTBT/TBTGuide;)V

    .line 2014
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    move-object/from16 v0, v28

    invoke-interface {v5, v0}, Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;->SetHUDGuide(Lcom/thinkware/sundo/remoteHUD/HUDGuide;)V

    .line 2015
    invoke-virtual/range {v29 .. v29}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->SetHudAdasInfo()V
    :try_end_1
    .catch Landroid/os/RemoteException; {:try_start_1 .. :try_end_1} :catch_2

    .line 2025
    :goto_1c
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v5

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->checkFVSATLCA()V

    .line 2028
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v5

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->checkChangeAutoLiveRoute()V

    goto/16 :goto_0

    .line 1200
    .end local v16    # "tbtGuide":Lcom/thinkware/sundo/remoteTBT/TBTGuide;
    .end local v22    # "bHideTurnAndDirInfoView":Z
    .end local v23    # "bRunningLaneAndTurn":Z
    .end local v26    # "currentSpeed":I
    .end local v28    # "hudGuide":Lcom/thinkware/sundo/remoteHUD/HUDGuide;
    .end local v33    # "nLaneAndTurnMode":I
    .restart local v38    # "strRoadName":Ljava/lang/String;
    :catch_0
    move-exception v27

    .line 1202
    .local v27, "e":Ljava/io/UnsupportedEncodingException;
    invoke-virtual/range {v27 .. v27}, Ljava/io/UnsupportedEncodingException;->printStackTrace()V

    goto/16 :goto_2

    .line 1217
    .end local v27    # "e":Ljava/io/UnsupportedEncodingException;
    .end local v38    # "strRoadName":Ljava/lang/String;
    .restart local v23    # "bRunningLaneAndTurn":Z
    :cond_32
    const/16 v23, 0x0

    goto/16 :goto_3

    .line 1222
    .restart local v33    # "nLaneAndTurnMode":I
    :cond_33
    const/16 v22, 0x0

    goto/16 :goto_4

    .line 1248
    .restart local v16    # "tbtGuide":Lcom/thinkware/sundo/remoteTBT/TBTGuide;
    .restart local v22    # "bHideTurnAndDirInfoView":Z
    .restart local v26    # "currentSpeed":I
    .restart local v28    # "hudGuide":Lcom/thinkware/sundo/remoteHUD/HUDGuide;
    :cond_34
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->courseRightViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/DriveCourseCurrentViewAR;

    const/4 v9, 0x0

    invoke-virtual {v5, v9}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/DriveCourseCurrentViewAR;->setUpdate(Lcom/thinkware/sundo/remoteTBT/TBTGuide;)V

    .line 1249
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->courseRightViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/DriveCourseCurrentViewAR;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/DriveCourseCurrentViewAR;->postInvalidate()V

    goto/16 :goto_5

    .line 1265
    :cond_35
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->courseViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/DriveCourseViewAR;

    const/4 v9, 0x0

    invoke-static {v5, v9}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    .line 1266
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->driveCourseViewRouteCancelButtonAR:Landroid/widget/Button;

    const/16 v9, 0x8

    invoke-static {v5, v9}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    .line 1267
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->courseViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/DriveCourseViewAR;

    move-object/from16 v0, v16

    invoke-virtual {v5, v0}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/DriveCourseViewAR;->setUpdate(Lcom/thinkware/sundo/remoteTBT/TBTGuide;)V

    .line 1268
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->courseViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/DriveCourseViewAR;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/DriveCourseViewAR;->postInvalidate()V

    goto/16 :goto_6

    .line 1303
    .restart local v30    # "ieve":Lcom/thinkware/sundo/ieve/IEVE;
    :cond_36
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->turnAreaViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaViewAR;

    move-object/from16 v0, v16

    invoke-virtual {v5, v0}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaViewAR;->setUpdate(Lcom/thinkware/sundo/remoteTBT/TBTGuide;)Z

    move-result v5

    if-eqz v5, :cond_37

    .line 1304
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->turnAreaViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaViewAR;

    const/4 v9, 0x0

    invoke-static {v5, v9}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    .line 1308
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v5

    move-object/from16 v0, v16

    invoke-virtual {v5, v0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->checkFirstSimpleMapZoom(Lcom/thinkware/sundo/remoteTBT/TBTGuide;)V

    goto/16 :goto_7

    .line 1311
    :cond_37
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->turnAreaViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaViewAR;

    const/4 v9, 0x4

    invoke-static {v5, v9}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    goto/16 :goto_7

    .line 1399
    .end local v30    # "ieve":Lcom/thinkware/sundo/ieve/IEVE;
    .restart local v7    # "safeZoneType":I
    .restart local v8    # "speedlimit":I
    :cond_38
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneLimitSpeedViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneLimitSpeedViewAR;

    const/4 v9, 0x4

    invoke-static {v5, v9}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    goto/16 :goto_8

    .line 1410
    .restart local v6    # "nDrawType":I
    .restart local v34    # "nRemaindist":I
    :cond_39
    const/16 v5, 0x136

    move/from16 v0, v34

    if-gt v0, v5, :cond_16

    .line 1411
    const/4 v6, 0x1

    goto/16 :goto_9

    .line 1421
    :cond_3a
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneMiniViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneMiniViewAR;

    const/4 v9, 0x4

    invoke-static {v5, v9}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    goto/16 :goto_a

    .line 1428
    .end local v6    # "nDrawType":I
    .end local v34    # "nRemaindist":I
    :cond_3b
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v5

    const/4 v9, 0x0

    invoke-virtual {v5, v9}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->stopAutoArMode(Z)V

    .line 1430
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneTypeViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneTypeViewAR;

    const/4 v9, 0x4

    invoke-static {v5, v9}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    .line 1431
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneDistanceViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneDistanceViewAR;

    const/4 v9, 0x4

    invoke-static {v5, v9}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    .line 1432
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneMiniViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneMiniViewAR;

    const/4 v9, 0x4

    invoke-static {v5, v9}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    .line 1433
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneViewAR;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneViewAR;->GetNextDistance()I

    move-result v13

    .line 1434
    .local v13, "nNextDistance":I
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneViewAR;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneViewAR;->IsPassedCamera()Z

    move-result v5

    const/4 v9, 0x1

    if-ne v5, v9, :cond_3c

    if-lez v13, :cond_3c

    .line 1435
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneMiniViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneMiniViewAR;

    move-object/from16 v0, v16

    invoke-virtual {v5, v0, v13}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneMiniViewAR;->setData(Lcom/thinkware/sundo/remoteTBT/TBTGuide;I)V

    .line 1436
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneMiniViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneMiniViewAR;

    const/4 v9, 0x0

    invoke-static {v5, v9}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    .line 1441
    :goto_1d
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneViewAR;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneViewAR;->GetPassedSpeed()I

    move-result v12

    .line 1442
    .local v12, "nPassedSpeed":I
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneViewAR;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneViewAR;->IsPassedOver()Z

    move-result v14

    .line 1443
    .local v14, "isOver":Z
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneViewAR;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneViewAR;->IsPassedCamera()Z

    move-result v5

    const/4 v9, 0x1

    if-ne v5, v9, :cond_17

    if-lez v12, :cond_17

    .line 1445
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneLimitSpeedViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneLimitSpeedViewAR;

    invoke-virtual {v5, v12, v14}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneLimitSpeedViewAR;->updateData(IZ)V

    .line 1446
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneLimitSpeedViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneLimitSpeedViewAR;

    const/4 v9, 0x0

    invoke-static {v5, v9}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    goto/16 :goto_a

    .line 1438
    .end local v12    # "nPassedSpeed":I
    .end local v14    # "isOver":Z
    :cond_3c
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneLimitSpeedViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneLimitSpeedViewAR;

    const/4 v9, 0x4

    invoke-static {v5, v9}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    .line 1439
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneMiniViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneMiniViewAR;

    const/4 v9, 0x0

    invoke-virtual {v5, v9}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneMiniViewAR;->setIsNextSafeZone(Z)V

    goto :goto_1d

    .line 1452
    .end local v7    # "safeZoneType":I
    .end local v8    # "speedlimit":I
    .end local v13    # "nNextDistance":I
    :cond_3d
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v5

    const/4 v9, 0x0

    invoke-virtual {v5, v9}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->stopAutoArMode(Z)V

    .line 1454
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneTypeViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneTypeViewAR;

    const/4 v9, 0x4

    invoke-static {v5, v9}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    .line 1455
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneLimitSpeedViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneLimitSpeedViewAR;

    const/4 v9, 0x4

    invoke-static {v5, v9}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    .line 1456
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneDistanceViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneDistanceViewAR;

    const/4 v9, 0x4

    invoke-static {v5, v9}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    .line 1457
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneMiniViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneMiniViewAR;

    const/4 v9, 0x4

    invoke-static {v5, v9}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    goto/16 :goto_a

    .line 1490
    :cond_3e
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->progressBarLayoutAR:Landroid/widget/RelativeLayout;

    const/16 v9, 0x8

    invoke-static {v5, v9}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    .line 1491
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->progressBarAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TrafficProgressBar;

    const/16 v9, 0x8

    invoke-static {v5, v9}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    goto/16 :goto_b

    .line 1532
    :cond_3f
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->progressBarLayout:Landroid/widget/RelativeLayout;

    const/16 v9, 0x8

    invoke-static {v5, v9}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    .line 1533
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->progressBar:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TrafficProgressBar;

    const/16 v9, 0x8

    invoke-static {v5, v9}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    .line 1534
    const/4 v5, 0x0

    invoke-static {v5}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetViewMargin(Z)V

    goto/16 :goto_c

    .line 1579
    .restart local v10    # "sfZone":Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZone;
    :cond_40
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->sectionView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;

    const/4 v9, 0x4

    invoke-static {v5, v9}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    .line 1580
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->sectionView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;

    const/4 v9, 0x0

    invoke-virtual {v5, v9}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;->setClickable(Z)V

    .line 1581
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;->GetPassedSpeed()I

    move-result v12

    .line 1582
    .restart local v12    # "nPassedSpeed":I
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;->GetNextDistance()I

    move-result v13

    .line 1583
    .restart local v13    # "nNextDistance":I
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;->IsPassedOver()Z

    move-result v14

    .line 1584
    .restart local v14    # "isOver":Z
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;->IsPassedCamera()Z

    move-result v5

    const/4 v9, 0x1

    if-ne v5, v9, :cond_41

    .line 1585
    sget-object v9, Lcom/thinkware/sundo/inavi3d/Inavi;->safePassedView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZonePassedView;

    move-object/from16 v11, v16

    invoke-virtual/range {v9 .. v14}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZonePassedView;->SetData(Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZone;Lcom/thinkware/sundo/remoteTBT/TBTGuide;IIZ)V

    .line 1586
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safePassedView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZonePassedView;

    const/4 v9, 0x0

    invoke-static {v5, v9}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    goto/16 :goto_d

    .line 1588
    :cond_41
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safePassedView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZonePassedView;

    const/16 v9, 0x8

    invoke-static {v5, v9}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    goto/16 :goto_d

    .line 1594
    .end local v10    # "sfZone":Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZone;
    .end local v12    # "nPassedSpeed":I
    .end local v13    # "nNextDistance":I
    .end local v14    # "isOver":Z
    :cond_42
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneLayout:Landroid/widget/RelativeLayout;

    const/4 v9, 0x4

    invoke-static {v5, v9}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    .line 1595
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;

    const/4 v9, 0x0

    invoke-virtual {v5, v9}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;->setClickable(Z)V

    .line 1596
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->sectionView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;

    const/4 v9, 0x0

    invoke-virtual {v5, v9}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;->setClickable(Z)V

    .line 1599
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v5

    const/4 v9, 0x0

    invoke-virtual {v5, v9}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->stopAutoArMode(Z)V

    goto/16 :goto_d

    .line 1613
    :cond_43
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->turnAreaView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;

    move-object/from16 v0, v16

    invoke-virtual {v5, v0}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;->setUpdate(Lcom/thinkware/sundo/remoteTBT/TBTGuide;)Z

    move-result v5

    if-eqz v5, :cond_44

    .line 1614
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->turnAreaView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;

    const/4 v9, 0x0

    invoke-static {v5, v9}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    .line 1615
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->turnAreaView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;

    const/4 v9, 0x1

    invoke-virtual {v5, v9}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;->setClickable(Z)V

    goto/16 :goto_e

    .line 1617
    :cond_44
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->turnAreaView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;

    const/16 v9, 0x8

    invoke-static {v5, v9}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    .line 1618
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->turnAreaView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;

    const/4 v9, 0x0

    invoke-virtual {v5, v9}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;->setClickable(Z)V

    goto/16 :goto_e

    .line 1626
    :cond_45
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->crossWayView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/CrossWayView;

    if-eqz v5, :cond_21

    .line 1627
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->crossWayView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/CrossWayView;

    move-object/from16 v0, v16

    invoke-virtual {v5, v0}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/CrossWayView;->setUpdate(Lcom/thinkware/sundo/remoteTBT/TBTGuide;)Z

    move-result v5

    if-eqz v5, :cond_46

    .line 1642
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->crossWayView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/CrossWayView;

    const/4 v9, 0x0

    invoke-static {v5, v9}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    goto/16 :goto_f

    .line 1645
    :cond_46
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->crossWayView:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/CrossWayView;

    const/4 v9, 0x4

    invoke-static {v5, v9}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    goto/16 :goto_f

    .line 1672
    .restart local v10    # "sfZone":Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZone;
    :cond_47
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->sectionView2:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;

    const/4 v9, 0x4

    invoke-static {v5, v9}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    .line 1673
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->sectionView2:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;

    const/4 v9, 0x0

    invoke-virtual {v5, v9}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;->setClickable(Z)V

    .line 1674
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneView2:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;->GetPassedSpeed()I

    move-result v12

    .line 1675
    .restart local v12    # "nPassedSpeed":I
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneView2:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;->GetNextDistance()I

    move-result v13

    .line 1676
    .restart local v13    # "nNextDistance":I
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneView2:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;->IsPassedOver()Z

    move-result v14

    .line 1677
    .restart local v14    # "isOver":Z
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneView2:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;->IsPassedCamera()Z

    move-result v5

    const/4 v9, 0x1

    if-ne v5, v9, :cond_48

    .line 1678
    sget-object v9, Lcom/thinkware/sundo/inavi3d/Inavi;->safePassedView2:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZonePassedView;

    move-object/from16 v11, v16

    invoke-virtual/range {v9 .. v14}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZonePassedView;->SetData(Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZone;Lcom/thinkware/sundo/remoteTBT/TBTGuide;IIZ)V

    .line 1679
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safePassedView2:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZonePassedView;

    const/4 v9, 0x0

    invoke-static {v5, v9}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    goto/16 :goto_10

    .line 1681
    :cond_48
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safePassedView2:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZonePassedView;

    const/16 v9, 0x8

    invoke-static {v5, v9}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    goto/16 :goto_10

    .line 1687
    .end local v10    # "sfZone":Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZone;
    .end local v12    # "nPassedSpeed":I
    .end local v13    # "nNextDistance":I
    .end local v14    # "isOver":Z
    :cond_49
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneLayout2:Landroid/widget/RelativeLayout;

    const/4 v9, 0x4

    invoke-static {v5, v9}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    .line 1688
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneView2:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;

    const/4 v9, 0x0

    invoke-virtual {v5, v9}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;->setClickable(Z)V

    .line 1689
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->sectionView2:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;

    const/4 v9, 0x0

    invoke-virtual {v5, v9}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;->setClickable(Z)V

    .line 1692
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v5

    const/4 v9, 0x0

    invoke-virtual {v5, v9}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->stopAutoArMode(Z)V

    goto/16 :goto_10

    .line 1709
    .restart local v24    # "bTurnViewIsShwing":Z
    :cond_4a
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->turnAreaView2:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;

    move-object/from16 v0, v16

    invoke-virtual {v5, v0}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;->setUpdate(Lcom/thinkware/sundo/remoteTBT/TBTGuide;)Z

    move-result v5

    if-eqz v5, :cond_4b

    .line 1710
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->turnAreaView2:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;

    const/4 v9, 0x0

    invoke-static {v5, v9}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    .line 1711
    const/16 v24, 0x1

    .line 1712
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->turnAreaView2:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;

    const/4 v9, 0x1

    invoke-virtual {v5, v9}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;->setClickable(Z)V

    goto/16 :goto_11

    .line 1714
    :cond_4b
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->turnAreaView2:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;

    const/4 v9, 0x4

    invoke-static {v5, v9}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    .line 1715
    const/16 v24, 0x0

    .line 1716
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->turnAreaView2:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;

    const/4 v9, 0x0

    invoke-virtual {v5, v9}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;->setClickable(Z)V

    goto/16 :goto_11

    .line 1723
    :cond_4c
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->crossWayView2:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/CrossWayView;

    if-eqz v5, :cond_25

    .line 1726
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->crossWayView2:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/CrossWayView;

    const/16 v9, 0x8

    invoke-static {v5, v9}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    goto/16 :goto_12

    .line 1762
    .restart local v10    # "sfZone":Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZone;
    :cond_4d
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->sectionView3:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;

    const/4 v9, 0x4

    invoke-static {v5, v9}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    .line 1763
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->sectionView3:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;

    const/4 v9, 0x0

    invoke-virtual {v5, v9}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;->setClickable(Z)V

    .line 1764
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneView3:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;->GetPassedSpeed()I

    move-result v12

    .line 1765
    .restart local v12    # "nPassedSpeed":I
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneView3:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;->GetNextDistance()I

    move-result v13

    .line 1766
    .restart local v13    # "nNextDistance":I
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneView3:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;->IsPassedOver()Z

    move-result v14

    .line 1767
    .restart local v14    # "isOver":Z
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneView3:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;->IsPassedCamera()Z

    move-result v5

    const/4 v9, 0x1

    if-ne v5, v9, :cond_4e

    .line 1768
    sget-object v9, Lcom/thinkware/sundo/inavi3d/Inavi;->safePassedView3:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZonePassedView;

    move-object/from16 v11, v16

    invoke-virtual/range {v9 .. v14}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZonePassedView;->SetData(Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZone;Lcom/thinkware/sundo/remoteTBT/TBTGuide;IIZ)V

    .line 1769
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safePassedView3:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZonePassedView;

    const/4 v9, 0x0

    invoke-static {v5, v9}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    goto/16 :goto_13

    .line 1771
    :cond_4e
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safePassedView3:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZonePassedView;

    const/16 v9, 0x8

    invoke-static {v5, v9}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    goto/16 :goto_13

    .line 1777
    .end local v10    # "sfZone":Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZone;
    .end local v12    # "nPassedSpeed":I
    .end local v13    # "nNextDistance":I
    .end local v14    # "isOver":Z
    :cond_4f
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneLayout3:Landroid/widget/RelativeLayout;

    const/4 v9, 0x4

    invoke-static {v5, v9}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    .line 1778
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneView3:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;

    const/4 v9, 0x0

    invoke-virtual {v5, v9}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;->setClickable(Z)V

    .line 1779
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->sectionView3:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;

    const/4 v9, 0x0

    invoke-virtual {v5, v9}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;->setClickable(Z)V

    .line 1782
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v5

    const/4 v9, 0x0

    invoke-virtual {v5, v9}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->stopAutoArMode(Z)V

    goto/16 :goto_13

    .line 1801
    :cond_50
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->turnAreaView3:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;

    move-object/from16 v0, v16

    invoke-virtual {v5, v0}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;->setUpdate(Lcom/thinkware/sundo/remoteTBT/TBTGuide;)Z

    move-result v5

    if-eqz v5, :cond_51

    .line 1802
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->turnAreaView3:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;

    const/4 v9, 0x0

    invoke-static {v5, v9}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    .line 1803
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->turnAreaView3:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;

    const/4 v9, 0x1

    invoke-virtual {v5, v9}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;->setClickable(Z)V

    goto/16 :goto_14

    .line 1805
    :cond_51
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->turnAreaView3:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;

    const/16 v9, 0x8

    invoke-static {v5, v9}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    .line 1806
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->turnAreaView3:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;

    const/4 v9, 0x0

    invoke-virtual {v5, v9}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;->setClickable(Z)V

    goto/16 :goto_14

    .line 1814
    :cond_52
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->crossWayView3:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/CrossWayView;

    if-eqz v5, :cond_29

    .line 1815
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->crossWayView3:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/CrossWayView;

    move-object/from16 v0, v16

    invoke-virtual {v5, v0}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/CrossWayView;->setUpdate(Lcom/thinkware/sundo/remoteTBT/TBTGuide;)Z

    move-result v5

    if-eqz v5, :cond_53

    .line 1816
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->crossWayView3:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/CrossWayView;

    const/4 v9, 0x0

    invoke-static {v5, v9}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    .line 1817
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->crossWayView3:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/CrossWayView;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/CrossWayView;->getWidth()I

    move-result v5

    sget-object v9, Lcom/thinkware/sundo/inavi3d/Inavi;->crossname:Landroid/widget/Button;

    invoke-virtual {v9}, Landroid/widget/Button;->getWidth()I

    move-result v9

    sub-int v42, v5, v9

    .line 1818
    .local v42, "viewWidth":I
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->crossWayView3:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/CrossWayView;

    const/4 v9, 0x1

    move/from16 v0, v42

    invoke-virtual {v5, v0, v9}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/CrossWayView;->setViewWidth(IZ)V

    goto/16 :goto_15

    .line 1820
    .end local v42    # "viewWidth":I
    :cond_53
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->crossWayView3:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/CrossWayView;

    const/16 v9, 0x8

    invoke-static {v5, v9}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    goto/16 :goto_15

    .line 1838
    .restart local v36    # "strCross":Ljava/lang/String;
    .restart local v40    # "textSize":I
    .restart local v41    # "textcolor":I
    :cond_54
    :try_start_2
    new-instance v37, Ljava/lang/String;

    move-object/from16 v0, v16

    iget-object v5, v0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->crossDirNm:[B

    const-string v9, "EUC-KR"

    move-object/from16 v0, v37

    invoke-direct {v0, v5, v9}, Ljava/lang/String;-><init>([BLjava/lang/String;)V
    :try_end_2
    .catch Ljava/io/UnsupportedEncodingException; {:try_start_2 .. :try_end_2} :catch_1

    .line 1839
    .end local v36    # "strCross":Ljava/lang/String;
    .local v37, "strCross":Ljava/lang/String;
    const/16 v32, 0x0

    .line 1848
    .local v32, "nEnd":I
    :try_start_3
    invoke-virtual/range {v37 .. v37}, Ljava/lang/String;->trim()Ljava/lang/String;
    :try_end_3
    .catch Ljava/io/UnsupportedEncodingException; {:try_start_3 .. :try_end_3} :catch_3

    move-result-object v36

    .line 1857
    .end local v37    # "strCross":Ljava/lang/String;
    .restart local v36    # "strCross":Ljava/lang/String;
    :try_start_4
    invoke-virtual/range {v36 .. v36}, Ljava/lang/String;->length()I

    move-result v31

    .line 1858
    .local v31, "len":I
    const/4 v5, 0x6

    move/from16 v0, v31

    if-gt v0, v5, :cond_55

    .line 1859
    const/16 v40, 0x16

    .line 1867
    :goto_1e
    const/16 v5, 0x99

    const/16 v9, 0x91

    const/16 v11, 0x99

    invoke-static {v5, v9, v11}, Landroid/graphics/Color;->rgb(III)I
    :try_end_4
    .catch Ljava/io/UnsupportedEncodingException; {:try_start_4 .. :try_end_4} :catch_1

    move-result v41

    .line 1873
    .end local v31    # "len":I
    .end local v32    # "nEnd":I
    :goto_1f
    move-object/from16 v0, v36

    move/from16 v1, v41

    move/from16 v2, v40

    invoke-static {v0, v1, v2}, Lcom/thinkware/sundo/inavi3d/Inavi;->setCrossNameInfo(Ljava/lang/String;II)V

    goto/16 :goto_16

    .line 1860
    .restart local v31    # "len":I
    .restart local v32    # "nEnd":I
    :cond_55
    const/4 v5, 0x7

    move/from16 v0, v31

    if-ne v0, v5, :cond_56

    .line 1861
    const/16 v40, 0x14

    goto :goto_1e

    .line 1863
    :cond_56
    const/16 v40, 0x14

    .line 1864
    :try_start_5
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x0

    const/4 v11, 0x5

    move-object/from16 v0, v36

    invoke-virtual {v0, v9, v11}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v5, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v9, "..."

    invoke-virtual {v5, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    :try_end_5
    .catch Ljava/io/UnsupportedEncodingException; {:try_start_5 .. :try_end_5} :catch_1

    move-result-object v36

    goto :goto_1e

    .line 1869
    .end local v31    # "len":I
    .end local v32    # "nEnd":I
    :catch_1
    move-exception v27

    .line 1871
    .restart local v27    # "e":Ljava/io/UnsupportedEncodingException;
    :goto_20
    invoke-virtual/range {v27 .. v27}, Ljava/io/UnsupportedEncodingException;->printStackTrace()V

    goto :goto_1f

    .line 1876
    .end local v27    # "e":Ljava/io/UnsupportedEncodingException;
    :cond_57
    move-object/from16 v0, v36

    move/from16 v1, v41

    move/from16 v2, v40

    invoke-static {v0, v1, v2}, Lcom/thinkware/sundo/inavi3d/Inavi;->setCrossNameInfo(Ljava/lang/String;II)V

    goto/16 :goto_16

    .line 1900
    .restart local v10    # "sfZone":Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZone;
    :cond_58
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->sectionView4:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;

    const/4 v9, 0x4

    invoke-static {v5, v9}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    .line 1901
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->sectionView4:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;

    const/4 v9, 0x0

    invoke-virtual {v5, v9}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;->setClickable(Z)V

    .line 1902
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneView4:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;->GetPassedSpeed()I

    move-result v12

    .line 1903
    .restart local v12    # "nPassedSpeed":I
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneView4:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;->GetNextDistance()I

    move-result v13

    .line 1904
    .restart local v13    # "nNextDistance":I
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneView4:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;->IsPassedOver()Z

    move-result v14

    .line 1905
    .restart local v14    # "isOver":Z
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneView4:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;->IsPassedCamera()Z

    move-result v5

    const/4 v9, 0x1

    if-ne v5, v9, :cond_59

    .line 1906
    sget-object v9, Lcom/thinkware/sundo/inavi3d/Inavi;->safePassedView4:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZonePassedView;

    move-object/from16 v11, v16

    invoke-virtual/range {v9 .. v14}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZonePassedView;->SetData(Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZone;Lcom/thinkware/sundo/remoteTBT/TBTGuide;IIZ)V

    .line 1907
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safePassedView4:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZonePassedView;

    const/4 v9, 0x0

    invoke-static {v5, v9}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    goto/16 :goto_17

    .line 1909
    :cond_59
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safePassedView4:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZonePassedView;

    const/16 v9, 0x8

    invoke-static {v5, v9}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    goto/16 :goto_17

    .line 1915
    .end local v10    # "sfZone":Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZone;
    .end local v12    # "nPassedSpeed":I
    .end local v13    # "nNextDistance":I
    .end local v14    # "isOver":Z
    :cond_5a
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneLayout4:Landroid/widget/RelativeLayout;

    const/4 v9, 0x4

    invoke-static {v5, v9}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    .line 1916
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneView4:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;

    const/4 v9, 0x0

    invoke-virtual {v5, v9}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneView;->setClickable(Z)V

    .line 1917
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->sectionView4:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;

    const/4 v9, 0x0

    invoke-virtual {v5, v9}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneSectionView;->setClickable(Z)V

    .line 1920
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v5

    const/4 v9, 0x0

    invoke-virtual {v5, v9}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->stopAutoArMode(Z)V

    goto/16 :goto_17

    .line 1934
    :cond_5b
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->turnAreaView4:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;

    move-object/from16 v0, v16

    invoke-virtual {v5, v0}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;->setUpdate(Lcom/thinkware/sundo/remoteTBT/TBTGuide;)Z

    move-result v5

    if-eqz v5, :cond_5c

    .line 1935
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->turnAreaView4:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;

    const/4 v9, 0x0

    invoke-static {v5, v9}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    .line 1936
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->turnAreaView4:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;

    const/4 v9, 0x1

    invoke-virtual {v5, v9}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;->setClickable(Z)V

    goto/16 :goto_18

    .line 1938
    :cond_5c
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->turnAreaView4:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;

    const/16 v9, 0x8

    invoke-static {v5, v9}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    .line 1939
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->turnAreaView4:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;

    const/4 v9, 0x0

    invoke-virtual {v5, v9}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/TurnAreaView;->setClickable(Z)V

    goto/16 :goto_18

    .line 1946
    :cond_5d
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->crossWayView4:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/CrossWayView;

    if-eqz v5, :cond_2d

    .line 1947
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->crossWayView4:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/CrossWayView;

    move-object/from16 v0, v16

    invoke-virtual {v5, v0}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/CrossWayView;->setUpdate(Lcom/thinkware/sundo/remoteTBT/TBTGuide;)Z

    move-result v5

    if-eqz v5, :cond_5e

    .line 1961
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->crossWayView4:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/CrossWayView;

    const/4 v9, 0x0

    invoke-static {v5, v9}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    goto/16 :goto_19

    .line 1964
    :cond_5e
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->crossWayView4:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/CrossWayView;

    const/4 v9, 0x4

    invoke-static {v5, v9}, Lcom/thinkware/sundo/inavi3d/Inavi;->SetVisible(Landroid/view/View;I)V

    goto/16 :goto_19

    .line 1989
    .end local v24    # "bTurnViewIsShwing":Z
    .end local v36    # "strCross":Ljava/lang/String;
    .end local v40    # "textSize":I
    .end local v41    # "textcolor":I
    :cond_5f
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/RouteCompareManager;->getInstance()Lcom/thinkware/sundo/inavi3d/RouteCompareManager;

    move-result-object v5

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3d/RouteCompareManager;->isMyRouteEditMode()Z

    move-result v5

    if-eqz v5, :cond_30

    .line 1990
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/RouteCompareManager;->getInstance()Lcom/thinkware/sundo/inavi3d/RouteCompareManager;

    move-result-object v5

    invoke-virtual {v5}, Lcom/thinkware/sundo/inavi3d/RouteCompareManager;->checkMyRouteEditMode()V

    goto/16 :goto_1a

    .line 2004
    :cond_60
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->tbtguide:Lcom/thinkware/sundo/remoteTBT/TBTGuide;

    const/4 v9, 0x0

    iput-boolean v9, v5, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->isDoroJibunShake:Z

    goto/16 :goto_1b

    .line 2006
    :cond_61
    sget-object v5, Lcom/thinkware/sundo/inavi3d/Inavi;->tbtguide:Lcom/thinkware/sundo/remoteTBT/TBTGuide;

    const/4 v9, 0x0

    iput-boolean v9, v5, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->isDoroJibunShake:Z

    goto/16 :goto_1b

    .line 2016
    :catch_2
    move-exception v27

    .line 2018
    .local v27, "e":Landroid/os/RemoteException;
    invoke-virtual/range {v27 .. v27}, Landroid/os/RemoteException;->printStackTrace()V

    goto/16 :goto_1c

    .line 1869
    .end local v27    # "e":Landroid/os/RemoteException;
    .restart local v24    # "bTurnViewIsShwing":Z
    .restart local v32    # "nEnd":I
    .restart local v37    # "strCross":Ljava/lang/String;
    .restart local v40    # "textSize":I
    .restart local v41    # "textcolor":I
    :catch_3
    move-exception v27

    move-object/from16 v36, v37

    .end local v37    # "strCross":Ljava/lang/String;
    .restart local v36    # "strCross":Ljava/lang/String;
    goto/16 :goto_20
.end method

.method public static native SetTestERerouteDis(I)V
.end method

.method public static native SetTestERerouteDis2(I)V
.end method

.method public static native SetTestSpeed(I)V
.end method

.method private static SetViewMargin(Z)V
    .locals 2
    .param p0, "isMargin"    # Z

    .prologue
    .line 2074
    sget-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    new-instance v1, Lcom/thinkware/sundo/inavi3d/Inavi$7;

    invoke-direct {v1, p0}, Lcom/thinkware/sundo/inavi3d/Inavi$7;-><init>(Z)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 2098
    return-void
.end method

.method private static SetVisible(Landroid/view/View;I)V
    .locals 1
    .param p0, "view"    # Landroid/view/View;
    .param p1, "Visibility"    # I

    .prologue
    .line 2060
    new-instance v0, Lcom/thinkware/sundo/inavi3d/Inavi$6;

    invoke-direct {v0, p0, p1}, Lcom/thinkware/sundo/inavi3d/Inavi$6;-><init>(Landroid/view/View;I)V

    invoke-virtual {p0, v0}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    .line 2071
    return-void
.end method

.method public static SetVisibleMisenGUI(Z)V
    .locals 2
    .param p0, "bShow"    # Z

    .prologue
    .line 2173
    sget-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->mDRDataLayout:Landroid/widget/RelativeLayout;

    if-nez v0, :cond_1

    .line 2201
    :cond_0
    :goto_0
    return-void

    .line 2175
    :cond_1
    sget-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->mDRUpDownRotationView2:Landroid/widget/ImageView;

    if-eqz v0, :cond_0

    .line 2177
    sget-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->mDRLeftRightRotationView2:Landroid/widget/ImageView;

    if-eqz v0, :cond_0

    .line 2180
    sget-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    new-instance v1, Lcom/thinkware/sundo/inavi3d/Inavi$9;

    invoke-direct {v1, p0}, Lcom/thinkware/sundo/inavi3d/Inavi$9;-><init>(Z)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    goto :goto_0
.end method

.method public static SetVisibleMisenGUIUserClick(Z)V
    .locals 2
    .param p0, "compulsionHide"    # Z

    .prologue
    .line 2204
    sget-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->mDRDataLayout:Landroid/widget/RelativeLayout;

    if-nez v0, :cond_0

    .line 2235
    :goto_0
    return-void

    .line 2207
    :cond_0
    sget-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    new-instance v1, Lcom/thinkware/sundo/inavi3d/Inavi$10;

    invoke-direct {v1, p0}, Lcom/thinkware/sundo/inavi3d/Inavi$10;-><init>(Z)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    goto :goto_0
.end method

.method public static ShowNativeToast(Ljava/lang/String;I)V
    .locals 4
    .param p0, "strMsg"    # Ljava/lang/String;
    .param p1, "nDuration"    # I

    .prologue
    .line 1094
    sget-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const/16 v2, 0xfbe

    const/4 v3, 0x0

    invoke-static {v1, v2, p1, v3, p0}, Landroid/os/Message;->obtain(Landroid/os/Handler;IIILjava/lang/Object;)Landroid/os/Message;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    .line 1096
    return-void
.end method

.method public static ShowOBD2Popup(ILcom/thinkware/sundo/inavi3d/oilprice/OilPricePoint;)V
    .locals 4
    .param p0, "type"    # I
    .param p1, "opp"    # Lcom/thinkware/sundo/inavi3d/oilprice/OilPricePoint;

    .prologue
    .line 1098
    new-instance v0, Lcom/thinkware/sundo/inavi3d/oilprice/OilPricePoint;

    invoke-direct {v0, p1}, Lcom/thinkware/sundo/inavi3d/oilprice/OilPricePoint;-><init>(Lcom/thinkware/sundo/inavi3d/oilprice/OilPricePoint;)V

    .line 1099
    .local v0, "_opp":Lcom/thinkware/sundo/inavi3d/oilprice/OilPricePoint;
    sget-object v2, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const/16 v3, 0xfb4

    invoke-static {v2, v3, v0}, Landroid/os/Message;->obtain(Landroid/os/Handler;ILjava/lang/Object;)Landroid/os/Message;

    move-result-object v1

    .line 1100
    .local v1, "msg":Landroid/os/Message;
    iput p0, v1, Landroid/os/Message;->arg1:I

    .line 1101
    sget-object v2, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    invoke-virtual {v2, v1}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    .line 1102
    return-void
.end method

.method public static ShowPopup(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;I)V
    .locals 6
    .param p0, "type"    # I
    .param p1, "id"    # Ljava/lang/String;
    .param p2, "title"    # Ljava/lang/String;
    .param p3, "contents"    # Ljava/lang/String;
    .param p4, "time"    # I

    .prologue
    .line 1090
    new-instance v0, Lcom/thinkware/sundo/inavi3d/Struct/PopupData;

    move v1, p0

    move-object v2, p1

    move-object v3, p2

    move-object v4, p3

    move v5, p4

    invoke-direct/range {v0 .. v5}, Lcom/thinkware/sundo/inavi3d/Struct/PopupData;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;I)V

    .line 1091
    .local v0, "data":Lcom/thinkware/sundo/inavi3d/Struct/PopupData;
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    sget-object v2, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    const/16 v3, 0xfaa

    invoke-static {v2, v3, v0}, Landroid/os/Message;->obtain(Landroid/os/Handler;ILjava/lang/Object;)Landroid/os/Message;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    .line 1092
    return-void
.end method

.method public static StartLiveLogging(Ljava/lang/String;)I
    .locals 4
    .param p0, "pathName"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .prologue
    .line 902
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    if-nez v1, :cond_0

    .line 903
    const/4 v1, -0x1

    .line 913
    :goto_0
    return v1

    .line 906
    :cond_0
    :try_start_0
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "/"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    .line 907
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    invoke-interface {v1, p0}, Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;->startLiveLogging(Ljava/lang/String;)I

    move-result v1

    sput v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mLogLiveLogging:I

    .line 908
    const-string v1, "UserLog"

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "MMC startLiveLogging return "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    sget v3, Lcom/thinkware/sundo/inavi3d/Inavi;->mLogLiveLogging:I

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Lcom/thinkware/sundo/inavi3d/LOGTW;->d(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    .line 913
    :goto_1
    sget v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mLogLiveLogging:I

    goto :goto_0

    .line 909
    :catch_0
    move-exception v0

    .line 911
    .local v0, "e":Landroid/os/RemoteException;
    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    goto :goto_1
.end method

.method public static StopLiveLogging()V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .prologue
    .line 918
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    if-eqz v1, :cond_0

    .line 920
    :try_start_0
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    invoke-interface {v1}, Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;->stopLiveLogging()V

    .line 921
    const-string v1, "UserLog"

    const-string v2, "MMC stopLiveLogging"

    invoke-static {v1, v2}, Lcom/thinkware/sundo/inavi3d/LOGTW;->d(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    .line 927
    .local v0, "e":Landroid/os/RemoteException;
    :cond_0
    :goto_0
    return-void

    .line 922
    .end local v0    # "e":Landroid/os/RemoteException;
    :catch_0
    move-exception v0

    .line 924
    .restart local v0    # "e":Landroid/os/RemoteException;
    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    goto :goto_0
.end method

.method public static native ToggleViewMode(IZ)Z
.end method

.method public static native UpdateDisConnectedTime()V
.end method

.method public static native UpdatePowerConnectedTime()V
.end method

.method private static _CheckData()I
    .locals 12

    .prologue
    .line 715
    new-instance v0, Lcom/thinkware/sundo/inavi3d/AuthDRM;

    invoke-direct {v0}, Lcom/thinkware/sundo/inavi3d/AuthDRM;-><init>()V

    sput-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->authDrm:Lcom/thinkware/sundo/inavi3d/AuthDRM;

    .line 716
    sget-object v1, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->kStorageRoot:Ljava/lang/String;

    .line 717
    .local v1, "strAppPath":Ljava/lang/String;
    sget-object v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->kMapdataPath:Ljava/lang/String;

    .line 718
    .local v2, "strMapPath":Ljava/lang/String;
    sget-object v3, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->kMapDataVersion:Ljava/lang/String;

    .line 719
    .local v3, "strMapVer":Ljava/lang/String;
    sget-object v4, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->kInaviVersionName:Ljava/lang/String;

    .line 721
    .local v4, "strAppV":Ljava/lang/String;
    const-string v5, "1417"

    .line 722
    .local v5, "strBuildV":Ljava/lang/String;
    sget-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->authDrm:Lcom/thinkware/sundo/inavi3d/AuthDRM;

    invoke-virtual/range {v0 .. v5}, Lcom/thinkware/sundo/inavi3d/AuthDRM;->Authorize(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v8

    .line 723
    .local v8, "ret":I
    if-nez v8, :cond_0

    .line 724
    sget-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->authDrm:Lcom/thinkware/sundo/inavi3d/AuthDRM;

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/AuthDRM;->GetSDRM4MMC()Ljava/lang/String;

    move-result-object v9

    .line 729
    .local v9, "sdrm4mmc":Ljava/lang/String;
    :try_start_0
    sget-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    invoke-interface {v0, v9}, Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;->SetDRMString(Ljava/lang/String;)Z

    move-result v7

    .line 730
    .local v7, "result":Z
    const-string v0, "hslee_test"

    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    const-string v11, "pass data4mmc. result : "

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10, v7}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v10

    invoke-static {v0, v10}, Lcom/thinkware/sundo/inavi3d/LOGTW;->d(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    .line 736
    .end local v7    # "result":Z
    .end local v9    # "sdrm4mmc":Ljava/lang/String;
    :cond_0
    :goto_0
    return v8

    .line 731
    .restart local v9    # "sdrm4mmc":Ljava/lang/String;
    :catch_0
    move-exception v6

    .line 733
    .local v6, "e":Landroid/os/RemoteException;
    invoke-virtual {v6}, Landroid/os/RemoteException;->printStackTrace()V

    goto :goto_0
.end method

.method static synthetic access$000()Z
    .locals 1

    .prologue
    .line 94
    sget-boolean v0, Lcom/thinkware/sundo/inavi3d/Inavi;->mbUserClickShowDRLayout:Z

    return v0
.end method

.method static synthetic access$002(Z)Z
    .locals 0
    .param p0, "x0"    # Z

    .prologue
    .line 94
    sput-boolean p0, Lcom/thinkware/sundo/inavi3d/Inavi;->mbUserClickShowDRLayout:Z

    return p0
.end method

.method static synthetic access$102(Z)Z
    .locals 0
    .param p0, "x0"    # Z

    .prologue
    .line 94
    sput-boolean p0, Lcom/thinkware/sundo/inavi3d/Inavi;->mIsDrSpeed:Z

    return p0
.end method

.method static synthetic access$200()Landroid/content/Context;
    .locals 1

    .prologue
    .line 94
    sget-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->mContext:Landroid/content/Context;

    return-object v0
.end method

.method static synthetic access$300()Landroid/os/Handler;
    .locals 1

    .prologue
    .line 94
    sget-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    return-object v0
.end method

.method public static native checkTimeLock(Ljava/lang/String;)Z
.end method

.method public static native clearFivepinPid()V
.end method

.method public static native clearPLogRankingDataForCurrentOn()V
.end method

.method public static native clearToggleViewModeLevel()V
.end method

.method public static closeAINAProcess()V
    .locals 1

    .prologue
    .line 3464
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v0

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->closeAINAProcess()V

    .line 3465
    return-void
.end method

.method public static native countofDrawPLogIcons()I
.end method

.method public static native finalMainInit()V
.end method

.method public static native getAroundCCTVOnOFF()Z
.end method

.method public static native getCurrentRouteOption()I
.end method

.method public static getDualSearch()Lcom/thinkware/sundo/inavi3d/Struct/DualSearchInfo;
    .locals 1

    .prologue
    .line 239
    sget-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->Dualsearch:Lcom/thinkware/sundo/inavi3d/Struct/DualSearchInfo;

    return-object v0
.end method

.method public static native getFivepinName(I)Ljava/lang/String;
.end method

.method public static native getFivepinPid(I)I
.end method

.method public static getHudguide()Lcom/thinkware/sundo/remoteHUD/HUDGuide;
    .locals 1

    .prologue
    .line 3301
    sget-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->hudguide:Lcom/thinkware/sundo/remoteHUD/HUDGuide;

    return-object v0
.end method

.method public static getMMCSpeed()I
    .locals 2

    .prologue
    .line 3468
    :try_start_0
    sget v1, Lcom/thinkware/sundo/inavi3dservice/MMCModule;->speed:I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 3471
    :goto_0
    return v1

    .line 3470
    :catch_0
    move-exception v0

    .line 3471
    .local v0, "e":Ljava/lang/Exception;
    const/4 v1, 0x0

    goto :goto_0
.end method

.method public static native getMapCenterX()I
.end method

.method public static native getMapCenterY()I
.end method

.method public static getNFGuide()Lcom/thinkware/sundo/inavi3d/TUNNEL_SUCCEED_GUIDE;
    .locals 1

    .prologue
    .line 245
    sget-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->nfguide:Lcom/thinkware/sundo/inavi3d/TUNNEL_SUCCEED_GUIDE;

    return-object v0
.end method

.method public static native getSelectedIndex()I
.end method

.method public static native getSunriseSunsetTime()Ljava/lang/String;
.end method

.method public static getTblInfo()Lcom/thinkware/sundo/inavi3d/ROUTE_TABLE_RENEW_INFO;
    .locals 1

    .prologue
    .line 251
    sget-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->TrafficRouteTableInfo:Lcom/thinkware/sundo/inavi3d/ROUTE_TABLE_RENEW_INFO;

    return-object v0
.end method

.method public static getTbtguide()Lcom/thinkware/sundo/remoteTBT/TBTGuide;
    .locals 1

    .prologue
    .line 3292
    sget-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->tbtguide:Lcom/thinkware/sundo/remoteTBT/TBTGuide;

    return-object v0
.end method

.method public static native getTestRerouteMeter()I
.end method

.method public static getULogLocationData()Lcom/thinkware/sundo/inavi3d/ULogLocationData;
    .locals 5

    .prologue
    const/4 v4, 0x0

    .line 1073
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mContext:Landroid/content/Context;

    const-string v2, "ULOG_LOCATION_DATA"

    invoke-virtual {v1, v2, v4}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v0

    .line 1074
    .local v0, "pref":Landroid/content/SharedPreferences;
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->ulogLocData:Lcom/thinkware/sundo/inavi3d/ULogLocationData;

    const-string v2, "nStartPosX"

    invoke-interface {v0, v2, v4}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v2

    iput v2, v1, Lcom/thinkware/sundo/inavi3d/ULogLocationData;->nStartPosX:I

    .line 1075
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->ulogLocData:Lcom/thinkware/sundo/inavi3d/ULogLocationData;

    const-string v2, "nStartPosY"

    invoke-interface {v0, v2, v4}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v2

    iput v2, v1, Lcom/thinkware/sundo/inavi3d/ULogLocationData;->nStartPosY:I

    .line 1076
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->ulogLocData:Lcom/thinkware/sundo/inavi3d/ULogLocationData;

    const-string v2, "nStartTime"

    invoke-interface {v0, v2, v4}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v2

    iput v2, v1, Lcom/thinkware/sundo/inavi3d/ULogLocationData;->nStartTime:I

    .line 1077
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->ulogLocData:Lcom/thinkware/sundo/inavi3d/ULogLocationData;

    const-string v2, "nStartViewMode"

    invoke-interface {v0, v2, v4}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v2

    iput v2, v1, Lcom/thinkware/sundo/inavi3d/ULogLocationData;->nStartViewMode:I

    .line 1079
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->ulogLocData:Lcom/thinkware/sundo/inavi3d/ULogLocationData;

    const-string v2, "nEndPosX"

    invoke-interface {v0, v2, v4}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v2

    iput v2, v1, Lcom/thinkware/sundo/inavi3d/ULogLocationData;->nEndPosX:I

    .line 1080
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->ulogLocData:Lcom/thinkware/sundo/inavi3d/ULogLocationData;

    const-string v2, "nEndPosY"

    invoke-interface {v0, v2, v4}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v2

    iput v2, v1, Lcom/thinkware/sundo/inavi3d/ULogLocationData;->nEndPosY:I

    .line 1081
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->ulogLocData:Lcom/thinkware/sundo/inavi3d/ULogLocationData;

    const-string v2, "nEndTime"

    invoke-interface {v0, v2, v4}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v2

    iput v2, v1, Lcom/thinkware/sundo/inavi3d/ULogLocationData;->nEndTime:I

    .line 1082
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->ulogLocData:Lcom/thinkware/sundo/inavi3d/ULogLocationData;

    const-string v2, "nEndViewMode"

    invoke-interface {v0, v2, v4}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v2

    iput v2, v1, Lcom/thinkware/sundo/inavi3d/ULogLocationData;->nEndViewMode:I

    .line 1083
    const-string v1, "inavi3d_gothmog"

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "UserLog setData getULogLocationData : nStartPosX "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "nStartPosX"

    invoke-interface {v0, v3, v4}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, ", nStartPosY "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "nStartPosY"

    invoke-interface {v0, v3, v4}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, ", nStartTime "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "nStartTime"

    invoke-interface {v0, v3, v4}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, ", nStartViewMode "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "nStartViewMode"

    invoke-interface {v0, v3, v4}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, ", nEndPosX "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "nEndPosX"

    invoke-interface {v0, v3, v4}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, ", nEndPosY "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "nEndPosY"

    invoke-interface {v0, v3, v4}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, ", nEndTime "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "nEndTime"

    invoke-interface {v0, v3, v4}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, ", nEndViewMode "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "nEndViewMode"

    invoke-interface {v0, v3, v4}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Lcom/thinkware/sundo/inavi3d/LOGTW;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 1085
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->ulogLocData:Lcom/thinkware/sundo/inavi3d/ULogLocationData;

    return-object v1
.end method

.method public static getULogRegisterEstimateData()Lcom/thinkware/sundo/inavi3d/ULogEstimateData;
    .locals 4

    .prologue
    const/4 v3, 0x0

    .line 1013
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mContext:Landroid/content/Context;

    const-string v2, "ULOG_ESTIMATE_DATA"

    invoke-virtual {v1, v2, v3}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v0

    .line 1015
    .local v0, "pref":Landroid/content/SharedPreferences;
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->ulogEstData:Lcom/thinkware/sundo/inavi3d/ULogEstimateData;

    const-string v2, "nStartPosX"

    invoke-interface {v0, v2, v3}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v2

    iput v2, v1, Lcom/thinkware/sundo/inavi3d/ULogEstimateData;->nStartPosX:I

    .line 1016
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->ulogEstData:Lcom/thinkware/sundo/inavi3d/ULogEstimateData;

    const-string v2, "nStartPosY"

    invoke-interface {v0, v2, v3}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v2

    iput v2, v1, Lcom/thinkware/sundo/inavi3d/ULogEstimateData;->nStartPosY:I

    .line 1017
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->ulogEstData:Lcom/thinkware/sundo/inavi3d/ULogEstimateData;

    const-string v2, "nEstimateDistance"

    invoke-interface {v0, v2, v3}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v2

    iput v2, v1, Lcom/thinkware/sundo/inavi3d/ULogEstimateData;->nEstimateDistance:I

    .line 1018
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->ulogEstData:Lcom/thinkware/sundo/inavi3d/ULogEstimateData;

    const-string v2, "nEstimateTime"

    invoke-interface {v0, v2, v3}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v2

    iput v2, v1, Lcom/thinkware/sundo/inavi3d/ULogEstimateData;->nEstimateTime:I

    .line 1019
    const-string v1, "inavi3d_gothmog"

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "UserLog setData getEstimateData : startPosX "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    sget-object v3, Lcom/thinkware/sundo/inavi3d/Inavi;->ulogEstData:Lcom/thinkware/sundo/inavi3d/ULogEstimateData;

    iget v3, v3, Lcom/thinkware/sundo/inavi3d/ULogEstimateData;->nStartPosX:I

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, ", nStartPosY "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    sget-object v3, Lcom/thinkware/sundo/inavi3d/Inavi;->ulogEstData:Lcom/thinkware/sundo/inavi3d/ULogEstimateData;

    iget v3, v3, Lcom/thinkware/sundo/inavi3d/ULogEstimateData;->nStartPosY:I

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, ", nEstDis "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    sget-object v3, Lcom/thinkware/sundo/inavi3d/Inavi;->ulogEstData:Lcom/thinkware/sundo/inavi3d/ULogEstimateData;

    iget v3, v3, Lcom/thinkware/sundo/inavi3d/ULogEstimateData;->nEstimateDistance:I

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, ", nEstTime "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    sget-object v3, Lcom/thinkware/sundo/inavi3d/Inavi;->ulogEstData:Lcom/thinkware/sundo/inavi3d/ULogEstimateData;

    iget v3, v3, Lcom/thinkware/sundo/inavi3d/ULogEstimateData;->nEstimateTime:I

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Lcom/thinkware/sundo/inavi3d/LOGTW;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 1020
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->ulogEstData:Lcom/thinkware/sundo/inavi3d/ULogEstimateData;

    return-object v1
.end method

.method public static getVisibleSafeZoneMiniView()Z
    .locals 2

    .prologue
    const/4 v0, 0x0

    .line 3475
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneMiniViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneMiniViewAR;

    if-nez v1, :cond_1

    .line 3481
    :cond_0
    :goto_0
    return v0

    .line 3478
    :cond_1
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->safeZoneMiniViewAR:Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneMiniViewAR;

    invoke-virtual {v1}, Lcom/thinkware/sundo/inavi3d/ui/guidecomponent/SafeZoneMiniViewAR;->getVisibility()I

    move-result v1

    if-nez v1, :cond_0

    .line 3479
    const/4 v0, 0x1

    goto :goto_0
.end method

.method private static handleBackgroundMessage()V
    .locals 2

    .prologue
    .line 2517
    sget-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    new-instance v1, Lcom/thinkware/sundo/inavi3d/Inavi$13;

    invoke-direct {v1}, Lcom/thinkware/sundo/inavi3d/Inavi$13;-><init>()V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 2526
    return-void
.end method

.method public static isCurrentOnAndRootActivity()Z
    .locals 1

    .prologue
    .line 2390
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->isCurrentOnAndRootActivity()Z

    move-result v0

    if-eqz v0, :cond_0

    .line 2391
    const/4 v0, 0x1

    .line 2393
    :goto_0
    return v0

    :cond_0
    const/4 v0, 0x0

    goto :goto_0
.end method

.method public static isMyRoute()Z
    .locals 7

    .prologue
    const/4 v3, 0x1

    .line 3512
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/Inavi;->getTbtguide()Lcom/thinkware/sundo/remoteTBT/TBTGuide;

    move-result-object v2

    .line 3513
    .local v2, "tbtguide":Lcom/thinkware/sundo/remoteTBT/TBTGuide;
    if-eqz v2, :cond_0

    .line 3515
    :try_start_0
    new-instance v4, Ljava/lang/String;

    iget-object v5, v2, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->routeoption:[B

    const-string v6, "EUC-KR"

    invoke-direct {v4, v5, v6}, Ljava/lang/String;-><init>([BLjava/lang/String;)V

    invoke-virtual {v4}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v1

    .line 3516
    .local v1, "routeOption":Ljava/lang/String;
    const-string v4, "\ub0b4\uacbd\ub85c"

    invoke-static {v1, v4}, Lcom/thinkware/sundo/inavi3d/StringHelper;->isEqualString(Ljava/lang/String;Ljava/lang/String;)Z
    :try_end_0
    .catch Ljava/io/UnsupportedEncodingException; {:try_start_0 .. :try_end_0} :catch_0

    move-result v4

    if-ne v4, v3, :cond_0

    .line 3524
    .end local v1    # "routeOption":Ljava/lang/String;
    :goto_0
    return v3

    .line 3519
    :catch_0
    move-exception v0

    .line 3521
    .local v0, "e":Ljava/io/UnsupportedEncodingException;
    invoke-virtual {v0}, Ljava/io/UnsupportedEncodingException;->printStackTrace()V

    .line 3524
    .end local v0    # "e":Ljava/io/UnsupportedEncodingException;
    :cond_0
    const/4 v3, 0x0

    goto :goto_0
.end method

.method public static native isNaviCurrentOn()Z
.end method

.method public static native isUserLogSupportDevice()Z
.end method

.method public static isValidRoute()Z
    .locals 1

    .prologue
    .line 304
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/Inavi;->getTbtguide()Lcom/thinkware/sundo/remoteTBT/TBTGuide;

    move-result-object v0

    iget v0, v0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->viaCount:I

    if-lez v0, :cond_0

    .line 305
    const/4 v0, 0x1

    .line 307
    :goto_0
    return v0

    :cond_0
    const/4 v0, 0x0

    goto :goto_0
.end method

.method public static native resetCustomView()V
.end method

.method public static native saveSearchDataForUserLog(ZII)Z
.end method

.method private static setCrossNameInfo(Ljava/lang/String;II)V
    .locals 2
    .param p0, "str"    # Ljava/lang/String;
    .param p1, "color"    # I
    .param p2, "size"    # I

    .prologue
    .line 2042
    sget-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->crossname:Landroid/widget/Button;

    if-eqz v0, :cond_0

    .line 2043
    sget-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->crossname:Landroid/widget/Button;

    new-instance v1, Lcom/thinkware/sundo/inavi3d/Inavi$5;

    invoke-direct {v1, p0, p1, p2}, Lcom/thinkware/sundo/inavi3d/Inavi$5;-><init>(Ljava/lang/String;II)V

    invoke-virtual {v0, v1}, Landroid/widget/Button;->post(Ljava/lang/Runnable;)Z

    .line 2056
    :cond_0
    return-void
.end method

.method public static setHudguide(Lcom/thinkware/sundo/remoteTBT/TBTGuide;)V
    .locals 9
    .param p0, "tbtGuide"    # Lcom/thinkware/sundo/remoteTBT/TBTGuide;

    .prologue
    .line 3309
    sget-object v7, Lcom/thinkware/sundo/inavi3d/Inavi;->hudguide:Lcom/thinkware/sundo/remoteHUD/HUDGuide;

    iget v8, p0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->road_type:I

    iput v8, v7, Lcom/thinkware/sundo/remoteHUD/HUDGuide;->road_type:I

    .line 3311
    sget-object v7, Lcom/thinkware/sundo/inavi3d/Inavi;->hudguide:Lcom/thinkware/sundo/remoteHUD/HUDGuide;

    iget v8, p0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->turn_index_1:I

    iput v8, v7, Lcom/thinkware/sundo/remoteHUD/HUDGuide;->turn_index_1:I

    .line 3312
    sget-object v7, Lcom/thinkware/sundo/inavi3d/Inavi;->hudguide:Lcom/thinkware/sundo/remoteHUD/HUDGuide;

    iget v8, p0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->turn_index_2:I

    iput v8, v7, Lcom/thinkware/sundo/remoteHUD/HUDGuide;->turn_index_2:I

    .line 3316
    sget-object v7, Lcom/thinkware/sundo/inavi3d/Inavi;->hudguide:Lcom/thinkware/sundo/remoteHUD/HUDGuide;

    iget v8, p0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->dis_cross:I

    div-int/lit8 v8, v8, 0xa

    mul-int/lit8 v8, v8, 0xa

    add-int/lit8 v8, v8, -0xa

    iput v8, v7, Lcom/thinkware/sundo/remoteHUD/HUDGuide;->dis_cross:I

    .line 3317
    sget-object v7, Lcom/thinkware/sundo/inavi3d/Inavi;->hudguide:Lcom/thinkware/sundo/remoteHUD/HUDGuide;

    iget v7, v7, Lcom/thinkware/sundo/remoteHUD/HUDGuide;->dis_cross:I

    if-gez v7, :cond_0

    .line 3318
    sget-object v7, Lcom/thinkware/sundo/inavi3d/Inavi;->hudguide:Lcom/thinkware/sundo/remoteHUD/HUDGuide;

    const/4 v8, 0x0

    iput v8, v7, Lcom/thinkware/sundo/remoteHUD/HUDGuide;->dis_cross:I

    .line 3322
    :cond_0
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->getInstance()Lcom/thinkware/sundo/inavi3d/InaviConfig;

    move-result-object v7

    const/16 v8, 0x138

    invoke-virtual {v7, v8}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->CNaviConfigGet(I)I

    move-result v6

    .line 3323
    .local v6, "nMode":I
    const/4 v1, 0x0

    .line 3324
    .local v1, "distanceCross2":I
    if-nez v6, :cond_5

    .line 3325
    iget v7, p0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->dis_cross:I

    iget v8, p0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->dis_cross2:I

    add-int/2addr v7, v8

    div-int/lit8 v7, v7, 0xa

    mul-int/lit8 v7, v7, 0xa

    add-int/lit8 v1, v7, -0xa

    .line 3326
    if-gez v1, :cond_1

    .line 3327
    const/4 v1, 0x0

    .line 3335
    :cond_1
    :goto_0
    sget-object v7, Lcom/thinkware/sundo/inavi3d/Inavi;->hudguide:Lcom/thinkware/sundo/remoteHUD/HUDGuide;

    iput v1, v7, Lcom/thinkware/sundo/remoteHUD/HUDGuide;->dis_cross2:I

    .line 3338
    sget-object v7, Lcom/thinkware/sundo/inavi3d/Inavi;->hudguide:Lcom/thinkware/sundo/remoteHUD/HUDGuide;

    iget v8, p0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->guide_code1:I

    iput v8, v7, Lcom/thinkware/sundo/remoteHUD/HUDGuide;->guide_code1:I

    .line 3339
    sget-object v7, Lcom/thinkware/sundo/inavi3d/Inavi;->hudguide:Lcom/thinkware/sundo/remoteHUD/HUDGuide;

    iget v8, p0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->guide_code2:I

    iput v8, v7, Lcom/thinkware/sundo/remoteHUD/HUDGuide;->guide_code2:I

    .line 3340
    sget-object v7, Lcom/thinkware/sundo/inavi3d/Inavi;->hudguide:Lcom/thinkware/sundo/remoteHUD/HUDGuide;

    iget v8, p0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->viaCount:I

    iput v8, v7, Lcom/thinkware/sundo/remoteHUD/HUDGuide;->viaCount:I

    .line 3342
    sget-object v7, Lcom/thinkware/sundo/inavi3d/Inavi;->hudguide:Lcom/thinkware/sundo/remoteHUD/HUDGuide;

    iget v8, p0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->restDist:I

    iput v8, v7, Lcom/thinkware/sundo/remoteHUD/HUDGuide;->restDist:I

    .line 3343
    sget-object v7, Lcom/thinkware/sundo/inavi3d/Inavi;->hudguide:Lcom/thinkware/sundo/remoteHUD/HUDGuide;

    iget v8, p0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->dis_via:I

    iput v8, v7, Lcom/thinkware/sundo/remoteHUD/HUDGuide;->dis_via:I

    .line 3344
    sget-object v7, Lcom/thinkware/sundo/inavi3d/Inavi;->hudguide:Lcom/thinkware/sundo/remoteHUD/HUDGuide;

    iget v8, p0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->via_index:I

    iput v8, v7, Lcom/thinkware/sundo/remoteHUD/HUDGuide;->via_index:I

    .line 3345
    sget-object v7, Lcom/thinkware/sundo/inavi3d/Inavi;->hudguide:Lcom/thinkware/sundo/remoteHUD/HUDGuide;

    iget v8, p0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->via_type:I

    iput v8, v7, Lcom/thinkware/sundo/remoteHUD/HUDGuide;->via_type:I

    .line 3347
    sget-object v7, Lcom/thinkware/sundo/inavi3d/Inavi;->hudguide:Lcom/thinkware/sundo/remoteHUD/HUDGuide;

    iget v8, p0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->isroute:I

    iput v8, v7, Lcom/thinkware/sundo/remoteHUD/HUDGuide;->isroute:I

    .line 3348
    sget-object v7, Lcom/thinkware/sundo/inavi3d/Inavi;->hudguide:Lcom/thinkware/sundo/remoteHUD/HUDGuide;

    iget v8, p0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->progress:I

    iput v8, v7, Lcom/thinkware/sundo/remoteHUD/HUDGuide;->progress:I

    .line 3349
    sget-object v7, Lcom/thinkware/sundo/inavi3d/Inavi;->hudguide:Lcom/thinkware/sundo/remoteHUD/HUDGuide;

    iget v8, p0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->routeindex:I

    iput v8, v7, Lcom/thinkware/sundo/remoteHUD/HUDGuide;->routeindex:I

    .line 3350
    sget-object v7, Lcom/thinkware/sundo/inavi3d/Inavi;->hudguide:Lcom/thinkware/sundo/remoteHUD/HUDGuide;

    iget-object v8, p0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->routeoption:[B

    iput-object v8, v7, Lcom/thinkware/sundo/remoteHUD/HUDGuide;->routeoption:[B

    .line 3351
    sget-object v7, Lcom/thinkware/sundo/inavi3d/Inavi;->hudguide:Lcom/thinkware/sundo/remoteHUD/HUDGuide;

    iget-boolean v8, p0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->isTrafficRoute:Z

    iput-boolean v8, v7, Lcom/thinkware/sundo/remoteHUD/HUDGuide;->isTrafficRoute:Z

    .line 3353
    sget-object v7, Lcom/thinkware/sundo/inavi3d/Inavi;->hudguide:Lcom/thinkware/sundo/remoteHUD/HUDGuide;

    iget-object v8, p0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->sigInfo:[B

    iput-object v8, v7, Lcom/thinkware/sundo/remoteHUD/HUDGuide;->sigInfo:[B

    .line 3354
    sget-object v7, Lcom/thinkware/sundo/inavi3d/Inavi;->hudguide:Lcom/thinkware/sundo/remoteHUD/HUDGuide;

    iget-object v8, p0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->roadNm:[B

    iput-object v8, v7, Lcom/thinkware/sundo/remoteHUD/HUDGuide;->roadNm:[B

    .line 3355
    sget-object v7, Lcom/thinkware/sundo/inavi3d/Inavi;->hudguide:Lcom/thinkware/sundo/remoteHUD/HUDGuide;

    iget-object v8, p0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->crossDirNm:[B

    iput-object v8, v7, Lcom/thinkware/sundo/remoteHUD/HUDGuide;->crossDirNm:[B

    .line 3357
    sget-object v7, Lcom/thinkware/sundo/inavi3d/Inavi;->hudguide:Lcom/thinkware/sundo/remoteHUD/HUDGuide;

    iget v8, p0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->laneData_index:I

    iput v8, v7, Lcom/thinkware/sundo/remoteHUD/HUDGuide;->laneData_index:I

    .line 3358
    sget-object v7, Lcom/thinkware/sundo/inavi3d/Inavi;->hudguide:Lcom/thinkware/sundo/remoteHUD/HUDGuide;

    iget v8, p0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->laneData_align:I

    iput v8, v7, Lcom/thinkware/sundo/remoteHUD/HUDGuide;->laneData_align:I

    .line 3359
    sget-object v7, Lcom/thinkware/sundo/inavi3d/Inavi;->hudguide:Lcom/thinkware/sundo/remoteHUD/HUDGuide;

    iget v8, p0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->laneData_distance:I

    iput v8, v7, Lcom/thinkware/sundo/remoteHUD/HUDGuide;->laneData_distance:I

    .line 3360
    sget-object v7, Lcom/thinkware/sundo/inavi3d/Inavi;->hudguide:Lcom/thinkware/sundo/remoteHUD/HUDGuide;

    iget v8, p0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->laneData_laneNum:I

    iput v8, v7, Lcom/thinkware/sundo/remoteHUD/HUDGuide;->laneData_laneNum:I

    .line 3361
    sget-object v7, Lcom/thinkware/sundo/inavi3d/Inavi;->hudguide:Lcom/thinkware/sundo/remoteHUD/HUDGuide;

    iget-object v8, p0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->laneData_laneCode:[B

    iput-object v8, v7, Lcom/thinkware/sundo/remoteHUD/HUDGuide;->laneData_laneCode:[B

    .line 3362
    sget-object v7, Lcom/thinkware/sundo/inavi3d/Inavi;->hudguide:Lcom/thinkware/sundo/remoteHUD/HUDGuide;

    iget-object v8, p0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->laneData_laneType:[B

    iput-object v8, v7, Lcom/thinkware/sundo/remoteHUD/HUDGuide;->laneData_laneType:[B

    .line 3363
    sget-object v7, Lcom/thinkware/sundo/inavi3d/Inavi;->hudguide:Lcom/thinkware/sundo/remoteHUD/HUDGuide;

    iget-object v8, p0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->laneData_laneRecomm:[B

    iput-object v8, v7, Lcom/thinkware/sundo/remoteHUD/HUDGuide;->laneData_laneRecomm:[B

    .line 3364
    sget-object v7, Lcom/thinkware/sundo/inavi3d/Inavi;->hudguide:Lcom/thinkware/sundo/remoteHUD/HUDGuide;

    iget-object v8, p0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->laneData_dirName:[B

    iput-object v8, v7, Lcom/thinkware/sundo/remoteHUD/HUDGuide;->laneData_dirName:[B

    .line 3366
    sget-object v7, Lcom/thinkware/sundo/inavi3d/Inavi;->hudguide:Lcom/thinkware/sundo/remoteHUD/HUDGuide;

    iget v8, p0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->laneData_hpassLane:I

    iput v8, v7, Lcom/thinkware/sundo/remoteHUD/HUDGuide;->laneData_hpassLane:I

    .line 3367
    sget-object v7, Lcom/thinkware/sundo/inavi3d/Inavi;->hudguide:Lcom/thinkware/sundo/remoteHUD/HUDGuide;

    iget v8, p0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->laneData_temp1:I

    iput v8, v7, Lcom/thinkware/sundo/remoteHUD/HUDGuide;->laneData_temp1:I

    .line 3368
    sget-object v7, Lcom/thinkware/sundo/inavi3d/Inavi;->hudguide:Lcom/thinkware/sundo/remoteHUD/HUDGuide;

    iget v8, p0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->laneData_temp2:I

    iput v8, v7, Lcom/thinkware/sundo/remoteHUD/HUDGuide;->laneData_temp2:I

    .line 3369
    sget-object v7, Lcom/thinkware/sundo/inavi3d/Inavi;->hudguide:Lcom/thinkware/sundo/remoteHUD/HUDGuide;

    iget v8, p0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->laneData_temp3:I

    iput v8, v7, Lcom/thinkware/sundo/remoteHUD/HUDGuide;->laneData_temp3:I

    .line 3372
    sget-object v7, Lcom/thinkware/sundo/inavi3d/Inavi;->hudguide:Lcom/thinkware/sundo/remoteHUD/HUDGuide;

    iget v8, p0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->speedlimit:I

    iput v8, v7, Lcom/thinkware/sundo/remoteHUD/HUDGuide;->speedlimit:I

    .line 3373
    sget-object v7, Lcom/thinkware/sundo/inavi3d/Inavi;->hudguide:Lcom/thinkware/sundo/remoteHUD/HUDGuide;

    iget v8, p0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->dist:I

    iput v8, v7, Lcom/thinkware/sundo/remoteHUD/HUDGuide;->dist:I

    .line 3374
    sget-object v7, Lcom/thinkware/sundo/inavi3d/Inavi;->hudguide:Lcom/thinkware/sundo/remoteHUD/HUDGuide;

    iget v8, p0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->roadkind:I

    iput v8, v7, Lcom/thinkware/sundo/remoteHUD/HUDGuide;->roadkind:I

    .line 3376
    sget-object v7, Lcom/thinkware/sundo/inavi3d/Inavi;->hudguide:Lcom/thinkware/sundo/remoteHUD/HUDGuide;

    iget v8, p0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->camRecSpeed:I

    iput v8, v7, Lcom/thinkware/sundo/remoteHUD/HUDGuide;->camRecSpeed:I

    .line 3377
    sget-object v7, Lcom/thinkware/sundo/inavi3d/Inavi;->hudguide:Lcom/thinkware/sundo/remoteHUD/HUDGuide;

    iget v8, p0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->RemainDist:I

    iput v8, v7, Lcom/thinkware/sundo/remoteHUD/HUDGuide;->RemainDist:I

    .line 3378
    sget-object v7, Lcom/thinkware/sundo/inavi3d/Inavi;->hudguide:Lcom/thinkware/sundo/remoteHUD/HUDGuide;

    iget-object v8, p0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->pair_remain_time:Ljava/lang/String;

    iput-object v8, v7, Lcom/thinkware/sundo/remoteHUD/HUDGuide;->pair_remain_time:Ljava/lang/String;

    .line 3379
    sget-object v7, Lcom/thinkware/sundo/inavi3d/Inavi;->hudguide:Lcom/thinkware/sundo/remoteHUD/HUDGuide;

    iget v8, p0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->mSafeAreaRemainRatio:I

    iput v8, v7, Lcom/thinkware/sundo/remoteHUD/HUDGuide;->mSafeAreaRemainRatio:I

    .line 3380
    sget-object v7, Lcom/thinkware/sundo/inavi3d/Inavi;->hudguide:Lcom/thinkware/sundo/remoteHUD/HUDGuide;

    iget-char v8, p0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->camerakind:C

    iput-char v8, v7, Lcom/thinkware/sundo/remoteHUD/HUDGuide;->camerakind:C

    .line 3381
    sget-object v7, Lcom/thinkware/sundo/inavi3d/Inavi;->hudguide:Lcom/thinkware/sundo/remoteHUD/HUDGuide;

    iget-char v8, p0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->tmp1:C

    iput-char v8, v7, Lcom/thinkware/sundo/remoteHUD/HUDGuide;->tmp1:C

    .line 3382
    sget-object v7, Lcom/thinkware/sundo/inavi3d/Inavi;->hudguide:Lcom/thinkware/sundo/remoteHUD/HUDGuide;

    iget-char v8, p0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->tmp2:C

    iput-char v8, v7, Lcom/thinkware/sundo/remoteHUD/HUDGuide;->tmp2:C

    .line 3383
    sget-object v7, Lcom/thinkware/sundo/inavi3d/Inavi;->hudguide:Lcom/thinkware/sundo/remoteHUD/HUDGuide;

    iget-char v8, p0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->tmp3:C

    iput-char v8, v7, Lcom/thinkware/sundo/remoteHUD/HUDGuide;->tmp3:C

    .line 3385
    sget-object v7, Lcom/thinkware/sundo/inavi3d/Inavi;->hudguide:Lcom/thinkware/sundo/remoteHUD/HUDGuide;

    iget v8, p0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->SpeedLimitZoneGuide_type:I

    iput v8, v7, Lcom/thinkware/sundo/remoteHUD/HUDGuide;->SpeedLimitZoneGuide_type:I

    .line 3386
    sget-object v7, Lcom/thinkware/sundo/inavi3d/Inavi;->hudguide:Lcom/thinkware/sundo/remoteHUD/HUDGuide;

    iget v8, p0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->ConstructionGuide_type:I

    iput v8, v7, Lcom/thinkware/sundo/remoteHUD/HUDGuide;->ConstructionGuide_type:I

    .line 3389
    sget-object v7, Lcom/thinkware/sundo/inavi3d/Inavi;->hudguide:Lcom/thinkware/sundo/remoteHUD/HUDGuide;

    iget v8, p0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->equalturn:I

    iput v8, v7, Lcom/thinkware/sundo/remoteHUD/HUDGuide;->equalturn:I

    .line 3391
    sget-object v7, Lcom/thinkware/sundo/inavi3d/Inavi;->hudguide:Lcom/thinkware/sundo/remoteHUD/HUDGuide;

    iget v8, p0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->mCurrentSpeed:I

    iput v8, v7, Lcom/thinkware/sundo/remoteHUD/HUDGuide;->mCurrentSpeed:I

    .line 3393
    sget-object v7, Lcom/thinkware/sundo/inavi3d/Inavi;->hudguide:Lcom/thinkware/sundo/remoteHUD/HUDGuide;

    iget v8, p0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->trackstatebar_show:I

    iput v8, v7, Lcom/thinkware/sundo/remoteHUD/HUDGuide;->trackstatebar_show:I

    .line 3394
    sget-object v7, Lcom/thinkware/sundo/inavi3d/Inavi;->hudguide:Lcom/thinkware/sundo/remoteHUD/HUDGuide;

    iget v8, p0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->time_required:I

    iput v8, v7, Lcom/thinkware/sundo/remoteHUD/HUDGuide;->time_required:I

    .line 3396
    sget-object v7, Lcom/thinkware/sundo/inavi3d/Inavi;->hudguide:Lcom/thinkware/sundo/remoteHUD/HUDGuide;

    iget v8, p0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->trackstatebar_Goal:I

    iput v8, v7, Lcom/thinkware/sundo/remoteHUD/HUDGuide;->trackstatebar_Goal:I

    .line 3397
    sget-object v7, Lcom/thinkware/sundo/inavi3d/Inavi;->hudguide:Lcom/thinkware/sundo/remoteHUD/HUDGuide;

    iget-object v8, p0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->goalname:[B

    iput-object v8, v7, Lcom/thinkware/sundo/remoteHUD/HUDGuide;->goalname:[B

    .line 3399
    iget v2, p0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->trackstatebar_Goal:I

    .line 3401
    .local v2, "goalIndex":I
    if-ltz v2, :cond_2

    const/4 v7, 0x6

    if-le v2, v7, :cond_3

    .line 3402
    :cond_2
    const/4 v2, 0x0

    .line 3405
    :cond_3
    add-int/lit8 v3, v2, -0x1

    .line 3406
    .local v3, "index":I
    if-gez v3, :cond_4

    .line 3407
    const/4 v3, 0x0

    .line 3410
    :cond_4
    sget-object v7, Lcom/thinkware/sundo/inavi3d/Inavi;->hudguide:Lcom/thinkware/sundo/remoteHUD/HUDGuide;

    iget-object v8, p0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->MulitiGoalRemainDistanceInt:[I

    aget v8, v8, v3

    iput v8, v7, Lcom/thinkware/sundo/remoteHUD/HUDGuide;->arrive_Distance:I

    .line 3412
    const/4 v0, 0x0

    .line 3413
    .local v0, "bTimeRequired":Z
    iget v7, p0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->time_required:I

    if-nez v7, :cond_6

    .line 3414
    const/4 v0, 0x0

    .line 3419
    :goto_1
    const/4 v4, 0x0

    .line 3420
    .local v4, "nHourTime":I
    const/4 v5, 0x0

    .line 3421
    .local v5, "nMinTime":I
    if-eqz v0, :cond_7

    .line 3422
    iget-object v7, p0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->MulitGoalRemainHour:[I

    aget v4, v7, v3

    .line 3423
    iget-object v7, p0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->MulitGoalRemainMin:[I

    aget v5, v7, v3

    .line 3429
    :goto_2
    sget-object v7, Lcom/thinkware/sundo/inavi3d/Inavi;->hudguide:Lcom/thinkware/sundo/remoteHUD/HUDGuide;

    iput v4, v7, Lcom/thinkware/sundo/remoteHUD/HUDGuide;->arrive_time_hour:I

    .line 3430
    sget-object v7, Lcom/thinkware/sundo/inavi3d/Inavi;->hudguide:Lcom/thinkware/sundo/remoteHUD/HUDGuide;

    iput v5, v7, Lcom/thinkware/sundo/remoteHUD/HUDGuide;->arrive_time_min:I

    .line 3431
    sget-object v7, Lcom/thinkware/sundo/inavi3d/Inavi;->hudguide:Lcom/thinkware/sundo/remoteHUD/HUDGuide;

    iget v8, p0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->arrive_time_sec:I

    iput v8, v7, Lcom/thinkware/sundo/remoteHUD/HUDGuide;->arrive_time_sec:I

    .line 3441
    sget-object v7, Lcom/thinkware/sundo/inavi3d/Inavi;->hudguide:Lcom/thinkware/sundo/remoteHUD/HUDGuide;

    iget v8, p0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->m_bConfTurn:I

    iput v8, v7, Lcom/thinkware/sundo/remoteHUD/HUDGuide;->m_bConfTurn:I

    .line 3442
    sget-object v7, Lcom/thinkware/sundo/inavi3d/Inavi;->hudguide:Lcom/thinkware/sundo/remoteHUD/HUDGuide;

    iget v8, p0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->m_bConfSafeGuide:I

    iput v8, v7, Lcom/thinkware/sundo/remoteHUD/HUDGuide;->m_bConfSafeGuide:I

    .line 3443
    sget-object v7, Lcom/thinkware/sundo/inavi3d/Inavi;->hudguide:Lcom/thinkware/sundo/remoteHUD/HUDGuide;

    iget v8, p0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->m_bConfSignInfo:I

    iput v8, v7, Lcom/thinkware/sundo/remoteHUD/HUDGuide;->m_bConfSignInfo:I

    .line 3444
    sget-object v7, Lcom/thinkware/sundo/inavi3d/Inavi;->hudguide:Lcom/thinkware/sundo/remoteHUD/HUDGuide;

    iget v8, p0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->m_bConfLaneInfo:I

    iput v8, v7, Lcom/thinkware/sundo/remoteHUD/HUDGuide;->m_bConfLaneInfo:I

    .line 3445
    sget-object v7, Lcom/thinkware/sundo/inavi3d/Inavi;->hudguide:Lcom/thinkware/sundo/remoteHUD/HUDGuide;

    iget v8, p0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->m_bConfCrossNm:I

    iput v8, v7, Lcom/thinkware/sundo/remoteHUD/HUDGuide;->m_bConfCrossNm:I

    .line 3446
    sget-object v7, Lcom/thinkware/sundo/inavi3d/Inavi;->hudguide:Lcom/thinkware/sundo/remoteHUD/HUDGuide;

    iget v8, p0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->m_bConfRestAreaNm:I

    iput v8, v7, Lcom/thinkware/sundo/remoteHUD/HUDGuide;->m_bConfRestAreaNm:I

    .line 3447
    sget-object v7, Lcom/thinkware/sundo/inavi3d/Inavi;->hudguide:Lcom/thinkware/sundo/remoteHUD/HUDGuide;

    iget v8, p0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->m_bConfTrackState:I

    iput v8, v7, Lcom/thinkware/sundo/remoteHUD/HUDGuide;->m_bConfTrackState:I

    .line 3448
    sget-object v7, Lcom/thinkware/sundo/inavi3d/Inavi;->hudguide:Lcom/thinkware/sundo/remoteHUD/HUDGuide;

    iget v8, p0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->m_bConfSpeed:I

    iput v8, v7, Lcom/thinkware/sundo/remoteHUD/HUDGuide;->m_bConfSpeed:I

    .line 3450
    sget-object v7, Lcom/thinkware/sundo/inavi3d/Inavi;->hudguide:Lcom/thinkware/sundo/remoteHUD/HUDGuide;

    iget-boolean v8, p0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->isSimulation:Z

    iput-boolean v8, v7, Lcom/thinkware/sundo/remoteHUD/HUDGuide;->isSimulation:Z

    .line 3451
    return-void

    .line 3330
    .end local v0    # "bTimeRequired":Z
    .end local v2    # "goalIndex":I
    .end local v3    # "index":I
    .end local v4    # "nHourTime":I
    .end local v5    # "nMinTime":I
    :cond_5
    iget v7, p0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->dis_cross2:I

    div-int/lit8 v7, v7, 0xa

    mul-int/lit8 v1, v7, 0xa

    .line 3331
    if-nez v1, :cond_1

    .line 3332
    const/16 v1, 0xa

    goto/16 :goto_0

    .line 3416
    .restart local v0    # "bTimeRequired":Z
    .restart local v2    # "goalIndex":I
    .restart local v3    # "index":I
    :cond_6
    const/4 v0, 0x1

    goto :goto_1

    .line 3425
    .restart local v4    # "nHourTime":I
    .restart local v5    # "nMinTime":I
    :cond_7
    iget-object v7, p0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->MulitGoalArriveHour:[I

    aget v4, v7, v3

    .line 3426
    iget-object v7, p0, Lcom/thinkware/sundo/remoteTBT/TBTGuide;->MulitGoalArriveMin:[I

    aget v5, v7, v3

    goto :goto_2
.end method

.method public static native setLiveRoute(Z)V
.end method

.method public static native setLiveRouteAutoChange(Z)V
.end method

.method public static native setLongTimeTest(IIIII)V
.end method

.method public static native setSearchDataFlagForUserLog(Z)V
.end method

.method public static native setSuperCapPowerOff(Z)V
.end method

.method public static setTbtguide(Lcom/thinkware/sundo/remoteTBT/TBTGuide;)V
    .locals 0
    .param p0, "tbtguide"    # Lcom/thinkware/sundo/remoteTBT/TBTGuide;

    .prologue
    .line 3296
    sput-object p0, Lcom/thinkware/sundo/inavi3d/Inavi;->tbtguide:Lcom/thinkware/sundo/remoteTBT/TBTGuide;

    .line 3297
    return-void
.end method

.method public static setUI()V
    .locals 2

    .prologue
    .line 3154
    sget-object v0, Lcom/thinkware/sundo/inavi3d/Inavi;->mHandlerMain:Landroid/os/Handler;

    new-instance v1, Lcom/thinkware/sundo/inavi3d/Inavi$16;

    invoke-direct {v1}, Lcom/thinkware/sundo/inavi3d/Inavi$16;-><init>()V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 3289
    return-void
.end method

.method public static native setULogEvent(II)V
.end method

.method public static native setULogEventPOILOCMAP()V
.end method

.method public static native setULogEventPOILOCSTART()V
.end method

.method public static native setULogFreq(I)V
.end method

.method public static setULogLocationData(IIIII)V
    .locals 6
    .param p0, "nMode"    # I
    .param p1, "nPosX"    # I
    .param p2, "nPosY"    # I
    .param p3, "nTime"    # I
    .param p4, "nViewMode"    # I

    .prologue
    const/4 v5, 0x0

    .line 1025
    sget-object v2, Lcom/thinkware/sundo/inavi3d/Inavi;->mContext:Landroid/content/Context;

    const-string v3, "ULOG_LOCATION_DATA"

    invoke-virtual {v2, v3, v5}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v1

    .line 1028
    .local v1, "pref":Landroid/content/SharedPreferences;
    invoke-interface {v1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    .line 1029
    .local v0, "edit":Landroid/content/SharedPreferences$Editor;
    if-nez p0, :cond_0

    .line 1030
    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->clear()Landroid/content/SharedPreferences$Editor;

    .line 1031
    const-string v2, "nStartPosX"

    invoke-interface {v0, v2, p1}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    .line 1032
    const-string v2, "nStartPosY"

    invoke-interface {v0, v2, p2}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    .line 1033
    const-string v2, "nStartTime"

    invoke-interface {v0, v2, p3}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    .line 1034
    const-string v2, "nStartViewMode"

    invoke-interface {v0, v2, p4}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    .line 1043
    :goto_0
    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->commit()Z

    .line 1045
    const-string v2, "inavi3d_gothmog"

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "UserLog setData setULogLocationData : nStartPosX "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, "nStartPosX"

    invoke-interface {v1, v4, v5}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, ", nStartPosY "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, "nStartPosY"

    invoke-interface {v1, v4, v5}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, ", nStartTime "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, "nStartTime"

    invoke-interface {v1, v4, v5}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, ", nStartViewMode "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, "nStartViewMode"

    invoke-interface {v1, v4, v5}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, ", nEndPosX "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, "nEndPosX"

    invoke-interface {v1, v4, v5}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, ", nEndPosY "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, "nEndPosY"

    invoke-interface {v1, v4, v5}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, ", nEndTime "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, "nEndTime"

    invoke-interface {v1, v4, v5}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, ", nEndViewMode "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, "nEndViewMode"

    invoke-interface {v1, v4, v5}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Lcom/thinkware/sundo/inavi3d/LOGTW;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 1047
    return-void

    .line 1035
    :cond_0
    const/4 v2, 0x1

    if-ne p0, v2, :cond_1

    .line 1036
    const-string v2, "nEndPosX"

    invoke-interface {v0, v2, p1}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    .line 1037
    const-string v2, "nEndPosY"

    invoke-interface {v0, v2, p2}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    .line 1038
    const-string v2, "nEndTime"

    invoke-interface {v0, v2, p3}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    .line 1039
    const-string v2, "nEndViewMode"

    invoke-interface {v0, v2, p4}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    goto/16 :goto_0

    .line 1041
    :cond_1
    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->clear()Landroid/content/SharedPreferences$Editor;

    goto/16 :goto_0
.end method

.method public static setULogRegisterEstimateData(IIII)V
    .locals 6
    .param p0, "nStartPosX"    # I
    .param p1, "nStartPosY"    # I
    .param p2, "nDistance"    # I
    .param p3, "time"    # I

    .prologue
    const/4 v5, 0x0

    .line 997
    sget-object v2, Lcom/thinkware/sundo/inavi3d/Inavi;->mContext:Landroid/content/Context;

    const-string v3, "ULOG_ESTIMATE_DATA"

    invoke-virtual {v2, v3, v5}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v1

    .line 999
    .local v1, "pref":Landroid/content/SharedPreferences;
    invoke-interface {v1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    .line 1001
    .local v0, "edit":Landroid/content/SharedPreferences$Editor;
    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->clear()Landroid/content/SharedPreferences$Editor;

    .line 1002
    const-string v2, "nStartPosX"

    invoke-interface {v0, v2, p0}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    .line 1003
    const-string v2, "nStartPosY"

    invoke-interface {v0, v2, p1}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    .line 1004
    const-string v2, "nEstimateDistance"

    invoke-interface {v0, v2, p2}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    .line 1005
    const-string v2, "nEstimateTime"

    invoke-interface {v0, v2, p3}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    .line 1006
    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->commit()Z

    .line 1008
    const-string v2, "inavi3d_gothmog"

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "UserLog setData setEstimateData : startPosX "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, "nStartPosX"

    invoke-interface {v1, v4, v5}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, ", nStartPosY "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, "nStartPosY"

    invoke-interface {v1, v4, v5}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, ", nEstDis "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, "nEstimateDistance"

    invoke-interface {v1, v4, v5}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, ", nEstTime "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, "nEstimateTime"

    invoke-interface {v1, v4, v5}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Lcom/thinkware/sundo/inavi3d/LOGTW;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 1009
    return-void
.end method

.method public static native setULogSearch(Z)V
.end method

.method public static toByteArray(Ljava/lang/Object;)[B
    .locals 4
    .param p0, "obj"    # Ljava/lang/Object;

    .prologue
    .line 824
    const/4 v1, 0x0

    .line 825
    .local v1, "bytes":[B
    new-instance v0, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v0}, Ljava/io/ByteArrayOutputStream;-><init>()V

    .line 827
    .local v0, "bos":Ljava/io/ByteArrayOutputStream;
    :try_start_0
    new-instance v2, Ljava/io/ObjectOutputStream;

    invoke-direct {v2, v0}, Ljava/io/ObjectOutputStream;-><init>(Ljava/io/OutputStream;)V

    .line 828
    .local v2, "oos":Ljava/io/ObjectOutputStream;
    invoke-virtual {v2, p0}, Ljava/io/ObjectOutputStream;->writeObject(Ljava/lang/Object;)V

    .line 829
    invoke-virtual {v2}, Ljava/io/ObjectOutputStream;->flush()V

    .line 830
    invoke-virtual {v2}, Ljava/io/ObjectOutputStream;->close()V

    .line 831
    invoke-virtual {v0}, Ljava/io/ByteArrayOutputStream;->close()V

    .line 832
    invoke-virtual {v0}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    move-result-object v1

    .line 836
    .end local v2    # "oos":Ljava/io/ObjectOutputStream;
    :goto_0
    return-object v1

    .line 833
    :catch_0
    move-exception v3

    goto :goto_0
.end method

.method public static native updatePLogRankingData([Lcom/thinkware/sundo/inavi3d/fivepin/PLogRankingData;IZ)V
.end method

.method public static native updatePLogRankingDataForCurrentOn([Lcom/thinkware/sundo/inavi3d/fivepin/PLogRankingData;IZ)V
.end method


# virtual methods
.method public native CNaviConfigGet(I)I
.end method

.method public native CNaviConfingGet(I)I
.end method

.method public native COMPACTARSetUseDRConfig(Z)V
.end method

.method public native DPPause(Z)V
.end method

.method public native DirectRoute(ILcom/thinkware/sundo/inavi3d/Struct/InaviPoint;)V
.end method

.method public DirectRouteWaitCursor(ILcom/thinkware/sundo/inavi3d/Struct/InaviPoint;)V
    .locals 1
    .param p1, "type"    # I
    .param p2, "point"    # Lcom/thinkware/sundo/inavi3d/Struct/InaviPoint;

    .prologue
    .line 405
    const/4 v0, 0x1

    sput-boolean v0, Lcom/thinkware/sundo/inavi3d/ui/popup/PopupManager;->mRouteSearchWaitCursor:Z

    .line 406
    invoke-virtual {p0, p1, p2}, Lcom/thinkware/sundo/inavi3d/Inavi;->DirectRoute(ILcom/thinkware/sundo/inavi3d/Struct/InaviPoint;)V

    .line 407
    return-void
.end method

.method public native DualMapZoomIn()Z
.end method

.method public native DualMapZoomOut()Z
.end method

.method public native GetRouteLineVerteces()[F
.end method

.method public native GetTraficType()I
.end method

.method public native GetVolume()I
.end method

.method public native Initialize(Ljava/lang/String;II)Z
.end method

.method public native IsEscapeRoute()Z
.end method

.method public native LocationRevision()Z
.end method

.method public native MapViewPopupClose()Z
.end method

.method public native MapZoomIn()Z
.end method

.method public native MapZoomOut()Z
.end method

.method public native MuteStatus(Z)V
.end method

.method public native PositionMove(ILcom/thinkware/sundo/inavi3d/Struct/InaviPoint;)V
.end method

.method public ProcessSolution(Landroid/content/Intent;)V
    .locals 10
    .param p1, "intent"    # Landroid/content/Intent;

    .prologue
    const/16 v9, 0x270f

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v6, -0x1

    .line 653
    invoke-virtual {p1}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v4

    if-nez v4, :cond_1

    .line 694
    :cond_0
    :goto_0
    return-void

    .line 656
    :cond_1
    invoke-virtual {p1}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v4

    const-string v5, "com.thinkware.sundo.inavi3d.action.RUN"

    invoke-virtual {v4, v5}, Ljava/lang/String;->compareTo(Ljava/lang/String;)I

    move-result v4

    if-eqz v4, :cond_0

    .line 659
    invoke-virtual {p1}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v4

    const-string v5, "com.thinkware.sundo.inavi3d.action.EXIT"

    invoke-virtual {v4, v5}, Ljava/lang/String;->compareTo(Ljava/lang/String;)I

    move-result v4

    if-nez v4, :cond_2

    .line 661
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/Inavi;->force_exit:Z

    .line 662
    invoke-virtual {p0, v9, v7}, Lcom/thinkware/sundo/inavi3d/Inavi;->onCommande(II)V

    goto :goto_0

    .line 664
    :cond_2
    invoke-virtual {p1}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v4

    const-string v5, "android.intent.action.ACTION_SHUTDOWN"

    invoke-virtual {v4, v5}, Ljava/lang/String;->compareTo(Ljava/lang/String;)I

    move-result v4

    if-nez v4, :cond_3

    .line 666
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/Inavi;->force_exit:Z

    .line 667
    invoke-virtual {p0, v9, v7}, Lcom/thinkware/sundo/inavi3d/Inavi;->onCommande(II)V

    goto :goto_0

    .line 669
    :cond_3
    invoke-virtual {p1}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v4

    const-string v5, "android.intent.action.MEDIA_EJECT"

    invoke-virtual {v4, v5}, Ljava/lang/String;->compareTo(Ljava/lang/String;)I

    move-result v4

    if-nez v4, :cond_4

    .line 671
    const-string v4, "inavi3d_java"

    const-string v5, "android.intent.action.MEDIA_EJECT2"

    invoke-static {v4, v5}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 672
    iput-boolean v8, p0, Lcom/thinkware/sundo/inavi3d/Inavi;->force_exit:Z

    .line 673
    invoke-virtual {p0, v9, v7}, Lcom/thinkware/sundo/inavi3d/Inavi;->onCommande(II)V

    goto :goto_0

    .line 675
    :cond_4
    invoke-virtual {p1}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v4

    const-string v5, "com.thinkware.sundo.inavi3d.action.MAPMOVE"

    invoke-virtual {v4, v5}, Ljava/lang/String;->compareTo(Ljava/lang/String;)I

    move-result v4

    if-nez v4, :cond_5

    .line 679
    const-string v4, "name"

    invoke-virtual {p1, v4}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 680
    .local v2, "name":Ljava/lang/String;
    new-instance v3, Lcom/thinkware/sundo/inavi3d/Inavi$location;

    invoke-direct {v3, p0}, Lcom/thinkware/sundo/inavi3d/Inavi$location;-><init>(Lcom/thinkware/sundo/inavi3d/Inavi;)V

    .line 682
    .local v3, "wgs84":Lcom/thinkware/sundo/inavi3d/Inavi$location;
    const-string v4, "longitude"

    invoke-virtual {p1, v4, v6}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v4

    iput v4, v3, Lcom/thinkware/sundo/inavi3d/Inavi$location;->longitude:I

    .line 683
    const-string v4, "latitude"

    invoke-virtual {p1, v4, v6}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v4

    iput v4, v3, Lcom/thinkware/sundo/inavi3d/Inavi$location;->latitude:I

    .line 684
    const-string v4, "level"

    const/16 v5, 0xd

    invoke-virtual {p1, v4, v5}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v0

    .line 686
    .local v0, "level":I
    iget v4, v3, Lcom/thinkware/sundo/inavi3d/Inavi$location;->longitude:I

    iget v5, v3, Lcom/thinkware/sundo/inavi3d/Inavi$location;->latitude:I

    invoke-virtual {p0, v2, v4, v5, v0}, Lcom/thinkware/sundo/inavi3d/Inavi;->solutionMoveMap(Ljava/lang/String;III)V

    goto :goto_0

    .line 687
    .end local v0    # "level":I
    .end local v2    # "name":Ljava/lang/String;
    .end local v3    # "wgs84":Lcom/thinkware/sundo/inavi3d/Inavi$location;
    :cond_5
    invoke-virtual {p1}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v4

    const-string v5, "com.thinkware.sundo.inavi3d.action.SECRETKEY.BR.FG"

    invoke-virtual {v4, v5}, Ljava/lang/String;->compareTo(Ljava/lang/String;)I

    move-result v4

    if-nez v4, :cond_0

    .line 689
    const-string v4, "msg_id"

    invoke-virtual {p1, v4, v6}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v1

    .line 690
    .local v1, "msg_id":I
    const/16 v4, 0x7530

    invoke-virtual {p0, v4, v1, v6, v6}, Lcom/thinkware/sundo/inavi3d/Inavi;->PushMessage(IIII)V

    goto/16 :goto_0
.end method

.method public native PushMessage(IIII)V
.end method

.method public native ReRoute()Z
.end method

.method public native SetConfigSave()Z
.end method

.method public native SetMute(I)Z
.end method

.method public SetRouteBinder(Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;)V
    .locals 0
    .param p1, "binder"    # Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    .prologue
    .line 644
    sput-object p1, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    .line 645
    return-void
.end method

.method public native SetSchUIType(I)I
.end method

.method public native SetVolume(I)Z
.end method

.method public native StartCCTVLinkPrjection()V
.end method

.method public native TCONProcessStatus(IIIII)V
.end method

.method public native UpdateRoute()V
.end method

.method public native UserSafeCamera()I
.end method

.method public native birdviewtracking(I)V
.end method

.method public native destroy()V
.end method

.method public native executeRender(J)V
.end method

.method public native executeRender2(J)V
.end method

.method public native initCallBack()V
.end method

.method public native isExecuteAvoid()Z
.end method

.method public native isInitDone()Z
.end method

.method public native isMute()Z
.end method

.method public native nativeRouteCancle()Z
.end method

.method public native onButtonDown(II)V
.end method

.method public native onButtonUp(II)V
.end method

.method public native onCommande(II)V
.end method

.method public native onMultiButton(FFFFI)V
.end method

.method public native onSingleButton(FFI)V
.end method

.method public native playSoundStatus(Z)V
.end method

.method public native preinit(Ljava/lang/String;I)V
.end method

.method public processIX(Landroid/content/Intent;)V
    .locals 4
    .param p1, "intent"    # Landroid/content/Intent;

    .prologue
    const/4 v3, 0x1

    .line 3534
    const-class v1, Lcom/thinkware/sundo/inavi3d/Inavi;

    const-string v2, ""

    invoke-static {v1, v2}, Lcom/thinkware/sundo/inavi3d/util/TWLogger;->df(Ljava/lang/Class;Ljava/lang/String;)V

    .line 3535
    if-nez p1, :cond_1

    .line 3548
    :cond_0
    :goto_0
    return-void

    .line 3538
    :cond_1
    invoke-virtual {p1}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v0

    .line 3539
    .local v0, "strAction":Ljava/lang/String;
    if-eqz v0, :cond_0

    .line 3540
    const-string v1, "com.thinkware.sundo.inavi3d.action.EXIT"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-ne v1, v3, :cond_2

    .line 3542
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v1

    iget-object v1, v1, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->receiverHandler:Landroid/os/Handler;

    const v2, 0x493e1

    invoke-virtual {v1, v2}, Landroid/os/Handler;->sendEmptyMessage(I)Z

    goto :goto_0

    .line 3543
    :cond_2
    const-string v1, "com.thinkware.ivision.action.ROUTEDEL"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-ne v1, v3, :cond_0

    .line 3545
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v1

    iget-object v1, v1, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->receiverHandler:Landroid/os/Handler;

    const v2, 0x493e2

    invoke-virtual {v1, v2}, Landroid/os/Handler;->sendEmptyMessage(I)Z

    goto :goto_0
.end method

.method public native setDisplaySize(II)V
.end method

.method public native setHardwareDisplaySize(III)V
.end method

.method public setOBD2Data(Lcom/tw/mapmatch/dataset/_MMOBD2Data;)V
    .locals 2
    .param p1, "obd2Data"    # Lcom/tw/mapmatch/dataset/_MMOBD2Data;

    .prologue
    .line 3495
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    if-nez v1, :cond_0

    .line 3504
    :goto_0
    return-void

    .line 3499
    :cond_0
    :try_start_0
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    invoke-interface {v1, p1}, Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;->setOBD2Data(Lcom/tw/mapmatch/dataset/_MMOBD2Data;)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    .line 3500
    :catch_0
    move-exception v0

    .line 3502
    .local v0, "e":Landroid/os/RemoteException;
    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    goto :goto_0
.end method

.method public native setSupportAirMode(Z)V
.end method

.method public setTimerEvent(II)V
    .locals 2
    .param p1, "timerType"    # I
    .param p2, "TimerID"    # I

    .prologue
    .line 427
    const v0, 0x222e0

    const v1, 0x27100

    invoke-virtual {p0, v0, v1, p1, p2}, Lcom/thinkware/sundo/inavi3d/Inavi;->PushMessage(IIII)V

    .line 428
    return-void
.end method

.method public native setTimerEventNative(II)V
.end method

.method setUIManager(Lcom/thinkware/sundo/inavi3d/UIManager;)V
    .locals 0
    .param p1, "manager"    # Lcom/thinkware/sundo/inavi3d/UIManager;

    .prologue
    .line 640
    sput-object p1, Lcom/thinkware/sundo/inavi3d/Inavi;->mUIManager:Lcom/thinkware/sundo/inavi3d/UIManager;

    .line 641
    return-void
.end method

.method public setUseOBD2(Z)V
    .locals 2
    .param p1, "use"    # Z

    .prologue
    .line 3484
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    if-nez v1, :cond_0

    .line 3493
    :goto_0
    return-void

    .line 3488
    :cond_0
    :try_start_0
    sget-object v1, Lcom/thinkware/sundo/inavi3d/Inavi;->mRouteBinder:Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;

    invoke-interface {v1, p1}, Lcom/thinkware/sundo/inavi3dservice/ILocationInfoInterface;->setUseOBD2Data(Z)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    .line 3489
    :catch_0
    move-exception v0

    .line 3491
    .local v0, "e":Landroid/os/RemoteException;
    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    goto :goto_0
.end method

.method public native solutionMoveMap(Ljava/lang/String;III)V
.end method

.method public native volumerange(I)V
.end method
