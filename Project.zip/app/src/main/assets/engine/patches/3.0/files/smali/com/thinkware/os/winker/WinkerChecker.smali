.class public Lcom/thinkware/os/winker/WinkerChecker;
.super Ljava/lang/Thread;
.source "WinkerChecker.java"


# static fields
.field private static final BIT_LEFT:I = 0x1

.field private static final BIT_LEFT_SHIFT:I = 0x0

.field private static final BIT_RIGHT:I = 0x2

.field private static final BIT_RIGHT_SHIFT:I = 0x1

.field static FileFailCnt:I

.field private static final TAG:Ljava/lang/String;


# instance fields
.field private mListener:Lcom/thinkware/os/winker/IWinkerStateListener;

.field private mStop:Z


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .prologue
    .line 13
    const-class v0, Lcom/thinkware/os/winker/WinkerChecker;

    invoke-virtual {v0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/thinkware/os/winker/WinkerChecker;->TAG:Ljava/lang/String;

    .line 29
    const/4 v0, 0x0

    sput v0, Lcom/thinkware/os/winker/WinkerChecker;->FileFailCnt:I

    return-void
.end method

.method public constructor <init>(Lcom/thinkware/os/winker/IWinkerStateListener;)V
    .locals 1
    .param p1, "listener"    # Lcom/thinkware/os/winker/IWinkerStateListener;

    .prologue
    .line 31
    invoke-direct {p0}, Ljava/lang/Thread;-><init>()V

    .line 27
    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/thinkware/os/winker/WinkerChecker;->mStop:Z

    .line 32
    iput-object p1, p0, Lcom/thinkware/os/winker/WinkerChecker;->mListener:Lcom/thinkware/os/winker/IWinkerStateListener;

    .line 33
    return-void
.end method

.method private notifyState(I)V
    .locals 3
    .param p1, "state"    # I

    .prologue
    .line 65
    and-int/lit8 v2, p1, 0x1

    shr-int/lit8 v0, v2, 0x0

    .line 66
    .local v0, "leftState":I
    and-int/lit8 v2, p1, 0x2

    shr-int/lit8 v1, v2, 0x1

    .line 68
    .local v1, "rightState":I
    iget-object v2, p0, Lcom/thinkware/os/winker/WinkerChecker;->mListener:Lcom/thinkware/os/winker/IWinkerStateListener;

    invoke-interface {v2, v0, v1}, Lcom/thinkware/os/winker/IWinkerStateListener;->onStateValue(II)V

    .line 69
    return-void
.end method

.method private readWinkerState()I
    .locals 8

    .prologue
    const/16 v5, 0x400

    const/4 v7, 0x0

    .line 36
    new-array v0, v5, [C

    .line 38
    .local v0, "buffer":[C
    const/4 v4, 0x0

    .line 40
    .local v4, "state":I
    :try_start_0
    new-instance v2, Ljava/io/FileReader;

    const-string v5, "/sys/class/switch/winker_switch/state"

    invoke-direct {v2, v5}, Ljava/io/FileReader;-><init>(Ljava/lang/String;)V

    .line 41
    .local v2, "file":Ljava/io/FileReader;
    const/4 v5, 0x0

    const/16 v6, 0x400

    invoke-virtual {v2, v0, v5, v6}, Ljava/io/InputStreamReader;->read([CII)I

    move-result v3

    .line 42
    .local v3, "len":I
    invoke-virtual {v2}, Ljava/io/InputStreamReader;->close()V

    .line 43
    new-instance v5, Ljava/lang/String;

    const/4 v6, 0x0

    invoke-direct {v5, v0, v6, v3}, Ljava/lang/String;-><init>([CII)V

    invoke-virtual {v5}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v5

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/Integer;->intValue()I
    :try_end_0
    .catch Ljava/io/FileNotFoundException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1

    move-result v4

    .line 61
    .end local v2    # "file":Ljava/io/FileReader;
    .end local v3    # "len":I
    :cond_0
    :goto_0
    return v4

    .line 45
    :catch_0
    move-exception v1

    .line 46
    .local v1, "e":Ljava/io/FileNotFoundException;
    sget-object v5, Lcom/thinkware/os/winker/WinkerChecker;->TAG:Ljava/lang/String;

    const-string v6, "This kernel does not have winker support"

    invoke-static {v5, v6}, Landroid/util/Slog;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 48
    sget-object v5, Landroid/os/Build;->DEVICE:Ljava/lang/String;

    const-string v6, "runa"

    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_1

    sget-object v5, Landroid/os/Build;->DEVICE:Ljava/lang/String;

    const-string v6, "mxb"

    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_1

    sget-object v5, Landroid/os/Build;->DEVICE:Ljava/lang/String;

    const-string v6, "mowgli"

    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_1

    sget-object v5, Landroid/os/Build;->DEVICE:Ljava/lang/String;

    const-string v6, "lucya"

    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_1

    sget-object v5, Landroid/os/Build;->DEVICE:Ljava/lang/String;

    const-string v6, "lucyb"

    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_1

    sget-object v5, Landroid/os/Build;->DEVICE:Ljava/lang/String;

    const-string v6, "lucyr"

    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_0

    .line 49
    :cond_1
    sget v5, Lcom/thinkware/os/winker/WinkerChecker;->FileFailCnt:I

    add-int/lit8 v5, v5, 0x1

    sput v5, Lcom/thinkware/os/winker/WinkerChecker;->FileFailCnt:I

    .line 51
    sget v5, Lcom/thinkware/os/winker/WinkerChecker;->FileFailCnt:I

    const/16 v6, 0xa

    if-le v5, v6, :cond_0

    .line 52
    const/4 v5, 0x1

    iput-boolean v5, p0, Lcom/thinkware/os/winker/WinkerChecker;->mStop:Z

    .line 53
    sput v7, Lcom/thinkware/os/winker/WinkerChecker;->FileFailCnt:I

    goto :goto_0

    .line 57
    .end local v1    # "e":Ljava/io/FileNotFoundException;
    :catch_1
    move-exception v1

    .line 58
    .local v1, "e":Ljava/lang/Exception;
    sget-object v5, Lcom/thinkware/os/winker/WinkerChecker;->TAG:Ljava/lang/String;

    const-string v6, ""

    invoke-static {v5, v6, v1}, Landroid/util/Slog;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    goto :goto_0
.end method


# virtual methods
.method public quit()V
    .locals 1

    .prologue
    .line 89
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/thinkware/os/winker/WinkerChecker;->mStop:Z

    .line 90
    return-void
.end method

.method public run()V
    .locals 4

    .prologue
    .line 73
    :goto_0
    iget-boolean v2, p0, Lcom/thinkware/os/winker/WinkerChecker;->mStop:Z

    if-nez v2, :cond_0

    .line 74
    const/4 v1, 0x0

    .line 75
    .local v1, "state":I
    invoke-direct {p0}, Lcom/thinkware/os/winker/WinkerChecker;->readWinkerState()I

    move-result v1

    .line 78
    const-wide/16 v2, 0x64

    :try_start_0
    invoke-static {v2, v3}, Ljava/lang/Thread;->sleep(J)V
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0

    .line 84
    :goto_1
    invoke-direct {p0, v1}, Lcom/thinkware/os/winker/WinkerChecker;->notifyState(I)V

    goto :goto_0

    .line 79
    :catch_0
    move-exception v0

    .line 81
    .local v0, "e":Ljava/lang/InterruptedException;
    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    goto :goto_1

    .line 86
    .end local v0    # "e":Ljava/lang/InterruptedException;
    .end local v1    # "state":I
    :cond_0
    return-void
.end method
