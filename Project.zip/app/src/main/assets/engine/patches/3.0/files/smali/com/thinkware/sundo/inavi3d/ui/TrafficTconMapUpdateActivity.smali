.class public Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;
.super Lcom/thinkware/sundo/inavi3d/MainActivity;
.source "TrafficTconMapUpdateActivity.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# static fields
.field public static final ERROR_999:I = 0x3e7

.field public static final UI_COMPLETE:I = 0x3

.field public static final UI_ERROR:I = 0x4

.field public static final UI_INIT:I = 0x1

.field public static final UI_RUNNING:I = 0x2

.field public static mHandler:Landroid/os/Handler;

.field private static mThisInastance:Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;


# instance fields
.field private btnRestartInavi:Landroid/widget/Button;

.field private btnStartUpdata:Landroid/widget/Button;

.field m_bDownLoadComplete:Z

.field m_bNowDownLoading:Z

.field m_imgTconMapUpdateInfoTopSub1_Comma:Landroid/widget/ImageView;

.field m_imgTconMapUpdateInfoTopSub2_Comma:Landroid/widget/ImageView;

.field m_imgTconMapUpdateInfoTopSub3_Comma:Landroid/widget/ImageView;

.field m_txtTconMapUpdateInfoBottom1:Landroid/widget/TextView;

.field m_txtTconMapUpdateInfoTop:Landroid/widget/TextView;

.field m_txtTconMapUpdateInfoTopSub1:Landroid/widget/TextView;

.field m_txtTconMapUpdateInfoTopSub1_Info:Landroid/widget/TextView;

.field m_txtTconMapUpdateInfoTopSub2:Landroid/widget/TextView;

.field m_txtTconMapUpdateInfoTopSub2_Info:Landroid/widget/TextView;

.field m_txtTconMapUpdateInfoTopSub3:Landroid/widget/TextView;

.field m_txtTconMapUpdateInfoTopSub3_Info:Landroid/widget/TextView;

.field m_txtTconMapUpdateInfo_DownLoading_Percent:Landroid/widget/TextView;

.field m_txtTconMapUpdateInfo_DownLoading_Total:Landroid/widget/TextView;

.field progressBar:Landroid/widget/ProgressBar;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .prologue
    .line 33
    const/4 v0, 0x0

    sput-object v0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->mThisInastance:Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;

    .line 70
    new-instance v0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity$1;

    invoke-direct {v0}, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity$1;-><init>()V

    sput-object v0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->mHandler:Landroid/os/Handler;

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    .prologue
    const/4 v1, 0x0

    const/4 v0, 0x0

    .line 31
    invoke-direct {p0}, Lcom/thinkware/sundo/inavi3d/MainActivity;-><init>()V

    .line 45
    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_imgTconMapUpdateInfoTopSub1_Comma:Landroid/widget/ImageView;

    .line 46
    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_imgTconMapUpdateInfoTopSub2_Comma:Landroid/widget/ImageView;

    .line 47
    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_imgTconMapUpdateInfoTopSub3_Comma:Landroid/widget/ImageView;

    .line 49
    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfoTop:Landroid/widget/TextView;

    .line 50
    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfoTopSub1:Landroid/widget/TextView;

    .line 51
    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfoTopSub2:Landroid/widget/TextView;

    .line 52
    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfoTopSub3:Landroid/widget/TextView;

    .line 53
    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfoTopSub1_Info:Landroid/widget/TextView;

    .line 54
    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfoTopSub2_Info:Landroid/widget/TextView;

    .line 55
    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfoTopSub3_Info:Landroid/widget/TextView;

    .line 56
    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfoBottom1:Landroid/widget/TextView;

    .line 60
    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfo_DownLoading_Total:Landroid/widget/TextView;

    .line 61
    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfo_DownLoading_Percent:Landroid/widget/TextView;

    .line 66
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_bNowDownLoading:Z

    .line 67
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_bDownLoadComplete:Z

    return-void
.end method

.method static synthetic access$000()Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;
    .locals 1

    .prologue
    .line 31
    sget-object v0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->mThisInastance:Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;

    return-object v0
.end method

.method static getErrMsg(I)Ljava/lang/String;
    .locals 4
    .param p0, "errNum"    # I

    .prologue
    const/4 v1, 0x1

    const/4 v3, 0x0

    .line 168
    sparse-switch p0, :sswitch_data_0

    .line 185
    const-string v0, "\uc5c5\ub370\uc774\ud2b8 \uc911 \uc624\ub958\uac00 \ubc1c\uc0dd\ud558\uc600\uc2b5\ub2c8\ub2e4.(%d)\n\uc7a0\uc2dc \ud6c4 \ub2e4\uc2dc \uc2dc\ub3c4\ud574 \uc8fc\uc2ed\uc2dc\uc624."

    new-array v1, v1, [Ljava/lang/Object;

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    aput-object v2, v1, v3

    invoke-static {v0, v1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    :goto_0
    return-object v0

    .line 170
    :sswitch_0
    const-string v0, "\ub124\ud2b8\uc6cc\ud06c \uc0c1\ud0dc\ub97c \ud655\uc778\ud558\uc138\uc694.(%d)"

    new-array v1, v1, [Ljava/lang/Object;

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    aput-object v2, v1, v3

    invoke-static {v0, v1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    goto :goto_0

    .line 172
    :sswitch_1
    const-string v0, "SD\uce74\ub4dc\uc5d0 \uc6a9\ub7c9\uc774 \ubd80\uc871\ud569\ub2c8\ub2e4.(%d)"

    new-array v1, v1, [Ljava/lang/Object;

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    aput-object v2, v1, v3

    invoke-static {v0, v1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    goto :goto_0

    .line 175
    :sswitch_2
    const-string v0, "\uc5c5\ub370\uc774\ud2b8 \uc911 \uc624\ub958\uac00 \ubc1c\uc0dd\ud558\uc600\uc2b5\ub2c8\ub2e4.(%d)\n\uc7a0\uc2dc \ud6c4 \ub2e4\uc2dc \uc2dc\ub3c4\ud574 \uc8fc\uc2ed\uc2dc\uc624."

    new-array v1, v1, [Ljava/lang/Object;

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    aput-object v2, v1, v3

    invoke-static {v0, v1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    goto :goto_0

    .line 177
    :sswitch_3
    const-string v0, "\ub370\uc774\ud130\uac00 \uc815\uc0c1\uc801\uc774\uc9c0 \uc54a\uc2b5\ub2c8\ub2e4.(%d)"

    new-array v1, v1, [Ljava/lang/Object;

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    aput-object v2, v1, v3

    invoke-static {v0, v1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    goto :goto_0

    .line 179
    :sswitch_4
    const-string v0, "\uc5c5\ub370\uc774\ud2b8 \uc911 \uc624\ub958\uac00 \ubc1c\uc0dd\ud558\uc600\uc2b5\ub2c8\ub2e4.(%d)\n\uc7a0\uc2dc \ud6c4 \ub2e4\uc2dc \uc2dc\ub3c4\ud574 \uc8fc\uc2ed\uc2dc\uc624."

    new-array v1, v1, [Ljava/lang/Object;

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    aput-object v2, v1, v3

    invoke-static {v0, v1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    goto :goto_0

    .line 181
    :sswitch_5
    const-string v0, "\uc5c5\ub370\uc774\ud2b8 \uc911 \uc624\ub958\uac00 \ubc1c\uc0dd\ud558\uc600\uc2b5\ub2c8\ub2e4.(%d)\n\uc7a0\uc2dc \ud6c4 \ub2e4\uc2dc \uc2dc\ub3c4\ud574 \uc8fc\uc2ed\uc2dc\uc624."

    new-array v1, v1, [Ljava/lang/Object;

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    aput-object v2, v1, v3

    invoke-static {v0, v1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    goto :goto_0

    .line 183
    :sswitch_6
    const-string v0, "\uc11c\ubc84\uac00 \uc6d0\ud65c\ud558\uc9c0 \uc54a\uc2b5\ub2c8\ub2e4.(%d)\n\uc7a0\uc2dc \ud6c4 \ub2e4\uc2dc \uc2dc\ub3c4\ud574 \uc8fc\uc2ed\uc2dc\uc624."

    new-array v1, v1, [Ljava/lang/Object;

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    aput-object v2, v1, v3

    invoke-static {v0, v1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    goto :goto_0

    .line 168
    nop

    :sswitch_data_0
    .sparse-switch
        0x1838 -> :sswitch_2
        0x1839 -> :sswitch_0
        0x183b -> :sswitch_1
        0x183c -> :sswitch_3
        0x183d -> :sswitch_6
        0x183f -> :sswitch_5
        0x189b -> :sswitch_4
    .end sparse-switch
.end method


# virtual methods
.method protected DownLoadCompleteUI()V
    .locals 9

    .prologue
    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v5, 0x0

    .line 576
    const-string v3, "JUNE"

    const-string v4, "DownLoadCompleteUI "

    invoke-static {v3, v4}, Lcom/thinkware/sundo/inavi3d/LOGTW;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 582
    iput-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_bDownLoadComplete:Z

    .line 584
    const-string v2, ""

    .line 586
    .local v2, "strTmp":Ljava/lang/String;
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfoTop:Landroid/widget/TextView;

    invoke-virtual {v3, v5}, Landroid/widget/TextView;->setVisibility(I)V

    .line 587
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfoTop:Landroid/widget/TextView;

    const-string v4, "\ucd5c\uc2e0 \ubc84\uc804\uc744 \uc774\ubbf8 \ub2e4\uc6b4\ub85c\ub4dc \ud558\uc600\uc2b5\ub2c8\ub2e4. \uc544\uc774\ub098\ube44 \uc7ac \ubd80\ud305 \ud6c4 \uc5c5\ub370\uc774\ud2b8\ub41c \uc815\ubcf4\ub97c \uc774\uc6a9\ud558\uc2e4 \uc218 \uc788\uc2b5\ub2c8\ub2e4."

    invoke-virtual {v3, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 589
    sget-object v1, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_szServerMapVersion:Ljava/lang/String;

    .line 590
    .local v1, "nServerMapVersion":Ljava/lang/String;
    const-string v3, "."

    const-string v4, ""

    invoke-virtual {v1, v3, v4}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v1

    .line 591
    invoke-virtual {v1, v5, v8}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v1

    .line 592
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->loadMapVer()Ljava/lang/String;

    move-result-object v0

    .line 593
    .local v0, "Mapversion":Ljava/lang/String;
    const-string v3, "."

    const-string v4, ""

    invoke-virtual {v0, v3, v4}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v0

    .line 594
    invoke-virtual {v0, v5, v8}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v0

    .line 596
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_imgTconMapUpdateInfoTopSub1_Comma:Landroid/widget/ImageView;

    invoke-virtual {v3, v5}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 597
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_imgTconMapUpdateInfoTopSub2_Comma:Landroid/widget/ImageView;

    invoke-virtual {v3, v5}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 598
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfoTopSub1:Landroid/widget/TextView;

    invoke-virtual {v3, v5}, Landroid/widget/TextView;->setVisibility(I)V

    .line 599
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfoTopSub1_Info:Landroid/widget/TextView;

    invoke-virtual {v3, v5}, Landroid/widget/TextView;->setVisibility(I)V

    .line 600
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfoTopSub2:Landroid/widget/TextView;

    invoke-virtual {v3, v5}, Landroid/widget/TextView;->setVisibility(I)V

    .line 601
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfoTopSub2_Info:Landroid/widget/TextView;

    invoke-virtual {v3, v5}, Landroid/widget/TextView;->setVisibility(I)V

    .line 603
    const-string v2, "\ud604\uc7ac \ubc84\uc804"

    .line 604
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfoTopSub1:Landroid/widget/TextView;

    invoke-virtual {v3, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 605
    move-object v2, v0

    .line 606
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfoTopSub1_Info:Landroid/widget/TextView;

    invoke-virtual {v3, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 608
    const-string v2, "\uc5c5\uadf8\ub808\uc774\ub4dc \ubc84\uc804"

    .line 609
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfoTopSub2:Landroid/widget/TextView;

    invoke-virtual {v3, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 610
    move-object v2, v1

    .line 611
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfoTopSub2_Info:Landroid/widget/TextView;

    invoke-virtual {v3, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 613
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_imgTconMapUpdateInfoTopSub3_Comma:Landroid/widget/ImageView;

    invoke-virtual {v3, v6}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 614
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfoTopSub3:Landroid/widget/TextView;

    invoke-virtual {v3, v6}, Landroid/widget/TextView;->setVisibility(I)V

    .line 615
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfoTopSub3_Info:Landroid/widget/TextView;

    invoke-virtual {v3, v6}, Landroid/widget/TextView;->setVisibility(I)V

    .line 617
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfo_DownLoading_Total:Landroid/widget/TextView;

    invoke-virtual {v3, v6}, Landroid/widget/TextView;->setVisibility(I)V

    .line 618
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfo_DownLoading_Percent:Landroid/widget/TextView;

    invoke-virtual {v3, v6}, Landroid/widget/TextView;->setVisibility(I)V

    .line 620
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfoBottom1:Landroid/widget/TextView;

    invoke-virtual {v3, v6}, Landroid/widget/TextView;->setVisibility(I)V

    .line 624
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->progressBar:Landroid/widget/ProgressBar;

    invoke-virtual {v3, v6}, Landroid/widget/ProgressBar;->setVisibility(I)V

    .line 626
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->btnStartUpdata:Landroid/widget/Button;

    const-string v4, "\uc5c5\ub370\uc774\ud2b8 \uc2dc\uc791"

    invoke-virtual {v3, v4}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 627
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->btnStartUpdata:Landroid/widget/Button;

    invoke-virtual {v3, v5}, Landroid/widget/Button;->setEnabled(Z)V

    .line 628
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->btnRestartInavi:Landroid/widget/Button;

    invoke-virtual {v3, v7}, Landroid/widget/Button;->setEnabled(Z)V

    .line 629
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->btnRestartInavi:Landroid/widget/Button;

    invoke-virtual {v3, v5}, Landroid/widget/Button;->setVisibility(I)V

    .line 630
    return-void
.end method

.method protected DownLoadingUI(Lcom/thinkware/sundo/inavi3d/Struct/TconMapUpdateObj;)V
    .locals 16
    .param p1, "Obj"    # Lcom/thinkware/sundo/inavi3d/Struct/TconMapUpdateObj;

    .prologue
    .line 481
    move-object/from16 v0, p0

    iget-object v11, v0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->btnRestartInavi:Landroid/widget/Button;

    const/16 v12, 0x8

    invoke-virtual {v11, v12}, Landroid/widget/Button;->setVisibility(I)V

    .line 485
    const/4 v11, 0x1

    move-object/from16 v0, p0

    iput-boolean v11, v0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_bNowDownLoading:Z

    .line 488
    const/4 v3, 0x0

    .local v3, "filesize":I
    const/4 v10, 0x0

    .local v10, "totalfilesize":I
    const/4 v5, 0x0

    .local v5, "percent":I
    const/4 v2, 0x0

    .line 490
    .local v2, "fileid":I
    move-object/from16 v0, p1

    iget v3, v0, Lcom/thinkware/sundo/inavi3d/Struct/TconMapUpdateObj;->fileSize:I

    .line 491
    move-object/from16 v0, p1

    iget v10, v0, Lcom/thinkware/sundo/inavi3d/Struct/TconMapUpdateObj;->totalSize:I

    .line 492
    move-object/from16 v0, p1

    iget v9, v0, Lcom/thinkware/sundo/inavi3d/Struct/TconMapUpdateObj;->totalCnt:I

    .line 493
    .local v9, "totalCnt":I
    move-object/from16 v0, p1

    iget v5, v0, Lcom/thinkware/sundo/inavi3d/Struct/TconMapUpdateObj;->downPercent:I

    .line 494
    move-object/from16 v0, p1

    iget v2, v0, Lcom/thinkware/sundo/inavi3d/Struct/TconMapUpdateObj;->fileId:I

    .line 495
    const-string v7, ""

    .line 496
    .local v7, "strTmp":Ljava/lang/String;
    sget-boolean v11, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->mMRDownloadPauseFlag:Z

    const/4 v12, 0x1

    if-ne v11, v12, :cond_0

    .line 497
    new-instance v11, Ljava/lang/StringBuilder;

    invoke-direct {v11}, Ljava/lang/StringBuilder;-><init>()V

    const-string v12, "\ub2e4\uc6b4\ub85c\ub4dc\uac00 \uc911\uc9c0\ub418\uc5c8\uc2b5\ub2c8\ub2e4. ("

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    invoke-virtual {v11, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v11

    const-string v12, "/"

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    invoke-virtual {v11, v9}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v11

    const-string v12, ")"

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    .line 498
    move-object/from16 v0, p0

    iget-object v11, v0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->btnStartUpdata:Landroid/widget/Button;

    const-string v12, "\uc774\uc5b4\ubc1b\uae30"

    invoke-virtual {v11, v12}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 504
    :goto_0
    move-object/from16 v0, p0

    iget-object v11, v0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfoTop:Landroid/widget/TextView;

    const/4 v12, 0x0

    invoke-virtual {v11, v12}, Landroid/widget/TextView;->setVisibility(I)V

    .line 505
    move-object/from16 v0, p0

    iget-object v11, v0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfoTop:Landroid/widget/TextView;

    invoke-virtual {v11, v7}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 507
    move-object/from16 v0, p0

    iget-object v11, v0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfo_DownLoading_Total:Landroid/widget/TextView;

    const/4 v12, 0x0

    invoke-virtual {v11, v12}, Landroid/widget/TextView;->setVisibility(I)V

    .line 508
    move-object/from16 v0, p0

    iget-object v11, v0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfo_DownLoading_Percent:Landroid/widget/TextView;

    const/4 v12, 0x0

    invoke-virtual {v11, v12}, Landroid/widget/TextView;->setVisibility(I)V

    .line 510
    const-string v6, ""

    .line 511
    .local v6, "strSubSize":Ljava/lang/String;
    const/high16 v11, 0x100000

    if-le v3, v11, :cond_1

    .line 512
    div-int/lit16 v11, v3, 0x400

    div-int/lit16 v3, v11, 0x400

    .line 513
    new-instance v11, Ljava/lang/StringBuilder;

    invoke-direct {v11}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v11, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v11

    const-string v12, "MB"

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    .line 522
    :goto_1
    const-string v8, ""

    .line 523
    .local v8, "strTotalSize":Ljava/lang/String;
    const/high16 v11, 0x100000

    if-le v10, v11, :cond_3

    .line 524
    div-int/lit16 v11, v10, 0x400

    div-int/lit16 v10, v11, 0x400

    .line 525
    new-instance v11, Ljava/lang/StringBuilder;

    invoke-direct {v11}, Ljava/lang/StringBuilder;-><init>()V

    const-string v12, " / "

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    invoke-virtual {v11, v10}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v11

    const-string v12, "MB"

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    .line 533
    :goto_2
    move-object/from16 v0, p0

    iget-object v11, v0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfo_DownLoading_Total:Landroid/widget/TextView;

    new-instance v12, Ljava/lang/StringBuilder;

    invoke-direct {v12}, Ljava/lang/StringBuilder;-><init>()V

    const-string v13, "<FONT color=#00b7f4>"

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    invoke-virtual {v12, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    const-string v13, "</font>"

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    invoke-virtual {v12, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    invoke-virtual {v12}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v12

    invoke-static {v12}, Landroid/text/Html;->fromHtml(Ljava/lang/String;)Landroid/text/Spanned;

    move-result-object v12

    sget-object v13, Landroid/widget/TextView$BufferType;->SPANNABLE:Landroid/widget/TextView$BufferType;

    invoke-virtual {v11, v12, v13}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;Landroid/widget/TextView$BufferType;)V

    .line 536
    new-instance v11, Ljava/lang/StringBuilder;

    invoke-direct {v11}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v11, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v11

    const-string v12, "%"

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    .line 537
    move-object/from16 v0, p0

    iget-object v11, v0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfo_DownLoading_Percent:Landroid/widget/TextView;

    invoke-virtual {v11, v7}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 539
    move-object/from16 v0, p0

    iget-object v11, v0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->progressBar:Landroid/widget/ProgressBar;

    const/4 v12, 0x0

    invoke-virtual {v11, v12}, Landroid/widget/ProgressBar;->setVisibility(I)V

    .line 540
    move-object/from16 v0, p0

    iget-object v11, v0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->progressBar:Landroid/widget/ProgressBar;

    invoke-virtual {v11, v5}, Landroid/widget/ProgressBar;->setProgress(I)V

    .line 545
    const-string v1, ""

    .line 550
    .local v1, "fileName":Ljava/lang/String;
    move-object/from16 v0, p0

    iget-object v11, v0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfoBottom1:Landroid/widget/TextView;

    invoke-virtual {v11}, Landroid/widget/TextView;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v4

    check-cast v4, Landroid/widget/RelativeLayout$LayoutParams;

    .line 551
    .local v4, "layout":Landroid/widget/RelativeLayout$LayoutParams;
    const/16 v11, 0x190

    iput v11, v4, Landroid/widget/RelativeLayout$LayoutParams;->topMargin:I

    .line 552
    move-object/from16 v0, p0

    iget-object v11, v0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfoBottom1:Landroid/widget/TextView;

    const/4 v12, 0x0

    invoke-virtual {v11, v12}, Landroid/widget/TextView;->setVisibility(I)V

    .line 553
    move-object/from16 v0, p0

    iget-object v11, v0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfoBottom1:Landroid/widget/TextView;

    const-string v12, "\u203b\ub124\ud2b8\uc6cc\ud06c \uc5f0\uacb0 \uc0c1\ud0dc\uc5d0 \ub530\ub77c \uc218 \ubd84\uc774 \uc18c\uc694\ub420 \uc218 \uc788\uc73c\uba70, \ub370\uc774\ud130 \ud1b5\ud654\ub8cc\uac00 \ubc1c\uc0dd\ud560 \uc218 \uc788\uc2b5\ub2c8\ub2e4.\n\ub2e4\uc6b4\ub85c\ub4dc \ud6c4 \ub2e8\ub9d0\uae30\ub97c \uc7ac \ubd80\ud305\ud574\uc57c\ub9cc \uc5c5\ub370\uc774\ud2b8\ub41c \uc815\ubcf4\ub97c \uc774\uc6a9\ud558\uc2e4 \uc218 \uc788\uc2b5\ub2c8\ub2e4."

    invoke-virtual {v11, v12}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 556
    move-object/from16 v0, p0

    iget-object v11, v0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_imgTconMapUpdateInfoTopSub1_Comma:Landroid/widget/ImageView;

    const/4 v12, 0x4

    invoke-virtual {v11, v12}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 557
    move-object/from16 v0, p0

    iget-object v11, v0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_imgTconMapUpdateInfoTopSub2_Comma:Landroid/widget/ImageView;

    const/4 v12, 0x4

    invoke-virtual {v11, v12}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 558
    move-object/from16 v0, p0

    iget-object v11, v0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_imgTconMapUpdateInfoTopSub3_Comma:Landroid/widget/ImageView;

    const/4 v12, 0x4

    invoke-virtual {v11, v12}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 560
    move-object/from16 v0, p0

    iget-object v11, v0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfoTopSub1:Landroid/widget/TextView;

    const/4 v12, 0x4

    invoke-virtual {v11, v12}, Landroid/widget/TextView;->setVisibility(I)V

    .line 561
    move-object/from16 v0, p0

    iget-object v11, v0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfoTopSub2:Landroid/widget/TextView;

    const/4 v12, 0x4

    invoke-virtual {v11, v12}, Landroid/widget/TextView;->setVisibility(I)V

    .line 562
    move-object/from16 v0, p0

    iget-object v11, v0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfoTopSub3:Landroid/widget/TextView;

    const/4 v12, 0x4

    invoke-virtual {v11, v12}, Landroid/widget/TextView;->setVisibility(I)V

    .line 563
    move-object/from16 v0, p0

    iget-object v11, v0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfoTopSub1_Info:Landroid/widget/TextView;

    const/4 v12, 0x4

    invoke-virtual {v11, v12}, Landroid/widget/TextView;->setVisibility(I)V

    .line 564
    move-object/from16 v0, p0

    iget-object v11, v0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfoTopSub2_Info:Landroid/widget/TextView;

    const/4 v12, 0x4

    invoke-virtual {v11, v12}, Landroid/widget/TextView;->setVisibility(I)V

    .line 565
    move-object/from16 v0, p0

    iget-object v11, v0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfoTopSub3_Info:Landroid/widget/TextView;

    const/4 v12, 0x4

    invoke-virtual {v11, v12}, Landroid/widget/TextView;->setVisibility(I)V

    .line 567
    const-string v11, "JUNE"

    const-string v12, "DownLoadingUI: id(%d) File %s, size(%d/%d),  per(%d)"

    const/4 v13, 0x5

    new-array v13, v13, [Ljava/lang/Object;

    const/4 v14, 0x0

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v15

    aput-object v15, v13, v14

    const/4 v14, 0x1

    aput-object v1, v13, v14

    const/4 v14, 0x2

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v15

    aput-object v15, v13, v14

    const/4 v14, 0x3

    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v15

    aput-object v15, v13, v14

    const/4 v14, 0x4

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v15

    aput-object v15, v13, v14

    invoke-static {v12, v13}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v12

    invoke-static {v11, v12}, Lcom/thinkware/sundo/inavi3d/LOGTW;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 572
    return-void

    .line 500
    .end local v1    # "fileName":Ljava/lang/String;
    .end local v4    # "layout":Landroid/widget/RelativeLayout$LayoutParams;
    .end local v6    # "strSubSize":Ljava/lang/String;
    .end local v8    # "strTotalSize":Ljava/lang/String;
    :cond_0
    new-instance v11, Ljava/lang/StringBuilder;

    invoke-direct {v11}, Ljava/lang/StringBuilder;-><init>()V

    const-string v12, "\ucd5c\uc2e0 \ubc84\uc804\uc744 \ub2e4\uc6b4\ub85c\ub4dc \uc911\uc785\ub2c8\ub2e4. ("

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    invoke-virtual {v11, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v11

    const-string v12, "/"

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    invoke-virtual {v11, v9}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v11

    const-string v12, ")"

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    .line 501
    move-object/from16 v0, p0

    iget-object v11, v0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->btnStartUpdata:Landroid/widget/Button;

    const-string v12, "\ub2e4\uc6b4\ub85c\ub4dc \uc911\uc9c0"

    invoke-virtual {v11, v12}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    goto/16 :goto_0

    .line 514
    .restart local v6    # "strSubSize":Ljava/lang/String;
    :cond_1
    const/16 v11, 0x400

    if-le v3, v11, :cond_2

    .line 515
    div-int/lit16 v3, v3, 0x400

    .line 516
    new-instance v11, Ljava/lang/StringBuilder;

    invoke-direct {v11}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v11, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v11

    const-string v12, "KB"

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    goto/16 :goto_1

    .line 518
    :cond_2
    new-instance v11, Ljava/lang/StringBuilder;

    invoke-direct {v11}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v11, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v11

    const-string v12, "Bytes"

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    goto/16 :goto_1

    .line 526
    .restart local v8    # "strTotalSize":Ljava/lang/String;
    :cond_3
    const/16 v11, 0x400

    if-le v10, v11, :cond_4

    .line 527
    div-int/lit16 v10, v10, 0x400

    .line 528
    new-instance v11, Ljava/lang/StringBuilder;

    invoke-direct {v11}, Ljava/lang/StringBuilder;-><init>()V

    const-string v12, " / "

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    invoke-virtual {v11, v10}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v11

    const-string v12, "KB"

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    goto/16 :goto_2

    .line 530
    :cond_4
    new-instance v11, Ljava/lang/StringBuilder;

    invoke-direct {v11}, Ljava/lang/StringBuilder;-><init>()V

    const-string v12, " / "

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    invoke-virtual {v11, v10}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v11

    const-string v12, "Bytes"

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    goto/16 :goto_2
.end method

.method protected InitUI()V
    .locals 30

    .prologue
    .line 231
    const-string v25, "JUNE"

    const-string v26, "InitUI  "

    invoke-static/range {v25 .. v26}, Lcom/thinkware/sundo/inavi3d/LOGTW;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 233
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->btnRestartInavi:Landroid/widget/Button;

    move-object/from16 v25, v0

    const/16 v26, 0x8

    invoke-virtual/range {v25 .. v26}, Landroid/widget/Button;->setVisibility(I)V

    .line 236
    sget-boolean v25, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->mbServerAvailable:Z

    if-nez v25, :cond_0

    .line 237
    sget-object v25, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->mHandler:Landroid/os/Handler;

    sget-object v26, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->mHandler:Landroid/os/Handler;

    const/16 v27, 0x4

    const/16 v28, 0x183d

    invoke-static/range {v28 .. v28}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v28

    invoke-virtual/range {v26 .. v28}, Landroid/os/Handler;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object v26

    invoke-virtual/range {v25 .. v26}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    .line 476
    :goto_0
    return-void

    .line 241
    :cond_0
    sget-boolean v25, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->mbXmlListDone:Z

    if-nez v25, :cond_2

    .line 242
    sget-object v25, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->mMapDownLoadRCode:Ljava/lang/String;

    sget-object v26, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->MAPUPDATE_FAIL_STRING_999:Ljava/lang/String;

    invoke-virtual/range {v25 .. v26}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v25

    if-eqz v25, :cond_1

    .line 243
    sget-object v25, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->mHandler:Landroid/os/Handler;

    invoke-static/range {v25 .. v25}, Landroid/os/Message;->obtain(Landroid/os/Handler;)Landroid/os/Message;

    move-result-object v19

    .line 244
    .local v19, "msg":Landroid/os/Message;
    const/16 v25, 0x3e7

    move/from16 v0, v25

    move-object/from16 v1, v19

    iput v0, v1, Landroid/os/Message;->what:I

    .line 245
    const/16 v25, 0x3e7

    move/from16 v0, v25

    move-object/from16 v1, v19

    iput v0, v1, Landroid/os/Message;->arg1:I

    .line 246
    sget-object v25, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->mMapDownLoadRMsg:Ljava/lang/String;

    move-object/from16 v0, v25

    move-object/from16 v1, v19

    iput-object v0, v1, Landroid/os/Message;->obj:Ljava/lang/Object;

    .line 247
    sget-object v25, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->mHandler:Landroid/os/Handler;

    move-object/from16 v0, v25

    move-object/from16 v1, v19

    invoke-virtual {v0, v1}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto :goto_0

    .line 249
    .end local v19    # "msg":Landroid/os/Message;
    :cond_1
    sget-object v25, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->mHandler:Landroid/os/Handler;

    sget-object v26, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->mHandler:Landroid/os/Handler;

    const/16 v27, 0x4

    const/16 v28, 0x1839

    invoke-static/range {v28 .. v28}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v28

    invoke-virtual/range {v26 .. v28}, Landroid/os/Handler;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object v26

    invoke-virtual/range {v25 .. v26}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto :goto_0

    .line 254
    :cond_2
    sget-boolean v25, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->mbMRDwonLoadComplete:Z

    const/16 v26, 0x1

    move/from16 v0, v25

    move/from16 v1, v26

    if-ne v0, v1, :cond_3

    .line 255
    invoke-virtual/range {p0 .. p0}, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->DownLoadCompleteUI()V

    goto :goto_0

    .line 259
    :cond_3
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->GetLocalMRVersion()Ljava/lang/String;

    move-result-object v4

    .line 262
    .local v4, "LocalMR":Ljava/lang/String;
    invoke-virtual {v4}, Ljava/lang/String;->length()I

    move-result v25

    const/16 v26, 0x5

    move/from16 v0, v25

    move/from16 v1, v26

    if-ge v0, v1, :cond_4

    .line 263
    invoke-virtual {v4}, Ljava/lang/String;->length()I

    move-result v25

    const/16 v26, 0x4

    move/from16 v0, v25

    move/from16 v1, v26

    if-ne v0, v1, :cond_5

    .line 264
    new-instance v25, Ljava/lang/StringBuilder;

    invoke-direct/range {v25 .. v25}, Ljava/lang/StringBuilder;-><init>()V

    move-object/from16 v0, v25

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v25

    const-string v26, "a"

    invoke-virtual/range {v25 .. v26}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v25

    invoke-virtual/range {v25 .. v25}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    .line 270
    :cond_4
    :goto_1
    const-string v25, "."

    const-string v26, ""

    move-object/from16 v0, v25

    move-object/from16 v1, v26

    invoke-virtual {v4, v0, v1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v4

    .line 272
    sget-object v6, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_szServerMapVersion:Ljava/lang/String;

    .line 273
    .local v6, "ServerMR":Ljava/lang/String;
    const-string v25, "."

    const-string v26, ""

    move-object/from16 v0, v25

    move-object/from16 v1, v26

    invoke-virtual {v6, v0, v1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v6

    .line 281
    const/16 v25, 0x0

    const/16 v26, 0x5

    move/from16 v0, v25

    move/from16 v1, v26

    invoke-virtual {v4, v0, v1}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v4

    .line 282
    const/16 v25, 0x0

    const/16 v26, 0x5

    move/from16 v0, v25

    move/from16 v1, v26

    invoke-virtual {v6, v0, v1}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v6

    .line 284
    invoke-virtual {v4, v6}, Ljava/lang/String;->compareTo(Ljava/lang/String;)I

    move-result v23

    .line 285
    .local v23, "nResult":I
    if-ltz v23, :cond_6

    .line 291
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->loadMapVer()Ljava/lang/String;

    move-result-object v5

    .line 293
    .local v5, "MainMapVer":Ljava/lang/String;
    const-string v24, ""

    .line 294
    .local v24, "strTmp":Ljava/lang/String;
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfoTop:Landroid/widget/TextView;

    move-object/from16 v25, v0

    const-string v26, "\ucd5c\uc2e0 \ubc84\uc804\uc758 \ub3c4\ub85c\ub9dd \ub370\uc774\ud130\ub97c \uc0ac\uc6a9 \uc911\uc785\ub2c8\ub2e4."

    invoke-virtual/range {v25 .. v26}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 296
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_imgTconMapUpdateInfoTopSub1_Comma:Landroid/widget/ImageView;

    move-object/from16 v25, v0

    const/16 v26, 0x0

    invoke-virtual/range {v25 .. v26}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 297
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_imgTconMapUpdateInfoTopSub2_Comma:Landroid/widget/ImageView;

    move-object/from16 v25, v0

    const/16 v26, 0x0

    invoke-virtual/range {v25 .. v26}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 299
    const-string v24, "\ub3c4\ub85c\ub9dd \ubc84\uc804"

    .line 300
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfoTopSub1:Landroid/widget/TextView;

    move-object/from16 v25, v0

    move-object/from16 v0, v25

    move-object/from16 v1, v24

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 301
    move-object/from16 v24, v4

    .line 302
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfoTopSub1_Info:Landroid/widget/TextView;

    move-object/from16 v25, v0

    move-object/from16 v0, v25

    move-object/from16 v1, v24

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 304
    const-string v24, "\uc9c0\ub3c4 \ubc84\uc804"

    .line 305
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfoTopSub2:Landroid/widget/TextView;

    move-object/from16 v25, v0

    move-object/from16 v0, v25

    move-object/from16 v1, v24

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 306
    const/16 v25, 0x0

    const/16 v26, 0x5

    move/from16 v0, v25

    move/from16 v1, v26

    invoke-virtual {v5, v0, v1}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v24

    .line 308
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfoTopSub2_Info:Landroid/widget/TextView;

    move-object/from16 v25, v0

    move-object/from16 v0, v25

    move-object/from16 v1, v24

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 310
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_imgTconMapUpdateInfoTopSub3_Comma:Landroid/widget/ImageView;

    move-object/from16 v25, v0

    const/16 v26, 0x4

    invoke-virtual/range {v25 .. v26}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 311
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfoTopSub3:Landroid/widget/TextView;

    move-object/from16 v25, v0

    const/16 v26, 0x4

    invoke-virtual/range {v25 .. v26}, Landroid/widget/TextView;->setVisibility(I)V

    .line 312
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfoTopSub3_Info:Landroid/widget/TextView;

    move-object/from16 v25, v0

    const/16 v26, 0x4

    invoke-virtual/range {v25 .. v26}, Landroid/widget/TextView;->setVisibility(I)V

    .line 314
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfo_DownLoading_Total:Landroid/widget/TextView;

    move-object/from16 v25, v0

    const/16 v26, 0x4

    invoke-virtual/range {v25 .. v26}, Landroid/widget/TextView;->setVisibility(I)V

    .line 315
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfo_DownLoading_Percent:Landroid/widget/TextView;

    move-object/from16 v25, v0

    const/16 v26, 0x4

    invoke-virtual/range {v25 .. v26}, Landroid/widget/TextView;->setVisibility(I)V

    .line 317
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfoBottom1:Landroid/widget/TextView;

    move-object/from16 v25, v0

    const/16 v26, 0x4

    invoke-virtual/range {v25 .. v26}, Landroid/widget/TextView;->setVisibility(I)V

    .line 319
    const-string v25, "JUNE"

    const-string v26, "InitUI newserver  "

    invoke-static/range {v25 .. v26}, Lcom/thinkware/sundo/inavi3d/LOGTW;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 321
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->btnStartUpdata:Landroid/widget/Button;

    move-object/from16 v25, v0

    const/16 v26, 0x0

    invoke-virtual/range {v25 .. v26}, Landroid/widget/Button;->setEnabled(Z)V

    goto/16 :goto_0

    .line 266
    .end local v5    # "MainMapVer":Ljava/lang/String;
    .end local v6    # "ServerMR":Ljava/lang/String;
    .end local v23    # "nResult":I
    .end local v24    # "strTmp":Ljava/lang/String;
    :cond_5
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->loadMapVer()Ljava/lang/String;

    move-result-object v4

    goto/16 :goto_1

    .line 325
    .restart local v6    # "ServerMR":Ljava/lang/String;
    .restart local v23    # "nResult":I
    :cond_6
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfoBottom1:Landroid/widget/TextView;

    move-object/from16 v25, v0

    invoke-virtual/range {v25 .. v25}, Landroid/widget/TextView;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v12

    check-cast v12, Landroid/widget/RelativeLayout$LayoutParams;

    .line 326
    .local v12, "layout":Landroid/widget/RelativeLayout$LayoutParams;
    const/16 v25, 0x172

    move/from16 v0, v25

    iput v0, v12, Landroid/widget/RelativeLayout$LayoutParams;->topMargin:I

    .line 327
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfoBottom1:Landroid/widget/TextView;

    move-object/from16 v25, v0

    const/16 v26, 0x0

    invoke-virtual/range {v25 .. v26}, Landroid/widget/TextView;->setVisibility(I)V

    .line 328
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfoBottom1:Landroid/widget/TextView;

    move-object/from16 v25, v0

    const-string v26, "\u203b\ucd5c\uc2e0 \ubc84\uc804 \uc0ac\uc6a9 \uc2dc \'\ube60\ub974Go/\ube60\ub974Go(\ubb34\ub8cc)/\ud3b8\ud558Go/\ud3b8\ud558Go(\ubb34\ub8cc)\' \ud0d0\uc0c9 \uc635\uc158\uc744 \uc0ac\uc6a9\ud558\uc2e4 \uc218 \uc788\uc2b5\ub2c8\ub2e4.\n\ub124\ud2b8\uc6cc\ud06c \uc5f0\uacb0 \uc0c1\ud0dc\uc5d0 \ub530\ub77c \uc218 \ubd84\uc774 \uc18c\uc694\ub420 \uc218 \uc788\uc73c\uba70, \ub370\uc774\ud130 \ud1b5\ud654\ub8cc\uac00 \ubc1c\uc0dd\ud560 \uc218 \uc788\uc2b5\ub2c8\ub2e4.\n\uc544\uc774\ub098\ube44 \uc804\uccb4 \uc5c5\uadf8\ub808\uc774\ub4dc\ub294 PC\ub9e4\ub2c8\uc800\ub97c \uc774\uc6a9\ud558\uc2ed\uc2dc\uc624."

    invoke-virtual/range {v25 .. v26}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 332
    const-string v3, "/inavi3d/mapdata/mrdata/"

    .line 333
    .local v3, "ExtractPath":Ljava/lang/String;
    const-string v8, "recommendation1.iho"

    .line 334
    .local v8, "filename":Ljava/lang/String;
    new-instance v2, Ljava/io/File;

    new-instance v25, Ljava/lang/StringBuilder;

    invoke-direct/range {v25 .. v25}, Ljava/lang/StringBuilder;-><init>()V

    const-string v26, "/storage/emulated/0/inavi3d/tempmapdata/airmrdata/"

    invoke-virtual/range {v25 .. v26}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v25

    move-object/from16 v0, v25

    invoke-virtual {v0, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v25

    invoke-virtual/range {v25 .. v25}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v25

    move-object/from16 v0, v25

    invoke-direct {v2, v0}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 335
    .local v2, "CheckExistsfile":Ljava/io/File;
    invoke-virtual {v2}, Ljava/io/File;->exists()Z

    move-result v25

    if-nez v25, :cond_7

    .line 336
    sget v14, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_nSerVerMapZipSize:I

    .line 337
    .local v14, "m_nSerVerMapSize":I
    sget v15, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_nServiceVersion:I

    .line 340
    .local v15, "m_nServerMapVersion":I
    const-string v24, ""

    .line 341
    .restart local v24    # "strTmp":Ljava/lang/String;
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfoTop:Landroid/widget/TextView;

    move-object/from16 v25, v0

    const-string v26, "\ub354 \uc815\ud655\ud55c \uacbd\ub85c \uc548\ub0b4\ub97c \uc704\ud574 \uc2e0\uaddc \ub3c4\ub85c\ub9dd\uacfc \uad50\ud1b5\ub9dd \uc815\ubcf4\ub9cc \ube60\ub974\uac8c \uc5c5\ub370\uc774\ud2b8\ud569\ub2c8\ub2e4."

    invoke-virtual/range {v25 .. v26}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 343
    const-string v24, "\ub370\uc774\ud130 \uc6a9\ub7c9 "

    .line 344
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfoTopSub1:Landroid/widget/TextView;

    move-object/from16 v25, v0

    move-object/from16 v0, v25

    move-object/from16 v1, v24

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 346
    div-int/lit16 v0, v14, 0x400

    move/from16 v25, v0

    move/from16 v0, v25

    div-int/lit16 v0, v0, 0x400

    move/from16 v17, v0

    .line 347
    .local v17, "mapsize":I
    new-instance v25, Ljava/lang/StringBuilder;

    invoke-direct/range {v25 .. v25}, Ljava/lang/StringBuilder;-><init>()V

    move-object/from16 v0, v25

    move/from16 v1, v17

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v25

    const-string v26, "MB"

    invoke-virtual/range {v25 .. v26}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v25

    invoke-virtual/range {v25 .. v25}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v24

    .line 348
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfoTopSub1_Info:Landroid/widget/TextView;

    move-object/from16 v25, v0

    move-object/from16 v0, v25

    move-object/from16 v1, v24

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 350
    const-string v24, "\ud604\uc7ac \ubc84\uc804"

    .line 351
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfoTopSub2:Landroid/widget/TextView;

    move-object/from16 v25, v0

    move-object/from16 v0, v25

    move-object/from16 v1, v24

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 352
    move-object/from16 v24, v4

    .line 353
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfoTopSub2_Info:Landroid/widget/TextView;

    move-object/from16 v25, v0

    move-object/from16 v0, v25

    move-object/from16 v1, v24

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 355
    const-string v24, "\uc5c5\uadf8\ub808\uc774\ub4dc \ubc84\uc804"

    .line 356
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfoTopSub3:Landroid/widget/TextView;

    move-object/from16 v25, v0

    move-object/from16 v0, v25

    move-object/from16 v1, v24

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 357
    move-object/from16 v24, v6

    .line 358
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfoTopSub3_Info:Landroid/widget/TextView;

    move-object/from16 v25, v0

    move-object/from16 v0, v25

    move-object/from16 v1, v24

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 360
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_imgTconMapUpdateInfoTopSub1_Comma:Landroid/widget/ImageView;

    move-object/from16 v25, v0

    const/16 v26, 0x0

    invoke-virtual/range {v25 .. v26}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 361
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_imgTconMapUpdateInfoTopSub2_Comma:Landroid/widget/ImageView;

    move-object/from16 v25, v0

    const/16 v26, 0x0

    invoke-virtual/range {v25 .. v26}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 362
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_imgTconMapUpdateInfoTopSub3_Comma:Landroid/widget/ImageView;

    move-object/from16 v25, v0

    const/16 v26, 0x0

    invoke-virtual/range {v25 .. v26}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 364
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfoTopSub1:Landroid/widget/TextView;

    move-object/from16 v25, v0

    const/16 v26, 0x0

    invoke-virtual/range {v25 .. v26}, Landroid/widget/TextView;->setVisibility(I)V

    .line 365
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfoTopSub2:Landroid/widget/TextView;

    move-object/from16 v25, v0

    const/16 v26, 0x0

    invoke-virtual/range {v25 .. v26}, Landroid/widget/TextView;->setVisibility(I)V

    .line 366
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfoTopSub3:Landroid/widget/TextView;

    move-object/from16 v25, v0

    const/16 v26, 0x0

    invoke-virtual/range {v25 .. v26}, Landroid/widget/TextView;->setVisibility(I)V

    .line 367
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfoTopSub1_Info:Landroid/widget/TextView;

    move-object/from16 v25, v0

    const/16 v26, 0x0

    invoke-virtual/range {v25 .. v26}, Landroid/widget/TextView;->setVisibility(I)V

    .line 368
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfoTopSub2_Info:Landroid/widget/TextView;

    move-object/from16 v25, v0

    const/16 v26, 0x0

    invoke-virtual/range {v25 .. v26}, Landroid/widget/TextView;->setVisibility(I)V

    .line 369
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfoTopSub3_Info:Landroid/widget/TextView;

    move-object/from16 v25, v0

    const/16 v26, 0x0

    invoke-virtual/range {v25 .. v26}, Landroid/widget/TextView;->setVisibility(I)V

    .line 372
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfo_DownLoading_Total:Landroid/widget/TextView;

    move-object/from16 v25, v0

    const/16 v26, 0x4

    invoke-virtual/range {v25 .. v26}, Landroid/widget/TextView;->setVisibility(I)V

    .line 373
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfo_DownLoading_Percent:Landroid/widget/TextView;

    move-object/from16 v25, v0

    const/16 v26, 0x4

    invoke-virtual/range {v25 .. v26}, Landroid/widget/TextView;->setVisibility(I)V

    .line 375
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->btnStartUpdata:Landroid/widget/Button;

    move-object/from16 v25, v0

    const-string v26, "\uc5c5\ub370\uc774\ud2b8 \uc2dc\uc791"

    invoke-virtual/range {v25 .. v26}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 376
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->btnStartUpdata:Landroid/widget/Button;

    move-object/from16 v25, v0

    const/16 v26, 0x1

    invoke-virtual/range {v25 .. v26}, Landroid/widget/Button;->setEnabled(Z)V

    goto/16 :goto_0

    .line 382
    .end local v14    # "m_nSerVerMapSize":I
    .end local v15    # "m_nServerMapVersion":I
    .end local v17    # "mapsize":I
    .end local v24    # "strTmp":Ljava/lang/String;
    :cond_7
    const/16 v21, 0x0

    .line 383
    .local v21, "nDownloadedFileCnt":I
    const/16 v20, 0x0

    .line 384
    .local v20, "nDownLoadedSize":I
    const/4 v10, 0x0

    .local v10, "i":I
    :goto_2
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getmXmlList()Ljava/util/Vector;

    move-result-object v25

    invoke-virtual/range {v25 .. v25}, Ljava/util/Vector;->size()I

    move-result v25

    move/from16 v0, v25

    if-ge v10, v0, :cond_b

    .line 386
    new-instance v13, Lcom/thinkware/sundo/inavi3d/Struct/ServerMapXmlList;

    invoke-direct {v13}, Lcom/thinkware/sundo/inavi3d/Struct/ServerMapXmlList;-><init>()V

    .line 388
    .local v13, "mXmlList":Lcom/thinkware/sundo/inavi3d/Struct/ServerMapXmlList;
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getmXmlList()Ljava/util/Vector;

    move-result-object v25

    move-object/from16 v0, v25

    invoke-virtual {v0, v10}, Ljava/util/Vector;->get(I)Ljava/lang/Object;

    move-result-object v13

    .end local v13    # "mXmlList":Lcom/thinkware/sundo/inavi3d/Struct/ServerMapXmlList;
    check-cast v13, Lcom/thinkware/sundo/inavi3d/Struct/ServerMapXmlList;

    .line 390
    .restart local v13    # "mXmlList":Lcom/thinkware/sundo/inavi3d/Struct/ServerMapXmlList;
    iget-object v3, v13, Lcom/thinkware/sundo/inavi3d/Struct/ServerMapXmlList;->ExtractPath:Ljava/lang/String;

    .line 391
    iget-object v8, v13, Lcom/thinkware/sundo/inavi3d/Struct/ServerMapXmlList;->FileName:Ljava/lang/String;

    .line 393
    const-string v18, "/inavi3d/mapdata/mrdata"

    .line 394
    .local v18, "mrStr":Ljava/lang/String;
    const-string v7, "/inavi3d/mapdata/darc"

    .line 395
    .local v7, "darcStr":Ljava/lang/String;
    move-object/from16 v0, v18

    invoke-virtual {v3, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v25

    if-eqz v25, :cond_9

    .line 396
    const-string v3, "/inavi3d/tempmapdata/airmrdata"

    .line 402
    :goto_3
    new-instance v2, Ljava/io/File;

    .end local v2    # "CheckExistsfile":Ljava/io/File;
    new-instance v25, Ljava/lang/StringBuilder;

    invoke-direct/range {v25 .. v25}, Ljava/lang/StringBuilder;-><init>()V

    const-string v26, "/storage/emulated/0"

    invoke-virtual/range {v25 .. v26}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v25

    move-object/from16 v0, v25

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v25

    const-string v26, "/"

    invoke-virtual/range {v25 .. v26}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v25

    move-object/from16 v0, v25

    invoke-virtual {v0, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v25

    invoke-virtual/range {v25 .. v25}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v25

    move-object/from16 v0, v25

    invoke-direct {v2, v0}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 404
    .restart local v2    # "CheckExistsfile":Ljava/io/File;
    invoke-virtual {v2}, Ljava/io/File;->exists()Z

    move-result v25

    if-eqz v25, :cond_8

    .line 407
    iget-object v0, v13, Lcom/thinkware/sundo/inavi3d/Struct/ServerMapXmlList;->FileSize:Ljava/lang/String;

    move-object/from16 v25, v0

    invoke-static/range {v25 .. v25}, Ljava/lang/Integer;->valueOf(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v25

    invoke-virtual/range {v25 .. v25}, Ljava/lang/Integer;->intValue()I

    move-result v9

    .line 408
    .local v9, "filesize":I
    iget-object v0, v13, Lcom/thinkware/sundo/inavi3d/Struct/ServerMapXmlList;->InstallSize:Ljava/lang/String;

    move-object/from16 v25, v0

    invoke-static/range {v25 .. v25}, Ljava/lang/Integer;->valueOf(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v25

    invoke-virtual/range {v25 .. v25}, Ljava/lang/Integer;->intValue()I

    move-result v11

    .line 410
    .local v11, "installfilesize":I
    invoke-virtual {v2}, Ljava/io/File;->length()J

    move-result-wide v26

    int-to-long v0, v11

    move-wide/from16 v28, v0

    cmp-long v25, v26, v28

    if-nez v25, :cond_8

    .line 411
    add-int/lit8 v21, v21, 0x1

    .line 412
    add-int v20, v20, v9

    .line 384
    .end local v9    # "filesize":I
    .end local v11    # "installfilesize":I
    :cond_8
    add-int/lit8 v10, v10, 0x1

    goto/16 :goto_2

    .line 397
    :cond_9
    invoke-virtual {v3, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v25

    if-eqz v25, :cond_a

    .line 398
    const-string v3, "/inavi3d/tempmapdata/airdarc"

    goto :goto_3

    .line 400
    :cond_a
    const-string v3, "/inavi3d/tempmapdata/air3d"

    goto :goto_3

    .line 432
    .end local v7    # "darcStr":Ljava/lang/String;
    .end local v13    # "mXmlList":Lcom/thinkware/sundo/inavi3d/Struct/ServerMapXmlList;
    .end local v18    # "mrStr":Ljava/lang/String;
    :cond_b
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getmXmlList()Ljava/util/Vector;

    move-result-object v25

    invoke-virtual/range {v25 .. v25}, Ljava/util/Vector;->size()I

    move-result v25

    move/from16 v0, v21

    move/from16 v1, v25

    if-ne v0, v1, :cond_c

    .line 433
    invoke-virtual/range {p0 .. p0}, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->DownLoadCompleteUI()V

    goto/16 :goto_0

    .line 437
    :cond_c
    new-instance v16, Lcom/thinkware/sundo/inavi3d/Struct/TconMapUpdateObj;

    invoke-direct/range {v16 .. v16}, Lcom/thinkware/sundo/inavi3d/Struct/TconMapUpdateObj;-><init>()V

    .line 438
    .local v16, "mapUpdateObj":Lcom/thinkware/sundo/inavi3d/Struct/TconMapUpdateObj;
    move/from16 v0, v21

    move-object/from16 v1, v16

    iput v0, v1, Lcom/thinkware/sundo/inavi3d/Struct/TconMapUpdateObj;->fileId:I

    .line 439
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getmXmlList()Ljava/util/Vector;

    move-result-object v25

    invoke-virtual/range {v25 .. v25}, Ljava/util/Vector;->size()I

    move-result v25

    move/from16 v0, v25

    move-object/from16 v1, v16

    iput v0, v1, Lcom/thinkware/sundo/inavi3d/Struct/TconMapUpdateObj;->totalCnt:I

    .line 440
    sget v25, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_nSerVerMapZipSize:I

    move/from16 v0, v25

    move-object/from16 v1, v16

    iput v0, v1, Lcom/thinkware/sundo/inavi3d/Struct/TconMapUpdateObj;->totalSize:I

    .line 441
    move/from16 v0, v20

    move-object/from16 v1, v16

    iput v0, v1, Lcom/thinkware/sundo/inavi3d/Struct/TconMapUpdateObj;->fileSize:I

    .line 442
    new-instance v25, Ljava/lang/StringBuilder;

    invoke-direct/range {v25 .. v25}, Ljava/lang/StringBuilder;-><init>()V

    const-string v26, "/storage/emulated/0"

    invoke-virtual/range {v25 .. v26}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v25

    move-object/from16 v0, v25

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v25

    const-string v26, "/"

    invoke-virtual/range {v25 .. v26}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v25

    move-object/from16 v0, v25

    invoke-virtual {v0, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v25

    invoke-virtual/range {v25 .. v25}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v25

    move-object/from16 v0, v25

    move-object/from16 v1, v16

    iput-object v0, v1, Lcom/thinkware/sundo/inavi3d/Struct/TconMapUpdateObj;->fileName:Ljava/lang/String;

    .line 443
    move/from16 v0, v20

    int-to-float v0, v0

    move/from16 v25, v0

    sget v26, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_nSerVerMapZipSize:I

    move/from16 v0, v26

    int-to-float v0, v0

    move/from16 v26, v0

    div-float v25, v25, v26

    const/high16 v26, 0x42c80000    # 100.0f

    mul-float v25, v25, v26

    move/from16 v0, v25

    float-to-int v0, v0

    move/from16 v22, v0

    .line 444
    .local v22, "nPercent":I
    move/from16 v0, v22

    int-to-float v0, v0

    move/from16 v25, v0

    invoke-static/range {v25 .. v25}, Ljava/lang/Math;->round(F)I

    move-result v25

    invoke-static/range {v25 .. v25}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v25

    invoke-static/range {v25 .. v25}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v25

    move/from16 v0, v25

    move-object/from16 v1, v16

    iput v0, v1, Lcom/thinkware/sundo/inavi3d/Struct/TconMapUpdateObj;->downPercent:I

    .line 445
    move-object/from16 v0, p0

    move-object/from16 v1, v16

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->DownLoadingUI(Lcom/thinkware/sundo/inavi3d/Struct/TconMapUpdateObj;)V

    .line 447
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->btnStartUpdata:Landroid/widget/Button;

    move-object/from16 v25, v0

    const-string v26, "\uc774\uc5b4\ubc1b\uae30"

    invoke-virtual/range {v25 .. v26}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 448
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->btnStartUpdata:Landroid/widget/Button;

    move-object/from16 v25, v0

    const/16 v26, 0x1

    invoke-virtual/range {v25 .. v26}, Landroid/widget/Button;->setEnabled(Z)V

    goto/16 :goto_0
.end method

.method protected getContentViewId()I
    .locals 1

    .prologue
    .line 663
    const v0, 0x7f0a0978

    return v0
.end method

.method protected occurError(ILjava/lang/String;)V
    .locals 4
    .param p1, "errNum"    # I
    .param p2, "errMSG"    # Ljava/lang/String;

    .prologue
    const/4 v3, 0x4

    .line 191
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->btnRestartInavi:Landroid/widget/Button;

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setVisibility(I)V

    .line 193
    invoke-virtual {p2}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    const/4 v1, 0x1

    if-ne v0, v1, :cond_2

    .line 194
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfoTop:Landroid/widget/TextView;

    invoke-static {p1}, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->getErrMsg(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 197
    :goto_0
    sget-object v0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->mThisInastance:Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;

    if-eqz v0, :cond_0

    .line 202
    :cond_0
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_imgTconMapUpdateInfoTopSub1_Comma:Landroid/widget/ImageView;

    invoke-virtual {v0, v3}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 203
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_imgTconMapUpdateInfoTopSub2_Comma:Landroid/widget/ImageView;

    invoke-virtual {v0, v3}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 204
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_imgTconMapUpdateInfoTopSub3_Comma:Landroid/widget/ImageView;

    invoke-virtual {v0, v3}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 206
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfoTopSub1:Landroid/widget/TextView;

    invoke-virtual {v0, v3}, Landroid/widget/TextView;->setVisibility(I)V

    .line 207
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfoTopSub2:Landroid/widget/TextView;

    invoke-virtual {v0, v3}, Landroid/widget/TextView;->setVisibility(I)V

    .line 208
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfoTopSub3:Landroid/widget/TextView;

    invoke-virtual {v0, v3}, Landroid/widget/TextView;->setVisibility(I)V

    .line 209
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfoTopSub1_Info:Landroid/widget/TextView;

    invoke-virtual {v0, v3}, Landroid/widget/TextView;->setVisibility(I)V

    .line 210
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfoTopSub2_Info:Landroid/widget/TextView;

    invoke-virtual {v0, v3}, Landroid/widget/TextView;->setVisibility(I)V

    .line 211
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfoTopSub3_Info:Landroid/widget/TextView;

    invoke-virtual {v0, v3}, Landroid/widget/TextView;->setVisibility(I)V

    .line 212
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfoBottom1:Landroid/widget/TextView;

    invoke-virtual {v0, v3}, Landroid/widget/TextView;->setVisibility(I)V

    .line 216
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfo_DownLoading_Total:Landroid/widget/TextView;

    invoke-virtual {v0, v3}, Landroid/widget/TextView;->setVisibility(I)V

    .line 217
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfo_DownLoading_Percent:Landroid/widget/TextView;

    invoke-virtual {v0, v3}, Landroid/widget/TextView;->setVisibility(I)V

    .line 219
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->progressBar:Landroid/widget/ProgressBar;

    invoke-virtual {v0, v3}, Landroid/widget/ProgressBar;->setVisibility(I)V

    .line 221
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->btnStartUpdata:Landroid/widget/Button;

    const-string v1, "\uc774\uc5b4\ubc1b\uae30"

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 223
    const/16 v0, 0x1839

    if-ne p1, v0, :cond_1

    .line 224
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->btnStartUpdata:Landroid/widget/Button;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setEnabled(Z)V

    .line 226
    :cond_1
    return-void

    .line 196
    :cond_2
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfoTop:Landroid/widget/TextView;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "("

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ")"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    goto :goto_0
.end method

.method public onClick(Landroid/view/View;)V
    .locals 4
    .param p1, "v"    # Landroid/view/View;

    .prologue
    const/4 v2, 0x0

    const/4 v1, 0x1

    .line 634
    invoke-virtual {p1}, Landroid/view/View;->getId()I

    move-result v0

    const v3, 0x7f0a0979

    if-ne v0, v3, :cond_4

    .line 635
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0}, Lcom/thinkware/i3dlite/CommonDef;->IsNetworkAvailable(Landroid/content/Context;)Z

    move-result v0

    if-nez v0, :cond_0

    .line 642
    :cond_0
    sget-boolean v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->mMRDownLoadThreadRunning:Z

    if-eqz v0, :cond_1

    .line 643
    sget-boolean v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->mMRDownloadPauseFlag:Z

    if-nez v0, :cond_6

    move v0, v1

    :goto_0
    sput-boolean v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->mMRDownloadPauseFlag:Z

    .line 645
    :cond_1
    sget-boolean v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->mMRDownloadPauseFlag:Z

    if-ne v0, v1, :cond_2

    .line 646
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->btnStartUpdata:Landroid/widget/Button;

    const-string v3, "\uc774\uc5b4\ubc1b\uae30"

    invoke-virtual {v0, v3}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 649
    :cond_2
    sget-boolean v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->mMRDownloadPauseFlag:Z

    if-nez v0, :cond_3

    .line 650
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->btnStartUpdata:Landroid/widget/Button;

    const-string v3, "\ub2e4\uc6b4\ub85c\ub4dc \uc911\uc9c0"

    invoke-virtual {v0, v3}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 653
    :cond_3
    const v0, 0x2628d

    const-string v3, ""

    invoke-static {v0, v1, v3}, Lcom/thinkware/sundo/inavi3d/Inavi;->ProcessMessage(IILjava/lang/String;)I

    .line 656
    :cond_4
    invoke-virtual {p1}, Landroid/view/View;->getId()I

    move-result v0

    const v1, 0x7f0a0988

    if-ne v0, v1, :cond_5

    .line 657
    const/16 v0, 0x270e

    const-string v1, ""

    invoke-static {v0, v2, v1}, Lcom/thinkware/sundo/inavi3d/Inavi;->ProcessMessage(IILjava/lang/String;)I

    .line 659
    :cond_5
    return-void

    :cond_6
    move v0, v2

    .line 643
    goto :goto_0
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 5
    .param p1, "savedInstanceState"    # Landroid/os/Bundle;

    .prologue
    const v4, 0x7f0a074f

    .line 113
    invoke-super {p0, p1}, Lcom/thinkware/sundo/inavi3d/MainActivity;->onCreate(Landroid/os/Bundle;)V

    .line 115
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v1

    if-nez v1, :cond_0

    .line 116
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 117
    .local v0, "startMain":Landroid/content/Intent;
    const-string v1, "android.intent.action.MAIN"

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    .line 118
    const-string v1, "android.intent.category.LAUNCHER"

    invoke-virtual {v0, v1}, Landroid/content/Intent;->addCategory(Ljava/lang/String;)Landroid/content/Intent;

    .line 119
    const/high16 v1, 0x10000000

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;

    .line 120
    invoke-virtual {p0, v0}, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->startActivity(Landroid/content/Intent;)V

    .line 121
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->finish()V

    .line 165
    .end local v0    # "startMain":Landroid/content/Intent;
    :goto_0
    return-void

    .line 125
    :cond_0
    sget-boolean v1, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->mbXmlListDone:Z

    if-nez v1, :cond_1

    .line 126
    const v1, 0x2628f

    const/4 v2, 0x1

    const-string v3, ""

    invoke-static {v1, v2, v3}, Lcom/thinkware/sundo/inavi3d/Inavi;->ProcessMessage(IILjava/lang/String;)I

    .line 128
    :cond_1
    sput-object p0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->mThisInastance:Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;

    .line 130
    const v1, 0x7f030155

    invoke-virtual {p0, v1}, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->setContentView(I)V

    .line 132
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v1

    invoke-virtual {v1}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->is_support_scale()Z

    move-result v1

    if-eqz v1, :cond_3

    .line 133
    invoke-virtual {p0, v4}, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->findViewById(I)Landroid/view/View;

    move-result-object v1

    if-eqz v1, :cond_2

    .line 134
    invoke-virtual {p0, v4}, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->findViewById(I)Landroid/view/View;

    move-result-object v1

    invoke-virtual {v1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    const/16 v2, 0x221

    iput v2, v1, Landroid/view/ViewGroup$LayoutParams;->height:I

    .line 135
    invoke-virtual {p0, v4}, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->findViewById(I)Landroid/view/View;

    move-result-object v1

    invoke-virtual {v1}, Landroid/view/View;->requestLayout()V

    .line 137
    :cond_2
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INaviScaleManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INaviScaleManager;

    move-result-object v1

    invoke-virtual {v1, p0}, Lcom/thinkware/sundo/inavi3d/INaviScaleManager;->scaleOnce(Landroid/app/Activity;)V

    .line 140
    :cond_3
    const v1, 0x7f0a0979

    invoke-virtual {p0, v1}, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/Button;

    iput-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->btnStartUpdata:Landroid/widget/Button;

    .line 141
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->btnStartUpdata:Landroid/widget/Button;

    invoke-virtual {v1, p0}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 143
    const v1, 0x7f0a0988

    invoke-virtual {p0, v1}, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/Button;

    iput-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->btnRestartInavi:Landroid/widget/Button;

    .line 144
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->btnRestartInavi:Landroid/widget/Button;

    invoke-virtual {v1, p0}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 146
    const v1, 0x7f0a097b

    invoke-virtual {p0, v1}, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    iput-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfoTop:Landroid/widget/TextView;

    .line 147
    const v1, 0x7f0a097c

    invoke-virtual {p0, v1}, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/ImageView;

    iput-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_imgTconMapUpdateInfoTopSub1_Comma:Landroid/widget/ImageView;

    .line 148
    const v1, 0x7f0a097f

    invoke-virtual {p0, v1}, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/ImageView;

    iput-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_imgTconMapUpdateInfoTopSub2_Comma:Landroid/widget/ImageView;

    .line 149
    const v1, 0x7f0a0982

    invoke-virtual {p0, v1}, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/ImageView;

    iput-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_imgTconMapUpdateInfoTopSub3_Comma:Landroid/widget/ImageView;

    .line 150
    const v1, 0x7f0a097d

    invoke-virtual {p0, v1}, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    iput-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfoTopSub1:Landroid/widget/TextView;

    .line 151
    const v1, 0x7f0a0980

    invoke-virtual {p0, v1}, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    iput-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfoTopSub2:Landroid/widget/TextView;

    .line 152
    const v1, 0x7f0a0983

    invoke-virtual {p0, v1}, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    iput-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfoTopSub3:Landroid/widget/TextView;

    .line 153
    const v1, 0x7f0a097e

    invoke-virtual {p0, v1}, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    iput-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfoTopSub1_Info:Landroid/widget/TextView;

    .line 154
    const v1, 0x7f0a0981

    invoke-virtual {p0, v1}, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    iput-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfoTopSub2_Info:Landroid/widget/TextView;

    .line 155
    const v1, 0x7f0a0984

    invoke-virtual {p0, v1}, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    iput-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfoTopSub3_Info:Landroid/widget/TextView;

    .line 156
    const v1, 0x7f0a0985

    invoke-virtual {p0, v1}, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    iput-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfoBottom1:Landroid/widget/TextView;

    .line 159
    const v1, 0x7f0a0986

    invoke-virtual {p0, v1}, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    iput-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfo_DownLoading_Total:Landroid/widget/TextView;

    .line 160
    const v1, 0x7f0a0987

    invoke-virtual {p0, v1}, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    iput-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->m_txtTconMapUpdateInfo_DownLoading_Percent:Landroid/widget/TextView;

    .line 162
    const v1, 0x7f0a00e8

    invoke-virtual {p0, v1}, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/ProgressBar;

    iput-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->progressBar:Landroid/widget/ProgressBar;

    .line 164
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->InitUI()V

    goto/16 :goto_0
.end method

.method protected onPause()V
    .locals 1

    .prologue
    .line 107
    const/4 v0, 0x1

    sput-boolean v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_bNeedSleep:Z

    .line 108
    invoke-super {p0}, Lcom/thinkware/sundo/inavi3d/MainActivity;->onPause()V

    .line 109
    return-void
.end method

.method protected onResume()V
    .locals 1

    .prologue
    .line 101
    invoke-super {p0}, Lcom/thinkware/sundo/inavi3d/MainActivity;->onResume()V

    .line 102
    const/4 v0, 0x0

    sput-boolean v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_bNeedSleep:Z

    .line 103
    return-void
.end method
