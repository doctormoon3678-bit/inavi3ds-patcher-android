.class Lcom/thinkware/sundo/inavi3d/INavi3DActivity$215;
.super Ljava/lang/Object;
.source "INavi3DActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/thinkware/sundo/inavi3d/INavi3DActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;


# direct methods
.method constructor <init>(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)V
    .locals 0

    .prologue
    .line 32080
    iput-object p1, p0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$215;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 44

    .prologue
    .line 32084
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v40

    .line 32087
    .local v40, "startTickcount":J
    const-string v2, "SendToServer"

    const-string v11, "mMrDownRunnable run"

    invoke-static {v2, v11}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 32088
    move-object/from16 v0, p0

    iget-object v3, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$215;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    const/16 v4, 0x1770

    const-string v5, ""

    sget v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_nSerVerMapZipSize:I

    int-to-long v6, v2

    sget v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_nSerVerMapUnZipSize:I

    int-to-long v8, v2

    const-wide/16 v10, 0x0

    const-string v12, "\ub2e4\uc6b4\ub85c\ub4dc \uc2dc\uc791"

    invoke-static/range {v3 .. v12}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$24600(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;ILjava/lang/String;JJJLjava/lang/String;)V

    .line 32091
    const/16 v37, 0x0

    .line 32092
    .local v37, "retCode":I
    const/16 v29, 0x0

    .line 32093
    .local v29, "downDone":Z
    const/16 v31, 0x0

    .line 32095
    .local v31, "fileIndex":I
    new-instance v42, Landroid/os/StatFs;

    sget-object v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->SD_EXT_STORAGE_PATH:Ljava/lang/String;

    move-object/from16 v0, v42

    invoke-direct {v0, v2}, Landroid/os/StatFs;-><init>(Ljava/lang/String;)V

    .line 32096
    .local v42, "stat":Landroid/os/StatFs;
    invoke-virtual/range {v42 .. v42}, Landroid/os/StatFs;->getAvailableBytes()J

    move-result-wide v24

    .line 32097
    .local v24, "availableByte":J
    const-wide/32 v26, 0x6400000

    .line 32099
    .local v26, "bufferSize":J
    sget v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_nSerVerMapUnZipSize:I

    int-to-long v12, v2

    add-long v12, v12, v26

    cmp-long v2, v24, v12

    if-gez v2, :cond_0

    .line 32100
    const/16 v29, 0x1

    .line 32101
    const/16 v37, 0x183b

    .line 32102
    move-object/from16 v0, p0

    iget-object v3, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$215;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    const/16 v4, 0x183b

    const-string v5, ""

    sget v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_nSerVerMapZipSize:I

    int-to-long v6, v2

    sget v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_nSerVerMapUnZipSize:I

    int-to-long v8, v2

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v12

    sub-long v10, v12, v40

    const-string v12, "\uc800\uc7a5\uacf5\uac04\ubd80\uc871"

    invoke-static/range {v3 .. v12}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$24600(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;ILjava/lang/String;JJJLjava/lang/String;)V

    .line 32105
    :cond_0
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getmXmlList()Ljava/util/Vector;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/Vector;->size()I

    move-result v2

    if-gtz v2, :cond_1

    .line 32106
    const/16 v29, 0x1

    .line 32107
    const/16 v37, 0x1839

    .line 32108
    move-object/from16 v0, p0

    iget-object v3, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$215;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    const/16 v4, 0x1839

    const-string v5, ""

    sget v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_nSerVerMapZipSize:I

    int-to-long v6, v2

    sget v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_nSerVerMapUnZipSize:I

    int-to-long v8, v2

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v12

    sub-long v10, v12, v40

    const-string v12, "\uc5c5\ub370\uc774\ud2b8 \uc2dc\ub3c4\ud558\ub098 XML \ubbf8\uc0dd\uc131"

    invoke-static/range {v3 .. v12}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$24600(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;ILjava/lang/String;JJJLjava/lang/String;)V

    .line 32112
    :cond_1
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v2

    if-eqz v2, :cond_2

    .line 32113
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v2

    const/4 v11, 0x1

    invoke-virtual {v2, v11}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->showMapUpdateStatus(Z)V

    .line 32117
    :cond_2
    const/4 v2, 0x0

    sput v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_nDownloadedMapZipSize:I

    .line 32119
    :cond_3
    if-nez v29, :cond_5

    .line 32122
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$215;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    iget-object v0, v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->mCDN_URL:Ljava/lang/String;

    move-object/from16 v33, v0

    .line 32123
    .local v33, "http":Ljava/lang/String;
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getmXmlList()Ljava/util/Vector;

    move-result-object v2

    move/from16 v0, v31

    invoke-virtual {v2, v0}, Ljava/util/Vector;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/thinkware/sundo/inavi3d/Struct/ServerMapXmlList;

    iget-object v5, v2, Lcom/thinkware/sundo/inavi3d/Struct/ServerMapXmlList;->FileName:Ljava/lang/String;

    .line 32124
    .local v5, "FileName":Ljava/lang/String;
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getmXmlList()Ljava/util/Vector;

    move-result-object v2

    move/from16 v0, v31

    invoke-virtual {v2, v0}, Ljava/util/Vector;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/thinkware/sundo/inavi3d/Struct/ServerMapXmlList;

    iget-object v0, v2, Lcom/thinkware/sundo/inavi3d/Struct/ServerMapXmlList;->VersionPath:Ljava/lang/String;

    move-object/from16 v22, v0

    .line 32125
    .local v22, "VersionPath":Ljava/lang/String;
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getmXmlList()Ljava/util/Vector;

    move-result-object v2

    move/from16 v0, v31

    invoke-virtual {v2, v0}, Ljava/util/Vector;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/thinkware/sundo/inavi3d/Struct/ServerMapXmlList;

    iget-object v0, v2, Lcom/thinkware/sundo/inavi3d/Struct/ServerMapXmlList;->FilePath:Ljava/lang/String;

    move-object/from16 v21, v0

    .line 32126
    .local v21, "FilePath":Ljava/lang/String;
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    move-object/from16 v0, v33

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    move-object/from16 v0, v22

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    move-object/from16 v0, v21

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v11, "/"

    invoke-virtual {v2, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    .line 32127
    .local v3, "downurl":Ljava/lang/String;
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getmXmlList()Ljava/util/Vector;

    move-result-object v2

    move/from16 v0, v31

    invoke-virtual {v2, v0}, Ljava/util/Vector;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/thinkware/sundo/inavi3d/Struct/ServerMapXmlList;

    iget-object v4, v2, Lcom/thinkware/sundo/inavi3d/Struct/ServerMapXmlList;->ExtractPath:Ljava/lang/String;

    .line 32129
    .local v4, "ExtractPath":Ljava/lang/String;
    const-string v2, "\\"

    const-string v11, "/"

    invoke-virtual {v3, v2, v11}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v3

    .line 32130
    const-string v2, "\\"

    const-string v11, "/"

    invoke-virtual {v4, v2, v11}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v4

    .line 32133
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getmXmlList()Ljava/util/Vector;

    move-result-object v2

    move/from16 v0, v31

    invoke-virtual {v2, v0}, Ljava/util/Vector;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/thinkware/sundo/inavi3d/Struct/ServerMapXmlList;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/Struct/ServerMapXmlList;->InstallSize:Ljava/lang/String;

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v2

    int-to-long v8, v2

    .line 32134
    .local v8, "installSize":J
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getmXmlList()Ljava/util/Vector;

    move-result-object v2

    move/from16 v0, v31

    invoke-virtual {v2, v0}, Ljava/util/Vector;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/thinkware/sundo/inavi3d/Struct/ServerMapXmlList;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/Struct/ServerMapXmlList;->FileSize:Ljava/lang/String;

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v2

    int-to-long v6, v2

    .line 32135
    .local v6, "downLoadSize":J
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getmXmlList()Ljava/util/Vector;

    move-result-object v2

    move/from16 v0, v31

    invoke-virtual {v2, v0}, Ljava/util/Vector;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/thinkware/sundo/inavi3d/Struct/ServerMapXmlList;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/Struct/ServerMapXmlList;->ID:Ljava/lang/String;

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v10

    .line 32137
    .local v10, "fileid":I
    const-string v35, "/inavi3d/mapdata/mrdata"

    .line 32138
    .local v35, "mrStr":Ljava/lang/String;
    const-string v28, "/inavi3d/mapdata/darc"

    .line 32139
    .local v28, "darcStr":Ljava/lang/String;
    move-object/from16 v0, v35

    invoke-virtual {v4, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_9

    .line 32140
    const-string v4, "/inavi3d/tempmapdata/airmrdata"

    .line 32146
    :goto_0
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$215;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getmXmlList()Ljava/util/Vector;

    move-result-object v11

    invoke-virtual {v11}, Ljava/util/Vector;->size()I

    move-result v11

    invoke-virtual/range {v2 .. v11}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->gzipdownloader(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;JJII)I

    move-result v37

    .line 32147
    if-nez v37, :cond_4

    .line 32149
    sget v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_nDownloadedMapZipSize:I

    int-to-long v12, v2

    add-long/2addr v12, v6

    long-to-int v2, v12

    sput v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_nDownloadedMapZipSize:I

    .line 32152
    :cond_4
    if-eqz v37, :cond_b

    .line 32166
    .end local v3    # "downurl":Ljava/lang/String;
    .end local v4    # "ExtractPath":Ljava/lang/String;
    .end local v5    # "FileName":Ljava/lang/String;
    .end local v6    # "downLoadSize":J
    .end local v8    # "installSize":J
    .end local v10    # "fileid":I
    .end local v21    # "FilePath":Ljava/lang/String;
    .end local v22    # "VersionPath":Ljava/lang/String;
    .end local v28    # "darcStr":Ljava/lang/String;
    .end local v33    # "http":Ljava/lang/String;
    .end local v35    # "mrStr":Ljava/lang/String;
    :cond_5
    :goto_1
    const/4 v2, 0x0

    sput-boolean v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->mMRDownLoadThreadRunning:Z

    .line 32167
    const/4 v2, 0x1

    sput-boolean v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->mMRDownloadPauseFlag:Z

    .line 32168
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v2

    if-eqz v2, :cond_6

    .line 32169
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v2

    const/4 v11, 0x0

    invoke-virtual {v2, v11}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->showMapUpdateStatus(Z)V

    .line 32174
    :cond_6
    if-nez v37, :cond_c

    .line 32175
    const-string v36, "/storage/emulated/0/inavi3d/tempmapdata/airmrdata/airmapinfo.bin"

    .line 32176
    .local v36, "outnam":Ljava/lang/String;
    new-instance v30, Ljava/io/File;

    move-object/from16 v0, v30

    move-object/from16 v1, v36

    invoke-direct {v0, v1}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 32177
    .local v30, "file":Ljava/io/File;
    invoke-virtual/range {v30 .. v30}, Ljava/io/File;->exists()Z

    move-result v2

    if-nez v2, :cond_7

    .line 32180
    :try_start_0
    sget-object v39, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_szServerMapVersion:Ljava/lang/String;

    .line 32181
    .local v39, "s":Ljava/lang/String;
    new-instance v32, Ljava/io/FileWriter;

    const/4 v2, 0x0

    move-object/from16 v0, v32

    move-object/from16 v1, v30

    invoke-direct {v0, v1, v2}, Ljava/io/FileWriter;-><init>(Ljava/io/File;Z)V

    .line 32184
    .local v32, "fw":Ljava/io/FileWriter;
    move-object/from16 v0, v32

    move-object/from16 v1, v39

    invoke-virtual {v0, v1}, Ljava/io/FileWriter;->write(Ljava/lang/String;)V

    .line 32185
    invoke-virtual/range {v32 .. v32}, Ljava/io/FileWriter;->flush()V

    .line 32188
    invoke-virtual/range {v32 .. v32}, Ljava/io/FileWriter;->close()V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    .line 32194
    .end local v32    # "fw":Ljava/io/FileWriter;
    .end local v39    # "s":Ljava/lang/String;
    :cond_7
    :goto_2
    const/4 v2, 0x1

    sput-boolean v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->mbMRDwonLoadComplete:Z

    .line 32196
    sget-object v2, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->mHandler:Landroid/os/Handler;

    sget-object v11, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->mHandler:Landroid/os/Handler;

    const/4 v12, 0x3

    invoke-virtual {v11, v12}, Landroid/os/Handler;->obtainMessage(I)Landroid/os/Message;

    move-result-object v11

    const-wide/16 v12, 0x7d0

    invoke-virtual {v2, v11, v12, v13}, Landroid/os/Handler;->sendMessageDelayed(Landroid/os/Message;J)Z

    .line 32199
    move-object/from16 v0, p0

    iget-object v11, v0, Lcom/thinkware/sundo/inavi3d/INavi3DActivity$215;->this$0:Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    const/4 v12, 0x0

    const-string v13, ""

    sget v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_nSerVerMapZipSize:I

    int-to-long v14, v2

    sget v2, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->m_nSerVerMapUnZipSize:I

    int-to-long v0, v2

    move-wide/from16 v16, v0

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v18

    sub-long v18, v18, v40

    const-string v20, "\ub2e4\uc6b4\ub85c\ub4dc \ubc0f \uc555\ucd95 \ud574\uc81c \uc644\ub8cc"

    invoke-static/range {v11 .. v20}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$24600(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;ILjava/lang/String;JJJLjava/lang/String;)V

    .line 32201
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v2

    const-string v11, "activity"

    invoke-virtual {v2, v11}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v23

    check-cast v23, Landroid/app/ActivityManager;

    .line 32202
    .local v23, "activityManager":Landroid/app/ActivityManager;
    const/16 v2, 0xa

    move-object/from16 v0, v23

    invoke-virtual {v0, v2}, Landroid/app/ActivityManager;->getRunningTasks(I)Ljava/util/List;

    move-result-object v34

    .line 32203
    .local v34, "info":Ljava/util/List;, "Ljava/util/List<Landroid/app/ActivityManager$RunningTaskInfo;>;"
    const/4 v2, 0x0

    move-object/from16 v0, v34

    invoke-interface {v0, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v38

    check-cast v38, Landroid/app/ActivityManager$RunningTaskInfo;

    .line 32204
    .local v38, "runningTaskInfo":Landroid/app/ActivityManager$RunningTaskInfo;
    move-object/from16 v0, v38

    iget-object v2, v0, Landroid/app/ActivityManager$RunningTaskInfo;->topActivity:Landroid/content/ComponentName;

    invoke-virtual {v2}, Landroid/content/ComponentName;->getClassName()Ljava/lang/String;

    move-result-object v43

    .line 32207
    .local v43, "topActivityName":Ljava/lang/String;
    const-class v2, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;

    invoke-virtual {v2}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v2

    move-object/from16 v0, v43

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_8

    .line 32208
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    move-result-object v2

    invoke-static {v2}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->access$24700(Lcom/thinkware/sundo/inavi3d/INavi3DActivity;)V

    .line 32214
    .end local v23    # "activityManager":Landroid/app/ActivityManager;
    .end local v30    # "file":Ljava/io/File;
    .end local v34    # "info":Ljava/util/List;, "Ljava/util/List<Landroid/app/ActivityManager$RunningTaskInfo;>;"
    .end local v36    # "outnam":Ljava/lang/String;
    .end local v38    # "runningTaskInfo":Landroid/app/ActivityManager$RunningTaskInfo;
    .end local v43    # "topActivityName":Ljava/lang/String;
    :cond_8
    :goto_3
    return-void

    .line 32141
    .restart local v3    # "downurl":Ljava/lang/String;
    .restart local v4    # "ExtractPath":Ljava/lang/String;
    .restart local v5    # "FileName":Ljava/lang/String;
    .restart local v6    # "downLoadSize":J
    .restart local v8    # "installSize":J
    .restart local v10    # "fileid":I
    .restart local v21    # "FilePath":Ljava/lang/String;
    .restart local v22    # "VersionPath":Ljava/lang/String;
    .restart local v28    # "darcStr":Ljava/lang/String;
    .restart local v33    # "http":Ljava/lang/String;
    .restart local v35    # "mrStr":Ljava/lang/String;
    :cond_9
    move-object/from16 v0, v28

    invoke-virtual {v4, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_a

    .line 32142
    const-string v4, "/inavi3d/tempmapdata/airdarc"

    goto/16 :goto_0

    .line 32144
    :cond_a
    const-string v4, "/inavi3d/tempmapdata/air3d"

    goto/16 :goto_0

    .line 32155
    :cond_b
    add-int/lit8 v31, v31, 0x1

    .line 32156
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->getmXmlList()Ljava/util/Vector;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/Vector;->size()I

    move-result v2

    move/from16 v0, v31

    if-ne v0, v2, :cond_3

    .line 32158
    const/16 v31, 0x0

    .line 32159
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;->downloadChecker()Z

    move-result v29

    .line 32160
    const/4 v2, 0x1

    move/from16 v0, v29

    if-ne v0, v2, :cond_3

    goto/16 :goto_1

    .line 32212
    .end local v3    # "downurl":Ljava/lang/String;
    .end local v4    # "ExtractPath":Ljava/lang/String;
    .end local v5    # "FileName":Ljava/lang/String;
    .end local v6    # "downLoadSize":J
    .end local v8    # "installSize":J
    .end local v10    # "fileid":I
    .end local v21    # "FilePath":Ljava/lang/String;
    .end local v22    # "VersionPath":Ljava/lang/String;
    .end local v28    # "darcStr":Ljava/lang/String;
    .end local v33    # "http":Ljava/lang/String;
    .end local v35    # "mrStr":Ljava/lang/String;
    :cond_c
    sget-object v2, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->mHandler:Landroid/os/Handler;

    sget-object v11, Lcom/thinkware/sundo/inavi3d/ui/TrafficTconMapUpdateActivity;->mHandler:Landroid/os/Handler;

    const/4 v12, 0x4

    new-instance v13, Ljava/lang/Integer;

    move/from16 v0, v37

    invoke-direct {v13, v0}, Ljava/lang/Integer;-><init>(I)V

    invoke-virtual {v11, v12, v13}, Landroid/os/Handler;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object v11

    invoke-virtual {v2, v11}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto :goto_3

    .line 32189
    .restart local v30    # "file":Ljava/io/File;
    .restart local v36    # "outnam":Ljava/lang/String;
    :catch_0
    move-exception v2

    goto/16 :goto_2
.end method
