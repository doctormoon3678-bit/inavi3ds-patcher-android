.class public Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;
.super Lcom/thinkware/sundo/inavi3d/MainActivity;
.source "UnitedSearchActivity.java"

# interfaces
.implements Landroid/view/View$OnClickListener;
.implements Landroid/widget/RadioGroup$OnCheckedChangeListener;
.implements Landroid/widget/TextView$OnEditorActionListener;
.implements Landroid/view/View$OnFocusChangeListener;
.implements Lcom/thinkware/sundo/inavi3d/ui/SIPLayout$SIPLayoutListener;
.implements Lcom/thinkware/sundo/inavi3d/ui/SIPQwertyLayout$SIPQwertyLayoutListener;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$OnceRunhandler;,
        Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$AntiClickhandler;
    }
.end annotation


# static fields
.field static final QUERY_HISTORY_MAX_COUNT:I = 0xc

.field static RET_NEED_ADDR_NAME_SELECT_MODE:I

.field static RET_NEED_ADMIN_SELECT_MODE:I

.field static RET_NEED_SANGHO_SELECT_MODE:I

.field static RET_SEARCH_FAIL:I

.field static RET_SEARCH_OK:I

.field static mActivity:Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;

.field static syncObjectRecommend:Ljava/lang/Object;


# instance fields
.field final EDIT_MAX_LENGTH:I

.field adtPopupString:Lcom/thinkware/sundo/inavi3d/ui/adapter/CustomAdapter$CustumRadioItemAdapter;

.field arrPopupData:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList",
            "<",
            "Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$AdminCandidate;",
            ">;"
        }
    .end annotation
.end field

.field arrPopupString:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList",
            "<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field bRetForLiveSearch:I

.field bShowPopup:Z

.field btnTabAddr:Landroid/widget/Button;

.field btnTabAround:Landroid/widget/Button;

.field btnTabICode:Landroid/widget/Button;

.field btnTabName:Landroid/widget/Button;

.field btnTabUnited:Landroid/widget/Button;

.field flipper:Landroid/widget/ViewFlipper;

.field layoutGapBottom:Landroid/widget/LinearLayout;

.field layoutGapMiddle:Landroid/widget/LinearLayout;

.field layoutGapTop:Landroid/widget/LinearLayout;

.field layoutRecommendFirst:Landroid/widget/LinearLayout;

.field layoutRecommendSecond:Landroid/widget/LinearLayout;

.field lstPopup:Landroid/widget/ListView;

.field private mAdminDlg:Landroid/app/Dialog;

.field mBtnErase:Landroid/widget/Button;

.field mBtnLive:Landroid/widget/Button;

.field mBtnSearch:Landroid/widget/ImageButton;

.field mBtnSetRegion:Landroid/widget/Button;

.field mEditInput:Landroid/widget/EditText;

.field private mHelpDialog:Landroid/app/Dialog;

.field private mLiveAgreeDialog:Landroid/app/Dialog;

.field mUnitedSearchTask:Lcom/thinkware/sundo/inavi3d/INaviTask;

.field mUnitedSearchTaskInterFace:Lcom/thinkware/sundo/inavi3d/INaviTask$iINaviTaskInterFace;

.field mWatcher:Landroid/text/TextWatcher;

.field m_ButtonArr:[Landroid/widget/Button;

.field m_CarDPXY:Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr$XYInfo;

.field m_CurrentDPXY:Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr$XYInfo;

.field m_ScrollViewRecommendFirst:Landroid/widget/HorizontalScrollView;

.field m_ScrollViewRecommendSecond:Landroid/widget/HorizontalScrollView;

.field m_SearchOption:Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;

.field m_StringColorIndex:Lcom/thinkware/sundo/inavi3d/ui/component/SrchResultColorIndex;

.field m_TempOption:Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;

.field m_ViewLineArr:[Landroid/view/View;

.field private m_bAddMode:Z

.field m_bCancleRecommend:Z

.field public m_bChangeBeforeKeyword:Z

.field m_bChangeClearKeyword:Z

.field m_bChangeKeyword:Z

.field m_bIsExistSpaceInKeyword:Z

.field m_bLiveSrch:Z

.field private m_bOnceRun:Z

.field m_bReSrch:Z

.field m_bSearchTimeCheck:Z

.field m_bShowOverFlowMsg:Z

.field public m_beforeParam:Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/UserDataMgr$beforeKeyParam;

.field m_btnDelHistory:Landroid/widget/Button;

.field m_btnHelpNew:Landroid/widget/Button;

.field m_btnRecent:Landroid/widget/TextView;

.field m_layoutHelpNew:Landroid/widget/LinearLayout;

.field m_layoutQueryHistory:Landroid/widget/LinearLayout;

.field m_layoutRecentWord:Landroid/widget/LinearLayout;

.field private m_nHistoryCount:I

.field m_nInputSpaceNum:I

.field m_nLocalNameIndex:I

.field m_nPrevBackKey:I

.field m_nSanghoIndex:I

.field m_strCurQuery:Ljava/lang/String;

.field m_strHistoryQuery:Ljava/lang/String;

.field m_strNewKeyword:Ljava/lang/String;

.field m_strPrevQuery:Ljava/lang/String;

.field m_strQuery:Ljava/lang/String;

.field private mode:I

.field wordData:Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$RecommendedWordData;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .prologue
    .line 134
    const/4 v0, 0x0

    sput v0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->RET_SEARCH_FAIL:I

    .line 135
    const/4 v0, 0x1

    sput v0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->RET_SEARCH_OK:I

    .line 136
    const/4 v0, -0x2

    sput v0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->RET_NEED_ADDR_NAME_SELECT_MODE:I

    .line 137
    const/4 v0, -0x3

    sput v0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->RET_NEED_SANGHO_SELECT_MODE:I

    .line 138
    const/4 v0, -0x4

    sput v0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->RET_NEED_ADMIN_SELECT_MODE:I

    .line 762
    const/4 v0, 0x0

    sput-object v0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mActivity:Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;

    .line 1179
    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->syncObjectRecommend:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>()V
    .locals 4

    .prologue
    const/4 v3, -0x1

    const/4 v2, 0x0

    const/4 v1, 0x0

    .line 81
    invoke-direct {p0}, Lcom/thinkware/sundo/inavi3d/MainActivity;-><init>()V

    .line 84
    const/16 v0, 0x10

    iput v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->EDIT_MAX_LENGTH:I

    .line 99
    const-string v0, ""

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strQuery:Ljava/lang/String;

    .line 115
    iput v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_nHistoryCount:I

    .line 123
    iput v3, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_nSanghoIndex:I

    .line 124
    iput v3, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_nLocalNameIndex:I

    .line 129
    iput-object v2, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mHelpDialog:Landroid/app/Dialog;

    .line 142
    iput-object v2, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mAdminDlg:Landroid/app/Dialog;

    .line 149
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bLiveSrch:Z

    .line 150
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bReSrch:Z

    .line 153
    iput-object v2, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mLiveAgreeDialog:Landroid/app/Dialog;

    .line 170
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bIsExistSpaceInKeyword:Z

    .line 173
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bSearchTimeCheck:Z

    .line 176
    iput v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mode:I

    .line 177
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bAddMode:Z

    .line 179
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bOnceRun:Z

    .line 207
    const-string v0, ""

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strNewKeyword:Ljava/lang/String;

    .line 208
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bChangeKeyword:Z

    .line 209
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bChangeClearKeyword:Z

    .line 210
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bShowOverFlowMsg:Z

    .line 211
    iput v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_nInputSpaceNum:I

    .line 212
    iput v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_nPrevBackKey:I

    .line 316
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bChangeBeforeKeyword:Z

    .line 388
    new-instance v0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$3;

    invoke-direct {v0, p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$3;-><init>(Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;)V

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mWatcher:Landroid/text/TextWatcher;

    .line 1171
    new-instance v0, Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$RecommendedWordData;

    invoke-direct {v0}, Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$RecommendedWordData;-><init>()V

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->wordData:Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$RecommendedWordData;

    .line 1172
    const-string v0, ""

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strPrevQuery:Ljava/lang/String;

    .line 1173
    const-string v0, ""

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strCurQuery:Ljava/lang/String;

    .line 1174
    new-instance v0, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr$XYInfo;

    invoke-direct {v0}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr$XYInfo;-><init>()V

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_CurrentDPXY:Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr$XYInfo;

    .line 1175
    new-instance v0, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr$XYInfo;

    invoke-direct {v0}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr$XYInfo;-><init>()V

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_CarDPXY:Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr$XYInfo;

    .line 1176
    iput-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bCancleRecommend:Z

    .line 1177
    iput-object v2, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_ButtonArr:[Landroid/widget/Button;

    .line 1178
    iput-object v2, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_ViewLineArr:[Landroid/view/View;

    .line 1181
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/ui/component/SrchResultColorIndex;->getInstance()Lcom/thinkware/sundo/inavi3d/ui/component/SrchResultColorIndex;

    move-result-object v0

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_StringColorIndex:Lcom/thinkware/sundo/inavi3d/ui/component/SrchResultColorIndex;

    .line 2157
    iput v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->bRetForLiveSearch:I

    .line 2295
    iput-object v2, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mUnitedSearchTask:Lcom/thinkware/sundo/inavi3d/INaviTask;

    .line 2296
    new-instance v0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$19;

    invoke-direct {v0, p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$19;-><init>(Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;)V

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mUnitedSearchTaskInterFace:Lcom/thinkware/sundo/inavi3d/INaviTask$iINaviTaskInterFace;

    .line 2597
    return-void
.end method

.method private ChangeBeforeKeyword()V
    .locals 3

    .prologue
    .line 321
    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bChangeBeforeKeyword:Z

    .line 323
    const-string v0, "HYO"

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "HYO ChangeBeforeKeyword => before="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_beforeParam:Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/UserDataMgr$beforeKeyParam;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/UserDataMgr$beforeKeyParam;->strBeforeKeyword:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ", curIdx="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_beforeParam:Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/UserDataMgr$beforeKeyParam;

    iget v2, v2, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/UserDataMgr$beforeKeyParam;->nCurIndex:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/thinkware/sundo/inavi3d/LOGTW;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 325
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    const-string v1, ""

    invoke-virtual {v0, v1}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    .line 326
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_beforeParam:Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/UserDataMgr$beforeKeyParam;

    iget-object v1, v1, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/UserDataMgr$beforeKeyParam;->strBeforeKeyword:Ljava/lang/String;

    invoke-virtual {v0, v1}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    .line 328
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_beforeParam:Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/UserDataMgr$beforeKeyParam;

    iget v0, v0, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/UserDataMgr$beforeKeyParam;->nCurIndex:I

    if-ltz v0, :cond_0

    .line 329
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_beforeParam:Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/UserDataMgr$beforeKeyParam;

    iget v1, v1, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/UserDataMgr$beforeKeyParam;->nCurIndex:I

    invoke-virtual {v0, v1}, Landroid/widget/EditText;->setSelection(I)V

    .line 331
    :cond_0
    return-void
.end method

.method private ChangeEditClear()V
    .locals 2

    .prologue
    .line 243
    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bChangeClearKeyword:Z

    .line 244
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    const-string v1, ""

    invoke-virtual {v0, v1}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    .line 245
    return-void
.end method

.method private ChangeEditText()V
    .locals 2

    .prologue
    .line 218
    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bChangeKeyword:Z

    .line 219
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    const-string v1, ""

    invoke-virtual {v0, v1}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    .line 220
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strNewKeyword:Ljava/lang/String;

    invoke-virtual {v0, v1}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    .line 221
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strNewKeyword:Ljava/lang/String;

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/widget/EditText;->setSelection(I)V

    .line 222
    const-string v0, ""

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strNewKeyword:Ljava/lang/String;

    .line 224
    return-void
.end method

.method private ChangeFirstSpaceDelete()V
    .locals 4

    .prologue
    const/4 v3, 0x2

    .line 229
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    invoke-virtual {v1}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    .line 230
    .local v0, "strKey":Ljava/lang/String;
    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    .line 232
    iput v3, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_nInputSpaceNum:I

    .line 234
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    const-string v2, ""

    invoke-virtual {v1, v2}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    .line 235
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    invoke-virtual {v1, v0}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    .line 236
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v2

    invoke-virtual {v1, v2}, Landroid/widget/EditText;->setSelection(I)V

    .line 238
    iput v3, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_nInputSpaceNum:I

    .line 239
    return-void
.end method

.method private EraseSpaceInEditText()V
    .locals 10

    .prologue
    const/4 v9, 0x1

    .line 343
    iget-object v7, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    invoke-virtual {v7}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v5

    .line 344
    .local v5, "strKey":Ljava/lang/String;
    const-string v6, ""

    .line 345
    .local v6, "strNewKey":Ljava/lang/String;
    invoke-virtual {v5}, Ljava/lang/String;->length()I

    move-result v3

    .line 347
    .local v3, "nLen":I
    const/4 v0, 0x0

    .line 348
    .local v0, "bSpaceFound":Z
    const/4 v4, 0x0

    .line 351
    .local v4, "nSpaceCount":I
    invoke-virtual {p0, v9}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->enableRegionBtn(Z)V

    .line 354
    const/4 v2, 0x0

    .local v2, "ii":I
    :goto_0
    if-ge v2, v3, :cond_2

    .line 356
    invoke-virtual {v5, v2}, Ljava/lang/String;->charAt(I)C

    move-result v1

    .line 357
    .local v1, "ch":C
    const/16 v7, 0x20

    if-eq v1, v7, :cond_0

    .line 359
    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v7, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-static {v1}, Ljava/lang/Character;->toString(C)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    .line 354
    :goto_1
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    .line 363
    :cond_0
    add-int/lit8 v4, v4, 0x1

    .line 364
    if-ne v4, v9, :cond_1

    if-eqz v2, :cond_1

    add-int/lit8 v7, v3, -0x1

    if-eq v2, v7, :cond_1

    .line 365
    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v7, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-static {v1}, Ljava/lang/Character;->toString(C)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    goto :goto_1

    .line 367
    :cond_1
    const/4 v0, 0x1

    goto :goto_1

    .line 372
    .end local v1    # "ch":C
    :cond_2
    if-eqz v0, :cond_3

    .line 374
    iput-boolean v9, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bCancleRecommend:Z

    .line 375
    iget-object v7, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    const-string v8, ""

    invoke-virtual {v7, v8}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    .line 376
    iput-boolean v9, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bCancleRecommend:Z

    .line 377
    iget-object v7, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    invoke-virtual {v7, v6}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    .line 378
    iget-object v7, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    invoke-virtual {v6}, Ljava/lang/String;->length()I

    move-result v8

    invoke-virtual {v7, v8}, Landroid/widget/EditText;->setSelection(I)V

    .line 379
    iget-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bLiveSrch:Z

    if-nez v7, :cond_3

    .line 381
    invoke-virtual {p0, v9}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->enableRegionBtn(Z)V

    .line 385
    :cond_3
    return-void
.end method

.method private MakeAdminCandidatePopup()Z
    .locals 7

    .prologue
    const/4 v6, 0x0

    .line 182
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->arrPopupString:Ljava/util/ArrayList;

    invoke-virtual {v4}, Ljava/util/ArrayList;->clear()V

    .line 183
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->arrPopupData:Ljava/util/ArrayList;

    invoke-virtual {v4}, Ljava/util/ArrayList;->clear()V

    .line 184
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->USGetAdminCandidateCnt()I

    move-result v2

    .line 185
    .local v2, "nCnt":I
    new-instance v3, Ljava/util/TreeMap;

    invoke-direct {v3}, Ljava/util/TreeMap;-><init>()V

    .line 187
    .local v3, "tempSortingMap":Ljava/util/TreeMap;, "Ljava/util/TreeMap<Ljava/lang/String;Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$AdminCandidate;>;"
    const/4 v1, 0x0

    .local v1, "ii":I
    :goto_0
    if-ge v1, v2, :cond_0

    .line 190
    new-instance v0, Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$AdminCandidate;

    invoke-direct {v0}, Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$AdminCandidate;-><init>()V

    .line 191
    .local v0, "data":Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$AdminCandidate;
    invoke-static {v1, v0}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->USGetAdminCandidateData(ILcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$AdminCandidate;)I

    .line 193
    iget-object v4, v0, Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$AdminCandidate;->m_cpAdminName:Ljava/lang/String;

    invoke-virtual {v3, v4, v0}, Ljava/util/TreeMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 187
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    .line 196
    .end local v0    # "data":Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$AdminCandidate;
    :cond_0
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->arrPopupData:Ljava/util/ArrayList;

    invoke-virtual {v3}, Ljava/util/TreeMap;->values()Ljava/util/Collection;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 197
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->arrPopupString:Ljava/util/ArrayList;

    invoke-virtual {v3}, Ljava/util/TreeMap;->keySet()Ljava/util/Set;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 199
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->adtPopupString:Lcom/thinkware/sundo/inavi3d/ui/adapter/CustomAdapter$CustumRadioItemAdapter;

    invoke-virtual {v4, v6}, Lcom/thinkware/sundo/inavi3d/ui/adapter/CustomAdapter$CustumRadioItemAdapter;->SetCheckIndex(I)V

    .line 200
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->adtPopupString:Lcom/thinkware/sundo/inavi3d/ui/adapter/CustomAdapter$CustumRadioItemAdapter;

    invoke-virtual {v4}, Lcom/thinkware/sundo/inavi3d/ui/adapter/CustomAdapter$CustumRadioItemAdapter;->notifyDataSetChanged()V

    .line 202
    iget-object v4, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->lstPopup:Landroid/widget/ListView;

    invoke-virtual {v4, v6, v6}, Landroid/widget/ListView;->setSelectionFromTop(II)V

    .line 204
    const/4 v4, 0x1

    return v4
.end method

.method public static SetNetwork(Z)V
    .locals 3
    .param p0, "bNetwork"    # Z

    .prologue
    const/4 v2, 0x1

    .line 2656
    sget-object v0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mActivity:Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;

    if-nez v0, :cond_1

    .line 2675
    :cond_0
    :goto_0
    return-void

    .line 2659
    :cond_1
    if-ne p0, v2, :cond_0

    .line 2661
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->getInstance()Lcom/thinkware/sundo/inavi3d/InaviConfig;

    move-result-object v0

    const/16 v1, 0x11b

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->CNaviConfigGet(I)I

    move-result v0

    if-ne v0, v2, :cond_0

    .line 2663
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/livesearch/LiveSearchManager;->getInstance()Lcom/thinkware/sundo/inavi3d/livesearch/LiveSearchManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/livesearch/LiveSearchManager;->isAgreed()Z

    move-result v0

    if-ne v0, v2, :cond_2

    .line 2665
    sget-object v0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mActivity:Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;

    iput-boolean v2, v0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bLiveSrch:Z

    .line 2666
    sget-object v0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mActivity:Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mBtnLive:Landroid/widget/Button;

    invoke-virtual {v0, v2}, Landroid/widget/Button;->setSelected(Z)V

    .line 2667
    sget-object v0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mActivity:Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;

    iget-object v0, v0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mBtnLive:Landroid/widget/Button;

    invoke-virtual {v0}, Landroid/widget/Button;->invalidate()V

    goto :goto_0

    .line 2670
    :cond_2
    sget-object v0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mActivity:Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;

    invoke-direct {v0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->showLiveProvisionPopup()V

    goto :goto_0
.end method

.method private ShowInputOverflowMsg()V
    .locals 7

    .prologue
    const/16 v6, 0x10

    const/4 v5, 0x1

    const/4 v4, 0x0

    .line 283
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    invoke-virtual {v1, v4}, Landroid/widget/EditText;->setEnabled(Z)V

    .line 285
    iput-boolean v4, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bShowOverFlowMsg:Z

    .line 287
    iget-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->bShowPopup:Z

    if-nez v1, :cond_0

    .line 288
    const/16 v1, 0x30

    const-string v2, "\uc54c\ub9bc"

    const-string v3, "\ub354 \uc774\uc0c1 \uc785\ub825\ud560 \uc218 \uc5c6\uc2b5\ub2c8\ub2e4."

    invoke-static {v1, p0, v2, v3, v4}, Lcom/thinkware/sundo/inavi3d/ui/popup/PopupManager;->ShowPopup(ILandroid/content/Context;Ljava/lang/String;Ljava/lang/String;I)Lcom/thinkware/sundo/inavi3d/ui/popup/InaviPopup;

    move-result-object v0

    .line 292
    .local v0, "popup":Lcom/thinkware/sundo/inavi3d/ui/popup/InaviPopup;
    new-instance v1, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$2;

    invoke-direct {v1, p0, v0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$2;-><init>(Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;Lcom/thinkware/sundo/inavi3d/ui/popup/InaviPopup;)V

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/inavi3d/ui/popup/InaviPopup;->SetokListner(Landroid/view/View$OnClickListener;)Z

    .line 300
    iput-boolean v5, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->bShowPopup:Z

    .line 304
    .end local v0    # "popup":Lcom/thinkware/sundo/inavi3d/ui/popup/InaviPopup;
    :goto_0
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strNewKeyword:Ljava/lang/String;

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v1

    if-le v1, v6, :cond_1

    .line 305
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strNewKeyword:Ljava/lang/String;

    invoke-virtual {v2, v4, v6}, Ljava/lang/String;->subSequence(II)Ljava/lang/CharSequence;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    .line 308
    :goto_1
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    invoke-virtual {v2}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v2

    invoke-interface {v2}, Landroid/text/Editable;->length()I

    move-result v2

    invoke-virtual {v1, v2}, Landroid/widget/EditText;->setSelection(I)V

    .line 310
    const-string v1, ""

    iput-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strNewKeyword:Ljava/lang/String;

    .line 312
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    invoke-virtual {v1, v5}, Landroid/widget/EditText;->setEnabled(Z)V

    .line 313
    return-void

    .line 302
    :cond_0
    iput-boolean v4, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->bShowPopup:Z

    goto :goto_0

    .line 307
    :cond_1
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strNewKeyword:Ljava/lang/String;

    invoke-virtual {v1, v2}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    goto :goto_1
.end method

.method private _ShowInputOverflowMsg()V
    .locals 6

    .prologue
    const/4 v5, 0x1

    const/4 v4, 0x0

    .line 249
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    invoke-virtual {v1, v4}, Landroid/widget/EditText;->setEnabled(Z)V

    .line 251
    iput-boolean v4, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bShowOverFlowMsg:Z

    .line 253
    iget-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->bShowPopup:Z

    if-nez v1, :cond_0

    .line 254
    const/16 v1, 0x30

    const-string v2, "\uc54c\ub9bc"

    const-string v3, "\ub354 \uc774\uc0c1 \uc785\ub825\ud560 \uc218 \uc5c6\uc2b5\ub2c8\ub2e4."

    invoke-static {v1, p0, v2, v3, v4}, Lcom/thinkware/sundo/inavi3d/ui/popup/PopupManager;->ShowPopup(ILandroid/content/Context;Ljava/lang/String;Ljava/lang/String;I)Lcom/thinkware/sundo/inavi3d/ui/popup/InaviPopup;

    move-result-object v0

    .line 258
    .local v0, "popup":Lcom/thinkware/sundo/inavi3d/ui/popup/InaviPopup;
    new-instance v1, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$1;

    invoke-direct {v1, p0, v0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$1;-><init>(Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;Lcom/thinkware/sundo/inavi3d/ui/popup/InaviPopup;)V

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/inavi3d/ui/popup/InaviPopup;->SetokListner(Landroid/view/View$OnClickListener;)Z

    .line 266
    iput-boolean v5, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->bShowPopup:Z

    .line 278
    .end local v0    # "popup":Lcom/thinkware/sundo/inavi3d/ui/popup/InaviPopup;
    :goto_0
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    invoke-virtual {v1, v5}, Landroid/widget/EditText;->setEnabled(Z)V

    .line 279
    return-void

    .line 268
    :cond_0
    iput-boolean v4, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->bShowPopup:Z

    goto :goto_0
.end method

.method static synthetic access$000(Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;)V
    .locals 0
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;

    .prologue
    .line 81
    invoke-direct {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->ShowInputOverflowMsg()V

    return-void
.end method

.method static synthetic access$100(Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;)V
    .locals 0
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;

    .prologue
    .line 81
    invoke-direct {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->ChangeEditText()V

    return-void
.end method

.method static synthetic access$1000(Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;)Landroid/app/Dialog;
    .locals 1
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;

    .prologue
    .line 81
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mLiveAgreeDialog:Landroid/app/Dialog;

    return-object v0
.end method

.method static synthetic access$1100(Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;)V
    .locals 0
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;

    .prologue
    .line 81
    invoke-direct {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->tabButtonEnable()V

    return-void
.end method

.method static synthetic access$1200(Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;)V
    .locals 0
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;

    .prologue
    .line 81
    invoke-direct {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->loadQueryHistory()V

    return-void
.end method

.method static synthetic access$1300(Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;)Z
    .locals 1
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;

    .prologue
    .line 81
    invoke-direct {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->MakeAdminCandidatePopup()Z

    move-result v0

    return v0
.end method

.method static synthetic access$1402(Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;Z)Z
    .locals 0
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;
    .param p1, "x1"    # Z

    .prologue
    .line 81
    iput-boolean p1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bOnceRun:Z

    return p1
.end method

.method static synthetic access$200(Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;)V
    .locals 0
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;

    .prologue
    .line 81
    invoke-direct {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->ChangeEditClear()V

    return-void
.end method

.method static synthetic access$300(Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;)V
    .locals 0
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;

    .prologue
    .line 81
    invoke-direct {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->ChangeFirstSpaceDelete()V

    return-void
.end method

.method static synthetic access$400(Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;)V
    .locals 0
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;

    .prologue
    .line 81
    invoke-direct {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->ChangeBeforeKeyword()V

    return-void
.end method

.method static synthetic access$500(Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;Ljava/lang/String;)V
    .locals 0
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;
    .param p1, "x1"    # Ljava/lang/String;

    .prologue
    .line 81
    invoke-direct {p0, p1}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->loadRecommendWord(Ljava/lang/String;)V

    return-void
.end method

.method static synthetic access$600(Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;)V
    .locals 0
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;

    .prologue
    .line 81
    invoke-direct {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->hideRecommendedWord()V

    return-void
.end method

.method static synthetic access$700(Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;)V
    .locals 0
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;

    .prologue
    .line 81
    invoke-direct {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->EraseSpaceInEditText()V

    return-void
.end method

.method static synthetic access$800(Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;)Landroid/app/Dialog;
    .locals 1
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;

    .prologue
    .line 81
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mAdminDlg:Landroid/app/Dialog;

    return-object v0
.end method

.method static synthetic access$900(Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;)I
    .locals 1
    .param p0, "x0"    # Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;

    .prologue
    .line 81
    iget v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mode:I

    return v0
.end method

.method private convertToLocalHorizontalCoordinate(Landroid/widget/EditText;F)F
    .locals 2
    .param p1, "textView2"    # Landroid/widget/EditText;
    .param p2, "x"    # F

    .prologue
    .line 739
    invoke-virtual {p1}, Landroid/widget/EditText;->getTotalPaddingLeft()I

    move-result v0

    int-to-float v0, v0

    sub-float/2addr p2, v0

    .line 741
    const/4 v0, 0x0

    invoke-static {v0, p2}, Ljava/lang/Math;->max(FF)F

    move-result p2

    .line 742
    invoke-virtual {p1}, Landroid/widget/EditText;->getWidth()I

    move-result v0

    invoke-virtual {p1}, Landroid/widget/EditText;->getTotalPaddingRight()I

    move-result v1

    sub-int/2addr v0, v1

    add-int/lit8 v0, v0, -0x1

    int-to-float v0, v0

    invoke-static {v0, p2}, Ljava/lang/Math;->min(FF)F

    move-result p2

    .line 743
    invoke-virtual {p1}, Landroid/widget/EditText;->getScrollX()I

    move-result v0

    int-to-float v0, v0

    add-float/2addr p2, v0

    .line 744
    return p2
.end method

.method private getLineAtCoordinate(Landroid/widget/EditText;F)I
    .locals 2
    .param p1, "textView2"    # Landroid/widget/EditText;
    .param p2, "y"    # F

    .prologue
    .line 748
    invoke-virtual {p1}, Landroid/widget/EditText;->getTotalPaddingTop()I

    move-result v0

    int-to-float v0, v0

    sub-float/2addr p2, v0

    .line 750
    const/4 v0, 0x0

    invoke-static {v0, p2}, Ljava/lang/Math;->max(FF)F

    move-result p2

    .line 751
    invoke-virtual {p1}, Landroid/widget/EditText;->getHeight()I

    move-result v0

    invoke-virtual {p1}, Landroid/widget/EditText;->getTotalPaddingBottom()I

    move-result v1

    sub-int/2addr v0, v1

    add-int/lit8 v0, v0, -0x1

    int-to-float v0, v0

    invoke-static {v0, p2}, Ljava/lang/Math;->min(FF)F

    move-result p2

    .line 752
    invoke-virtual {p1}, Landroid/widget/EditText;->getScrollY()I

    move-result v0

    int-to-float v0, v0

    add-float/2addr p2, v0

    .line 753
    invoke-virtual {p1}, Landroid/widget/EditText;->getLayout()Landroid/text/Layout;

    move-result-object v0

    float-to-int v1, p2

    invoke-virtual {v0, v1}, Landroid/text/Layout;->getLineForVertical(I)I

    move-result v0

    return v0
.end method

.method private getOffsetAtCoordinate(Landroid/widget/EditText;IF)I
    .locals 1
    .param p1, "textView2"    # Landroid/widget/EditText;
    .param p2, "line"    # I
    .param p3, "x"    # F

    .prologue
    .line 734
    invoke-direct {p0, p1, p3}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->convertToLocalHorizontalCoordinate(Landroid/widget/EditText;F)F

    move-result p3

    .line 735
    invoke-virtual {p1}, Landroid/widget/EditText;->getLayout()Landroid/text/Layout;

    move-result-object v0

    invoke-virtual {v0, p2, p3}, Landroid/text/Layout;->getOffsetForHorizontal(IF)I

    move-result v0

    return v0
.end method

.method private hideRecommendedWord()V
    .locals 3

    .prologue
    const/16 v2, 0x8

    .line 1364
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_layoutRecentWord:Landroid/widget/LinearLayout;

    invoke-virtual {v0}, Landroid/widget/LinearLayout;->getVisibility()I

    move-result v0

    if-eqz v0, :cond_0

    .line 1365
    const-string v0, ""

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strPrevQuery:Ljava/lang/String;

    .line 1366
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_layoutHelpNew:Landroid/widget/LinearLayout;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setVisibility(I)V

    .line 1367
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->layoutGapTop:Landroid/widget/LinearLayout;

    invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->setVisibility(I)V

    .line 1368
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->layoutGapMiddle:Landroid/widget/LinearLayout;

    invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->setVisibility(I)V

    .line 1369
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->layoutGapBottom:Landroid/widget/LinearLayout;

    invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->setVisibility(I)V

    .line 1370
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_ScrollViewRecommendFirst:Landroid/widget/HorizontalScrollView;

    invoke-virtual {v0, v2}, Landroid/widget/HorizontalScrollView;->setVisibility(I)V

    .line 1371
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_ScrollViewRecommendSecond:Landroid/widget/HorizontalScrollView;

    invoke-virtual {v0, v2}, Landroid/widget/HorizontalScrollView;->setVisibility(I)V

    .line 1373
    :cond_0
    return-void
.end method

.method private loadQueryHistory()V
    .locals 14

    .prologue
    .line 1377
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->USGetQueryHistoryCount()I

    move-result v4

    .line 1379
    .local v4, "nCount":I
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_layoutRecentWord:Landroid/widget/LinearLayout;

    invoke-virtual {v10}, Landroid/widget/LinearLayout;->getVisibility()I

    move-result v10

    if-eqz v10, :cond_0

    .line 1380
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_layoutRecentWord:Landroid/widget/LinearLayout;

    const/4 v11, 0x0

    invoke-virtual {v10, v11}, Landroid/widget/LinearLayout;->setVisibility(I)V

    .line 1383
    :cond_0
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_layoutQueryHistory:Landroid/widget/LinearLayout;

    invoke-virtual {v10}, Landroid/widget/LinearLayout;->removeAllViews()V

    .line 1386
    new-instance v6, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v10, -0x2

    const/4 v11, -0x1

    invoke-direct {v6, v10, v11}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 1389
    .local v6, "params":Landroid/widget/LinearLayout$LayoutParams;
    const/16 v10, 0x11

    iput v10, v6, Landroid/widget/LinearLayout$LayoutParams;->gravity:I

    .line 1391
    const/4 v1, 0x0

    .local v1, "i":I
    :goto_0
    if-ge v1, v4, :cond_3

    .line 1392
    new-instance v0, Landroid/widget/Button;

    invoke-direct {v0, p0}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    .line 1393
    .local v0, "btn":Landroid/widget/Button;
    invoke-static {v1}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->USGetQueryHistory(I)Ljava/lang/String;

    move-result-object v8

    .line 1395
    .local v8, "strQuery":Ljava/lang/String;
    move-object v7, v8

    .line 1397
    .local v7, "strOrginal":Ljava/lang/String;
    move-object v9, v8

    .line 1398
    .local v9, "strQueryInButton":Ljava/lang/String;
    invoke-virtual {v8}, Ljava/lang/String;->length()I

    move-result v5

    .line 1400
    .local v5, "nLen":I
    const/16 v10, 0xa

    if-le v5, v10, :cond_1

    .line 1401
    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x0

    const/16 v12, 0xa

    invoke-virtual {v8, v11, v12}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    const-string v11, "..."

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    .line 1403
    :cond_1
    invoke-virtual {v0, v8}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 1404
    const/4 v10, 0x0

    const/high16 v11, 0x41c00000    # 24.0f

    invoke-virtual {v0, v10, v11}, Landroid/widget/Button;->setTextSize(IF)V

    .line 1405
    const/16 v10, 0x6c

    const/16 v11, 0x88

    const/16 v12, 0xb0

    invoke-static {v10, v11, v12}, Landroid/graphics/Color;->rgb(III)I

    move-result v10

    invoke-virtual {v0, v10}, Landroid/widget/Button;->setTextColor(I)V

    .line 1406
    invoke-virtual {v0, v6}, Landroid/widget/Button;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 1407
    const v10, 0x7f02051b

    invoke-virtual {v0, v10}, Landroid/widget/Button;->setBackgroundResource(I)V

    .line 1408
    const/16 v10, 0xa5

    invoke-virtual {v0, v10}, Landroid/widget/Button;->setWidth(I)V

    .line 1409
    const/16 v10, 0xf

    const/4 v11, 0x0

    const/16 v12, 0xf

    const/4 v13, 0x0

    invoke-virtual {v0, v10, v11, v12, v13}, Landroid/widget/Button;->setPadding(IIII)V

    .line 1411
    new-instance v10, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$7;

    invoke-direct {v10, p0, v7}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$7;-><init>(Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;Ljava/lang/String;)V

    invoke-virtual {v0, v10}, Landroid/widget/Button;->setOnLongClickListener(Landroid/view/View$OnLongClickListener;)V

    .line 1456
    new-instance v10, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$8;

    invoke-direct {v10, p0, v7}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$8;-><init>(Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;Ljava/lang/String;)V

    invoke-virtual {v0, v10}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 1504
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_layoutQueryHistory:Landroid/widget/LinearLayout;

    invoke-virtual {v10, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 1506
    add-int/lit8 v10, v4, -0x1

    if-ge v1, v10, :cond_2

    .line 1507
    new-instance v2, Landroid/widget/ImageView;

    invoke-direct {v2, p0}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    .line 1508
    .local v2, "line":Landroid/widget/ImageView;
    const v10, 0x7f020e12

    invoke-virtual {v2, v10}, Landroid/widget/ImageView;->setImageResource(I)V

    .line 1509
    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v10, -0x2

    const/4 v11, -0x2

    const/high16 v12, 0x41800000    # 16.0f

    invoke-direct {v3, v10, v11, v12}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    .line 1510
    .local v3, "lineParams":Landroid/widget/LinearLayout$LayoutParams;
    const/16 v10, 0x10

    iput v10, v3, Landroid/widget/LinearLayout$LayoutParams;->gravity:I

    .line 1511
    invoke-virtual {v2, v3}, Landroid/widget/ImageView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 1512
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_layoutQueryHistory:Landroid/widget/LinearLayout;

    invoke-virtual {v10, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 1513
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v10

    invoke-virtual {v10}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->getScaleType()I

    move-result v10

    const/4 v11, 0x2

    if-lt v10, v11, :cond_2

    .line 1514
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INaviScaleManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INaviScaleManager;

    move-result-object v10

    invoke-virtual {v10, v2}, Lcom/thinkware/sundo/inavi3d/INaviScaleManager;->restoreScale1Pixel(Landroid/view/View;)V

    .line 1391
    .end local v2    # "line":Landroid/widget/ImageView;
    .end local v3    # "lineParams":Landroid/widget/LinearLayout$LayoutParams;
    :cond_2
    add-int/lit8 v1, v1, 0x1

    goto/16 :goto_0

    .line 1519
    .end local v0    # "btn":Landroid/widget/Button;
    .end local v5    # "nLen":I
    .end local v7    # "strOrginal":Ljava/lang/String;
    .end local v8    # "strQuery":Ljava/lang/String;
    .end local v9    # "strQueryInButton":Ljava/lang/String;
    :cond_3
    if-gtz v4, :cond_4

    .line 1523
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_btnDelHistory:Landroid/widget/Button;

    const/16 v11, 0x8

    invoke-virtual {v10, v11}, Landroid/widget/Button;->setVisibility(I)V

    .line 1531
    :goto_1
    return-void

    .line 1529
    :cond_4
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_btnDelHistory:Landroid/widget/Button;

    const/4 v11, 0x0

    invoke-virtual {v10, v11}, Landroid/widget/Button;->setVisibility(I)V

    goto :goto_1
.end method

.method private loadRecommendWord(Ljava/lang/String;)V
    .locals 4
    .param p1, "strQuery"    # Ljava/lang/String;

    .prologue
    const/4 v2, 0x1

    const/4 v3, 0x0

    .line 1186
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bCancleRecommend:Z

    if-eqz v0, :cond_1

    .line 1188
    iput-boolean v3, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bCancleRecommend:Z

    .line 1360
    :cond_0
    :goto_0
    return-void

    .line 1192
    :cond_1
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strPrevQuery:Ljava/lang/String;

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_0

    .line 1195
    iput-object p1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strPrevQuery:Ljava/lang/String;

    .line 1196
    invoke-static {v2}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->USRecommendedBreak(Z)I

    .line 1197
    new-instance v0, Lcom/thinkware/sundo/inavi3d/INaviTask;

    new-instance v1, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$6;

    invoke-direct {v1, p0, p1}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$6;-><init>(Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;Ljava/lang/String;)V

    invoke-direct {v0, v1, v3}, Lcom/thinkware/sundo/inavi3d/INaviTask;-><init>(Lcom/thinkware/sundo/inavi3d/INaviTask$iINaviTaskInterFace;Z)V

    new-array v1, v2, [Ljava/lang/Object;

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    aput-object v2, v1, v3

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/inavi3d/INaviTask;->execute([Ljava/lang/Object;)Landroid/os/AsyncTask;

    goto :goto_0
.end method

.method private showLiveProvisionPopup()V
    .locals 3

    .prologue
    .line 2648
    const-string v1, "Live"

    const-string v2, "showLiveProvisionPopup()"

    invoke-static {v1, v2}, Lcom/thinkware/sundo/inavi3d/LOGTW;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 2650
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mLiveAgreeDialog:Landroid/app/Dialog;

    const v2, 0x7f0a0312

    invoke-virtual {v1, v2}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    .line 2651
    .local v0, "txtLiveTerm":Landroid/widget/TextView;
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/livesearch/LiveSearchManager;->getInstance()Lcom/thinkware/sundo/inavi3d/livesearch/LiveSearchManager;

    move-result-object v1

    invoke-virtual {v1}, Lcom/thinkware/sundo/inavi3d/livesearch/LiveSearchManager;->getProvisionText()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2652
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mLiveAgreeDialog:Landroid/app/Dialog;

    invoke-virtual {v1}, Landroid/app/Dialog;->show()V

    .line 2653
    return-void
.end method

.method private tabButtonDesable()V
    .locals 3

    .prologue
    const/4 v2, 0x0

    const/4 v1, 0x0

    .line 1846
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabUnited:Landroid/widget/Button;

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setClickable(Z)V

    .line 1847
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabName:Landroid/widget/Button;

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setClickable(Z)V

    .line 1848
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabAddr:Landroid/widget/Button;

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setClickable(Z)V

    .line 1849
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabAround:Landroid/widget/Button;

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setClickable(Z)V

    .line 1850
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabICode:Landroid/widget/Button;

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setClickable(Z)V

    .line 1851
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabUnited:Landroid/widget/Button;

    invoke-virtual {v0, v2}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 1852
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabName:Landroid/widget/Button;

    invoke-virtual {v0, v2}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 1853
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabAddr:Landroid/widget/Button;

    invoke-virtual {v0, v2}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 1854
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabAround:Landroid/widget/Button;

    invoke-virtual {v0, v2}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 1855
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabICode:Landroid/widget/Button;

    invoke-virtual {v0, v2}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 1856
    return-void
.end method

.method private tabButtonEnable()V
    .locals 2

    .prologue
    const/4 v1, 0x1

    .line 1859
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabUnited:Landroid/widget/Button;

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setClickable(Z)V

    .line 1860
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabName:Landroid/widget/Button;

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setClickable(Z)V

    .line 1861
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabAddr:Landroid/widget/Button;

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setClickable(Z)V

    .line 1862
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabAround:Landroid/widget/Button;

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setClickable(Z)V

    .line 1863
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabICode:Landroid/widget/Button;

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setClickable(Z)V

    .line 1864
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabUnited:Landroid/widget/Button;

    invoke-virtual {v0, p0}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 1865
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabName:Landroid/widget/Button;

    invoke-virtual {v0, p0}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 1866
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabAddr:Landroid/widget/Button;

    invoke-virtual {v0, p0}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 1867
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabAround:Landroid/widget/Button;

    invoke-virtual {v0, p0}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 1868
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabICode:Landroid/widget/Button;

    invoke-virtual {v0, p0}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 1869
    return-void
.end method


# virtual methods
.method public DoLiveSearch()V
    .locals 4

    .prologue
    const/4 v2, 0x1

    const/4 v3, 0x0

    .line 2159
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strQuery:Ljava/lang/String;

    invoke-static {v0}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->USSetQuery(Ljava/lang/String;)V

    .line 2161
    new-instance v0, Lcom/thinkware/sundo/inavi3d/INaviTask;

    new-instance v1, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$18;

    invoke-direct {v1, p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$18;-><init>(Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;)V

    invoke-direct {v0, v1, v3, v2}, Lcom/thinkware/sundo/inavi3d/INaviTask;-><init>(Lcom/thinkware/sundo/inavi3d/INaviTask$iINaviTaskInterFace;ZZ)V

    new-array v1, v2, [Ljava/lang/Object;

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    aput-object v2, v1, v3

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/inavi3d/INaviTask;->execute([Ljava/lang/Object;)Landroid/os/AsyncTask;

    .line 2292
    return-void
.end method

.method public DoSearch()V
    .locals 4

    .prologue
    const/4 v3, 0x0

    const/4 v2, 0x1

    .line 2420
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strQuery:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    if-ge v0, v2, :cond_0

    .line 2456
    :goto_0
    return-void

    .line 2424
    :cond_0
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strQuery:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strQuery:Ljava/lang/String;

    .line 2427
    iput-boolean v3, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bSearchTimeCheck:Z

    .line 2430
    invoke-static {v2}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->USSetSubFacilityMerge(Z)V

    .line 2433
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strQuery:Ljava/lang/String;

    const-string v1, " "

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-ne v0, v2, :cond_1

    .line 2435
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strQuery:Ljava/lang/String;

    invoke-virtual {p0, v0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->IsIncludeAdminName(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_1

    .line 2436
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strQuery:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strQuery:Ljava/lang/String;

    .line 2440
    :cond_1
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strQuery:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->toUpperCase()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strQuery:Ljava/lang/String;

    .line 2442
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strQuery:Ljava/lang/String;

    invoke-static {v0}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->USSetQuery(Ljava/lang/String;)V

    .line 2446
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_SearchOption:Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;

    invoke-static {v0}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->USSetSearchOption(Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;)V

    .line 2449
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mUnitedSearchTask:Lcom/thinkware/sundo/inavi3d/INaviTask;

    if-eqz v0, :cond_2

    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mUnitedSearchTask:Lcom/thinkware/sundo/inavi3d/INaviTask;

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/INaviTask;->isFinished()Z

    move-result v0

    if-eqz v0, :cond_3

    .line 2450
    :cond_2
    const/4 v0, 0x0

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mUnitedSearchTask:Lcom/thinkware/sundo/inavi3d/INaviTask;

    .line 2451
    new-instance v0, Lcom/thinkware/sundo/inavi3d/INaviTask;

    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mUnitedSearchTaskInterFace:Lcom/thinkware/sundo/inavi3d/INaviTask$iINaviTaskInterFace;

    invoke-direct {v0, v1, v2, v2}, Lcom/thinkware/sundo/inavi3d/INaviTask;-><init>(Lcom/thinkware/sundo/inavi3d/INaviTask$iINaviTaskInterFace;ZZ)V

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mUnitedSearchTask:Lcom/thinkware/sundo/inavi3d/INaviTask;

    .line 2452
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mUnitedSearchTask:Lcom/thinkware/sundo/inavi3d/INaviTask;

    new-array v1, v3, [Ljava/lang/Object;

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/inavi3d/INaviTask;->execute([Ljava/lang/Object;)Landroid/os/AsyncTask;

    goto :goto_0

    .line 2454
    :cond_3
    const-string v0, "inavi3d_bona"

    const-string v1, "DoSearch Fail reason - already run"

    invoke-static {v0, v1}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_0
.end method

.method public IsAdminName(Ljava/lang/String;)Z
    .locals 2
    .param p1, "strName"    # Ljava/lang/String;

    .prologue
    .line 678
    invoke-virtual {p1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v1

    .line 681
    .local v1, "strAdmin":Ljava/lang/String;
    const/4 v0, 0x0

    .line 682
    .local v0, "bRet":Z
    invoke-static {v1}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->USIsAdminName(Ljava/lang/String;)Z

    move-result v0

    .line 684
    return v0
.end method

.method public IsEnableSearchBtn()Z
    .locals 1

    .prologue
    .line 2613
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mBtnSearch:Landroid/widget/ImageButton;

    invoke-virtual {v0}, Landroid/widget/ImageButton;->isEnabled()Z

    move-result v0

    return v0
.end method

.method public IsEnableSpaceBtn()Z
    .locals 2

    .prologue
    const/4 v0, 0x0

    .line 2620
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    invoke-virtual {v1}, Landroid/widget/EditText;->length()I

    move-result v1

    if-gtz v1, :cond_1

    .line 2629
    :cond_0
    :goto_0
    return v0

    .line 2624
    :cond_1
    iget-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bIsExistSpaceInKeyword:Z

    if-eqz v1, :cond_2

    iget-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bLiveSrch:Z

    if-eqz v1, :cond_0

    .line 2629
    :cond_2
    const/4 v0, 0x1

    goto :goto_0
.end method

.method public IsIncludeAdminName(Ljava/lang/String;)Z
    .locals 5
    .param p1, "strQuery"    # Ljava/lang/String;

    .prologue
    const/4 v3, 0x0

    .line 662
    const/4 v0, -0x1

    .line 663
    .local v0, "idxBlank":I
    const-string v4, " "

    invoke-virtual {p1, v4}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result v0

    .line 664
    if-gez v0, :cond_1

    .line 672
    :cond_0
    :goto_0
    return v3

    .line 666
    :cond_1
    invoke-virtual {p1, v3, v0}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v1

    .line 667
    .local v1, "strName1":Ljava/lang/String;
    add-int/lit8 v4, v0, 0x1

    invoke-virtual {p1, v4}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v2

    .line 669
    .local v2, "strName2":Ljava/lang/String;
    invoke-virtual {p0, v1}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->IsAdminName(Ljava/lang/String;)Z

    move-result v4

    if-nez v4, :cond_2

    invoke-virtual {p0, v2}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->IsAdminName(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_0

    .line 672
    :cond_2
    const/4 v3, 0x1

    goto :goto_0
.end method

.method public IsValidQuery(Ljava/lang/String;)Z
    .locals 10
    .param p1, "strQuery"    # Ljava/lang/String;

    .prologue
    const/4 v7, 0x1

    const/4 v9, 0x2

    .line 693
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v4

    .line 695
    .local v4, "nLen":I
    const/4 v1, 0x0

    .line 696
    .local v1, "nChoCnt":I
    const/4 v3, 0x0

    .line 697
    .local v3, "nHanCnt":I
    const/4 v2, 0x0

    .line 699
    .local v2, "nEngNumCnt":I
    const/4 v6, 0x0

    .local v6, "oo":I
    :goto_0
    if-ge v6, v4, :cond_6

    .line 701
    invoke-virtual {p1, v6}, Ljava/lang/String;->charAt(I)C

    move-result v0

    .line 702
    .local v0, "ch":C
    const/16 v8, 0x30

    if-gt v8, v0, :cond_1

    const/16 v8, 0x3a

    if-gt v0, v8, :cond_1

    .line 703
    add-int/lit8 v2, v2, 0x1

    .line 699
    :cond_0
    :goto_1
    add-int/lit8 v6, v6, 0x1

    goto :goto_0

    .line 704
    :cond_1
    const/16 v8, 0x41

    if-gt v8, v0, :cond_2

    const/16 v8, 0x5a

    if-le v0, v8, :cond_3

    :cond_2
    const/16 v8, 0x61

    if-gt v8, v0, :cond_4

    const/16 v8, 0x7a

    if-gt v0, v8, :cond_4

    .line 705
    :cond_3
    add-int/lit8 v2, v2, 0x1

    goto :goto_1

    .line 706
    :cond_4
    const/16 v8, 0x3131

    if-gt v8, v0, :cond_5

    const/16 v8, 0x314e

    if-gt v0, v8, :cond_5

    .line 707
    add-int/lit8 v1, v1, 0x1

    goto :goto_1

    .line 710
    :cond_5
    move v5, v0

    .line 711
    .local v5, "nVal":I
    const v8, 0xac00

    if-gt v8, v5, :cond_0

    const v8, 0xd7a3

    if-gt v5, v8, :cond_0

    .line 712
    add-int/lit8 v3, v3, 0x1

    goto :goto_1

    .line 716
    .end local v0    # "ch":C
    .end local v5    # "nVal":I
    :cond_6
    if-ge v2, v9, :cond_7

    if-ge v1, v9, :cond_7

    if-ge v3, v7, :cond_7

    add-int v8, v2, v1

    if-lt v8, v9, :cond_8

    .line 719
    :cond_7
    :goto_2
    return v7

    :cond_8
    const/4 v7, 0x0

    goto :goto_2
.end method

.method ReadyLiveSearchAgreePopup()V
    .locals 6

    .prologue
    const v5, 0x7f030055

    .line 1683
    new-instance v1, Lcom/thinkware/sundo/inavi3d/ui/popup/InaviPopup;

    const-string v2, ""

    const-string v3, ""

    const/4 v4, 0x0

    invoke-direct {v1, p0, v2, v3, v4}, Lcom/thinkware/sundo/inavi3d/ui/popup/InaviPopup;-><init>(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;I)V

    iput-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mLiveAgreeDialog:Landroid/app/Dialog;

    .line 1684
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v1

    invoke-virtual {v1}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->is_support_scale()Z

    move-result v1

    if-eqz v1, :cond_0

    .line 1685
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mLiveAgreeDialog:Landroid/app/Dialog;

    invoke-virtual {v1, v5}, Landroid/app/Dialog;->setContentView(I)V

    .line 1686
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INaviScaleManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INaviScaleManager;

    move-result-object v1

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mLiveAgreeDialog:Landroid/app/Dialog;

    const v3, 0x7f0a0292

    invoke-virtual {v2, v3}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/thinkware/sundo/inavi3d/INaviScaleManager;->scaleOnceDialog(Landroid/view/View;)V

    .line 1691
    :goto_0
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mLiveAgreeDialog:Landroid/app/Dialog;

    const v2, 0x7f0a00c1

    invoke-virtual {v1, v2}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    .line 1692
    .local v0, "Title":Landroid/widget/TextView;
    const-string v1, "\uc544\uc774\ub098\ube44 Live \uc11c\ube44\uc2a4 \uc57d\uad00 \ub3d9\uc758"

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1694
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mLiveAgreeDialog:Landroid/app/Dialog;

    const v2, 0x7f0a0313

    invoke-virtual {v1, v2}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    new-instance v2, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$12;

    invoke-direct {v2, p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$12;-><init>(Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;)V

    invoke-virtual {v1, v2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 1708
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mLiveAgreeDialog:Landroid/app/Dialog;

    const v2, 0x7f0a030d

    invoke-virtual {v1, v2}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    new-instance v2, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$13;

    invoke-direct {v2, p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$13;-><init>(Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;)V

    invoke-virtual {v1, v2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 1719
    return-void

    .line 1688
    .end local v0    # "Title":Landroid/widget/TextView;
    :cond_0
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mLiveAgreeDialog:Landroid/app/Dialog;

    invoke-virtual {v1, v5}, Landroid/app/Dialog;->setContentView(I)V

    goto :goto_0
.end method

.method ReadyPreAreaNameSearch()V
    .locals 5

    .prologue
    .line 1583
    new-instance v1, Lcom/thinkware/sundo/inavi3d/ui/popup/InaviPopup;

    const-string v2, ""

    const-string v3, ""

    const/4 v4, 0x0

    invoke-direct {v1, p0, v2, v3, v4}, Lcom/thinkware/sundo/inavi3d/ui/popup/InaviPopup;-><init>(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;I)V

    iput-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mAdminDlg:Landroid/app/Dialog;

    .line 1584
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mAdminDlg:Landroid/app/Dialog;

    const v2, 0x7f030054

    invoke-virtual {v1, v2}, Landroid/app/Dialog;->setContentView(I)V

    .line 1585
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v1

    invoke-virtual {v1}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->is_support_scale()Z

    move-result v1

    if-eqz v1, :cond_0

    .line 1586
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INaviScaleManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INaviScaleManager;

    move-result-object v1

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mAdminDlg:Landroid/app/Dialog;

    const v3, 0x7f0a0292

    invoke-virtual {v2, v3}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/thinkware/sundo/inavi3d/INaviScaleManager;->scaleOnceDialog(Landroid/view/View;)V

    .line 1590
    :cond_0
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mAdminDlg:Landroid/app/Dialog;

    const v2, 0x7f0a0310

    invoke-virtual {v1, v2}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/ListView;

    iput-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->lstPopup:Landroid/widget/ListView;

    .line 1591
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->lstPopup:Landroid/widget/ListView;

    const/4 v2, 0x1

    invoke-virtual {v1, v2}, Landroid/widget/ListView;->setChoiceMode(I)V

    .line 1593
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mAdminDlg:Landroid/app/Dialog;

    const v2, 0x7f0a00c1

    invoke-virtual {v1, v2}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    .line 1594
    .local v0, "Title":Landroid/widget/TextView;
    const-string v1, "\uac80\uc0c9 \uc9c0\uc5ed \uc120\ud0dd"

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1596
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mAdminDlg:Landroid/app/Dialog;

    const v2, 0x7f0a030d

    invoke-virtual {v1, v2}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    new-instance v2, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$10;

    invoke-direct {v2, p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$10;-><init>(Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;)V

    invoke-virtual {v1, v2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 1605
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->arrPopupData:Ljava/util/ArrayList;

    .line 1606
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->arrPopupString:Ljava/util/ArrayList;

    .line 1607
    new-instance v1, Lcom/thinkware/sundo/inavi3d/ui/adapter/CustomAdapter$CustumRadioItemAdapter;

    const v2, 0x7f030050

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->arrPopupString:Ljava/util/ArrayList;

    invoke-direct {v1, p0, v2, v3}, Lcom/thinkware/sundo/inavi3d/ui/adapter/CustomAdapter$CustumRadioItemAdapter;-><init>(Landroid/content/Context;ILjava/util/ArrayList;)V

    iput-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->adtPopupString:Lcom/thinkware/sundo/inavi3d/ui/adapter/CustomAdapter$CustumRadioItemAdapter;

    .line 1608
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->lstPopup:Landroid/widget/ListView;

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->adtPopupString:Lcom/thinkware/sundo/inavi3d/ui/adapter/CustomAdapter$CustumRadioItemAdapter;

    invoke-virtual {v1, v2}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    .line 1609
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->lstPopup:Landroid/widget/ListView;

    new-instance v2, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$11;

    invoke-direct {v2, p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$11;-><init>(Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;)V

    invoke-virtual {v1, v2}, Landroid/widget/ListView;->setOnItemClickListener(Landroid/widget/AdapterView$OnItemClickListener;)V

    .line 1679
    return-void
.end method

.method public ShowPopupNoResult()V
    .locals 4

    .prologue
    .line 1756
    const/16 v0, 0x30

    const-string v1, "\uc54c\ub9bc"

    const-string v2, "\uac80\uc0c9 \uacb0\uacfc\uac00 \uc5c6\uc2b5\ub2c8\ub2e4.\n\uac80\uc0c9 \uc870\uac74\uc744 \ud655\uc778\ud574 \uc8fc\uc2ed\uc2dc\uc624."

    const/4 v3, 0x0

    invoke-static {v0, p0, v1, v2, v3}, Lcom/thinkware/sundo/inavi3d/ui/popup/PopupManager;->ShowPopup(ILandroid/content/Context;Ljava/lang/String;Ljava/lang/String;I)Lcom/thinkware/sundo/inavi3d/ui/popup/InaviPopup;

    .line 1759
    return-void
.end method

.method public ShowPopupNotify()V
    .locals 5

    .prologue
    .line 1724
    const/16 v1, 0x20

    const-string v2, "\uc54c\ub9bc"

    const-string v3, "\uac80\uc0c9 \uacb0\uacfc\uac00 \uc5c6\uc2b5\ub2c8\ub2e4.\n\uac80\uc0c9\uc5b4 \ub610\ub294 \uc9c0\uc5ed\uc124\uc815\uc744 \ud655\uc778\ud574\n\uc8fc\uc2ed\uc2dc\uc624."

    const/4 v4, 0x0

    invoke-static {v1, p0, v2, v3, v4}, Lcom/thinkware/sundo/inavi3d/ui/popup/PopupManager;->ShowPopup(ILandroid/content/Context;Ljava/lang/String;Ljava/lang/String;I)Lcom/thinkware/sundo/inavi3d/ui/popup/InaviPopup;

    move-result-object v0

    .line 1728
    .local v0, "popup2":Lcom/thinkware/sundo/inavi3d/ui/popup/InaviPopup;
    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/ui/popup/InaviPopup;->getOkButton()Landroid/widget/Button;

    move-result-object v1

    const-string v2, "\uc804\uad6d\uc73c\ub85c \uac80\uc0c9"

    invoke-virtual {v1, v2}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 1729
    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/ui/popup/InaviPopup;->getCancleButton()Landroid/widget/Button;

    move-result-object v1

    const-string v2, "\ucde8\uc18c"

    invoke-virtual {v1, v2}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 1730
    new-instance v1, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$14;

    invoke-direct {v1, p0, v0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$14;-><init>(Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;Lcom/thinkware/sundo/inavi3d/ui/popup/InaviPopup;)V

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/inavi3d/ui/popup/InaviPopup;->SetokListner(Landroid/view/View$OnClickListener;)Z

    .line 1744
    new-instance v1, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$15;

    invoke-direct {v1, p0, v0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$15;-><init>(Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;Lcom/thinkware/sundo/inavi3d/ui/popup/InaviPopup;)V

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/inavi3d/ui/popup/InaviPopup;->SetcancleListner(Landroid/view/View$OnClickListener;)Z

    .line 1750
    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/ui/popup/InaviPopup;->show()V

    .line 1751
    return-void
.end method

.method public doUnitedSearch()V
    .locals 7

    .prologue
    const/16 v6, 0x1773

    const/4 v5, 0x1

    const/4 v4, 0x0

    .line 2103
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mBtnErase:Landroid/widget/Button;

    invoke-virtual {v1, v4}, Landroid/widget/Button;->setClickable(Z)V

    .line 2105
    new-instance v0, Landroid/os/Handler;

    invoke-direct {v0}, Landroid/os/Handler;-><init>()V

    .line 2106
    .local v0, "h":Landroid/os/Handler;
    new-instance v1, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$AntiClickhandler;

    invoke-direct {v1, p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$AntiClickhandler;-><init>(Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;)V

    const-wide/16 v2, 0x3e8

    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 2110
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    invoke-virtual {v1}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    iput-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strQuery:Ljava/lang/String;

    .line 2112
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strQuery:Ljava/lang/String;

    const-string v2, "##\ub85c\uae45\uc2dc\uc791"

    invoke-virtual {v1, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_0

    .line 2113
    sget-object v1, Lcom/thinkware/sundo/inavi3d/GpsLogDriver;->mPath:Ljava/io/File;

    invoke-virtual {v1}, Ljava/io/File;->mkdir()Z

    .line 2114
    const-string v1, ""

    invoke-static {v6, v5, v1}, Lcom/thinkware/sundo/inavi3d/Inavi;->ProcessMessage(IILjava/lang/String;)I

    .line 2115
    const-string v1, "\ub85c\uae45\uc2dc\uc791 (/storage/emulated/0/inavi3d/gpslog/)"

    invoke-static {p0, v1, v5}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v1

    invoke-virtual {v1}, Landroid/widget/Toast;->show()V

    .line 2116
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strQuery:Ljava/lang/String;

    invoke-static {v1, v4}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->USSetQueryHistory(Ljava/lang/String;I)V

    .line 2144
    :goto_0
    return-void

    .line 2119
    :cond_0
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strQuery:Ljava/lang/String;

    const-string v2, "##\ub85c\uae45\uc911\ub2e8"

    invoke-virtual {v1, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_1

    .line 2120
    sget-object v1, Lcom/thinkware/sundo/inavi3d/GpsLogDriver;->mPath:Ljava/io/File;

    invoke-virtual {v1}, Ljava/io/File;->mkdir()Z

    .line 2121
    const-string v1, ""

    invoke-static {v6, v4, v1}, Lcom/thinkware/sundo/inavi3d/Inavi;->ProcessMessage(IILjava/lang/String;)I

    .line 2122
    const-string v1, "\ub85c\uae45\uc911\ub2e8 (/storage/emulated/0/inavi3d/gpslog/)"

    invoke-static {p0, v1, v5}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v1

    invoke-virtual {v1}, Landroid/widget/Toast;->show()V

    .line 2123
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strQuery:Ljava/lang/String;

    invoke-static {v1, v4}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->USSetQueryHistory(Ljava/lang/String;I)V

    goto :goto_0

    .line 2126
    :cond_1
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strQuery:Ljava/lang/String;

    const-string v2, "##\uc8fc\ucc28\uc7a5\uc2dc\uc791"

    invoke-virtual {v1, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_2

    .line 2127
    const/16 v1, 0x1775

    const-string v2, ""

    invoke-static {v1, v4, v2}, Lcom/thinkware/sundo/inavi3d/Inavi;->ProcessMessage(IILjava/lang/String;)I

    .line 2128
    const-string v1, "\uc9c0\ud558\uc8fc\ucc28\uc7a5 \uc9c4\uc785\ub370\uc774\ud130 \ubc84\ud2bc \ud65c\uc131\ud654!!"

    invoke-static {p0, v1, v5}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v1

    invoke-virtual {v1}, Landroid/widget/Toast;->show()V

    goto :goto_0

    .line 2131
    :cond_2
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strQuery:Ljava/lang/String;

    const-string v2, "##\uc8fc\ucc28\uc7a5\uc885\ub8cc"

    invoke-virtual {v1, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_3

    .line 2132
    const/16 v1, 0x1776

    const-string v2, ""

    invoke-static {v1, v4, v2}, Lcom/thinkware/sundo/inavi3d/Inavi;->ProcessMessage(IILjava/lang/String;)I

    .line 2133
    const-string v1, "\uc9c0\ud558\uc8fc\ucc28\uc7a5 \uc9c4\uc785\ub370\uc774\ud130 \ubc84\ud2bc \ube44\ud65c\uc131\ud654!!"

    invoke-static {p0, v1, v5}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v1

    invoke-virtual {v1}, Landroid/widget/Toast;->show()V

    goto :goto_0

    .line 2138
    :cond_3
    iput-boolean v4, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bReSrch:Z

    .line 2140
    iget-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bLiveSrch:Z

    if-eqz v1, :cond_4

    .line 2141
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->DoLiveSearch()V

    goto :goto_0

    .line 2143
    :cond_4
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->DoSearch()V

    goto :goto_0
.end method

.method enableRegionBtn(Z)V
    .locals 2
    .param p1, "enabled"    # Z

    .prologue
    .line 334
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mBtnSetRegion:Landroid/widget/Button;

    invoke-virtual {v0, p1}, Landroid/widget/Button;->setEnabled(Z)V

    .line 335
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mBtnSetRegion:Landroid/widget/Button;

    invoke-virtual {v0, p1}, Landroid/widget/Button;->setClickable(Z)V

    .line 336
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mBtnSetRegion:Landroid/widget/Button;

    if-eqz p1, :cond_0

    const/4 v0, -0x1

    :goto_0
    invoke-virtual {v1, v0}, Landroid/widget/Button;->setTextColor(I)V

    .line 337
    return-void

    .line 336
    :cond_0
    const v0, -0x777778

    goto :goto_0
.end method

.method public finish()V
    .locals 4

    .prologue
    const/4 v3, 0x0

    .line 1874
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_SearchOption:Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;

    invoke-static {v0}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->USSetSearchOption(Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;)V

    .line 1875
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->USSaveSearchingOption()V

    .line 1877
    const-string v0, "HYO"

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "HYO USSaveSearchingOption()admincode="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_SearchOption:Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;

    iget v2, v2, Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;->m_nAdminCode:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/thinkware/sundo/inavi3d/LOGTW;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 1879
    invoke-super {p0}, Lcom/thinkware/sundo/inavi3d/MainActivity;->finish()V

    .line 1880
    invoke-virtual {p0, v3, v3}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->overridePendingTransition(II)V

    .line 1881
    return-void
.end method

.method protected getContentViewId()I
    .locals 1

    .prologue
    .line 2607
    const v0, 0x7f0a026e

    return v0
.end method

.method public getOffsetForPosition(Landroid/widget/EditText;FF)I
    .locals 3
    .param p1, "textView"    # Landroid/widget/EditText;
    .param p2, "x"    # F
    .param p3, "y"    # F

    .prologue
    .line 725
    invoke-virtual {p1}, Landroid/widget/EditText;->getLayout()Landroid/text/Layout;

    move-result-object v2

    if-nez v2, :cond_0

    .line 726
    const/4 v1, -0x1

    .line 730
    :goto_0
    return v1

    .line 728
    :cond_0
    invoke-direct {p0, p1, p3}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->getLineAtCoordinate(Landroid/widget/EditText;F)I

    move-result v0

    .line 729
    .local v0, "line":I
    invoke-direct {p0, p1, v0, p2}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->getOffsetAtCoordinate(Landroid/widget/EditText;IF)I

    move-result v1

    .line 730
    .local v1, "offset":I
    goto :goto_0
.end method

.method protected onActivityResult(IILandroid/content/Intent;)V
    .locals 6
    .param p1, "requestCode"    # I
    .param p2, "resultCode"    # I
    .param p3, "data"    # Landroid/content/Intent;

    .prologue
    const/4 v3, -0x1

    const/4 v5, 0x1

    const/4 v4, 0x0

    .line 2460
    packed-switch p1, :pswitch_data_0

    .line 2550
    :cond_0
    :goto_0
    :pswitch_0
    return-void

    .line 2463
    :pswitch_1
    if-ne p2, v3, :cond_0

    .line 2465
    const-string v3, "SearchData"

    invoke-virtual {p3, v3}, Landroid/content/Intent;->getSerializableExtra(Ljava/lang/String;)Ljava/io/Serializable;

    move-result-object v3

    check-cast v3, Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;

    iput-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_SearchOption:Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;

    .line 2467
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_SearchOption:Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;

    invoke-static {v3}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->USSetSearchOption(Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;)V

    .line 2469
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->setSearchOption()V

    goto :goto_0

    .line 2476
    :pswitch_2
    if-ne p2, v3, :cond_0

    .line 2477
    new-instance v2, Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;

    invoke-direct {v2}, Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;-><init>()V

    .line 2478
    .local v2, "tempOption":Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;
    const-string v3, "SearchData"

    invoke-virtual {p3, v3}, Landroid/content/Intent;->getSerializableExtra(Ljava/lang/String;)Ljava/io/Serializable;

    move-result-object v2

    .end local v2    # "tempOption":Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;
    check-cast v2, Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;

    .line 2480
    .restart local v2    # "tempOption":Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strQuery:Ljava/lang/String;

    iput-object v3, v2, Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;->m_strQuery:Ljava/lang/String;

    .line 2482
    invoke-static {v2}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->USSetSearchOption(Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;)V

    .line 2483
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->USRunSanghoSearch()I

    move-result v1

    .line 2484
    .local v1, "nRet":I
    sget v3, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->RET_SEARCH_OK:I

    if-ne v1, v3, :cond_4

    .line 2485
    invoke-static {v5}, Lcom/thinkware/sundo/inavi3d/Inavi;->setULogSearch(Z)V

    .line 2489
    :cond_1
    :goto_1
    sget v3, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->RET_SEARCH_OK:I

    if-ne v1, v3, :cond_5

    .line 2492
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v3

    invoke-virtual {v3}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->supportRecommendedWord()Z

    move-result v3

    if-eqz v3, :cond_2

    .line 2493
    invoke-direct {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->hideRecommendedWord()V

    .line 2494
    :cond_2
    new-instance v0, Landroid/content/Intent;

    const-class v3, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchResultActivity;

    invoke-direct {v0, p0, v3}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 2498
    .local v0, "intent":Landroid/content/Intent;
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_SearchOption:Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;

    iget v3, v3, Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;->m_nAdminCode:I

    if-nez v3, :cond_3

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_SearchOption:Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;

    iget v3, v3, Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;->m_nOption:I

    if-nez v3, :cond_3

    .line 2500
    const-string v3, "RegionAll"

    invoke-virtual {v0, v3, v5}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 2501
    const-string v3, "HYO"

    const-string v4, "HYO region all == 1"

    invoke-static {v3, v4}, Lcom/thinkware/sundo/inavi3d/LOGTW;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 2505
    :cond_3
    const-string v3, "mode"

    iget v4, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mode:I

    invoke-virtual {v0, v3, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 2507
    const/16 v3, 0x3eb

    invoke-virtual {p0, v0, v3}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->startActivityForResult(Landroid/content/Intent;I)V

    goto :goto_0

    .line 2486
    .end local v0    # "intent":Landroid/content/Intent;
    :cond_4
    sget v3, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->RET_SEARCH_FAIL:I

    if-ne v1, v3, :cond_1

    .line 2487
    invoke-static {v4}, Lcom/thinkware/sundo/inavi3d/Inavi;->setULogSearch(Z)V

    goto :goto_1

    .line 2512
    :cond_5
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_SearchOption:Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;

    iget v3, v3, Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;->m_nAdminCode:I

    if-nez v3, :cond_6

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_SearchOption:Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;

    iget v3, v3, Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;->m_nOption:I

    if-ne v3, v5, :cond_7

    .line 2513
    :cond_6
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->ShowPopupNotify()V

    goto/16 :goto_0

    .line 2515
    :cond_7
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->ShowPopupNoResult()V

    goto/16 :goto_0

    .line 2523
    .end local v1    # "nRet":I
    .end local v2    # "tempOption":Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;
    :pswitch_3
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strQuery:Ljava/lang/String;

    invoke-static {v3, v4}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->USSetQueryHistory(Ljava/lang/String;I)V

    .line 2524
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v3

    invoke-virtual {v3}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->supportRecommendedWord()Z

    move-result v3

    if-nez v3, :cond_8

    .line 2525
    invoke-direct {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->loadQueryHistory()V

    .line 2529
    :cond_8
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    invoke-virtual {v3}, Landroid/widget/EditText;->selectAll()V

    .line 2530
    const-string v3, "HYO"

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "EditText SetSelection!!"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    iget-object v5, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    invoke-virtual {v5}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v3, v4}, Lcom/thinkware/sundo/inavi3d/LOGTW;->d(Ljava/lang/String;Ljava/lang/String;)V

    goto/16 :goto_0

    .line 2537
    :pswitch_4
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strQuery:Ljava/lang/String;

    invoke-static {v3, v4}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->USSetQueryHistory(Ljava/lang/String;I)V

    .line 2538
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v3

    invoke-virtual {v3}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->supportRecommendedWord()Z

    move-result v3

    if-nez v3, :cond_9

    .line 2539
    invoke-direct {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->loadQueryHistory()V

    .line 2543
    :cond_9
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    invoke-virtual {v3}, Landroid/widget/EditText;->selectAll()V

    .line 2544
    const-string v3, "HYO"

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "EditText SetSelection!!"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    iget-object v5, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    invoke-virtual {v5}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v3, v4}, Lcom/thinkware/sundo/inavi3d/LOGTW;->d(Ljava/lang/String;Ljava/lang/String;)V

    goto/16 :goto_0

    .line 2460
    :pswitch_data_0
    .packed-switch 0x3e9
        :pswitch_1
        :pswitch_2
        :pswitch_3
        :pswitch_0
        :pswitch_4
    .end packed-switch
.end method

.method public onCheckedChanged(Landroid/widget/RadioGroup;I)V
    .locals 0
    .param p1, "arg0"    # Landroid/widget/RadioGroup;
    .param p2, "arg1"    # I

    .prologue
    .line 2554
    return-void
.end method

.method public onClick(Landroid/view/View;)V
    .locals 12
    .param p1, "v"    # Landroid/view/View;

    .prologue
    const/16 v11, 0x11b

    const/high16 v10, 0x41f00000    # 30.0f

    const/high16 v7, 0x41d00000    # 26.0f

    const/4 v8, 0x1

    const/4 v9, 0x0

    .line 1888
    invoke-virtual {p1}, Landroid/view/View;->getId()I

    move-result v6

    sparse-switch v6, :sswitch_data_0

    .line 2068
    :cond_0
    :goto_0
    return-void

    .line 1892
    :sswitch_0
    iget-object v6, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabUnited:Landroid/widget/Button;

    invoke-virtual {v6, v9}, Landroid/widget/Button;->setSelected(Z)V

    .line 1893
    iget-object v6, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabUnited:Landroid/widget/Button;

    invoke-virtual {v6, v9, v7}, Landroid/widget/Button;->setTextSize(IF)V

    .line 1894
    iget-object v6, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabName:Landroid/widget/Button;

    invoke-virtual {v6, v8}, Landroid/widget/Button;->setSelected(Z)V

    .line 1895
    iget-object v6, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabName:Landroid/widget/Button;

    invoke-virtual {v6, v9, v10}, Landroid/widget/Button;->setTextSize(IF)V

    .line 1896
    iget-object v6, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabName:Landroid/widget/Button;

    invoke-virtual {v6}, Landroid/widget/Button;->postInvalidate()V

    .line 1897
    invoke-direct {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->tabButtonDesable()V

    .line 1898
    new-instance v0, Landroid/content/Intent;

    const-class v6, Lcom/thinkware/sundo/inavi3d/ui/NameSearchActivity;

    invoke-direct {v0, p0, v6}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 1900
    .local v0, "intent":Landroid/content/Intent;
    const-string v6, "mode"

    iget v7, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mode:I

    invoke-virtual {v0, v6, v7}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 1904
    new-instance v1, Landroid/content/Intent;

    const-class v6, Lcom/thinkware/sundo/inavi3d/INavi3DActivity;

    invoke-direct {v1, p0, v6}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 1905
    .local v1, "mapIntent":Landroid/content/Intent;
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    move-result-object v6

    invoke-virtual {v6, p0, v1, v0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->startActivityToMap(Landroid/content/Context;Landroid/content/Intent;Landroid/content/Intent;)V

    .line 1906
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    move-result-object v6

    const/4 v7, 0x0

    invoke-virtual {v6, p0, v7}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->tabButtonClearTop(Landroid/content/Context;Landroid/content/Intent;)V

    goto :goto_0

    .line 1910
    .end local v0    # "intent":Landroid/content/Intent;
    .end local v1    # "mapIntent":Landroid/content/Intent;
    :sswitch_1
    iget-object v6, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabUnited:Landroid/widget/Button;

    invoke-virtual {v6, v9}, Landroid/widget/Button;->setSelected(Z)V

    .line 1911
    iget-object v6, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabUnited:Landroid/widget/Button;

    invoke-virtual {v6, v9, v7}, Landroid/widget/Button;->setTextSize(IF)V

    .line 1912
    iget-object v6, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabAddr:Landroid/widget/Button;

    invoke-virtual {v6, v8}, Landroid/widget/Button;->setSelected(Z)V

    .line 1913
    iget-object v6, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabAddr:Landroid/widget/Button;

    invoke-virtual {v6, v9, v10}, Landroid/widget/Button;->setTextSize(IF)V

    .line 1914
    iget-object v6, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabAddr:Landroid/widget/Button;

    invoke-virtual {v6}, Landroid/widget/Button;->postInvalidate()V

    .line 1915
    invoke-direct {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->tabButtonDesable()V

    .line 1916
    new-instance v0, Landroid/content/Intent;

    const-class v6, Lcom/thinkware/sundo/inavi3d/ui/AddressSearch;

    invoke-direct {v0, p0, v6}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 1918
    .restart local v0    # "intent":Landroid/content/Intent;
    const-string v6, "mode"

    iget v7, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mode:I

    invoke-virtual {v0, v6, v7}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 1920
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    move-result-object v6

    invoke-virtual {v6, p0, v0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->tabButtonClearTop(Landroid/content/Context;Landroid/content/Intent;)V

    goto :goto_0

    .line 1923
    .end local v0    # "intent":Landroid/content/Intent;
    :sswitch_2
    iget-object v6, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabUnited:Landroid/widget/Button;

    invoke-virtual {v6, v9}, Landroid/widget/Button;->setSelected(Z)V

    .line 1924
    iget-object v6, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabUnited:Landroid/widget/Button;

    invoke-virtual {v6, v9, v7}, Landroid/widget/Button;->setTextSize(IF)V

    .line 1925
    iget-object v6, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabAround:Landroid/widget/Button;

    invoke-virtual {v6, v8}, Landroid/widget/Button;->setSelected(Z)V

    .line 1926
    iget-object v6, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabAround:Landroid/widget/Button;

    invoke-virtual {v6, v9, v10}, Landroid/widget/Button;->setTextSize(IF)V

    .line 1927
    iget-object v6, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabAround:Landroid/widget/Button;

    invoke-virtual {v6}, Landroid/widget/Button;->postInvalidate()V

    .line 1928
    invoke-direct {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->tabButtonDesable()V

    .line 1929
    new-instance v0, Landroid/content/Intent;

    const-class v6, Lcom/thinkware/sundo/inavi3d/ui/AroundSrchActivity;

    invoke-direct {v0, p0, v6}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 1931
    .restart local v0    # "intent":Landroid/content/Intent;
    const-string v6, "mode"

    iget v7, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mode:I

    invoke-virtual {v0, v6, v7}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 1933
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    move-result-object v6

    invoke-virtual {v6, p0, v0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->tabButtonClearTop(Landroid/content/Context;Landroid/content/Intent;)V

    goto/16 :goto_0

    .line 1936
    .end local v0    # "intent":Landroid/content/Intent;
    :sswitch_3
    iget-object v6, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabUnited:Landroid/widget/Button;

    invoke-virtual {v6, v9}, Landroid/widget/Button;->setSelected(Z)V

    .line 1937
    iget-object v6, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabUnited:Landroid/widget/Button;

    invoke-virtual {v6, v9, v7}, Landroid/widget/Button;->setTextSize(IF)V

    .line 1938
    iget-object v6, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabICode:Landroid/widget/Button;

    invoke-virtual {v6, v8}, Landroid/widget/Button;->setSelected(Z)V

    .line 1939
    iget-object v6, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabICode:Landroid/widget/Button;

    invoke-virtual {v6, v9, v10}, Landroid/widget/Button;->setTextSize(IF)V

    .line 1940
    iget-object v6, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabICode:Landroid/widget/Button;

    invoke-virtual {v6}, Landroid/widget/Button;->postInvalidate()V

    .line 1941
    invoke-direct {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->tabButtonDesable()V

    .line 1942
    new-instance v0, Landroid/content/Intent;

    const-class v6, Lcom/thinkware/sundo/inavi3d/ui/ICodeSearchActivity;

    invoke-direct {v0, p0, v6}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 1944
    .restart local v0    # "intent":Landroid/content/Intent;
    const-string v6, "mode"

    iget v7, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mode:I

    invoke-virtual {v0, v6, v7}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 1946
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;

    move-result-object v6

    invoke-virtual {v6, p0, v0}, Lcom/thinkware/sundo/inavi3d/INavi3DActivityManager;->tabButtonClearTop(Landroid/content/Context;Landroid/content/Intent;)V

    goto/16 :goto_0

    .line 1949
    .end local v0    # "intent":Landroid/content/Intent;
    :sswitch_4
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->searchClear()V

    goto/16 :goto_0

    .line 1955
    :sswitch_5
    iget-boolean v6, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bLiveSrch:Z

    if-eqz v6, :cond_1

    .line 1957
    iput-boolean v9, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bLiveSrch:Z

    .line 1961
    invoke-direct {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->EraseSpaceInEditText()V

    .line 1962
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->getInstance()Lcom/thinkware/sundo/inavi3d/InaviConfig;

    move-result-object v6

    invoke-virtual {v6, v11, v9}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->CNaviConfigSet(II)Z

    .line 1963
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->getInstance()Lcom/thinkware/sundo/inavi3d/InaviConfig;

    move-result-object v6

    invoke-virtual {v6}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->SetConfigSave()Z

    .line 1996
    :goto_1
    iget-object v6, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mBtnLive:Landroid/widget/Button;

    iget-boolean v7, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bLiveSrch:Z

    invoke-virtual {v6, v7}, Landroid/widget/Button;->setSelected(Z)V

    .line 1998
    iget-boolean v6, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bLiveSrch:Z

    if-eqz v6, :cond_4

    .line 2000
    invoke-virtual {p0, v9}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->enableRegionBtn(Z)V

    goto/16 :goto_0

    .line 1968
    :cond_1
    invoke-virtual {p0, v9}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->enableRegionBtn(Z)V

    .line 1973
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v6

    invoke-virtual {v6}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->supportRSearch()Z

    move-result v6

    if-eqz v6, :cond_3

    .line 1974
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/livesearch/LiveSearchManager;->getInstance()Lcom/thinkware/sundo/inavi3d/livesearch/LiveSearchManager;

    move-result-object v6

    invoke-virtual {v6}, Lcom/thinkware/sundo/inavi3d/livesearch/LiveSearchManager;->isAgreed()Z

    move-result v6

    iput-boolean v6, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bLiveSrch:Z

    .line 1975
    iget-boolean v6, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bLiveSrch:Z

    if-nez v6, :cond_2

    .line 1976
    invoke-direct {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->showLiveProvisionPopup()V

    .line 1993
    :cond_2
    :goto_2
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/ui/SIPModel;->getInstance()Lcom/thinkware/sundo/inavi3d/ui/SIPModel;

    move-result-object v6

    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->IsEnableSpaceBtn()Z

    move-result v7

    invoke-virtual {v6, v7}, Lcom/thinkware/sundo/inavi3d/ui/SIPModel;->setSpaceButtonEnable(Z)V

    .line 1994
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->getInstance()Lcom/thinkware/sundo/inavi3d/InaviConfig;

    move-result-object v6

    invoke-virtual {v6, v11, v8}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->CNaviConfigSet(II)Z

    goto :goto_1

    .line 1980
    :cond_3
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->USGetLiveTermAgreed()Z

    move-result v6

    iput-boolean v6, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bLiveSrch:Z

    .line 1981
    iget-boolean v6, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bLiveSrch:Z

    if-nez v6, :cond_2

    .line 1983
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->_USGetLiveTerms()Ljava/lang/String;

    move-result-object v4

    .line 1985
    .local v4, "temp":Ljava/lang/String;
    const-string v6, "\uae40 \uc9c4\ubc94"

    const-string v7, "\uc774 \ud765\ubcf5"

    invoke-virtual {v4, v6, v7}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v4

    .line 1986
    const-string v6, "\uc11c\uc6b8\uc2dc \uc11c\ucd08\uad6c \uc591\uc7ac\ub3d9 275-7 \ud2b8\ub7ec\uc2a4\ud2b8\ud0c0\uc6cc 22\uce35"

    const-string v7, "\uacbd\uae30 \uc131\ub0a8\uc2dc \ubd84\ub2f9\uad6c \uc0bc\ud3c9\ub3d9 678 \uc0bc\ud658\ud558\uc774\ud399\uc2a4 A\ub3d9 9F"

    invoke-virtual {v4, v6, v7}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v4

    .line 1987
    iget-object v6, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mLiveAgreeDialog:Landroid/app/Dialog;

    const v7, 0x7f0a0312

    invoke-virtual {v6, v7}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v5

    check-cast v5, Landroid/widget/TextView;

    .line 1988
    .local v5, "txtLiveTerm":Landroid/widget/TextView;
    invoke-virtual {v5, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1990
    iget-object v6, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mLiveAgreeDialog:Landroid/app/Dialog;

    invoke-virtual {v6}, Landroid/app/Dialog;->show()V

    goto :goto_2

    .line 2004
    .end local v4    # "temp":Ljava/lang/String;
    .end local v5    # "txtLiveTerm":Landroid/widget/TextView;
    :cond_4
    invoke-virtual {p0, v8}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->enableRegionBtn(Z)V

    .line 2005
    iget-object v6, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    invoke-virtual {v6}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v6

    iput-object v6, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strQuery:Ljava/lang/String;

    .line 2007
    iget-object v6, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strQuery:Ljava/lang/String;

    invoke-virtual {v6}, Ljava/lang/String;->length()I

    move-result v6

    if-lt v6, v8, :cond_0

    .line 2011
    iget-object v6, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strQuery:Ljava/lang/String;

    const-string v7, " "

    invoke-virtual {v6, v7}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v6

    if-ne v6, v8, :cond_0

    .line 2012
    iget-object v6, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strQuery:Ljava/lang/String;

    invoke-virtual {p0, v6}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->IsIncludeAdminName(Ljava/lang/String;)Z

    move-result v6

    if-nez v6, :cond_5

    .line 2013
    invoke-virtual {p0, v8}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->enableRegionBtn(Z)V

    goto/16 :goto_0

    .line 2015
    :cond_5
    invoke-virtual {p0, v9}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->enableRegionBtn(Z)V

    goto/16 :goto_0

    .line 2023
    :sswitch_6
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->doUnitedSearch()V

    goto/16 :goto_0

    .line 2029
    :sswitch_7
    iget-object v6, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mHelpDialog:Landroid/app/Dialog;

    invoke-virtual {v6}, Landroid/app/Dialog;->show()V

    goto/16 :goto_0

    .line 2035
    :sswitch_8
    iget-object v6, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mHelpDialog:Landroid/app/Dialog;

    invoke-virtual {v6}, Landroid/app/Dialog;->dismiss()V

    goto/16 :goto_0

    .line 2039
    :sswitch_9
    new-instance v0, Landroid/content/Intent;

    const-class v6, Lcom/thinkware/sundo/inavi3d/ui/SetRegionRadiusActivity;

    invoke-direct {v0, p0, v6}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 2040
    .restart local v0    # "intent":Landroid/content/Intent;
    const-string v6, "SearchData"

    iget-object v7, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_SearchOption:Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;

    invoke-virtual {v0, v6, v7}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/io/Serializable;)Landroid/content/Intent;

    .line 2041
    const/16 v6, 0x3e9

    invoke-virtual {p0, v0, v6}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->startActivityForResult(Landroid/content/Intent;I)V

    goto/16 :goto_0

    .line 2047
    .end local v0    # "intent":Landroid/content/Intent;
    :sswitch_a
    const/16 v6, 0x20

    const-string v7, "\uc54c\ub9bc"

    const-string v8, "\ucd5c\uadfc \uac80\uc0c9\uc5b4\ub97c \ubaa8\ub450 \uc0ad\uc81c\ud558\uc2dc\uaca0\uc2b5\ub2c8\uae4c?"

    invoke-static {v6, p0, v7, v8, v9}, Lcom/thinkware/sundo/inavi3d/ui/popup/PopupManager;->ShowPopup(ILandroid/content/Context;Ljava/lang/String;Ljava/lang/String;I)Lcom/thinkware/sundo/inavi3d/ui/popup/InaviPopup;

    move-result-object v3

    .line 2051
    .local v3, "popup":Lcom/thinkware/sundo/inavi3d/ui/popup/InaviPopup;
    new-instance v2, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$17;

    invoke-direct {v2, p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$17;-><init>(Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;)V

    .line 2061
    .local v2, "ok":Landroid/view/View$OnClickListener;
    invoke-static {v2}, Lcom/thinkware/sundo/inavi3d/ui/popup/PopupManager;->SetokListner(Landroid/view/View$OnClickListener;)Z

    goto/16 :goto_0

    .line 1888
    nop

    :sswitch_data_0
    .sparse-switch
        0x7f0a005d -> :sswitch_0
        0x7f0a005e -> :sswitch_1
        0x7f0a005f -> :sswitch_2
        0x7f0a0060 -> :sswitch_3
        0x7f0a016a -> :sswitch_a
        0x7f0a026f -> :sswitch_5
        0x7f0a0270 -> :sswitch_9
        0x7f0a0272 -> :sswitch_6
        0x7f0a0273 -> :sswitch_4
        0x7f0a0276 -> :sswitch_7
        0x7f0a0709 -> :sswitch_8
        0x7f0a08ec -> :sswitch_6
    .end sparse-switch
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 15
    .param p1, "savedInstanceState"    # Landroid/os/Bundle;

    .prologue
    .line 765
    invoke-super/range {p0 .. p1}, Lcom/thinkware/sundo/inavi3d/MainActivity;->onCreate(Landroid/os/Bundle;)V

    .line 766
    sput-object p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mActivity:Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;

    .line 767
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v10

    invoke-virtual {v10}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->is_support_scale()Z

    move-result v10

    if-eqz v10, :cond_2

    .line 768
    const v10, 0x7f030040

    invoke-virtual {p0, v10}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->setContentView(I)V

    .line 770
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INaviScaleManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INaviScaleManager;

    move-result-object v10

    invoke-virtual {v10, p0}, Lcom/thinkware/sundo/inavi3d/INaviScaleManager;->scaleOnce(Landroid/app/Activity;)V

    .line 771
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v10

    invoke-virtual {v10}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->is_support_builtin_statusbar()Z

    move-result v10

    if-eqz v10, :cond_0

    .line 779
    :cond_0
    :goto_0
    new-instance v10, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/UserDataMgr$beforeKeyParam;

    invoke-direct {v10}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/UserDataMgr$beforeKeyParam;-><init>()V

    iput-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_beforeParam:Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/UserDataMgr$beforeKeyParam;

    .line 782
    const v10, 0x7f0a005c

    invoke-virtual {p0, v10}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->findViewById(I)Landroid/view/View;

    move-result-object v10

    check-cast v10, Landroid/widget/Button;

    iput-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabUnited:Landroid/widget/Button;

    .line 783
    const v10, 0x7f0a005d

    invoke-virtual {p0, v10}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->findViewById(I)Landroid/view/View;

    move-result-object v10

    check-cast v10, Landroid/widget/Button;

    iput-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabName:Landroid/widget/Button;

    .line 784
    const v10, 0x7f0a005e

    invoke-virtual {p0, v10}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->findViewById(I)Landroid/view/View;

    move-result-object v10

    check-cast v10, Landroid/widget/Button;

    iput-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabAddr:Landroid/widget/Button;

    .line 785
    const v10, 0x7f0a005f

    invoke-virtual {p0, v10}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->findViewById(I)Landroid/view/View;

    move-result-object v10

    check-cast v10, Landroid/widget/Button;

    iput-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabAround:Landroid/widget/Button;

    .line 786
    const v10, 0x7f0a0060

    invoke-virtual {p0, v10}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->findViewById(I)Landroid/view/View;

    move-result-object v10

    check-cast v10, Landroid/widget/Button;

    iput-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabICode:Landroid/widget/Button;

    .line 788
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabUnited:Landroid/widget/Button;

    const/4 v11, 0x1

    invoke-virtual {v10, v11}, Landroid/widget/Button;->setSelected(Z)V

    .line 790
    invoke-direct {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->tabButtonDesable()V

    .line 792
    const v10, 0x7f0a026f

    invoke-virtual {p0, v10}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->findViewById(I)Landroid/view/View;

    move-result-object v10

    check-cast v10, Landroid/widget/Button;

    iput-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mBtnLive:Landroid/widget/Button;

    .line 793
    const v10, 0x7f0a0270

    invoke-virtual {p0, v10}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->findViewById(I)Landroid/view/View;

    move-result-object v10

    check-cast v10, Landroid/widget/Button;

    iput-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mBtnSetRegion:Landroid/widget/Button;

    .line 794
    const v10, 0x7f0a0273

    invoke-virtual {p0, v10}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->findViewById(I)Landroid/view/View;

    move-result-object v10

    check-cast v10, Landroid/widget/Button;

    iput-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mBtnErase:Landroid/widget/Button;

    .line 795
    const v10, 0x7f0a0272

    invoke-virtual {p0, v10}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->findViewById(I)Landroid/view/View;

    move-result-object v10

    check-cast v10, Landroid/widget/ImageButton;

    iput-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mBtnSearch:Landroid/widget/ImageButton;

    .line 801
    const v10, 0x7f0a0271

    invoke-virtual {p0, v10}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->findViewById(I)Landroid/view/View;

    move-result-object v10

    check-cast v10, Landroid/widget/EditText;

    iput-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    .line 803
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    iget-object v11, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mWatcher:Landroid/text/TextWatcher;

    invoke-virtual {v10, v11}, Landroid/widget/EditText;->addTextChangedListener(Landroid/text/TextWatcher;)V

    .line 805
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    invoke-virtual {v10, p0}, Landroid/widget/EditText;->setOnEditorActionListener(Landroid/widget/TextView$OnEditorActionListener;)V

    .line 806
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    invoke-virtual {v10, p0}, Landroid/widget/EditText;->setOnFocusChangeListener(Landroid/view/View$OnFocusChangeListener;)V

    .line 809
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    const/4 v11, 0x1

    invoke-virtual {v10, v11}, Landroid/widget/EditText;->setTextIsSelectable(Z)V

    .line 810
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    const/4 v11, 0x0

    invoke-virtual {v10, v11}, Landroid/widget/EditText;->setLongClickable(Z)V

    .line 812
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    new-instance v11, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$4;

    invoke-direct {v11, p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$4;-><init>(Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;)V

    invoke-virtual {v10, v11}, Landroid/widget/EditText;->setOnKeyListener(Landroid/view/View$OnKeyListener;)V

    .line 824
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    new-instance v11, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$5;

    invoke-direct {v11, p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$5;-><init>(Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;)V

    invoke-virtual {v10, v11}, Landroid/widget/EditText;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    .line 852
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mBtnSetRegion:Landroid/widget/Button;

    invoke-virtual {v10, p0}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 853
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mBtnErase:Landroid/widget/Button;

    invoke-virtual {v10, p0}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 854
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mBtnSearch:Landroid/widget/ImageButton;

    invoke-virtual {v10, p0}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 855
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mBtnLive:Landroid/widget/Button;

    invoke-virtual {v10, p0}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 857
    const/4 v10, 0x0

    iput-boolean v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->bShowPopup:Z

    .line 861
    new-instance v10, Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;

    invoke-direct {v10}, Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;-><init>()V

    iput-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_SearchOption:Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;

    .line 864
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->USPrepareUnitedSrch()V

    .line 867
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_SearchOption:Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;

    invoke-static {v10}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->USGetSearchOption(Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;)V

    .line 870
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->setSearchOption()V

    .line 874
    new-instance v10, Lcom/thinkware/sundo/inavi3d/ui/popup/InaviPopup;

    const-string v11, ""

    const-string v12, ""

    const/4 v13, 0x0

    invoke-direct {v10, p0, v11, v12, v13}, Lcom/thinkware/sundo/inavi3d/ui/popup/InaviPopup;-><init>(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;I)V

    iput-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mHelpDialog:Landroid/app/Dialog;

    .line 875
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v10

    invoke-virtual {v10}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->is_support_scale()Z

    move-result v10

    if-eqz v10, :cond_3

    .line 876
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mHelpDialog:Landroid/app/Dialog;

    const v11, 0x7f030105

    invoke-virtual {v10, v11}, Landroid/app/Dialog;->setContentView(I)V

    .line 877
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INaviScaleManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INaviScaleManager;

    move-result-object v10

    iget-object v11, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mHelpDialog:Landroid/app/Dialog;

    const v12, 0x7f0a0292

    invoke-virtual {v11, v12}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v11

    invoke-virtual {v10, v11}, Lcom/thinkware/sundo/inavi3d/INaviScaleManager;->scaleOnceDialog(Landroid/view/View;)V

    .line 881
    :goto_1
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mHelpDialog:Landroid/app/Dialog;

    const v11, 0x7f0a0709

    invoke-virtual {v10, v11}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v10

    invoke-virtual {v10, p0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 891
    const v10, 0x7f0a0281

    invoke-virtual {p0, v10}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->findViewById(I)Landroid/view/View;

    move-result-object v10

    check-cast v10, Landroid/widget/LinearLayout;

    iput-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_layoutRecentWord:Landroid/widget/LinearLayout;

    .line 892
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_layoutRecentWord:Landroid/widget/LinearLayout;

    const/4 v11, 0x0

    invoke-virtual {v10, v11}, Landroid/widget/LinearLayout;->setVisibility(I)V

    .line 894
    const v10, 0x7f0a0169

    invoke-virtual {p0, v10}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->findViewById(I)Landroid/view/View;

    move-result-object v10

    check-cast v10, Landroid/widget/LinearLayout;

    iput-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_layoutQueryHistory:Landroid/widget/LinearLayout;

    .line 895
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_layoutQueryHistory:Landroid/widget/LinearLayout;

    const/4 v11, 0x0

    invoke-virtual {v10, v11}, Landroid/widget/LinearLayout;->setVisibility(I)V

    .line 900
    const v10, 0x7f0a0282

    invoke-virtual {p0, v10}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->findViewById(I)Landroid/view/View;

    move-result-object v10

    check-cast v10, Landroid/widget/TextView;

    iput-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_btnRecent:Landroid/widget/TextView;

    .line 902
    const v10, 0x7f0a016a

    invoke-virtual {p0, v10}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->findViewById(I)Landroid/view/View;

    move-result-object v10

    check-cast v10, Landroid/widget/Button;

    iput-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_btnDelHistory:Landroid/widget/Button;

    .line 903
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_btnDelHistory:Landroid/widget/Button;

    invoke-virtual {v10, p0}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 908
    const v10, 0x7f0a0274

    invoke-virtual {p0, v10}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->findViewById(I)Landroid/view/View;

    move-result-object v10

    check-cast v10, Landroid/widget/LinearLayout;

    iput-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_layoutHelpNew:Landroid/widget/LinearLayout;

    .line 909
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_layoutHelpNew:Landroid/widget/LinearLayout;

    const/4 v11, 0x0

    invoke-virtual {v10, v11}, Landroid/widget/LinearLayout;->setVisibility(I)V

    .line 911
    const v10, 0x7f0a0276

    invoke-virtual {p0, v10}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->findViewById(I)Landroid/view/View;

    move-result-object v10

    check-cast v10, Landroid/widget/Button;

    iput-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_btnHelpNew:Landroid/widget/Button;

    .line 912
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_btnHelpNew:Landroid/widget/Button;

    invoke-virtual {v10, p0}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 914
    const v10, 0x7f0a027b

    invoke-virtual {p0, v10}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->findViewById(I)Landroid/view/View;

    move-result-object v10

    check-cast v10, Landroid/widget/HorizontalScrollView;

    iput-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_ScrollViewRecommendFirst:Landroid/widget/HorizontalScrollView;

    .line 915
    const v10, 0x7f0a027e

    invoke-virtual {p0, v10}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->findViewById(I)Landroid/view/View;

    move-result-object v10

    check-cast v10, Landroid/widget/HorizontalScrollView;

    iput-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_ScrollViewRecommendSecond:Landroid/widget/HorizontalScrollView;

    .line 917
    const v10, 0x7f0a027c

    invoke-virtual {p0, v10}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->findViewById(I)Landroid/view/View;

    move-result-object v10

    check-cast v10, Landroid/widget/LinearLayout;

    iput-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->layoutRecommendFirst:Landroid/widget/LinearLayout;

    .line 918
    const v10, 0x7f0a027f

    invoke-virtual {p0, v10}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->findViewById(I)Landroid/view/View;

    move-result-object v10

    check-cast v10, Landroid/widget/LinearLayout;

    iput-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->layoutRecommendSecond:Landroid/widget/LinearLayout;

    .line 920
    const v10, 0x7f0a027a

    invoke-virtual {p0, v10}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->findViewById(I)Landroid/view/View;

    move-result-object v10

    check-cast v10, Landroid/widget/LinearLayout;

    iput-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->layoutGapTop:Landroid/widget/LinearLayout;

    .line 921
    const v10, 0x7f0a027d

    invoke-virtual {p0, v10}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->findViewById(I)Landroid/view/View;

    move-result-object v10

    check-cast v10, Landroid/widget/LinearLayout;

    iput-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->layoutGapMiddle:Landroid/widget/LinearLayout;

    .line 922
    const v10, 0x7f0a0280

    invoke-virtual {p0, v10}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->findViewById(I)Landroid/view/View;

    move-result-object v10

    check-cast v10, Landroid/widget/LinearLayout;

    iput-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->layoutGapBottom:Landroid/widget/LinearLayout;

    .line 924
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_CurrentDPXY:Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr$XYInfo;

    invoke-static {v10}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->GetCurrentDPPositionXY(Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr$XYInfo;)V

    .line 925
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_CarDPXY:Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr$XYInfo;

    invoke-static {v10}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->GetCarDPPositionXY(Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr$XYInfo;)V

    .line 928
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_ButtonArr:[Landroid/widget/Button;

    if-nez v10, :cond_4

    .line 930
    const/16 v10, 0xa

    new-array v10, v10, [Landroid/widget/Button;

    iput-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_ButtonArr:[Landroid/widget/Button;

    .line 931
    const/16 v10, 0xa

    new-array v10, v10, [Landroid/view/View;

    iput-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_ViewLineArr:[Landroid/view/View;

    .line 933
    new-instance v8, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v10, 0x1

    const/4 v11, -0x2

    const/high16 v12, 0x41800000    # 16.0f

    invoke-direct {v8, v10, v11, v12}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    .line 936
    .local v8, "paramsLine":Landroid/widget/LinearLayout$LayoutParams;
    const/16 v10, 0x10

    iput v10, v8, Landroid/widget/LinearLayout$LayoutParams;->gravity:I

    .line 939
    new-instance v7, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v10, 0xcb

    const/4 v11, -0x1

    invoke-direct {v7, v10, v11}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 945
    .local v7, "paramsButton":Landroid/widget/LinearLayout$LayoutParams;
    const/4 v3, 0x0

    .local v3, "i":I
    :goto_2
    const/16 v10, 0xa

    if-ge v3, v10, :cond_4

    .line 947
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_ButtonArr:[Landroid/widget/Button;

    new-instance v11, Landroid/widget/Button;

    invoke-direct {v11, p0}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    aput-object v11, v10, v3

    .line 948
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_ButtonArr:[Landroid/widget/Button;

    aget-object v10, v10, v3

    const/4 v11, 0x0

    const/high16 v12, 0x41b00000    # 22.0f

    invoke-virtual {v10, v11, v12}, Landroid/widget/Button;->setTextSize(IF)V

    .line 949
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_ButtonArr:[Landroid/widget/Button;

    aget-object v10, v10, v3

    const/16 v11, 0xac

    const/16 v12, 0xbe

    const/16 v13, 0xd8

    invoke-static {v11, v12, v13}, Landroid/graphics/Color;->rgb(III)I

    move-result v11

    invoke-virtual {v10, v11}, Landroid/widget/Button;->setTextColor(I)V

    .line 950
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_ButtonArr:[Landroid/widget/Button;

    aget-object v10, v10, v3

    invoke-virtual {v10, v7}, Landroid/widget/Button;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 951
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_ButtonArr:[Landroid/widget/Button;

    aget-object v10, v10, v3

    const v11, 0x7f02051b

    invoke-virtual {v10, v11}, Landroid/widget/Button;->setBackgroundResource(I)V

    .line 952
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_ButtonArr:[Landroid/widget/Button;

    aget-object v10, v10, v3

    const/16 v11, 0x8

    invoke-virtual {v10, v11}, Landroid/widget/Button;->setVisibility(I)V

    .line 953
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_ButtonArr:[Landroid/widget/Button;

    aget-object v10, v10, v3

    const/16 v11, 0xa

    const/4 v12, 0x0

    const/16 v13, 0xa

    const/4 v14, 0x0

    invoke-virtual {v10, v11, v12, v13, v14}, Landroid/widget/Button;->setPadding(IIII)V

    .line 955
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_ViewLineArr:[Landroid/view/View;

    new-instance v11, Landroid/widget/ImageView;

    invoke-direct {v11, p0}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    aput-object v11, v10, v3

    .line 956
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_ViewLineArr:[Landroid/view/View;

    aget-object v10, v10, v3

    const v11, 0x7f020e12

    invoke-virtual {v10, v11}, Landroid/view/View;->setBackgroundResource(I)V

    .line 957
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_ViewLineArr:[Landroid/view/View;

    aget-object v10, v10, v3

    invoke-virtual {v10, v8}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 958
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_ViewLineArr:[Landroid/view/View;

    aget-object v10, v10, v3

    const/16 v11, 0x8

    invoke-virtual {v10, v11}, Landroid/view/View;->setVisibility(I)V

    .line 960
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v10

    invoke-virtual {v10}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->getScaleType()I

    move-result v10

    const/4 v11, 0x2

    if-lt v10, v11, :cond_1

    .line 961
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/INaviScaleManager;->getInstance()Lcom/thinkware/sundo/inavi3d/INaviScaleManager;

    move-result-object v10

    iget-object v11, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_ViewLineArr:[Landroid/view/View;

    aget-object v11, v11, v3

    invoke-virtual {v10, v11}, Lcom/thinkware/sundo/inavi3d/INaviScaleManager;->restoreScale1Pixel(Landroid/view/View;)V

    .line 945
    :cond_1
    add-int/lit8 v3, v3, 0x1

    goto/16 :goto_2

    .line 775
    .end local v3    # "i":I
    .end local v7    # "paramsButton":Landroid/widget/LinearLayout$LayoutParams;
    .end local v8    # "paramsLine":Landroid/widget/LinearLayout$LayoutParams;
    :cond_2
    const v10, 0x7f03015d

    invoke-virtual {p0, v10}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->setContentView(I)V

    goto/16 :goto_0

    .line 879
    :cond_3
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mHelpDialog:Landroid/app/Dialog;

    const v11, 0x7f030105

    invoke-virtual {v10, v11}, Landroid/app/Dialog;->setContentView(I)V

    goto/16 :goto_1

    .line 1046
    :cond_4
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->ReadyPreAreaNameSearch()V

    .line 1047
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->ReadyLiveSearchAgreePopup()V

    .line 1049
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v10

    invoke-virtual {v10}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->supportRSearch()Z

    move-result v10

    if-nez v10, :cond_7

    .line 1051
    const/4 v10, 0x0

    invoke-static {v10}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->USAskLiveAgreeTerm(Z)Z

    .line 1052
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->USGetLiveTermAgreed()Z

    move-result v10

    const/4 v11, 0x1

    if-ne v10, v11, :cond_6

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->getInstance()Lcom/thinkware/sundo/inavi3d/InaviConfig;

    move-result-object v10

    const/16 v11, 0xe3

    invoke-virtual {v10, v11}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->CNaviConfigGet(I)I

    move-result v10

    const/4 v11, 0x1

    if-ne v10, v11, :cond_6

    .line 1054
    const/4 v10, 0x1

    iput-boolean v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bLiveSrch:Z

    .line 1077
    :goto_3
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mBtnLive:Landroid/widget/Button;

    iget-boolean v11, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bLiveSrch:Z

    invoke-virtual {v10, v11}, Landroid/widget/Button;->setSelected(Z)V

    .line 1080
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->USGetQueryHistoryCount()I

    move-result v10

    if-lez v10, :cond_12

    const/4 v10, 0x0

    invoke-static {v10}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->USGetQueryHistory(I)Ljava/lang/String;

    move-result-object v10

    iput-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strHistoryQuery:Ljava/lang/String;

    if-eqz v10, :cond_12

    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strHistoryQuery:Ljava/lang/String;

    invoke-virtual {p0, v10}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->IsValidQuery(Ljava/lang/String;)Z

    move-result v10

    if-eqz v10, :cond_12

    .line 1084
    const/4 v6, 0x0

    .line 1085
    .local v6, "nSpaceCnt":I
    iget-boolean v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bLiveSrch:Z

    if-nez v10, :cond_c

    .line 1086
    iget-object v9, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strHistoryQuery:Ljava/lang/String;

    .line 1087
    .local v9, "strKey":Ljava/lang/String;
    invoke-virtual {v9}, Ljava/lang/String;->length()I

    move-result v5

    .line 1089
    .local v5, "nLen":I
    const/4 v4, 0x0

    .local v4, "ii":I
    :goto_4
    if-ge v4, v5, :cond_c

    .line 1090
    invoke-virtual {v9, v4}, Ljava/lang/String;->charAt(I)C

    move-result v1

    .line 1091
    .local v1, "ch":C
    const/16 v10, 0x20

    if-ne v1, v10, :cond_5

    .line 1093
    add-int/lit8 v6, v6, 0x1

    .line 1089
    :cond_5
    add-int/lit8 v4, v4, 0x1

    goto :goto_4

    .line 1056
    .end local v1    # "ch":C
    .end local v4    # "ii":I
    .end local v5    # "nLen":I
    .end local v6    # "nSpaceCnt":I
    .end local v9    # "strKey":Ljava/lang/String;
    :cond_6
    const/4 v10, 0x0

    iput-boolean v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bLiveSrch:Z

    goto :goto_3

    .line 1060
    :cond_7
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v10

    invoke-virtual {v10}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->isSupportLiveService()Z

    move-result v10

    if-nez v10, :cond_8

    .line 1061
    const/4 v10, 0x0

    iput-boolean v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bLiveSrch:Z

    goto :goto_3

    .line 1063
    :cond_8
    invoke-static {p0}, Lcom/thinkware/i3dlite/CommonDef;->IsNetworkAvailable(Landroid/content/Context;)Z

    move-result v0

    .line 1064
    .local v0, "bNetwork":Z
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/livesearch/LiveSearchManager;->getInstance()Lcom/thinkware/sundo/inavi3d/livesearch/LiveSearchManager;

    move-result-object v10

    invoke-virtual {v10}, Lcom/thinkware/sundo/inavi3d/livesearch/LiveSearchManager;->isAgreed()Z

    move-result v10

    const/4 v11, 0x1

    if-ne v10, v11, :cond_a

    .line 1065
    if-eqz v0, :cond_9

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->getInstance()Lcom/thinkware/sundo/inavi3d/InaviConfig;

    move-result-object v10

    const/16 v11, 0x11b

    invoke-virtual {v10, v11}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->CNaviConfigGet(I)I

    move-result v10

    const/4 v11, 0x1

    if-ne v10, v11, :cond_9

    .line 1066
    const/4 v10, 0x1

    iput-boolean v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bLiveSrch:Z

    goto :goto_3

    .line 1068
    :cond_9
    const/4 v10, 0x0

    iput-boolean v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bLiveSrch:Z

    goto :goto_3

    .line 1070
    :cond_a
    if-eqz v0, :cond_b

    invoke-static {}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->getInstance()Lcom/thinkware/sundo/inavi3d/InaviConfig;

    move-result-object v10

    const/16 v11, 0x11b

    invoke-virtual {v10, v11}, Lcom/thinkware/sundo/inavi3d/InaviConfig;->CNaviConfigGet(I)I

    move-result v10

    const/4 v11, 0x1

    if-ne v10, v11, :cond_b

    .line 1071
    invoke-direct {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->showLiveProvisionPopup()V

    goto/16 :goto_3

    .line 1073
    :cond_b
    const/4 v10, 0x0

    iput-boolean v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bLiveSrch:Z

    goto/16 :goto_3

    .line 1097
    .end local v0    # "bNetwork":Z
    .restart local v6    # "nSpaceCnt":I
    :cond_c
    const/4 v10, 0x1

    iput-boolean v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bCancleRecommend:Z

    .line 1098
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    iget-object v11, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strHistoryQuery:Ljava/lang/String;

    invoke-virtual {v10, v11}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    .line 1101
    const/4 v10, 0x1

    if-le v6, v10, :cond_d

    .line 1102
    invoke-direct {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->EraseSpaceInEditText()V

    .line 1105
    :cond_d
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    invoke-virtual {v10}, Landroid/widget/EditText;->selectAll()V

    .line 1107
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    invoke-virtual {v10}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v10

    iput-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strHistoryQuery:Ljava/lang/String;

    .line 1109
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/ui/SIPModel;->getInstance()Lcom/thinkware/sundo/inavi3d/ui/SIPModel;

    move-result-object v10

    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->IsEnableSpaceBtn()Z

    move-result v11

    invoke-virtual {v10, v11}, Lcom/thinkware/sundo/inavi3d/ui/SIPModel;->setSpaceButtonEnable(Z)V

    .line 1120
    .end local v6    # "nSpaceCnt":I
    :goto_5
    iget-boolean v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bLiveSrch:Z

    if-eqz v10, :cond_13

    .line 1122
    const/4 v10, 0x0

    invoke-virtual {p0, v10}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->enableRegionBtn(Z)V

    .line 1137
    :cond_e
    :goto_6
    invoke-direct {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->loadQueryHistory()V

    .line 1146
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->getIntent()Landroid/content/Intent;

    move-result-object v10

    const-string v11, "mode"

    const/4 v12, 0x0

    invoke-virtual {v10, v11, v12}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v10

    iput v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mode:I

    .line 1147
    iget v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mode:I

    const/4 v11, 0x1

    if-eq v10, v11, :cond_f

    iget v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mode:I

    const/4 v11, 0x2

    if-eq v10, v11, :cond_f

    iget v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mode:I

    const/16 v11, 0xc

    if-eq v10, v11, :cond_f

    iget v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mode:I

    const/16 v11, 0xd

    if-eq v10, v11, :cond_f

    iget v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mode:I

    const/4 v11, 0x4

    if-eq v10, v11, :cond_f

    iget v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mode:I

    const/4 v11, 0x3

    if-eq v10, v11, :cond_f

    iget v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mode:I

    const/16 v11, 0xb

    if-ne v10, v11, :cond_10

    .line 1149
    :cond_f
    const/4 v10, 0x1

    iput-boolean v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bAddMode:Z

    .line 1156
    :cond_10
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->getIntent()Landroid/content/Intent;

    move-result-object v10

    const-string v11, "Query"

    invoke-virtual {v10, v11}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    if-eqz v10, :cond_11

    .line 1157
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->getIntent()Landroid/content/Intent;

    move-result-object v11

    const-string v12, "Query"

    invoke-virtual {v11, v12}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v10, v11}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    .line 1158
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->getIntent()Landroid/content/Intent;

    move-result-object v10

    const-string v11, "Query"

    invoke-virtual {v10, v11}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    iput-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strQuery:Ljava/lang/String;

    .line 1160
    const/4 v10, 0x0

    iput-boolean v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bReSrch:Z

    .line 1162
    iget-boolean v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bLiveSrch:Z

    if-eqz v10, :cond_15

    .line 1163
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->DoLiveSearch()V

    .line 1168
    :cond_11
    :goto_7
    return-void

    .line 1112
    :cond_12
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mBtnSearch:Landroid/widget/ImageButton;

    const/4 v11, 0x0

    invoke-virtual {v10, v11}, Landroid/widget/ImageButton;->setEnabled(Z)V

    .line 1113
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mBtnErase:Landroid/widget/Button;

    const/4 v11, 0x4

    invoke-virtual {v10, v11}, Landroid/widget/Button;->setVisibility(I)V

    .line 1115
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/ui/SIPModel;->getInstance()Lcom/thinkware/sundo/inavi3d/ui/SIPModel;

    move-result-object v10

    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->IsEnableSearchBtn()Z

    move-result v11

    invoke-virtual {v10, v11}, Lcom/thinkware/sundo/inavi3d/ui/SIPModel;->setSearchButtonEnable(Z)V

    .line 1116
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/ui/SIPModel;->getInstance()Lcom/thinkware/sundo/inavi3d/ui/SIPModel;

    move-result-object v10

    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->IsEnableSpaceBtn()Z

    move-result v11

    invoke-virtual {v10, v11}, Lcom/thinkware/sundo/inavi3d/ui/SIPModel;->setSpaceButtonEnable(Z)V

    goto/16 :goto_5

    .line 1126
    :cond_13
    iget-object v10, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    invoke-virtual {v10}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    .line 1128
    .local v2, "edtString":Ljava/lang/String;
    const-string v10, " "

    invoke-virtual {v2, v10}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v10

    const/4 v11, 0x1

    if-ne v10, v11, :cond_e

    .line 1129
    invoke-virtual {p0, v2}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->IsIncludeAdminName(Ljava/lang/String;)Z

    move-result v10

    if-nez v10, :cond_14

    .line 1130
    const/4 v10, 0x1

    invoke-virtual {p0, v10}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->enableRegionBtn(Z)V

    goto/16 :goto_6

    .line 1132
    :cond_14
    const/4 v10, 0x0

    invoke-virtual {p0, v10}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->enableRegionBtn(Z)V

    goto/16 :goto_6

    .line 1165
    .end local v2    # "edtString":Ljava/lang/String;
    :cond_15
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->DoSearch()V

    goto :goto_7
.end method

.method protected onDestroy()V
    .locals 4

    .prologue
    const/4 v3, 0x0

    .line 1551
    const-string v0, "inavi3d_bona"

    const-string v1, "UnitedSearchActivity onDestroy 1"

    invoke-static {v0, v1}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 1552
    new-instance v0, Lcom/thinkware/sundo/inavi3d/INaviTask;

    new-instance v1, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$9;

    invoke-direct {v1, p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$9;-><init>(Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;)V

    invoke-direct {v0, v1, v3}, Lcom/thinkware/sundo/inavi3d/INaviTask;-><init>(Lcom/thinkware/sundo/inavi3d/INaviTask$iINaviTaskInterFace;Z)V

    const/4 v1, 0x1

    new-array v1, v1, [Ljava/lang/Object;

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    aput-object v2, v1, v3

    invoke-virtual {v0, v1}, Lcom/thinkware/sundo/inavi3d/INaviTask;->execute([Ljava/lang/Object;)Landroid/os/AsyncTask;

    .line 1578
    invoke-super {p0}, Lcom/thinkware/sundo/inavi3d/MainActivity;->onDestroy()V

    .line 1579
    return-void
.end method

.method public onEditorAction(Landroid/widget/TextView;ILandroid/view/KeyEvent;)Z
    .locals 6
    .param p1, "v"    # Landroid/widget/TextView;
    .param p2, "actionId"    # I
    .param p3, "event"    # Landroid/view/KeyEvent;

    .prologue
    const/16 v5, 0x1773

    const/4 v1, 0x0

    const/4 v2, 0x1

    .line 2557
    const/4 v3, 0x6

    if-eq p2, v3, :cond_0

    const/4 v3, 0x3

    if-eq p2, v3, :cond_0

    if-eqz p3, :cond_1

    invoke-virtual {p3}, Landroid/view/KeyEvent;->getKeyCode()I

    move-result v3

    const/16 v4, 0x42

    if-ne v3, v4, :cond_1

    .line 2559
    :cond_0
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    invoke-virtual {v3}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p0, v3}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->IsValidQuery(Ljava/lang/String;)Z

    move-result v3

    if-nez v3, :cond_2

    move v1, v2

    .line 2594
    :cond_1
    :goto_0
    return v1

    .line 2563
    :cond_2
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    invoke-virtual {v3}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v3

    iput-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strQuery:Ljava/lang/String;

    .line 2565
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strQuery:Ljava/lang/String;

    const-string v4, "##\ub85c\uae45\uc2dc\uc791"

    invoke-virtual {v3, v4}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v3

    if-eqz v3, :cond_3

    .line 2566
    const-string v3, ""

    invoke-static {v5, v2, v3}, Lcom/thinkware/sundo/inavi3d/Inavi;->ProcessMessage(IILjava/lang/String;)I

    .line 2567
    const-string v3, "\ub85c\uae45\uc2dc\uc791 (/storage/emulated/0/inavi3d/gpslog/)"

    invoke-static {p0, v3, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v2

    invoke-virtual {v2}, Landroid/widget/Toast;->show()V

    .line 2568
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strQuery:Ljava/lang/String;

    invoke-static {v2, v1}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->USSetQueryHistory(Ljava/lang/String;I)V

    goto :goto_0

    .line 2571
    :cond_3
    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strQuery:Ljava/lang/String;

    const-string v4, "##\ub85c\uae45\uc911\ub2e8"

    invoke-virtual {v3, v4}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v3

    if-eqz v3, :cond_4

    .line 2572
    const-string v3, ""

    invoke-static {v5, v1, v3}, Lcom/thinkware/sundo/inavi3d/Inavi;->ProcessMessage(IILjava/lang/String;)I

    .line 2573
    const-string v3, "\ub85c\uae45\uc911\ub2e8 (/storage/emulated/0/inavi3d/gpslog/)"

    invoke-static {p0, v3, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v2

    invoke-virtual {v2}, Landroid/widget/Toast;->show()V

    .line 2574
    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strQuery:Ljava/lang/String;

    invoke-static {v2, v1}, Lcom/thinkware/sundo/inavi3d/ui/uinativemgr/SearchNativeMgr;->USSetQueryHistory(Ljava/lang/String;I)V

    goto :goto_0

    .line 2578
    :cond_4
    iget-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bOnceRun:Z

    if-nez v1, :cond_6

    .line 2579
    iget-boolean v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bLiveSrch:Z

    if-eqz v1, :cond_5

    .line 2580
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->DoLiveSearch()V

    .line 2584
    :goto_1
    iput-boolean v2, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bOnceRun:Z

    .line 2589
    new-instance v0, Landroid/os/Handler;

    invoke-direct {v0}, Landroid/os/Handler;-><init>()V

    .line 2590
    .local v0, "h":Landroid/os/Handler;
    new-instance v1, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$OnceRunhandler;

    invoke-direct {v1, p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$OnceRunhandler;-><init>(Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;)V

    const-wide/16 v4, 0x3e8

    invoke-virtual {v0, v1, v4, v5}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    move v1, v2

    .line 2592
    goto :goto_0

    .line 2582
    .end local v0    # "h":Landroid/os/Handler;
    :cond_5
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->DoSearch()V

    goto :goto_1

    :cond_6
    move v1, v2

    .line 2586
    goto :goto_0
.end method

.method public onFocusChange(Landroid/view/View;Z)V
    .locals 3
    .param p1, "v"    # Landroid/view/View;
    .param p2, "hasFocus"    # Z

    .prologue
    const/4 v2, 0x0

    .line 2072
    invoke-virtual {p1}, Landroid/view/View;->getId()I

    move-result v0

    packed-switch v0, :pswitch_data_0

    .line 2081
    :goto_0
    return-void

    .line 2074
    :pswitch_0
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    const v1, 0x7f020df4

    invoke-virtual {v0, v1}, Landroid/widget/EditText;->setBackgroundResource(I)V

    .line 2075
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    const/16 v1, 0xf

    invoke-virtual {v0, v1, v2, v2, v2}, Landroid/widget/EditText;->setPadding(IIII)V

    goto :goto_0

    .line 2072
    nop

    :pswitch_data_0
    .packed-switch 0x7f0a0271
        :pswitch_0
    .end packed-switch
.end method

.method protected onResume()V
    .locals 7

    .prologue
    const/4 v4, 0x1

    const/4 v5, 0x0

    .line 1810
    invoke-virtual {p0, v5, v5}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->overridePendingTransition(II)V

    .line 1811
    invoke-super {p0}, Lcom/thinkware/sundo/inavi3d/MainActivity;->onResume()V

    .line 1814
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->getIntent()Landroid/content/Intent;

    move-result-object v0

    const-string v1, "mode"

    invoke-virtual {v0, v1, v5}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v0

    iput v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mode:I

    .line 1815
    iget v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mode:I

    if-eq v0, v4, :cond_0

    iget v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mode:I

    const/4 v1, 0x2

    if-eq v0, v1, :cond_0

    iget v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mode:I

    const/16 v1, 0xc

    if-eq v0, v1, :cond_0

    iget v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mode:I

    const/16 v1, 0xd

    if-eq v0, v1, :cond_0

    iget v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mode:I

    const/4 v1, 0x4

    if-eq v0, v1, :cond_0

    iget v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mode:I

    const/4 v1, 0x3

    if-eq v0, v1, :cond_0

    iget v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mode:I

    const/16 v1, 0xb

    if-ne v0, v1, :cond_1

    .line 1817
    :cond_0
    iput-boolean v4, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bAddMode:Z

    .line 1823
    :cond_1
    const v0, 0x7f0a003c

    invoke-virtual {p0, v0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/RelativeLayout;

    .line 1825
    .local v2, "SIPBGlayout":Landroid/widget/RelativeLayout;
    invoke-virtual {v2, v5}, Landroid/widget/RelativeLayout;->setBackgroundColor(I)V

    .line 1827
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/ui/SIPModel;->getInstance()Lcom/thinkware/sundo/inavi3d/ui/SIPModel;

    move-result-object v0

    iget-object v3, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    const/16 v6, 0x10

    move-object v1, p0

    invoke-virtual/range {v0 .. v6}, Lcom/thinkware/sundo/inavi3d/ui/SIPModel;->addSIP(Landroid/content/Context;Landroid/view/ViewGroup;Landroid/widget/EditText;ZZI)V

    .line 1829
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    const v1, 0x7f020df6

    invoke-virtual {v0, v1}, Landroid/widget/EditText;->setBackgroundResource(I)V

    .line 1830
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    const/16 v1, 0xf

    invoke-virtual {v0, v1, v5, v5, v5}, Landroid/widget/EditText;->setPadding(IIII)V

    .line 1832
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->btnTabUnited:Landroid/widget/Button;

    new-instance v1, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$16;

    invoke-direct {v1, p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity$16;-><init>(Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;)V

    const-wide/16 v4, 0x64

    invoke-virtual {v0, v1, v4, v5}, Landroid/widget/Button;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 1840
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->GetInstance()Lcom/thinkware/sundo/inavi3d/DeviceInfo;

    move-result-object v0

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/DeviceInfo;->is_support_builtin_statusbar()Z

    move-result v0

    if-eqz v0, :cond_2

    .line 1843
    :cond_2
    return-void
.end method

.method public onSearchClear()V
    .locals 0

    .prologue
    .line 2644
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->searchClear()V

    .line 2645
    return-void
.end method

.method public onSelectedSearch()V
    .locals 0

    .prologue
    .line 2639
    invoke-virtual {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->doUnitedSearch()V

    .line 2640
    return-void
.end method

.method protected onStart()V
    .locals 2

    .prologue
    .line 1536
    invoke-super {p0}, Lcom/thinkware/sundo/inavi3d/MainActivity;->onStart()V

    .line 1537
    const-string v0, "inavi3d_bona"

    const-string v1, "MainMenu onStart"

    invoke-static {v0, v1}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 1538
    return-void
.end method

.method protected onStop()V
    .locals 2

    .prologue
    .line 1543
    sget-object v0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mActivity:Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;

    if-eqz v0, :cond_0

    .line 1544
    const/4 v0, 0x0

    sput-object v0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mActivity:Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;

    .line 1545
    :cond_0
    invoke-super {p0}, Lcom/thinkware/sundo/inavi3d/MainActivity;->onStop()V

    .line 1546
    const-string v0, "inavi3d_java"

    const-string v1, "MainMenu onStop"

    invoke-static {v0, v1}, Lcom/thinkware/sundo/inavi3d/LOGTW;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 1547
    return-void
.end method

.method public searchClear()V
    .locals 2

    .prologue
    .line 2084
    iget-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mEditInput:Landroid/widget/EditText;

    const-string v1, ""

    invoke-virtual {v0, v1}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    .line 2087
    const-string v0, ""

    iput-object v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_strQuery:Ljava/lang/String;

    .line 2090
    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bIsExistSpaceInKeyword:Z

    .line 2091
    iget-boolean v0, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_bLiveSrch:Z

    if-nez v0, :cond_0

    .line 2093
    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->enableRegionBtn(Z)V

    .line 2098
    :cond_0
    invoke-static {}, Lcom/thinkware/sundo/inavi3d/ui/SIPModel;->getInstance()Lcom/thinkware/sundo/inavi3d/ui/SIPModel;

    move-result-object v0

    invoke-virtual {v0}, Lcom/thinkware/sundo/inavi3d/ui/SIPModel;->clearText()V

    .line 2099
    return-void
.end method

.method setSearchOption()V
    .locals 4

    .prologue
    const/4 v2, 0x1

    .line 1762
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_SearchOption:Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;

    iget v1, v1, Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;->m_nOption:I

    if-nez v1, :cond_2

    .line 1764
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_SearchOption:Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;

    iget v1, v1, Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;->m_nAdminCode:I

    if-nez v1, :cond_1

    .line 1765
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mBtnSetRegion:Landroid/widget/Button;

    const-string v2, "\uc804\uad6d"

    invoke-virtual {v1, v2}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 1805
    :cond_0
    :goto_0
    return-void

    .line 1766
    :cond_1
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_SearchOption:Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;

    iget-object v1, v1, Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;->m_strOption:Ljava/lang/String;

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v1

    if-le v1, v2, :cond_0

    .line 1768
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mBtnSetRegion:Landroid/widget/Button;

    iget-object v2, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_SearchOption:Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;

    iget-object v2, v2, Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;->m_strOption:Ljava/lang/String;

    invoke-virtual {v1, v2}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 1771
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_SearchOption:Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;

    iget-object v1, v1, Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;->m_strOption:Ljava/lang/String;

    const-string v2, "\uc138\uc885\ud2b9\ubcc4\uc790\uce58\uc2dc"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_0

    .line 1772
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mBtnSetRegion:Landroid/widget/Button;

    const-string v2, "\uc138\uc885\ud2b9\ubcc4\uc2dc"

    invoke-virtual {v1, v2}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    goto :goto_0

    .line 1776
    :cond_2
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_SearchOption:Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;

    iget v1, v1, Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;->m_nOption:I

    if-ne v1, v2, :cond_0

    .line 1779
    const/4 v0, 0x0

    .line 1781
    .local v0, "nRadiusKM":I
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->m_SearchOption:Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;

    iget v1, v1, Lcom/thinkware/sundo/inavi3d/ui/adapterdata/UnitedSchListInfo$SearchData;->m_nRadiusBoundary:I

    packed-switch v1, :pswitch_data_0

    .line 1800
    :goto_1
    iget-object v1, p0, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->mBtnSetRegion:Landroid/widget/Button;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " km"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    goto :goto_0

    .line 1783
    :pswitch_0
    const/4 v0, 0x1

    .line 1784
    goto :goto_1

    .line 1786
    :pswitch_1
    const/4 v0, 0x2

    .line 1787
    goto :goto_1

    .line 1789
    :pswitch_2
    const/4 v0, 0x5

    .line 1790
    goto :goto_1

    .line 1792
    :pswitch_3
    const/16 v0, 0x8

    .line 1793
    goto :goto_1

    .line 1795
    :pswitch_4
    const/16 v0, 0xa

    .line 1796
    goto :goto_1

    .line 1781
    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
        :pswitch_1
        :pswitch_2
        :pswitch_3
        :pswitch_4
    .end packed-switch
.end method

.method public showMaxLengthPopup()V
    .locals 0

    .prologue
    .line 2634
    invoke-direct {p0}, Lcom/thinkware/sundo/inavi3d/ui/UnitedSearchActivity;->_ShowInputOverflowMsg()V

    .line 2635
    return-void
.end method
