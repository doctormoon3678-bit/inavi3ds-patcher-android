.class public Lcom/thinkware/os/winker/WinkerObserver;
.super Ljava/lang/Object;
.source "WinkerObserver.java"


# instance fields
.field private mChecker:Lcom/thinkware/os/winker/WinkerChecker;

.field private mIsStarted:Z

.field private mListener:Lcom/thinkware/os/winker/IWinkerStateListener;


# direct methods
.method public constructor <init>(Lcom/thinkware/os/winker/IWinkerStateListener;)V
    .locals 1
    .param p1, "listener"    # Lcom/thinkware/os/winker/IWinkerStateListener;

    .prologue
    .line 9
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 10
    iput-object p1, p0, Lcom/thinkware/os/winker/WinkerObserver;->mListener:Lcom/thinkware/os/winker/IWinkerStateListener;

    .line 11
    new-instance v0, Lcom/thinkware/os/winker/WinkerChecker;

    invoke-direct {v0, p1}, Lcom/thinkware/os/winker/WinkerChecker;-><init>(Lcom/thinkware/os/winker/IWinkerStateListener;)V

    iput-object v0, p0, Lcom/thinkware/os/winker/WinkerObserver;->mChecker:Lcom/thinkware/os/winker/WinkerChecker;

    .line 12
    return-void
.end method


# virtual methods
.method public startWinkerObserving()V
    .locals 2

    .prologue
    .line 15
    iget-boolean v0, p0, Lcom/thinkware/os/winker/WinkerObserver;->mIsStarted:Z

    if-eqz v0, :cond_0

    .line 25
    :goto_0
    return-void

    .line 18
    :cond_0
    iget-object v0, p0, Lcom/thinkware/os/winker/WinkerObserver;->mChecker:Lcom/thinkware/os/winker/WinkerChecker;

    if-nez v0, :cond_1

    .line 19
    new-instance v0, Lcom/thinkware/os/winker/WinkerChecker;

    iget-object v1, p0, Lcom/thinkware/os/winker/WinkerObserver;->mListener:Lcom/thinkware/os/winker/IWinkerStateListener;

    invoke-direct {v0, v1}, Lcom/thinkware/os/winker/WinkerChecker;-><init>(Lcom/thinkware/os/winker/IWinkerStateListener;)V

    iput-object v0, p0, Lcom/thinkware/os/winker/WinkerObserver;->mChecker:Lcom/thinkware/os/winker/WinkerChecker;

    .line 21
    :cond_1
    iget-object v0, p0, Lcom/thinkware/os/winker/WinkerObserver;->mChecker:Lcom/thinkware/os/winker/WinkerChecker;

    if-eqz v0, :cond_2

    .line 22
    iget-object v0, p0, Lcom/thinkware/os/winker/WinkerObserver;->mChecker:Lcom/thinkware/os/winker/WinkerChecker;

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    .line 24
    :cond_2
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/thinkware/os/winker/WinkerObserver;->mIsStarted:Z

    goto :goto_0
.end method

.method public stopWinkerObserving()V
    .locals 1

    .prologue
    .line 28
    iget-object v0, p0, Lcom/thinkware/os/winker/WinkerObserver;->mChecker:Lcom/thinkware/os/winker/WinkerChecker;

    if-eqz v0, :cond_0

    .line 29
    iget-object v0, p0, Lcom/thinkware/os/winker/WinkerObserver;->mChecker:Lcom/thinkware/os/winker/WinkerChecker;

    invoke-virtual {v0}, Lcom/thinkware/os/winker/WinkerChecker;->quit()V

    .line 30
    const/4 v0, 0x0

    iput-object v0, p0, Lcom/thinkware/os/winker/WinkerObserver;->mChecker:Lcom/thinkware/os/winker/WinkerChecker;

    .line 32
    :cond_0
    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/thinkware/os/winker/WinkerObserver;->mIsStarted:Z

    .line 33
    return-void
.end method
