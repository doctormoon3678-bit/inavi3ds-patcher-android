"""패치 엔진: apktool 디컴파일 폴더에 패치팩을 적용한다 (GUI와 분리, 단독 테스트 가능)."""
import os, re, json, shutil, glob, subprocess, sys

HEX = re.compile(r"0x7f[0-9a-f]{6}")
TOKEN = re.compile(r"@@RES:(\w+)/([^@]+)@@")
PUB = re.compile(r'<public type="(\w+)" name="([^"]+)" id="(0x7f[0-9a-f]{6})"')
NOWIN = 0x08000000 if os.name == "nt" else 0
BUILD_ID = "r10-diagnostics"
IS_TERMUX = "com.termux" in os.environ.get("PREFIX", "") or os.path.isdir("/data/data/com.termux/files")


def base_dir():
    return getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))


def list_packs():
    """patches/ 아래 패치팩 {버전: 경로}"""
    root = os.path.join(base_dir(), "patches")
    out = {}
    for d in sorted(glob.glob(os.path.join(root, "*", "manifest.json"))):
        out[os.path.basename(os.path.dirname(d))] = os.path.dirname(d)
    return out


def load_pack(pack_dir):
    with open(os.path.join(pack_dir, "manifest.json"), encoding="utf8") as f:
        return json.load(f)


def _pub(src):
    p = os.path.join(src, "res/values/public.xml")
    txt = open(p, encoding="utf8").read()
    return {(t, n): i for t, n, i in PUB.findall(txt)}, p, txt


def apply_pack(src, pack_dir, item_ids, excluded=frozenset(), log=print):
    """src: apktool로 디컴파일한 대상 폴더. item_ids: 적용할 항목 id 목록.
    excluded: 제외할 파일 상대경로 집합. 반환: 요약 dict"""
    pack = load_pack(pack_dir)
    idmap = json.load(open(os.path.join(pack_dir, "idmap.json")))
    tgt, pub_path, pub_txt = _pub(src)
    warn, stats = [], {"replace": 0, "add": 0, "skip": 0}

    # 1) 패치가 새로 만드는 리소스 등록 (현재는 id 타입만)
    tokens = {}
    for r in pack.get("res_add", []):
        t, n = r["type"], r["name"]
        if (t, n) in tgt:
            tokens[(t, n)] = tgt[(t, n)]; continue
        if t != "id":
            warn.append(f"신규 리소스 {t}/{n}: id 타입만 자동 추가 지원"); continue
        used = [int(v, 16) for (tt, _), v in tgt.items() if tt == t]
        new = "0x%08x" % (max(used) + 1)
        pub_txt = pub_txt.replace("</resources>", f'    <public type="{t}" name="{n}" id="{new}" />\n</resources>')
        ids_p = os.path.join(src, "res/values/ids.xml")
        ids = open(ids_p, encoding="utf8").read()
        ids = ids.replace("</resources>", f'    <item type="id" name="{n}" />\n</resources>')
        open(ids_p, "w", encoding="utf8", newline="").write(ids)
        for rp in glob.glob(os.path.join(src, "smali*", "**", "R$id.smali"), recursive=True):
            s = open(rp, encoding="utf8", newline="").read()
            s = s.replace(".method", f".field public static final {n}:I = {new}\n\n.method", 1)
            open(rp, "w", encoding="utf8", newline="").write(s)
        tgt[(t, n)] = new; tokens[(t, n)] = new
        log(f"  신규 리소스 {t}/{n} -> {new}")
    open(pub_path, "w", encoding="utf8", newline="").write(pub_txt)

    # 2) 패치팩 ID -> 대상 ID 변환표 (이름 기준)
    remap, missing = {}, set()
    for pid, (t, n) in idmap.items():
        tid = tgt.get((t, n))
        if tid is None: missing.add(pid)
        elif tid != pid: remap[pid] = tid
    log(f"  리소스 ID 변환 {len(remap)}건 (대상에 없는 이름 {len(missing)}건)")

    def conv(text, kind):
        if kind == "smali":
            text = TOKEN.sub(lambda m: tokens.get((m.group(1), m.group(2)), m.group(0)), text)
            return HEX.sub(lambda m: remap.get(m.group(0), m.group(0)), text)
        return text  # xml은 이름 기반이라 변환 불필요

    def locate(rel):
        if os.path.exists(os.path.join(src, rel)): return os.path.join(src, rel)
        if rel.startswith("smali/"):
            for d in glob.glob(os.path.join(src, "smali_classes*")):
                p = os.path.join(d, rel[len("smali/"):])
                if os.path.exists(p): return p
        return None

    # 3) 파일 적용
    for item in pack["items"]:
        if item["id"] not in item_ids: continue
        for rec in item["files"]:
            rel = rec["path"]
            if rel in excluded: stats["skip"] += 1; continue
            data_p = os.path.join(pack_dir, "files", rel)
            dst = locate(rel)
            if dst is None:
                dst = os.path.join(src, rel)
                if rec["op"] == "replace": warn.append(f"대상에 없어 새로 추가: {rel}")
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            if rec["remap"] == "none":
                shutil.copyfile(data_p, dst)
            else:
                txt = open(data_p, encoding="utf8", newline="").read()
                open(dst, "w", encoding="utf8", newline="").write(conv(txt, rec["remap"]))
            stats["replace" if rec["op"] == "replace" else "add"] += 1
        # 4) 매니페스트 수정
        mp = os.path.join(src, "AndroidManifest.xml")
        for op in item.get("manifest_ops", []):
            m = open(mp, encoding="utf8", newline="").read()
            if op["op"] == "add_permission":
                if f'android:name="{op["name"]}"' in m:
                    log("  매니페스트: 권한이 이미 있음"); continue
                nl = "\r\n" if "\r\n" in m else "\n"
                tag = f'    <uses-permission android:name="{op["name"]}"/>{nl}'
                i = m.find("<application")
                if i < 0: warn.append("매니페스트에 <application> 이 없어 권한을 추가하지 못함"); continue
                m2 = m[:i].rstrip(" ") + tag + "    " + m[i:] if m[:i].endswith(("\n", " ")) else m[:i] + nl + tag + m[i:]
            else:
                m2 = re.sub(op["pattern"], "", m)
                if m2 == m: log("  매니페스트: 이미 정리되어 있음"); continue
            open(mp, "w", encoding="utf8", newline="").write(m2)
        log(f"  [{item['title']}] 완료")
    return {"stats": stats, "warnings": warn}



def fix_fake_images(src, log=print):
    """확장자는 .png 인데 실제로는 BMP/JPEG/GIF/WebP 인 리소스를 올바른 확장자로 바꾼다.
    (aapt 가 'Not a PNG file' 로 빌드를 중단하는 것을 막는다)"""
    magic = [(b"BM", ".bmp"), (b"\xff\xd8\xff", ".jpg"), (b"GIF8", ".gif")]
    fixed = 0
    for base, _, files in os.walk(os.path.join(src, "res")):
        for fn in files:
            if not fn.lower().endswith(".png"): continue
            p = os.path.join(base, fn)
            with open(p, "rb") as f: head = f.read(12)
            if head[:8] == b"\x89PNG\r\n\x1a\n": continue
            ext = None
            for m, e in magic:
                if head.startswith(m): ext = e; break
            if head[:4] == b"RIFF" and head[8:12] == b"WEBP": ext = ".webp"
            if ext is None:
                log(f"  ! PNG 형식이 아닌 파일(변환 불가): {os.path.relpath(p, src)}"); continue
            if fn.lower().endswith(".9.png"):
                log(f"  ! 9-patch 이미지가 PNG 형식이 아님: {os.path.relpath(p, src)}"); continue
            new = p[:-4] + ext
            os.replace(p, new); fixed += 1
            log(f"  이미지 확장자 수정: {os.path.relpath(p, src)} -> {os.path.basename(new)}")
    return fixed

# ---- 외부 도구 실행 ----
import time, threading, locale, traceback


class Cancelled(Exception):
    """사용자가 작업을 중지함"""


HEARTBEAT = 20                      # 오래 걸리는 단계에서 상태를 알리는 간격(초)
_state = {"proc": None, "cancel": threading.Event()}
LAST_LOG = {"path": None}
ENC = locale.getpreferredencoding(False) or "utf8"   # 자바 출력 인코딩과 맞춤 (한국어 윈도우: cp949)


def tools():
    t = os.path.join(base_dir(), "tools")
    java = os.path.join(t, "jre", "bin", "java.exe" if os.name == "nt" else "java")
    return {"java": java if os.path.exists(java) else "java",
            "apktool": os.path.join(t, "apktool.jar"),
            "signer": os.path.join(t, "uber-apk-signer.jar")}


# ---- 로그 파일 ----
def log_dir():
    if os.name == "nt":
        base = os.environ.get("LOCALAPPDATA") or os.path.expanduser("~")
        return os.path.join(base, "iNavi3DS_Patcher", "logs")
    return os.path.join(os.path.expanduser("~"), ".inavi3ds_patcher", "logs")


def _new_log_path():
    d = log_dir(); os.makedirs(d, exist_ok=True)
    for old in sorted(glob.glob(os.path.join(d, "patch_*.log")))[:-19]:   # 최근 20개만 보관
        try: os.remove(old)
        except OSError: pass
    return os.path.join(d, time.strftime("patch_%Y%m%d_%H%M%S.log"))


class _Logger:
    """화면(ui)과 로그 파일에 동시에 기록. file_only 는 파일에만 기록(길어지는 상세 내용용)"""
    def __init__(self, ui, path): self.ui, self.path = ui, path
    def _w(self, msg):
        try:
            with open(self.path, "a", encoding="utf8") as f: f.write(time.strftime("%H:%M:%S ") + msg + "\n")
        except OSError: pass
    def __call__(self, msg): self._w(msg); self.ui(msg)
    def file_only(self, msg): self._w(msg)


def _fmt(sec):
    sec = int(sec); m, s = divmod(sec, 60); h, m = divmod(m, 60)
    return f"{h}시간 {m}분" if h else (f"{m}분 {s}초" if m else f"{s}초")


# ---- 중지 / 실행 ----
def _kill_tree(p):
    try:
        if os.name == "nt":
            subprocess.run(["taskkill", "/F", "/T", "/PID", str(p.pid)], creationflags=NOWIN,
                           stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        else:
            p.kill()
    except Exception:
        pass


def cancel():
    """진행 중인 작업을 중지 (실행 중인 자바 프로세스 트리도 종료)"""
    _state["cancel"].set()
    p = _state["proc"]
    if p is not None and p.poll() is None: _kill_tree(p)


def run(cmd, log):
    if _state["cancel"].is_set(): raise Cancelled()
    log("  $ " + " ".join(os.path.basename(c) if os.path.sep in c else c for c in cmd[:4]) + " ...")
    # stdin 을 막아 두어, 입력을 기다리며 멈추는 일이 없게 한다 (창만 있는 exe 에서 특히 중요)
    p = subprocess.Popen(cmd, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                         text=True, encoding=ENC, errors="replace", creationflags=NOWIN)
    _state["proc"] = p
    stop, t0 = threading.Event(), time.time()

    def beat():
        while not stop.wait(HEARTBEAT):
            log(f"  … 실행 중 ({_fmt(time.time() - t0)} 경과)")
    threading.Thread(target=beat, daemon=True).start()
    try:
        for line in p.stdout:
            line = line.rstrip()
            if line: log("    " + line)
        rc = p.wait()
    finally:
        stop.set(); _state["proc"] = None
    if _state["cancel"].is_set(): raise Cancelled()
    if rc != 0: raise RuntimeError(f"명령 실패 (코드 {rc})")
    log(f"  ✓ 완료 ({_fmt(time.time() - t0)})")


# ---- 환경 점검 ----
def java_info(java):
    """(첫 줄, 64비트 여부). 자바를 못 찾으면 (None, False)"""
    try:
        r = subprocess.run([java, "-version"], stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                           text=True, encoding=ENC, errors="replace", timeout=30, creationflags=NOWIN)
    except FileNotFoundError:
        return None, False
    except Exception as e:
        return f"확인 실패: {e}", True
    lines = r.stdout.strip().splitlines()
    return (lines[0] if lines else "?"), ("64-bit" in r.stdout.lower())


def total_ram_mb():
    try:
        if os.name == "nt":
            import ctypes

            class MS(ctypes.Structure):
                _fields_ = [("dwLength", ctypes.c_ulong), ("dwMemoryLoad", ctypes.c_ulong),
                            ("ullTotalPhys", ctypes.c_ulonglong), ("ullAvailPhys", ctypes.c_ulonglong),
                            ("ullTotalPageFile", ctypes.c_ulonglong), ("ullAvailPageFile", ctypes.c_ulonglong),
                            ("ullTotalVirtual", ctypes.c_ulonglong), ("ullAvailVirtual", ctypes.c_ulonglong),
                            ("sullAvailExtendedVirtual", ctypes.c_ulonglong)]
            m = MS(); m.dwLength = ctypes.sizeof(MS)
            ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m))
            return int(m.ullTotalPhys // 1048576)
        return int(os.sysconf("SC_PAGE_SIZE") * os.sysconf("SC_PHYS_PAGES") // 1048576)
    except Exception:
        return None


def heap_flag(is64):
    """자바 최대 힙. 64비트면 램의 60%(1~4GB), 32비트면 1GB (그 이상은 JVM 이 시작되지 않음)"""
    if IS_TERMUX: return "-Xmx1g"
    if not is64: return "-Xmx1024m"
    total = total_ram_mb()
    return None if total is None else "-Xmx%dm" % max(1024, min(4096, int(total * 0.6)))


def read_build(src):
    """apktool 이 디컴파일한 폴더에서 (versionCode, versionName)"""
    for name in ("apktool.yml", "apktool.json"):
        p = os.path.join(src, name)
        if os.path.exists(p):
            t = open(p, encoding="utf8", errors="replace").read()
            m = re.search(r"versionCode\W+(\d+)", t)
            n = re.search(r"versionName\W+([^\s'\",}]+)", t)
            if m: return m.group(1), (n.group(1) if n else "?")
    return None, None


def _check_cancel():
    if _state["cancel"].is_set(): raise Cancelled()


def patch_apk(apk, out_apk, pack_dir, item_ids, excluded, keystore, work_root, ui_log, confirm=None):
    """confirm(msg)->bool : 빌드가 다를 때 계속할지 묻는 콜백 (None 이면 경고만 하고 계속)"""
    _state["cancel"].clear()
    path = _new_log_path(); LAST_LOG["path"] = path
    log = _Logger(ui_log, path)
    try:
        T = tools()
        for k in ("apktool", "signer"):
            if not os.path.exists(T[k]): raise RuntimeError(f"도구가 없습니다: {T[k]}")
        log(f"패처 빌드: {BUILD_ID}")
        jl, is64 = java_info(T["java"])
        if jl is None:
            raise RuntimeError("Java 를 찾을 수 없습니다. tools\\jre 를 넣거나 64비트 Java 를 설치하세요.")
        log(f"  Java: {jl}")
        if not is64 and not IS_TERMUX:
            log("  ! 32비트 Java 입니다. 큰 APK에서 메모리 부족으로 매우 느려지거나 멈출 수 있어 64비트 Java 를 권장합니다")
        heap = heap_flag(is64)
        JV = [T["java"]] + ([heap] if heap else [])
        size_mb = os.path.getsize(apk) / 1048576
        log(f"  APK: {os.path.basename(apk)} ({size_mb:.0f} MB) · 힙 {heap or '기본'}")
        if size_mb > 300:
            log("  ! APK 가 큽니다. 디컴파일/빌드에 수십 분 이상 걸릴 수 있습니다 (진행 중에는 경과 시간이 표시됩니다)")
        try:
            free_mb = shutil.disk_usage(work_root).free / 1048576
            if free_mb < size_mb * 4:
                log(f"  ! 임시 폴더 여유 공간이 부족할 수 있습니다 (여유 {free_mb:.0f} MB, 권장 {size_mb * 4:.0f} MB 이상)")
        except OSError:
            pass
        log(f"  로그 파일: {path}")

        work = os.path.join(work_root, "i3dp"); shutil.rmtree(work, ignore_errors=True); os.makedirs(work)
        src, built = os.path.join(work, "src"), os.path.join(work, "built.apk")

        log("1/4 디컴파일 (apktool)")
        run(JV + ["-jar", T["apktool"], "d", "-f", "-o", src, apk], log)
        _check_cancel()

        # 패치팩 기준 빌드와 대상 APK 빌드 비교
        base = load_pack(pack_dir).get("base_build")
        code, name = read_build(src)
        if base and code:
            if code == base["code"]:
                log(f"  대상 APK 빌드: {name} (패치팩 기준과 일치)")
            else:
                msg = (f"대상 APK 빌드가 패치팩 기준과 다릅니다.\n  대상: {name}\n  기준: {base['name']}\n"
                       "다른 빌드에 적용하면 설치 후 실행 중 오류가 날 수 있습니다.")
                log("  ! 대상 APK 빌드가 패치팩 기준과 다릅니다 (대상 %s / 기준 %s)" % (name, base["name"]))
                if confirm is not None and not confirm(msg): raise Cancelled()
        elif base:
            log("  ! 대상 APK 의 빌드 번호를 확인하지 못했습니다")
        _check_cancel()

        log("2/4 패치 적용")
        res = apply_pack(src, pack_dir, item_ids, excluded, log)
        ws = res["warnings"]
        for w in ws[:6]: log("  ⚠ " + w)
        if len(ws) > 6:
            log(f"  ⚠ … 외 {len(ws) - 6}건 (전체 내용은 로그 파일에 기록됨)")
            for w in ws[6:]: log.file_only("  ⚠ " + w)
        _check_cancel()

        log("3/4 빌드 (apktool)")
        fix_fake_images(src, log)
        aapt = os.environ.get("AAPT_PATH") or (shutil.which("aapt") if IS_TERMUX else None)
        if IS_TERMUX and not aapt:
            raise RuntimeError("aapt 를 찾을 수 없습니다. Termux에서 'pkg install aapt' 를 실행하세요.")
        bcmd = JV + ["-jar", T["apktool"], "b"] + (["-a", aapt] if aapt else []) + ["-o", built, src]
        if aapt: log(f"  aapt: {aapt}")
        run(bcmd, log)
        _check_cancel()

        log("4/4 정렬 + 서명")
        outdir = os.path.join(work, "signed"); os.makedirs(outdir, exist_ok=True)
        sign_in = built
        cmd = JV + ["-jar", T["signer"], "-a", sign_in, "--out", outdir, "--allowResign"]
        if IS_TERMUX:
            # 서명 도구 내장 zipalign 은 폰(ARM)에서 실행되지 않으므로 건너뛰고, 있으면 Termux의 zipalign 사용
            za = shutil.which("zipalign")
            if za:
                aligned = os.path.join(work, "aligned.apk")
                run([za, "-f", "-p", "4", built, aligned], log)
                cmd[cmd.index(built)] = aligned
            else:
                log("  ! zipalign 없음 - 정렬 없이 서명합니다 (대부분 문제 없음)")
            cmd.append("--skipZipAlign")
        if keystore:
            cmd += ["--ks", keystore["path"], "--ksAlias", keystore["alias"],
                    "--ksPass", keystore["pass"], "--ksKeyPass", keystore.get("keypass") or keystore["pass"]]
        run(cmd, log)
        signed = sorted(glob.glob(os.path.join(outdir, "*.apk")))
        if not signed: raise RuntimeError("서명된 APK를 찾지 못했습니다")
        shutil.copyfile(signed[0], out_apk)
        shutil.rmtree(work, ignore_errors=True)
        log(f"완료: {out_apk}")
        return res
    except Cancelled:
        log("중지됨")
        raise
    except Exception:
        log.file_only(traceback.format_exc())
        raise
